# EXPORT_CONTRACT.md — contrato técnico del motor de exportación
streaming (`backend/export_streaming/`)

Fase 16 de la Orden Maestra de Saneamiento Pre-Auditoría Aldhira
Phonographic. Se pospuso documentar esto formalmente hasta que hubiera
código real que lo cumpliera (documentar un contrato antes de que el
código lo cumpla es apariencia sin sustancia) — con Fases 1/8/10 y el
catálogo completo de normalización implementados y verificados
(aunque todavía no integrados a la GUI real), ese momento ya llegó.

## Garantías

1. **Memoria O(block_frames), nunca O(duración de la sesión).**
   Ningún componente de `export_streaming/` materializa la sesión
   completa en RAM. `SegmentProvider.iter_blocks()` lee un segmento a
   la vez, en bloques acotados (`DEFAULT_BLOCK_FRAMES=32768` por
   defecto), liberando cada segmento antes de abrir el siguiente.
   Medido, no solo argumentado: un caso de 12 000 000 de frames
   normalizados de punta a punta usó ~804 KB de RSS (GAP-028).

2. **Ningún error de formato o de lectura se resuelve en silencio.**
   - `FormatMismatchError` — segmentos con distinto samplerate/
     canales/ancho de muestra, o un segmento faltante.
   - `SegmentReadError` (GAP-034) — header WAV corrupto/no válido, o
     un segmento TRUNCADO (el header declara más frames de los que el
     archivo físicamente contiene) — se detecta en el momento y se
     nombra el segmento exacto responsable.
   - `ExportAbortError` (`AtomicFinalizer`) — discrepancia entre
     frames procesados y frames esperados, o cualquier fallo del
     encoder — nunca se deja un archivo final a medias.

3. **Finalización atómica.** `AtomicFinalizer` nunca deja un archivo
   final corrupto o parcial visible en el destino: escribe a una ruta
   temporal y solo la renombra al destino final si todo el pase
   terminó sin error. Un crash a mitad de escritura nunca deja un
   archivo huérfano con el nombre final.

4. **`WavEncoder` — bit-exacto para PCM_16/PCM_24 sin DSP** (GAP-026).
   PCM_32 tiene un límite real (no un bug) de precisión de `float32`
   (24 bits de mantisa) — documentado y medido, no asumido.

5. **RF64 automático sobre ~3.9 GB** (GAP-033) — `WavEncoder` decide
   RIFF vs RF64 ANTES de escribir el primer byte, usando
   `total_frames_hint` (siempre conocido de antemano por
   `SegmentProvider`, que suma headers de segmentos). Nunca produce un
   WAV truncado ni falla con `NotImplementedError`.

6. **Los 20 modos de `NormalizationMode`/`NormalizationModeV21` tienen
   una réplica streaming verificada** (GAP-027 a GAP-030) — arquitectura
   de dos pasadas (medir → aplicar), memoria O(bloque) u O(n_bloques),
   nunca O(duración). Bit-exactos salvo dos excepciones documentadas y
   medidas: `INTELLIGENT_PEAK` (percentil aproximado por histograma) y
   `TRUE_PEAK` en fronteras de segmento (discrepancia acotada).

7. **`DSP_NONFINITE_OUTPUT`** (GAP-025) — aunque vive en
   `backend/dsp/`, no en `export_streaming/`, gobierna cualquier
   integración futura entre ambos: ninguna etapa DSP debe propagar
   NaN/Inf aguas abajo; si ocurre, se sanea y se resetea el estado
   interno de la etapa afectada.

## Lo que este contrato NO cubre todavía

- **No está integrado a `main_window.export()`** — `_build_export_array()`
  + `ExporterBase.export()` siguen siendo el camino real que la GUI
  usa hoy. **Actualización (GAP-036)**: se confirmó, con ejecución
  real (no solo lectura de código), que `_build_export_array()`
  produce un resultado bit-exacto idéntico a `SegmentProvider`
  streaming para el caso base — reduce el riesgo de una futura
  integración, pero el swap real todavía no se hizo, y `export()`
  completo (diálogos, normalización, codecs, progreso asíncrono) es
  bastante más grande que `_build_export_array` en aislamiento.
- Los codecs FLAC/OGG/WavPack (`lorito_exporters.py`) no tienen
  equivalente streaming — solo WAV/RF64.
- El resampleo por velocidad de exportación no se ha auditado en el
  camino streaming (requiere medir `_resample_stateful` con hardware o
  stubs de sounddevice/soundfile, ver GAP-029).
