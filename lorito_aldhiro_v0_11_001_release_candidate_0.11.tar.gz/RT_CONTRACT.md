# RT_CONTRACT.md — contrato técnico del path de tiempo real (captura)

Fase 16 de la Orden Maestra de Saneamiento Pre-Auditoría Aldhira
Phonographic. Documenta lo que está construido y VERIFICADO (con
concurrencia real de hilos donde aplica) en el path de captura —
distinguiendo explícitamente entre lo que ya rige `CaptureEngineV2`
en producción y lo que existe como propuesta verificada, todavía sin
integrar.

## Vigente hoy en `CaptureEngineV2` (producción)

1. **`RingBufferAbsorcion.write()` — nunca bloquea el callback más
   allá de un lock breve** (`threading.Condition`, contención mínima).
   Modo overwrite-oldest: si el buffer está lleno, sacrifica el slot
   más antiguo y cuenta el overrun (`_overrun_total`) — nunca acumula
   deuda silenciosa.

2. **`ColaElasticaDisco` — nunca descarta silenciosamente** (GAP-031:
   `dropped_frames` ahora sí se incrementa de verdad cuando la cola
   está llena; el drain loop ya leía este campo, solo que antes
   siempre valía 0).

3. **Recovery no-destructivo** (`_auto_recover`, GAP-032, auditado sin
   defectos): cooldown de 45s entre cadenas de recovery, backoff
   exponencial (200ms→12s cap), hasta 12 intentos, rotación de
   blocksize desde el intento 4. RBA y CED NUNCA se limpian durante un
   recovery — los frames en vuelo se preservan.

4. **Política de reintento de escritura a disco** (GAP-034, verificado
   con inyección de fallos real): un `OSError` genérico se reintenta
   hasta `CE_DISK_WRITE_RETRY_MAX=3` veces (10ms entre intentos) antes
   de descartar el bloque; `ENOSPC` NO se reintenta — detiene el
   writer de inmediato. Un chequeo de espacio libre (`os.statvfs`)
   antes de cada intento evita siquiera intentar escribir si quedan
   menos de 50MB (o 4× el tamaño estimado del bloque) libres. Perder
   un batch nunca mata el `DiskWriterV2` — el siguiente batch se
   escribe con normalidad.

5. **Política de errores de lectura de segmentos** (GAP-034, aplica al
   RELEER segmentos ya escritos, p. ej. para exportar): un segmento
   truncado (header miente sobre su tamaño real — el síntoma real de
   un crash a mitad de escritura) se detecta y se nombra
   explícitamente (`SegmentReadError`), nunca se entrega en silencio
   como si fuera el final normal de la sesión.

## Construido y verificado, TODAVÍA NO integrado a producción

6. **`LockFreeSPSCRingBuffer`** (`backend/rt/`, GAP-031) — alternativa
   WAIT-FREE a `RingBufferAbsorcion`: el productor nunca toma un lock
   ni espera nada, es el CONSUMIDOR quien detecta los overruns (al
   notar un salto de secuencia), protocolo tipo seqlock para evitar
   lecturas mezcladas. Verificado con hilos productor/consumidor
   REALES de Python (no simulados), incluido el escenario más agresivo
   posible (3 slots, 5000 bloques, sin sleeps). **GAP-037**: verificado
   también bajo un pipeline de captura completo simulado (audio real
   fluyendo vía un stub funcional de `sounddevice.InputStream`) — el
   swap real dentro de `CaptureEngineV2` en producción sigue pendiente,
   ahora con más evidencia de que la mecánica es correcta bajo carga.

7. **Máquina de estados archival** (`backend/archival/`, GAP-032) —
   clasifica una sesión ya finalizada en `ARCHIVAL_SAFE`/`DEGRADED`/
   `INVALID` a partir de los contadores reales del motor
   (`frames_dropped`, `xrun_count`, `rba_overrun_total`,
   `ced_dropped_frames`, `recovery_count`, `starvation_events`,
   verificación de segmentos en disco). **No está wireada a ningún
   punto real de `CaptureEngineV2` que la invoque al finalizar una
   sesión.** Deliberadamente NO depende de `integrity_crc32_errors`
   (ver punto 8).

10. **Pipeline de captura end-to-end verificado con ejecución real**
    (GAP-037) — con stubs funcionales de `sounddevice`/`soundfile`,
    `CaptureEngineV2` se corrió de punta a punta: audio simulado →
    `_audio_callback` real → `RingBufferAbsorcion` real → drain loop
    real → `ColaElasticaDisco` real → `DiskWriterV2` real → WAV en
    disco, con cero frames perdidos y el watchdog escalando
    YELLOW→ORANGE→RED→recovery con temporización real. Primera vez
    que este mecanismo se ejercita con ejecución real, no solo lectura
    de código.

11. **`resample_stateful_continuous`** (`backend/dsp/lorito_dsp_
    resample_continuous.py`, GAP-037) — corrección MEDIDA (no solo
    especulada) de la deriva de fase de `_resample_stateful`: con los
    tamaños de bloque reales de `PlaybackEngine`, el legado acumula
    error progresivamente en cada frontera de chunk. La corrección
    (historial de 2 muestras entre llamadas) reproduce el valor real
    con precisión de `float32`, verificado contra una referencia
    Catmull-Rom calculada a mano. NO integrada a `PlaybackEngine` real
    — requiere extender `_SpeedState` y tocar 4-5 sitios de llamada.

## Conectado en esta sesión (GAP-035)

8. **Checksums reales por segmento** (`backend/archival/
   lorito_segment_checksum.py`) — `DiskWriterV2` calcula SHA-256+CRC32
   de cada segmento RELEYÉNDOLO desde disco inmediatamente después de
   cerrarlo (nunca desde el buffer float32 previo a la conversión de
   `soundfile`, cuyo redondeo interno no se puede verificar en este
   sandbox sin la librería instalada — ver el docstring del módulo
   para el razonamiento completo). `classify_session()` (Fase 7) puede
   recibir estos checksums y re-verificarlos, marcando la sesión
   `INVALID` con el segmento y el campo exactos si detecta corrupción
   real entre la captura y la clasificación. Esto reemplaza al viejo
   `integrity_crc32_errors`/`_IntegrityMonitor` (nunca conectado, ver
   más abajo) con un mecanismo más simple y verificado end-to-end
   contra `DiskWriterV2` real (incluida detección de bit rot real
   simulado y de truncamiento posterior).

## Defecto real documentado, deliberadamente NO reutilizado

9. **`_IntegrityMonitor` (CRC32/SHA256 incremental por bloque,
   `lorito_ring_buffers.py`) sigue sin conectarse** —
   `integrity_crc32_errors` sigue en 0 estructuralmente. Se investigó
   conectarlo directamente (GAP-035) pero se descartó: haría hashing
   del buffer float32 ANTES de la conversión interna de `soundfile` a
   PCM, una conversión que este sandbox no puede verificar si es
   bit-exacta — GAP-026 ya encontró que la propia implementación
   streaming de este proyecto SÍ tenía un bug de ese tipo, así que
   asumir que `soundfile` no lo tiene sería repetir el mismo error de
   razonamiento. El checksum del punto 8 (releer de disco) resuelve el
   mismo problema sin ese riesgo — `_IntegrityMonitor` queda como
   código muerto documentado, no como algo pendiente de "arreglar".

## Generational Transport (`backend/transport/`) — pieza independiente

9. **`GenerationGuard`** (GAP-034, casos "seek durante prefetch" y
   "scrub con underrun" verificados explícitamente) — cualquier bloque
   de audio prefetcheado que no coincida con la generación de
   transporte VIGENTE se descarta, sin importar cuánto tiempo lleve en
   vuelo ni en qué orden lleguen los bloques atrasados. No está
   integrado a `PlaybackEngine` real (contrato aislado, verificable
   sin audio real, ver `lorito_transport_state.py`).
