from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Clasificación de sesiones de captura finalizadas en ARCHIVAL_SAFE/DEGRADED/INVALID.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_archival_state.py — Fase 7 de la Orden Maestra de Saneamiento
Pre-Auditoría Aldhira Phonographic: máquina de estados de integridad
post-sesión (`ARCHIVAL_SAFE` / `DEGRADED` / `INVALID`).

CONSTRUIDO DESDE CERO esta sesión — auditando el código existente se
confirmó que esta máquina de estados NO EXISTÍA en ninguna forma:
`ARCHIVAL_SAFE_FPS`/`ARCHIVAL_SAFE_WATCHDOG` (`lorito_constants.py`)
son constantes de rendimiento de GUI (FPS/frecuencia de watchdog en un
modo de bajo consumo) sin ninguna relación con integridad de sesión;
`archival_safe_mode` (`CaptureEngineStatus`) es un simple toggle
manual del usuario (`lorito_main_window.py`, línea ~1043), no una
clasificación calculada.

Hallazgo adicional relevante para el diseño de este módulo:
`integrity_crc32_errors` (`CaptureEngineStatus`) está declarado,
documentado y se muestra en logs/reportes, pero **nunca se incrementa
en ningún punto del código** — y más aún, `_IntegrityMonitor`
(`lorito_ring_buffers.py`, CRC32+SHA256 por segmento, completamente
implementado y thread-safe) **nunca se referencia desde
`lorito_capture_engine.py`** — el `DiskWriterV2` real no lo usa. Es
decir, `integrity_crc32_errors` no es solo "un contador que nadie
incrementa" (como era el caso de `ColaElasticaDisco.dropped_frames`,
GAP-031) sino un campo que hoy es ESTRUCTURALMENTE imposible que deje
de ser 0 — no existe ningún mecanismo de verificación conectado que
pudiera generar ese valor. Por eso esta clasificación NO depende de
`integrity_crc32_errors` (sería una falsa señal de "todo perfecto"
sistemáticamente) y se apoya únicamente en contadores que SÍ están
conectados y son fiables hoy: `frames_dropped`, `xrun_count`,
`recovery_count`, `rba_overrun_total`, `ced_dropped_frames`
(fiable desde GAP-031) y `starvation_events`.

Conectar `_IntegrityMonitor` al `DiskWriterV2` real (para que
`integrity_crc32_errors` dejara de ser una promesa vacía) es un
trabajo mayor, que toca el camino de escritura real y necesitaría
verificarse con datos fluyendo de verdad por `ColaElasticaDisco` — se
deja como línea de trabajo futura explícita, no incluida en esta
sesión.

Criterios de clasificación (diseño de esta sesión — heurística
razonable, no extraída de un documento previo; sujeta a ajuste si una
sesión futura aporta un criterio más preciso):

  INVALID  — la copia NO puede considerarse una captura completa y
             fiel:
             · `frames_dropped > 0` (pérdida de audio irrecuperable —
               ENOSPC, fallo de escritura tras agotar reintentos).
             · algún segmento declarado en `segment_paths` no existe
               en disco, o tiene tamaño 0.
             · el stream terminó muerto sin haberse podido recuperar
               (`wd_phase` distinto de "OK" al finalizar Y
               `recovery_count > 0` — se intentó recovery y no se
               logró seguir grabando).

  DEGRADED — la captura es completa (ningún frame perdido de forma
             irrecuperable) pero hubo anomalías registradas durante la
             sesión que ameritan una advertencia antes de tratarla
             como patrimonio definitivo:
             · `xrun_count > 0`
             · `rba_overrun_total > 0`
             · `ced_dropped_frames > 0`
             · `recovery_count > 0` (con recuperación exitosa)
             · `starvation_events > 0`
             · `dsp_nonfinite_total > 0` (GAP-062, §16/FASE 6 — ver más
               abajo) — cualquier muestra NaN/Inf saneada por la cadena
               DSP durante la sesión, sin importar cuántas.

  ARCHIVAL_SAFE — ninguna de las condiciones anteriores — sesión sin
             anomalías registradas.

── FASE 6 (§16, GAP-062) — política NaN/Inf, decidida por el usuario ──

`NRCoordinator`/`sanitize_finite()` (Fase 10, GAP-025) sanean NaN/Inf
en SILENCIO (nunca lanzan excepción, ni en captura en vivo ni en
export/reprocesado offline) y solo cuentan cuántas muestras sanearon
(`nonfinite_counts`) — esa política de recuperación silenciosa se
CONFIRMÓ explícitamente vía cuestionario al usuario en GAP-062 (no se
reabre sin una decisión nueva). `DSPIntegrityError` sigue existiendo
sin conectar a ningún `raise` real — ver `lorito_errors_dsp.py`.

Lo que SÍ se decidió cambiar: el conteo de saneamientos (antes solo
diagnóstico interno, no leído en ningún otro sitio) ahora SÍ afecta la
clasificación archival — cualquier `dsp_nonfinite_total > 0` durante
la sesión impide `ARCHIVAL_SAFE` (como mucho `DEGRADED`), aplicado por
igual a TODAS las etapas de la cadena (input y cada etapa interna),
sin umbral de tolerancia — una sola muestra saneada ya degrada.
Consistente con el espíritu de trazabilidad RAW+TREATED (§P0.5): una
sesión con audio sustituido en algún punto no debe archivarse como
"sin anomalías" de forma silenciosa.
"""

import os
from dataclasses import dataclass, field
from enum import Enum


class ArchivalReason(str):
    """Motivo de clasificación (§9, FASE 2 de la Orden de Saneamiento,
    Integración y Consolidación — GAP-052).

    Subclase de `str`, no un objeto separado: `result.reasons` seguía
    siendo, antes de esta fase, una lista de strings planos, y varios
    tests existentes (`tests/test_archival_state.py`) hacen `assertIn
    ("texto", result.reasons[0])` — una comprobación de substring que
    solo funciona si el elemento se comporta como un string de
    verdad. Al heredar de `str` en vez de envolverlo, cada
    `ArchivalReason` ES el mismo texto exacto de siempre (cero cambio
    de comportamiento para código existente) y ADEMÁS lleva un `code`
    estructurado para quien quiera reaccionar programáticamente sin
    parsear texto — mismo patrón que `LoritoError` heredando de
    `RuntimeError` en GAP-051.
    """

    def __new__(cls, text: str, code: str = ""):
        obj = super().__new__(cls, text)
        obj.code = code
        return obj


class ArchivalState(Enum):
    ARCHIVAL_SAFE = "ARCHIVAL_SAFE"
    DEGRADED = "DEGRADED"
    INVALID = "INVALID"


@dataclass
class ArchivalClassification:
    state: ArchivalState
    reasons: list = field(default_factory=list)

    # ── GAP-052 (§9, FASE 2) — campos cuantitativos del contrato ──────
    # Aditivos: `state`/`reasons` no cambiaron de nombre ni significado.
    frames_expected: int = 0
    frames_written: int = 0
    frames_lost: int = 0
    segments_expected: int = 0
    segments_valid: int = 0
    segments_invalid: int = 0
    checksum_verified: bool = False
    dsp_nonfinite_total: int = 0  # GAP-062, §16/FASE 6 — ver docstring del módulo

    @property
    def status(self) -> ArchivalState:
        """Alias de `state` — nombre exacto del campo en el contrato
        §9 (`ArchivalState.status`). Mismo valor, nunca un cálculo
        distinto."""
        return self.state

    @property
    def is_safe(self) -> bool:
        return self.state == ArchivalState.ARCHIVAL_SAFE

    @property
    def is_usable(self) -> bool:
        """SAFE o DEGRADED son usables (con o sin advertencia);
        INVALID no debe tratarse como una captura patrimonial válida."""
        return self.state != ArchivalState.INVALID


def _get(status, name, default=0):
    """Lee un atributo de `status` (objeto `CaptureEngineStatus` o
    dict-like) de forma tolerante — permite pasar tanto la instancia
    real como un snapshot en dict (útil para tests sin depender de
    `lorito_capture_engine.py`)."""
    if isinstance(status, dict):
        return status.get(name, default)
    return getattr(status, name, default)


def classify_session(status, segment_paths=None,
                     check_files_exist: bool = True,
                     segment_checksums=None,
                     dsp_nonfinite_total: int = 0) -> ArchivalClassification:
    """Clasifica una sesión de captura ya finalizada. `status` puede
    ser un `CaptureEngineStatus` real o un dict con los mismos nombres
    de campo (para tests). `segment_paths`, si se provee, se verifica
    en disco (existencia + tamaño > 0) salvo que `check_files_exist`
    sea False (útil para clasificar a partir de solo telemetría, sin
    acceso al filesystem de los segmentos).

    `segment_checksums` (GAP-035, opcional): lista de dicts con la
    forma que devuelve `DiskWriterV2.get_segment_checksums()`/
    `compute_segment_checksum()` (uno por segmento, con al menos
    `path`/`sha256`/`crc32`/`frames`). Si se provee, cada segmento se
    RE-LEE de disco y se recalcula su checksum — una discrepancia real
    (bit rot, fallo de hardware de almacenamiento entre la captura y
    esta clasificación) marca la sesión como INVALID, nombrando el
    segmento y qué campo no coincide. Sin este parámetro, la
    clasificación sigue funcionando igual que antes (GAP-032) — esto
    es un refinamiento opcional, no un requisito nuevo.

    `dsp_nonfinite_total` (GAP-062, §16/FASE 6, opcional, default 0):
    total de muestras NaN/Inf saneadas por la cadena DSP durante la
    sesión (típicamente `sum(NRCoordinator.nonfinite_counts.values())`)
    — ver la nota de FASE 6 en el docstring del módulo. Cualquier valor
    > 0 impide `ARCHIVAL_SAFE`, sin umbral de tolerancia.

    GAP-052 (§9, FASE 2): además de `state`/`reasons` (sin cambios de
    comportamiento), el resultado ahora incluye los campos
    cuantitativos del contrato — ver `ArchivalClassification`. Nota
    sobre `checksum_verified`: es `True` únicamente si `segment_
    checksums` se proveyó Y todos los segmentos verificables
    coincidieron; si no se provee, es `False` de forma honesta (nunca
    `True` vacuo por "no había nada que verificar") — pero, a
    diferencia de lo que el texto literal de §9 podría sugerir, `state`
    NO exige `checksum_verified == True` para ser `ARCHIVAL_SAFE`: el
    parámetro sigue siendo OPCIONAL (como lo era antes de esta fase) y
    forzar esa exigencia habría reclasificado, sin aviso, sesiones que
    hoy son SAFE sin haber tenido nunca checksums que verificar — un
    cambio de política real, no solo de reporting, que le corresponde
    decidir al usuario (ver GAP-052 y `ESTADO_MAESTRO_CONSOLIDACION.md`).
    """
    reasons = []
    invalid_segment_paths: set[str] = set()

    frames_dropped = _get(status, "frames_dropped", 0)
    if frames_dropped > 0:
        reasons.append(ArchivalReason(
            f"frames_dropped={frames_dropped} (pérdida irrecuperable de audio)",
            code="FRAMES_DROPPED"))

    if segment_paths and check_files_exist:
        for p in segment_paths:
            if not os.path.exists(p) or os.path.getsize(p) == 0:
                invalid_segment_paths.add(p)
        missing_segments = [p for p in segment_paths if p in invalid_segment_paths]
        if missing_segments:
            reasons.append(ArchivalReason(
                f"{len(missing_segments)} segmento(s) faltante(s) o vacío(s): "
                f"{missing_segments}", code="SEGMENT_MISSING_OR_EMPTY"))

    checksum_verified = False
    if segment_checksums:
        from lorito_aldhiro.backend.archival.lorito_segment_checksum import (
            verify_segment_checksum,
        )
        checksum_verified = True
        for expected in segment_checksums:
            path = expected.get("path")
            if not path or not os.path.exists(path):
                continue  # ya cubierto arriba por missing_segments
            result = verify_segment_checksum(path, expected)
            if not result["ok"]:
                checksum_verified = False
                invalid_segment_paths.add(path)
                reasons.append(ArchivalReason(
                    f"corrupción de integridad detectada: {result['reason']}",
                    code="CHECKSUM_MISMATCH"))

    recovery_count = _get(status, "recovery_count", 0)
    wd_phase = _get(status, "wd_phase", "OK")
    stream_dead_unrecovered = recovery_count > 0 and wd_phase not in ("OK",)
    if stream_dead_unrecovered:
        reasons.append(ArchivalReason(
            f"recovery agotado sin éxito (wd_phase={wd_phase!r} al finalizar)",
            code="RECOVERY_EXHAUSTED"))

    # ── Campos cuantitativos (§9, GAP-052) — comunes a los 3 desenlaces ──
    segments_expected = len(segment_paths) if segment_paths else 0
    segments_invalid = len(invalid_segment_paths)
    counts = dict(
        frames_expected=_get(status, "frames_received", 0),
        frames_written=_get(status, "frames_written", 0),
        frames_lost=frames_dropped,
        segments_expected=segments_expected,
        segments_invalid=segments_invalid,
        segments_valid=max(0, segments_expected - segments_invalid),
        checksum_verified=checksum_verified,
        dsp_nonfinite_total=dsp_nonfinite_total,
    )

    if reasons:
        return ArchivalClassification(state=ArchivalState.INVALID, reasons=reasons, **counts)

    # ── DEGRADED — completa, pero con anomalías registradas ──────────
    degraded_reasons = []
    xrun_count = _get(status, "xrun_count", 0)
    if xrun_count > 0:
        degraded_reasons.append(ArchivalReason(f"xrun_count={xrun_count}", code="XRUN"))
    rba_overrun_total = _get(status, "rba_overrun_total", 0)
    if rba_overrun_total > 0:
        degraded_reasons.append(ArchivalReason(
            f"rba_overrun_total={rba_overrun_total}", code="RBA_OVERRUN"))
    ced_dropped_frames = _get(status, "ced_dropped_frames", 0)
    if ced_dropped_frames > 0:
        degraded_reasons.append(ArchivalReason(
            f"ced_dropped_frames={ced_dropped_frames}", code="CED_DROPPED_FRAMES"))
    if recovery_count > 0:
        degraded_reasons.append(ArchivalReason(
            f"recovery_count={recovery_count} (recuperado con éxito)",
            code="RECOVERY_SUCCEEDED"))
    starvation_events = _get(status, "starvation_events", 0)
    if starvation_events > 0:
        degraded_reasons.append(ArchivalReason(
            f"starvation_events={starvation_events}", code="STARVATION"))
    if dsp_nonfinite_total > 0:
        degraded_reasons.append(ArchivalReason(
            f"dsp_nonfinite_total={dsp_nonfinite_total} (NaN/Inf saneado en la "
            f"cadena DSP — política confirmada por el usuario en GAP-062: "
            f"recuperación silenciosa, pero degrada la clasificación archival)",
            code="DSP_NONFINITE_SANITIZED"))

    if degraded_reasons:
        return ArchivalClassification(
            state=ArchivalState.DEGRADED, reasons=degraded_reasons, **counts)

    return ArchivalClassification(state=ArchivalState.ARCHIVAL_SAFE, reasons=[], **counts)
