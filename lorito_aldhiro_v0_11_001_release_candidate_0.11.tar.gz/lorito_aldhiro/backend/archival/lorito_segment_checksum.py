from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Checksums SHA-256/CRC32 reales por segmento para detectar corrupción entre captura y verificación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_segment_checksum.py — GAP-035, conexión real de integridad de
segmento (Fase 7, continuación de GAP-032).

GAP-032 encontró que `_IntegrityMonitor` (`lorito_ring_buffers.py`,
CRC32/SHA256 incremental por bloque) nunca se conectaba al
`DiskWriterV2` real — `integrity_crc32_errors` estaba estructuralmente
condenado a valer siempre 0.

Este módulo NO reutiliza `_IntegrityMonitor` tal cual, por una razón
concreta encontrada al diseñar la conexión: `_IntegrityMonitor.update()`
está pensado para hashear los bytes ANTES de que `sf.SoundFile.write()`
los convierta internamente a PCM — pero esa conversión ocurre dentro de
`soundfile`/libsndfile, fuera de lo que Python puede observar
directamente, y este sandbox no tiene `soundfile` instalado para
verificar si su redondeo float32↔PCM24 es bit-exacto (GAP-026 encontró
que la propia implementación streaming de este proyecto SÍ tenía un
bug de este tipo — asumir que `soundfile` no lo tiene sería repetir el
mismo error de razonamiento). Hashear "lo que se pensaba escribir" en
vez de "lo que realmente quedó en disco" arriesga falsos positivos de
corrupción permanentes (cada segmento marcado como corrupto aunque
nunca lo esté), lo cual sería peor que el estado actual (siempre 0).

Diseño de este módulo: el hash se calcula RELEYENDO el segmento YA
ESCRITO Y CERRADO desde disco (bytes PCM reales, sin ambigüedad de
conversión) — inmediatamente después de cerrarlo (línea base) y, más
tarde, en cualquier punto donde se quiera verificar que no hubo
corrupción entre medio (bit rot, fallo de hardware de almacenamiento).
No toca el path RT de escritura en absoluto — se ejecuta en el mismo
hilo de `DiskWriterV2` pero DESPUÉS de que los datos ya están a salvo
en disco, nunca en el callback de audio ni en el hot path de escritura.
"""

import hashlib
import wave
import zlib


def compute_segment_checksum(path: str) -> dict:
    """Lee el segmento WAV completo (bytes PCM crudos, vía `wave` de
    la librería estándar) y calcula SHA-256 + CRC32 sobre su
    contenido real en disco. Memoria O(chunk), no materializa el
    archivo completo de una sola vez."""
    sha256_ctx = hashlib.sha256()
    crc32_running = 0
    chunk_frames = 65536
    with wave.open(path, "rb") as wf:
        n_frames = wf.getnframes()
        channels = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        remaining = n_frames
        while remaining > 0:
            take = min(chunk_frames, remaining)
            raw = wf.readframes(take)
            sha256_ctx.update(raw)
            crc32_running = zlib.crc32(raw, crc32_running) & 0xFFFFFFFF
            remaining -= take
    return {
        "path": path,
        "sha256": sha256_ctx.hexdigest(),
        "crc32": f"{crc32_running:08x}",
        "frames": n_frames,
        "channels": channels,
        "sample_width": sampwidth,
    }


def verify_segment_checksum(path: str, expected: dict) -> dict:
    """Recalcula el checksum de `path` y lo compara contra `expected`
    (el dict que devolvió `compute_segment_checksum` cuando el
    segmento se cerró por primera vez). Devuelve un dict con `ok` y,
    si no coincide, `reason` explicando qué campo difiere."""
    try:
        actual = compute_segment_checksum(path)
    except Exception as e:
        return {"ok": False, "reason": f"no se pudo releer '{path}': {e}"}

    if actual["frames"] != expected.get("frames"):
        return {"ok": False, "reason": (
            f"'{path}': frames cambiaron ({expected.get('frames')} → "
            f"{actual['frames']}) — el archivo fue truncado o alterado")}
    if actual["sha256"] != expected.get("sha256"):
        return {"ok": False, "reason": (
            f"'{path}': SHA-256 no coincide — corrupción real detectada "
            f"(esperado {expected.get('sha256', '')[:16]}..., "
            f"actual {actual['sha256'][:16]}...)")}
    if actual["crc32"] != expected.get("crc32"):
        return {"ok": False, "reason": (
            f"'{path}': CRC32 no coincide (esperado "
            f"{expected.get('crc32')}, actual {actual['crc32']})")}
    return {"ok": True, "reason": ""}
