from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de captura de audio en tiempo real — callback, ring buffer, escritura a disco.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import threading
import time
import queue
import logging
import errno
from collections import deque
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_constants import CE_CED_BATCH_FRAMES, CE_CED_CAPACITY, CE_CHANNELS, CE_DISK_FLUSH_SETTLE_MAX_S, CE_DISK_FSYNC_EVERY, CE_DISK_WRITE_RETRY_MAX, CE_DISK_WRITE_RETRY_SLEEP, CE_DRAIN_BATCH_MAX, CE_DRAIN_BATCH_MIN, CE_JITTER_EWMA_ALPHA, CE_JITTER_HIST_SIZE, CE_PREROLL_SECS_DEFAULT, CE_PREROLL_SECS_MAX, CE_RBA_FRAMES_MAX, CE_RBA_SLOTS, CE_RBA_WATERMARK_CRIT, CE_RBA_WATERMARK_HIGH, CE_RBA_WATERMARK_LOW, CE_RBA_WATERMARK_MID, CE_RECOVERY_BACKOFF_BASE, CE_RECOVERY_BACKOFF_CAP, CE_RECOVERY_COOLDOWN, CE_RECOVERY_MAX_ATTEMPTS, CE_SAMPLE_RATE_DEFAULT, CE_WD_ORANGE_SECS, CE_WD_RED_SECS, CE_WD_TICK_SECS, CE_WD_YELLOW_SECS, CE_WM_HYSTERESIS, _ce_log
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _LIBC, _set_rt_priority
from lorito_aldhiro.backend.core.lorito_timing import CaptureClock, _monotonic_raw_ns
from lorito_aldhiro.backend.archival.lorito_segment_checksum import compute_segment_checksum
# GAP-052 (§8/§9, FASE 2 de la Orden de Saneamiento, Integración y
# Consolidación): aliasado para no chocar de nombre con el método
# `CaptureEngineV2.classify_session()` definido más abajo.
from lorito_aldhiro.backend.archival.lorito_archival_state import (
    classify_session as _classify_archival_session,
)



# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 3: SLOT ATÓMICO DE INTERCAMBIO (Nivel 0)
#  Transferencia zero-lock entre callback RT y drain loop.
#  Inspirado en el buffer de 1 slot de los grabadores CD-R profesionales:
#  el mecanismo más simple posible que garantiza que el callback NUNCA espera.
# ══════════════════════════════════════════════════════════════════════════════

class _AtomicSlot:
    """
    Slot de intercambio de un solo elemento entre productor RT y consumidor.

    GARANTÍA:
    · El productor (callback RT) NUNCA bloquea. Siempre escribe.
    · Si el consumidor (drain) es lento, el slot anterior se sobrescribe.
    · La sobrescritura es el comportamiento correcto: el drain debe
      procesar los datos más recientes disponibles.
    · Sin Lock en el path de escritura del productor (usa GIL de Python
      para atomicidad de asignación de referencia de objeto).

    NOTA SOBRE GIL:
    En CPython, la asignación de una referencia de objeto es atómica
    bajo el GIL. El drain llama _try_get() que lee la referencia y la
    resetea a None. El callback llama put() que asigna una nueva referencia.
    Dado que GIL garantiza atomicidad de asignaciones escalares, no se
    necesita Lock en el hot path. El uso de threading.Event solo es para
    la señalización de disponibilidad, no para la protección de datos.
    """

    __slots__ = ("_slot", "_event", "_overflow_count")

    def __init__(self):
        self._slot           = None        # np.ndarray o None
        self._event          = threading.Event()
        self._overflow_count = 0           # bloques sobrescritos (contador acumulativo)

    def put(self, block: np.ndarray):
        """Escribe bloque. Sobrescribe el anterior si no fue consumido."""
        if self._slot is not None:
            self._overflow_count += 1
        self._slot = block
        self._event.set()

    def get(self, timeout: float = 0.001) -> Optional[np.ndarray]:
        """Lee bloque. Retorna None si no hay datos en timeout."""
        if self._slot is None:
            self._event.wait(timeout=timeout)
        blk        = self._slot
        self._slot = None
        self._event.clear()
        return blk

    @property
    def overflow_count(self) -> int:
        return self._overflow_count


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 4: RING BUFFER DE ABSORCIÓN — RBA (Nivel 1)
#  Sistema antiskip tipo CD portátil.
#
#  FILOSOFÍA ANTISKIP:
#  Los reproductores CD portátiles (Sony G-Protection, ATRAC Anti-Skip,
#  Panasonic ESP+) usan un buffer circular RAM de 3-40 segundos que absorbe
#  los microcortes del mecanismo óptico durante movimiento o vibración.
#  La lectura del disco llena el buffer con anticipación; la reproducción
#  consume del buffer. El salto físico del disco no llega al DAC mientras
#  el buffer no se agote.
#
#  En CRAC, el "disco" es el scheduler del OS bajo presión. El "buffer
#  antiskip" es el RBA. El callback RT llena el RBA; el drain + DiskWriter
#  consumen del RBA. Un burst de preemption del scheduler de 2-3 segundos
#  no llega al DiskWriter mientras el RBA tenga datos.
#
#  WATERMARK DINÁMICO CON HISTÉRESIS:
#  El drain adapta su velocidad según el nivel del RBA:
#  · Nivel bajo (<10%)  → drenar agresivamente (batch máximo, sleep mínimo)
#  · Nivel medio (10-60%) → drenar normalmente
#  · Nivel alto (60-85%) → drenar más despacio para no saturar la cola de disco
#  · Nivel crítico (>85%) → drenar al máximo, alerta al watchdog
#  Histéresis de ±5% para evitar oscilación en los umbrales.
# ══════════════════════════════════════════════════════════════════════════════

class RingBufferAbsorcion:
    """
    Ring Buffer de Absorción prealocado. Núcleo del sistema antiskip.

    Características:
    · 100% prealocado al inicio: sin allocaciones en el hot path.
    · Escritura (callback→drain) con lock mínimo (Condition, <1µs en uncontended).
    · Lectura por batch: copia a buffer destino prealocado, sin allocaciones.
    · Watermark dinámico con histéresis configurable.
    · resize() defensivo thread-safe (solo expansión, nunca contracción).
    · Métricas de watermark para el drain loop y el watchdog.
    · Modo overwrite_oldest: el callback NUNCA bloquea. Si el buffer está
      lleno, el slot más antiguo se sacrifica (dato perdido con contador).
    """

    def __init__(self, n_slots: int, frames_max: int, channels: int,
                 name: str = "RBA"):
        self._name        = name
        self._n           = n_slots
        self._frames_max  = frames_max
        self._channels    = channels

        # Preallocación total: [slots, frames_max, channels]
        self._buf         = np.zeros((n_slots, frames_max, channels),
                                     dtype=np.float32)
        self._frame_count = np.zeros(n_slots, dtype=np.int32)

        # Índices y estado
        self._write_idx   = 0
        self._read_idx    = 0
        self._count       = 0          # slots con datos válidos

        # Estadísticas (acumulativas por sesión)
        self._overrun_total  = 0       # slots sobrescritos por buffer lleno
        self._underrun_total = 0       # lecturas con buffer vacío

        # Sincronización
        self._cond        = threading.Condition(threading.Lock())

        # Watermark (leído por drain sin lock — atomicidad CPython float)
        self.watermark_pct      = 0.0
        self._wm_hysteresis     = CE_WM_HYSTERESIS
        self._wm_state          = "LOW"  # LOW, MID, HIGH, CRIT

    # ── Escritura (path RT — mínimo locking) ─────────────────────────────────

    def write(self, block: np.ndarray) -> bool:
        """
        Escribe bloque en el próximo slot.
        Modo overwrite_oldest: siempre retorna True. Nunca bloquea.
        Si buffer lleno: sacrifica el slot más antiguo (overrun).
        """
        n = block.shape[0]
        if n > self._frames_max:
            # Truncar silenciosamente — el callback puede enviar blocksize
            # variable en las primeras llamadas
            n     = self._frames_max
            block = block[:n]

        with self._cond:
            if self._count >= self._n:
                # Overrun: sacrificar slot más antiguo
                self._overrun_total += 1
                self._read_idx = (self._read_idx + 1) % self._n
                self._count   -= 1

            # Copiar al slot actual
            self._buf[self._write_idx, :n] = block
            self._frame_count[self._write_idx] = n
            self._write_idx = (self._write_idx + 1) % self._n
            self._count    += 1

            # Actualizar watermark (lectura sin lock por el drain)
            self.watermark_pct = self._count / self._n

            self._cond.notify_all()

        return True

    # ── Lectura por batch (drain loop) ───────────────────────────────────────

    def read_batch_into(self, dest_list: list, max_items: int) -> int:
        """
        Lee hasta max_items bloques en dest_list (lista de np.arrays
        prealocados). Retorna cantidad de bloques leídos.

        DISEÑO SIN ALLOCACIONES:
        En lugar de generar nuevas arrays (como read_batch() anterior),
        copia al destino proporcionado. El drain proporciona buffers
        prealocados del pool. Cero malloc en el hot path.
        """
        count = 0
        with self._cond:
            while self._count > 0 and count < max_items:
                idx = self._read_idx
                n   = int(self._frame_count[idx])

                if count < len(dest_list):
                    # Copiar a buffer destino prealocado
                    dst = dest_list[count]
                    dst[:n] = self._buf[idx, :n]
                    dest_list[count] = (dst, n)   # (array, frames_valid)
                else:
                    break

                self._read_idx = (self._read_idx + 1) % self._n
                self._count   -= 1
                count         += 1

            # Actualizar watermark
            self.watermark_pct = self._count / self._n

        return count

    def read_batch(self, max_items: int) -> list:
        """
        Versión compatible con la API anterior. Lee bloques como lista
        de copias. Usar read_batch_into() para zero-alloc.
        """
        out = []
        with self._cond:
            while self._count > 0 and len(out) < max_items:
                idx = self._read_idx
                n   = int(self._frame_count[idx])
                out.append(self._buf[idx, :n].copy())
                self._read_idx = (self._read_idx + 1) % self._n
                self._count   -= 1
            self.watermark_pct = self._count / self._n
        return out

    # ── Watermark y estado ────────────────────────────────────────────────────

    def get_watermark_state(self) -> str:
        """
        Retorna estado del watermark con histéresis.
        SAFE, MEDIUM, HIGH, CRITICAL.
        """
        wm = self.watermark_pct
        hy = self._wm_hysteresis
        prev = self._wm_state

        # Transiciones con histéresis
        if prev == "CRITICAL":
            new = "CRITICAL" if wm > CE_RBA_WATERMARK_HIGH - hy else "HIGH"
        elif prev == "HIGH":
            if wm > CE_RBA_WATERMARK_CRIT:
                new = "CRITICAL"
            elif wm < CE_RBA_WATERMARK_MID + hy:
                new = "MEDIUM"
            else:
                new = "HIGH"
        elif prev == "MEDIUM":
            if wm > CE_RBA_WATERMARK_HIGH:
                new = "HIGH"
            elif wm < CE_RBA_WATERMARK_LOW + hy:
                new = "SAFE"
            else:
                new = "MEDIUM"
        else:  # SAFE
            new = "MEDIUM" if wm > CE_RBA_WATERMARK_MID else "SAFE"

        self._wm_state = new
        return new

    # ── Expansión defensiva ───────────────────────────────────────────────────

    def expand(self, extra_slots: int):
        """
        Expande el buffer añadiendo extra_slots slots adicionales.
        Solo permite expansión, nunca contracción. Thread-safe.
        """
        with self._cond:
            if extra_slots <= 0:
                return
            extra_buf = np.zeros((extra_slots, self._frames_max, self._channels),
                                 dtype=np.float32)
            extra_cnt = np.zeros(extra_slots, dtype=np.int32)
            self._buf         = np.concatenate([self._buf,   extra_buf], axis=0)
            self._frame_count = np.concatenate([self._frame_count, extra_cnt])
            self._n          += extra_slots
            _ce_log.info("%s expandido: %d slots totales", self._name, self._n)

    # ── Propiedades y métricas ────────────────────────────────────────────────

    def clear_without_reset_stats(self):
        """
        Limpia slots pendientes SIN resetear estadísticas de sesión.
        Para recovery no destructivo: no descarta el historial de overruns.
        """
        with self._cond:
            self._write_idx    = 0
            self._read_idx     = 0
            self._count        = 0
            self.watermark_pct = 0.0

    @property
    def count(self) -> int:
        return self._count

    @property
    def capacity(self) -> int:
        return self._n

    @property
    def overrun_total(self) -> int:
        return self._overrun_total

    @property
    def underrun_total(self) -> int:
        return self._underrun_total

    @property
    def occupancy_pct(self) -> float:
        return self.watermark_pct * 100.0


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 5: COLA ELÁSTICA DE DISCO — CED (Nivel 2)
#  Cola entre drain loop y DiskWriter.
#  Diseño: el drain NUNCA bloquea por la cola de disco.
#  Si la cola está llena, activa backpressure inteligente en el drain
#  (reduce batch) pero NO descarta datos silenciosamente.
# ══════════════════════════════════════════════════════════════════════════════

class ColaElasticaDisco:
    """
    Cola elástica entre drain loop y DiskWriter.

    Diferencias vs queue.Queue estándar:
    · No usa put(timeout=...) desde el drain (nunca bloquea el drain).
    · Mantiene dos deques internos: uno de "datos normales" y uno de
      "datos de alta prioridad" (ej: pre-roll, último bloque de sesión).
    · put_nowait_or_drop() con política definida: si llena, retorna False
      y el caller decide (drain anota el overrun pero no descarta silenciosamente).
    · Métricas de presión para el backpressure del drain.
    """

    def __init__(self, capacity: int = CE_CED_CAPACITY):
        self._cap         = capacity
        self._q           = deque()        # cola principal (frames, arrays)
        self._frame_count = 0              # frames totales en cola
        self._lock        = threading.Lock()
        self._not_empty   = threading.Condition(self._lock)
        self._dropped     = 0              # frames descartados (NUNCA silencioso)
        self._total_in    = 0              # frames totales recibidos
        self._total_out   = 0             # frames totales consumidos

    def put_nowait(self, block: np.ndarray) -> bool:
        """
        Intenta encolar bloque sin bloquear.
        Retorna True si OK, False si cola llena (caller decide qué hacer).
        NUNCA descarta silenciosamente.
        """
        n = block.shape[0]
        with self._not_empty:
            if self._frame_count + n > self._cap:
                # GAP-031 (Fase 5): `_dropped` estaba declarado como
                # "NUNCA descarta silenciosamente" pero nunca se
                # incrementaba en ningún punto de la clase — el propio
                # contrato de conteo que ColaElasticaDisco promete
                # quedaba roto: `dropped_frames` siempre devolvía 0
                # aunque el caller SÍ estuviera descartando frames
                # (confirmado en `_drain_loop`, que lee `ced.
                # dropped_frames` esperando que refleje la realidad).
                self._dropped += n
                return False
            self._q.append(block)
            self._frame_count += n
            self._total_in    += n
            self._not_empty.notify()
        return True

    def get_batch(self, max_frames: int = CE_CED_BATCH_FRAMES,
                  timeout: float = 0.5) -> Optional[np.ndarray]:
        """
        Lee hasta max_frames de la cola, concatenando bloques.
        Bloquea hasta timeout si la cola está vacía.
        Retorna None si timeout sin datos.
        """
        with self._not_empty:
            if self._frame_count == 0:
                self._not_empty.wait(timeout=timeout)
            if self._frame_count == 0:
                return None

            blocks   = []
            consumed = 0
            while self._q and consumed < max_frames:
                blk = self._q[0]
                n   = blk.shape[0]
                if consumed + n > max_frames:
                    break
                self._q.popleft()
                blocks.append(blk)
                consumed          += n
                self._frame_count -= n
                self._total_out   += n

        if not blocks:
            return None
        if len(blocks) == 1:
            return blocks[0]
        return np.concatenate(blocks, axis=0)

    @property
    def pressure_pct(self) -> float:
        """Presión actual de la cola (0-100%)."""
        return (self._frame_count / max(self._cap, 1)) * 100.0

    @property
    def frame_count(self) -> int:
        return self._frame_count

    @property
    def dropped_frames(self) -> int:
        return self._dropped

    def clear(self):
        with self._not_empty:
            self._q.clear()
            self._frame_count = 0


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 6: POOL DE BUFFERS PREALOCADOS
#  Permite al drain loop operar sin allocaciones dinámicas de numpy.
# ══════════════════════════════════════════════════════════════════════════════

class PreallocPool:
    """
    Pool de arrays numpy prealocados para el drain loop.
    Elimina allocaciones dinámicas en el hot path.

    Uso típico:
        pool = PreallocPool(n=256, frames=4096, channels=2)
        buf  = pool.acquire()
        # ... llenar buf ...
        pool.release(buf)
    """

    def __init__(self, n: int, frames: int, channels: int):
        self._pool = [
            np.zeros((frames, channels), dtype=np.float32)
            for _ in range(n)
        ]
        self._lock = threading.Lock()

    def acquire(self) -> Optional[np.ndarray]:
        """Obtiene buffer del pool. Retorna None si pool vacío."""
        with self._lock:
            if self._pool:
                return self._pool.pop()
        return None

    def release(self, buf: np.ndarray):
        """Devuelve buffer al pool."""
        with self._lock:
            self._pool.append(buf)

    @property
    def available(self) -> int:
        return len(self._pool)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 7: STATUS DEL MOTOR (estructura compartida de telemetría)
# ══════════════════════════════════════════════════════════════════════════════

class CaptureEngineStatus:
    """
    Estructura de telemetría compartida entre todos los componentes.
    Todos los campos son atómicos en CPython (escritura de float/int/bool
    bajo GIL es indivisible). Sin locks en el hot path de lectura.
    """
    __slots__ = (
        # Stream
        "stream_alive", "recording", "paused",
        # Callbacks
        "callback_tick", "last_callback_ns",
        "frames_received", "frames_written", "frames_dropped",
        # Jitter
        "jitter_ewma_ms", "jitter_peak_ms", "jitter_p95_ms", "jitter_p99_ms",
        # Drift
        "drift_ms", "drift_ppm",
        # Buffers
        "rba_watermark_pct", "rba_overrun_total",
        "ced_pressure_pct", "ced_dropped_frames",
        # Disco
        "disk_alive", "disk_bytes_written", "disk_write_ms_last",
        # Watchdog
        "wd_phase", "recovery_count", "recovery_last_t",
        # XRuns
        "xrun_count", "starvation_events",
        # RT
        "estimated_latency_ms",
        # PSI
        "psi_cpu_pct", "psi_io_pct", "psi_mem_pct",
        # ── Campos heredados de BackendStatus (v0.22.00: _status redirigido al motor) ──
        "queue_size", "dsp_load", "frames_exported", "disk_write_secs",
        "backpressure_state",
        "ram_mb_approx", "ram_state",
        "callback_jitter_ms", "disk_write_ms_max", "disk_mbps",
        "drift_warn_count", "expected_frames",
        "clip_count_l", "clip_count_r",
        "archival_safe_mode", "last_callback_t",
        "callback_latency_sum", "callback_latency_count", "callback_latency_avg_ms",
        "rb_l1_occupancy_pct", "rb_l2_occupancy_pct",
        "segment_count", "current_segment_frames", "integrity_crc32_errors",
        "stress_test_active",
        "_xrlog_last_msg", "_xrlog_last_t", "_xrlog_repeat_count",
        "rb_l1_overrun_count", "rb_l2_expanded_count",
        "drift_ewma_ms", "drift_chronic", "drift_frames_pct",
        "disk_slow_count", "disk_io_protected",
        "normalization_mode", "normalization_gain_db", "normalization_peak_db",
        "normalization_lufs", "normalization_noise_floor_db", "normalization_true_peak_db",
        "normalization_stats",
        "normalization_pre_gain_db", "normalization_post_gain_db",
        "normalization_mid_rms", "normalization_side_rms", "normalization_stereo_balance",
        "normalization_crest_factor_db", "normalization_dynamic_range",
        "normalization_histogram_density", "normalization_silence_ratio",
        "normalization_auto_mode",
        "auto_normalization_decision", "auto_normalization_reason",
        "normalization_rms_final_db", "normalization_percentile_5",
        "normalization_percentile_95", "normalization_true_peak_final_db",
        "normalization_report_path",
        "_lock",
    )

    def __init__(self):
        self.stream_alive        = False
        self.recording           = False
        self.paused              = False
        self.callback_tick       = 0
        self.last_callback_ns    = 0
        self.frames_received     = 0
        self.frames_written      = 0
        self.frames_dropped      = 0
        self.jitter_ewma_ms      = 0.0
        self.jitter_peak_ms      = 0.0
        self.jitter_p95_ms       = 0.0
        self.jitter_p99_ms       = 0.0
        self.drift_ms            = 0.0
        self.drift_ppm           = 0.0
        self.rba_watermark_pct   = 0.0
        self.rba_overrun_total   = 0
        self.ced_pressure_pct    = 0.0
        self.ced_dropped_frames  = 0
        self.disk_alive          = False
        self.disk_bytes_written  = 0
        self.disk_write_ms_last  = 0.0
        self.wd_phase            = "OK"
        self.recovery_count      = 0
        self.recovery_last_t     = 0.0
        self.xrun_count          = 0
        self.starvation_events   = 0
        self.estimated_latency_ms= 0.0
        self.psi_cpu_pct         = 0.0
        self.psi_io_pct          = 0.0
        self.psi_mem_pct         = 0.0
        # ── Campos heredados de BackendStatus ────────────────────────────────
        self._lock                       = threading.Lock()
        self.queue_size                  = 0
        self.dsp_load                    = 0.0
        self.frames_exported             = 0
        self.disk_write_secs             = 0.0
        self.backpressure_state          = "SAFE"
        self.ram_mb_approx               = 0.0
        self.ram_state                   = "OK"
        self.callback_jitter_ms          = 0.0
        self.disk_write_ms_max           = 0.0
        self.disk_mbps                   = 0.0
        self.drift_warn_count            = 0
        self.expected_frames             = 0
        self.clip_count_l                = 0
        self.clip_count_r                = 0
        self.archival_safe_mode          = False
        self.last_callback_t             = 0.0
        self.callback_latency_sum        = 0.0
        self.callback_latency_count      = 0
        self.callback_latency_avg_ms     = 0.0
        self.rb_l1_occupancy_pct         = 0.0
        self.rb_l2_occupancy_pct         = 0.0
        self.segment_count               = 0
        self.current_segment_frames      = 0
        self.integrity_crc32_errors      = 0
        self.stress_test_active          = False
        self._xrlog_last_msg             = ""
        self._xrlog_last_t               = 0.0
        self._xrlog_repeat_count         = 0
        self.rb_l1_overrun_count         = 0
        self.rb_l2_expanded_count        = 0
        self.drift_ewma_ms               = 0.0
        self.drift_chronic               = False
        self.drift_frames_pct            = 0.0
        self.disk_slow_count             = 0
        self.disk_io_protected           = False
        self.normalization_mode          = ""
        self.normalization_gain_db       = 0.0
        self.normalization_peak_db       = 0.0
        self.normalization_lufs          = float("-inf")
        self.normalization_noise_floor_db= 0.0
        self.normalization_true_peak_db  = 0.0
        self.normalization_stats         = {}
        self.normalization_pre_gain_db   = 0.0
        self.normalization_post_gain_db  = 0.0
        self.normalization_mid_rms       = 0.0
        self.normalization_side_rms      = 0.0
        self.normalization_stereo_balance= 0.0
        self.normalization_crest_factor_db = 0.0
        self.normalization_dynamic_range = 0.0
        self.normalization_histogram_density = 0.0
        self.normalization_silence_ratio = 0.0
        self.normalization_auto_mode     = ""
        self.auto_normalization_decision = ""
        self.auto_normalization_reason   = ""
        self.normalization_rms_final_db  = 0.0
        self.normalization_percentile_5  = 0.0
        self.normalization_percentile_95 = 0.0
        self.normalization_true_peak_final_db = 0.0
        self.normalization_report_path   = ""


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 8: PRE-ROLL BUFFER CIRCULAR
#  Mantiene los últimos N segundos antes de REC. Prealocado.
# ══════════════════════════════════════════════════════════════════════════════

class PreRollBufferV2:
    """
    Buffer circular de pre-roll. Versión hardened con prealocación.

    A diferencia de la versión anterior (deque de bloques variables),
    usa un array continuo prealocado para eliminar fragmentation del heap
    durante sesiones largas.
    """

    def __init__(self, secs: float = CE_PREROLL_SECS_DEFAULT,
                 rate: int = CE_SAMPLE_RATE_DEFAULT,
                 channels: int = CE_CHANNELS):
        self._secs     = min(max(0.0, secs), CE_PREROLL_SECS_MAX)
        self._rate     = rate
        self._channels = channels
        self._lock     = threading.Lock()
        self._active   = False
        self._buf      : Optional[np.ndarray] = None  # [max_frames, channels]
        self._write_pos = 0
        self._count    = 0
        self._max_frames = 0
        self._allocate()

    def _allocate(self):
        """Prealoca el buffer según la configuración actual."""
        max_f = int(self._rate * self._secs)
        if max_f <= 0:
            self._buf       = None
            self._max_frames = 0
            return
        self._buf        = np.zeros((max_f, self._channels), dtype=np.float32)
        self._max_frames = max_f
        self._write_pos  = 0
        self._count      = 0

    def configure(self, secs: float, rate: int):
        with self._lock:
            self._secs = min(max(0.0, secs), CE_PREROLL_SECS_MAX)
            self._rate = rate
            self._allocate()

    def push(self, block: np.ndarray):
        """
        Agrega frames al buffer circular prealocado.
        Sobrescribe los frames más antiguos cuando está lleno (circular).
        Cero allocaciones: copia directa en el array prealocado.
        """
        if self._buf is None or not self._active:
            return
        n = block.shape[0]
        with self._lock:
            if n >= self._max_frames:
                # Bloque más grande que el buffer: copiar solo el final
                self._buf[:] = block[-self._max_frames:]
                self._write_pos = 0
                self._count     = self._max_frames
                return
            space_end = self._max_frames - self._write_pos
            if n <= space_end:
                self._buf[self._write_pos:self._write_pos + n] = block
            else:
                # Wrap around
                self._buf[self._write_pos:] = block[:space_end]
                self._buf[:n - space_end]   = block[space_end:]
            self._write_pos = (self._write_pos + n) % self._max_frames
            self._count     = min(self._count + n, self._max_frames)

    def drain(self) -> Optional[np.ndarray]:
        """
        Drena el buffer y retorna el audio ordenado temporalmente.
        Limpia el buffer tras drenar. Retorna None si vacío.
        """
        with self._lock:
            if self._buf is None or self._count == 0:
                return None
            n = self._count
            if n == self._max_frames:
                # Buffer lleno: el audio empieza en write_pos
                start = self._write_pos
                if start == 0:
                    out = self._buf[:n].copy()
                else:
                    out = np.concatenate([
                        self._buf[start:],
                        self._buf[:start]
                    ], axis=0)
            else:
                # Buffer no lleno: audio de 0 a write_pos
                out = self._buf[:n].copy()
            # Reset
            self._write_pos = 0
            self._count     = 0
            return out

    def clear(self):
        with self._lock:
            self._write_pos = 0
            self._count     = 0

    def set_active(self, active: bool):
        self._active = active

    @property
    def buffered_secs(self) -> float:
        return self._count / max(self._rate, 1)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 9: DISK WRITER HARDENED (Nivel 3)
#  Thread dedicado de escritura. Separado del drain para máximo aislamiento.
# ══════════════════════════════════════════════════════════════════════════════

class DiskWriterV2:
    """
    Thread dedicado de escritura a disco. Hardened para I/O lento y errores.

    MEJORAS sobre DiskWriter v0.20.x:
    · Lee de ColaElasticaDisco por batches de frames (no por bloques individuales).
      Agrupa múltiples bloques en una sola llamada sf.write() → menos syscalls.
    · Detección de disco lleno con backoff exponencial antes de descartar.
    · Segmentación automática opcional.
    · fsync periódico con throttle adaptativo (más fsync bajo presión de I/O lento).
    · Integridad: CRC32 incremental por segmento (sin SHA-256 en path RT).
    · Telemetría de latencia de escritura con EWMA.

    API pública (compatible con DiskWriter v0.20.x):
      start(path_tmp, rate, channels)
      stop()
      flush(timeout)
      get_path() → str
      get_segment_paths() → list
    """

    def __init__(self, ced: ColaElasticaDisco, status: CaptureEngineStatus):
        self._ced          = ced
        self._status       = status
        self._active       = False
        self._thread       : Optional[threading.Thread] = None
        self._path_tmp     = ""
        self._rate         = CE_SAMPLE_RATE_DEFAULT
        self._channels     = CE_CHANNELS
        self._flush_done   = threading.Event()
        self._segment_paths: list = []
        self._segment_max_frames = 0
        # GAP-035 (Fase 7, continuación de GAP-032) — checksums reales
        # por segmento, calculados RELEYENDO el archivo ya cerrado
        # desde disco (nunca desde el buffer float32 previo a la
        # conversión de `soundfile`, ver docstring de
        # `lorito_segment_checksum.py` para por qué).
        self._segment_checksums: list = []

        # Métricas
        self._write_ewma_ms = 0.0
        self._fsync_count   = 0
        self._blocks_since_fsync = 0

    def start(self, path_tmp: str, rate: int, channels: int,
              segment_max_secs: float = 0.0):
        """Inicia el thread de escritura."""
        self.stop()
        self._path_tmp     = path_tmp
        self._rate         = rate
        self._channels     = channels
        self._active       = True
        self._flush_done.clear()
        self._segment_paths.clear()
        self._segment_max_frames = int(segment_max_secs * rate) if segment_max_secs > 0 else 0
        self._write_ewma_ms = 0.0
        self._fsync_count   = 0
        self._blocks_since_fsync = 0

        self._thread = threading.Thread(
            target=self._write_loop,
            daemon=True,
            name="crac-disk"
        )
        self._thread.start()
        self._status.disk_alive = True
        _ce_log.info("DiskWriter v2 iniciado: %s  %dHz  %dch", path_tmp, rate, channels)

    def stop(self):
        self._active = False
        # FIX-STOP-RACE (v0.22.04): capturar la referencia al thread localmente
        # antes de evaluar. Si otro hilo (closeEvent + engine.stop()) llama stop()
        # concurrentemente, _thread puede pasar de no-None a None entre el
        # "if self._thread" y el ".is_alive()", produciendo AttributeError.
        _t = self._thread
        if _t is not None and _t.is_alive():
            _t.join(timeout=20.0)
            if _t.is_alive():
                _ce_log.error("DiskWriter thread no terminó en 20s — bloqueo I/O.")
        self._thread = None
        self._status.disk_alive = False

    def flush(self, timeout: float = 30.0, progress_cb=None):
        """Espera vaciado completo de la cola y fsync final.

        progress_cb(pending, total): callback opcional llamado cada 50 ms
        con el conteo de bloques pendientes y el total inicial.

        GAP-064: `_flush_done` SOLO se marca en el `finally:` de
        `_write_loop()` — es decir, únicamente cuando el hilo de
        escritura TERMINA (`_active=False`, ver `stop()`). Si se llama
        `flush()` mientras el hilo sigue activo (el caso previsto por
        esta API pública: vaciar la cola SIN detener la captura — el
        único llamador real hoy, `tests/test_capture_engine_end_to_
        end.py`, llama `flush_disk()` antes de `_disk_writer.stop()`),
        `_flush_done` nunca se marca durante esta llamada — el `wait()`
        original esperaba el `timeout` COMPLETO (30s por defecto) en
        cada invocación, aunque la cola ya estuviera vacía desde el
        primer instante. Confirmado con medición real: un test que
        solo captura 0.3s de audio tardaba ~36s en total por esta
        única llamada. `_flush_done` sigue siendo útil para el caso en
        que el hilo YA terminó (p. ej. tras un error fatal) — en ese
        caso el `wait()` retorna al instante porque el Event ya está
        marcado. Para el caso común (hilo vivo, cola ya vacía), basta
        un margen breve y acotado — sobra tiempo de sobra frente a la
        latencia real de un solo batch (`CE_CED_BATCH_FRAMES` ≈1.4s de
        audio, tamaño en disco del orden de cientos de KB) incluso con
        reintentos (`CE_DISK_WRITE_RETRY_MAX`×`CE_DISK_WRITE_RETRY_
        SLEEP` ≈30ms) — sin tocar el hot path del hilo de escritura.
        """
        deadline = time.monotonic() + timeout
        total = max(self._ced.frame_count, 1)
        while self._ced.frame_count > 0 and time.monotonic() < deadline:
            if progress_cb is not None:
                try:
                    progress_cb(self._ced.frame_count, total)
                except Exception:
                    pass
            time.sleep(0.05)
        remaining = deadline - time.monotonic()
        if remaining > 0:
            self._flush_done.wait(timeout=min(remaining, CE_DISK_FLUSH_SETTLE_MAX_S))
        if progress_cb is not None:
            try:
                progress_cb(0, total)
            except Exception:
                pass

    def get_path(self) -> str:
        return self._path_tmp

    def get_segment_paths(self) -> list:
        return list(self._segment_paths)

    def get_segment_checksums(self) -> list:
        """GAP-035 — checksums (SHA-256/CRC32) calculados releyendo
        cada segmento YA CERRADO desde disco, en el momento en que se
        cerró. Lista de dicts, uno por segmento, en orden."""
        return list(self._segment_checksums)

    def _write_loop(self):
        """Loop principal de escritura. Thread dedicado."""
        _set_rt_priority(45)  # prioridad RT ligeramente inferior al drain

        sf_file      = None
        seg_idx      = 0
        seg_frames   = 0
        blocks_since_fsync = 0

        def _open_segment(idx: int):
            if idx == 0:
                path = self._path_tmp
            else:
                base = self._path_tmp.replace(".wav", "")
                path = f"{base}_seg{idx:04d}.wav"
            self._segment_paths.append(path)
            try:
                f = sf.SoundFile(
                    path, mode="w",
                    samplerate=self._rate,
                    channels=self._channels,
                    subtype="PCM_24",
                    format="WAV"
                )
                _ce_log.info("Segmento abierto: %s", path)
                return f
            except Exception as e:
                _ce_log.critical("No se pudo abrir archivo de captura: %s — %s", path, e)
                return None

        def _close_segment(f, idx: int):
            if f is None:
                return
            try:
                # fsync final del segmento
                f.flush()
                try:
                    fd = f.buffer.fileno() if hasattr(f, 'buffer') else None
                    if fd:
                        os.fsync(fd)
                except Exception:
                    pass
                f.close()
                _ce_log.info("Segmento cerrado: seg%04d", idx)
                # GAP-035 — checksum real releyendo el segmento ya
                # cerrado desde disco (nunca desde el buffer previo a
                # la conversión de `soundfile`). Se hace DESPUÉS de
                # fsync+close, nunca en el hot path de escritura.
                try:
                    seg_path = self._segment_paths[idx]
                    checksum = compute_segment_checksum(seg_path)
                    self._segment_checksums.append(checksum)
                except Exception as e:
                    _ce_log.error("No se pudo calcular checksum del "
                                  "segmento %d: %s", idx, e)
            except Exception as e:
                _ce_log.error("Error cerrando segmento %d: %s", idx, e)

        def _write_block_retry(f, block: np.ndarray) -> bool:
            """Escribe bloque con reintentos. Retorna True si OK."""
            # FIX-DISK-SATURATION: verificar espacio libre antes del primer intento.
            try:
                st = os.statvfs(self._path_tmp)
                free_bytes = st.f_bavail * st.f_frsize
                # Estimar tamaño del bloque en bytes (PCM_24 = 3 bytes/muestra)
                block_bytes = block.shape[0] * self._channels * 3
                if free_bytes < max(block_bytes * 4, 50 * 1024 * 1024):
                    _ce_log.critical(
                        "DISCO CASI LLENO: %d MB libres — deteniendo escritura para "
                        "evitar saturación.", free_bytes // 1024 // 1024
                    )
                    self._status.frames_dropped += block.shape[0]
                    self._active = False   # señalizar parada limpia
                    return False
            except OSError:
                pass  # si statvfs falla, intentar escribir igual

            for attempt in range(CE_DISK_WRITE_RETRY_MAX):
                try:
                    t0 = time.monotonic()
                    f.write(block)
                    dt_ms = (time.monotonic() - t0) * 1000.0
                    # EWMA de latencia
                    alpha = 0.1
                    self._write_ewma_ms = (alpha * dt_ms
                                           + (1 - alpha) * self._write_ewma_ms)
                    self._status.disk_write_ms_last = dt_ms
                    return True
                except OSError as e:
                    if e.errno == errno.ENOSPC:
                        _ce_log.critical("DISCO LLENO (ENOSPC): %s — deteniendo escritura.", e)
                        self._active = False   # parada limpia; no reintentar
                        break
                    _ce_log.warning("sf.write() error (intento %d/%d): %s",
                                    attempt + 1, CE_DISK_WRITE_RETRY_MAX, e)
                    time.sleep(CE_DISK_WRITE_RETRY_SLEEP)
                except Exception as e:
                    _ce_log.warning("sf.write() excepción (intento %d/%d): %s",
                                    attempt + 1, CE_DISK_WRITE_RETRY_MAX, e)
                    time.sleep(CE_DISK_WRITE_RETRY_SLEEP)
            self._status.frames_dropped += block.shape[0]
            _ce_log.critical("Bloque descartado: %d frames no pudieron escribirse",
                             block.shape[0])
            return False

        try:
            sf_file = _open_segment(0)
            if sf_file is None:
                return

            while self._active or self._ced.frame_count > 0:
                batch = self._ced.get_batch(
                    max_frames=CE_CED_BATCH_FRAMES,
                    timeout=0.5
                )
                if batch is None:
                    continue

                n_frames = batch.shape[0]
                ok = _write_block_retry(sf_file, batch)

                if ok:
                    self._status.frames_written += n_frames
                    seg_frames                  += n_frames
                    blocks_since_fsync          += 1

                # fsync periódico
                if blocks_since_fsync >= CE_DISK_FSYNC_EVERY:
                    try:
                        sf_file.flush()
                    except Exception as e:
                        _ce_log.debug("fsync parcial falló: %s", e)
                    blocks_since_fsync = 0

                # Segmentación automática
                if (self._segment_max_frames > 0
                        and seg_frames >= self._segment_max_frames):
                    _close_segment(sf_file, seg_idx)
                    seg_idx  += 1
                    seg_frames = 0
                    sf_file   = _open_segment(seg_idx)
                    blocks_since_fsync = 0
                    if sf_file is None:
                        break

                # OPT-04: actualizar tamaño sin syscall stat() — usar counter aritmético.
                # PCM_24 = 3 bytes/muestra × channels × frames_written + 44 (cabecera WAV).
                # Evita os.path.getsize() (~47 syscalls/s en hot path del DiskWriter).
                self._status.disk_bytes_written = (
                    self._status.frames_written * self._channels * 3 + 44
                )

        except Exception as exc:
            _ce_log.critical("DiskWriter error fatal: %s", exc, exc_info=True)
        finally:
            _close_segment(sf_file, seg_idx)
            self._status.disk_alive = False
            self._flush_done.set()
            _ce_log.info(
                "DiskWriter finalizado: %d frames escritos, %d descartados",
                self._status.frames_written,
                self._status.frames_dropped
            )



def _mlockall():
    """
    Bloquea todas las páginas del proceso en RAM (evita swap durante capture).
    Usa _LIBC (singleton global).
    """
    if sys.platform != "linux" or _LIBC is None:
        return
    try:
        MCL_CURRENT = 1
        MCL_FUTURE  = 2
        _LIBC.mlockall(MCL_CURRENT | MCL_FUTURE)
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 11: DRAIN LOOP — NÚCLEO DEL MOTOR ANTISKIP
#
#  El drain loop es el corazón del sistema. Opera entre el RBA y la CED.
#  Su velocidad se adapta dinámicamente al watermark del RBA:
#
#  WATERMARK SAFE   (<10%)  → sleep 200µs, batch pequeño
#    El buffer está casi vacío: el callback apenas produce datos.
#    El drain puede dormir más tiempo entre ciclos.
#
#  WATERMARK MEDIUM (10-60%) → sleep 500µs, batch normal
#    Operación normal. El buffer se mantiene en rango óptimo.
#
#  WATERMARK HIGH   (60-85%) → sleep 100µs, batch grande
#    El scheduler está bajo presión. Drenar más agresivamente.
#    Reducir sleep para procesar datos más rápido.
#
#  WATERMARK CRITICAL (>85%) → sleep 50µs, batch máximo
#    Situación de emergencia. El buffer está casi lleno.
#    El drain trabaja al máximo para prevenir overrun.
#    El watchdog ya debería haber alertado.
#
#  PREDICCIÓN DE UNDERRUN:
#  Si la tasa de llegada de datos (frames/s del callback) es mayor que la
#  tasa de consumo de disco (medida por EWMA), el drain aumenta proactivamente
#  su batch antes de que el RBA se llene. Esto es equivalente al sistema
#  de prefetch predictivo de los grabadores DVD.
# ══════════════════════════════════════════════════════════════════════════════

def _drain_loop_fn(
    rba:    RingBufferAbsorcion,
    ced:    ColaElasticaDisco,
    status: CaptureEngineStatus,
    stop_evt: threading.Event,
    visual_buf: Optional[deque],
    visual_lock: Optional[threading.Lock],
    nr_coordinator=None,
):
    """
    Función del drain loop. Ejecutada en thread dedicado de alta prioridad.
    No es un método de clase para reducir overhead de atributo lookup.

    Backpressure adaptativo basado en watermark del RBA:
    · Watermark bajo  → drenar despacio (el disco tiene tiempo)
    · Watermark alto  → drenar rápido (prevenir overrun del callback)
    · Watermark crítico → drenar al máximo, alertar watchdog

    NO BLOQUEA NUNCA por la cola de disco (CED).
    Si CED está llena: reporta overrun y descarta con log CRITICAL.
    El drain NUNCA puede quedar bloqueado: es el guardian del callback RT.

    `nr_coordinator` (§GAP-012): a diferencia del callback de audio RT
    (`_audio_callback`, con reglas absolutas de cero-allocation/cero-I/O),
    este hilo de drenaje NO es el callback RT en sí — ya tolera
    logging, dict lookups y `time.sleep()` cooperativo. Es el punto
    correcto para aplicar DSP con allocaciones (el motor NR de
    `lorito_aldhiro.backend.nr`, que usa numpy libremente) — nunca
    debe llamarse `nr_coordinator.process_chunk()` desde
    `_audio_callback` directamente, eso violaría sus reglas absolutas.
    """
    _set_rt_priority(58)
    _mlockall()

    # Tablas de parámetros por estado de watermark (lookup directo, sin branching)
    WM_PARAMS = {
        "SAFE":     (CE_DRAIN_BATCH_MIN,   5000),   # (batch, sleep_us)
        "MEDIUM":   (8,                    500),
        "HIGH":     (32,                   100),
        "CRITICAL": (CE_DRAIN_BATCH_MAX,   50),
    }

    _log = _ce_log
    prev_wm_state = "SAFE"
    batch_param   = CE_DRAIN_BATCH_MIN
    sleep_us      = 5000

    while not stop_evt.is_set():
        # ── Leer watermark y ajustar parámetros ──────────────────────────────
        wm_state = rba.get_watermark_state()
        if wm_state != prev_wm_state:
            batch_param, sleep_us = WM_PARAMS.get(wm_state, (8, 500))
            prev_wm_state         = wm_state
            _log.debug("Drain: watermark → %s  batch=%d sleep=%dµs",
                       wm_state, batch_param, sleep_us)

        # Actualizar status
        status.rba_watermark_pct = rba.watermark_pct * 100.0
        status.rba_overrun_total = rba.overrun_total
        status.ced_pressure_pct  = ced.pressure_pct

        # ── Leer batch del RBA ────────────────────────────────────────────────
        batch = rba.read_batch(max_items=batch_param)

        if not batch:
            # RBA vacío: sleep adaptativo — OPT-01: rama única directa (if/else tenían código idéntico)
            time.sleep(sleep_us / 1_000_000.0)
            continue

        # ── Procesamiento NR (§GAP-012) — ANTES de visual/CED, para que
        # tanto la forma de onda mostrada como el archivo escrito a disco
        # reflejen el audio ya decodificado. Fuera del hot-path del
        # callback RT (ver docstring) — cualquier excepción del motor NR
        # se registra y esa iteración cae a los bloques sin procesar, en
        # vez de perder la sesión de captura completa por un fallo DSP.
        if nr_coordinator is not None:
            try:
                batch = [nr_coordinator.process_chunk(blk) for blk in batch]
            except Exception as e:
                _log.error("Drain: fallo en NRCoordinator.process_chunk (%s) — "
                          "se continúa con el bloque sin procesar esta iteración", e)

        # ── Actualizar buffer visual (GUI) ────────────────────────────────────
        if visual_buf is not None and visual_lock is not None:
            with visual_lock:
                for blk in batch:
                    visual_buf.append(blk)

        # ── Enviar a CED (nunca bloquea) ──────────────────────────────────────
        for blk in batch:
            ok = ced.put_nowait(blk)
            if not ok:
                # CED llena: esto significa que el DiskWriter está muy rezagado.
                # NUNCA descartar silenciosamente.
                status.frames_dropped += blk.shape[0]
                status.ced_dropped_frames = ced.dropped_frames
                _log.critical(
                    "CED LLENA: %d frames descartados (DiskWriter congestionado). "
                    "RBA=%.0f%%  CED=%.0f%%",
                    blk.shape[0], rba.watermark_pct * 100.0, ced.pressure_pct
                )

        # Sleep proporcional al nivel de actividad
        time.sleep(sleep_us / 1_000_000.0)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 12: WATCHDOG PREDICTIVO
#
#  A diferencia del watchdog anterior (puramente reactivo), el nuevo watchdog
#  tiene capacidad predictiva basada en tendencias de watermark.
#
#  MÁQUINA DE ESTADOS:
#    OK → YELLOW → ORANGE → RED
#    RED desencadena _auto_recover()
#    Cualquier estado puede volver a OK cuando el callback se reactiva.
#
#  PREDICCIÓN:
#  El watchdog analiza la tendencia del watermark del RBA:
#  · Si el watermark lleva N ticks creciendo y ya está en HIGH, emite
#    alerta temprana y expande el RBA defensivamente antes de llegar a CRITICAL.
#  · Si el DiskWriter lleva M ticks sin progresar (frames_written estancado),
#    emite WRITE_STALL y activa modo de throttle del drain.
# ══════════════════════════════════════════════════════════════════════════════

def _watchdog_loop_fn(
    rba:      RingBufferAbsorcion,
    ced:      ColaElasticaDisco,
    status:   CaptureEngineStatus,
    stop_evt: threading.Event,
    on_stream_dead: Callable,   # callback para activar recovery
    on_alert: Optional[Callable] = None,  # callback para GUI
):
    """
    Función del watchdog. Thread no-RT de baja prioridad.
    Tick cada CE_WD_TICK_SECS (250ms).
    """
    _log           = _ce_log
    last_cb_tick   = 0
    last_frames_w  = 0
    # OPT-WM-DEQUE: deque con maxlen elimina la lista + pop(0) O(n) original
    WM_HISTORY_LEN = 8             # 8 ticks × 250ms = 2s de ventana
    wm_history     = deque(maxlen=WM_HISTORY_LEN)
    stall_ticks    = 0
    rba_expanded   = False

    while not stop_evt.is_set():
        time.sleep(CE_WD_TICK_SECS)

        if not status.recording or status.paused:
            last_cb_tick  = status.callback_tick
            last_frames_w = status.frames_written
            stall_ticks   = 0
            wm_history.clear()
            if status.wd_phase != "OK":
                status.wd_phase = "OK"
            continue

        now_ns    = _monotonic_raw_ns()
        now_tick  = status.callback_tick

        # ── Chequeo de callbacks ──────────────────────────────────────────────
        if now_tick == last_cb_tick:
            # No hubo callbacks en este tick
            elapsed_s = (now_ns - status.last_callback_ns) / 1e9

            if elapsed_s > CE_WD_RED_SECS:
                if status.wd_phase != "RED":
                    status.wd_phase    = "RED"
                    status.stream_alive = False
                    _log.error(
                        "Watchdog RED: stream muerto (%.1fs sin callbacks). "
                        "Iniciando recovery.", elapsed_s
                    )
                    if on_alert:
                        on_alert("RED", elapsed_s)
                    on_stream_dead()

            elif elapsed_s > CE_WD_ORANGE_SECS:
                if status.wd_phase not in ("ORANGE", "RED"):
                    status.wd_phase = "ORANGE"
                    _log.warning(
                        "Watchdog ORANGE: %.1fs sin callbacks. "
                        "Expandiendo RBA defensivamente.", elapsed_s
                    )
                    if not rba_expanded:
                        rba.expand(CE_RBA_SLOTS // 4)  # +25% de slots
                        rba_expanded = True
                    if on_alert:
                        on_alert("ORANGE", elapsed_s)

            elif elapsed_s > CE_WD_YELLOW_SECS:
                if status.wd_phase == "OK":
                    status.wd_phase = "YELLOW"
                    _log.warning("Watchdog YELLOW: %.1fs sin callbacks.", elapsed_s)
                    if on_alert:
                        on_alert("YELLOW", elapsed_s)
        else:
            # Hay callbacks nuevos
            last_cb_tick     = now_tick
            status.stream_alive = True
            rba_expanded     = False
            if status.wd_phase != "OK":
                _log.info("Watchdog: stream recuperado (fase: %s → OK)", status.wd_phase)
            status.wd_phase = "OK"

        # ── Tendencia de watermark (predicción) ───────────────────────────────
        wm = rba.watermark_pct
        wm_history.append(wm)
        # OPT-WM-DEQUE: maxlen en deque elimina el pop(0) original

        if len(wm_history) >= 4:
            # Tendencia: diferencia entre promedio reciente y antiguo
            # OPT-WM-DEQUE: convertir a list solo cuando se calcula tendencia (no en cada tick)
            _wm_list = list(wm_history)
            mid      = len(_wm_list) // 2
            avg_old  = sum(_wm_list[:mid]) / mid
            avg_new  = sum(_wm_list[mid:]) / max(len(_wm_list) - mid, 1)
            trend    = avg_new - avg_old
            # Si el watermark crece rápidamente y ya está en HIGH, alerta temprana
            if trend > 0.05 and avg_new > CE_RBA_WATERMARK_MID:
                _log.warning(
                    "Watchdog: RBA en tendencia creciente "
                    "(%.1f%% → %.1f%%, Δ=%.1f%%/2s). Presión de scheduler.",
                    avg_old * 100, avg_new * 100, trend * 100
                )

        # ── Write stall ───────────────────────────────────────────────────────
        fw_now = status.frames_written
        if fw_now == last_frames_w and ced.frame_count > 1024:
            stall_ticks += 1
            if stall_ticks >= 8:  # 8 × 250ms = 2s sin progresar
                _log.error(
                    "Watchdog: WRITE STALL — %d frames en CED sin progresar "
                    "(%d ticks × %.0fms).",
                    ced.frame_count, stall_ticks, CE_WD_TICK_SECS * 1000
                )
                stall_ticks = 0
        else:
            stall_ticks   = 0
            last_frames_w = fw_now

        # ── Jitter ────────────────────────────────────────────────────────────
        if status.jitter_ewma_ms > 30.0 or status.jitter_peak_ms > 80.0:
            _log.warning(
                "Watchdog: jitter severo EWMA=%.1fms peak=%.1fms",
                status.jitter_ewma_ms, status.jitter_peak_ms
            )


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 13: MOTOR PRINCIPAL — CaptureEngineV2
#  Integra todas las capas anteriores en una API limpia y compatible.
# ══════════════════════════════════════════════════════════════════════════════

class CaptureEngineV2:
    """
    Motor de captura fonográfica CRAC v2.0.

    ARQUITECTURA DE CAPAS:
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ CAPA 0: Callback RT (SCHED_FIFO 80)                                      │
    │   sounddevice → _audio_callback → escribe en RBA (lock mínimo)          │
    │   Zero-allocation. Sin I/O. Sin logging. Solo: copiar + contadores.      │
    └──────────────────────────────────────────────────────────────────────────┘
                         │ Ring Buffer de Absorción (RBA)
                         │ Sistema antiskip — absorbe bursts de 8-20s
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ CAPA 1: Drain Loop (SCHED_FIFO 58)                                       │
    │   RBA → NRCoordinator (§GAP-012, si hay uno asignado) → CED + visual    │
    │   Backpressure adaptativo por watermark. Never bloquea.                  │
    └──────────────────────────────────────────────────────────────────────────┘
                         │ Cola Elástica de Disco (CED)
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ CAPA 2: DiskWriter (SCHED_FIFO 45)                                       │
    │   CED → sf.SoundFile                                                     │
    │   Escritura por batches. fsync periódico. Reintentos hardened.           │
    └──────────────────────────────────────────────────────────────────────────┘
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ CAPA 3: Watchdog (no-RT, 250ms tick)                                     │
    │   Monitoreo de todas las capas. Recovery predictivo.                     │
    └──────────────────────────────────────────────────────────────────────────┘

    API PÚBLICA (compatible con AudioCaptureEngine v0.21.x):
      start(rate, blocksize) → bool
      stop()
      pause(state)
      flush_disk()
      get_status() → CaptureEngineStatus
      set_output(path_tmp, rate, channels)  # NUEVO: configurar salida
    """

    # Constantes RT
    _RT_PRIORITY_CALLBACK = 80   # callback sounddevice
    _RT_PRIORITY_DRAIN    = 58
    _RT_PRIORITY_DISK     = 45

    def __init__(self):
        # ── Status compartido ─────────────────────────────────────────────────
        self._status = CaptureEngineStatus()

        # ── Coordinador NR (§GAP-012) ─────────────────────────────────────────
        # Asignado externamente (LoritoAldhiroStudio.__init__) antes de start().
        # None = sin procesamiento NR, drain loop pasa los bloques tal cual.
        self.nr_coordinator = None

        # ── Clock lógico ──────────────────────────────────────────────────────
        self._clock = CaptureClock()

        # ── Ring Buffer de Absorción (antiskip) ───────────────────────────────
        self._rba = RingBufferAbsorcion(
            n_slots   = CE_RBA_SLOTS,
            frames_max= CE_RBA_FRAMES_MAX,
            channels  = CE_CHANNELS,
            name      = "RBA"
        )

        # ── Cola Elástica de Disco ────────────────────────────────────────────
        self._ced = ColaElasticaDisco(capacity=CE_CED_CAPACITY)

        # ── DiskWriter ────────────────────────────────────────────────────────
        self._disk_writer = DiskWriterV2(self._ced, self._status)

        # ── Pre-roll ──────────────────────────────────────────────────────────
        self._preroll = PreRollBufferV2()

        # ── Buffer visual para GUI ────────────────────────────────────────────
        self.buffer      : deque = deque(maxlen=4500)
        self.lock        = threading.Lock()

        # ── Buffers prealocados del callback (zero-allocation RT) ─────────────
        self._cb_prealloc = np.zeros(
            (CE_RBA_FRAMES_MAX, CE_CHANNELS), dtype=np.float32
        )
        self._monitor_block        = np.zeros(
            (CE_RBA_FRAMES_MAX, CE_CHANNELS), dtype=np.float32
        )
        self._monitor_block_frames = 0
        # Motor de monitorización en tiempo real — asignado desde fuera
        # (`lorito_main_window.py`) tras construir el `CaptureEngine`;
        # `None` por defecto = sin consumidor, `_audio_callback` no hace
        # nada extra (mismo criterio que `nr_coordinator`).
        self.monitor_engine = None

        # ── Histograma de jitter (prealocado) ─────────────────────────────────
        self._jitter_hist     = [0.0] * CE_JITTER_HIST_SIZE
        self._jitter_hist_pos = 0

        # ── Estado ────────────────────────────────────────────────────────────
        self.recording = False
        self.paused    = False
        self.rate      = CE_SAMPLE_RATE_DEFAULT
        self.blocksize = 2048
        self._stream   : Optional[sd.InputStream] = None

        # ── Threads ───────────────────────────────────────────────────────────
        self._drain_t    : Optional[threading.Thread] = None
        self._watchdog_t : Optional[threading.Thread] = None
        self._stop_evt   = threading.Event()

        # ── Recovery ─────────────────────────────────────────────────────────
        self._recovery_lock = threading.Lock()

    # ── API pública ───────────────────────────────────────────────────────────

    def start(self, rate: int, blocksize: int) -> bool:
        """
        Inicia captura. Retorna True si el stream se abrió correctamente.
        Compatible con AudioCaptureEngine.start().
        """
        self.rate      = rate
        self.blocksize = blocksize

        # Reset sin destruir buffers (no-destructivo)
        self._rba.clear_without_reset_stats()
        self._ced.clear()
        self._stop_evt.clear()
        self._clock.reset(sample_rate=rate)
        self._preroll.configure(secs=CE_PREROLL_SECS_DEFAULT, rate=rate)
        self._preroll.set_active(False)  # activo solo cuando no graba

        with self.lock:
            self.recording  = True
            self.paused     = False

        self._status.recording       = True
        self._status.paused          = False
        self._status.frames_received = 0
        self._status.frames_written  = 0
        self._status.frames_dropped  = 0
        self._status.xrun_count      = 0
        self._status.jitter_ewma_ms  = 0.0
        self._status.jitter_peak_ms  = 0.0

        # Abrir stream de audio
        if not self._open_stream():
            self.recording          = False
            self._status.recording  = False
            return False

        self._status.stream_alive = True
        self._status.last_callback_ns = _monotonic_raw_ns()

        # Iniciar drain loop
        self._drain_t = threading.Thread(
            target=_drain_loop_fn,
            args=(
                self._rba, self._ced, self._status, self._stop_evt,
                self.buffer, self.lock, self.nr_coordinator,
            ),
            daemon=True,
            name="crac-drain"
        )
        self._drain_t.start()

        # Iniciar watchdog
        self._watchdog_t = threading.Thread(
            target=_watchdog_loop_fn,
            args=(
                self._rba, self._ced, self._status, self._stop_evt,
                self._on_stream_dead,
                self._on_watchdog_alert,
            ),
            daemon=True,
            name="crac-watchdog"
        )
        self._watchdog_t.start()

        _ce_log.info(
            "CaptureEngineV2 iniciado: %dHz  bs=%d  RBA=%d slots  CED=%d frames",
            rate, blocksize, CE_RBA_SLOTS, CE_CED_CAPACITY
        )
        return True

    def stop(self):
        """Detiene la captura de forma segura y no-destructiva."""
        with self.lock:
            self.recording = False
            self.paused    = False
        self._status.recording  = False
        self._status.paused     = False
        self._stop_evt.set()
        self._close_stream()
        self._status.stream_alive = False

        # Esperar que el drain vacíe el RBA antes de detener disco
        _deadline = time.monotonic() + 5.0
        while self._rba.count > 0 and time.monotonic() < _deadline:
            time.sleep(0.05)

        # GAP-038 — mecanismo de protección replicado de CRAC
        # (`wait_for_pending_stream_close`, ver GAP_REFERENCIA_
        # CIERRE_FATAL_DEFERRED_CLOSE del tarball CRAC v0.37.416):
        # esperar, con timeout acotado, a que los hilos de fondo
        # (`_drain_t`/`_watchdog_t`) realmente terminen antes de que
        # `stop()` devuelva el control. CRAC sufrió un SIGSEGV real
        # (coredump "crac-audio-read") por dejar un hilo daemon vivo,
        # bloqueado en una llamada nativa, en el instante en que el
        # intérprete de Python empieza a finalizar tras cerrar la
        # ventana — la arquitectura de Lorito es distinta (sin hilo
        # de lectura bloqueante propio, el callback lo entrega
        # PortAudio), pero los hilos `_drain_t`/`_watchdog_t` SÍ son
        # daemon threads que de otro modo nunca se esperan
        # explícitamente — el mismo tipo de riesgo, con una causa
        # nativa distinta. Nunca bloquea indefinidamente: cada join
        # tiene su propio timeout acotado.
        self.wait_for_background_threads(timeout=5.0)

        _ce_log.info("CaptureEngineV2 detenido.")

    def wait_for_background_threads(self, timeout: float = 5.0) -> bool:
        """Espera a que `_drain_t` y `_watchdog_t` terminen realmente
        (cada uno con hasta `timeout` segundos, nunca indefinidamente).
        Devuelve True si ambos terminaron, False si alguno seguía vivo
        al agotar el timeout (se registra como advertencia, no como
        error fatal — el hilo es daemon, así que no impide que el
        proceso termine, pero si sigue vivo durante la finalización
        del intérprete es exactamente el tipo de condición de carrera
        que esta protección busca evitar)."""
        ok = True
        for _t in (self._drain_t, self._watchdog_t):
            if _t is not None and _t.is_alive():
                _t.join(timeout=timeout)
                if _t.is_alive():
                    _ce_log.warning(
                        "wait_for_background_threads: el hilo %s sigue vivo "
                        "tras %.1fs — posible condición de carrera al cerrar.",
                        _t.name, timeout)
                    ok = False
        return ok

    def pause(self, state: bool):
        """Pausa/reanuda la captura."""
        with self.lock:
            self.paused = state
        self._status.paused = state
        self._preroll.set_active(not state and not self.recording)

    def flush_disk(self):
        """Espera vaciado completo del DiskWriter."""
        self._disk_writer.flush(timeout=30.0)

    def set_output(self, path_tmp: str, rate: int, channels: int,
                   segment_max_secs: float = 0.0):
        """
        Configura la salida de disco. Llamar antes de start().
        Compatible con el flujo de configuración del monolito CRAC.
        """
        self._disk_writer.start(path_tmp, rate, channels, segment_max_secs)

    def get_status(self) -> CaptureEngineStatus:
        return self._status

    def get_path(self) -> str:
        return self._disk_writer.get_path()

    def get_segment_paths(self) -> list:
        return self._disk_writer.get_segment_paths()

    def classify_session(self):
        """§8/§9 (FASE 2, GAP-052, Orden de Saneamiento, Integración y
        Consolidación) — clasifica la sesión ya finalizada como
        ARCHIVAL_SAFE/DEGRADED/INVALID.

        Llamar DESPUÉS de `stop()` + `flush_disk()` +
        `self._disk_writer.stop()` — en ese punto los segmentos ya
        están cerrados en disco y `DiskWriterV2` ya calculó su
        checksum real de cada uno (ver `_close_segment()`). Llamarlo
        antes daría una clasificación prematura sobre segmentos aún
        abiertos.

        Delega en `backend.archival.classify_session()` con la
        telemetría, los segmentos y los checksums REALES de este
        motor — nunca placeholder ni sintético. Devuelve una
        `ArchivalClassification` (ver `backend/archival/
        lorito_archival_state.py` para el contrato completo, §9).

        GAP-062 (§16, FASE 6): si hay un `nr_coordinator` asignado a
        este motor (§GAP-012), su `nonfinite_counts` real (muestras
        NaN/Inf saneadas durante la sesión, por etapa) se suma y se
        pasa a `classify_session()` — política confirmada por el
        usuario vía cuestionario: cualquier saneamiento degrada la
        clasificación de ARCHIVAL_SAFE a DEGRADED (nunca aborta la
        captura en sí). Sin `nr_coordinator` asignado, el total es 0 y
        el comportamiento es idéntico al de antes de este GAP.
        """
        dsp_nonfinite_total = 0
        if self.nr_coordinator is not None:
            try:
                dsp_nonfinite_total = sum(self.nr_coordinator.nonfinite_counts.values())
            except Exception as e:
                _ce_log.error("classify_session(): no se pudo leer nonfinite_counts "
                              "de nr_coordinator: %s", e)
        return _classify_archival_session(
            self._status,
            segment_paths=self.get_segment_paths(),
            segment_checksums=self._disk_writer.get_segment_checksums(),
            dsp_nonfinite_total=dsp_nonfinite_total,
        )

    # ── Callback RT ───────────────────────────────────────────────────────────

    def _audio_callback(self, indata, frames, t, status):
        """
        Callback RT. REGLAS ABSOLUTAS:
        · Sin print, logging, I/O, allocaciones dinámicas.
        · Sin locks que puedan bloquear.
        · Solo: copiar → RBA, actualizar contadores atómicos.

        La copia usa el buffer prealocado _cb_prealloc para evitar
        que numpy cree un nuevo array en cada callback.
        """
        _s = self._status
        if _s is None:
            return

        # ── Registrar XRuns del driver ────────────────────────────────────────
        if status:
            _s.xrun_count += 1
            if status.input_overflow:
                _s.xrun_count += 1  # doble peso

        now_ns = _monotonic_raw_ns()

        # ── Telemetría de jitter (zero-alloc) ────────────────────────────────
        last_ns = _s.last_callback_ns
        if last_ns > 0:
            expected_gap_ns = int(frames / max(self.rate, 1) * 1e9)
            actual_gap_ns   = now_ns - last_ns
            jitter_ms       = abs(actual_gap_ns - expected_gap_ns) / 1_000_000.0

            # EWMA jitter
            alpha = CE_JITTER_EWMA_ALPHA
            _s.jitter_ewma_ms = alpha * jitter_ms + (1 - alpha) * _s.jitter_ewma_ms

            # Peak con decaimiento suave (FIX-JITTER-DECAY)
            if jitter_ms > _s.jitter_peak_ms:
                _s.jitter_peak_ms = jitter_ms
            elif jitter_ms < _s.jitter_peak_ms * 0.6:
                _s.jitter_peak_ms = (_s.jitter_peak_ms * 0.90
                                     + _s.jitter_ewma_ms * 0.10)

            # Histograma circular para p95/p99 (watchdog lo procesa)
            hp = self._jitter_hist_pos
            self._jitter_hist[hp]  = jitter_ms
            self._jitter_hist_pos  = (hp + 1) % CE_JITTER_HIST_SIZE

            # Starvation: gap real significativamente mayor que el esperado
            STARVE_THRESH_NS = 5_000_000  # 5ms
            if actual_gap_ns > expected_gap_ns + STARVE_THRESH_NS:
                _s.starvation_events += 1

        _s.last_callback_ns = now_ns
        _s.callback_tick   += 1

        # ── Monitor lateral (siempre activo, incluso en pausa) ────────────────
        n_mon = min(frames, CE_RBA_FRAMES_MAX)
        self._monitor_block[:n_mon]   = indata[:n_mon]
        self._monitor_block_frames    = n_mon
        # Motor de monitorización en tiempo real (§lorito_monitor_engine,
        # pedido explícito del usuario) — antes `_monitor_block` no tenía
        # ningún consumidor real; `push_block` es zero-allocation (solo
        # copia a un ring buffer prealocado), respeta las reglas
        # absolutas de este callback.
        if self.monitor_engine is not None:
            self.monitor_engine.push_block(indata[:n_mon])

        # ── Captura real ──────────────────────────────────────────────────────
        if self.recording and not self.paused:
            n = min(frames, CE_RBA_FRAMES_MAX)
            # Copiar a buffer prealocado (evitar que numpy cree nuevo array)
            self._cb_prealloc[:n] = indata[:n]
            # Escribir en RBA — overwrite_oldest si lleno (callback nunca bloquea)
            self._rba.write(self._cb_prealloc[:n])
            # Actualizar clock lógico
            self._clock.tick_received(n)
            _s.frames_received += n

        elif not self.recording:
            # Pre-roll: buffer circular de los últimos N segundos antes de REC
            self._preroll.push(indata[:min(frames, CE_RBA_FRAMES_MAX)])

    # ── Gestión del stream ────────────────────────────────────────────────────

    def _open_stream(self) -> bool:
        """
        Abre InputStream con latency='high' para buffers internos generosos.
        Reduce XRUNs bajo estrés sin cambiar la prioridad RT del callback.
        """
        try:
            self._stream = sd.InputStream(
                samplerate = self.rate,
                channels   = CE_CHANNELS,
                dtype      = "float32",
                blocksize  = self.blocksize,
                callback   = self._audio_callback,
                latency    = "high",
            )
            self._stream.start()
            self._status.estimated_latency_ms = (self.blocksize / self.rate) * 1000.0
            _ce_log.info(
                "Stream abierto: %dHz  bs=%d  latency=high  est_lat=%.1fms",
                self.rate, self.blocksize,
                self._status.estimated_latency_ms
            )
            return True
        except Exception as exc:
            _ce_log.error("ERROR al abrir stream: %s", exc)
            return False

    def _close_stream(self):
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception as e:
                _ce_log.warning("Error cerrando stream: %s", e)
            finally:
                self._stream = None

    # ── Recovery ─────────────────────────────────────────────────────────────

    def _on_watchdog_alert(self, phase: str, elapsed_s: float):
        """Callback del watchdog para alertas. Llama a bridge si está disponible."""
        # En integración con el monolito CRAC, aquí se emite la señal del bridge
        pass

    def _on_stream_dead(self):
        """Invocado por el watchdog cuando el stream muere. Inicia recovery."""
        with self._recovery_lock:
            self._auto_recover()

    def _auto_recover(self):
        """
        Recovery no-destructivo. Reabre el stream SIN destruir los buffers.

        DIFERENCIA CLAVE con v0.21.x:
        · NO limpia el RBA ni la CED antes de recovery.
        · Los frames que estaban en vuelo durante el stall se preservan.
        · Solo cierra y reabre el stream de sounddevice.
        · Si hay datos en el RBA, el drain los procesa normalmente
          una vez que el stream se restablece.
        · Rotación de blocksize a partir del intento 3.
        """
        _s   = self._status
        now  = time.monotonic()

        # Cooldown
        if _s.recovery_last_t > 0:
            elapsed = now - _s.recovery_last_t
            if elapsed < CE_RECOVERY_COOLDOWN:
                _ce_log.warning(
                    "Recovery: cooldown activo (%.1fs restantes).",
                    CE_RECOVERY_COOLDOWN - elapsed
                )
                return

        _s.recovery_count += 1
        _ce_log.warning("Recovery #%d iniciado.", _s.recovery_count)

        self._close_stream()
        # NO limpiamos RBA ni CED — recovery no-destructivo

        bs_candidates = [self.blocksize, 512, 1024, 2048, 4096]
        bs_candidates = list(dict.fromkeys(bs_candidates))  # dedup manteniendo orden

        for attempt in range(CE_RECOVERY_MAX_ATTEMPTS):
            raw_wait = CE_RECOVERY_BACKOFF_BASE * (2 ** min(attempt, 7))
            wait     = min(raw_wait, CE_RECOVERY_BACKOFF_CAP)
            _ce_log.info(
                "Recovery: intento %d/%d — esperando %.2fs.",
                attempt + 1, CE_RECOVERY_MAX_ATTEMPTS, wait
            )
            time.sleep(wait)

            # Rotar blocksize a partir del intento 3
            if attempt >= 3:
                bs_idx       = (attempt - 3) % len(bs_candidates)
                self.blocksize = bs_candidates[bs_idx]

            if self._open_stream():
                _s.stream_alive  = True
                _s.recovery_last_t = time.monotonic()
                _s.wd_phase      = "OK"
                _ce_log.info(
                    "Stream RECUPERADO en intento %d (blocksize=%d).",
                    attempt + 1, self.blocksize
                )
                return

            _ce_log.warning("Recovery: intento %d/%d falló.",
                           attempt + 1, CE_RECOVERY_MAX_ATTEMPTS)

        _s.recovery_last_t = time.monotonic()
        _ce_log.critical(
            "FALLO CRÍTICO: stream no pudo recuperarse tras %d intentos. "
            "Reinicia la aplicación o verifica el dispositivo de audio.",
            CE_RECOVERY_MAX_ATTEMPTS
        )



# ── Alias de compatibilidad con el monolito ──────────────────────────────────
# CaptureEngineV2 es el sucesor directo de AudioCaptureEngine.
AudioCaptureEngine = CaptureEngineV2
