from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Error de integridad DSP (NaN/Inf) — creado por contrato (§16) pero deliberadamente sin conectar a la cadena real esta sesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_errors_dsp.py — §16, FASE 1 de la Orden Maestra de Saneamiento,
Integración y Consolidación de Lorito Aldhiro.

`DSPIntegrityError` se crea aquí por contrato explícito de §16 ("Ante
NaN/Inf: DSPIntegrityError y recuperación controlada del estado"),
pero DELIBERADAMENTE no se conecta en esta sesión a ningún sitio real
de la cadena DSP. Motivo, para que quien continúe esta Orden no lo
reintente sin verlo:

`NRCoordinator`/`lorito_dsp_finite_guard.py` (Fase 10, GAP-025) ya
implementan un contrato finite-in/finite-out — pero con una política
de RECUPERACIÓN SILENCIOSA: los valores no finitos se sanean in-place
(se reemplazan) y solo se cuentan (`nonfinite_counts`), nunca se
lanza una excepción. Esa política tiene sentido real en una ruta de
audio en vivo: abortar toda la captura por una sola muestra NaN en un
plugin DSP sería mucho peor que reemplazarla y seguir. Cambiar esa
política a "lanzar `DSPIntegrityError` y abortar" — lo que un lector
superficial de §16 podría interpretar — sería un cambio de
COMPORTAMIENTO real en una ruta que este sandbox no puede verificar
con audio real (sin `sounddevice`/hardware), exactamente el tipo de
cambio que la convención del proyecto pide no hacer sin poder
ejecutarlo de verdad.

La propia Orden lo anticipa (§16: "Decidir formalmente una única
política") — es una decisión de política pendiente de confirmación
explícita del usuario, no un defecto a corregir unilateralmente. Esta
clase queda lista (y con test unitario propio) para cuando esa
decisión se tome.
"""

from lorito_aldhiro.backend.errors.lorito_errors_base import IntegrityError


class DSPIntegrityError(IntegrityError):
    """NaN/Inf detectado en una etapa DSP bajo el contrato
    finite-in/finite-out (§16). Ver el docstring del módulo — no
    conectada todavía a ningún sitio real de `raise`.

    Atributo adicional sobre `IntegrityError`:
        stage: nombre de la etapa DSP donde se detectó el valor no
            finito (p. ej. ``"input"`` o el nombre de la etapa de
            `NRCoordinator._nonfinite_counts`), o ``None``.
    """

    def __init__(self, message: str, *, stage: str | None = None,
                 cause: Exception | None = None):
        super().__init__(message, cause=cause)
        self.stage = stage
