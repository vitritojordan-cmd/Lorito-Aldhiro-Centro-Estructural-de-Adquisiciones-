from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Familia de errores de exportación con campos estructurados obligatorios (segment_id, frame_start, frame_count, path, cause, recoverable).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_errors_export.py — §11, FASE 1 de la Orden Maestra de
Saneamiento, Integración y Consolidación de Lorito Aldhiro.

Antes de esta fase, `FormatMismatchError`/`ExportAbortError`
(`lorito_export_blocks.py`) y `SegmentReadError`
(`lorito_segment_provider.py`) vivían como `RuntimeError` sueltos, con
toda su información (segmento afectado, posición) codificada
ÚNICAMENTE en el texto del mensaje — suficiente para un humano leyendo
un log, insuficiente para código que quisiera reaccionar
programáticamente (p. ej. "¿qué segmento falló?" sin parsear un
string). Esta sesión (GAP-051) las consolida aquí, en el mismo módulo,
con los 6 campos que exige §11, preservando el texto exacto de cada
mensaje existente (los tests que hacen `assertIn(path, str(exc))`
siguen pasando sin cambios).
"""

from lorito_aldhiro.backend.errors.lorito_errors_base import LoritoError


class ExportError(LoritoError):
    """Raíz de la familia de errores de exportación (§11).

    Contrato obligatorio: toda excepción de esta familia conserva
    ``segment_id``, ``frame_start``, ``frame_count``, ``path``,
    ``cause`` y ``recoverable``. Ninguno es obligatorio de proveer al
    construir la excepción (todos ``None``/``False`` por defecto),
    pero el ATRIBUTO siempre existe — el llamador puede leer
    ``err.segment_id`` directamente, sin ``getattr(err, ..., None)``
    defensivo.
    """

    def __init__(self, message: str, *, segment_id=None,
                 frame_start: int | None = None,
                 frame_count: int | None = None,
                 path: str | None = None,
                 cause: Exception | None = None,
                 recoverable: bool = False):
        super().__init__(message, cause=cause, recoverable=recoverable)
        self.segment_id = segment_id
        self.frame_start = frame_start
        self.frame_count = frame_count
        self.path = path


class FormatMismatchError(ExportError):
    """§21 — EXPORT_ABORT_FORMAT_MISMATCH.

    Se lanza cuando dos segmentos de la misma sesión no comparten
    samplerate/canales/subtype — nunca se concatenan en silencio.
    Antes: ``RuntimeError`` suelto en ``lorito_export_blocks.py``,
    consolidado aquí en GAP-051 (mismo nombre, mismos sitios de
    import, mismos mensajes)."""
    pass


class ExportAbortError(ExportError):
    """Error de exportación que debe abortar sin dejar un archivo
    final válido a medio escribir (§24, §37 de la Orden de
    Refundación). Antes: ``RuntimeError`` suelto en
    ``lorito_export_blocks.py``, consolidado aquí en GAP-051."""
    pass


class SegmentReadError(ExportError):
    """Un segmento no puede leerse de forma fiable: header corrupto,
    no-WAV, o TRUNCADO (el header declara más frames de los que el
    archivo físicamente contiene).

    Fase 2 de la Orden de Saneamiento Pre-Auditoría (GAP-034) —
    consolidada en la taxonomía común aquí (GAP-051): mismo nombre,
    mismo texto de mensaje en cada sitio existente, ahora también con
    ``segment_id``/``path``/``cause`` estructurados en vez de solo
    incrustados en el string."""
    pass


class SegmentIntegrityError(ExportError):
    """Un segmento se leyó COMPLETO pero su contenido no pasa una
    verificación de integridad posterior (p. ej. un checksum interno
    de segmento no coincide).

    Distinta de `SegmentReadError` (fallo AL leer, antes de tener
    datos) y de `ChecksumMismatchError` (fallo verificando el ARCHIVO
    FINAL ya exportado, no un segmento de origen). Creada por esta
    Orden (§11) — todavía sin un sitio de `raise` real conectado: no
    existe hoy en el proyecto un verificador de integridad DE
    SEGMENTO independiente del de lectura (ver ``ESTADO_MAESTRO_
    CONSOLIDACION.md``, pendiente categorizado)."""
    pass


class FrameAccountingError(ExportError):
    """``frames_in != frames_out``, o frames realmente procesados
    distintos de los frames esperados de la sesión — §4, contrato de
    ``ExportSession``/``AtomicFinalizer``. Conectada en GAP-051 a los
    dos sitios reales de `AtomicFinalizer.run()` que ya detectaban
    esta condición (antes: solo un string en ``report["error"]``,
    ahora también ``report["exception"]`` con esta clase)."""
    pass


class ChecksumMismatchError(ExportError):
    """El checksum del archivo final exportado no pudo calcularse, o
    no coincide con el esperado. §9: ``ARCHIVAL_SAFE`` exige
    ``checksum_verified == True`` — esta excepción es la contraparte
    de exportación de esa exigencia."""
    pass


class ExportFinalizeError(ExportError):
    """Fallo durante la etapa final de ``AtomicFinalizer`` (validación
    del encoder, escritura del archivo de checksum, o el rename
    atómico en sí). Tras este error, ``output.final`` NO debe existir
    como archivo válido (§24, §37). Conectada en GAP-051 a los tres
    sitios reales de `AtomicFinalizer.run()` que corresponden a esta
    etapa (validación del encoder, cómputo de checksum, rename)."""
    pass
