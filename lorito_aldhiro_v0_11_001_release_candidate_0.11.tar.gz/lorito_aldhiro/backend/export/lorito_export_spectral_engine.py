from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de análisis espectral para el visor de espectro de exportación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_spectral_engine.py — backend puro (sin Qt) de la imagen
espectral post-export (§GAP-016), portado en física desde
`crac_export_spectral_engine.py` (auditado en CRAC): misma matemática
exacta (FFT, ventana Hann, percentiles 2/98, mapeo R/G/B) — solo
renombrado a los estándares de Lorito Aldhiro. Cero imports de PySide6,
determinista y testeable con numpy puro.

Contraparte Qt: `lorito_export_spectral_render.py` (pinta cabecera/pie
sobre el buffer RGBA ya calculado aquí y guarda el PNG).
"""

from dataclasses import dataclass

import numpy as np

__all__ = [
    "SpectralImageLayout",
    "DEFAULT_LAYOUT",
    "compute_spectrogram_rgba",
    "compute_spectrogram_rgba_from_windows",
]


@dataclass(frozen=True)
class SpectralImageLayout:
    """Geometría de la imagen espectral 1920×1080 — compartida por el
    backend (qué franja ocupa el espectrograma) y el frontend (dónde
    dibujar cabecera/pie alrededor de esa franja)."""
    img_w: int = 1920
    img_h: int = 1080
    hdr_h: int = 72
    footer_h: int = 38

    @property
    def spec_h(self) -> int:
        return self.img_h - self.hdr_h - self.footer_h


#: Layout por defecto — mismas dimensiones que CRAC (1920×1080,
#: cabecera 72px, pie 38px).
DEFAULT_LAYOUT = SpectralImageLayout()


def _n_frames_and_step(total_len: int, win_size: int, hop_size: int, img_w: int):
    n_frames = max(1, (total_len - win_size) // hop_size + 1)
    step = max(1, n_frames // img_w)
    return n_frames, step


def compute_spectrogram_rgba_from_windows(
    window_provider,
    total_len: int,
    win_size: int,
    layout: SpectralImageLayout = DEFAULT_LAYOUT,
) -> np.ndarray:
    """Núcleo del cálculo del espectrograma, agnóstico de dónde viene el
    audio (array en RAM o archivo en disco vía streaming): solo necesita
    una muestra acotada del audio (`img_w` ventanas de `win_size`
    frames, repartidas uniformemente), nunca la señal completa.

    `window_provider(start_frame) -> np.ndarray` debe devolver
    exactamente `win_size` muestras float32 MONO (con padding de ceros
    si la ventana pisa el final del audio) — responsabilidad del
    llamador, no de este núcleo.
    """
    img_w = layout.img_w
    hdr_h, spec_h = layout.hdr_h, layout.spec_h
    hop_size = win_size // 8
    n_freq = win_size // 2 + 1
    freq_bins = min(spec_h, n_freq)

    window = np.hanning(win_size).astype(np.float32)
    _n_frames, step = _n_frames_and_step(total_len, win_size, hop_size, img_w)

    cols = []
    for xi in range(img_w):
        fi = xi * step
        start = fi * hop_size
        seg = window_provider(start)
        spec = np.abs(np.fft.rfft(seg * window))[:freq_bins]
        spec_db = 20.0 * np.log10(np.clip(spec, 1e-6, None))
        cols.append(spec_db)

    mag = np.array(cols, dtype=np.float32).T
    return _finish_spectrogram_rgba(mag, freq_bins, layout)


def _finish_spectrogram_rgba(
    mag: np.ndarray, freq_bins: int, layout: SpectralImageLayout,
) -> np.ndarray:
    """Percentiles 2/98, escalado del eje de frecuencia y mapeo de
    color — sin cambio de fórmula respecto de CRAC."""
    img_w, img_h = layout.img_w, layout.img_h
    hdr_h, spec_h = layout.hdr_h, layout.spec_h

    lo = np.percentile(mag, 2)
    hi = np.percentile(mag, 98)
    if hi > lo:
        mag = np.clip((mag - lo) / (hi - lo), 0.0, 1.0)
    else:
        mag[:] = 0.0

    if freq_bins != spec_h:
        ys = np.linspace(0, freq_bins - 1, spec_h)
        mag_scaled = np.zeros((spec_h, img_w), dtype=np.float32)
        src_idx = np.arange(freq_bins, dtype=np.float32)
        for xi in range(img_w):
            mag_scaled[:, xi] = np.interp(ys, src_idx, mag[:, xi])
        mag = mag_scaled

    t = mag.astype(np.float32)
    r = np.clip(1.6 * t - 0.10, 0.0, 1.0)
    g = np.clip(2.2 * t - 1.10, 0.0, 1.0)
    b = np.clip(0.6 - np.abs(t - 0.28) * 2.2, 0.0, 1.0)

    ru = (r * 255).astype(np.uint8)
    gu = (g * 255).astype(np.uint8)
    bu = (b * 255).astype(np.uint8)
    au = np.full_like(ru, 255)

    full_rgba = np.zeros((img_h, img_w, 4), dtype=np.uint8)
    full_rgba[:, :, 3] = 255
    spec_rgba = np.stack([ru, gu, bu, au], axis=2)[::-1, :, :].copy()
    full_rgba[hdr_h: hdr_h + spec_h, :, :] = spec_rgba

    return full_rgba


def compute_spectrogram_rgba(
    audio_np: np.ndarray,
    sample_rate: int,
    win_size: int,
    layout: SpectralImageLayout = DEFAULT_LAYOUT,
) -> np.ndarray:
    """Calcula el buffer RGBA (uint8, forma (img_h, img_w, 4)) del
    espectrograma de `audio_np` (mono o multicanal — se promedia a
    mono). `sample_rate` se conserva en la firma por compatibilidad,
    no se usa en el cálculo actual. La franja de cabecera/pie se
    devuelve en negro opaco — el frontend dibuja el texto encima."""
    del sample_rate  # no usado — ver docstring

    if audio_np.ndim > 1:
        mono = audio_np.mean(axis=1).astype(np.float32)
    else:
        mono = audio_np.astype(np.float32)

    def _window_from_array(start: int) -> np.ndarray:
        end = start + win_size
        if end > len(mono):
            seg = np.zeros(win_size, dtype=np.float32)
            avail = len(mono) - start
            if avail > 0:
                seg[:avail] = mono[start:start + avail]
            return seg
        return mono[start:end]

    return compute_spectrogram_rgba_from_windows(
        _window_from_array, len(mono), win_size, layout)
