from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Exportadores de audio a los formatos soportados (WAV/FLAC/OGG/WavPack) — camino legado.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import shutil
import subprocess
import time
import numpy as np
import soundfile as sf

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import FFMPEG_CAPS
from lorito_aldhiro.backend.core.lorito_constants import FLAC_COMP_N, FLAC_SUBTYPE, OGG_QUAL_N, WAV_SUBTYPE, WV_FLAGS



# ─────────────────────────────────────────────────────────────────────────────
#  EXPORT ENGINE MODULAR (v0.08)
# ─────────────────────────────────────────────────────────────────────────────

class ExporterBase:
    """
    Clase base para exportadores. Define la interfaz común.
    Cada subclase implementa _encode() con lógica independiente.
    """

    codec_name: str = "BASE"

    def export(self, audio: np.ndarray, rate: int, out_path: str,
               opt1: str = "", opt2: str = "") -> dict:
        """
        Realiza la exportación. Devuelve dict con:
          ok, path, size_bytes, duration_secs, frames, error
        """
        result = {"ok": False, "path": out_path, "size_bytes": 0,
                  "duration_secs": 0.0, "frames": len(audio), "error": ""}
        try:
            self._encode(audio, rate, out_path, opt1, opt2)
            if os.path.exists(out_path):
                result["size_bytes"]    = os.path.getsize(out_path)
                result["duration_secs"] = len(audio) / max(rate, 1)
                result["ok"]            = True
                _log.info("%s export OK: %s  %d bytes  %.2fs",
                          self.codec_name, out_path,
                          result["size_bytes"], result["duration_secs"])
            else:
                result["error"] = "archivo de salida no generado"
        except Exception as e:
            result["error"] = str(e)
            _log.error("%s export error: %s", self.codec_name, e, exc_info=True)
        return result

    def _encode(self, audio: np.ndarray, rate: int, out_path: str,
                opt1: str, opt2: str):
        raise NotImplementedError


class WAVExporter(ExporterBase):
    codec_name = "WAV"

    def _encode(self, audio, rate, out_path, opt1, opt2):
        subtype = WAV_SUBTYPE.get(opt1, "PCM_24")
        n_channels = audio.shape[1] if audio.ndim > 1 else 1

        # BUG CORREGIDO: WAV RIFF tiene un límite de ~4 GB en el campo "data chunk size"
        # (entero de 32 bits sin signo). A 96 kHz estéreo los límites prácticos son:
        #   PCM_16 → ~3.1 h    PCM_24 → ~2.1 h    PCM_32/FLOAT → ~1.55 h
        # Si se supera el límite, libsndfile trunca silenciosamente el archivo sin
        # lanzar excepción, produciendo WAV corrompido. Solución: usar RF64 para
        # archivos que superen el umbral seguro de 3.9 GB.
        BPS = {"PCM_16": 2, "PCM_24": 3, "PCM_32": 4, "FLOAT": 4}.get(subtype, 4)
        estimated_bytes = len(audio) * n_channels * BPS
        WAV_SAFE_LIMIT = 3_900_000_000  # margen bajo el límite RIFF de 4 GB

        if estimated_bytes > WAV_SAFE_LIMIT:
            wav_format = "RF64"
            _log.info("WAV: audio largo (%.2f GB %s) → usando RF64",
                      estimated_bytes / 1e9, subtype)
        else:
            wav_format = "WAV"

        # Usar context manager explícito + fsync para garantizar escritura
        # completa sin entrecortes — crítico para digitalización patrimonial
        with sf.SoundFile(out_path, mode="w", samplerate=rate,
                          channels=n_channels,
                          subtype=subtype, format=wav_format) as f:
            # PATCH 10H+: WRITE_BLOCK reducido a 32768 para mejor granularidad
            # de progreso y menor presión de caché en sesiones >10 h.
            # 32768 frames ≈ 0.68 s @ 48 kHz / 0.34 s @ 96 kHz
            WRITE_BLOCK = 32768
            for start in range(0, len(audio), WRITE_BLOCK):
                f.write(audio[start:start + WRITE_BLOCK])
        # fsync post-cierre: garantiza persistencia en disco antes de validar
        try:
            with open(out_path, "r+b") as raw:
                raw.flush()
                os.fsync(raw.fileno())
        except Exception:
            pass
        _log.info("WAV: %s  format=%s  subtype=%s  frames=%d",
                  out_path, wav_format, subtype, len(audio))


class FLACExporter(ExporterBase):
    codec_name = "FLAC"

    def _encode(self, audio, rate, out_path, opt1, opt2):
        subtype    = FLAC_SUBTYPE.get(opt1, "PCM_24")
        comp_level = FLAC_COMP_N.get(opt2, 4)
        n_channels = audio.shape[1] if audio.ndim > 1 else 1
        # PATCH 10H+: WRITE_BLOCK reducido a 32768 (ver WAVExporter)
        WRITE_BLOCK = 32768
        with sf.SoundFile(out_path, mode="w", samplerate=rate,
                          channels=n_channels,
                          subtype=subtype, format="FLAC") as f:
            for start in range(0, len(audio), WRITE_BLOCK):
                f.write(audio[start:start + WRITE_BLOCK])
        # fsync post-cierre
        try:
            with open(out_path, "r+b") as raw:
                raw.flush(); os.fsync(raw.fileno())
        except Exception:
            pass
        # Re-encode con ffmpeg para nivel de compresión
        if FFMPEG_CAPS["available"] and FFMPEG_CAPS["flac"]:
            tmp_flac = out_path + ".tmp_reenc.flac"
            os.rename(out_path, tmp_flac)
            # BUG CORREGIDO: timeout=300 fijo insuficiente para re-encode FLAC de
            # sesiones largas a 96 kHz. Un archivo FLAC de 2h+ puede tardar >5 min
            # en re-encodarse al nivel de compresión 8.
            # Además, TimeoutExpired no era capturado (mismo bug que OGGExporter).
            # Solución: timeout dinámico + Popen para kill limpio.
            # PATCH 10H+: división flotante para dur_s exacto (la versión int
            # truncaba a 0 con blocksize grande y producía timeout mínimo incorrecto).
            # Multiplicador 6× (antes 3×) para cubrir re-encode comp_level=8 en
            # CPUs lentas con carga I/O: 10 h × 6 + 60 = 216 060 s (~60 h).
            dur_s = len(audio) / max(rate, 1)
            flac_timeout = max(300, int(dur_s * 6 + 60))
            _log.info("FLAC re-encode timeout: %d s (audio=%.1f min)", flac_timeout, dur_s/60)
            try:
                proc = subprocess.Popen(
                    [FFMPEG_CAPS["path"], "-y", "-i", tmp_flac,
                     "-c:a", "flac", "-compression_level", str(comp_level),
                     out_path],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                try:
                    _out, _err = proc.communicate(timeout=flac_timeout)
                    if proc.returncode != 0:
                        err_txt = _err.decode(errors="replace")[:80]
                        raise subprocess.CalledProcessError(proc.returncode, [], _out, _err)
                except subprocess.TimeoutExpired:
                    proc.kill(); proc.communicate()
                    _log.warning("FLAC re-encode timeout (%d s) — usando soundfile", flac_timeout)
                    # Restaurar el FLAC original de soundfile
                    if os.path.exists(tmp_flac) and not os.path.exists(out_path):
                        os.rename(tmp_flac, out_path)
                    # El archivo soundfile ya es válido aunque sin nivel de compresión óptimo
                    _log.info("FLAC: usando archivo soundfile (comp_level=soundfile default)")
                    return
                # fsync del FLAC re-codificado
                try:
                    with open(out_path, "r+b") as raw:
                        raw.flush(); os.fsync(raw.fileno())
                except Exception:
                    pass
            except subprocess.CalledProcessError as fe:
                _log.warning("FLAC re-encode falló (%s), usando soundfile",
                             fe.stderr.decode(errors="replace")[:80] if fe.stderr else "?")
                if os.path.exists(tmp_flac) and not os.path.exists(out_path):
                    os.rename(tmp_flac, out_path)
            finally:
                if os.path.exists(tmp_flac):
                    try: os.remove(tmp_flac)
                    except Exception: pass
        _log.info("FLAC: %s  subtype=%s  comp=%d  frames=%d",
                  out_path, subtype, comp_level, len(audio))


class OGGExporter(ExporterBase):
    codec_name = "OGG"

    @staticmethod
    def _calc_ffmpeg_timeout(audio_len: int, rate: int) -> int:
        """
        Calcula un timeout dinámico para ffmpeg proporcional a la duración del audio.

        BUG CORREGIDO: timeout=600 fijo causaba subprocess.TimeoutExpired no capturado
        en sesiones >1 hora a 96 kHz con calidad máxima (q9). libvorbis a q9 sobre
        1.38 GB de PCM puede tardar 15-30 min en CPUs lentas. TimeoutExpired no es
        subclase de CalledProcessError, por lo que escapaba al except externo y
        crasheaba el hilo de exportación dejando el proceso colgado.

        Fórmula: 6× la duración real del audio + margen base de 120 s.
        Mínimo 300 s, sin techo (archivos multi-hora necesitan tiempo proporcional).
        PATCH 10H+: multiplicador elevado de 4× a 6× para cubrir libvorbis q9
        en CPUs lentas con carga I/O (10 h × 6 + 120 = 216 120 s ≈ 60 h).
        División flotante para dur_s exacto (la versión int//rate truncaba en
        bloques de tamaño grande produciendo timeout mínimo incorrecto).
        """
        dur_s = audio_len / max(rate, 1)
        return max(300, int(dur_s * 6 + 120))

    @staticmethod
    def _run_ffmpeg_safe(cmd: list, timeout: int) -> tuple:
        """
        Ejecuta ffmpeg con Popen en lugar de subprocess.run para poder matar
        el proceso si se excede el timeout, evitando que quede zombie.

        BUG CORREGIDO: subprocess.run con timeout deja ffmpeg huérfano en segundo
        plano si se lanza TimeoutExpired — el proceso sigue consumiendo CPU/IO.
        Con Popen + kill() garantizamos limpieza total del subproceso.

        Retorna (returncode, stdout_bytes, stderr_bytes).
        Lanza RuntimeError en timeout (con mensaje claro) en lugar de
        subprocess.TimeoutExpired no tipado, que el llamador captura limpiamente.
        """
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
            return proc.returncode, stdout, stderr
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()  # limpiar pipes para evitar deadlock
            raise RuntimeError(
                f"ffmpeg excedió el timeout de {timeout}s — proceso terminado. "
                f"El audio es demasiado largo o el sistema está sobrecargado."
            )

    def _encode(self, audio, rate, out_path, opt1, opt2):
        qual_n  = OGG_QUAL_N.get(opt1, 5)
        encoded = False
        tmp_wav = out_path + "_ogg_tmp.wav"

        # ── Timeout dinámico proporcional a la duración real del audio ──────────
        # BUG CORREGIDO: timeout fijo de 600 s insuficiente para sesiones >1 hora.
        ffmpeg_timeout = self._calc_ffmpeg_timeout(len(audio), rate)
        _log.info("OGG timeout ffmpeg: %d s (audio=%.1f min @ %d Hz)",
                  ffmpeg_timeout, len(audio) / max(rate, 1) / 60, rate)

        # ── Determinar formato del WAV intermedio ────────────────────────────────
        # BUG CORREGIDO: soundfile escribe WAV RIFF estándar con campos de tamaño
        # de 32 bits sin signo. El campo "data chunk size" admite hasta 4 294 967 295
        # bytes (~3.1 h a 96 kHz estéreo PCM_16). Para audio >~3 h el WAV intermedio
        # se corrompe silenciosamente (soundfile/libsndfile trunca sin error).
        # Solución: detectar si el audio supera el umbral y usar RF64 (W64) que
        # extiende los campos de tamaño a 64 bits, sin límite práctico.
        #
        # Límite seguro: 3 900 000 000 bytes (margen de seguridad sobre los 4 GB)
        n_channels = audio.shape[1] if audio.ndim > 1 else 1
        bytes_pcm16 = len(audio) * n_channels * 2  # 2 bytes por muestra PCM_16
        WAV_SAFE_LIMIT = 3_900_000_000  # ~3.9 GB — margen bajo el límite RIFF de 4 GB

        if bytes_pcm16 > WAV_SAFE_LIMIT:
            # RF64: extensión del estándar WAV con campos de 64 bits.
            # Soportado por ffmpeg ≥ 2.x como entrada sin flags adicionales.
            # soundfile/libsndfile ≥ 1.0.26 lo escribe con format="RF64".
            tmp_format = "RF64"
            _log.info("OGG: audio largo (%.2f GB PCM_16) → usando WAV RF64 para tmp",
                      bytes_pcm16 / 1e9)
        else:
            tmp_format = "WAV"

        try:
            # Escribir WAV/RF64 intermedio con fsync — garantiza que ffmpeg lea datos completos
            # PATCH 10H+: WRITE_BLOCK reducido a 32768 (ver WAVExporter)
            WRITE_BLOCK = 32768
            with sf.SoundFile(tmp_wav, mode="w", samplerate=rate,
                              channels=n_channels,
                              subtype="PCM_16",
                              format=tmp_format) as f:
                for start in range(0, len(audio), WRITE_BLOCK):
                    f.write(audio[start:start + WRITE_BLOCK])
            with open(tmp_wav, "r+b") as raw:
                raw.flush(); os.fsync(raw.fileno())

            # Intento 1: libvorbis
            if FFMPEG_CAPS["available"] and FFMPEG_CAPS["libvorbis"]:
                qual_f = float(qual_n)
                # ── Construcción del comando libvorbis ────────────────────────────
                #
                # MODO VBR PURO para todos los niveles de calidad:
                # libvorbis es un encoder VBR nativo. Los flags -maxrate:a,
                # -minrate:a y -bufsize:a son hints de control CBR/ABR que ffmpeg
                # pasa al encoder vía AVCodecContext. libvorbis los ignora en modo
                # VBR o los interpreta de forma inconsistente cuando coexisten con
                # -q:a, especialmente en q >= 6:
                #
                #   · -maxrate:a + -q:a juntos activan un modo "VBR-constrained"
                #     no documentado en libvorbis. A q9 (320 kbps) el encoder
                #     intenta respetar el techo de bitrate MIENTRAS mantiene la
                #     calidad VBR, entrando en conflicto cuando el material de audio
                #     requiere más bits de los que el techo permite. El resultado es
                #     un granulepos incorrecto en la página EOS: el último bloque
                #     de samples queda con un timestamp desplazado, lo que hace que
                #     los decoders (VLC, mpv, GStreamer, Chrome) reporten duración
                #     truncada o nula y el seek/scrub falle.
                #
                #   · -minrate:a 32k con -maxrate:a 320k (ratio 1:10) obliga al
                #     encoder a insertar padding en frames de baja energía (silencios,
                #     colas de reverb). Ese padding desplaza los límites de paquete
                #     en las últimas páginas Ogg y corrompe el granulepos final.
                #
                # SOLUCIÓN: modo VBR puro con solo -q:a. Sin -maxrate/-minrate/-bufsize.
                # El encoder elige libremente el número de bits por frame, el muxer
                # Ogg calcula el granulepos EOS correctamente, y los decoders leen
                # la duración real del stream desde el granulepos de la última página.
                #
                # -page_duration 500000 (microsegundos = 500 ms por página Ogg):
                # Sin esta flag, libogg usa el default de 1 segundo por página. A
                # 320 kbps eso son ~40 KB por página — demasiado grande para las
                # tablas de seek de muchos decoders (GStreamer, WebAudio). Con 500 ms
                # cada página pesa ~20 KB, dentro del rango óptimo para seek preciso.
                # A bitrates bajos (q1-q5) el impacto es mínimo pero tampoco perjudica.
                #
                # -map_metadata -1: descarta todos los metadatos del WAV fuente.
                # ffmpeg hereda el campo DURATION del WAV origen y lo escribe como
                # comentario Vorbis. Si ese valor difiere del granulepos EOS (aunque
                # sea por redondeo PCM_16), los decoders lo priorizan sobre el
                # granulepos y muestran duración incorrecta.
                #
                # -vn: descarta cualquier stream de video/cover que ffmpeg detecte
                # en el WAV, evitando que el muxer genere una segunda página lógica
                # en el stream Ogg que confunde a decoders que esperan solo audio.
                cmd = [
                    FFMPEG_CAPS["path"], "-y", "-i", tmp_wav,
                    "-vn", "-map_metadata", "-1",
                    "-c:a", "libvorbis",
                    "-q:a", f"{qual_f:.1f}",
                    "-page_duration", "500000",
                    out_path,
                ]
                try:
                    rc, _out, _err = self._run_ffmpeg_safe(cmd, ffmpeg_timeout)
                    if rc != 0:
                        raise subprocess.CalledProcessError(rc, cmd, _out, _err)
                    encoded = True
                    _log.info("OGG libvorbis OK: q=%.1f", qual_f)
                    # BUG CORREGIDO v4: fsync del .ogg de salida — garantiza que los
                    # datos escritos por ffmpeg estén realmente en disco antes de que
                    # _validate_export los lea. Sin fsync, el archivo puede parecer
                    # válido en tamaño pero estar truncado/corrupto al abrirlo.
                    try:
                        with open(out_path, "r+b") as _raw:
                            _raw.flush(); os.fsync(_raw.fileno())
                    except Exception:
                        pass
                except subprocess.CalledProcessError as e:
                    _log.warning("OGG libvorbis falló: %s",
                                 e.stderr.decode(errors="replace")[:120] if e.stderr else "")
                    if os.path.exists(out_path):
                        try: os.remove(out_path)
                        except Exception: pass
                except RuntimeError as e:
                    # TimeoutExpired convertido en RuntimeError descriptivo por _run_ffmpeg_safe
                    _log.warning("OGG libvorbis timeout: %s", e)
                    if os.path.exists(out_path):
                        try: os.remove(out_path)
                        except Exception: pass

            # Intento 2: vorbis nativo
            if not encoded and FFMPEG_CAPS["available"] and FFMPEG_CAPS["vorbis"]:
                qual_f = float(qual_n)
                try:
                    # Misma lógica VBR pura que Intento 1: sin -maxrate/-minrate,
                    # -page_duration 500000 para páginas Ogg de tamaño óptimo para
                    # seek, y sin -fflags +bitexact (incompatible con VBR en este encoder).
                    rc, _out, _err = self._run_ffmpeg_safe(
                        [FFMPEG_CAPS["path"], "-y", "-i", tmp_wav,
                         "-vn", "-map_metadata", "-1",
                         "-c:a", "vorbis", "-strict", "-2",
                         "-q:a", f"{qual_f:.1f}",
                         "-page_duration", "500000",
                         out_path],
                        ffmpeg_timeout
                    )
                    if rc != 0:
                        raise subprocess.CalledProcessError(rc, [], _out, _err)
                    encoded = True
                    _log.info("OGG vorbis nativo OK: q=%.1f", qual_f)
                    # BUG CORREGIDO v4: fsync del .ogg de salida (ver Intento 1)
                    try:
                        with open(out_path, "r+b") as _raw:
                            _raw.flush(); os.fsync(_raw.fileno())
                    except Exception:
                        pass
                except subprocess.CalledProcessError as e:
                    _log.warning("OGG vorbis nativo falló: %s",
                                 e.stderr.decode(errors="replace")[:120] if e.stderr else "")
                    if os.path.exists(out_path):
                        try: os.remove(out_path)
                        except Exception: pass
                except RuntimeError as e:
                    _log.warning("OGG vorbis nativo timeout: %s", e)
                    if os.path.exists(out_path):
                        try: os.remove(out_path)
                        except Exception: pass

            # Intento 3: soundfile fallback
            # NOTA: soundfile no usa WAV intermedio aquí — escribe OGG directo.
            # Para audio muy largo puede ser lento pero no tiene el límite de timeout.
            # Limitación: libsndfile no expone control de page_duration ni descarte
            # de metadatos. Si ffmpeg está disponible, se hace un reempaquetado
            # de paso único post-encode para aplicar las mismas correcciones que
            # los intentos 1 y 2 (page_duration=500ms, sin metadatos WAV heredados).
            if not encoded:
                _log.info("OGG soundfile fallback: escribiendo directo (sin ffmpeg)")
                tmp_sf_ogg = out_path + "_sf_tmp.ogg"
                WRITE_BLOCK = 32768
                with sf.SoundFile(tmp_sf_ogg, mode="w", samplerate=rate,
                                  channels=n_channels,
                                  subtype="VORBIS", format="OGG") as f_ogg:
                    for start in range(0, len(audio), WRITE_BLOCK):
                        f_ogg.write(audio[start:start + WRITE_BLOCK])
                with open(tmp_sf_ogg, "r+b") as _raw:
                    _raw.flush(); os.fsync(_raw.fileno())

                # Reempaquetado via ffmpeg: copy stream sin re-encode,
                # aplicando page_duration=500ms y descartando metadatos.
                # Esto corrige el granulepos EOS y la granularidad de seek
                # sin tocar los datos Vorbis codificados por libsndfile.
                _sf_repack_ok = False
                if FFMPEG_CAPS["available"]:
                    try:
                        _rp_timeout = max(120, int(len(audio) / max(rate, 1) * 2 + 60))
                        rc_rp, _, _rp_err = self._run_ffmpeg_safe(
                            [FFMPEG_CAPS["path"], "-y", "-i", tmp_sf_ogg,
                             "-vn", "-map_metadata", "-1",
                             "-c:a", "copy",
                             "-page_duration", "500000",
                             out_path],
                            _rp_timeout,
                        )
                        if rc_rp == 0:
                            _sf_repack_ok = True
                            _log.info("OGG soundfile fallback + repack OK")
                        else:
                            _log.warning("OGG soundfile repack falló (rc=%d): %s",
                                         rc_rp,
                                         _rp_err.decode(errors="replace")[:120] if _rp_err else "")
                    except Exception as _rp_e:
                        _log.warning("OGG soundfile repack excepción: %s", _rp_e)
                    finally:
                        if os.path.exists(tmp_sf_ogg):
                            try: os.remove(tmp_sf_ogg)
                            except Exception: pass

                if not _sf_repack_ok:
                    # Si el repack falló (o ffmpeg no está), usar el OGG de
                    # soundfile directamente — es funcional aunque el scrub
                    # puede ser menos preciso a bitrates altos.
                    if not os.path.exists(out_path) and os.path.exists(tmp_sf_ogg):
                        shutil.move(tmp_sf_ogg, out_path)
                    elif os.path.exists(tmp_sf_ogg):
                        try: os.remove(tmp_sf_ogg)
                        except Exception: pass
                    _log.info("OGG soundfile fallback OK (sin repack)")

                try:
                    with open(out_path, "r+b") as _raw:
                        _raw.flush(); os.fsync(_raw.fileno())
                except Exception:
                    pass
                encoded = True

            if not encoded:
                raise RuntimeError("No se pudo codificar OGG.")
        finally:
            if os.path.exists(tmp_wav):
                try: os.remove(tmp_wav)
                except Exception: pass


class WVExporter(ExporterBase):
    codec_name = "WV"

    def _encode(self, audio, rate, out_path, opt1, opt2):
        comp_level = WV_FLAGS.get(opt1, "5")
        if not FFMPEG_CAPS["available"]:
            raise RuntimeError("ffmpeg no encontrado para exportar WavPack.")
        n_channels = audio.shape[1] if audio.ndim > 1 else 1

        # OPTIMIZACIÓN: codificación via pipe — se elimina el WAV temporal en disco.
        # En la versión anterior se escribía un archivo WAV intermedio completo (hasta
        # varios GB) y luego ffmpeg lo leía entero: doble I/O innecesario que duplicaba
        # el tiempo de exportación. Ahora ffmpeg lee el PCM_s24le directamente desde
        # stdin, sin tocar el disco en absoluto hasta escribir el .wv final.
        #
        # ffmpeg recibe:  -f s24le -ar <rate> -ac <ch>  (raw PCM signed 24-bit LE)
        # El audio numpy se convierte a int32, se desplaza a los 24 bits superiores
        # y luego se empaqueta como s24le (3 bytes/muestra) antes de enviarlo al pipe.
        #
        # Timeout: 6× la duración + 120 s de margen (igual que antes), suficiente
        # incluso para el modo Extra (2-pass) en CPUs lentas.
        dur_s = len(audio) / max(rate, 1)
        wv_timeout = max(300, int(dur_s * 6 + 120))
        _log.info("WV pipe timeout: %d s (audio=%.1f min, cl=%s)",
                  wv_timeout, dur_s / 60, comp_level)

        # ── Streaming pipe: conversión float32→s24le por bloques ─────────────
        # OPTIMIZACIÓN: la versión anterior convertía TODO el array a s24le en
        # memoria antes de abrir ffmpeg, produciendo hasta 4 copias completas
        # del audio en RAM de forma secuencial:
        #
        #   1. np.asarray(float32)            → copia si no era float32 ya
        #   2. np.clip()                       → array float32 nuevo
        #   3. (* 2147483647).astype(int32)    → array int32 completo (4 B/sample)
        #   4. .tobytes()                      → bytes raw int32 (4 B/sample)
        #   5. frombuffer().reshape()[:,1:]    → vista uint8 + slice contiguo
        #   6. .tobytes()                      → bytes s24le finales (3 B/sample)
        #   7. proc.communicate(input=pcm24)   → todo el buffer en stdin de un golpe
        #
        # Para 1 h de audio estéreo a 96 kHz esto son ~7 GB solo en la etapa
        # de conversión (float32+int32+s24le) antes de escribir un byte al pipe,
        # bloqueando la GUI durante ese tiempo en el estado "SE PREPARAN A VACIAR".
        #
        # SOLUCIÓN: la conversión se hace en bloques de PIPE_BLOCK frames y se
        # escribe directamente al stdin del proceso ffmpeg por streaming. Solo un
        # bloque (~8 MB por defecto) reside en RAM en cada momento.
        # El proceso ffmpeg arranca inmediatamente y puede empezar a codificar
        # mientras los bloques siguen llegando, solapando I/O y CPU.
        #
        # Técnica s24le sin copia extra:
        #   pcm32 int32 LE en memoria = [b0(LSB) b1 b2 b3(MSB)]
        #   s24le requiere los 3 bytes SUPERIORES = [b1 b2 b3]
        #   → vista uint8, shape (n,4), tomar columnas [1,2,3], hacer ascontiguousarray
        #   → un solo tobytes() produce el stream s24le correcto sin copia intermedia.
        PIPE_BLOCK = 65536  # frames por bloque de pipe (~8 MB float32 estéreo)

        def _iter_pcm24_blocks(arr):
            """Generador: convierte arr float32 a bloques bytes s24le sin copia global."""
            n_frames = arr.shape[0]
            for start in range(0, n_frames, PIPE_BLOCK):
                chunk = arr[start:start + PIPE_BLOCK]
                chunk_f = np.clip(np.asarray(chunk, dtype=np.float32), -1.0, 1.0)
                pcm32_blk = (chunk_f * 2147483647.0).astype(np.int32)
                n_s = pcm32_blk.size
                u8 = np.frombuffer(pcm32_blk.tobytes(), dtype=np.uint8).reshape(n_s, 4)
                yield np.ascontiguousarray(u8[:, 1:]).tobytes()

        def _run_wv_pipe(encoder_name: str) -> tuple:
            """Arranca ffmpeg y le envía PCM s24le por stdin en bloques."""
            cmd = [
                FFMPEG_CAPS["path"], "-y",
                "-f", "s24le", "-ar", str(rate), "-ac", str(n_channels),
                "-i", "pipe:0",
                "-c:a", encoder_name, "-compression_level", comp_level,
                out_path,
            ]
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            try:
                # Escribir bloque a bloque: ffmpeg codifica en paralelo mientras
                # Python convierte el siguiente bloque — CPU y I/O solapados.
                deadline = time.monotonic() + wv_timeout
                for blk_bytes in _iter_pcm24_blocks(audio):
                    if time.monotonic() > deadline:
                        proc.kill(); proc.communicate()
                        raise RuntimeError(
                            f"ffmpeg WavPack ({encoder_name}) excedió el timeout "
                            f"de {wv_timeout}s durante escritura — proceso terminado.")
                    proc.stdin.write(blk_bytes)
                proc.stdin.close()
                # Esperar a que ffmpeg termine con el tiempo restante
                remaining = max(10, int(deadline - time.monotonic()))
                stdout, stderr = proc.communicate(timeout=remaining)
                return proc.returncode, stdout, stderr
            except subprocess.TimeoutExpired:
                proc.kill(); proc.communicate()
                raise RuntimeError(
                    f"ffmpeg WavPack ({encoder_name}) excedió el timeout "
                    f"de {wv_timeout}s — proceso terminado.")
            except Exception:
                try: proc.kill(); proc.communicate()
                except Exception: pass
                raise

        def _fsync_out():
            """fsync del .wv final: garantiza persistencia antes de _validate_export."""
            try:
                with open(out_path, "r+b") as _raw:
                    _raw.flush(); os.fsync(_raw.fileno())
            except Exception:
                pass

        encoded = False

        if FFMPEG_CAPS["libwavpack"]:
            try:
                rc, _out, _err = _run_wv_pipe("libwavpack")
                if rc != 0:
                    raise subprocess.CalledProcessError(rc, [], _out, _err)
                _fsync_out()
                encoded = True
                _log.info("WV libwavpack pipe OK: cl=%s", comp_level)
            except subprocess.CalledProcessError as e:
                _log.warning("WV libwavpack pipe falló (rc=%s): %s",
                             e.returncode,
                             e.stderr.decode(errors="replace")[:200] if e.stderr else "")
            except RuntimeError as e:
                _log.warning("WV libwavpack pipe: %s", e)

        if not encoded and FFMPEG_CAPS["wavpack"]:
            try:
                rc, _out, _err = _run_wv_pipe("wavpack")
                if rc != 0:
                    raise subprocess.CalledProcessError(rc, [], _out, _err)
                _fsync_out()
                encoded = True
                _log.info("WV wavpack nativo pipe OK: cl=%s", comp_level)
            except subprocess.CalledProcessError as e:
                _log.warning("WV wavpack nativo pipe falló (rc=%s): %s",
                             e.returncode,
                             e.stderr.decode(errors="replace")[:200] if e.stderr else "")
            except RuntimeError as e:
                _log.warning("WV wavpack nativo pipe: %s", e)

        if not encoded:
            raise RuntimeError("ffmpeg sin encoder WavPack disponible. "
                               "Instala: sudo apt install ffmpeg")


# Mapa codec → exportador
_EXPORTERS = {
    "WAV":  WAVExporter(),
    "FLAC": FLACExporter(),
    "OGG":  OGGExporter(),
    "WV":   WVExporter(),
}
