from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Finalización atómica de exportación — nunca deja un archivo final a medias.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_atomic_finalizer.py — finalización atómica (§24, §37, §38, FASE 8):

    output.partial → write → flush → fsync → validate → checksum
                   → atomic rename → output.final

Si falla cualquier etapa, `output.final` NO debe existir como archivo
válido. Envuelve cualquier `Encoder` (§23) sin conocer sus detalles de
codec — funciona igual para WAV nativo (`lorito_wav_encoder.py`) que
para los adaptadores futuros de FLAC/OGG/WV.

Reutiliza los helpers de integridad ya existentes y verificados en el
proyecto (`lorito_export_integrity._sha256_file` /
`_write_checksum_file`, streaming — nunca cargan el archivo completo en
RAM), en vez de reimplementar SHA-256.
"""

import os

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import ExportAbortError
# GAP-051 (§4/§11, FASE 1): usadas para adjuntar, además del string ya
# existente en `report["error"]` (preservado tal cual), la excepción
# tipificada y estructurada correspondiente en `report["exception"]`.
from lorito_aldhiro.backend.errors import ExportError, FrameAccountingError, ExportFinalizeError


def _sha256_file(path: str, chunk_size: int = 1 << 20) -> str:
    """
    Import diferido de `lorito_export_integrity._sha256_file` para no
    forzar la dependencia de `soundfile` (import a nivel de módulo en
    `lorito_export_integrity.py`) sobre algo que no la necesita — la
    propia función es pura stdlib (`hashlib`). Import perezoso dentro de
    la función; si `lorito_export_integrity` no puede importarse (p. ej.
    este sandbox, sin `soundfile` instalado), se usa una copia idéntica
    como fallback, NUNCA una versión distinta.
    """
    try:
        from lorito_aldhiro.backend.export.lorito_export_integrity import (
            _sha256_file as _real_sha256_file,
        )
        return _real_sha256_file(path, chunk_size)
    except ImportError:
        import hashlib
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                blk = f.read(chunk_size)
                if not blk:
                    break
                h.update(blk)
        return h.hexdigest()


def _write_checksum_file(audio_path: str, sha256: str,
                         duration_secs: float, frames: int) -> str:
    """Ver nota de `_sha256_file` — mismo patrón de import perezoso con
    fallback idéntico en forma, para no acoplar este módulo (sin
    dependencias externas) a `soundfile` solo por compartir paquete con
    `lorito_export_integrity.py`."""
    try:
        from lorito_aldhiro.backend.export.lorito_export_integrity import (
            _write_checksum_file as _real_write_checksum_file,
        )
        return _real_write_checksum_file(audio_path, sha256, duration_secs, frames)
    except ImportError:
        chk_path = audio_path + ".sha256"
        try:
            with open(chk_path, "w", encoding="utf-8") as f:
                f.write(f"{sha256}  {os.path.basename(audio_path)}\n")
                f.write(f"# Frames: {frames}\n# Duracion: {duration_secs:.3f} s\n")
        except OSError:
            chk_path = ""
        return chk_path


class AtomicFinalizer:
    """
    Uso:
        finalizer = AtomicFinalizer(encoder_cls=WavEncoder,
                                     fmt=fmt, final_path="captura.wav",
                                     encoder_kwargs={"subtype": "PCM_24",
                                                      "total_frames_hint": N})
        report = finalizer.run(blocks_iterable, total_frames_expected=N)
    """

    def __init__(self, encoder_cls, fmt, final_path: str,
                 encoder_kwargs: dict | None = None):
        self.encoder_cls = encoder_cls
        self.fmt = fmt
        self.final_path = final_path
        self.partial_path = final_path + ".partial"
        self.encoder_kwargs = dict(encoder_kwargs or {})

    def run(self, blocks_iterable, total_frames_expected: int = 0) -> dict:
        report = {
            "ok": False, "path": self.final_path, "error": "",
            "frames_in": 0, "frames_out": 0, "sha256": "",
            "checksum_path": "",
            # GAP-051 (§11): excepción tipificada/estructurada
            # equivalente a "error" — None en éxito. Aditivo: nadie
            # que ya lea solo "ok"/"error" ve ningún cambio.
            "exception": None,
        }

        # Limpiar cualquier .partial huérfano de una corrida anterior (§38)
        if os.path.exists(self.partial_path):
            try:
                os.remove(self.partial_path)
            except OSError:
                pass

        encoder = self.encoder_cls(self.fmt, self.partial_path, **self.encoder_kwargs)
        frames_in = 0
        try:
            encoder.open()
            for blk in blocks_iterable:
                encoder.write(blk)
                frames_in += blk.n_frames
            encoder.flush()
        except Exception as e:
            # GAP-066: `encoder.finalize()` DEBE correr ANTES de
            # `_cleanup_partial()`, no después (como hacía un
            # `finally` de más abajo en versiones previas de este
            # método). Para un encoder SÍNCRONO que escribe
            # directamente a un descriptor de archivo (`WavEncoder`),
            # el orden no importaba — cualquier byte ya escrito está
            # en disco de inmediato. Pero para un encoder ASÍNCRONO
            # respaldado por un subproceso (p. ej. `ffmpeg`, ver
            # `_FfmpegPipeEncoder`/`lorito_ffmpeg_stream_encoder.py`),
            # el archivo de salida puede no existir aún — o estar
            # incompleto — hasta que `finalize()` cierra el pipe de
            # entrada y ESPERA a que el proceso termine de escribir:
            # limpiar antes de eso dejaba, en la práctica (descubierto
            # con ejecución real de `ExportSession` con un encoder
            # ffmpeg real fallando a mitad de stream, no un escenario
            # hipotético), un `.partial` huérfano que el propio
            # proceso terminaba de crear DESPUÉS de que la "limpieza"
            # ya había corrido. §37/§38 exigen que ningún fallo deje
            # basura, sea cual sea el tipo de encoder.
            try:
                encoder.finalize()
            except Exception:
                pass
            self._cleanup_partial()
            report["error"] = f"fallo durante codificación: {e}"
            # Si `e` ya es de nuestra familia (p. ej. `SegmentReadError`
            # propagado desde `SegmentProvider.iter_blocks()` a través
            # del iterable de bloques), se preserva TAL CUAL — no se
            # reenvuelve, para no perder sus campos estructurados
            # (segment_id/path/frame_start) ni encadenar dos veces.
            report["exception"] = e if isinstance(e, ExportError) else ExportError(
                report["error"], cause=e)
            return report

        try:
            encoder.finalize()
        except Exception:
            pass

        report["frames_in"] = frames_in

        validation = encoder.validate()
        if not validation.get("ok"):
            self._cleanup_partial()
            report["error"] = f"validación falló: {validation.get('error')}"
            report["exception"] = ExportFinalizeError(report["error"])
            return report

        report["frames_out"] = validation.get("actual_frames", 0)

        # §28: en modo patrimonial estricto, frames_in == frames_out es requisito
        if total_frames_expected and frames_in != total_frames_expected:
            self._cleanup_partial()
            report["error"] = (
                f"frame accounting: se procesaron {frames_in} frames pero se "
                f"esperaban {total_frames_expected} (fuente incompleta)")
            report["exception"] = FrameAccountingError(
                report["error"], frame_count=total_frames_expected)
            return report

        if report["frames_out"] and report["frames_out"] != frames_in:
            self._cleanup_partial()
            report["error"] = (
                f"frame accounting: frames_in={frames_in} != "
                f"frames_out={report['frames_out']} — archivo final descartado")
            report["exception"] = FrameAccountingError(
                report["error"], frame_count=frames_in)
            return report

        # Checksum ANTES del rename (se checksuma el .partial, ya completo y válido)
        sha = _sha256_file(self.partial_path)
        if not sha:
            self._cleanup_partial()
            report["error"] = "no se pudo calcular checksum del archivo válido"
            report["exception"] = ExportFinalizeError(report["error"])
            return report
        report["sha256"] = sha

        # Atomic rename: mismo filesystem → operación atómica del SO
        try:
            os.replace(self.partial_path, self.final_path)
        except OSError as e:
            self._cleanup_partial()
            report["error"] = f"rename atómico falló: {e}"
            report["exception"] = ExportFinalizeError(report["error"], cause=e)
            return report

        chk_path = _write_checksum_file(
            self.final_path, sha,
            duration_secs=report["frames_out"] / max(self.fmt.rate, 1),
            frames=report["frames_out"],
        )
        report["checksum_path"] = chk_path
        report["ok"] = True
        return report

    def _cleanup_partial(self) -> None:
        if os.path.exists(self.partial_path):
            try:
                os.remove(self.partial_path)
            except OSError:
                pass
        # Nunca dejar output.final si algo falló a mitad de camino
        if os.path.exists(self.final_path):
            # Solo se llega aquí si un intento previo dejó basura; un
            # AtomicFinalizer nunca escribe final_path salvo en el rename
            # exitoso del final de run(), así que esto es puramente
            # defensivo (§37: "no corrupted final file").
            pass
