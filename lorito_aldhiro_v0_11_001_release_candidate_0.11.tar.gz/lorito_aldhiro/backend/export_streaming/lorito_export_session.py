from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Orquestador de una sesión de exportación streaming completa.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_session.py — orquesta el pipeline streaming completo (§20):

    Segment Provider → Block Iterator → (DSP/Resampler: pendiente, ver
    GAP-003 §6) → Codec Writer → Integrity Validator → Atomic Finalizer

Punto de entrada único para reemplazar, en una sesión futura, a
`LoritoAldhiroStudio._build_export_array()` + `ExporterBase.export()`
(`lorito_main_window.py` / `lorito_exporters.py`, ambos SIN TOCAR en
esta revisión — ver GAP-003 §7 sobre por qué la integración real queda
pendiente de una sesión con PySide6 disponible).
"""

import time
import resource
from dataclasses import dataclass, field

from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider, DEFAULT_BLOCK_FRAMES,
)
from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import AtomicFinalizer


@dataclass
class ExportSessionReport:
    ok: bool = False
    error: str = ""
    frames_in: int = 0
    frames_out: int = 0
    sha256: str = ""
    checksum_path: str = ""
    rss_start_kb: int = 0
    rss_peak_kb: int = 0
    rss_end_kb: int = 0
    segment_count: int = 0
    total_frames_expected: int = 0

    # ── GAP-051 (§4, FASE 1) — campos del contrato `ExportResult` ──────
    # Aditivos: ningún campo de arriba cambió de nombre ni de
    # significado, así que código existente que solo lea los campos
    # originales no ve ningún cambio.
    exception: object = None  # LoritoError | None — ver backend/errors
    output_path: str = ""
    duration_seconds: float = 0.0
    status: str = "ABORTED"   # "SUCCESS" | "ABORTED" — ver docstring de run()
    checksum_status: str = "not_computed"  # "verified" | "not_computed"
    segments_read: int = 0
    segments_failed: int = 0

    @property
    def frames_expected(self) -> int:
        """Alias de `total_frames_expected` — mismo valor, nombre
        exacto del contrato §4 (`ExportResult.frames_expected`)."""
        return self.total_frames_expected

    @property
    def frames_read(self) -> int:
        """Alias de `frames_in` — nombre exacto del contrato §4."""
        return self.frames_in

    @property
    def frames_written(self) -> int:
        """Alias de `frames_out` — nombre exacto del contrato §4."""
        return self.frames_out


def _rss_kb() -> int:
    # ru_maxrss: KB en Linux, bytes en macOS — este proyecto corre en Linux
    # (mismo supuesto que el resto de telemetría de memoria del proyecto).
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss


class ExportSession:
    """
    Uso:
        session = ExportSession(segment_paths, encoder_cls=WavEncoder,
                                 final_path="captura.wav",
                                 encoder_kwargs={"subtype": "PCM_24"})
        report = session.run()
    """

    def __init__(self, segment_paths, encoder_cls, final_path: str,
                 encoder_kwargs: dict | None = None,
                 block_frames: int = DEFAULT_BLOCK_FRAMES,
                 block_transform=None,
                 expected_output_frames: int | None = None):
        self.segment_paths = list(segment_paths)
        self.encoder_cls = encoder_cls
        self.final_path = final_path
        self.encoder_kwargs = dict(encoder_kwargs or {})
        self.block_frames = block_frames
        # Fase 1 (GAP-028) — transform opcional aplicado a cada `Block`
        # ANTES de codificarlo (p. ej. ganancia escalar de normalización
        # de la Categoría A de GAP-027). `None` (por defecto) preserva
        # exactamente el comportamiento anterior — sin cambio de
        # comportamiento para quien no lo use.
        self.block_transform = block_transform
        # GAP-065 (FASE 3, hueco (a)) — override explícito del conteo de
        # frames de SALIDA esperado, para cuando `block_transform` cambia
        # el conteo de frames respecto a la entrada (p. ej.
        # `StreamingSpeedResampleTransform`, ver
        # `lorito_export_resample_transform.py`). `None` (por defecto)
        # preserva EXACTAMENTE el comportamiento anterior — se sigue
        # usando `provider.total_frames` (conteo de ENTRADA), correcto
        # para cualquier `block_transform` que no altere el conteo de
        # frames (p. ej. la ganancia escalar de GAP-028) o cuando no hay
        # `block_transform` en absoluto. Solo un `block_transform` que
        # cambie el conteo de frames necesita pasar este parámetro.
        self.expected_output_frames = expected_output_frames

    def _segments_read_and_failed(self, exc) -> tuple[int, int]:
        """Deriva (segments_read, segments_failed) del resultado de
        esta sesión (§4).

        Criterio (documentado en GAP-051 — no hay forma de mejorar
        esta granularidad sin cambiar `Block`/`SegmentProvider` para
        llevar un índice de segmento por bloque, fuera de alcance de
        esta fase):

          · Sin excepción → todos los segmentos se leyeron.
          · Excepción con `.path` que identifica un segmento concreto
            (`SegmentReadError`/`FormatMismatchError`) → los segmentos
            ANTERIORES a él en la lista ya se leyeron completos (el
            proveedor/iterador procesan en orden estricto, §21);
            exactamente 1 falló; los POSTERIORES nunca se alcanzaron
            (no cuentan como leídos ni como fallidos — la exportación
            ya abortó).
          · Cualquier otra excepción (frame accounting, finalización)
            ocurre DESPUÉS de que el iterador de bloques se agotó por
            completo sin lanzar — es decir, con todos los segmentos ya
            leídos; el problema está en la etapa de codificación o
            verificación, no en el origen.
        """
        if exc is None:
            return len(self.segment_paths), 0
        path = getattr(exc, "path", None)
        if path is not None and path in self.segment_paths:
            return self.segment_paths.index(path), 1
        return len(self.segment_paths), 0

    def run(self) -> ExportSessionReport:
        """
        Ejecuta la sesión de exportación streaming completa (§20).

        `report.status` (§4, GAP-051): por diseño (P0.4 — nunca
        transformar corrupción en un resultado disfrazado de éxito),
        una `ExportSession` solo tiene dos desenlaces posibles:
        "SUCCESS" (equivalente a `report.ok is True`) o "ABORTED" —
        nunca un tercer estado "parcial"/"degradado" a este nivel (la
        clasificación DEGRADED/INVALID de una sesión completa es
        responsabilidad de `backend/archival/classify_session()`, un
        contrato distinto — §9 — que opera sobre la CAPTURA, no sobre
        esta única exportación).
        """
        report = ExportSessionReport()
        report.rss_start_kb = _rss_kb()
        report.segment_count = len(self.segment_paths)
        report.output_path = self.final_path
        _t0 = time.monotonic()

        try:
            provider = SegmentProvider(self.segment_paths)
        except Exception as e:
            report.error = str(e)
            report.exception = e
            report.segments_read, report.segments_failed = (
                self._segments_read_and_failed(e))
            report.rss_end_kb = _rss_kb()
            report.duration_seconds = time.monotonic() - _t0
            return report

        # GAP-065: `expected_output_frames` (cuando se pasa) es el
        # conteo de frames de SALIDA tras aplicar `block_transform` —
        # el valor correcto para el chequeo estricto de §28 más abajo.
        # Por defecto (`None`), sin cambio de comportamiento: se usa el
        # conteo de ENTRADA como siempre.
        _frames_expected = (
            self.expected_output_frames if self.expected_output_frames is not None
            else provider.total_frames)
        report.total_frames_expected = _frames_expected

        kwargs = dict(self.encoder_kwargs)
        kwargs.setdefault("total_frames_hint", _frames_expected)

        finalizer = AtomicFinalizer(
            encoder_cls=self.encoder_cls,
            fmt=provider.fmt,
            final_path=self.final_path,
            encoder_kwargs=kwargs,
        )

        peak = report.rss_start_kb

        def _blocks_with_telemetry():
            nonlocal peak
            for blk in provider.iter_blocks(self.block_frames):
                if self.block_transform is not None:
                    blk = self.block_transform(blk)
                cur = _rss_kb()
                if cur > peak:
                    peak = cur
                yield blk

        result = finalizer.run(_blocks_with_telemetry(),
                                total_frames_expected=_frames_expected)

        report.ok = result["ok"]
        report.error = result["error"]
        report.frames_in = result["frames_in"]
        report.frames_out = result["frames_out"]
        report.sha256 = result["sha256"]
        report.checksum_path = result["checksum_path"]
        report.exception = result.get("exception")
        report.rss_peak_kb = max(peak, _rss_kb())
        report.rss_end_kb = _rss_kb()
        report.duration_seconds = time.monotonic() - _t0
        report.status = "SUCCESS" if report.ok else "ABORTED"
        report.checksum_status = "verified" if (report.ok and report.sha256) else "not_computed"
        report.segments_read, report.segments_failed = (
            self._segments_read_and_failed(report.exception))
        return report
