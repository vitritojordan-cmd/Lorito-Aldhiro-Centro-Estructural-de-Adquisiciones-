from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Encoder WAV/RF64 streaming, bit-exacto, con soporte para sesiones mayores a 4GB.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_wav_encoder.py — encoder WAV/PCM streaming real (§17-§19, §23,
§25, FASE 7/8), sin depender de `soundfile` (que el resto del proyecto
sí usa, pero que este sandbox no puede instalar — ver GAP-003 §5).

Escribe el header RIFF (o RF64, ver más abajo) con tamaños en 0/
sentinela al abrir, escribe bloques directamente al descriptor de
archivo conforme llegan (memoria = O(block_frames), nunca O(duración
total)), y en `finalize()` vuelve a posicionar el cursor para corregir
los campos de tamaño — patrón estándar de escritor WAV streaming,
nunca materializa el archivo completo en RAM.

**RF64 (Fase 8, GAP-033)**: el RIFF WAV clásico usa campos de tamaño
de 32 bits (~4 GB). `ExportSession` SIEMPRE conoce `total_frames_hint`
de antemano (lo calcula `SegmentProvider` sumando los headers de los
segmentos antes de escribir nada) — por eso `WavEncoder.open()` puede
decidir CORRECTAMENTE, antes de escribir el primer byte, si el archivo
resultante va a superar el límite seguro de RIFF de 32 bits, y en ese
caso escribe un header RF64 (EBU Tech 3306 / BWF) desde el principio,
en vez de tener que "mutar" un RIFF ya escrito a mitad de camino (algo
mucho más frágil). El formato RF64 mantiene los chunks 'RIFF'→'RF64' y
'data' con sus campos de tamaño de 32 bits puestos a `0xFFFFFFFF`
(sentinela: "ver el chunk ds64 real") y añade un chunk 'ds64'
(tamaños de 64 bits reales) inmediatamente después de 'WAVE', antes de
'fmt '. `Encoder`/`ExportSession`/`AtomicFinalizer` no necesitan saber
nada de esto — la elección RIFF/RF64 es enteramente interna a
`WavEncoder`.
"""

import os
import struct

from lorito_aldhiro.backend.export_streaming.lorito_encoder_base import Encoder
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block, ExportAbortError

WAV_SAFE_LIMIT_BYTES = 3_900_000_000   # mismo margen que lorito_exporters.py
_DS64_CHUNK_SIZE = 28   # riffSize(8) + dataSize(8) + sampleCount(8) + tableLength(4)


def _sample_width_for_subtype(subtype: str) -> int:
    return {"PCM_16": 2, "PCM_24": 3, "PCM_32": 4}.get(subtype, 3)


class WavEncoder(Encoder):
    codec_name = "WAV"

    def __init__(self, fmt, out_path, subtype: str = "PCM_24",
                 total_frames_hint: int = 0, **options):
        super().__init__(fmt, out_path, **options)
        self.subtype = subtype
        self.sample_width = _sample_width_for_subtype(subtype)
        self.total_frames_hint = total_frames_hint
        self._fh = None
        self._data_bytes_written = 0
        self._rf64 = False
        self._ds64_riffsize_pos = 0   # posición del campo riffSize dentro de ds64

    def open(self) -> None:
        self._rf64 = False
        if self.total_frames_hint:
            estimated = (self.total_frames_hint * self.fmt.channels
                         * self.sample_width)
            if estimated > WAV_SAFE_LIMIT_BYTES:
                self._rf64 = True
        self._fh = open(self.out_path, "wb")
        if self._rf64:
            self._write_placeholder_header_rf64()
        else:
            self._write_placeholder_header()

    def _write_placeholder_header(self) -> None:
        ch = self.fmt.channels
        rate = self.fmt.rate
        bits = self.sample_width * 8
        block_align = ch * self.sample_width
        byte_rate = rate * block_align
        # RIFF header con tamaños en 0 — se corrigen en finalize()
        self._fh.write(b"RIFF")
        self._fh.write(struct.pack("<I", 0))
        self._fh.write(b"WAVE")
        self._fh.write(b"fmt ")
        self._fh.write(struct.pack("<I", 16))
        self._fh.write(struct.pack("<HHIIHH", 1, ch, rate, byte_rate,
                                    block_align, bits))
        self._fh.write(b"data")
        self._fh.write(struct.pack("<I", 0))
        self._data_start = self._fh.tell()

    def _write_placeholder_header_rf64(self) -> None:
        """RF64/BWF (EBU Tech 3306) — ver docstring de cabecera. Los
        campos de tamaño de 32 bits de 'RF64' y 'data' se escriben
        como `0xFFFFFFFF` (sentinela fijo, NUNCA se corrigen en
        finalize()); los tamaños reales de 64 bits viven en el chunk
        'ds64', que sí se corrige en finalize()."""
        ch = self.fmt.channels
        rate = self.fmt.rate
        bits = self.sample_width * 8
        block_align = ch * self.sample_width
        byte_rate = rate * block_align

        self._fh.write(b"RF64")
        self._fh.write(struct.pack("<I", 0xFFFFFFFF))  # sentinela — ver ds64
        self._fh.write(b"WAVE")

        self._fh.write(b"ds64")
        self._fh.write(struct.pack("<I", _DS64_CHUNK_SIZE))
        self._ds64_riffsize_pos = self._fh.tell()
        self._fh.write(struct.pack("<Q", 0))   # riffSize (64 bits) — placeholder
        self._fh.write(struct.pack("<Q", 0))   # dataSize (64 bits) — placeholder
        self._fh.write(struct.pack("<Q", 0))   # sampleCount (64 bits) — placeholder
        self._fh.write(struct.pack("<I", 0))   # tableLength = 0 (sin chunks extra >4GB)

        self._fh.write(b"fmt ")
        self._fh.write(struct.pack("<I", 16))
        self._fh.write(struct.pack("<HHIIHH", 1, ch, rate, byte_rate,
                                    block_align, bits))
        self._fh.write(b"data")
        self._fh.write(struct.pack("<I", 0xFFFFFFFF))  # sentinela — ver ds64.dataSize
        self._data_start = self._fh.tell()

    def write(self, block: Block) -> None:
        if self._fh is None:
            raise ExportAbortError("WavEncoder.write() llamado sin open()")
        raw = self._float32_to_pcm_bytes(block.data)
        self._fh.write(raw)
        self._data_bytes_written += len(raw)

    def _float32_to_pcm_bytes(self, data) -> bytes:
        import numpy as np
        clipped = np.clip(data, -1.0, 1.0)
        if self.sample_width == 2:
            # Escala SIMÉTRICA a la de decodificación (`SegmentProvider.
            # _pcm_bytes_to_float32`, que divide por 32768.0) — round-trip
            # bit-exacto para audio sin DSP. `np.round` (no `.astype`
            # directo, que trunca hacia cero) + clip final al rango int16
            # válido para el único caso borde (+1.0 exacto → 32768 se
            # recorta a 32767, el mismo tope ya usado por el decodificador
            # como máximo positivo representable). Ver GAP-026.
            pcm = np.clip(np.round(clipped * 32768.0), -32768, 32767).astype("<i2")
            return pcm.tobytes()
        elif self.sample_width == 3:
            pcm32 = np.clip(np.round(clipped * 8388608.0), -8388608, 8388607).astype(np.int32)
            u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
            return np.ascontiguousarray(u8[:, 0:3]).tobytes()
        elif self.sample_width == 4:
            pcm = np.clip(np.round(clipped * 2147483648.0),
                          -2147483648, 2147483647).astype("<i4")
            return pcm.tobytes()
        else:
            raise ValueError(f"sample_width no soportado: {self.sample_width}")

    def flush(self) -> None:
        if self._fh:
            self._fh.flush()
            os.fsync(self._fh.fileno())

    def finalize(self) -> None:
        if self._fh is None:
            return
        if self._rf64:
            self._finalize_rf64()
        else:
            self._finalize_riff()
        self._fh.flush()
        os.fsync(self._fh.fileno())
        self._fh.close()
        self._fh = None

    def _finalize_riff(self) -> None:
        # Corregir tamaños del header ahora que se conoce el total real
        riff_size = 4 + (8 + 16) + (8 + self._data_bytes_written)
        self._fh.seek(4)
        self._fh.write(struct.pack("<I", riff_size))
        self._fh.seek(self._data_start - 4)
        self._fh.write(struct.pack("<I", self._data_bytes_written))

    def _finalize_rf64(self) -> None:
        # Los campos de 32 bits de 'RF64' y 'data' NUNCA se tocan (se
        # quedan en 0xFFFFFFFF, el sentinela que le dice a un lector
        # RF64 que mire el chunk ds64) — solo se corrigen los 3 campos
        # de 64 bits reales dentro de ds64.
        block_align = self.fmt.channels * self.sample_width
        total_frames = self._data_bytes_written // block_align if block_align else 0
        file_size = self._data_start + self._data_bytes_written
        riff_size_64 = file_size - 8   # mismo significado que el campo RIFF clásico

        self._fh.seek(self._ds64_riffsize_pos)
        self._fh.write(struct.pack("<Q", riff_size_64))
        self._fh.write(struct.pack("<Q", self._data_bytes_written))
        self._fh.write(struct.pack("<Q", total_frames))
        # tableLength ya es 0 desde open() — no hay chunks >4GB extra.

    def validate(self) -> dict:
        result = {"ok": False, "path": self.out_path, "error": "",
                   "actual_frames": 0, "actual_rate": 0}
        try:
            with open(self.out_path, "rb") as f:
                magic = f.read(4)
            if magic == b"RF64":
                return self._validate_rf64(result)
            import wave
            with wave.open(self.out_path, "rb") as wf:
                result["actual_frames"] = wf.getnframes()
                result["actual_rate"] = wf.getframerate()
                result["actual_channels"] = wf.getnchannels()
            if result["actual_rate"] != self.fmt.rate:
                result["error"] = "samplerate incorrecto en archivo final"
                return result
            if result["actual_channels"] != self.fmt.channels:
                result["error"] = "canales incorrectos en archivo final"
                return result
            result["ok"] = True
        except Exception as e:
            result["error"] = str(e)
        return result

    def _validate_rf64(self, result: dict) -> dict:
        """El módulo estándar `wave` de Python no entiende RF64 (falla
        al no reconocer 'RIFF' como magic) — parser mínimo dedicado,
        suficiente para verificar que el archivo es coherente, sin
        depender de `soundfile` (no instalable en este sandbox)."""
        try:
            with open(self.out_path, "rb") as f:
                magic = f.read(4)
                if magic != b"RF64":
                    result["error"] = "magic RF64 esperado, no encontrado"
                    return result
                f.read(4)  # sentinela 0xFFFFFFFF del tamaño RIFF — se ignora
                wave_id = f.read(4)
                if wave_id != b"WAVE":
                    result["error"] = "falta 'WAVE' tras 'RF64'"
                    return result

                ds64_id = f.read(4)
                if ds64_id != b"ds64":
                    result["error"] = "falta chunk 'ds64' (obligatorio en RF64)"
                    return result
                ds64_size = struct.unpack("<I", f.read(4))[0]
                riff_size_64, data_size_64, sample_count_64 = struct.unpack(
                    "<QQQ", f.read(24))
                table_length = struct.unpack("<I", f.read(4))[0]
                # Saltar entradas de la tabla de chunks >4GB, si las hay
                f.read(table_length * 12)
                # Saltar cualquier padding si ds64_size > 28 (no debería
                # ocurrir con table_length=0, pero es robusto ante ello)
                consumed = 28 + table_length * 12
                if ds64_size > consumed:
                    f.read(ds64_size - consumed)

                fmt_id = f.read(4)
                if fmt_id != b"fmt ":
                    result["error"] = "falta chunk 'fmt ' tras 'ds64'"
                    return result
                fmt_size = struct.unpack("<I", f.read(4))[0]
                (_audio_fmt, channels, rate, _byte_rate,
                 block_align, _bits) = struct.unpack("<HHIIHH", f.read(16))
                if fmt_size > 16:
                    f.read(fmt_size - 16)

                data_id = f.read(4)
                if data_id != b"data":
                    result["error"] = "falta chunk 'data' tras 'fmt '"
                    return result
                f.read(4)  # sentinela 0xFFFFFFFF del tamaño de 'data' — se ignora

            actual_frames = data_size_64 // block_align if block_align else 0
            result["actual_frames"] = actual_frames
            result["actual_rate"] = rate
            result["actual_channels"] = channels
            result["rf64"] = True
            result["ds64_sample_count"] = sample_count_64
            if rate != self.fmt.rate:
                result["error"] = "samplerate incorrecto en archivo final (RF64)"
                return result
            if channels != self.fmt.channels:
                result["error"] = "canales incorrectos en archivo final (RF64)"
                return result
            if sample_count_64 and sample_count_64 != actual_frames:
                result["error"] = ("ds64.sampleCount no coincide con "
                                  "dataSize/block_align")
                return result
            result["ok"] = True
        except Exception as e:
            result["error"] = str(e)
        return result
