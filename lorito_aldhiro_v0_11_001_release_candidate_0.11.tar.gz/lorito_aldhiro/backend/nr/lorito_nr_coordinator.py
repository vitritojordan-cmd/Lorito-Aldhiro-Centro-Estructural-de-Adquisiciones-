from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Orquestador de toda la cadena DSP en tiempo real — un solo punto de entrada por bloque.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_coordinator.py — coordinador de selección única de reducción
de ruido (§GAP-011), mismo patrón `_active` de exclusión estructural ya
usado en el proyecto hermano (VitriCarola/PARMOSOC: un único perfil
activo a la vez, nunca cascada).

HX Pro y ALC son independientes entre sí y del selector NR (pueden
convivir con un perfil NR activo y entre ellos — no son parte de la
familia de doble/único extremo, son técnicas de grabación/nivelación
distintas), tal como especificó el usuario (menú OPTAPE separado del
menú NR).
"""

from typing import Optional

import numpy as np

from lorito_aldhiro.backend.nr.lorito_nr_profiles import NR_PROFILE_CLASSES, NRProfile
from lorito_aldhiro.backend.nr.lorito_nr_hxpro import HxProProfile
from lorito_aldhiro.backend.nr.lorito_nr_alc import AlcProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_mpx import MpxProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_eq_bias import TapeEqBiasProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_focus import FocusProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite
from lorito_aldhiro.backend.dsp.lorito_dsp_cristhi_cosh import CristhiCoshProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_antipestal_lola_grillo import AntipestalLolaProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import VersionOTronProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida import LuchaEnloquecidaProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import MuscleEqSamirProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import get_preset_bands


class NRCoordinator:
    def __init__(self, sample_rate: int = 48000, channels: int = 2, mode: str = "DECODE"):
        self.sample_rate = sample_rate
        self.channels = channels
        self.mode = mode
        self._active_token: Optional[str] = None
        self._active_profile: Optional[NRProfile] = None
        self._hx_pro: Optional[HxProProfile] = None
        self._alc: Optional[AlcProfile] = None
        # ── DSP nuevos de esta sesión (pedido explícito del usuario) —
        # mismo patrón de independencia estructural que HX Pro/ALC.
        self._mpx: Optional[MpxProfile] = None
        self._focus: Optional[FocusProfile] = None
        self._eq_bias: Optional[TapeEqBiasProfile] = None
        self._eq_bias_token: Optional[str] = None
        # ── DSP de PREVI adaptados de CRAC (GAP-039, pedido explícito
        # del usuario) — independiente del resto, vive en OPTAPE.
        self._cristhi_cosh: Optional[CristhiCoshProfile] = None
        self._antipestal: Optional[AntipestalLolaProfile] = None
        self._version_o_tron: Optional[VersionOTronProfile] = None
        self._lucha_enloquecida: Optional[LuchaEnloquecidaProfile] = None
        # ── Muscle Eq Samir (Vitrito) — GAP-043, orden de ingeniería
        # del usuario. Motor de ecualización en caliente, PRIMERO en
        # la cadena (orden §21: "CAPTURE → PRE-PROCESS → MUSCLE EQ
        # SAMIR → OTROS PROCESADORES OPTAPE").
        self._muscle_eq: Optional[MuscleEqSamirProfile] = None
        # ── Fase 10 (DSP_NONFINITE_OUTPUT) — contadores de saneamiento
        # por etapa, expuestos vía `nonfinite_counts` para diagnóstico/
        # auditoría (Fase 17). Nunca decrecen dentro de una sesión.
        self._nonfinite_counts: dict = {
            "input": 0, "eq_bias": 0, "mpx": 0, "nr": 0,
            "hx_pro": 0, "alc": 0, "focus": 0, "cristhi_cosh": 0,
            "antipestal": 0, "version_o_tron": 0, "lucha_enloquecida": 0,
            "muscle_eq": 0,
        }

    # ── Selector NR (exclusión estructural — un único perfil activo) ──
    def select(self, token: Optional[str], **profile_kwargs) -> None:
        """token en NR_PROFILE_CLASSES o None para apagar. `profile_kwargs`
        se pasa al constructor del perfil (p. ej. `dbx_type='224'` para
        DBX — ver GAP-012)."""
        if token == self._active_token and not profile_kwargs:
            return
        self._active_token = token
        if token is None:
            self._active_profile = None
            return
        cls = NR_PROFILE_CLASSES.get(token)
        if cls is None:
            self._active_profile = None
            self._active_token = None
            return
        self._active_profile = cls(mode=self.mode, sample_rate=self.sample_rate,
                                   channels=self.channels, **profile_kwargs)

    @property
    def active_token(self) -> Optional[str]:
        return self._active_token

    # ── HX Pro / ALC — independientes, pueden convivir con el NR y entre sí ──
    def set_hx_pro(self, active: bool) -> None:
        self._hx_pro = HxProProfile(mode="ACTIVE", sample_rate=self.sample_rate,
                                    channels=self.channels) if active else None

    def set_alc(self, active: bool) -> None:
        self._alc = AlcProfile(mode="ACTIVE", sample_rate=self.sample_rate,
                               channels=self.channels) if active else None

    # ── MPX / FOCUS — mismo patrón que HX Pro/ALC (independientes,
    # viven en el menú OPTAPE junto a HX Pro/ALC, pedido explícito del
    # usuario) ─────────────────────────────────────────────────────────
    def set_mpx(self, active: bool) -> None:
        self._mpx = MpxProfile(mode="ACTIVE", sample_rate=self.sample_rate,
                               channels=self.channels) if active else None

    def set_focus(self, active: bool) -> None:
        self._focus = FocusProfile(mode="ACTIVE", sample_rate=self.sample_rate,
                                   channels=self.channels) if active else None

    # ── Florecedor de Cristhi Cosh (PREVI) — GAP-039, adaptado de
    # CRAC. Independiente del resto, mismo patrón que MPX/FOCUS.
    def set_cristhi_cosh(self, active: bool, **params) -> None:
        self._cristhi_cosh = CristhiCoshProfile(
            mode="ACTIVE", sample_rate=self.sample_rate,
            channels=self.channels, **params) if active else None

    @property
    def cristhi_cosh_active(self) -> bool:
        return self._cristhi_cosh is not None

    # ── Antipestal de Lola Grillo (PREVI) — GAP-041, adaptado de CRAC.
    def set_antipestal(self, mode: str) -> None:
        """`mode` en {"BYPASS", "STRIKER", "KARI"}."""
        mode = (mode or "BYPASS").upper().strip()
        self._antipestal = AntipestalLolaProfile(
            mode=mode, sample_rate=self.sample_rate,
            channels=self.channels) if mode != "BYPASS" else None

    @property
    def antipestal_active(self) -> bool:
        return self._antipestal is not None

    @property
    def previ_dsp_active(self) -> bool:
        """Agregado de TODOS los DSP de PREVI activos — para la
        leyenda compartida "PREVI DSP" (GAP-040/041/042)."""
        return self.cristhi_cosh_active or self.antipestal_active or self.lucha_enloquecida_active

    # ── Lucha Enloquecida (PREVI) — GAP-042, adaptado de CRAC. 20
    # sub-perfiles A-T, selección única.
    def set_lucha_enloquecida(self, mode: str) -> None:
        """`mode` en {"BYPASS", "A", "B", ..., "T"}."""
        mode = (mode or "BYPASS").upper().strip()
        self._lucha_enloquecida = LuchaEnloquecidaProfile(
            mode=mode, sample_rate=self.sample_rate,
            channels=self.channels) if mode != "BYPASS" else None

    @property
    def lucha_enloquecida_active(self) -> bool:
        return self._lucha_enloquecida is not None

    # ── Muscle Eq Samir (Vitrito) — GAP-043 ──────────────────────────
    def set_muscle_eq_active(self, active: bool, preset_id: str = None) -> None:
        """Activa/desactiva sin reconstruir el motor (orden §16 —
        "HECHO" nunca resetea; §17 "RESTABLECER" sí, ver
        `reset_muscle_eq()`). Si el motor no existe todavía, se crea
        (con FLAT o el preset pedido); si ya existe, solo cambia
        `active` — nunca pierde bandas/estado al activar/desactivar."""
        if self._muscle_eq is None:
            bands = get_preset_bands(preset_id) if preset_id else []
            self._muscle_eq = MuscleEqSamirProfile(
                mode="ACTIVE" if active else "BYPASS",
                sample_rate=self.sample_rate, channels=self.channels,
                preset_id=preset_id or "FLAT", bands=None)
            if bands:
                self._muscle_eq.load_preset(preset_id, bands)
        else:
            self._muscle_eq.set_active(active)

    def set_muscle_eq_preset(self, preset_id: str) -> None:
        if self._muscle_eq is None:
            self.set_muscle_eq_active(True, preset_id=preset_id)
            return
        self._muscle_eq.load_preset(preset_id, get_preset_bands(preset_id))

    def set_muscle_eq_band(self, index: int, **kwargs) -> None:
        if self._muscle_eq is not None:
            self._muscle_eq.set_band(index, **kwargs)

    def reset_muscle_eq(self) -> None:
        """RESTABLECER (orden §17) — desactiva, vuelve a FLAT, retira
        el indicador."""
        if self._muscle_eq is not None:
            self._muscle_eq.reset_to_flat()

    @property
    def muscle_eq_active(self) -> bool:
        return self._muscle_eq is not None and self._muscle_eq.active

    # ── Versión O Tron (Funciones Especiales) — GAP-041, de CRAC.
    def set_version_o_tron(self, mode: str) -> None:
        """`mode` en {"BYPASS", "AA_MO", "BARRIL", "SIFON"}."""
        mode = (mode or "BYPASS").upper().strip()
        self._version_o_tron = VersionOTronProfile(
            mode=mode, sample_rate=self.sample_rate,
            channels=self.channels) if mode != "BYPASS" else None

    @property
    def version_o_tron_active(self) -> bool:
        return self._version_o_tron is not None

    @property
    def fnesp_dsp_active(self) -> bool:
        """Agregado de todos los DSP de Funciones Especiales activos —
        para la leyenda compartida "FNESP DSP" (GAP-040/041)."""
        return self.version_o_tron_active

    # ── EQ/BIAS — selección única entre NORMAL/CrO2/FeCr/Metal, mismo
    # patrón de exclusión estructural que el selector NR (menú propio
    # "EQ/BIAS", pedido explícito del usuario) ──────────────────────────
    def select_eq_bias(self, token: Optional[str]) -> None:
        self._eq_bias_token = token
        self._eq_bias = TapeEqBiasProfile(token, sample_rate=self.sample_rate,
                                          channels=self.channels) if token else None

    @property
    def eq_bias_active_token(self) -> Optional[str]:
        return self._eq_bias_token

    @property
    def mpx_active(self) -> bool:
        return self._mpx is not None

    @property
    def focus_active(self) -> bool:
        return self._focus is not None

    @property
    def hx_pro_active(self) -> bool:
        return self._hx_pro is not None

    @property
    def alc_active(self) -> bool:
        return self._alc is not None

    def reconfigure(self, sample_rate: int, channels: int) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        if self._active_profile is not None:
            self._active_profile.reconfigure(self.mode, sample_rate, channels)
        if self._hx_pro is not None:
            self._hx_pro.reconfigure("ACTIVE", sample_rate, channels)
        if self._alc is not None:
            self._alc.reconfigure("ACTIVE", sample_rate, channels)
        if self._mpx is not None:
            self._mpx.reconfigure("ACTIVE", sample_rate, channels)
        if self._focus is not None:
            self._focus.reconfigure("ACTIVE", sample_rate, channels)
        if self._eq_bias is not None:
            self._eq_bias.reconfigure(self._eq_bias_token, sample_rate, channels)

    def reset(self) -> None:
        if self._active_profile is not None:
            self._active_profile.reset()
        if self._hx_pro is not None:
            self._hx_pro.reset()
        if self._alc is not None:
            self._alc.reset()
        if self._mpx is not None:
            self._mpx.reset()
        if self._focus is not None:
            self._focus.reset()
        if self._eq_bias is not None:
            self._eq_bias.reset()
        if self._cristhi_cosh is not None:
            self._cristhi_cosh.reset()
        if self._antipestal is not None:
            self._antipestal.reset()
        if self._version_o_tron is not None:
            self._version_o_tron.reset()
        if self._lucha_enloquecida is not None:
            self._lucha_enloquecida.reset()
        if self._muscle_eq is not None:
            self._muscle_eq.reset()

    @property
    def nonfinite_counts(self) -> dict:
        """Contadores de saneamiento DSP_NONFINITE_OUTPUT por etapa desde
        que se creó este coordinador (Fase 10). Copia de solo lectura."""
        return dict(self._nonfinite_counts)

    def _sanitize_stage(self, label: str, out: np.ndarray, stage) -> np.ndarray:
        """Aplica el contrato DSP_NONFINITE_OUTPUT a la salida de una
        etapa. Si se encontró NaN/Inf: sanea el bloque actual Y resetea
        el estado interno de la etapa (`stage.reset()`) para que un NaN
        puntual no envenene de forma permanente su recursión IIR/EMA —
        ver docstring de `lorito_dsp_finite_guard.py` para el defecto
        real que esto corrige."""
        clean, n_bad = sanitize_finite(out)
        if n_bad:
            self._nonfinite_counts[label] += n_bad
            stage.reset()
        return clean

    # ── Cadena de proceso — orden de una restauración real: primero el
    # "voicing"/headroom del tipo de cinta (EQ/BIAS, coloración de
    # grabación), luego el filtro de piloto FM (MPX, limpia antes de
    # cualquier decodificación), luego el NR seleccionado → HX Pro →
    # ALC → por último FOCUS (azimuth), que en un deck real ocurre en
    # la propia cabeza de reproducción, después de todo lo demás.
    #
    # Fase 10 (DSP_NONFINITE_OUTPUT): cada etapa pasa por
    # `_sanitize_stage` — camino sano (siempre, en la inmensa mayoría
    # de los bloques) cuesta un único `np.isfinite(...).all()` extra
    # por etapa, sin copiar memoria. `chunk` de entrada también se
    # sanea (finite-in) para no alimentar la primera etapa con un
    # glitch que ya venga corrupto desde el motor de captura.
    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        out, n_bad_in = sanitize_finite(chunk)
        if n_bad_in:
            self._nonfinite_counts["input"] += n_bad_in
        # Muscle Eq Samir (Vitrito, GAP-043) — PRIMERO en la cadena,
        # antes que cualquier otro procesador de OPTAPE (orden §21:
        # "CAPTURE → PRE-PROCESS → MUSCLE EQ SAMIR → OTROS
        # PROCESADORES OPTAPE"). Corrige/compensa/colorea la señal
        # entrante antes de que el resto de la cadena (PREVI, EQ/BIAS,
        # MPX, NR) la procese.
        if self._muscle_eq is not None:
            out = self._sanitize_stage(
                "muscle_eq", self._muscle_eq.process_chunk(out), self._muscle_eq)
        # Florecedor de Cristhi Cosh (PREVI, GAP-039) — restaura
        # artefactos de distorsión de Bias del fonograma CRUDO, antes
        # de cualquier coloración/filtrado posterior (EQ/BIAS, MPX).
        if self._cristhi_cosh is not None:
            out = self._sanitize_stage(
                "cristhi_cosh", self._cristhi_cosh.process_chunk(out), self._cristhi_cosh)
        if self._antipestal is not None:
            out = self._sanitize_stage(
                "antipestal", self._antipestal.process_chunk(out), self._antipestal)
        if self._lucha_enloquecida is not None:
            out = self._sanitize_stage(
                "lucha_enloquecida", self._lucha_enloquecida.process_chunk(out),
                self._lucha_enloquecida)
        if self._eq_bias is not None:
            out = self._sanitize_stage(
                "eq_bias", self._eq_bias.process_chunk(out), self._eq_bias)
        if self._mpx is not None:
            out = self._sanitize_stage(
                "mpx", self._mpx.process_chunk(out), self._mpx)
        if self._active_profile is not None:
            out = self._sanitize_stage(
                "nr", self._active_profile.process_chunk(out), self._active_profile)
        if self._hx_pro is not None:
            out = self._sanitize_stage(
                "hx_pro", self._hx_pro.process_chunk(out), self._hx_pro)
        if self._alc is not None:
            out = self._sanitize_stage(
                "alc", self._alc.process_chunk(out), self._alc)
        if self._focus is not None:
            out = self._sanitize_stage(
                "focus", self._focus.process_chunk(out), self._focus)
        # Versión O Tron (Funciones Especiales, GAP-041) — coloración
        # de fuente de reproducción, última etapa (simula el "color"
        # final tal como llegaría a un oyente a través de ese medio).
        if self._version_o_tron is not None:
            out = self._sanitize_stage(
                "version_o_tron", self._version_o_tron.process_chunk(out), self._version_o_tron)
        return out
