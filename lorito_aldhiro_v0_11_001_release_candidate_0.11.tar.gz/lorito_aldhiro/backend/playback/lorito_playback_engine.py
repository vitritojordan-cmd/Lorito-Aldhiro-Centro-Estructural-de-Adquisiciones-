from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de reproducción en tiempo real — velocidad variable, scrub, resampleo.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import threading
import time
import queue
import logging
import gc
from collections import deque
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.capture.lorito_forensics import _frn_check_double_flush, _frn_check_snap_jump, _frn_emit, _frn_short_stack, _frn_state
from lorito_aldhiro.backend.dsp.lorito_dsp_resample_continuous import resample_stateful_continuous



# ─────────────────────────────────────────────────────────────────────────────
#  PLAYBACK ENGINE v1.0  (sustituye a StreamingPlayer v0.20.x)
#  Reconstrucción forense — motor separado integrado en el monolito
# ─────────────────────────────────────────────────────────────────────────────
# Todos los bugs de pops/saltos/cracs de las etapas de scrub, morphing y
# cambio de velocidad han sido corregidos en este motor.  Ver docstring de
# PlaybackEngine para el historial forense completo (FIX-1..FIX-G4 + BUG-C).
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES DEL MOTOR
# ─────────────────────────────────────────────────────────────────────────────

# Chunking / pipeline
PE_CHUNK_FRAMES   = 4_096   # ~85ms @ 48kHz — frames por chunk de prefetch
PE_RING_CHUNKS    = 4       # slots en chunk_q → ~341ms de colchón mínimo
PE_BLOCKSIZE      = 512     # frames por callback OutputStream (~10ms @ 48kHz)
PE_SPEED_WINDOW   = 32_768  # ventana de resampleo cúbico (RAM constante)
PE_PRELOAD_MIN    = 2       # chunks mínimos en deque antes de abrir OutputStream
PE_ENQUEUE_TIMEOUT= 0.010   # s — timeout put() en _enqueue_data

# Crossfade en flush
# FIX-XFADE-EP  (v0.21.01): lineal → equal-power (cos/sin).
# FIX-XFADE-512 (v0.21.02): 256→512 frames (~10.7ms @ 48kHz).
#   512 frames cubre exactamente 1 blocksize (PE_BLOCKSIZE=512) + margen.
#   Garantiza que el crossfade dure más que el período entre callbacks RT,
#   eliminando la posibilidad de que el callback oiga el borde de la ventana.
PE_XFADE_FRAMES   = 512

# Debounce de cambio de velocidad
# FIX-LIVE-DEB (v0.21.02): 30ms → 80ms.
#   Con 30ms el debounce dispara ~33 flushes/s durante drag continuo.
#   Cada flush tiene una ventana de deque-vacío (aunque mínima).
#   80ms → máx ~12 flushes/s, muy por debajo del umbral perceptible.
#   La latencia de respuesta sigue siendo < 1 ciclo prefetch (85ms).
PE_SPEED_DEBOUNCE = 0.030   # s — FIX-DOUBLE-FLUSH (v0.22.13): 5→30ms.
                            # El motor de suavizado puede emitir un FLUSH_SPEED_LIVE
                            # y, al converger ~10ms después, un FLUSH_SPEED_COMMIT
                            # desde el mismo hilo.  Con 5ms el debounce no cubría ese
                            # gap (observado en pop_forensics.jsonl: delta_ms=9.835).
                            # 30ms = PE_LIVE_DEBOUNCE/2 → absorbe el caso sin suprimir
                            # commits legítimos (los cambios discretos reales llegan
                            # separados por cientos de ms tras un release real).
PE_LIVE_DEBOUNCE  = 0.080   # s — FIX-LIVE-DEB v0.21.02: 30→80ms

# Phase cursor
PE_PHASE_RESET    = 0.0     # valor inicial/reset del cursor de fase

# FASE 4/5 (Orden Maestra de Saneamiento, Integracion y Consolidacion,
# S26 -- flag de migracion legado->nuevo con capacidad de rollback):
# GAP-037 midio (con senal sintetica) y GAP-062 confirmo (con audio
# real, Sotalomafer1.mp3 del usuario) una deriva de fase real y
# medible en `_resample_stateful` en cada frontera de chunk de
# prefetch (PE_CHUNK_FRAMES=4096) para cualquier ratio != 1.0 --
# `resample_stateful_continuous` (lorito_dsp_resample_continuous.py)
# la corrige sin ese artefacto (error residual = ruido de punto
# flotante, no deriva progresiva), verificado en ambas sesiones
# contra una referencia Catmull-Rom real en cada frontera de chunk.
# True = comportamiento nuevo (corregido). False = revertir al
# resampleador legado sin tocar mas codigo, si un fallo en produccion
# (con hardware/audio real que este sandbox no puede reproducir)
# aconsejara volver atras mientras se investiga.
USE_CONTINUOUS_RESAMPLE = True

# Underrun alert
PE_UNDERRUN_LIMIT = 5       # underruns RT consecutivos antes de warning

# ─────────────────────────────────────────────────────────────────────────────
#  LOGGER INTERNO
# ─────────────────────────────────────────────────────────────────────────────
_plog = logging.getLogger("aecct2.playback_engine")


# ─────────────────────────────────────────────────────────────────────────────
#  _SpeedState  —  estado de velocidad compartido entre threads
#  Todos los campos son lecturas/escrituras atómicas de Python (GIL).
#  No se usa Lock() en el hot path RT para cero latencia.
# ─────────────────────────────────────────────────────────────────────────────
class _SpeedState:
    """
    Contenedor de estado de velocidad.  Todos los campos son atómicos en CPython
    (escritura de float/bool es una operación indivisible bajo el GIL).

    Separar el estado en un objeto propio permite al _PrefetchWorker leer
    live_ratio/phase_cursor sin acceder al PlaybackEngine completo, reduciendo
    el acoplamiento entre componentes.
    """
    __slots__ = (
        "live_ratio",       # float: ratio aplicado por el prefetch SIN flush
        "commit_ratio",     # float: ratio confirmado por set_speed()
        "phase_cursor",     # float: cursor de fase entre chunks (preservado o reseteado)
        "phase_history",    # np.ndarray|None: ultimas HISTORY_LEN muestras del chunk
                            #   anterior para resample_stateful_continuous (GAP-062).
                            #   DEBE resetearse a None en TODO punto donde phase_cursor
                            #   se resetea a PE_PHASE_RESET -- un phase_cursor=0 con un
                            #   phase_history stale reintroduciria bleed-through entre
                            #   segmentos no contiguos (el mismo defecto que este fix
                            #   corrige, por la puerta trasera).
        "snap_pos",         # float: snapshot de posición en el momento del flush
        "head_pos",         # float: posición de lectura actual del prefetch (actualizada cada ciclo)
                            #   FIX-LIVE-SNAP (v0.21.04): para flushes live, snap_pos debe ser
                            #   head_pos (no src_pos), porque el prefetch ya ha leído ~650ms por
                            #   delante. Reiniciar desde src_pos causa un salto hacia atrás de
                            #   ~650ms en el stream → pop audible. head_pos = continuidad exacta.
        "live_flush_flag",  # bool: True → flush disparado por set_speed_live (preservar fase)
        "last_speed_flush", # float: monotonic del último set_speed() discreto
        "last_live_flush",  # float: monotonic del último set_speed_live() con flush
        "last_head_snap",   # float: head_pos usado como snap en el último flush live
                            #   FIX-SNAP-FROZEN-HEAD (v0.22.12): detectar head_pos estancado.
                            #   Si head_pos - last_head_snap < PE_CHUNK_FRAMES/2, el prefetch
                            #   no avanzó (abs_ratio ≈ 0) → usar src_pos como snap en su lugar.
    )

    def __init__(self, ratio: float = 1.0, start_pos: float = 0.0):
        self.live_ratio       = ratio
        self.commit_ratio     = ratio
        self.phase_cursor     = PE_PHASE_RESET
        self.phase_history    = None
        self.snap_pos         = start_pos
        self.head_pos         = start_pos
        self.live_flush_flag  = False
        self.last_speed_flush = 0.0
        self.last_live_flush  = 0.0
        self.last_head_snap   = 0.0

    def reset(self, ratio: float, start_pos: float):
        """Reseteo limpio al iniciar reproducción."""
        self.live_ratio       = ratio
        self.commit_ratio     = ratio
        self.phase_cursor     = PE_PHASE_RESET
        self.phase_history    = None
        self.snap_pos         = start_pos
        self.head_pos         = start_pos
        self.live_flush_flag  = False
        self.last_speed_flush = 0.0
        self.last_live_flush  = 0.0
        self.last_head_snap   = 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  Resampleador cúbico stateful
# ─────────────────────────────────────────────────────────────────────────────

def _resample_stateful(
        chunk: np.ndarray,
        ratio: float,
        in_cursor: float,
) -> tuple[np.ndarray, float]:
    """
    Resampleo cúbico (Catmull-Rom) con continuidad de fase entre llamadas.

    Parámetros
    ----------
    chunk      : array float32 (n_frames, n_channels) — entrada.
    ratio      : velocidad de reproducción (siempre positivo).
                 >1 = más rápido (output más corto).
                 <1 = más lento  (output más largo).
    in_cursor  : posición fraccional de muestreo al inicio de este chunk.
                 0.0 para el primer chunk tras flush/seek.

    Devuelve
    --------
    (out_chunk, next_cursor)
    out_chunk  : array float32 resampleado.
    next_cursor: in_cursor para el próximo chunk. Guardar en
                 _SpeedState.phase_cursor. Solo resetear a PE_PHASE_RESET
                 en flush discreto (set_speed) o seek.

    Nota sobre la zona neutra (|ratio - 1.0| < 0.0005):
    El cursor avanza linealmente preservando la fracción de fase para que
    la primera llamada con ratio≠1 reanude desde exactamente donde terminó
    el chunk anterior. Sin esta preservación, la transición de ×1.00 a otro
    ratio produce un salto de fase audible (pop).
    """
    if abs(ratio - 1.0) < 0.0005:
        # Zona neutra: sin resampleo, preservar cursor de fase relativo
        next_cursor = float(max(0.0, in_cursor))
        return chunk, next_cursor

    n_in  = len(chunk)
    n_out = max(1, int(round(n_in / ratio)))
    if n_in < 4 or n_out < 1:
        return chunk, in_cursor

    out_parts  = []
    win        = PE_SPEED_WINDOW
    cur_cursor = float(in_cursor)
    out_done   = 0

    while out_done < n_out:
        out_end = min(out_done + win, n_out)
        out_len = out_end - out_done

        # Posiciones de muestreo continuas desde cur_cursor exacto
        t          = cur_cursor + np.arange(out_len, dtype=np.float64) * ratio
        cur_cursor = t[-1] + ratio   # próximo punto (preserva fracción)

        i1 = np.floor(t).astype(np.int64)
        i1 = np.clip(i1, 0, n_in - 1)
        mu = (t - i1).astype(np.float32)
        i0 = np.maximum(i1 - 1, 0)
        i2 = np.minimum(i1 + 1, n_in - 1)
        i3 = np.minimum(i1 + 2, n_in - 1)

        mu2 = mu * mu
        mu3 = mu2 * mu
        c0  = (-0.5 * mu3 +        mu2 - 0.5 * mu)
        c1  = ( 1.5 * mu3 -  2.5 * mu2 + 1.0      )
        c2  = (-1.5 * mu3 +  2.0 * mu2 + 0.5 * mu  )
        c3  = ( 0.5 * mu3 -  0.5 * mu2              )

        n_ch = chunk.shape[1]
        part = np.empty((out_len, n_ch), dtype=np.float32)
        for c in range(n_ch):
            col      = chunk[:, c]
            part[:, c] = np.clip(
                c0 * col[i0] + c1 * col[i1] + c2 * col[i2] + c3 * col[i3],
                -1.0, 1.0
            )
        out_parts.append(part)
        out_done = out_end
        del t, i1, i0, i2, i3, mu, mu2, mu3, c0, c1, c2, c3, part

    result = np.concatenate(out_parts, axis=0) if out_parts else chunk
    del out_parts

    # next_cursor: posición relativa al inicio del PRÓXIMO chunk.
    # Restando n_in se obtiene el desplazamiento relativo al próximo chunk.
    # Clampeo a ≥0 para evitar cursores negativos cuando ratio < 1 (BUG-C).
    next_cursor = float(max(0.0, cur_cursor - n_in))

    # ── FORENSICS: discontinuidad de fase entre chunks ────────────────────────
    prev_c = _frn_state.get("phase_prev_cursor")
    if prev_c is not None and abs(in_cursor - prev_c) > 1.0:
        _frn_emit("POP_RISK_PHASE_GAP", {
            "expected" : round(prev_c, 6),
            "actual"   : round(in_cursor, 6),
            "gap"      : round(abs(in_cursor - prev_c), 6),
            "ratio"    : round(ratio, 5),
            "chunk_len": n_in,
            "note"     : "salto de fase entre chunks consecutivos → clic audible",
        }, crit=True)
    _frn_state["phase_prev_cursor"] = next_cursor
    # ─────────────────────────────────────────────────────────────────────────

    return result, next_cursor


def _adapt_channels(arr: np.ndarray, target_ch: int) -> np.ndarray:
    """Adapta el número de canales de arr a target_ch (mono↔estéreo)."""
    if arr.shape[1] == target_ch:
        return arr
    if target_ch == 1 and arr.shape[1] > 1:
        return arr[:, :1]
    if target_ch == 2 and arr.shape[1] == 1:
        return np.concatenate([arr, arr], axis=1)
    return arr


def _make_xfade_blk(
        old_blk: Optional[np.ndarray],
        new_blk: np.ndarray,
        xf: int = PE_XFADE_FRAMES,
) -> np.ndarray:
    """
    Crossfade equal-power de `xf` muestras entre el final de old_blk y el
    inicio de new_blk.  Elimina el salto de fase audible en los flushes de
    velocidad Y el "zipper noise" que produce la rampa lineal en la derivada
    de amplitud (perceptible como un clic suave a mitad del fundido).

    Equal-power: fade_out = cos(t·π/2),  fade_in = sin(t·π/2)
    con t ∈ [0, 1].  La suma cuadrática es constante = 1.0 en todo punto,
    lo que garantiza potencia constante durante la transición y cero artefacto
    en el cruce (sin "dip" de 3 dB típico del crossfade lineal).

    FIX-XFADE-EP    (v0.21.01): lineal → equal-power.
    FIX-XFADE-TRUNC (v0.21.05): si new_blk o old_blk son más cortos que xf,
      aplicar crossfade TRUNCADO al mínimo disponible (≥4 frames) en lugar de
      devolver new_blk crudo.  Elimina el clic físico al final de archivo y
      en chunks cortos producidos por el resampleador con ratio alto (ej. ×1.5
      cerca del EOF).  Si new_blk tiene <4 frames no hay crossfade posible y se
      devuelve con fade-in lineal de seguridad para suavizar el borde.
    """
    n_ch    = new_blk.shape[1]
    new_len = len(new_blk)
    old_len = len(old_blk) if old_blk is not None else 0

    # ── Calcular ventana de crossfade efectiva ────────────────────────────────
    # Usar el mínimo entre xf solicitado y lo disponible en ambos bloques.
    xf_eff = min(xf, old_len, new_len)

    if xf_eff < 4:
        # Bloques demasiado cortos para cualquier crossfade útil.
        # Aplicar un fade-in lineal de seguridad sobre new_blk completo para
        # suavizar el borde de ataque abrupto (elimina el clic de la muestra 0).
        _frn_state["xfade_short"] += 1
        _frn_emit("POP_RISK_XFADE_SHORT", {
            "old_len"  : old_len,
            "new_len"  : new_len,
            "xf"       : xf,
            "xf_eff"   : xf_eff,
            "n"        : _frn_state["xfade_short"],
            "note"     : "crossfade imposible (<4 frames) → fade-in lineal de seguridad",
        }, crit=True)
        if new_len > 0:
            fade_len = min(new_len, 16)   # rampa mínima de 16 frames ≈ 0.3ms
            ramp = np.linspace(0.0, 1.0, fade_len, dtype=np.float32).reshape(-1, 1)
            result = new_blk.copy()
            result[:fade_len] = (result[:fade_len] * ramp).astype(np.float32)
            return result
        return new_blk

    # ── FORENSICS: informar si el crossfade fue truncado ─────────────────────
    if xf_eff < xf:
        _frn_state["xfade_short"] += 1
        _frn_emit("POP_RISK_XFADE_SHORT", {
            "old_len"  : old_len,
            "new_len"  : new_len,
            "xf"       : xf,
            "xf_eff"   : xf_eff,
            "n"        : _frn_state["xfade_short"],
            "note"     : "crossfade TRUNCADO (bloque corto) → aplicado con ventana reducida",
        }, crit=False)
    else:
        _frn_emit("XFADE_OK", {
            "old_len": old_len, "new_len": new_len, "xf": xf,
        })
    # ─────────────────────────────────────────────────────────────────────────

    # t ∈ [0, 1] — vector de normalización del crossfade
    t         = np.linspace(0.0, 1.0, xf_eff, dtype=np.float32)
    half_pi_t = t * (np.pi / 2.0)
    fade_out  = np.cos(half_pi_t).reshape(-1, 1)   # 1 → 0  (potencia constante)
    fade_in   = np.sin(half_pi_t).reshape(-1, 1)   # 0 → 1

    tail = old_blk[-xf_eff:]
    head = new_blk[:xf_eff]

    # Adaptar canales si difieren (caso raro en flush de seek con cambio de canal)
    if tail.shape[1] != n_ch:
        tail = _adapt_channels(tail, n_ch)

    xfaded = (tail * fade_out + head * fade_in).astype(np.float32)

    if new_len > xf_eff:
        return np.concatenate([xfaded, new_blk[xf_eff:]], axis=0)
    return xfaded


# ═════════════════════════════════════════════════════════════════════════════
#  PlaybackEngine — Motor principal
# ═════════════════════════════════════════════════════════════════════════════

class PlaybackEngine:
    """
    Motor de reproducción streaming con control de velocidad en tiempo real.

    NUNCA carga el archivo completo en RAM.

    API pública
    -----------
    start(path, rate, channels, start_frame, speed_ratio, on_done)
        Inicia reproducción desde start_frame con speed_ratio.
    stop()
        Detiene la reproducción limpiamente (mute inmediato, join del thread).
    set_speed(ratio)
        Cambio DISCRETO de velocidad (press/release de scrub, seeks).
        Hace flush completo con crossfade anti-pop. Debounce 5ms.
    set_speed_live(ratio)
        Cambio CONTINUO de velocidad (drag en curso).
        Sin flush → cero gaps. Debounce 30ms para los flushes periódicos.
    seek_to(frame)
        Seek interno sin matar el stream. Latencia ≤ 2 ciclos (~10ms).
    is_active() → bool
        True si el thread de reproducción está vivo.

    Atributos de solo lectura
    -------------------------
    src_pos    : float — posición actual en frames del archivo fuente
    src_total  : int   — frames totales del archivo
    src_rate   : int   — sample rate del archivo
    vu_l, vu_r : float — nivel RMS suavizado 0..1 (canal L/R)
    """

    def __init__(self):
        self._thread   : Optional[threading.Thread] = None
        self._stream   : Optional[sd.OutputStream]  = None
        self._stop_evt  = threading.Event()
        self._gen       = 0
        self._lock      = threading.Lock()

        # Estado de velocidad (objeto autónomo, accedido por prefetch y API)
        self._ss        = _SpeedState(ratio=1.0, start_pos=0.0)

        # Eventos de control de flujo
        self._speed_change_evt = threading.Event()
        self._seek_evt         = threading.Event()
        self._seek_frame       = 0

        # Mute inmediato (silencia callback al señalar stop — elimina pop de cierre)
        self._muted = False

        # Posición de reproducción y metadatos del archivo
        self.src_pos   = 0.0
        self.src_total = 0
        self.src_rate  = 48000

        # VU (leído desde el GUI thread, escrito desde el monitor loop)
        self.vu_l = 0.0
        self.vu_r = 0.0

        self._on_done: Optional[Callable] = None

    # ── API pública ───────────────────────────────────────────────────────────

    def start(
        self,
        path        : str,
        rate        : int,
        channels    : int,
        start_frame : int,
        speed_ratio : float,
        on_done     : Optional[Callable] = None,
    ) -> None:
        """Inicia reproducción streaming desde start_frame con speed_ratio."""
        self.stop()

        with self._lock:
            self._gen += 1
            my_gen = self._gen

        # Probar apertura del archivo antes de lanzar el thread
        try:
            with sf.SoundFile(path, "r") as probe:
                self.src_total = probe.frames
        except Exception as exc:
            _plog.error("PlaybackEngine: no se pudo abrir %s: %s", path, exc)
            return

        self.src_rate  = rate
        self.src_pos   = float(start_frame)
        self._on_done  = on_done

        # Resetear toda la maquinaria de estado
        self._stop_evt.clear()
        self._speed_change_evt.clear()
        self._seek_evt.clear()
        self._seek_frame = 0
        self._muted      = False
        self._ss.reset(ratio=speed_ratio, start_pos=float(start_frame))

        self._thread = threading.Thread(
            target = self._play_loop,
            args   = (path, rate, channels, start_frame, speed_ratio, my_gen),
            daemon = True,
            name   = "pe-play",
        )
        self._thread.start()

    def stop(self) -> None:
        """Detiene la reproducción limpiamente."""
        self._muted = True              # silenciar callback antes de detener stream
        self._stop_evt.set()
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=3.0)
        self._thread = None
        self._stop_evt.clear()
        self._muted = False
        self.vu_l = 0.0
        self.vu_r = 0.0

    def set_speed(self, ratio: float) -> None:
        """
        Cambio DISCRETO de velocidad — press/release de scrub, seek finalizado.

        Hace flush completo (vacía chunk_q + _cb_deque, pre-encola chunk nuevo
        desde snap_pos). El bridge aplica crossfade de PE_XFADE_FRAMES muestras
        para eliminar el artefacto de fase en la transición.

        Debounce: PE_SPEED_DEBOUNCE (0.030s) como guardia anti double-flush en
        eventos discretos consecutivos muy rápidos (p.ej. doble-click rápido).
        Si se omite el flush por debounce, _live_speed se actualiza igual para
        que el prefetch vea el nuevo ratio.

        FIX-CROSS-FLUSH-DEBOUNCE (v0.22.16): el debounce original solo comparaba
        contra last_speed_flush (último commit), ignorando last_live_flush.
        EVIDENCIA: pop_forensics.jsonl t=44988ms — FLUSH_SPEED_LIVE seguido 8ms
        después de FLUSH_SPEED_COMMIT (delta_ms=8.052); last_speed_flush estaba
        2499ms antes → debounce de 30ms no actuó → doble flush → clic audible.
        Solución: comparar también contra last_live_flush; si cualquiera de los
        dos está dentro de PE_SPEED_DEBOUNCE, omitir el commit.
        """
        now           = time.monotonic()
        elapsed       = now - self._ss.last_speed_flush
        elapsed_live  = now - self._ss.last_live_flush   # FIX-CROSS-FLUSH-DEBOUNCE
        if elapsed < PE_SPEED_DEBOUNCE or elapsed_live < PE_SPEED_DEBOUNCE:
            # Guardia: actualizar live para que el prefetch vea el nuevo ratio
            # aunque el flush se omita
            _frn_emit("SET_SPEED_DEBOUNCED", {
                "ratio"          : round(ratio, 5),
                "elapsed_ms"     : round(elapsed*1000, 3),
                "elapsed_live_ms": round(elapsed_live*1000, 3),
                "note": "flush omitido por debounce — solo live_ratio actualizado",
            })
            self._ss.live_ratio = ratio
            return

        # ── FORENSICS ────────────────────────────────────────────────────────
        _frn_check_double_flush("FLUSH_SPEED_COMMIT")
        _frn_check_snap_jump(self.src_pos, ratio)
        _frn_emit("FLUSH_SPEED_COMMIT", {
            "ratio"       : round(ratio, 5),
            "src_pos"     : round(self.src_pos, 1),
            "phase_cursor": round(self._ss.phase_cursor, 6),
            "live_ratio"  : round(self._ss.live_ratio, 5),
            "elapsed_ms"  : round(elapsed*1000, 3),
            "stack"       : _frn_short_stack(),
        }, crit=True)
        # ─────────────────────────────────────────────────────────────────────

        # FIX-G3: snapshot ANTES de escribir ratio nuevo
        snap = self.src_pos
        self._ss.commit_ratio     = ratio
        self._ss.live_ratio       = ratio    # alinear live con commit
        self._ss.last_speed_flush = now
        # FIX-PHASE-RACE (v0.21.03): NO resetear phase_cursor aquí desde MainThread.
        # El prefetch puede estar leyendo ss.phase_cursor en su loop normal en este
        # mismo instante → race condition → chunk con in_cursor=0 → PHASE_GAP audible.
        # El reset ya ocurre en el prefetch (live_flush_flag=False → ss.phase_cursor=0)
        # en un solo hilo y en el momento correcto, tras vaciar chunk_q.
        self._ss.snap_pos         = snap
        self._ss.live_flush_flag  = False    # este es un commit, no un live-flush
        self._speed_change_evt.set()

    def set_speed_live_noflush(self, ratio: float) -> None:
        """
        Escribe live_ratio directamente sin disparar _speed_change_evt.

        FIX-ELASTIC-LIVE (v0.21.02):
          Usado exclusivamente por el retorno elástico del MorpherScrubBar.
          Durante el retorno, los ratios decrecen suavemente tick a tick.
          El prefetch los lee en su ciclo natural (latencia ≤ 85ms) sin
          necesidad de vaciar la cola → cero gaps → cero pops durante el retorno.

          NO usar para cambios de velocidad que requieran reposicionamiento
          de la cabeza lectora (seeks, cambios de dirección).  Para esos casos,
          usar set_speed() o set_speed_live().
        """
        self._ss.live_ratio = float(ratio)
        # ── FORENSICS ────────────────────────────────────────────────────────
        _frn_emit("SET_SPEED_NOFLUSH", {
            "ratio"  : round(ratio, 5),
            "src_pos": round(self.src_pos, 1),
        })
        # ─────────────────────────────────────────────────────────────────────

    def set_speed_live(self, ratio: float) -> None:
        """
        Cambio CONTINUO de velocidad — drag en curso del scrub.

        Sin flush en cada llamada → cero gaps durante el arrastre.
        Con debounce de PE_LIVE_DEBOUNCE (30ms) dispara _speed_change_evt
        para que el prefetch vacíe la cola y reinicie desde snap_pos.

        Entre flushes, solo actualiza live_ratio — el prefetch lo lee en
        su próximo ciclo normal (~85ms de latencia máxima).

        FIX-P1: snap_pos capturado ANTES de escribir live_ratio.
        FIX-P5: _live_flush_flag=True → prefetch preserva phase_cursor.
        FIX-SNAP-FROZEN-HEAD (v0.22.12): cuando abs_ratio ≈ 0, el prefetch
        genera chunks de ~1 frame y head_pos casi no avanza. Si head_pos no
        avanzó más de PE_CHUNK_FRAMES/2 desde el flush anterior, está congelado
        → usar src_pos como snap en su lugar para evitar el salto masivo.
        """
        now = time.monotonic()
        if (now - self._ss.last_live_flush) >= PE_LIVE_DEBOUNCE:
            # FIX-LIVE-SNAP (v0.21.04): usar head_pos como snap_pos para flushes live.
            # FIX-SNAP-FROZEN-HEAD (v0.22.12): pero solo si head_pos realmente avanzó
            # desde el último flush. Si la diferencia es < PE_CHUNK_FRAMES/2, el prefetch
            # estaba congelado (abs_ratio ≈ 0) → fallback a src_pos para snap limpio.
            # FIX-SNAP-FROZEN-HEAD-REVERSE (v0.22.15): el check anterior era
            #   head_advanced = (cur_head - last_head_snap) >= PE_CHUNK_FRAMES/2
            # que en modo reversa (ratio < 0) es SIEMPRE False porque head_pos
            # DISMINUYE intencionalmente. Resultado: todo flush en reversa caía al
            # fallback src_pos, que puede estar 30+ segundos detrás de head_pos
            # (buffer forward aún drenando tras el cambio de dirección).
            # EVIDENCIA: pop_forensics.jsonl POP_RISK_SNAP_JUMP t=27797.907:
            #   prev=7,632,203 → new=6,151,644, delta=1,480,559 frames (33.6s).
            #   head_pos=7,628,370; src_pos=6,151,644; gap=1,476,726 frames.
            # SOLUCIÓN: considerar el signo del ratio para determinar "avanzó".
            #   · Forward (ratio ≥ 0): avanzó si cur_head - last_head_snap ≥ umbral
            #   · Reverse (ratio < 0): avanzó si last_head_snap - cur_head ≥ umbral
            cur_head = self._ss.head_pos
            _head_delta = (cur_head - self._ss.last_head_snap) * (-1.0 if ratio < 0 else 1.0)
            head_advanced = _head_delta >= (PE_CHUNK_FRAMES / 2)
            if cur_head > 0.0 and head_advanced:
                snap = cur_head
            else:
                snap = self.src_pos   # fallback: head_pos congelado o no inicializado
            # ── FORENSICS ─────────────────────────────────────────────────────
            _frn_check_double_flush("FLUSH_SPEED_LIVE")
            _frn_check_snap_jump(snap, ratio)
            _frn_emit("FLUSH_SPEED_LIVE", {
                "ratio"       : round(ratio, 5),
                "src_pos"     : round(snap, 1),
                "phase_cursor": round(self._ss.phase_cursor, 6),
                "elapsed_ms"  : round((now - self._ss.last_live_flush)*1000, 3),
                "stack"       : _frn_short_stack(),
            }, crit=True)
            # ──────────────────────────────────────────────────────────────────
            self._ss.snap_pos        = snap
            self._ss.live_ratio      = ratio
            self._ss.last_live_flush = now
            self._ss.last_head_snap  = cur_head   # FIX-SNAP-FROZEN-HEAD: registrar head al momento del flush
            self._ss.live_flush_flag = True    # FIX-P5: preservar fase en prefetch
            self._speed_change_evt.set()
        else:
            # Entre flushes: solo actualizar live_ratio (sin flush)
            prev = self._ss.live_ratio
            self._ss.live_ratio = ratio
            if abs(ratio - prev) >= 0.05:
                _frn_emit("LIVE_RATIO_UPDATE", {
                    "ratio": round(ratio, 5), "prev": round(prev, 5),
                    "delta": round(ratio - prev, 5),
                })

    def seek_to(self, frame: int) -> None:
        """
        Seek interno sin matar el stream.

        FIX-2: NO emite _speed_change_evt — el seek tiene su propio path
        completo (_seek_evt) que ya vacía chunk_q y _cb_deque. Emitir
        _speed_change_evt además causaba un flush doble → pop doble.

        Latencia de respuesta ≤ 2 ciclos de prefetch (~10ms).
        Usar para seeks durante drag (mouseMoveEvent).
        Para seeks finales (mouseReleaseEvent) usar play_audio() del studio.
        """
        target           = int(max(0, frame))
        self._seek_frame = target
        self.src_pos     = float(target)
        self._ss.snap_pos = float(target)
        self._seek_evt.set()

    def is_active(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ── Loop interno ─────────────────────────────────────────────────────────

    def _play_loop(
        self,
        path        : str,
        rate        : int,
        channels    : int,
        start_frame : int,
        speed_ratio : float,
        my_gen      : int,
    ) -> None:
        """
        Thread worker principal.
        Lanza _PrefetchWorker, _BridgeWorker, OutputStream callback.
        RAM constante: PE_RING_CHUNKS * PE_CHUNK_FRAMES frames máx en RAM.
        """
        # Sincronizar _SpeedState con los parámetros reales del thread
        self._ss.reset(ratio=speed_ratio, start_pos=float(start_frame))

        # ── Colas del pipeline ────────────────────────────────────────────────
        chunk_q   : queue.Queue  = queue.Queue(maxsize=PE_RING_CHUNKS)
        _cb_deque : deque        = deque()

        # Eventos de sincronización prefetch ↔ bridge
        _flush_req_evt   = threading.Event()   # prefetch → bridge: "inicio flush"
        _flush_ready_evt = threading.Event()   # prefetch → bridge: "datos nuevos listos"

        # ── _enqueue_data ─────────────────────────────────────────────────────
        def _enqueue_data(data: np.ndarray) -> None:
            """
            Encola data en slots de PE_CHUNK_FRAMES.
            FIX-7: put bloqueante con timeout corto (PE_ENQUEUE_TIMEOUT=10ms)
            en lugar de 4×50ms, minimizando el tiempo de bloqueo del prefetch.

            FIX-ENQUEUE-PREEMPT (v0.22.13): si _speed_change_evt se activa mientras
            el prefetch está bloqueado en chunk_q.put() (cola llena), abortar el
            enqueue inmediatamente y retornar.  El bucle principal comprobará el
            evento en la siguiente iteración y ejecutará el flush antes de que el
            deque se agote.

            Sin este fix, el prefetch gira indefinidamente sobre put(timeout=10ms)
            sin poder comprobar _speed_change_evt → el bridge sigue drenando el
            deque → deque vacío → underrun → POP.  Observado: hasta 755ms de
            bloqueo con 881 callbacks en underrun consecutivo.
            """
            offset = 0
            while offset < len(data) and not self._stop_evt.is_set():
                # Si hay un flush pendiente, abortar: el bucle principal lo manejará
                if self._speed_change_evt.is_set() or self._seek_evt.is_set():
                    return
                end = min(offset + PE_CHUNK_FRAMES, len(data))
                blk = data[offset:end].copy()
                while not self._stop_evt.is_set():
                    if self._speed_change_evt.is_set() or self._seek_evt.is_set():
                        return  # flush urgente: abandonar bloque actual
                    try:
                        chunk_q.put(blk, timeout=PE_ENQUEUE_TIMEOUT)
                        break
                    except queue.Full:
                        pass
                offset = end

        # ── _PrefetchWorker ───────────────────────────────────────────────────
        def _prefetch() -> None:
            """
            Lee disco → resamplea → encola en chunk_q.
            Responde a _seek_evt y _speed_change_evt vacilando la cola
            y re-leyendo desde la posición correcta (snap_pos).
            """
            head_pos = float(start_frame)
            ss       = self._ss   # alias local (evita atributo lookup en hot loop)
            try:
                with sf.SoundFile(path, "r") as f:
                    total_frames = f.frames

                    while not self._stop_evt.is_set():

                        # ── Seek interno ──────────────────────────────────────
                        if self._seek_evt.is_set():
                            self._seek_evt.clear()

                            # 1. Vaciar chunk_q (datos de posición anterior)
                            while True:
                                try:   chunk_q.get_nowait()
                                except queue.Empty: break

                            # 2. Señalar al bridge que inicie el flush de _cb_deque
                            _flush_req_evt.set()

                            # 3. Reposicionar cabeza lectora
                            head_pos = max(0.0, min(float(total_frames - 1),
                                                    float(self._seek_frame)))

                            # 4. Absorber speed-change redundante (seek ya reposiciona)
                            self._speed_change_evt.clear()

                            # 5. Resetear fase (seek es siempre evento discreto)
                            ss.phase_cursor = PE_PHASE_RESET
                            ss.phase_history = None  # GAP-062: en lockstep con phase_cursor
                            # FIX-SEEK-PHASE-TRACKER (v0.22.19): al resetear phase_cursor
                            # también resetear phase_prev_cursor en el detector forense.
                            # Sin este reset, el siguiente chunk tiene in_cursor=0.0 pero
                            # _frn_state["phase_prev_cursor"] sigue en el valor pre-seek →
                            # POP_RISK_PHASE_GAP falso (gap=old_cursor, actual=0.0).
                            # Evidencia: pop_forensics.jsonl — 7 eventos con actual=0.0,
                            # todos tras seek interno con phase_cursor reset sin sincronizar
                            # el tracker forense.
                            _frn_state["phase_prev_cursor"] = None  # FIX-SEEK-PHASE-TRACKER

                            # 6. Pre-encolar ≥1 chunk ANTES de señalar al bridge (FIX-4)
                            read_start = int(head_pos)
                            if read_start < total_frames:
                                f.seek(read_start)
                                pre = f.read(PE_CHUNK_FRAMES,
                                             dtype="float32", always_2d=True)
                                if pre.shape[0] > 0:
                                    pre = _adapt_channels(pre, channels)
                                    ratio = ss.live_ratio
                                    abs_r = abs(ratio)
                                    if ratio < 0:
                                        pre = pre[::-1].copy()
                                    if abs(abs_r - 1.0) > 0.0005:
                                        if USE_CONTINUOUS_RESAMPLE:
                                            pre, ss.phase_cursor, ss.phase_history = resample_stateful_continuous(
                                                pre, abs_r, ss.phase_cursor, ss.phase_history)
                                        else:
                                            pre, ss.phase_cursor = _resample_stateful(
                                                pre, abs_r, ss.phase_cursor)
                                    head_pos = float(read_start + PE_CHUNK_FRAMES)
                                    try: chunk_q.put_nowait(pre)
                                    except queue.Full: pass

                            # 7. Señalar al bridge: datos listos, puede vaciar deque
                            _flush_ready_evt.set()
                            continue

                        # ── Speed-change flush ────────────────────────────────
                        if self._speed_change_evt.is_set():
                            # FIX-PHASE-FLAG-RACE (v0.21.05): leer live_flush_flag
                            # ANTES de llamar a .clear() sobre el evento.
                            # Si el MainThread escribe live_flush_flag=True y luego
                            # dispara _speed_change_evt, hay una ventana donde el
                            # prefetch podría leer el evento como set pero leer el
                            # flag antes de que el MainThread lo haya escrito
                            # (distinto orden de visibilidad bajo el GIL).
                            # Capturar el flag antes del clear() garantiza que se
                            # lee el valor que el MainThread puso, porque el evt
                            # solo puede estar set DESPUÉS de que live_flush_flag
                            # fue escrito (set_speed_live lo escribe primero, línea
                            # 6120, y luego hace .set(), línea 6121 —orden Python).
                            captured_live_flag = ss.live_flush_flag
                            self._speed_change_evt.clear()

                            # ── FORENSICS ─────────────────────────────────────
                            _frn_emit("PREFETCH_SPEED_FLUSH", {
                                "head_pos"       : round(head_pos, 1),
                                "snap_pos"       : round(ss.snap_pos, 1),
                                "live_ratio"     : round(ss.live_ratio, 5),
                                "phase_cursor"   : round(ss.phase_cursor, 6),
                                "live_flush_flag": captured_live_flag,
                                "chunk_q_size"   : chunk_q.qsize(),
                            })
                            # ──────────────────────────────────────────────────

                            # Vaciar chunk_q
                            while True:
                                try:   chunk_q.get_nowait()
                                except queue.Empty: break

                            # Señalar flush al bridge
                            _flush_req_evt.set()

                            # FIX-P5: preservar phase_cursor solo en flushes de drag.
                            # En flushes de commit (set_speed), resetear a PE_PHASE_RESET.
                            # Usar captured_live_flag (leído antes del clear) para evitar
                            # la race donde el MainThread ya limpió el flag a False antes
                            # de que lleguemos aquí.
                            if not captured_live_flag:
                                # ── FORENSICS: fase reseteada en commit ───────
                                _frn_emit("PREFETCH_PHASE_RESET", {
                                    "old_cursor": round(ss.phase_cursor, 6),
                                    "note"      : "commit discreto → phase_cursor=0",
                                })
                                # ─────────────────────────────────────────────
                                ss.phase_cursor = PE_PHASE_RESET
                                ss.phase_history = None  # GAP-062: en lockstep con phase_cursor
                            # FIX-PHASE-GAP (v0.21.04): resetear trazabilidad forense
                            # en AMBOS tipos de flush (commit y live).
                            _frn_state["phase_prev_cursor"] = None  # reset trazabilidad
                            ss.live_flush_flag = False   # limpiar flag para próximo flush

                            # FIX-3: usar snap_pos (atómico) en vez de src_pos
                            head_pos = max(0.0, min(float(total_frames - 1),
                                                    ss.snap_pos))

                            # Pre-encolar ≥1 chunk desde nueva posición (FIX-4)
                            read_start = int(head_pos)
                            if read_start < total_frames:
                                f.seek(read_start)
                                ratio  = ss.live_ratio
                                abs_r  = abs(ratio)
                                is_rev = ratio < 0
                                # Leer suficiente para producir PE_CHUNK_FRAMES de output
                                src_needed = max(512, int(PE_CHUNK_FRAMES * max(abs_r, 0.25)))
                                pre = f.read(src_needed, dtype="float32", always_2d=True)
                                if pre.shape[0] > 0:
                                    pre = _adapt_channels(pre, channels)
                                    if is_rev:
                                        pre = pre[::-1].copy()
                                    if abs(abs_r - 1.0) > 0.0005:
                                        if USE_CONTINUOUS_RESAMPLE:
                                            pre, ss.phase_cursor, ss.phase_history = resample_stateful_continuous(
                                                pre, abs_r, ss.phase_cursor, ss.phase_history)
                                        else:
                                            pre, ss.phase_cursor = _resample_stateful(
                                                pre, abs_r, ss.phase_cursor)
                                    head_pos = float(read_start + src_needed)
                                    try: chunk_q.put_nowait(pre)
                                    except queue.Full: pass

                            _flush_ready_evt.set()
                            continue

                        # ── Lectura normal ────────────────────────────────────
                        # FIX-G1: usar live_ratio (nunca commit_ratio aquí) para que
                        # los cambios de drag se apliquen sin flush (latencia ≤ 85ms).
                        ratio      = ss.live_ratio
                        abs_ratio  = abs(ratio)
                        is_reverse = ratio < 0
                        src_needed = max(512, int(PE_CHUNK_FRAMES * max(abs_ratio, 0.25)))

                        if is_reverse:
                            read_start = int(head_pos) - src_needed
                            if read_start < 0:
                                src_needed = max(0, int(head_pos))
                                read_start = 0
                            if src_needed == 0:
                                break   # inicio del archivo en reversa → EOF
                            f.seek(read_start)
                            data = f.read(src_needed, dtype="float32", always_2d=True)
                            if data.shape[0] == 0:
                                break
                            actual = data.shape[0]
                            data   = _adapt_channels(data, channels)
                            data   = data[::-1].copy()
                            if abs(abs_ratio - 1.0) > 0.0005:
                                if USE_CONTINUOUS_RESAMPLE:
                                    data, ss.phase_cursor, ss.phase_history = resample_stateful_continuous(
                                        data, abs_ratio, ss.phase_cursor, ss.phase_history)
                                else:
                                    data, ss.phase_cursor = _resample_stateful(
                                        data, abs_ratio, ss.phase_cursor)
                            _enqueue_data(data)
                            del data
                            head_pos = float(read_start)   # avanza hacia atrás
                            ss.head_pos = head_pos   # FIX-LIVE-SNAP: mantener head_pos visible desde MainThread

                        else:
                            read_start = int(head_pos)
                            if read_start >= total_frames:
                                break   # EOF
                            f.seek(read_start)
                            data = f.read(src_needed, dtype="float32", always_2d=True)
                            if data.shape[0] == 0:
                                break
                            actual = data.shape[0]
                            data   = _adapt_channels(data, channels)
                            if abs(abs_ratio - 1.0) > 0.0005:
                                if USE_CONTINUOUS_RESAMPLE:
                                    data, ss.phase_cursor, ss.phase_history = resample_stateful_continuous(
                                        data, abs_ratio, ss.phase_cursor, ss.phase_history)
                                else:
                                    data, ss.phase_cursor = _resample_stateful(
                                        data, abs_ratio, ss.phase_cursor)
                            _enqueue_data(data)
                            del data
                            head_pos = float(read_start + actual)
                            ss.head_pos = head_pos   # FIX-LIVE-SNAP: mantener head_pos visible desde MainThread

            except Exception as exc:
                _plog.error("PlaybackEngine prefetch: %s", exc)
            finally:
                # Señal de fin de archivo: 3 intentos con chunk vacío
                for _ in range(3):
                    try:
                        chunk_q.put(
                            np.zeros((0, channels), dtype=np.float32),
                            timeout=1.0,
                        )
                        break
                    except queue.Full:
                        pass

        prefetch_t = threading.Thread(
            target=_prefetch, daemon=True, name="pe-prefetch"
        )
        prefetch_t.start()

        # ── _BridgeWorker ─────────────────────────────────────────────────────
        # FIX-ZERO-GAP (v0.21.02): reemplaza clear()+appendleft() por hot-swap
        # atómico mediante double-buffer.
        #
        # PROBLEMA ORIGINAL:
        #   _cb_deque.clear()       ← punto A: deque queda VACÍO
        #   _cb_deque.appendleft()  ← punto B: deque tiene datos
        #   Entre A y B el callback RT puede correr → underrun → silencio → POP.
        #   Con GIL + OS scheduling, la ventana A→B puede ser 5-15ms, suficiente
        #   para que el callback (blocksize=512, ~10.7ms) la experimente.
        #
        # SOLUCIÓN:
        #   Usar _deque_ref = [deque_activo] como puntero hot-swappable.
        #   El callback lee siempre _deque_ref[0].pop().
        #   El bridge construye un deque_nuevo completo con [xf_blk],
        #   luego hace _deque_ref[0] = deque_nuevo — una sola asignación
        #   de referencia, atómica bajo el GIL de CPython.
        #   El callback nunca ve un deque vacío.
        #
        # FIX-P1+P2 (original, mantenido): xfade se construye ANTES del swap.
        _bridge_stop  = threading.Event()
        _last_blk_ref = [None]   # mutable ref al último bloque entregado al callback

        # Hot-swap pointer: [deque_activo]. El callback lee _deque_ref[0].
        # La asignación _deque_ref[0] = x es atómica en CPython (GIL).
        _deque_ref = [_cb_deque]

        def _bridge() -> None:
            nonlocal _cb_deque   # mantener referencia local sincronizada
            while not _bridge_stop.is_set():
                if _flush_req_evt.is_set():
                    _flush_req_evt.clear()
                    # ── FORENSICS: medir tiempo de espera del flush_ready ─────
                    _t_flush_start = time.monotonic()
                    # ─────────────────────────────────────────────────────────
                    # FIX-BRIDGE-TIMEOUT (v0.21.05): aumentar timeout a 200ms.
                    # Con 120ms, discos HDD con seek time >10ms o SSD con cola
                    # saturada pueden tardar >110ms y provocar
                    # POP_RISK_FLUSH_PREFETCH_TIMEOUT frecuentemente.
                    # 200ms sigue siendo menor que PE_RING_CHUNKS*PE_CHUNK_FRAMES
                    # @ 48kHz (≈341ms), así que el deque viejo tiene margen para
                    # servir al callback durante la espera sin underrun.
                    _flush_ready_evt.wait(timeout=0.200)
                    _flush_ready_evt.clear()

                    # ── FORENSICS: detectar timeout de prefetch ───────────────
                    _wait_ms = (time.monotonic() - _t_flush_start) * 1000
                    if _wait_ms >= 110.0:
                        _frn_emit("POP_RISK_FLUSH_PREFETCH_TIMEOUT", {
                            "wait_ms"  : round(_wait_ms, 2),
                            "deque_len": len(_deque_ref[0]),
                            "note"     : "prefetch tardó >110ms → deque puede vaciarse antes del swap",
                        }, crit=True)
                    # ─────────────────────────────────────────────────────────

                    # Construir xfade ANTES del swap → el callback nunca para.
                    # FIX-BRIDGE-RETRY (v0.21.04): retry de 30ms si chunk_q vacío.
                    new_blk = None
                    try:
                        new_blk = chunk_q.get_nowait()
                    except queue.Empty:
                        try:
                            new_blk = chunk_q.get(timeout=0.030)
                        except queue.Empty:
                            pass

                    if new_blk is not None and new_blk.shape[0] > 0:
                        xf_blk = _make_xfade_blk(_last_blk_ref[0], new_blk)
                        _last_blk_ref[0] = xf_blk
                        # FIX-ZERO-GAP: construir deque nuevo COMPLETO antes del swap.
                        # appendleft(xf_blk) → xf_blk es el PRIMERO que el callback recibe.
                        _new_deque = deque()
                        _new_deque.appendleft(xf_blk)
                        # SWAP ATÓMICO: una sola asignación de referencia bajo GIL.
                        _deque_ref[0] = _new_deque
                        _cb_deque     = _new_deque   # sincronizar referencia local
                        # ── FORENSICS: hot-swap confirmado ────────────────────
                        _frn_emit("BRIDGE_HOT_SWAP", {
                            "wait_ms" : round(_wait_ms, 2),
                            "xf_len"  : len(xf_blk),
                            "new_deque_len": len(_new_deque),
                        })
                        # ─────────────────────────────────────────────────────
                    else:
                        # FIX-BRIDGE-FALLBACK (v0.21.05): prefetch sin datos tras
                        # 230ms de espera total (200+30ms retry).  En lugar de dejar
                        # fluir el deque viejo sin más (que puede estar ya vacío),
                        # inyectar el último bloque conocido con un fade-out lineal
                        # de seguridad para que el callback tenga al menos un chunk
                        # que consumir y el eventual underrun sea enmascarado.
                        # Si no hay último bloque (_last_blk_ref[0] is None), no se
                        # hace nada: el deque viejo sigue siendo la mejor opción.
                        last = _last_blk_ref[0]
                        if last is not None and len(last) > 0:
                            fade_len = min(len(last), 256)
                            ramp = np.linspace(1.0, 0.0, fade_len, dtype=np.float32).reshape(-1, 1)
                            fallback = last.copy()
                            fallback[:fade_len] = (fallback[:fade_len] * ramp).astype(np.float32)
                            if len(fallback) > fade_len:
                                fallback[fade_len:] = 0.0
                            _safety_deque = deque()
                            _safety_deque.appendleft(fallback)
                            _deque_ref[0] = _safety_deque
                            _cb_deque     = _safety_deque
                            _frn_emit("POP_RISK_FLUSH_EMPTY_DEQUE", {
                                "wait_ms"  : round(_wait_ms, 2),
                                "deque_len": len(_safety_deque),
                                "note"     : "prefetch sin datos → fallback fade-out inyectado",
                            }, crit=True)
                        else:
                            _frn_emit("POP_RISK_FLUSH_EMPTY_DEQUE", {
                                "wait_ms"  : round(_wait_ms, 2),
                                "deque_len": len(_deque_ref[0]),
                                "note"     : "prefetch no entregó datos → swap abortado → deque viejo sigue fluyendo",
                            }, crit=True)
                    continue

                # Relleno normal del deque
                cur = _deque_ref[0]
                if len(cur) < PE_RING_CHUNKS:
                    try:
                        blk = chunk_q.get(timeout=0.005)
                        if blk.shape[0] > 0:
                            _last_blk_ref[0] = blk
                        cur.appendleft(blk)
                    except queue.Empty:
                        pass
                else:
                    # OPT-09: Event.wait en lugar de time.sleep — despertable por señal
                    _bridge_stop.wait(timeout=0.001)

        _bridge_t = threading.Thread(
            target=_bridge, daemon=True, name="pe-bridge"
        )
        _bridge_t.start()

        # ── Estado del callback RT ────────────────────────────────────────────
        cb_state = {
            "chunk"          : None,
            "pos"            : 0,
            "done"           : False,
            "underrun"       : 0,
            "underrun_consec": 0,
        }

        def _try_refill() -> None:
            """Intenta obtener el siguiente bloque del deque (non-blocking).
            FIX-ZERO-GAP (v0.21.02): lee de _deque_ref[0] para respetar el
            hot-swap atómico del bridge. En el mismo instante que el bridge
            hace _deque_ref[0] = deque_nuevo, el callback lee el deque nuevo
            en la SIGUIENTE llamada a _try_refill() → cero underrun."""
            try:
                blk = _deque_ref[0].pop()
                if blk.shape[0] == 0:
                    cb_state["done"]  = True
                    cb_state["chunk"] = None
                else:
                    cb_state["chunk"] = blk
                    cb_state["pos"]   = 0
                cb_state["underrun_consec"] = 0
            except IndexError:
                cb_state["underrun"]        += 1
                cb_state["underrun_consec"] += 1
                _frn_state["underrun_total"] += 1
                # ── FORENSICS: pop real confirmado ────────────────────────────
                _frn_emit("POP_RISK_DEQUE_EMPTY_CB", {
                    "underrun_total" : _frn_state["underrun_total"],
                    "underrun_consec": cb_state["underrun_consec"],
                    "deque_len"      : len(_deque_ref[0]),
                    "last_flush_type": _frn_state["last_flush_type"],
                    "ms_since_flush" : round(
                        (time.monotonic_ns() - _frn_state["last_flush_ns"]) / 1e6, 2
                    ) if _frn_state["last_flush_ns"] else -1,
                    "note": "DEQUE VACÍO en callback RT → silencio → POP",
                }, crit=True)
                # ─────────────────────────────────────────────────────────────

        # ── Pre-carga: FIX-8 ─────────────────────────────────────────────────
        _preload = min(4, max(1, PE_RING_CHUNKS // 2))
        _t0      = time.monotonic()
        while len(_deque_ref[0]) < _preload and (time.monotonic() - _t0) < 2.0:
            time.sleep(0.005)
        if len(_deque_ref[0]) == 0:
            _plog.warning("PlaybackEngine: sin datos en 2s, abortando")
            _bridge_stop.set()
            prefetch_t.join(timeout=2.0)
            _bridge_t.join(timeout=1.0)
            return
        first = _deque_ref[0].pop()
        if first.shape[0] == 0:
            cb_state["done"] = True
        else:
            cb_state["chunk"] = first
            cb_state["pos"]   = 0

        # ── VU acumulador (liviano, fuera del hot path RT) ───────────────────
        _vu_acc    = [0.0, 0.0, 0]
        _VU_SMOOTH = 0.35   # EWMA ágil — GUI lee a 24Hz, necesita respuesta rápida

        # ── Callback RT ───────────────────────────────────────────────────────
        def _audio_cb(outdata, frames, time_info, status):
            if my_gen != self._gen or cb_state["done"] or self._muted:
                outdata[:] = 0
                raise sd.CallbackStop()

            out_written = 0
            while out_written < frames:
                if (cb_state["chunk"] is None or
                        cb_state["pos"] >= len(cb_state["chunk"])):
                    _try_refill()
                    if cb_state["done"]:
                        outdata[out_written:] = 0
                        raise sd.CallbackStop()
                    # FIX-UNDERRUN-SPIN (GAP-073): tras un refill fallido, el
                    # chunk puede haber quedado en dos estados de "sin datos"
                    # distintos: None (nunca hubo chunk) o NO-None pero
                    # AGOTADO (`pos >= len(chunk)`, el que traíamos antes de
                    # llamar a `_try_refill()`, que en un fallo por
                    # `IndexError` NO se modifica). El chequeo original solo
                    # cubría el primer caso — en el segundo, `avail` sale en
                    # 0, `take = min(0, need) = 0`, `out_written` NO avanza,
                    # y el `while` de arriba vuelve a intentar `_try_refill()`
                    # sin límite ni espera: un busy-spin real dentro del
                    # callback RT durante todo el tiempo que tarde el disco
                    # lento en entregar el siguiente chunk (confirmado con
                    # ejecución real bajo disco lento inyectado,
                    # `tests/test_fault_injection_playback.py`,
                    # `TestSlowDiskDuringPlayback` — el comentario original
                    # de la línea de abajo prometía "nunca stall" pero SÍ
                    # se colgaba en este caso). Comprobar AMBOS estados aquí
                    # restaura la garantía real de "nunca stall": silencio
                    # inmediato en vez de girar en el hilo de audio.
                    if (cb_state["chunk"] is None or
                            cb_state["pos"] >= len(cb_state["chunk"])):
                        # Underrun transitorio: silencio, nunca stall
                        outdata[out_written:] = 0
                        break

                chunk  = cb_state["chunk"]
                avail  = len(chunk) - cb_state["pos"]
                need   = frames - out_written
                take   = min(avail, need)
                src    = chunk[cb_state["pos"]: cb_state["pos"] + take]
                outdata[out_written: out_written + take] = src
                cb_state["pos"] += take
                out_written += take

                # FIX-G1: avanzar src_pos con live_ratio para que el scrub visual
                # refleje el ratio real que el prefetch está usando.
                # FIX-G2: NO sobreescribir snap_pos desde el callback RT.
                spd = self._ss.live_ratio
                self.src_pos += take * spd

                # VU: sumas escalares puras (sin numpy en el hot path RT)
                if src.shape[1] >= 2:
                    col_l = src[:, 0]; col_r = src[:, 1]
                    _vu_acc[0] += float(col_l @ col_l)
                    _vu_acc[1] += float(col_r @ col_r)
                else:
                    ss_val = float(src[:, 0] @ src[:, 0])
                    _vu_acc[0] += ss_val; _vu_acc[1] += ss_val
                _vu_acc[2] += take

        # ── Monitor loop: abre el OutputStream y monitorea underruns ─────────
        try:
            self._stream = sd.OutputStream(
                samplerate = rate,
                channels   = channels,
                dtype      = "float32",
                blocksize  = PE_BLOCKSIZE,
                latency    = "low",
                callback   = _audio_cb,
            )
            # GAP-063: copia local — self._stream puede quedar en None desde
            # OTRO hilo (PlaybackEngine.stop(), llamado por el hilo llamador/
            # main) entre iteraciones de este bucle, que corre en el hilo de
            # _play_loop. Carrera real confirmada con hilos reales (ver
            # tests/test_playback_engine_integration.py, GAP-062): antes de
            # este fix, cada test registraba "PlaybackEngine OutputStream:
            # 'NoneType' object has no attribute 'active'" en el log (no
            # fatal — capturado por el except de abajo — pero real en cada
            # stop()). Una variable local de pila es inmune a que otro hilo
            # reasigne self._stream; leerla en vez de self._stream elimina
            # la carrera sin cambiar la semántica (mismo objeto stream).
            _stream_local = self._stream
            with _stream_local:
                _underrun_warn_last = 0.0
                while _stream_local.active:
                    if self._stop_evt.is_set() or my_gen != self._gen:
                        break
                    time.sleep(0.020)

                    # Actualizar VU
                    n = _vu_acc[2]
                    if n > 0:
                        rms_l = (_vu_acc[0] / n) ** 0.5
                        rms_r = (_vu_acc[1] / n) ** 0.5
                        _vu_acc[0] = _vu_acc[1] = 0.0
                        _vu_acc[2] = 0
                        db_l = max(-60.0, min(0.0, 20.0 * _math.log10(max(rms_l, 1e-12))))
                        db_r = max(-60.0, min(0.0, 20.0 * _math.log10(max(rms_r, 1e-12))))
                        self.vu_l += _VU_SMOOTH * ((db_l + 60) / 60 - self.vu_l)
                        self.vu_r += _VU_SMOOTH * ((db_r + 60) / 60 - self.vu_r)

                    # Alert de underruns prolongados
                    uc     = cb_state["underrun_consec"]
                    now_t  = time.monotonic()
                    if uc >= PE_UNDERRUN_LIMIT and (now_t - _underrun_warn_last) > 5.0:
                        _underrun_warn_last = now_t
                        _plog.warning(
                            "PE UNDERRUN prolongado: %d consecutivos "
                            "— buffer insuficiente o CPU saturada", uc
                        )

        except Exception as exc:
            _plog.error("PlaybackEngine OutputStream: %s", exc)
        finally:
            self._stop_evt.set()
            _bridge_stop.set()
            prefetch_t.join(timeout=3.0)
            _bridge_t.join(timeout=1.0)
            # FIX-ZERO-GAP (v0.21.02): limpiar el deque activo vía _deque_ref[0]
            _deque_ref[0].clear()
            while not chunk_q.empty():
                try: chunk_q.get_nowait()
                except queue.Empty: break
            del chunk_q
            # OPT-06: gc.collect() eliminado del hot path stop (stop-the-world ~5-10ms)
            self.vu_l = 0.0; self.vu_r = 0.0
            self._stream = None
            if my_gen == self._gen and self._on_done:
                self._on_done()


    @staticmethod
    def _resample_chunk(chunk: np.ndarray, ratio: float) -> np.ndarray:
        """Compatibilidad con código heredado — wrapper sobre _resample_stateful."""
        out, _ = _resample_stateful(chunk, ratio, 0.0)
        return out
