"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Núcleo de transporte con generación (Transport Core) — única autoridad sobre el estado de transporte, sin lógica de negocio en la UI.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Rama del árbol de módulos de Lorito Aldhiro (§4-§7, FASE 1 de la Orden
Maestra de Refundación de Scrubs Morpher/Velocista y motor de
exportación). Este `__init__.py` estaba vacío desde su creación —
violación de la convención "nunca se deja un `__init__.py` vacío como
simple marcador de paquete" (vigente desde GAP-032) que pasó
desapercibida hasta esta sesión (GAP-051, FASE 1 de la Orden de
Saneamiento, Integración y Consolidación).

Módulos:
  · lorito_transport_state    — `TransportState`, `TransportMode`, `Direction`.
  · lorito_transport_commands — `TransportCommand`, `CommandKind`.
  · lorito_speed_planner      — `SpeedPlanner`, `SpeedPlannerConfig`.
  · lorito_transport_machine  — `TransportMachine` (única autoridad de
    transición, §4), `GenerationGuard`/`TaggedBlock` (§5-§6),
    `InvalidTransitionError` (consolidada bajo `LoritoError` en GAP-051).

Nota de estado (ver `ESTADO_MAESTRO_CONSOLIDACION.md`): estos módulos
ya existen y están verificados de forma aislada (máquina de estados
pura, sin hardware) — su integración como autoridad real dentro de
`PlaybackEngine`/Scrubs Morpher/Velocista (P0.2 de la Orden vigente)
sigue pendiente.
"""

from lorito_aldhiro.backend.transport.lorito_transport_state import (
    TransportState, TransportMode, Direction,
)
from lorito_aldhiro.backend.transport.lorito_transport_commands import (
    TransportCommand, CommandKind,
)
from lorito_aldhiro.backend.transport.lorito_speed_planner import (
    SpeedPlanner, SpeedPlannerConfig,
)
from lorito_aldhiro.backend.transport.lorito_transport_machine import (
    TransportMachine, GenerationGuard, TaggedBlock, InvalidTransitionError,
)

__all__ = [
    "TransportState", "TransportMode", "Direction",
    "TransportCommand", "CommandKind",
    "SpeedPlanner", "SpeedPlannerConfig",
    "TransportMachine", "GenerationGuard", "TaggedBlock", "InvalidTransitionError",
]
