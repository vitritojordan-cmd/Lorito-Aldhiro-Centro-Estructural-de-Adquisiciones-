"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Exportación: construcción del array de audio, diálogo exportador, orquestación de codecs.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
# GAP-051 (P0.4 de la Orden de Saneamiento, Integración y
# Consolidación): usada en `_build_export_array` para abortar de forma
# explícita ante un segmento truncado, en vez del relleno de silencio
# (o, peor — ver gaps/GAP-051.md — el desplazamiento temporal silencioso
# que el código anterior producía de hecho) que existía antes.
from lorito_aldhiro.backend.errors import SegmentReadError
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb, _status
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.export.lorito_export_integrity import _sha256_file, _validate_export, _write_checksum_file
from lorito_aldhiro.backend.export.lorito_exporters import _EXPORTERS
# GAP-056 (FASE 7, §13): primer corte de extracción del God Object —
# lógica pura (verificación de integridad + texto del spec de sesión)
# sin ninguna dependencia de Qt, extraída de este mismo archivo.
from lorito_aldhiro.backend.export.lorito_export_session_spec import (
    compute_integrity_check, build_session_spec_text,
)
# GAP-071 (FASE 7, §13): tercer corte de extracción del God Object —
# lógica pura de nombrado/formato de exportación (extensión por
# códec, tag/sufijo de velocidad, tag de clips), extraída de
# `_do_export()` en este mismo archivo.
from lorito_aldhiro.backend.export.lorito_export_naming import (
    export_codec_extension, export_speed_filename_tag,
    export_speed_display_suffix, export_clip_tag,
)
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization import _apply_normalization_advanced, _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_v21 import NORM_ITEMS_V21, _dispatch_v21, _soft_limiter_conservative
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image, paint_wood_canvas,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, SignalPulseCell,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




class ExportMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _build_export_array(self, primary_path: str):
        """
        Lee TODOS los segmentos de la sesión y los ensambla en un único array
        numpy float32 estéreo [frames, 2] listo para exportar.

        PATCH 10H+: reemplaza el sf.read() atómico que cargaba toda la sesión
        en RAM de un golpe y solo leía el primer segmento cuando había
        segmentación activa.

        Estrategia de memoria:
          1. Se calculan los frames totales de todos los segmentos sin cargar datos.
          2. Se pre-reserva np.empty((total_frames, 2), dtype=float32) → un solo alloc.
          3. Se copia cada segmento bloque a bloque (STREAM_BLOCK=65536 frames)
             directamente en el destino → sin copias intermedias.

        Para sesiones de 10 h @ 96 kHz estéreo float32:
          total_frames = 10×3600×96000 = 3 456 000 000
          RAM requerida = 3 456 000 000 × 2 × 4 = ~25.9 GB
          El array sigue siendo grande, pero se reserva de una sola vez y se
          rellena sin duplicados. Si no hay RAM suficiente, numpy lanzará
          MemoryError limpiamente (sin colgar el proceso).

        Devuelve (audio_np_float32, samplerate).
        """
        STREAM_BLOCK = 65536  # 65536 frames ≈ 1.37 s @ 48 kHz

        # Recopilar rutas de segmentos — incluye el primario y todos los segmentos extra
        seg_paths = self._engine._disk_writer.get_segment_paths()
        if not seg_paths:
            # Sin segmentación: solo el archivo primario
            seg_paths = [primary_path]
        else:
            # Con segmentación: el listado ya incluye el primario como seg_paths[0]
            # pero si el path_tmp fue reasignado al primer segmento verificamos que
            # primary_path esté dentro de la lista para no duplicarlo.
            if primary_path not in seg_paths:
                # Sesión sin segmentos completados: insertar primario al inicio
                seg_paths = [primary_path] + seg_paths

        # Filtrar segmentos existentes y con contenido
        seg_paths = [p for p in seg_paths
                     if p and os.path.exists(p) and os.path.getsize(p) > 512]
        if not seg_paths:
            return None, 0

        # ── Paso 1: sondear samplerate y contar frames totales ────────────────
        rate = 0
        n_channels = 2
        total_frames = 0
        seg_frames = []  # [(path, frames)] por segmento
        for p in seg_paths:
            try:
                with sf.SoundFile(p, "r") as f:
                    if rate == 0:
                        rate = f.samplerate
                        n_channels = f.channels
                    seg_frames.append((p, f.frames))
                    total_frames += f.frames
            except Exception as e:
                _log.warning("_build_export_array: no pudo sondear %s: %s", p, e)

        if total_frames == 0 or rate == 0:
            return None, 0

        dur_h = total_frames / max(rate, 1) / 3600.0
        ram_gb = total_frames * 2 * 4 / 1e9  # float32 estéreo
        _log.info("_build_export_array: %d segmentos  %.2f h  %.2f GB RAM  %d Hz",
                  len(seg_frames), dur_h, ram_gb, rate)
        if ram_gb > 20.0:
            _log.warning("_build_export_array: sesión muy larga (%.2f GB) — "
                         "asegúrate de tener RAM suficiente", ram_gb)

        # ── Paso 2: pre-reservar array destino ────────────────────────────────
        try:
            audio_out = np.empty((total_frames, 2), dtype=np.float32)
        except MemoryError:
            raise MemoryError(
                f"No hay RAM suficiente para exportar {dur_h:.1f} h de audio "
                f"({ram_gb:.1f} GB requeridos). Considera exportar segmentos "
                f"individuales desde {os.path.dirname(seg_paths[0])}.")

        # ── Paso 3: copiar segmentos bloque a bloque ──────────────────────────
        # GAP-051 (P0.4 de la Orden de Saneamiento, Integración y
        # Consolidación): esta sección reemplaza un defecto real
        # confirmado en esta sesión. El código anterior, ante un
        # `blk.shape[0] < n_read` (lectura corta — el caso real de un
        # segmento truncado por un crash a mitad de captura, MISMO
        # escenario que motivó `SegmentReadError` en la Fase 2 de la
        # Orden de Saneamiento Pre-Auditoría, GAP-034, para el camino
        # streaming), NO lo trataba como error en absoluto: seguía el
        # bucle, la siguiente lectura devolvía un bloque vacío
        # (`blk.shape[0] == 0`), el `break` cortaba el segmento
        # silenciosamente, y el segmento SIGUIENTE se escribía a
        # continuación en `write_pos` — desplazando en el tiempo el
        # resto de la sesión sin ningún aviso ni log. El bloque
        # `except Exception` de abajo (que sí rellenaba con silencio)
        # nunca llegaba a ejecutarse en este escenario porque `wave`/
        # `soundfile` no lanzan excepción ante una lectura corta, solo
        # devuelven menos datos — el mismo hecho ya documentado para
        # el camino streaming en GAP-034. Ambos comportamientos violan
        # P0.4 ("la corrupción de un segmento nunca deberá
        # transformarse silenciosamente en audio válido"); ahora se
        # aborta la exportación completa con un `SegmentReadError`
        # tipificado y estructurado, nombrando el segmento y la
        # posición exactos — igual que ya hace `SegmentProvider.
        # iter_blocks()` desde GAP-034.
        write_pos = 0
        for path, n_frames in seg_frames:
            seg_write_start = write_pos
            try:
                with sf.SoundFile(path, "r") as f:
                    remaining = n_frames
                    while remaining > 0:
                        n_read = min(STREAM_BLOCK, remaining)
                        blk = f.read(n_read, dtype="float32", always_2d=True)
                        actual = blk.shape[0]
                        if actual < n_read:
                            frames_read_seg = (write_pos - seg_write_start) + actual
                            raise SegmentReadError(
                                "EXPORT_ABORT_SEGMENT_READ_ERROR: segmento "
                                f"truncado: '{path}' — el header declara "
                                f"{n_frames} frames pero solo se pudieron "
                                f"leer {frames_read_seg} de los {n_frames} "
                                "esperados en este segmento (faltan "
                                f"{n_frames - frames_read_seg} frames). El "
                                "proceso de captura pudo haberse "
                                "interrumpido antes de cerrar el segmento "
                                "correctamente.",
                                segment_id=path, path=path,
                                frame_start=seg_write_start,
                                frame_count=n_frames)
                        if actual == 0:
                            break
                        # Convertir mono a estéreo si es necesario
                        if blk.shape[1] == 1:
                            blk = np.concatenate([blk, blk], axis=1)
                        elif blk.shape[1] > 2:
                            blk = blk[:, :2]
                        audio_out[write_pos:write_pos + actual] = blk
                        write_pos += actual
                        remaining -= actual
            except SegmentReadError:
                # Nunca silenciar ni "degradar" un segmento truncado —
                # abortar la exportación completa (P0.4). Se relanza
                # sin envolver para preservar el tipo y los campos
                # estructurados; `export()`/`_do_export()` ya tienen un
                # `except RuntimeError` que informa al usuario en vez
                # de dejar un archivo corrupto o desplazado en disco.
                raise
            except Exception as e:
                _log.error("_build_export_array: error leyendo %s: %s", path, e)
                raise SegmentReadError(
                    f"EXPORT_ABORT_SEGMENT_READ_ERROR: fallo leyendo "
                    f"'{path}' ({e.__class__.__name__}: {e}).",
                    segment_id=path, path=path,
                    frame_start=seg_write_start, cause=e) from e

        # Recortar al real escrito (por si algún segmento fue más corto)
        if write_pos < total_frames:
            audio_out = audio_out[:write_pos]

        _log.info("_build_export_array OK: %d frames leídos  %.2f s",
                  len(audio_out), len(audio_out) / max(rate, 1))
        return audio_out, rate
    def _open_lorito_exportador(self):
        """
        Abre "LORITO EXPORTADOR" (§GAP-016) — clon del panel de
        exportación MANUAL de CRAC. Mismo mecanismo real que CRAC: el
        diálogo deja elegir códec/profundidad/normalización/directorio
        antes de disparar la exportación real (`self.export()`), en vez
        de exportar directo con lo que estuviera seleccionado.
        """
        if not (self._disk_tmp_path and os.path.exists(self._disk_tmp_path)
                and os.path.getsize(self._disk_tmp_path) > 512
                and not self._engine.recording):
            QMessageBox.warning(self, "Sin audio", "No hay audio grabado.")
            return
        dlg = LoritoExportadorDialog(self, self)
        dlg.export_requested.connect(self.export)
        dlg.exec()
    def export(self):
        # ══════════════════════════════════════════════════════════════════════
        #  ETAPA 1 — CAPTURAR PARÁMETROS EN EL GUI THREAD (solo lectura widgets)
        # ══════════════════════════════════════════════════════════════════════
        codec    = self.codec_box.currentText()
        opt1_val = self.opt1_box.currentText()
        opt2_val = self.opt2_box.currentText()
        norm_val = self.norm_box.currentText()
        ratio    = self._speed_ratio

        # ── Validación rápida de fuente de audio (GUI thread, sin I/O pesada) ──
        tmp_path = self._disk_tmp_path
        use_disk = (tmp_path and os.path.exists(tmp_path)
                    and os.path.getsize(tmp_path) > 512
                    and not self._engine.recording)
        if not use_disk:
            QMessageBox.warning(self, "Sin audio", "No hay audio grabado."); return

        # ══════════════════════════════════════════════════════════════════════
        #  ETAPA 2 — BLOQUEAR CONTROLES INMEDIATAMENTE (antes de cualquier I/O)
        # ══════════════════════════════════════════════════════════════════════
        # CORRECCIÓN CRÍTICA v0.20: en versiones anteriores _set_ui_state("export")
        # y _sync_buttons() se llamaban DESPUÉS de _build_export_array() y
        # la normalización — que pueden tardar minutos en sesiones largas o con
        # modos de normalización pesados (LUFS, two-pass, presets de cinta).
        # Resultado: la interfaz quedaba bloqueada en "SE PREPARAN A VACIAR"
        # con todos los controles habilitados por tiempo indefinido.
        # Solución: bloquear la UI PRIMERO, luego lanzar el hilo con toda la carga.
        _normalized = (norm_val != "Sin normalizar")
        _CODEC_PREFIX = {
            "WAV":  ("__EXPORT_WAV__",  "LORITO EXPORTANDO WAV"),
            "FLAC": ("__EXPORT_FLAC__", "LORITO EXPORTANDO FLAC"),
            "OGG":  ("__EXPORT_OGG__",  "LORITO EXPORTANDO OGG VORBIS"),
            "WV":   ("__EXPORT_WV__",   "LORITO EXPORTANDO WAVEPACK"),
        }
        _pfx, _label = _CODEC_PREFIX.get(codec, ("__CAROLAMOTION_EXPORT__", f"EXPORTANDO {codec}"))

        self._set_ui_state("export")
        self._sync_buttons()
        # Overlay "Export" en el contómetro — calco exacto de CRAC,
        # genérico sin variante por códec (mismo sistema VFD terso —
        # GAP-010).
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("EXPORT", True, "EXPORT")
        self.status_label.setText(
            "__EXPORT_PREPARING__LORITO SE PREPARA A VACIAR, ESPERA…")
        # WAYLAND-FIX: QApplication.processEvents() puede producir reentrancia
        # no segura en Qt6/Wayland cuando se llama directamente desde un slot.
        # Diferir la exportación un ciclo del event loop garantiza que el repaint
        # del status_label se procese antes de arrancar el hilo de fondo.

        if _normalized:
            self._norm_blink_timer.start()

        # ══════════════════════════════════════════════════════════════════════
        #  ETAPA 3 — HILO BACKGROUND: toda la I/O y el procesamiento pesado
        # ══════════════════════════════════════════════════════════════════════
        # _build_export_array, normalización y resampleo de velocidad se ejecutan
        # DENTRO del hilo — el GUI thread queda libre con controles inhabilitados.
        def _do_export():
            audio = None
            rate  = 44100
            ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
            spd_tag = export_speed_filename_tag(ratio)
            base    = os.path.join(self._export_output_dir, f"aecct2_{ts}{spd_tag}")
            try:
                # ── 3a. Lectura multi-segmento desde disco (PATCH 10H+) ───────
                _bridge.status_msg.emit(
                    "__EXPORT_PREPARING__LORITO SE PREPARA A VACIAR, ESPERA…")
                audio_raw, rate = self._build_export_array(tmp_path)
                if audio_raw is None:
                    raise RuntimeError("_build_export_array devolvió None — sin audio.")

                # ── 3b. Normalización avanzada v0.20/v0.21 ────────────────────
                _norm_mode = NormalizationMode.from_label(norm_val)
                if _norm_mode != NormalizationMode.NONE or norm_val in NORM_ITEMS_V21:
                    _bridge.status_msg.emit(
                        "__EXPORT_PREPARING__LORITO SE PREPARA A VACIAR, ESPERA…")
                    _result_v21 = _dispatch_v21(audio_raw, norm_val, rate)
                    if _result_v21 is not None:
                        audio_raw, _norm_stats = _result_v21
                    else:
                        audio_raw, _norm_stats = _apply_normalization_advanced(
                            audio_raw, _norm_mode, rate)
                    audio_raw, _limiter_stats = _soft_limiter_conservative(audio_raw)
                    _norm_stats["soft_limiter_triggered"]    = _limiter_stats["triggered"]
                    _norm_stats["soft_limiter_reduction_db"] = _limiter_stats["max_reduction_db"]
                    _status.normalization_mode            = norm_val
                    _status.normalization_gain_db         = _norm_stats.get("gain_db", 0.0)
                    _status.normalization_peak_db         = _norm_stats.get("peak_db", 0.0)
                    _status.normalization_lufs            = _norm_stats.get("lufs", float("-inf"))
                    _status.normalization_noise_floor_db  = _norm_stats.get("noise_floor_db", float("-inf"))
                    _status.normalization_true_peak_db    = _norm_stats.get("true_peak_db", 0.0)
                    _status.normalization_stats           = _norm_stats
                    _status.normalization_pre_gain_db     = _norm_stats.get("pre_normalization_gain_db",  0.0)
                    _status.normalization_post_gain_db    = _norm_stats.get("post_normalization_gain_db", 0.0)
                    _status.normalization_mid_rms         = _norm_stats.get("mid_rms",              float("-inf"))
                    _status.normalization_side_rms        = _norm_stats.get("side_rms",             float("-inf"))
                    _status.normalization_stereo_balance  = _norm_stats.get("stereo_balance_index", 0.0)
                    _status.normalization_crest_factor_db = _norm_stats.get("crest_factor_db",      float("inf"))
                    _status.normalization_dynamic_range   = _norm_stats.get("dynamic_range_estimate", 0.0)
                    _status.normalization_histogram_density = _norm_stats.get("histogram_peak_density", 0.0)
                    _status.normalization_silence_ratio   = _norm_stats.get("silence_ratio",          0.0)
                    _status.normalization_auto_mode       = _norm_stats.get("auto_selected_mode",     "")
                    _log.info(
                        "Normalización [%s]: gain=%.2f dB  peak_in=%.2f dBFS"
                        "  lufs=%.2f  noise_floor=%.2f dBFS  true_peak=%.2f dBFS"
                        "  pre_gain=%.2f dB  post_gain=%.2f dB"
                        "  mid_rms=%.2f dBFS  side_rms=%.2f dBFS  sbi=%.3f"
                        "  crest_factor=%.2f dB  dynamic_range=%.1f dB"
                        "  silence_ratio=%.2f  clip_density=%.4f%s",
                        norm_val,
                        _norm_stats.get("gain_db", 0.0),
                        _norm_stats.get("peak_db", 0.0),
                        _norm_stats.get("lufs", float("-inf")),
                        _norm_stats.get("noise_floor_db", float("-inf")),
                        _norm_stats.get("true_peak_db", 0.0),
                        _norm_stats.get("pre_normalization_gain_db",  0.0),
                        _norm_stats.get("post_normalization_gain_db", 0.0),
                        _norm_stats.get("mid_rms",              float("-inf")),
                        _norm_stats.get("side_rms",             float("-inf")),
                        _norm_stats.get("stereo_balance_index", 0.0),
                        (_norm_stats.get("crest_factor_db", float("inf"))
                         if _norm_stats.get("crest_factor_db", float("inf")) != float("inf")
                         else -999.0),
                        _norm_stats.get("dynamic_range_estimate", 0.0),
                        _norm_stats.get("silence_ratio",          0.0),
                        _norm_stats.get("histogram_peak_density", 0.0),
                        (f"  auto_selected={_norm_stats['auto_selected_mode']}"
                         if _norm_stats.get("auto_selected_mode") else ""),
                    )
                else:
                    audio_raw = np.clip(audio_raw.astype(np.float32), -1.0, 1.0)

                # ── 3c. Resampleo por velocidad (si aplica) ───────────────────
                if abs(ratio - 1.0) > 0.0005:
                    _bridge.status_msg.emit(
                        f"__EXPORT_PREPARING__LORITO SE PREPARA A VACIAR, "
                        f"ESPERA… ×{ratio:.2f}")
                    audio = PlaybackEngine._resample_chunk(audio_raw, ratio)
                    del audio_raw
                    # OPT-06: gc.collect() eliminado del path export (bg thread, no RT)
                else:
                    audio = audio_raw
                    audio_raw = None

                # ── 3d. Exportador modular ────────────────────────────────────
                _total_frames = len(audio)
                ext      = export_codec_extension(codec)
                out_path = f"{base}.{ext}"

                _bridge.status_msg.emit(f"{_pfx}{_label}")   # leyenda sin porcentaje [FIX-EXPORT-DLG]
                if _normalized:
                    _bridge.status_msg.emit("__NORM_BLINK_ON__")

                exporter = _EXPORTERS.get(codec)
                if exporter is None:
                    raise ValueError(f"Codec desconocido: {codec}")

                _done_flag = [False]
                _target_sz = max(1, _total_frames * (2 if codec == "WAV" else 1))

                def _progress_monitor():
                    _bridge.export_progress.emit(codec, norm_val, 0)   # abrir diálogo al 0%
                    while not _done_flag[0]:
                        time.sleep(0.4)
                        if _done_flag[0]:
                            break
                        try:
                            if os.path.exists(out_path):
                                cur_sz = os.path.getsize(out_path)
                                pct    = min(99, int(cur_sz / max(_target_sz, 1) * 100))
                                _bridge.export_progress.emit(codec, norm_val, pct)
                        except Exception:
                            pass

                _mon = threading.Thread(target=_progress_monitor, daemon=True,
                                        name="aecct2-export-progress")
                _mon.start()

                result = exporter.export(audio, rate, out_path, opt1_val, opt2_val)
                _done_flag[0] = True
                _bridge.export_progress.emit(codec, norm_val, 100)   # cerrar diálogo [FIX-EXPORT-DLG]

                if not result["ok"]:
                    raise RuntimeError(f"Export {codec} falló: {result['error']}")

                # ── 3e. Validación post-export ────────────────────────────────
                _bridge.status_msg.emit("__EXPORT_VALIDATING_START__")
                _bridge.status_msg.emit(f"__EXPORT_VALIDATING__LORITO CALIFICANDO {codec}…")
                expected_dur = len(audio) / max(rate, 1)
                val = _validate_export(out_path, expected_dur, rate)
                _bridge.status_msg.emit("__EXPORT_VALIDATING_STOP__")
                if not val["ok"]:
                    _log.error("Validación post-export FALLÓ: %s", val["error"])
                    _bridge.status_msg.emit(f"__EXPORT_DESTROYED__😰 LORITO DESTRUIDO: {val['error'][:80]}")
                    return

                # ── 3f. SHA-256 ───────────────────────────────────────────────
                _bridge.status_msg.emit("__EXPORT_CHECKSUM__LORITO CHECKSUM...")
                sha256 = _sha256_file(out_path)
                if sha256:
                    _write_checksum_file(out_path, sha256,
                                         val["actual_dur"], val["actual_frames"])

                # ── 3g. Integridad end-to-end ─────────────────────────────────
                # GAP-056 (FASE 7): lógica de comparación extraída a
                # backend/export/lorito_export_session_spec.py — este bloque
                # solo lee el resultado y conserva los mismos efectos
                # secundarios (log + forense) que antes.
                _status.frames_exported = val["actual_frames"]
                fr = _status.frames_received
                fw = _status.frames_written
                fe = _status.frames_exported
                _integ = compute_integrity_check(fr, fw, fe)
                if not _integ.ok:
                    _log.error("INTEGRIDAD END-TO-END: %s  (fr=%d fw=%d fe=%d)",
                               _integ.summary, fr, fw, fe)
                    _xrun_forensics.record_xrun(
                        f"INTEGRITY_FAIL:{_integ.summary[:40]}",
                        cb_latency_ms=0.0, write_latency_ms=0.0, queue_size=0)
                else:
                    _log.info("Integridad end-to-end OK: fr=%d fw=%d fe=%d", fr, fw, fe)

                # ── 3h. Metadata de clips ─────────────────────────────────────
                clip_data = _clip_log.to_dict()
                if clip_data["total_l"] + clip_data["total_r"] > 0:
                    _log.warning("Sesión con clips: L=%d R=%d",
                                 clip_data["total_l"], clip_data["total_r"])

                # ── 3i. Mensaje final ─────────────────────────────────────────
                out_sz   = val["actual_size"]
                dur_s    = val["actual_dur"]
                spd_info = export_speed_display_suffix(ratio)
                clip_tag = export_clip_tag(clip_data["total_l"], clip_data["total_r"])
                msg = (f"__EXPORT_SAVED__LORITO GUARDÓ: aecct2_{ts}{spd_tag}.{ext}{spd_info}"
                       f"  ({out_sz//1024} KB  {dur_s/60:.1f} min){clip_tag}")
                _log.info("Export completo: %s  %d bytes  %.2f s  sha256=%s...",
                          out_path, out_sz, dur_s, sha256[:16] if sha256 else "?")
                _bridge.status_msg.emit(msg)

                # ── 3i-bis. Imagen espectral post-export (§GAP-016) ────────────
                # "Lorito Exportador" — generador portado de CRAC
                # (crac_export_spectral_engine/render), con la marca de
                # plataforma renombrada y recoloreada (pedido explícito).
                try:
                    from lorito_aldhiro.backend.export.lorito_export_spectral_engine import (
                        compute_spectrogram_rgba,
                    )
                    from lorito_aldhiro.frontend.spectral.lorito_export_spectral_render import (
                        render_spectral_png,
                    )
                    _spec_png_path = f"{base}_spectral.png"
                    _spec_rgba = compute_spectrogram_rgba(audio, rate, win_size=2048)
                    render_spectral_png(
                        _spec_rgba, _spec_png_path,
                        filename=os.path.basename(out_path), codec_name=codec,
                    )
                    _log.info("Imagen espectral generada: %s", _spec_png_path)
                except Exception as _spec_exc:
                    # Nunca perder una exportación ya exitosa por un fallo en
                    # la imagen espectral (mismo criterio que el resto del
                    # pipeline de export — un componente secundario no debe
                    # tumbar el resultado principal).
                    _log.error("Fallo al generar imagen espectral: %s", _spec_exc)

                # ── 3j. Log "Aldhira de Especificación de CRAC" (v0.22.36) ────
                # Archivo de especificaciones técnicas completas de la sesión,
                # incluyendo datos del cuentavueltas según el tipo de cassette.
                # GAP-056 (FASE 7): construcción del texto extraída a
                # backend/export/lorito_export_session_spec.py — este bloque
                # solo lee estado de widgets Qt y arma los argumentos; la
                # lógica de formato en sí (sin Qt) vive en el backend.
                try:
                    _spec_path = f"{base}_aldhira_spec_crac.txt"
                    # Obtener el panel TapeLogPanel activo según la selección actual
                    _tape_lbl_active = self.cassette_dur_box.currentText()
                    _tape_panel_map  = {
                        "C-60":  self.tape_c60,
                        "C-90":  self.tape_c90,
                        "OTROS": self.tape_otros,
                    }
                    _tape_panel = _tape_panel_map.get(_tape_lbl_active)
                    _spec_data  = _tape_panel.get_spec_log_data() if _tape_panel else {}
                    _tape_lbl   = _spec_data.get("tape_label", _tape_lbl_active)
                    _is_otros   = _spec_data.get("is_otros", True)
                    _clip_l     = clip_data.get("total_l", 0)
                    _clip_r     = clip_data.get("total_r", 0)

                    _spec_text = build_session_spec_text(
                        app_brand=APP_BRAND, app_version=APP_VERSION,
                        out_filename=os.path.basename(out_path),
                        timestamp_str=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        tape_label=_tape_lbl, sha256=sha256 or "",
                        codec=codec, rate=rate, duration_s=dur_s, size_bytes=out_sz,
                        total_frames=val['actual_frames'], speed_ratio=ratio,
                        codec_opt1=opt1_val or "", codec_opt2=opt2_val or "",
                        norm_mode_label=_status.normalization_mode or "Sin normalizar",
                        norm_gain_db=_status.normalization_gain_db,
                        norm_peak_db=_status.normalization_peak_db,
                        norm_lufs=_status.normalization_lufs,
                        frames_received=_status.frames_received,
                        frames_written=_status.frames_written,
                        frames_exported=_status.frames_exported,
                        clip_l=_clip_l, clip_r=_clip_r,
                        is_otros=_is_otros, tape_counter_data=_spec_data,
                    )
                    with open(_spec_path, "w", encoding="utf-8") as _sf_spec:
                        _sf_spec.write(_spec_text)
                    _log.info("Aldhira de Especificación de CRAC guardada: %s", _spec_path)
                except Exception as _spec_err:
                    _log.error("No se pudo escribir spec CRAC: %s", _spec_err)

            except RuntimeError as e:
                _log.error("Export RuntimeError: %s", e)
                _bridge.status_msg.emit(f"__ERROR_CAROLA__OYE NO!! EN QUE FALLE?? {str(e)[:120]}")
            except subprocess.CalledProcessError as e:
                err = e.stderr.decode(errors="replace")[:200] if e.stderr else str(e)
                _log.error("Export ffmpeg CalledProcessError: %s", err)
                _bridge.status_msg.emit(f"__ERROR_CAROLA__ERROR ffmpeg: {err[:100]}")
            except subprocess.TimeoutExpired as e:
                cmd_str = " ".join(str(x) for x in (e.cmd or []))[:80]
                _log.error("Export ffmpeg TimeoutExpired (%s s): %s", e.timeout, cmd_str)
                _bridge.status_msg.emit(
                    f"__ERROR_CAROLA__OYE NO!! EN QUE FALLE?? ffmpeg excedió el tiempo máximo ({e.timeout:.0f}s). "
                    f"Audio muy largo o sistema sobrecargado.")
            except Exception as e:
                _log.error("Export excepción inesperada: %s", e, exc_info=True)
                _bridge.status_msg.emit(f"__ERROR_CAROLA__SI TODO ESTABA BIEN 🥺: {str(e)[:100]}")
            finally:
                if audio is not None:
                    del audio
                # OPT-06: gc.collect() eliminado del finally export
                _log.debug("Export finalizado — memoria liberada")
                _bridge.export_progress.emit(codec, norm_val, -1)   # cierra el diálogo en cualquier caso [FIX-EXPORT-DLG]
                _bridge.status_msg.emit("__EXPORT_DONE__")

        # WAYLAND-FIX: diferir el lanzamiento del hilo un ciclo del event loop
        # para que el repaint del status_label se complete antes de arrancar I/O.
        QTimer.singleShot(0, lambda: threading.Thread(
            target=_do_export, daemon=True, name="crac-export"
        ).start())
    @staticmethod
    def _fmt_short(sec):
        return f"{int(sec//60):02d}:{int(sec%60):02d}"
