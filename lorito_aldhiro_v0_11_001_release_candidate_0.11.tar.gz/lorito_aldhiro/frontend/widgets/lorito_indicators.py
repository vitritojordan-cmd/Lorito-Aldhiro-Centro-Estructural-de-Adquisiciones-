from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Panel de indicadores tipo VU/contómetro — celdas de leyenda, VU-meter, reloj digital.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF, QRectF

import math as _math

from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, VFD_GOLD, VFD_GOLD_BRIGHT, VFD_GOLD_DIM, VFD_GOLD_GLOW,
    paint_vfd_glass, paint_vfd_sheen, paint_brushed_aluminum, paint_alu_screw,
)
from lorito_aldhiro.frontend.support.lorito_fonts import font_ui, font_contometro, font_leyendas, font_celdas_compartidas
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget


class LuminousIndicator(QWidget):
    """
    LED indicador parpadeante del lateral del panel de contómetro —
    SEGUNDO rediseño (pedido explícito del usuario, SVG de referencia
    adjunto: lente de cristal tipo joya, bisel de aluminio pulido con
    encastre rebajado, resplandor incandescente y facetas internas).
    Ya NO lleva la etiqueta de texto que tenía debajo (IDLE/REC/BUSY/
    ACT) — el SVG de referencia es una joya de cristal pura, sin
    leyenda, y a este tamaño el texto de 5px apenas se leía; se
    prioriza fidelidad al material de referencia. Tamaño aumentado
    ligeramente (`SIZE` 22→28, pedido explícito) — se reposiciona desde
    `lorito_mw_ui_build.py` para quedar centrado verticalmente en el
    lateral izquierdo del panel fusionado del contómetro
    (`CounterMegapanel`).
    """
    SIZE = 28
    TOTAL_H = SIZE   # ya no hay fila de texto separada — círculo puro

    def __init__(self, parent=None):
        super().__init__(parent)
        self._state    = "standby"
        self._blink_on = True
        self.setFixedSize(self.SIZE, self.TOTAL_H)
        # ── Wayland-safe attributes ───────────────────────────────────────────
        # WA_OpaquePaintEvent=False: composición alpha correcta en Wayland SHM.
        # WA_TranslucentBackground=True: esquinas del círculo transparentes.
        # WA_NoSystemBackground=True: sin relleno de fondo del parent widget.
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)

    def setState(self, s):  self._state = s;    self.update()
    def setBlink(self, b):  self._blink_on = b; self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w = self.width()
        cx = cy = w / 2.0
        R = w / 2.0 - 1.0

        st = THEME["states"].get(self._state, THEME["states"]["standby"])
        base_col = QColor(st["ind"])
        lit = (self._state != "rec") or self._blink_on
        if self._state == "rec" and not self._blink_on:
            base_col = QColor("#3a0000")

        # Anillo exterior de aluminio pulido — bisel (calco de
        # `aluminumBezel` del SVG, colapsado a radial: el widget es un
        # círculo pequeño, no un panel cuadrado donde tenga sentido un
        # gradiente diagonal de varias paradas).
        bezel = QRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 1.6)
        bezel.setColorAt(0.00, QColor(230, 232, 236))
        bezel.setColorAt(0.35, QColor(140, 144, 152))
        bezel.setColorAt(0.65, QColor(90, 92, 98))
        bezel.setColorAt(1.00, QColor(50, 52, 56))
        p.setPen(QPen(QColor(20, 21, 23), 1))
        p.setBrush(QBrush(bezel))
        p.drawEllipse(QPointF(cx, cy), R, R)

        # Encastre interior rebajado (hueco negro) — deja visible el aro
        # de bisel alrededor, calco de `innerBezel`/encastre del SVG.
        R2 = R * 0.78
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(10, 11, 12))
        p.drawEllipse(QPointF(cx, cy), R2, R2)

        R3 = R * 0.64

        # Halo de resplandor (bloom) detrás de la joya, solo si el
        # estado tiene glow y está en fase "encendida" del parpadeo.
        if st["glow"] and lit:
            glow = QRadialGradient(cx, cy, R3 * 1.9)
            gcol = QColor(st["glow"]); gcol.setAlpha(190)
            glow.setColorAt(0.0, gcol)
            glow.setColorAt(1.0, QColor(gcol.red(), gcol.green(), gcol.blue(), 0))
            p.setPen(Qt.NoPen); p.setBrush(QBrush(glow))
            p.drawEllipse(QPointF(cx, cy), R3 * 1.9, R3 * 1.9)

        # Cuerpo de la joya — radial cálido, calco de `jewelGlow` del SVG
        # (blanco→color→oscuro), con una variante "apagada" más plana
        # para cuando el estado no tiene glow o está en la fase oscura
        # del parpadeo de REC.
        jewel = QRadialGradient(cx - R3 * 0.16, cy - R3 * 0.22, R3 * 1.15)
        if lit and st["glow"]:
            jewel.setColorAt(0.00, QColor(255, 255, 255))
            jewel.setColorAt(0.20, base_col.lighter(160))
            jewel.setColorAt(0.60, base_col)
            jewel.setColorAt(1.00, base_col.darker(220))
        else:
            jewel.setColorAt(0.00, base_col.lighter(120))
            jewel.setColorAt(0.35, base_col)
            jewel.setColorAt(1.00, base_col.darker(160))
        p.setPen(QPen(base_col.darker(200), 0.8))
        p.setBrush(QBrush(jewel))
        p.drawEllipse(QPointF(cx, cy), R3, R3)

        # Facetas internas (patrón de diamante, muy sutil) — calco del
        # `<g>` de facetas del SVG, simplificado a 6 radios + un círculo
        # central en vez de los polígonos exactos (a este tamaño de
        # widget los polígonos completos no se distinguirían).
        p.setPen(QPen(QColor(255, 255, 255, 55 if lit else 22), 0.8))
        p.setBrush(Qt.NoBrush)
        for i in range(6):
            a = _math.radians(i * 60)
            p.drawLine(QPointF(cx, cy),
                       QPointF(cx + R3 * 0.92 * _math.cos(a), cy + R3 * 0.92 * _math.sin(a)))
        p.drawEllipse(QPointF(cx, cy), R3 * 0.5, R3 * 0.5)

        # Reflejo especular convexo (highlight elíptico rotado, calco
        # de la elipse blanca del SVG).
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 130 if lit else 55))
        p.save()
        p.translate(cx - R3 * 0.28, cy - R3 * 0.40)
        p.rotate(-24)
        p.drawEllipse(QPointF(0, 0), R3 * 0.50, R3 * 0.24)
        p.restore()

        p.end()


class AluminumTitlePlaque(QWidget):
    """
    Placa de título en aluminio pulido TROQUELADO — pedido explícito del
    usuario tras el rediseño del lienzo a madera vintage marrón (los
    títulos en texto negro plano perdían contraste sobre el marrón
    oscuro nuevo). Reemplaza los `QLabel` de texto negro plano que
    nombran cada widget (título principal, Scrubs, Visor de Señal) por
    una placa de aluminio — MISMO acabado de material que los botones
    de transporte (`LoritoTransportButton`), pero SIN su brillo/
    resplandor 3D (pedido explícito: "de aluminio pulido sin el brillo
    en 3D") — un gradiente plano, mate, pulido. El texto queda
    TROQUELADO directamente sobre el metal (relieve grabado: realce
    claro desplazado arriba-izquierda + sombra oscura desplazada
    abajo-derecha, sin relleno de color plano — el propio metal se lee
    "a través" del corte, como una chapa grabada a presión). Bordes
    redondeados — mismo radio en las cuatro esquinas que el resto de
    biseles metálicos del proyecto (botones/celdas VFD), para que se
    lea como una pieza del mismo juego de materiales, no un elemento
    aislado.
    """

    def __init__(self, text: str = "", parent=None, radius: int = 6,
                 letter_spacing: float = 3.0, font_size: int = 8):
        super().__init__(parent)
        self._text = text
        self._radius = radius
        self._letter_spacing = letter_spacing
        self._font_size = font_size
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

    def setText(self, text: str) -> None:
        self._text = text
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        rect = QRectF(0.5, 0.5, max(1, w - 1), max(1, h - 1))

        # Placa de aluminio pulido MATE — calco de `btn-metal`/
        # `aluminumBezel` del SVG de referencia, pero SIN sus paradas de
        # alto brillo (pedido explícito: "sin el brillo en 3D") — un
        # gradiente vertical claro→medio→oscuro, plano y sobrio.
        grad = QLinearGradient(0, 0, 0, h)
        grad.setColorAt(0.00, QColor(0xc7, 0xca, 0xcf))
        grad.setColorAt(0.45, QColor(0x9a, 0x9e, 0xa5))
        grad.setColorAt(0.55, QColor(0x9a, 0x9e, 0xa5))
        grad.setColorAt(1.00, QColor(0x74, 0x78, 0x7e))
        p.setPen(QPen(QColor(0x45, 0x47, 0x4a), 1))
        p.setBrush(QBrush(grad))
        p.drawRoundedRect(rect, self._radius, self._radius)

        if not self._text:
            p.end()
            return

        fnt = font_ui(size=self._font_size)
        fnt.setBold(True)
        fnt.setPixelSize(self._font_size)
        fnt.setLetterSpacing(QFont.AbsoluteSpacing, self._letter_spacing)
        p.setFont(fnt)
        text_rect = QRect(0, 0, w, h)

        # Troquelado — realce claro (arriba-izquierda) + sombra oscura
        # (abajo-derecha), sin relleno de color plano: imita el texto
        # grabado a presión sobre la chapa de aluminio.
        p.setPen(QColor(255, 255, 255, 130))
        p.drawText(text_rect.translated(0, -1), Qt.AlignCenter, self._text)
        p.setPen(QColor(30, 30, 30, 150))
        p.drawText(text_rect.translated(0, 1), Qt.AlignCenter, self._text)
        p.setPen(QColor(60, 62, 66, 210))
        p.drawText(text_rect, Qt.AlignCenter, self._text)

        p.end()


def _parse_css_color(color: str) -> QColor:
    """Parsea 'rgba(r,g,b,a)' (a en 0..1 o 0..255) o '#rrggbb'/nombre
    Qt — mismo formato de color que usa el registro de overlays de
    CRAC (`mega_panel_text_registry.py`), para poder reutilizar sus
    cadenas literalmente sin reformatearlas a mano."""
    color = color.strip()
    if color.startswith("rgba"):
        nums = color[color.find("(") + 1: color.find(")")].split(",")
        r, g, b = (int(float(x)) for x in nums[:3])
        a_raw = float(nums[3])
        a = int(a_raw * 255) if a_raw <= 1.0 else int(a_raw)
        return QColor(r, g, b, a)
    return QColor(color)


class DigitalClock(QWidget):
    """
    Panel de contómetro principal de Lorito Aldhiro — megacelda del
    contador central, con una fila de 6 celdas invisibles arriba y otra
    de 6 abajo (paridad con CRAC, pedido explícito del usuario — ver
    GAP-010), más 4 celdas verticales invisibles en cada extremo de la
    megacelda (§GAP-015) — sumadas a la celda de esquina de las filas
    superior/inferior que ya tocan ese mismo borde, dan 6 celdas por
    extremo en total. SIN Vitreous Subeventos/logos SVG: solo leyendas
    de texto (mismo patrón "celda invisible" del VFD Display de CRAC).

        ┌──────────────────────────────────────────────┐
        │ DOLBY B  DOLBY C  DOLBY S  DBX  ANRS  S ANRS  │  ← fila superior
        ├──┬────────────────────────────────────────┬──┤
        │L1│                                        │R1│
        │L2│              00:00:00                  │R2│  ← megacelda
        │L3│                                        │R3│
        │L4│                                        │R4│
        ├──┴────────────────────────────────────────┴──┤
        │  DNL    DNR    ALC   ALSA   JACK   C-60       │  ← fila inferior
        └──────────────────────────────────────────────┘

    Es la megacelda IZQUIERDA del panel fusionado (`CounterMegapanel`,
    ver más abajo) — el Media Anim ya NO comparte este widget (antes
    vivía como hijo suyo, en el extremo derecho, empujando las celdas
    R1-R4): ahora vive en su propia megacelda cuadrada hermana.

    La celda final de la fila inferior conmuta su leyenda entre
    "C-60"/"C-90"/"OTROS" según `cassette_dur_box` (ver
    `set_tape_label_cell()`, llamado desde
    `_on_cassette_dur_changed()` en `lorito_main_window.py`).

    Las 8 celdas verticales (L1-L4/R1-R4) quedan como slots vacíos,
    listos para recibir contenido — sin asignación de leyenda todavía
    (pendiente de instrucción explícita, ver GAP-015 §pendiente).
    """

    LEGEND_ROW_H = 12
    SIDE_COL_W = 15   # ancho de cada columna vertical izquierda/derecha

    TOP_CELLS    = [("DOLBY B", "DOLBY_B"), ("DOLBY C", "DOLBY_C"),
                    ("DOLBY S", "DOLBY_S"), ("DBX", "DBX"),
                    ("ANRS", "ANRS"), ("S ANRS", "S_ANRS")]
    BOTTOM_CELLS = [("DNL", "DNL"), ("DNR", "DNR"), ("ALC", "ALC"),
                    ("ALSA", "ALSA"), ("JACK", "JACK"), ("C-60", "TAPE_LABEL")]
    # Columna izquierda (L1-L4, de arriba a abajo, pedido explícito del
    # usuario): LADO A/B (conmuta según el lado de cinta), STEREO, MONO,
    # MON 1/2/3 (1=monitor estéreo normal, 2=monitor mono izquierdo,
    # 3=monitor mono derecho).
    LEFT_CELLS  = ["L1", "L2", "L3", "L4"]
    # Columna derecha (R1-R4): MPX, NORMAL (alterna con CrO2/FeCr/Metal),
    # DITHER (parpadea al seleccionar un maquillador dither — en Lorito
    # Aldhiro vive en la entrada de menú "DSP"), FOCUS.
    RIGHT_CELLS = ["R1", "R2", "R3", "R4"]

    # ── Dorado lumínico (§VFD_GOLD_PALETTE) — TODAS las leyendas del
    # contómetro (arriba/abajo/laterales) comparten el mismo tono dorado
    # lumínico, pedido explícito del usuario; ya no hay color por-token
    # distinto por sistema (Dolby/DBX/ANRS/etc. — eso vivía en
    # `_CELL_LIT_COLOR` antes de este rediseño VFD). Se conserva un único
    # QColor "encendido" vs. un "apagado" (fósforo residual, tenue).
    _CELL_LIT_COLOR_GOLD = QColor(255, 204, 85, 235)
    # FIX-CELL-APAGADO (pedido explícito del usuario): el estado "sin
    # sistema activo" de una celda de leyenda debe leerse como fósforo
    # genuinamente APAGADO (un residuo casi imperceptible, como un
    # segmento VFD real que nunca se encendió), no como una versión
    # "dimmer" a media intensidad del mismo dorado encendido. Antes
    # alpha=46 seguía siendo bien legible; se reduce a un residuo
    # fantasma (alpha=14) para que la diferencia encendido/apagado sea
    # clara de un vistazo, igual que un VFD real.
    _CELL_DIM_COLOR = QColor(255, 204, 85, 14)

    # Categorías de overlay en orden de prioridad — calcado del árbol real
    # de CRAC ("LilyGain > PeaKxtrem > scrub_msg > FnTape Aldh > ITL Flip
    # (FnSide A/B) > SeekYng > VaccUm TP > Expn Signal > SIPActiV > Pause
    # (manual) > Export > H-Dubb/N-Dubb > OvFlow > Side A/B > Auto Pause
    # > ... > NR transitorio > Dolby X > HX Pro"), filtrado a las
    # categorías que Lorito Aldhiro realmente tiene (§GAP-010). La
    # primera con una entrada activa en `_overlay_stack` es la que se
    # muestra; "FNC_NO_DISP" siempre gana (prioridad absoluta en CRAC).
    _CATEGORY_PRIORITY = (
        "FNC_NO_DISP", "SCRUBS", "FN_TAPE_ALDH", "ITL",
        "SIPA", "PAUSE_PHYSICAL", "EXPORT", "OVFLOW_TP", "SIDE_MSG",
        "NR", "EQBIAS", "HX_PRO", "MONITOR", "CAPTURE_MONITOR",
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self._text  = "00:00:00"; self._state = "standby"
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

        # ── Celdas de leyenda (arriba/abajo) — invisibles (sin fondo),
        # solo texto, se iluminan cuando el sistema correspondiente está
        # activo (§GAP-010, paridad con CRAC TOP_ROW_LEGEND_COLORS/
        # BACKEND_LEGEND_COLORS, sin logos SVG). ──────────────────────────
        self._cell_lit: dict[str, bool] = {
            token: False for _, token in (self.TOP_CELLS + self.BOTTOM_CELLS)
        }
        self._tape_label_text = "C-60"

        # ── Celdas verticales de extremo — leyendas fijas pedidas
        # explícitamente por el usuario (columna izquierda: LADO A/B,
        # STEREO, MONO, MON 1/2/3 — columna derecha: MPX, NORMAL/CrO2/
        # FeCr/Metal, DITHER, FOCUS). Arrancan apagadas (fósforo dorado
        # tenue) salvo el estado por defecto razonable de cada una.
        self._side_cell_text: dict[str, str] = {
            "L1": "LADO A", "L2": "STEREO", "L3": "MONO", "L4": "MON 1",
            "R1": "MPX", "R2": "NORMAL", "R3": "DITHER", "R4": "FOCUS",
        }
        self._side_cell_lit: dict[str, bool] = {
            token: False for token in (self.LEFT_CELLS + self.RIGHT_CELLS)
        }
        # Estado por defecto: LADO A encendido, STEREO encendido (modo
        # normal), MON 1 encendido (monitor estéreo normal).
        self._side_cell_lit["L1"] = True
        self._side_cell_lit["L2"] = True
        self._side_cell_lit["L4"] = True
        self._monitor_mode = 1          # 1=estéreo normal, 2=mono izq, 3=mono der
        self._dither_active = False     # True mientras hay un maquillador dither seleccionado
        self._dither_blink_on = True

        # ── Leyendas de DSP de CRAC adaptados (GAP-039/040, pedido
        # explícito del usuario) — "PREVI DSP" reemplaza la leyenda
        # "DOLBY B" mientras algún DSP de PREVI está activo (Cristhi
        # Cosh, etc. — comparten esta única celda, no hay uno por DSP).
        # "FNESP DSP" hace lo mismo en la celda "DOLBY C", pero SI
        # Dolby C real está también activo, ambas leyendas alternan
        # cada ~1s (avanzado por `tick_legend_alternation()`, mismo
        # tick central de 480ms que el resto de parpadeos del panel).
        self._previ_dsp_active = False
        self._fnesp_dsp_active = False
        self._legend_alt_on = True
        self._legend_alt_tick_count = 0

        # ── Leyenda "MUSC EQ" (GAP-043, Muscle Eq Samir) — reemplaza
        # "DOLBY S" en su celda; si Dolby S real también está activo,
        # ambas alternan cada ~1s (orden §19-20, mismo mecanismo ya
        # construido para PREVI DSP/FNESP DSP con Dolby B/C).
        self._muscle_eq_active = False
        self._muscle_eq_alt_on = True
        self._muscle_eq_alt_tick_count = 0

        # ── Overlay general (§GAP-010, generaliza el overlay ITL de
        # GAP-007/008 a múltiples categorías con prioridad) ──────────────
        self._overlay_stack: dict[str, tuple[str, QColor]] = {}
        self._overlay_blink_on = True

        # FIX-OVERLAY-BLINK-AUTOSUFICIENTE (pedido explícito del
        # usuario — auditoría de overlays): antes `_overlay_blink_on`
        # SOLO avanzaba cuando `tickITLOverlayBlink()` era llamado desde
        # afuera, y eso únicamente ocurría durante la auto-pausa por
        # silencio o el desbordamiento de cuentavueltas — es decir,
        # cualquier overlay ajeno a esos dos casos (SCRUBS, SIDE_MSG,
        # FN_TAPE_ALDH, HX_PRO, etc.) dependía de un tick que nunca
        # llegaba mientras esos dos subsistemas estuvieran inactivos.
        # Un widget bien diseñado no depende de que un módulo externo
        # no relacionado recuerde llamarlo: DigitalClock ahora es
        # autosuficiente y trae su propio QTimer de parpadeo a 480ms
        # (mismo intervalo que el resto del panel), activo siempre que
        # haya al menos un overlay armado. Las llamadas externas a
        # `tickITLOverlayBlink()` desde auto-pausa/overflow se retiraron
        # (ver `lorito_mw_silence_autopause.py`) para no duplicar el
        # parpadeo cuando ambos coincidan.
        self._overlay_blink_timer = QTimer(self)
        self._overlay_blink_timer.setInterval(480)
        self._overlay_blink_timer.timeout.connect(self.tickITLOverlayBlink)
        self._overlay_blink_timer.start()

        # Fase de "respiro" fosfórico de las scanlines (§paint_vfd_glass)
        # — avanzada por el panel fusionado dueño (`CounterMegapanel`),
        # NO por un timer propio: las tres megaceldas del panel deben
        # respirar EN FASE, como una sola pieza de vidrio.
        self._breath_phase = 0.0

    def set_breath_phase(self, phase: float) -> None:
        self._breath_phase = phase
        self.update()

    def setText(self, t):  self._text  = t; self.update()
    def setState(self, s): self._state = s; self.update()

    # ── Celdas de leyenda ──────────────────────────────────────────────
    def set_cell_lit(self, token: str, lit: bool) -> None:
        """Enciende/apaga una celda de leyenda por su token (§TOP_CELLS/
        BOTTOM_CELLS). Token desconocido: no-op silencioso (nunca rompe
        el arranque por un nombre mal escrito)."""
        if token in self._cell_lit:
            self._cell_lit[token] = lit
            self.update()

    def set_host_cell(self, backend: str) -> None:
        """ALSA/JACK son mutuamente excluyentes — enciende una, apaga la
        otra (paridad con BACKEND_LEGEND_COLORS de CRAC)."""
        self.set_cell_lit("ALSA", backend == "ALSA")
        self.set_cell_lit("JACK", backend == "JACK")

    def set_tape_label_cell(self, text: str) -> None:
        """Conmuta la leyenda de la celda final de la fila inferior
        entre C-60/C-90/OTROS (pedido explícito del usuario)."""
        self._tape_label_text = text
        self.update()

    def set_side_cell(self, token: str, text: str = "", lit: bool = False) -> None:
        """Asigna texto/estado a una celda vertical de extremo
        (L1-L4/R1-R4, §GAP-015). Token desconocido: no-op silencioso."""
        if token in self._side_cell_text:
            self._side_cell_text[token] = text
            self._side_cell_lit[token] = lit
            self.update()

    # ── Leyendas fijas de columna — helpers de conveniencia ────────────
    def set_tape_side(self, side: str) -> None:
        """L1: conmuta LADO A / LADO B según el lado de cinta activo."""
        side = "B" if str(side).upper().startswith("B") else "A"
        self.set_side_cell("L1", f"LADO {side}", True)

    def set_channel_mode(self, stereo: bool) -> None:
        """L2/L3: STEREO/MONO — exclusión mutua, mismo patrón que
        ALSA/JACK (`set_host_cell`)."""
        self.set_side_cell("L2", "STEREO", stereo)
        self.set_side_cell("L3", "MONO", not stereo)

    def set_monitor_mode(self, mode: int) -> None:
        """L4: MON 1 (monitor estéreo normal) / MON 2 (monitor mono
        izquierdo) / MON 3 (monitor mono derecho)."""
        mode = mode if mode in (1, 2, 3) else 1
        self._monitor_mode = mode
        self.set_side_cell("L4", f"MON {mode}", True)

    def set_tape_type(self, tipo: str) -> None:
        """R2: NORMAL (alterna con CrO2/FeCr/Metal)."""
        self.set_side_cell("R2", tipo.upper(), True)

    def set_mpx_lit(self, lit: bool) -> None:
        """R1: MPX (filtro de piloto estéreo 19kHz)."""
        self.set_side_cell("R1", "MPX", lit)

    def set_focus_lit(self, lit: bool) -> None:
        """R4: FOCUS."""
        self.set_side_cell("R4", "FOCUS", lit)

    def set_dither_active(self, active: bool) -> None:
        """R3: DITHER — parpadea mientras un maquillador dither está
        seleccionado (en Lorito Aldhiro vive en la entrada de menú
        "DSP", a diferencia de CRAC donde vive en Pañalissu). El
        parpadeo real avanza vía `tick_dither_blink()`, llamado desde
        el mismo tick de 480ms que el resto de parpadeos del panel."""
        self._dither_active = active
        if not active:
            self._dither_blink_on = True
        self.set_side_cell("R3", "DITHER", active and self._dither_blink_on)

    def tick_dither_blink(self) -> None:
        if self._dither_active:
            self._dither_blink_on = not self._dither_blink_on
            self.set_side_cell("R3", "DITHER", self._dither_blink_on)

    # ── Leyendas "PREVI DSP"/"FNESP DSP" (GAP-039/040) ──────────────────
    def set_previ_dsp_active(self, active: bool) -> None:
        """Mientras `active`, la celda "DOLBY B" muestra "PREVI DSP" en
        su lugar — compartida por todos los DSP de PREVI (no hay una
        celda por DSP; si más de uno estuviera activo, esta leyenda
        sigue reflejando "hay al menos uno armado")."""
        self._previ_dsp_active = active

    def set_fnesp_dsp_active(self, active: bool) -> None:
        """Mientras `active`, la celda "DOLBY C" muestra "FNESP DSP" —
        si Dolby C real también está activo (`_cell_lit["DOLBY_C"]`),
        ambas leyendas alternan cada ~1s vía `tick_legend_alternation()`."""
        self._fnesp_dsp_active = active
        if not active:
            self._legend_alt_on = True
            self._legend_alt_tick_count = 0

    def tick_legend_alternation(self) -> None:
        """Avanza la alternancia PREVI DSP/FNESP DSP con Dolby B/C —
        llamado desde el mismo tick de 480ms que `tick_dither_blink()`;
        alterna cada 2 llamadas (~960ms, aproxima el "cada segundo"
        pedido por el usuario sin crear un QTimer nuevo)."""
        if not self._fnesp_dsp_active or not self._cell_lit.get("DOLBY_C", False):
            return
        self._legend_alt_tick_count += 1
        if self._legend_alt_tick_count % 2 == 0:
            self._legend_alt_on = not self._legend_alt_on

    # ── Leyenda "MUSC EQ" (GAP-043) ──────────────────────────────────
    def set_muscle_eq_active(self, active: bool) -> None:
        """Mientras `active`, la celda "DOLBY S" muestra "MUSC EQ" —
        si Dolby S real también está activo, ambas alternan cada ~1s
        (orden §19-20)."""
        self._muscle_eq_active = active
        if not active:
            self._muscle_eq_alt_on = True
            self._muscle_eq_alt_tick_count = 0

    def tick_muscle_eq_alternation(self) -> None:
        """Avanza el parpadeo/alternancia de "MUSC EQ" — mismo tick
        central de 480ms que el resto de parpadeos. Dos comportamientos
        distintos (orden §19 vs §20):
        - Muscle Eq Samir activo SOLO (Dolby S real apagado): la
          leyenda "MUSC EQ" PARPADEA (aparece/desaparece) durante la
          actividad del procesador (§19).
        - Muscle Eq Samir Y Dolby S real activos a la vez: la celda
          ALTERNA entre "DOLBY S" y "MUSC EQ" en vez de parpadear
          cada una por separado (§20)."""
        if not self._muscle_eq_active:
            return
        self._muscle_eq_alt_tick_count += 1
        if self._muscle_eq_alt_tick_count % 2 == 0:
            self._muscle_eq_alt_on = not self._muscle_eq_alt_on

    # ── Overlay general (múltiples categorías, con prioridad) ─────────
    def setOverlay(self, category: str, active: bool,
                   text: str = "", color: str = "") -> None:
        """
        Activa/desactiva un overlay en una categoría dada. Varias
        categorías pueden estar "armadas" a la vez (p. ej. SIPA activo
        mientras se arma una EXPORT) — solo se muestra la de mayor
        prioridad (`_CATEGORY_PRIORITY`). Pasar `active=False` retira
        SOLO esa categoría; si había otra por debajo en prioridad, pasa
        a mostrarse automáticamente.
        """
        if active:
            self._overlay_stack[category] = (text, _parse_css_color(color) if color else QColor(255, 255, 255, 220))
        else:
            self._overlay_stack.pop(category, None)
            if not self._overlay_stack:
                # Sin overlays armados: reiniciar la fase de parpadeo a
                # "visible" para que el PRÓXIMO overlay que se active
                # empiece siempre mostrándose, en vez de heredar una
                # fase "apagada" residual del último parpadeo.
                self._overlay_blink_on = True
        self.update()

    def setOverlayFromRegistry(self, category: str, active: bool, token: str | None = None) -> None:
        """Conveniencia: resuelve texto/color desde
        `lorito_overlay_registry.message_for(token)` en vez de pasarlos
        a mano — usado por los disparadores de NR/HX Pro/monitor."""
        if active and token:
            from lorito_aldhiro.backend.export.lorito_overlay_registry import message_for
            text, color = message_for(token)
            self.setOverlay(category, True, text, color)
        else:
            self.setOverlay(category, False)

    def _active_overlay(self) -> tuple[str, QColor] | None:
        for cat in self._CATEGORY_PRIORITY:
            if cat in self._overlay_stack:
                return self._overlay_stack[cat]
        return None

    # ── Compatibilidad retroactiva: la API de GAP-007/008 sigue viva,
    # ahora como delegado de la categoría "ITL" del overlay general. ────
    def setITLOverlay(self, active: bool, text: str = "",
                      color: str = "rgba(80,220,255,200)") -> None:
        self.setOverlay("ITL", active, text, color)

    def tickITLOverlayBlink(self) -> None:
        """Alterna la visibilidad del overlay activo (cualquier
        categoría) — llamado desde el mismo tick de 480ms que ya
        sincroniza pausa/PC/paneles de cinta."""
        if self._overlay_stack:
            self._overlay_blink_on = not self._overlay_blink_on
            self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        row_h = self.LEGEND_ROW_H
        st = THEME["states"].get(self._state, THEME["states"]["standby"])

        # ── Megacelda (LCD del contómetro) — solo en la franja central,
        # entre las dos filas de leyendas. Acabado VFD dorado lumínico de
        # Lorito Aldhiro (§VFD_GOLD_PALETTE): vidrio ahumado negro +
        # scanlines + halo fosfórico, mismo acabado que la nueva
        # megacelda de señal (`SignalPulseCell`, ver más abajo) ──────────
        mc_y, mc_h = row_h, h - 2 * row_h
        paint_vfd_glass(p, QRect(0, mc_y, w, mc_h), radius=10,
                        breath_phase=self._breath_phase, sheen=False)

        # Columnas verticales de extremo (§GAP-015) — reservan SIDE_COL_W
        # a cada lado de la megacelda; el contenido central (dígitos/
        # overlay/animación) se recorta a la franja que queda entre ellas.
        _scw = self.SIDE_COL_W
        p.setPen(QPen(QColor(255,255,255,14), 1))
        p.drawLine(_scw, mc_y + 6, _scw, mc_y + mc_h - 6)
        p.drawLine(w - _scw, mc_y + 6, w - _scw, mc_y + mc_h - 6)
        self._paint_side_column(p, self.LEFT_CELLS, 0, mc_y, _scw, mc_h)
        self._paint_side_column(p, self.RIGHT_CELLS, w - _scw, mc_y, _scw, mc_h)

        # FIX-MEDIA-ANIM-MEGACELDA (rediseño de panel fusionado): el
        # Media Anim YA NO es hijo de DigitalClock — vive en su propia
        # megacelda cuadrada, hermana de esta, dentro del panel
        # fusionado (`CounterMegapanel`, ver más abajo). Antes convivían
        # en el mismo widget con una sola columna de reserva (SIDE_COL_W)
        # entre ambos, lo que hacía que las celdas de leyenda derechas
        # (R1-R4) se extendieran visualmente hacia la zona de dibujo del
        # icono animado. Al separarse en megaceldas propias, el área de
        # contenido central usa el ancho completo entre las dos columnas
        # laterales, sin descontar nada por la animación.
        _content_x0 = _scw
        _content_x1 = w - _scw

        overlay = self._active_overlay()
        if overlay is not None and self._overlay_blink_on:
            ov_text, ov_color = overlay
            # FIX-OVERLAY-FONT (mismo error que CRAC sufrió durante el
            # desarrollo de su VFD display, ya corregido allí con
            # `self._font_family_counter`): los overlays deben usar la
            # MISMA familia tipográfica que los dígitos del contómetro
            # (`font_contometro`), no la de las leyendas fijas
            # (`font_leyendas`) — antes el overlay se veía con una
            # fuente distinta a la del resto del panel.
            fnt_ov = font_contometro(size=0, bold=True)
            fnt_ov.setPixelSize(max(9, int((_content_x1 - _content_x0) / max(1, len(ov_text)) * 1.6)))
            fnt_ov.setLetterSpacing(QFont.AbsoluteSpacing, 1)
            p.setFont(fnt_ov)
            p.setPen(ov_color)
            p.drawText(QRect(_content_x0 + 4, mc_y, _content_x1 - _content_x0 - 8, mc_h),
                      Qt.AlignCenter | Qt.TextWordWrap, ov_text)
        elif overlay is None:
            # Dígitos siempre en dorado lumínico (§VFD_GOLD_PALETTE,
            # pedido explícito del usuario) — con un halo suave detrás
            # para el efecto fosfórico del tubo VFD.
            p.save()
            glow_pen = QPen(QColor(VFD_GOLD_GLOW))
            fnt_glow = font_contometro(size=0, bold=True)
            fnt_glow.setPointSize(36)
            fnt_glow.setLetterSpacing(QFont.AbsoluteSpacing, 2)
            p.setFont(fnt_glow)
            for _dx, _dy in ((1,0),(-1,0),(0,1),(0,-1)):
                p.setPen(glow_pen)
                p.drawText(QRect(_content_x0 + _dx, mc_y + _dy, _content_x1 - _content_x0, mc_h),
                          Qt.AlignCenter, self._text)
            p.restore()
            active_col = QColor(VFD_GOLD_BRIGHT) if self._state in ("rec", "play") else QColor(VFD_GOLD)
            p.setPen(active_col)
            fnt = font_contometro(size=0, bold=True)
            fnt.setPointSize(36)
            fnt.setLetterSpacing(QFont.AbsoluteSpacing, 2)
            p.setFont(fnt)
            # Centrar el texto solo en la franja central (sin solapar
            # ni las columnas laterales ni la animación)
            p.drawText(QRect(_content_x0, mc_y, _content_x1 - _content_x0, mc_h),
                      Qt.AlignCenter, self._text)
        # (si overlay activo pero en el "apagado" del parpadeo: no se dibuja
        # nada en la megacelda ese frame — mismo comportamiento que antes)

        # ── Filas de leyenda (arriba/abajo) — invisibles, solo texto ──────
        self._paint_legend_row(p, self.TOP_CELLS, 0, row_h, w)
        self._paint_legend_row(p, self.BOTTOM_CELLS, mc_y + mc_h, row_h, w)

        p.end()

    def _paint_side_column(self, p: QPainter, tokens, x: int, y: int, col_w: int, col_h: int) -> None:
        """Columna de 4 celdas verticales invisibles (§GAP-015) — slots
        vacíos hasta que se les asigne contenido vía `set_side_cell()`.
        Fuente Utendo (pedido explícito del usuario — celdas
        compartidas del contómetro principal, ver `lorito_fonts.py`)."""
        n = len(tokens)
        cell_h = col_h / n
        fnt = font_celdas_compartidas(size=0, bold=True)
        fnt.setPixelSize(max(6, col_w - 4))
        p.setFont(fnt)
        p.save()
        for i, token in enumerate(tokens):
            text = self._side_cell_text.get(token, "")
            lit = self._side_cell_lit.get(token, False)
            color = self._CELL_LIT_COLOR_GOLD if lit else self._CELL_DIM_COLOR
            p.setPen(color)
            cy = y + int(i * cell_h)
            p.drawText(QRect(x, cy, col_w, int(cell_h)), Qt.AlignCenter | Qt.TextWordWrap, text)
        p.restore()

    def _paint_legend_row(self, p: QPainter, cells, y: int, row_h: int, w: int) -> None:
        """Fila de leyenda superior/inferior — Utendo (pedido explícito
        del usuario, misma familia que `_paint_side_column`: son las
        celdas compartidas del contómetro principal)."""
        n = len(cells)
        cell_w = w / n
        fnt = font_celdas_compartidas(size=0, bold=True)
        fnt.setPixelSize(max(6, row_h - 4))
        p.setFont(fnt)
        for i, (label, token) in enumerate(cells):
            if token == "TAPE_LABEL":
                text = self._tape_label_text
            elif token == "DOLBY_B" and self._previ_dsp_active:
                text = "PREVI DSP"
            elif token == "DOLBY_C" and self._fnesp_dsp_active:
                if self._cell_lit.get("DOLBY_C", False):
                    text = "FNESP DSP" if self._legend_alt_on else "DOLBY C"
                else:
                    text = "FNESP DSP"
            elif token == "DOLBY_S" and self._muscle_eq_active:
                if self._cell_lit.get("DOLBY_S", False):
                    text = "MUSC EQ" if self._muscle_eq_alt_on else "DOLBY S"
                else:
                    text = "MUSC EQ" if self._muscle_eq_alt_on else ""
            else:
                text = label
            lit = self._cell_lit.get(token, False)
            if token == "DOLBY_B" and self._previ_dsp_active:
                lit = True
            if token == "DOLBY_C" and self._fnesp_dsp_active:
                lit = True
            if token == "DOLBY_S" and self._muscle_eq_active:
                lit = True
            color = self._CELL_LIT_COLOR_GOLD if lit else self._CELL_DIM_COLOR
            p.setPen(color)
            p.drawText(QRect(int(i * cell_w), y, int(cell_w), row_h),
                      Qt.AlignCenter, text)


class SignalPulseCell(QWidget):
    """
    Megacelda INFERIOR del panel fusionado del contómetro
    (`CounterMegapanel`) — traza la onda bamboleante. Antes vivía como
    widget HERMANO independiente, con la MISMA altura que la megacelda
    del contómetro (bug reportado por el usuario: panel separado,
    empujando el lienzo de forma anormal); ahora es una megacelda más
    de `CounterMegapanel`, con 1/4 de la altura del bloque superior
    (contómetro + Media Anim) — ver `CounterMegapanel._layout_children()`.
    Mismo acabado VFD (vidrio ahumado negro + scanlines + halo
    fosfórico, vía `paint_vfd_glass`), respirando EN FASE con las otras
    dos megaceldas del panel.

    CONEXIÓN REAL AL MOTOR DE CAPTURA (corregido en esta sesión tras
    instrucción explícita del usuario: "la línea de reacción a la señal
    entrante deberá funcionar de modo real... conectada al motor de
    captura y no como algo estético"). Diseño anterior (GAP-018): un
    QTimer interno hacía avanzar una fase sintética que dibujaba dos
    senoides sumadas, moduladas por el NIVEL RMS — con un "piso de
    movimiento sutil incluso en silencio" que hacía que la línea
    ondulara SIEMPRE, tuviera o no señal real. Eso era, efectivamente,
    una animación decorativa con un volumen real como parámetro, no un
    trazo real de la señal.

    Ahora: `set_samples(mono)` recibe el bloque de muestras CRUDAS real
    del pipeline de captura (`CaptureEngine._monitor_block`, el mismo
    buffer ya usado para los VU meters — ver `lorito_main_window.py::
    _tick()`), y `paintEvent` dibuja esas muestras TAL CUAL (un
    osciloscopio real, no una síntesis). Sin QTimer propio: el trazo
    SOLO se mueve cuando llega un bloque nuevo — silencio real ahora sí
    se ve como una línea plana, no como una ondulación fingida.
    `set_level(l, r)` se conserva como *fallback* únicamente para
    reproducción (el reproductor, `StreamingPlayer`, no expone todavía
    un buffer de muestras crudas — solo VU suavizado, ver GAP de
    referencia) — en ese caso se dibuja una envolvente simple
    proporcional al nivel real, SIN oscilación sintética añadida.
    """

    # FIX-MEGACELDA-INFERIOR (pedido explícito del usuario): la
    # megacelda inferior de la onda bamboleante ya NO lleva ninguna
    # leyenda de texto — antes mostraba "SEÑAL" en la esquina, retirada
    # por completo (la celda queda como osciloscopio puro).

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self._samples: "np.ndarray | None" = None   # bloque crudo real más reciente
        self._level_l = 0.0
        self._level_r = 0.0
        self._breath_phase = 0.0   # avanzada por CounterMegapanel, ver DigitalClock

    def set_breath_phase(self, phase: float) -> None:
        self._breath_phase = phase
        self.update()

    def set_samples(self, mono) -> None:
        """Alimenta el trazo con muestras CRUDAS reales (mono, ya
        mezclado L/R si hace falta) del pipeline de captura — llamado
        desde `lorito_main_window.py::_tick()` con
        `CaptureEngine._monitor_block`. Reemplaza cualquier nivel
        previo de `set_level()` como fuente del trazo mientras haya
        muestras nuevas."""
        self._samples = mono
        self.update()

    def set_level(self, l: float, r: float) -> None:
        """Fallback SOLO para reproducción (sin buffer de muestras
        crudas expuesto todavía por `StreamingPlayer` — ver GAP de
        referencia). Limpia `_samples` para que `paintEvent` sepa que
        debe dibujar la envolvente por nivel, no un trazo de muestras."""
        self._samples = None
        self._level_l = max(0.0, min(1.0, l))
        self._level_r = max(0.0, min(1.0, r))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        rect = QRect(0, 0, w, h)
        paint_vfd_glass(p, rect, radius=10, breath_phase=self._breath_phase, sheen=False)

        mid_y = h * 0.58
        amp_max = h * 0.34
        pts = []

        if self._samples is not None and len(self._samples) > 1:
            # ── Trazo REAL de osciloscopio — muestras crudas del motor
            # de captura, remuestreadas por selección de índice (sin
            # interpolar/inventar valores) a un punto por columna de
            # pantalla, tal como se vería en un osciloscopio real.
            samples = self._samples
            n_src = len(samples)
            n_pts = max(2, int(w))
            peak = 0.0
            for i in range(n_pts):
                idx = min(n_src - 1, int(i * n_src / n_pts))
                v = float(samples[idx])
                peak = max(peak, abs(v))
                x = i
                y = mid_y - v * amp_max
                pts.append(QPointF(x, y))
            level = min(1.0, peak)
        else:
            # ── Fallback SOLO reproducción: envolvente por nivel, sin
            # oscilación sintética (silencio real = línea plana).
            level = max(self._level_l, self._level_r)
            n_pts = max(24, w // 6)
            for i in range(n_pts + 1):
                fx = i / n_pts
                x = fx * w
                # Envolvente simple (medio punto por encima/debajo del
                # centro proporcional al nivel) — no es forma de onda
                # real, es un indicador de nivel honesto (no finge más
                # detalle del que hay disponible).
                y = mid_y - amp_max * level * (1.0 if i % 2 == 0 else -1.0) * 0.5
                pts.append(QPointF(x, y))

        if not pts:
            p.end()
            return

        # Halo (trazo ancho semitransparente) + línea nítida encima —
        # mismo efecto fosfórico que los dígitos del contómetro.
        path = QPainterPath()
        path.moveTo(pts[0])
        for pt in pts[1:]:
            path.lineTo(pt)

        p.setPen(QPen(QColor(VFD_GOLD_GLOW), 5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawPath(path)
        p.setPen(QPen(QColor(VFD_GOLD_BRIGHT if level > 0.05 else VFD_GOLD), 2,
                     Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawPath(path)

        p.end()


class _MediaAnimGlassCell(QWidget):
    """
    Megacelda cuadrada de vidrio VFD (§CounterMegapanel) que aloja el
    Media Anim — mismo acabado `paint_vfd_glass` que las otras dos
    megaceldas del panel fusionado, para que las tres se vean como una
    sola pieza. El Media Anim se centra dentro de ella con un margen
    fijo pequeño, SIEMPRE cuadrado (mismo lado que la celda que lo
    aloja) — corrige el bug reportado de un tamaño aproximado que
    hacía que el icono se viera desbordado o recortado.
    """

    PAD = 8   # margen entre el vidrio de la celda y el Media Anim

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.anim = MediaAnimWidget(self)
        self._breath_phase = 0.0

    def set_breath_phase(self, phase: float) -> None:
        self._breath_phase = phase
        self.update()

    def resizeEvent(self, event):
        side = max(10, min(self.width(), self.height()) - 2 * self.PAD)
        x = (self.width() - side) // 2
        y = (self.height() - side) // 2
        self.anim.setGeometry(x, y, side, side)
        super().resizeEvent(event)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        paint_vfd_glass(p, QRect(0, 0, self.width(), self.height()),
                        radius=10, breath_phase=self._breath_phase, sheen=False)
        p.end()


class _GlassSheenOverlay(QWidget):
    """
    Cobertor vítreo ÚNICO del panel fusionado (§CounterMegapanel) —
    corrección explícita del usuario tras el primer rediseño: "las 3
    megaceldas deben ser cubiertas por el mismo cobertor vítreo... de
    manera tal que todo el conjunto parezca una sola pantalla". Antes
    cada megacelda (`DigitalClock`, `_MediaAnimGlassCell`,
    `SignalPulseCell`) pintaba su propio reflejo diagonal por separado
    — visualmente eran tres piezas de vidrio independientes en vez de
    una sola. Este widget se superpone POR ENCIMA de las tres (se crea
    último, así que nace ya en la cima del orden Z de `CounterMegapanel`)
    y pinta un único `paint_vfd_sheen()` recortado al contorno exterior
    completo del panel — el reflejo cruza los separadores blancos
    igual que cruzaría el vidrio de una sola pantalla física.

    Transparente a eventos de ratón: es puramente decorativo, nunca
    debe interceptar clics/arrastres destinados a los widgets que
    cubre.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self._radius = 12

    def set_radius(self, radius: int) -> None:
        self._radius = radius

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        paint_vfd_sheen(p, QRect(0, 0, self.width(), self.height()), radius=self._radius)
        p.end()


class CounterMegapanel(QWidget):
    """
    Panel fusionado del contómetro principal de Lorito Aldhiro —
    rediseño pedido explícito del usuario, UNA SOLA PIEZA física (mismo
    criterio de fusión que usa el VFD Display de CRAC): un widget padre
    con bordes redondeados y un marco BLANCO decorativo exterior, que
    aloja tres megaceldas:

      · IZQUIERDA (rectangular) — `DigitalClock`: contómetro central +
        las filas/columnas de leyenda ya existentes (sin cambios en su
        estructura interna, solo en su ancho: ya no comparte espacio
        con el Media Anim).
      · DERECHA (cuadrada perfecta) — `_MediaAnimGlassCell`, que aloja
        el `MediaAnimWidget`, ahora en su propia megacelda dedicada, sin
        desbordar ni verse recortada.
      · INFERIOR — `SignalPulseCell` (onda bamboleante, sin leyenda),
        con 1/4 de la altura de las megaceldas superiores.

    Separadores BLANCOS entre las tres (vertical entre izquierda/
    derecha, horizontal entre el bloque superior y el inferior) —
    pedido explícito del usuario, mismo criterio que el marco. Las tres
    megaceldas respiran EN FASE (mismo `breath_phase`, avanzado por un
    único QTimer de este panel) para que el efecto fosfórico se vea
    como el de una sola pieza de vidrio, no tres independientes.

    Geometría — fórmula cerrada (nunca iterativa, mismo criterio ya
    establecido en este proyecto para evitar recalcular por tanteo):
    dado el alto total `h` del panel,
        TOP_H = (h - SEP - 2*BORDER) / 1.25
        BOTTOM_H = TOP_H / 4
    de modo que  2*BORDER + TOP_H + SEP + BOTTOM_H == h  exactamente.
    El lado del cuadrado derecho es TOP_H (la altura completa de la
    megacelda izquierda); con un margen de seguridad para nunca
    quitarle a la izquierda más del 45% del ancho disponible (nunca
    debería activarse con las proporciones reales del panel, pero
    evita una megacelda izquierda ilegible si el panel se usara alguna
    vez con un ancho anormalmente angosto).
    """

    BORDER = 3            # grosor del marco blanco exterior
    SEP    = 3             # grosor de los separadores blancos internos
    BREATH_INTERVAL_MS = 60
    BREATH_STEP = 0.05

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

        self.digital_clock = DigitalClock(self)
        self.media_anim_glass = _MediaAnimGlassCell(self)
        self.signal_pulse = SignalPulseCell(self)
        # Creado AL FINAL a propósito: en Qt, el último hijo creado nace
        # en la cima del orden Z entre hermanos — así el cobertor vítreo
        # único queda por encima de las tres megaceldas sin necesitar
        # raise_() explícito (se llama de todas formas en
        # `_layout_children()`, por robustez ante reordenamientos).
        self._sheen = _GlassSheenOverlay(self)

        self._breath_phase = 0.0
        self._breath_timer = QTimer(self)
        self._breath_timer.setInterval(self.BREATH_INTERVAL_MS)
        self._breath_timer.timeout.connect(self._tick_breath)
        self._breath_timer.start()

    @property
    def media_anim(self) -> MediaAnimWidget:
        return self.media_anim_glass.anim

    def _tick_breath(self) -> None:
        self._breath_phase += self.BREATH_STEP
        self.digital_clock.set_breath_phase(self._breath_phase)
        self.signal_pulse.set_breath_phase(self._breath_phase)
        self.media_anim_glass.set_breath_phase(self._breath_phase)

    def resizeEvent(self, event):
        self._layout_children()
        super().resizeEvent(event)

    def _layout_children(self) -> None:
        w, h = self.width(), self.height()
        B, S = self.BORDER, self.SEP

        top_h = max(60, int((h - S - 2 * B) / 1.25))
        bottom_h = max(10, h - 2 * B - S - top_h)

        square_side = min(top_h, max(60, int(w * 0.45)))
        left_w = max(10, w - 2 * B - S - square_side)

        self.digital_clock.setGeometry(B, B, left_w, top_h)
        self.media_anim_glass.setGeometry(B + left_w + S, B, square_side, top_h)
        self.signal_pulse.setGeometry(B, B + top_h + S, w - 2 * B, bottom_h)

        # Cobertor vítreo único — cubre TODO el rectángulo interior que
        # agrupa las tres megaceldas (mismo contorno redondeado que el
        # marco blanco exterior, ligeramente adentro de él), por encima
        # de las tres, como una sola pantalla física.
        self._sheen.setGeometry(B, B, w - 2 * B, h - 2 * B)
        self._sheen.set_radius(10)
        self._sheen.raise_()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        B, S = self.BORDER, self.SEP

        # Marco BLANCO decorativo exterior (pedido explícito del
        # usuario, mismo criterio que el VFD Display de CRAC).
        p.setPen(QPen(QColor(255, 255, 255, 235), B))
        p.setBrush(Qt.NoBrush)
        _half = B / 2.0
        p.drawRoundedRect(QRectF(_half, _half, w - B, h - B), 12, 12)

        # Separador vertical blanco entre la megacelda izquierda y la
        # megacelda cuadrada del Media Anim.
        sep_x = self.media_anim_glass.x() - S // 2 - 1
        top_h = self.digital_clock.height()
        p.setPen(QPen(QColor(255, 255, 255, 210), S))
        p.drawLine(sep_x, B + 4, sep_x, B + top_h - 4)

        # Separador horizontal blanco entre el bloque superior y la
        # megacelda inferior de la onda bamboleante.
        sep_y = self.signal_pulse.y() - S // 2 - 1
        p.drawLine(B + 4, sep_y, w - B - 4, sep_y)
        p.end()


class VitrifiedMegapanel(QWidget):
    """
    Fondo compartido "vitrificado" para fusionar visualmente varios
    paneles en un solo Megapanel (pedido explícito del usuario: fusionar
    el panel de logs, el de duración de cinta y la forma de onda —
    mismo criterio de fusión que CRAC usa para su vista de onda + celda
    Carolaventos + Status Display, no disponible en el tarball de esta
    sesión, así que se reconstruye aquí un acabado equivalente propio:
    una sola placa de cristal ahumado detrás de los tres paneles, en vez
    de tres fondos independientes).

    Este widget NO reemplaza ni repinta el contenido de los paneles que
    fusiona — se coloca detrás de ellos (`.lower()`) cubriendo su
    extensión conjunta; cada panel hijo conserva su propia lógica y
    pintado intactos, solo se les retira su fondo individual opaco
    (ver `lorito_main_window.py`) para que se vea el cristal común.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()

        g = QLinearGradient(0, 0, 0, h)
        g.setColorAt(0.0, QColor(26, 22, 16, 235))
        g.setColorAt(1.0, QColor(14, 12, 8, 235))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(g))
        p.drawRoundedRect(0, 0, w, h, 12, 12)

        # Sheen superior vitreo
        sheen = QLinearGradient(0, 0, 0, h * 0.4)
        sheen.setColorAt(0.0, QColor(255, 220, 160, 22))
        sheen.setColorAt(1.0, QColor(255, 220, 160, 0))
        p.setBrush(QBrush(sheen))
        p.drawRoundedRect(0, 0, w, int(h * 0.4), 12, 12)

        # Borde dorado tenue — misma familia cromática que el VFD
        p.setPen(QPen(QColor(255, 204, 85, 55), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(0, 0, w - 1, h - 1, 12, 12)
        p.end()


class VUMeterChassis(QWidget):
    """
    Coraza de aluminio pulido de la zona de VU meters — pedido explícito
    del usuario ("estos deben estar sobre una coraza de aluminio pulido
    con los indicadores de nivel y denominación rodeado también con
    acabado de aluminio troquelado"). Se pinta detrás de todo lo demás
    de su columna de VU (encabezado, escala de dB, `VUBar`, etiquetas
    L/R — todos ellos hijos de la ventana, no de esta coraza, colocados
    encima con la misma geometría de siempre) mediante orden de
    creación (nace primero → queda detrás): una placa de aluminio
    pulido cepillado exterior — corrección posterior del usuario:
    MISMO acabado detallado que `AluminumChassisPanel` (microrayado,
    reflejo especular, viñeteado, doble bisel — vía
    `paint_brushed_aluminum()`, no ya el gradiente plano de la primera
    versión) — con una ventana rebajada oscura en el centro donde viven
    los números de la escala y las barras — así el VU meter en sí queda
    legible sobre fondo oscuro (el color rojo/ámbar/verde de la escala
    es funcional, no debe competir con el aluminio claro) y el conjunto
    se lee como un instrumento empotrado en metal, no como texto
    flotando sobre el lienzo.
    """

    def __init__(self, parent=None, radius: int = 8):
        super().__init__(parent)
        self._radius = radius
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        rect = QRectF(0.5, 0.5, max(1, w - 1), max(1, h - 1))

        # Placa exterior — MISMO acabado de aluminio cepillado detallado
        # que `AluminumChassisPanel` y las placas de título (pedido
        # explícito del usuario: "los vumeters digitales también
        # deberán contar con el mismo acabado de aluminio detallado en
        # el código").
        paint_brushed_aluminum(p, rect, radius=self._radius)

        # Ventana rebajada oscura — encastre para la escala/barras,
        # calco de `recess-grad` del SVG de referencia de los botones.
        pad = 6
        rwin = QRectF(pad, pad, max(1, w - 2*pad), max(1, h - 2*pad))
        recess = QLinearGradient(0, rwin.top(), 0, rwin.bottom())
        recess.setColorAt(0.00, QColor(0x08, 0x08, 0x09))
        recess.setColorAt(0.20, QColor(0x12, 0x13, 0x15))
        recess.setColorAt(0.80, QColor(0x1a, 0x1c, 0x1e))
        recess.setColorAt(1.00, QColor(0x2d, 0x30, 0x35))
        p.setPen(QPen(QColor(0x0d, 0x0e, 0x0f), 2))
        p.setBrush(QBrush(recess))
        p.drawRoundedRect(rwin, self._radius - 3, self._radius - 3)
        p.setPen(QPen(QColor(0x4f, 0x53, 0x59, 100), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(rwin.adjusted(1, 1, -1, -1), self._radius - 4, self._radius - 4)

        p.end()


class AluminumChassisPanel(QWidget):
    """
    Placa única de aluminio pulido que fusiona en una sola pieza física
    los paneles de Scrubs, Visor de Señal (forma de onda), panel de
    logs (`StatusDisplay`) y panel de duración de cinta — pedido
    explícito del usuario ("a diferencia de CRAC... Lorito Aldhiro es
    más orientado a acabado vintage con panel fosfórico, vumeters
    digitales y acabado en madera y aluminio, une los paneles log,
    duración de cinta, forma de onda, Scrubs en una sola placa de
    aluminio pulido"). Se coloca DETRÁS de esos widgets (nace primero
    en `lorito_mw_ui_build.py`, antes de `scrub_title`) — cada uno de
    ellos conserva su propio fondo oscuro (VFD/recesado), que ahora se
    lee como una "ventana" empotrada en esta placa, mismo lenguaje
    visual que `VUMeterChassis` con su escala de dB. El acabado —
    `paint_brushed_aluminum()` — es EXACTAMENTE el mismo que usan
    `VUMeterChassis` y (opcionalmente) `AluminumTitlePlaque`, para que
    todo el conjunto se lea como una sola familia de material.

    Tornillos Allen en las 4 esquinas — pedido explícito: "los
    tornillos también deberán ubicarse en los extremos del inicio del
    revestimiento" — se dibujan en las 4 esquinas de ESTA placa (el
    "inicio del revestimiento" del conjunto fusionado), vía
    `paint_alu_screw()`, calco directo del SVG de referencia.
    """

    def __init__(self, parent=None, radius: int = 10, screw_r: float = 7.0):
        super().__init__(parent)
        self._radius = radius
        self._screw_r = screw_r
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        rect = QRectF(0.5, 0.5, max(1, w - 1), max(1, h - 1))

        paint_brushed_aluminum(p, rect, radius=self._radius)

        # Tornillos en las 4 esquinas — "extremos del inicio del
        # revestimiento" (pedido explícito del usuario), con el mismo
        # margen de inserción que usa el SVG de referencia (~3.2% del
        # lado) para que no queden pegados al borde ni demasiado
        # adentro.
        m = max(self._screw_r + 3, min(w, h) * 0.032 + self._screw_r)
        paint_alu_screw(p, m, m, self._screw_r)
        paint_alu_screw(p, w - m, m, self._screw_r)
        paint_alu_screw(p, m, h - m, self._screw_r)
        paint_alu_screw(p, w - m, h - m, self._screw_r)

        p.end()


class VUBar(QWidget):
    # Caída de nivel: 0.012/tick a 24 fps ≈ lenta y cinematográfica
    # (antes 0.018 calibrado para 30fps; a 15Hz efectivos era demasiado brusco)
    DECAY_STEP  = 0.012
    # Peak-hold: mantener 72 ticks (~3s a 24fps) antes de caer
    PEAK_HOLD   = 72
    # Caída del peak: 0.003/tick — muy lenta, analógica
    PEAK_DECAY  = 0.003

    def __init__(self, parent=None):
        super().__init__(parent)
        self._val_l = 0.0; self._val_r = 0.0
        self._pk_l  = 0.0; self._pk_r  = 0.0
        self._ph_l  = 0;   self._ph_r  = 0
        # Alpha de la marca peak (fade-out tras caída)
        self._pk_alpha_l = 0; self._pk_alpha_r = 0
        # ── Wayland-safe: WA_TranslucentBackground + WA_NoSystemBackground ──
        # Correcto en Wayland nativo: el compositor gestiona la alpha de la
        # subsurface. WA_OpaquePaintEvent=False: paintEvent dibuja todo.
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)

    def setValues(self, l: float, r: float):
        """Actualiza estado interno del VU meter. NO llama update().

        WAYLAND-NATIVE: update() se invoca exclusivamente desde
        _tick_vu_redraw() en el GUI timer (15 Hz) o desde _on_vu_ready()
        que recibe la señal vu_ready ya en el main thread.
        Esto garantiza que QWaylandShmBackingStore::flush solo ocurre
        desde el GUI thread — cero crashes en pintado concurrente.
        """
        def upd(val, pk, ph, pka):
            val = max(0., min(1., val))
            if val >= pk:
                pk = val; ph = self.PEAK_HOLD; pka = 255
            else:
                ph -= 1
                if ph <= 0:
                    pk = max(pk - self.PEAK_DECAY, val)
                    pka = max(0, int(255 * pk))
            return val, pk, ph, pka
        self._val_l, self._pk_l, self._ph_l, self._pk_alpha_l = upd(
            l, self._pk_l, self._ph_l, self._pk_alpha_l)
        self._val_r, self._pk_r, self._ph_r, self._pk_alpha_r = upd(
            r, self._pk_r, self._ph_r, self._pk_alpha_r)
        # ── NO self.update() aquí — ver docstring ────────────────────────

    def decay(self):
        def dec(val, pk, ph, pka):
            val = max(0., val - self.DECAY_STEP)
            ph -= 1
            if ph <= 0:
                pk  = max(0., pk - self.PEAK_DECAY)
                pka = max(0, int(255 * pk))
            return val, pk, ph, pka
        self._val_l, self._pk_l, self._ph_l, self._pk_alpha_l = dec(
            self._val_l, self._pk_l, self._ph_l, self._pk_alpha_l)
        self._val_r, self._pk_r, self._ph_r, self._pk_alpha_r = dec(
            self._val_r, self._pk_r, self._ph_r, self._pk_alpha_r)
        self.update()

    def _draw_bar(self, p, x, y, bw, bh, val, pk, pk_alpha):
        # Fondo redondeado igual al resto de paneles
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(6, 6, 6, 230))
        p.drawRoundedRect(x, y, bw, bh, 5, 5)

        # Relleno de nivel con clip path redondeado
        fh = int(bh * val)
        if fh > 0:
            g = QLinearGradient(0, y + bh, 0, y)
            g.setColorAt(0.00, QColor(THEME["vu_green"]).darker(150))
            g.setColorAt(0.50, QColor(THEME["vu_green"]))
            g.setColorAt(0.72, QColor(THEME["vu_yellow"]))
            g.setColorAt(0.84, QColor(THEME["vu_red"]).lighter(130))
            g.setColorAt(1.00, QColor(THEME["vu_red"]))
            # Clip redondeado para que el relleno respete las esquinas
            path = QPainterPath()
            path.addRoundedRect(x, y, bw, bh, 5, 5)
            p.save()
            p.setClipPath(path)
            p.fillRect(x, y + bh - fh, bw, fh, QBrush(g))
            p.restore()

        # Líneas de escala semitransparentes
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(QPen(QColor(0, 0, 0, 55), 1))
        for i in range(1, 10):
            ly = y + int(bh * i / 10)
            p.drawLine(x + 2, ly, x + bw - 2, ly)

        # Borde exterior redondeado (igual al estilo de otros paneles)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(QPen(QColor(255, 255, 255, 18), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(x, y, bw - 1, bh - 1, 5, 5)

        # Marca peak-hold cinematográfica
        if pk > 0.02 and pk_alpha > 0:
            py = y + int(bh * (1.0 - pk))
            # Determinar color de la marca según zona
            if pk > 0.84:
                pk_rgb = QColor(THEME["vu_red"]).lighter(130)
            elif pk > 0.72:
                pk_rgb = QColor(THEME["vu_yellow"])
            else:
                pk_rgb = QColor(THEME["vu_green"])
            pk_rgb.setAlpha(pk_alpha)
            # Línea principal
            p.setPen(QPen(pk_rgb, 2, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(x + 2, py, x + bw - 3, py)
            # Pequeño halo difuso encima/abajo
            halo = QColor(pk_rgb); halo.setAlpha(pk_alpha // 4)
            p.setPen(QPen(halo, 1))
            p.drawLine(x + 2, py - 1, x + bw - 3, py - 1)
            p.drawLine(x + 2, py + 1, x + bw - 3, py + 1)

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height(); gap = 6; bw = (w - gap) // 2
        # FIX-VU-BLACK-RECT (v0.22.02): CompositionMode_Clear sobre un widget con
        # WA_TranslucentBackground produce un rectángulo negro opaco cuando el padre
        # no tiene composición real (LoritoAldhiroStudio es un QWidget sólido).
        # Se elimina el paso Clear; _draw_bar ya pinta su propio fondo redondeado
        # oscuro semitransparente que cubre el área correctamente sin cuadrado negro.
        self._draw_bar(p, 0,       0, bw, h, self._val_l, self._pk_l, self._pk_alpha_l)
        self._draw_bar(p, bw + gap, 0, bw, h, self._val_r, self._pk_r, self._pk_alpha_r)
        # Glow analógico en bordes: intensidad proporcional al RMS
        _rms = max(self._val_l, self._val_r)
        if _rms > 0.05:
            _ga = int(min(52, _rms * 90))
            if _rms > 0.72:
                _gc = QColor(int(THEME["vu_red"][1:3],16),
                             int(THEME["vu_red"][3:5],16),
                             int(THEME["vu_red"][5:7],16), _ga)
            elif _rms > 0.42:
                _gc = QColor(int(THEME["vu_yellow"][1:3],16),
                             int(THEME["vu_yellow"][3:5],16),
                             int(THEME["vu_yellow"][5:7],16), _ga)
            else:
                _gc = QColor(int(THEME["vu_green"][1:3],16),
                             int(THEME["vu_green"][3:5],16),
                             int(THEME["vu_green"][5:7],16), _ga)
            p.setBrush(Qt.NoBrush)
            for _off in (2, 1):
                _alpha = _ga * (2 - _off) // 2
                _gc.setAlpha(_alpha)
                p.setPen(QPen(_gc, 1))
                p.drawRoundedRect(-_off, -_off, w + _off*2 - 1, h + _off*2 - 1, 5 + _off, 5 + _off)
        p.end()
