from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Barras de scrub/velocidad interactivas de la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.capture.lorito_forensics import _frn_emit
from lorito_aldhiro.frontend.support.lorito_theme import THEME



# ═════════════════════════════════════════════════════════════════════════════
#  ScrubBarPlay  —  barra de posición 0..1
# ═════════════════════════════════════════════════════════════════════════════

class ScrubBarPlay(QWidget):
    """
    Barra de scrub de posición de reproducción.

    Señales (callbacks):
      onSeek(pct: float)    — llamado en mousePressEvent y mouseMoveEvent
      onRelease(pct: float) — llamado en mouseReleaseEvent

    El handler de onSeek usa seek_to() interno (sin reiniciar el stream).
    El handler de onRelease usa play_audio() solo si Δpos > 0.5% (FIX-5).
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._value  = 0.0
        self._enabled = False
        self._drag   = False
        self._dimmed = False
        self.setFixedHeight(24)
        self.onSeek    : Optional[Callable] = None
        self.onRelease : Optional[Callable] = None

    # ── API ───────────────────────────────────────────────────────────────────

    def setValue(self, v: float) -> None:
        self._value = max(0.0, min(1.0, v))
        self.update()

    def setEnabled(self, e: bool) -> None:
        self._enabled = e
        self.setCursor(Qt.PointingHandCursor if e else Qt.ArrowCursor)
        self.update()

    def setDimmed(self, d: bool) -> None:
        """Atenúa visualmente durante grabación, sin afectar la lógica."""
        if self._dimmed != d:
            self._dimmed = d
            self.update()

    # ── Geometría ─────────────────────────────────────────────────────────────

    def _pct(self, x: float) -> float:
        pad = 10; uw = self.width() - pad * 2
        return max(0.0, min(1.0, (x - pad) / max(uw, 1)))

    # ── Eventos de ratón ─────────────────────────────────────────────────────

    def mousePressEvent(self, e):
        if not self._enabled: return
        self._drag   = True
        self._value  = self._pct(e.position().x())
        self.update()
        if self.onSeek: self.onSeek(self._value)

    def mouseMoveEvent(self, e):
        if not self._drag: return
        self._value = self._pct(e.position().x())
        self.update()
        if self.onSeek: self.onSeek(self._value)

    def mouseReleaseEvent(self, e):
        if not self._drag: return
        self._drag  = False
        self._value = self._pct(e.position().x())
        self.update()
        if self.onRelease: self.onRelease(self._value)

    def mouseDoubleClickEvent(self, _):
        """
        FIX-SCRUB-DOUBLE-RESET (v0.22.43): doble clic en cualquier punto del
        scrub de reproducción retorna la posición al inicio (0.0).
        Se emite onRelease(0.0) para que el studio arranque desde 0 si hay
        player activo, o posicione el scrub en 0 si estaba detenido.
        """
        if not self._enabled: return
        self._drag  = False
        self._value = 0.0
        self.update()
        if self.onRelease: self.onRelease(0.0)

    # ── Paint ─────────────────────────────────────────────────────────────────

    def paintEvent(self, _):
        # Importar THEME en runtime (ya existe en el monolito al momento del paint)
        try:
            _th = THEME
            br  = _th["bright"]
            ac  = _th["accent"]
            mid = _th["mid"]
        except Exception:
            br  = (180, 180, 220); ac  = (120, 160, 255); mid = (80, 80, 100)

        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h   = self.width(), self.height()
        vivid  = not self._dimmed

        # ── Rediseño con referencia SVG del usuario (fader horizontal de
        # placa oscura + ranura central + marcas de graduación + cap
        # metálico rectangular) — longitud reacondicionada dinámicamente
        # al ancho real del widget (nunca al viewBox fijo del SVG) para
        # conservar la proporción/comportamiento exacto de arrastre.
        pad = 12
        tw  = w - pad * 2
        cy  = h // 2

        # Placa de fondo del fader
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 70 if vivid else 24), 1.5))
        p.setBrush(QColor(28, 28, 28, 220 if vivid else 90))
        p.drawRoundedRect(2, 2, w - 4, h - 4, 5, 5)

        # Marcas de graduación superiores (9, como el SVG de referencia)
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 100 if vivid else 30), 1))
        for i in range(9):
            fx = i / 8.0
            tx_mark = pad + tw * fx
            tick_h = 5 if i in (0, 4, 8) else 3
            p.drawLine(int(tx_mark), 4, int(tx_mark), 4 + tick_h)

        # Ranura central (slot por donde corre el control)
        slot_h = max(4, h // 6)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(10, 10, 10, 230 if vivid else 90))
        p.drawRoundedRect(pad, cy - slot_h // 2, tw, slot_h, 2, 2)

        # Fill cromático hasta la posición actual, dentro de la ranura
        fw = int(tw * self._value)
        if fw > 0:
            a0 = 220 if self._drag else 180
            a1 = 255 if self._drag else 220
            g  = QLinearGradient(pad, 0, pad + tw, 0)
            g.setColorAt(0.0, QColor(int(ac[0]*0.6), int(ac[1]*0.6),
                                     int(ac[2]*0.6), a0 if vivid else 40))
            g.setColorAt(1.0, QColor(int(min(255, ac[0]*1.2)),
                                     int(min(255, ac[1]*1.1)),
                                     int(min(255, ac[2]*1.3)), a1 if vivid else 50))
            p.setBrush(QBrush(g))
            p.drawRoundedRect(pad, cy - slot_h // 2, fw, slot_h, 2, 2)

        # ── Cap / thumb metálico rectangular (calco del SVG: cuerpo
        # exterior oscuro + parte superior metálica clara + línea
        # indicadora central vertical) ───────────────────────────────
        tx = pad + int(tw * self._value)
        cap_w = max(14, int(w * 0.11))
        cap_h = max(h - 6, 18)
        at_rest = (not self._drag) and (self._value < 0.005 or not vivid)

        if vivid:
            accent = QColor(int(ac[0]), int(ac[1]), int(ac[2])) if not at_rest else \
                     QColor(int(mid[0]*0.6+br[0]*0.4), int(mid[1]*0.6+br[1]*0.4), int(mid[2]*0.6+br[2]*0.4))
            # Sombra del cap
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 100))
            p.drawRoundedRect(int(tx - cap_w/2 - 1), int(cy - cap_h/2 + 2), cap_w + 2, cap_h, 3, 3)
            # Cuerpo exterior
            p.setPen(QPen(QColor(17, 17, 17, 230), 1.5))
            p.setBrush(QColor(51, 51, 51, 235))
            p.drawRoundedRect(int(tx - cap_w/2), int(cy - cap_h/2), cap_w, cap_h, 3, 3)
            # Parte superior metálica con relieve, teñida con el color de acento
            inset = 2
            metal_g = QLinearGradient(0, cy - cap_h/2 + inset, 0, cy + cap_h/2 - inset)
            metal_g.setColorAt(0.0, accent.lighter(180))
            metal_g.setColorAt(0.5, accent.lighter(120) if self._drag else QColor(224, 224, 224))
            metal_g.setColorAt(1.0, accent.darker(120))
            p.setPen(QPen(QColor(150, 150, 150, 200), 1))
            p.setBrush(QBrush(metal_g))
            p.drawRoundedRect(int(tx - cap_w/2 + inset), int(cy - cap_h/2 + inset),
                              cap_w - 2*inset, cap_h - 2*inset, 2, 2)
            # Línea indicadora central
            p.setPen(QPen(QColor(26, 26, 26, 230), 2.5))
            p.drawLine(int(tx), int(cy - cap_h/2 + inset + 2), int(tx), int(cy + cap_h/2 - inset - 2))
            # Halo de arrastre
            if self._drag:
                glow = QColor(accent); glow.setAlpha(70)
                p.setPen(Qt.NoPen); p.setBrush(glow)
                p.drawRoundedRect(int(tx - cap_w/2 - 4), int(cy - cap_h/2 - 4), cap_w + 8, cap_h + 8, 5, 5)
        else:
            p.setPen(Qt.NoPen); p.setBrush(QColor(60, 60, 60, 60))
            p.drawRoundedRect(int(tx - cap_w/2), int(cy - cap_h/2), cap_w, cap_h, 3, 3)

        p.end()


# ═════════════════════════════════════════════════════════════════════════════
#  MorpherScrubBar  —  joystick bipolar -1..+1
# ═════════════════════════════════════════════════════════════════════════════

class MorpherScrubBar(QWidget):
    """
    Scrub de morphing — joystick bipolar con snap elástico al centro al soltar.

    Rango:
      pos > 0  → reproducción hacia adelante, ratio 1.0..MAX_FORWARD (×1.50)
      pos < 0  → reversa con zona muerta:
                  pos ∈ [-0.02, 0)   → velocidad 1.0 en reversa (zona muerta 2%)
                  pos ∈ [-0.70, -0.02) → descenso de velocidad 1.0 → MAX_REVERSE (×0.70)
      pos = 0  → neutro (snap elástico al soltar)

    Señales:
      onChanged(ratio: float, reverse: bool, pos: float)

    Arquitectura:
      mousePressEvent  → _fire_drag(pos)
      mouseMoveEvent   → _fire_drag(pos)
      mouseReleaseEvent→ inicia retorno elástico animado → onChanged(1.0, False, 0.0)
                         al llegar al centro.

    El snap elástico (v0.21.01):
      Al soltar, _pos retorna exponencialmente hacia 0 en ticks de ~16ms
      con coeficiente ELASTIC_DECAY (0.22 ≡ τ ≈ 70ms).  El PlaybackEngine
      recibe set_speed_live() gradual en lugar del salto discontinuo de ratio
      → cero pop en el release del morpher.  onChanged con pos=0.0 exacto
      se emite solo al converger (_pos < ELASTIC_STOP), garantizando un único
      flush limpio de consolidación.
    """

    MAX_FORWARD   = 1.50   # ratio máximo hacia adelante (tope derecho +1.50)
    MAX_REVERSE   = 0.70   # ratio mínimo en reversa (factor límite -0.70)

    # Zona muerta en reversa: pos ∈ [-0.02, 0) → velocidad 1.0 en reversa (2%).
    # Solo cuando pos < REVERSE_DEADZONE_START comienza el descenso de velocidad.
    # FIX-DEADZONE-2PCT (v0.22.09): la zona muerta era [-0.65, 0) — un 65% del
    # rango reverso — lo que impedía percibir el descenso de velocidad hasta casi
    # el tope izquierdo.  Corregido a -0.02 (2%) para que el descenso real
    # comience casi de inmediato al deslizar en reversa.
    REVERSE_DEADZONE_START = -0.02   # inicio del descenso: 2% en reversa
    REVERSE_DEADZONE_END   = -0.70   # límite máximo del arrastre (tope izquierdo)

    # Parámetros del retorno elástico
    ELASTIC_MS    = 16     # intervalo del timer de retorno (~60 Hz)
    ELASTIC_DECAY = 0.22   # coeficiente EMA de retorno: pos *= (1 - DECAY) por tick
                           # τ ≈ ELASTIC_MS / (-ln(1-DECAY)) ≈ 66ms — perceptiblemente
                           # "elástico" pero que termina en < 250ms
    ELASTIC_STOP  = 0.012  # umbral de convergencia — debajo de esto se considera centro

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pos     = 0.0
        self._drag    = False
        self._enabled = False
        self._dimmed  = False
        # FIX-ELASTIC-LIVE (v0.21.02): flag que indica que el timer elástico
        # está en retorno. El handler usa este flag para escribir live_ratio
        # directamente sin disparar flushes durante el retorno.
        self._elastic_returning = False
        self.onChanged : Optional[Callable] = None
        # Aliases de compatibilidad retroactiva
        self.onLive    : Optional[Callable] = None
        self.onCommit  : Optional[Callable] = None
        self.onDrag    : Optional[Callable] = None
        self.onRelease : Optional[Callable] = None
        self.setFixedHeight(26)
        self.setCursor(Qt.ArrowCursor)

        # Timer del retorno elástico (sustituye al snap instantáneo)
        self._morpher_motor_timer = QTimer(self)
        self._morpher_motor_timer.setInterval(self.ELASTIC_MS)
        self._morpher_motor_timer.timeout.connect(self._elastic_tick)

    # ── Motor elástico ────────────────────────────────────────────────────────

    def _elastic_tick(self) -> None:
        """
        Retorno exponencial de _pos hacia 0.

        FIX-ELASTIC-POP  (v0.21.01): decay exponencial en lugar de snap.
        FIX-ELASTIC-LIVE (v0.21.02): durante el retorno, los ticks emiten
          onChanged con _drag=False y pos>0.015, lo que en _on_morpher_changed
          dispara set_speed_live() con su debounce de 80ms → hasta 3 flushes
          durante los 272ms de retorno → 3 gaps → 3 pops.

          Solución: el retorno elástico usa un path directo en el handler que
          escribe SOLO live_ratio sin flush, mediante el flag _elastic_returning.
          El handler detecta ese flag y llama pe.set_speed_live_noflush(ratio)
          en lugar de set_speed_live(ratio).

          set_speed_live_noflush() escribe directamente en _ss.live_ratio sin
          disparar _speed_change_evt → cero flushes durante el retorno.
          El prefetch lee live_ratio en su ciclo natural (latencia ≤ 85ms),
          sin vaciar la cola → cero gaps → cero pops.

          Solo el tick final (convergencia) emite _fire_release() →
          _on_morpher_changed recibe pos=0.0, _drag=False → set_speed() discreto
          con crossfade → UN flush limpio de consolidación.
        """
        self._pos *= (1.0 - self.ELASTIC_DECAY)
        self.update()

        if abs(self._pos) < self.ELASTIC_STOP:
            # Convergido: forzar centro exacto y emitir flush final
            self._pos = 0.0
            self._elastic_returning = False
            self._morpher_motor_timer.stop()
            self.update()
            # ── FORENSICS: convergencia → flush de consolidación ──────────
            _frn_emit("MORPHER_ELASTIC_CONVERGED", {
                "note": "retorno elástico convergido → _fire_release() → flush",
            }, crit=True)
            # ─────────────────────────────────────────────────────────────
            self._fire_release()
        else:
            # Retornando: emitir live SIN flush vía flag _elastic_returning
            self._elastic_returning = True
            ratio   = self._pos_to_ratio(self._pos)
            reverse = self._pos < 0
            # ── FORENSICS: tick elástico sin flush ────────────────────────
            _frn_emit("MORPHER_ELASTIC_TICK", {
                "pos"    : round(self._pos, 5),
                "ratio"  : round(ratio, 5),
                "reverse": reverse,
                "flag"   : "noflush",
            })
            # ─────────────────────────────────────────────────────────────
            cb = self.onChanged or self.onDrag or self.onLive
            if cb: cb(ratio, reverse, self._pos)

    # ── Emisores ─────────────────────────────────────────────────────────────

    def _fire_drag(self, pos: float) -> None:
        ratio   = self._pos_to_ratio(pos)
        reverse = pos < 0
        cb = self.onChanged or self.onDrag or self.onLive
        if cb: cb(ratio, reverse, pos)

    def _fire_release(self) -> None:
        # ── FORENSICS ────────────────────────────────────────────────────────
        _frn_emit("MORPHER_FIRE_RELEASE", {
            "note": "_fire_release() → onChanged(1.0, False, 0.0) → set_speed(speed_ratio)",
        }, crit=True)
        # ─────────────────────────────────────────────────────────────────────
        cb = self.onChanged or self.onCommit or self.onRelease
        if cb: cb(1.0, False, 0.0)

    # ── API ───────────────────────────────────────────────────────────────────

    def setEnabled(self, e: bool) -> None:
        self._enabled = e
        self.setCursor(Qt.SizeHorCursor if e else Qt.ArrowCursor)
        if not e:
            self._drag = False
            self._pos  = 0.0
            self._elastic_returning = False   # FIX-ELASTIC-LIVE (v0.21.02)
            # FIX-ELASTIC-POP (v0.21.01): detener timer elástico al deshabilitar
            if self._morpher_motor_timer.isActive():
                self._morpher_motor_timer.stop()
        self.update()

    def setDimmed(self, d: bool) -> None:
        if self._dimmed != d:
            self._dimmed = d; self.update()

    # ── Geometría ─────────────────────────────────────────────────────────────

    def _x_to_pos(self, x: float) -> float:
        """
        Convierte x pixel → posición normalizada en el espacio de pantalla.

        El espacio de pantalla mapea el ancho útil de la barra a:
          píxel izquierdo  → REVERSE_DEADZONE_END (-0.70)   ← tope reversa
          píxel central    → 0.0                             ← neutro
          píxel derecho    → +1.0                            ← máximo forward

        Esto garantiza que el thumb llega visualmente al borde izquierdo
        exactamente cuando _pos == REVERSE_DEADZONE_END, sin recorte ni
        hueco entre el thumb y el extremo de la barra.
        """
        pad = 10; uw = self.width() - pad * 2
        pct = max(0.0, min(1.0, (x - pad) / max(uw, 1)))
        # pct=0 → REVERSE_DEADZONE_END, pct=1 → +1.0
        _lo = self.REVERSE_DEADZONE_END   # -0.70
        _hi = 1.0
        return _lo + pct * (_hi - _lo)

    def _pos_to_x(self, pos: float) -> int:
        """Inversa exacta de _x_to_pos: posición lógica → coordenada X del thumb."""
        pad = 10; uw = self.width() - pad * 2
        _lo = self.REVERSE_DEADZONE_END   # -0.70
        _hi = 1.0
        pct = (pos - _lo) / (_hi - _lo)
        return pad + int(pct * uw)

    def _pos_to_ratio(self, pos: float) -> float:
        """
        pos ∈ [0, +1]   → ratio 1.0 .. MAX_FORWARD  (hasta ×1.50)
        pos ∈ [-0.70, 0) → reversa con zona muerta 2%:
            · pos ∈ [-0.02, 0)   → ratio 1.0 (reversa a velocidad estándar — zona muerta 2%)
            · pos ∈ [-0.70, -0.02) → ratio desciende 1.0 → MAX_REVERSE (×0.70)
        El valor devuelto es siempre positivo; el handler gestiona la dirección.
        """
        if pos >= 0:
            return 1.0 + pos * (self.MAX_FORWARD - 1.0)
        else:
            # Zona muerta 2%: pos ∈ [REVERSE_DEADZONE_START, 0)  → velocidad estándar 1.0
            # FIX-DEADZONE-2PCT (v0.22.09): zona muerta corregida a -0.02 (2%).
            # Antes era -0.65 (65%) → el morpher tardaba casi todo el recorrido
            # en reversa para comenzar a descender la velocidad.
            if pos >= self.REVERSE_DEADZONE_START:
                return 1.0
            # Descenso controlado: pos ∈ [REVERSE_DEADZONE_END, REVERSE_DEADZONE_START)
            # mapear [REVERSE_DEADZONE_END, REVERSE_DEADZONE_START] → [MAX_REVERSE, 1.0]
            deep = (pos - self.REVERSE_DEADZONE_START) / (self.REVERSE_DEADZONE_END - self.REVERSE_DEADZONE_START)
            deep = max(0.0, min(1.0, deep))
            return 1.0 - deep * (1.0 - self.MAX_REVERSE)

    # ── Eventos de ratón ─────────────────────────────────────────────────────

    def mousePressEvent(self, e):
        if not self._enabled: return
        # FIX-ELASTIC-POP (v0.21.01): si el usuario presiona durante el retorno
        # elástico, cancelar el timer y tomar control inmediatamente.
        if self._morpher_motor_timer.isActive():
            self._morpher_motor_timer.stop()
        self._elastic_returning = False   # FIX-ELASTIC-LIVE (v0.21.02)
        self._drag = True
        self._pos  = self._x_to_pos(e.position().x())
        self.update()
        self._fire_drag(self._pos)

    def mouseMoveEvent(self, e):
        if not self._drag: return
        self._pos = self._x_to_pos(e.position().x())
        self.update()
        self._fire_drag(self._pos)

    def mouseReleaseEvent(self, e):
        if not self._drag: return
        self._drag = False
        # FIX-ELASTIC-POP  (v0.21.01): retorno elástico animado en lugar de snap.
        # FIX-ELASTIC-LIVE (v0.21.02): marcar el retorno para que el handler
        # use set_speed_live_noflush() en lugar de set_speed_live() durante el
        # retorno → cero flushes → cero gaps → cero pops.
        self._elastic_returning = True
        if not self._morpher_motor_timer.isActive():
            self._morpher_motor_timer.start()
        self.update()

    # ── Paint ─────────────────────────────────────────────────────────────────

    def paintEvent(self, _):
        # NOTA MODULARIZACION: THEME se importa a nivel de modulo (ver arriba);
        # el original hacia "from __main__ import THEME" en runtime para
        # obtener el dict actualizado tras un rebind global. Aqui THEME se
        # muta in-place (ver frontend/main_window.py), asi que la referencia
        # importada a nivel de modulo ya queda siempre actualizada.
        try:
            br = THEME["bright"]; ac = THEME["accent"]; mid = THEME["mid"]
        except Exception:
            br = (180, 180, 220); ac = (120, 160, 255); mid = (80, 80, 100)

        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()

        # ── Rediseño con referencia SVG del usuario (mismo lenguaje visual
        # que `ScrubBarPlay`: placa + marcas de graduación + ranura + cap
        # metálico rectangular) — adaptado al joystick BIPOLAR del Morpher:
        # el centro (0.0) queda en el medio de la ranura, con relleno
        # cromático que crece desde ahí hacia donde esté el cap, no desde
        # el borde izquierdo como en el scrub de reproducción.
        pad = 10
        tw  = w - pad * 2
        cy  = h // 2
        center_x = self._pos_to_x(0.0)
        tx = self._pos_to_x(self._pos)
        at_rest = (not self._drag) and abs(self._pos) < 0.02

        if self._dimmed:
            p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 24), 1))
            p.setBrush(QColor(28, 28, 28, 60))
            p.drawRoundedRect(2, 2, w-4, h-4, 5, 5)
            p.setPen(Qt.NoPen); p.setBrush(QColor(10, 10, 10, 60))
            slot_h = max(4, h // 6)
            p.drawRoundedRect(pad, cy - slot_h//2, tw, slot_h, 2, 2)
            p.setPen(Qt.NoPen); p.setBrush(QColor(60, 60, 60, 40))
            cap_w = max(14, int(w*0.11)); cap_h = max(h-6, 18)
            p.drawRoundedRect(int(tx-cap_w/2), int(cy-cap_h/2), cap_w, cap_h, 3, 3)
            p.end(); return

        # Placa de fondo
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 70), 1.5))
        p.setBrush(QColor(28, 28, 28, 220))
        p.drawRoundedRect(2, 2, w-4, h-4, 5, 5)

        # Marcas de graduación (centro + extremos + referencias de la zona
        # muerta reversa y mitad forward, en vez de las 9 genéricas)
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 100), 1))
        for _ref_pos in (self.REVERSE_DEADZONE_END, self.REVERSE_DEADZONE_START,
                         0.0, 0.5, 1.0):
            _mx = self._pos_to_x(_ref_pos)
            tick_h = 5 if _ref_pos in (0.0, self.REVERSE_DEADZONE_END, 1.0) else 3
            p.drawLine(int(_mx), 4, int(_mx), 4 + tick_h)

        # Ranura central
        slot_h = max(4, h // 6)
        p.setPen(Qt.NoPen); p.setBrush(QColor(10, 10, 10, 230))
        p.drawRoundedRect(pad, cy - slot_h//2, tw, slot_h, 2, 2)

        # Fill cromático desde el CENTRO hacia el cap (bipolar)
        x0, x1 = min(center_x, tx), max(center_x, tx)
        if x1 > x0 and not at_rest:
            gf = QLinearGradient(x0, 0, x1, 0)
            gf.setColorAt(0.0, QColor(int(ac[0]*0.7), int(ac[1]*0.5),
                                      int(min(255, ac[2]*1.5)), 190))
            gf.setColorAt(1.0, QColor(int(min(255, ac[0]*1.3)), int(ac[1]), int(ac[2]), 235))
            p.setBrush(QBrush(gf))
            p.drawRoundedRect(int(x0), cy - slot_h//2, int(x1-x0), slot_h, 2, 2)

        # Línea de centro, más marcada que el resto de marcas
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 130), 1.5))
        p.drawLine(int(center_x), cy - slot_h//2 - 3, int(center_x), cy + slot_h//2 + 3)

        # ── Cap metálico rectangular (calco del SVG) ───────────────────
        cap_w = max(14, int(w * 0.11))
        cap_h = max(h - 6, 18)
        accent = QColor(int(ac[0]), int(ac[1]), int(ac[2])) if not at_rest else \
                 QColor(int(mid[0]*0.6+br[0]*0.4), int(mid[1]*0.6+br[1]*0.4), int(mid[2]*0.6+br[2]*0.4))
        p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 100))
        p.drawRoundedRect(int(tx-cap_w/2-1), int(cy-cap_h/2+2), cap_w+2, cap_h, 3, 3)
        p.setPen(QPen(QColor(17, 17, 17, 230), 1.5))
        p.setBrush(QColor(51, 51, 51, 235))
        p.drawRoundedRect(int(tx-cap_w/2), int(cy-cap_h/2), cap_w, cap_h, 3, 3)
        inset = 2
        metal_g = QLinearGradient(0, cy-cap_h/2+inset, 0, cy+cap_h/2-inset)
        metal_g.setColorAt(0.0, accent.lighter(180))
        metal_g.setColorAt(0.5, accent.lighter(120) if self._drag else QColor(224, 224, 224))
        metal_g.setColorAt(1.0, accent.darker(120))
        p.setPen(QPen(QColor(150, 150, 150, 200), 1))
        p.setBrush(QBrush(metal_g))
        p.drawRoundedRect(int(tx-cap_w/2+inset), int(cy-cap_h/2+inset), cap_w-2*inset, cap_h-2*inset, 2, 2)
        p.setPen(QPen(QColor(26, 26, 26, 230), 2.5))
        p.drawLine(int(tx), int(cy-cap_h/2+inset+2), int(tx), int(cy+cap_h/2-inset-2))
        if self._drag:
            glow = QColor(accent); glow.setAlpha(70)
            p.setPen(Qt.NoPen); p.setBrush(glow)
            p.drawRoundedRect(int(tx-cap_w/2-4), int(cy-cap_h/2-4), cap_w+8, cap_h+8, 5, 5)
        p.end()


# ═════════════════════════════════════════════════════════════════════════════
#  SpeedScrubBar  —  deslizador de velocidad 0.50..2.00
# ═════════════════════════════════════════════════════════════════════════════

class SpeedScrubBar(QWidget):
    """
    Scrub de velocidad de reproducción con motor de suavizado exponencial propio.

    Rango: 0.50 (tope izquierdo) .. 1.00 (neutro) .. 2.00 (tope derecho).

    Motor exclusivo (_speed_motor_timer, ~60 Hz):
      · Tick cada MOTOR_INTERVAL_MS → interpola _ratio → _target_ratio.
      · Emite onChanged durante drag (SMOOTH continuo) y en convergencia final.
      · Se detiene automáticamente al converger (|diff| < STOP_THRESHOLD).

    FIX-P3: al iniciar nuevo drag, el motor anterior se detiene y _ratio
    converge instantáneamente, evitando ticks obsoletos que disparan flush doble.

    FIX-P4: guardia de generación en _motor_tick — ticks de gesto obsoleto
    no emiten onChanged.

    Señales:
      onChanged(ratio: float) — emitido durante drag y en convergencia final

    Zona lenta (0.50 .. 0.99): leyendas en pantalla de logs via _on_speed_changed:
      0.90 … 0.99  → Calibrante
      0.70 … 0.89  → Aguilar
      0.60 … 0.69  → Cromantina
      0.50 … 0.59  → Superprador
    """

    MIN_SPEED        =  0.50
    MAX_SPEED        =  2.00
    MOTOR_INTERVAL_MS= 16      # ~60 Hz
    SMOOTH           = 0.28    # coeficiente suavizado exponencial
    SNAP_THRESHOLD   = 0.004   # diferencia mínima para emitir cambio
    STOP_THRESHOLD   = 0.001   # diferencia para considerar convergido

    def __init__(self, parent=None):
        super().__init__(parent)
        self._ratio        = 1.0
        self._target_ratio = 1.0
        self._drag         = False
        self._enabled      = False
        self._dimmed       = False
        self._motor_gen    = 0
        self.onChanged : Optional[Callable] = None
        self.setFixedHeight(26)
        self.setCursor(Qt.ArrowCursor)

        self._speed_motor_timer = QTimer(self)
        self._speed_motor_timer.setInterval(self.MOTOR_INTERVAL_MS)
        self._speed_motor_timer.timeout.connect(self._motor_tick)

    # ── Geometría ─────────────────────────────────────────────────────────────

    def _ratio_to_pct(self, r: float) -> float:
        r = max(self.MIN_SPEED, min(self.MAX_SPEED, r))
        return (r - self.MIN_SPEED) / (self.MAX_SPEED - self.MIN_SPEED)

    def _pct_to_ratio(self, pct: float) -> float:
        return self.MIN_SPEED + pct * (self.MAX_SPEED - self.MIN_SPEED)

    def _x_to_pct(self, x: float) -> float:
        pad = 10; uw = self.width() - pad * 2
        return max(0.0, min(1.0, (x - pad) / max(uw, 1)))

    # ── Motor de suavizado ────────────────────────────────────────────────────

    def _motor_tick(self) -> None:
        """
        Interpola _ratio → _target_ratio.

        FIX-P4: guardia de generación para descartar ticks de gestos obsoletos.
        FIX (v0.20.21): durante convergencia post-release (_drag=False), solo
        emite en el tick FINAL de convergencia.
        """
        my_gen = self._motor_gen
        diff   = self._target_ratio - self._ratio

        if abs(diff) < self.STOP_THRESHOLD:
            self._ratio = self._target_ratio
            self._speed_motor_timer.stop()
            self.update()
            # FIX-P4: solo emitir si pertenece a la generación actual
            if self.onChanged and my_gen == self._motor_gen:
                self.onChanged(self._ratio)
            return

        self._ratio += diff * (1.0 - self.SMOOTH)
        self.update()
        # FIX-SPEED-MOTOR-DRAG (v0.22.19): durante drag, mouseMoveEvent ya emitió
        # onChanged con el valor raw directamente (FIX-SPEED-DIRECT).  El motor
        # solo actualiza _ratio para suavizar la animación visual del thumb.
        # NO emitir aquí durante drag → cero doble disparo, cero flushes extra.
        # Sí emitir en convergencia post-release (ver bloque abs(diff)<STOP_THRESHOLD).

    def _set_target(self, raw_ratio: float) -> None:
        self._target_ratio = max(self.MIN_SPEED, min(self.MAX_SPEED, raw_ratio))
        if not self._speed_motor_timer.isActive():
            self._speed_motor_timer.start()

    # ── API ───────────────────────────────────────────────────────────────────

    def getRatio(self) -> float:
        return self._ratio

    def setRatio(self, r: float) -> None:
        """Fija ratio instantáneamente (sin suavizado) — para reset programático."""
        r = max(self.MIN_SPEED, min(self.MAX_SPEED, r))
        self._ratio        = r
        self._target_ratio = r
        self._speed_motor_timer.stop()
        self.update()
        if self.onChanged:
            self.onChanged(self._ratio)

    def setEnabled(self, e: bool) -> None:
        self._enabled = e
        self.setCursor(Qt.SizeHorCursor if e else Qt.ArrowCursor)
        if not e:
            self._drag = False
            self._speed_motor_timer.stop()
        self.update()

    def setDimmed(self, d: bool) -> None:
        if self._dimmed != d:
            self._dimmed = d; self.update()

    # ── Eventos de ratón ─────────────────────────────────────────────────────

    def mousePressEvent(self, e):
        if not self._enabled: return
        # FIX-P3: detener motor anterior e instantanear _ratio
        if self._speed_motor_timer.isActive():
            self._speed_motor_timer.stop()
            self._ratio = self._target_ratio
        self._drag = True
        self._motor_gen += 1
        raw_ratio = self._pct_to_ratio(self._x_to_pct(e.position().x()))
        self._set_target(raw_ratio)
        if self.onChanged:
            self.onChanged(raw_ratio)
        self.update()

    def mouseMoveEvent(self, e):
        if not self._drag: return
        # FIX-SPEED-DIRECT (v0.22.19): emitir onChanged INMEDIATAMENTE desde el evento
        # de ratón, igual que ScrubBarPlay.onSeek y MorpherScrubBar._fire_drag.
        # Antes solo actualizaba _target_ratio y esperaba el siguiente tick del motor
        # (~16ms de latencia) → el audio respondía tarde y el comportamiento no era
        # idéntico al scrub de reproducción.
        # Ahora: el valor raw llega al handler de audio sin demora (cero latencia de motor);
        # _set_target sigue activo para que el thumb se anime suavemente hacia el target.
        # El motor durante drag ya NO emite onChanged (ver FIX-SPEED-MOTOR-DRAG v0.22.19)
        # para evitar doble disparo.
        raw_ratio = self._pct_to_ratio(self._x_to_pct(e.position().x()))
        self._set_target(raw_ratio)
        if self.onChanged:
            self.onChanged(raw_ratio)
        self.update()

    def mouseReleaseEvent(self, e):
        if not self._drag: return
        self._drag = False
        self._set_target(self._pct_to_ratio(self._x_to_pct(e.position().x())))
        self.update()

    def mouseDoubleClickEvent(self, _):
        if not self._enabled: return
        self.setRatio(1.0)

    # ── Paint ─────────────────────────────────────────────────────────────────

    def paintEvent(self, _):
        # NOTA MODULARIZACION: THEME se importa a nivel de modulo (ver arriba);
        # el original hacia "from __main__ import THEME" en runtime para
        # obtener el dict actualizado tras un rebind global. Aqui THEME se
        # muta in-place (ver frontend/main_window.py), asi que la referencia
        # importada a nivel de modulo ya queda siempre actualizada.
        try:
            br = THEME["bright"]; ac = THEME["accent"]; mid = THEME["mid"]
        except Exception:
            br = (180, 180, 220); ac = (120, 160, 255); mid = (80, 80, 100)

        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()

        # ── Rediseño con referencia SVG del usuario (mismo lenguaje visual
        # que ScrubBarPlay/MorpherScrubBar) — conserva el esquema cian
        # (lento, <1.0) / ámbar (rápido, >1.0) propio de este scrub.
        pad = 10
        tw  = w - pad * 2
        cy  = h // 2
        center_x = pad + tw // 2
        pct = self._ratio_to_pct(self._ratio)
        tx  = pad + int(tw * pct)
        at_rest = (not self._drag) and abs(self._ratio - 1.0) < 0.005

        if self._dimmed:
            p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 24), 1))
            p.setBrush(QColor(28, 28, 28, 60))
            p.drawRoundedRect(2, 2, w-4, h-4, 5, 5)
            p.setPen(Qt.NoPen); p.setBrush(QColor(10, 10, 10, 60))
            slot_h = max(4, h // 6)
            p.drawRoundedRect(pad, cy - slot_h//2, tw, slot_h, 2, 2)
            p.setPen(Qt.NoPen); p.setBrush(QColor(60, 60, 60, 40))
            cap_w = max(14, int(w*0.11)); cap_h = max(h-6, 18)
            p.drawRoundedRect(int(tx-cap_w/2), int(cy-cap_h/2), cap_w, cap_h, 3, 3)
            p.end(); return

        # Placa de fondo
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 70), 1.5))
        p.setBrush(QColor(28, 28, 28, 220))
        p.drawRoundedRect(2, 2, w-4, h-4, 5, 5)

        # Marcas de graduación (extremos + 1.00 central + medios)
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 100), 1))
        for _ref_pct in (0.0, 0.25, 0.5, 0.75, 1.0):
            _mx = pad + int(tw * _ref_pct)
            tick_h = 5 if _ref_pct in (0.0, 0.5, 1.0) else 3
            p.drawLine(_mx, 4, _mx, 4 + tick_h)

        # Ranura central
        slot_h = max(4, h // 6)
        p.setPen(Qt.NoPen); p.setBrush(QColor(10, 10, 10, 230))
        p.drawRoundedRect(pad, cy - slot_h//2, tw, slot_h, 2, 2)

        # Fill cromático desde 1.00 (centro) — cian hacia abajo, ámbar hacia arriba
        x0, x1 = min(center_x, tx), max(center_x, tx)
        if x1 > x0 and not at_rest:
            gf = QLinearGradient(x0, 0, x1, 0)
            if self._ratio >= 1.0:
                gf.setColorAt(0.0, QColor(200, 120, 0, 190))
                gf.setColorAt(1.0, QColor(255, 200, 0, 235))
            else:
                gf.setColorAt(0.0, QColor(0, 200, 255, 235))
                gf.setColorAt(1.0, QColor(0, 80, 200, 190))
            p.setBrush(QBrush(gf))
            p.drawRoundedRect(int(x0), cy - slot_h//2, int(x1-x0), slot_h, 2, 2)

        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 130), 1.5))
        p.drawLine(center_x, cy - slot_h//2 - 3, center_x, cy + slot_h//2 + 3)

        # ── Cap metálico rectangular, teñido cian/ámbar según velocidad ──
        cap_w = max(14, int(w * 0.11))
        cap_h = max(h - 6, 18)
        if at_rest:
            accent = QColor(int(mid[0]*0.6+br[0]*0.4), int(mid[1]*0.6+br[1]*0.4), int(mid[2]*0.6+br[2]*0.4))
        elif self._ratio >= 1.0:
            accent = QColor(255, 190, 0)
        else:
            accent = QColor(0, 180, 255)
        p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 100))
        p.drawRoundedRect(int(tx-cap_w/2-1), int(cy-cap_h/2+2), cap_w+2, cap_h, 3, 3)
        p.setPen(QPen(QColor(17, 17, 17, 230), 1.5))
        p.setBrush(QColor(51, 51, 51, 235))
        p.drawRoundedRect(int(tx-cap_w/2), int(cy-cap_h/2), cap_w, cap_h, 3, 3)
        inset = 2
        metal_g = QLinearGradient(0, cy-cap_h/2+inset, 0, cy+cap_h/2-inset)
        metal_g.setColorAt(0.0, accent.lighter(180))
        metal_g.setColorAt(0.5, accent.lighter(120) if self._drag else QColor(224, 224, 224))
        metal_g.setColorAt(1.0, accent.darker(120))
        p.setPen(QPen(QColor(150, 150, 150, 200), 1))
        p.setBrush(QBrush(metal_g))
        p.drawRoundedRect(int(tx-cap_w/2+inset), int(cy-cap_h/2+inset), cap_w-2*inset, cap_h-2*inset, 2, 2)
        p.setPen(QPen(QColor(26, 26, 26, 230), 2.5))
        p.drawLine(int(tx), int(cy-cap_h/2+inset+2), int(tx), int(cy+cap_h/2-inset-2))
        if self._drag:
            glow = QColor(accent); glow.setAlpha(70)
            p.setPen(Qt.NoPen); p.setBrush(glow)
            p.drawRoundedRect(int(tx-cap_w/2-4), int(cy-cap_h/2-4), cap_w+8, cap_h+8, 5, 5)
        p.end()


# ─────────────────────────────────────────────────────────────────────────────
#  Alias de compatibilidad — mantiene referencias heredadas funcionales
# ─────────────────────────────────────────────────────────────────────────────
# ScrubBar era la clase de posición en v0.20.x.  Ahora es ScrubBarPlay.
# El alias permite que la GUI (self.scrub = ScrubBar(self)) funcione sin cambios.
ScrubBar = ScrubBarPlay
