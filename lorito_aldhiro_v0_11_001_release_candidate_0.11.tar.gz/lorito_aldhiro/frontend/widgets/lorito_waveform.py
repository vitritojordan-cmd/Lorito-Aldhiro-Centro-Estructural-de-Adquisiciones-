from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Renderizado de forma de onda en la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import threading
import queue
import numpy as np
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.core.lorito_constants import WAVEFORM_CACHE_MAX_POINTS
from lorito_aldhiro.frontend.support.lorito_fonts import font_ui
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.support.lorito_theme import THEME



class WaveformDisplay(QWidget):
    """
    Forma de onda con:
      · Buffer circular (_wave_ring) de tamaño fijo para modo REC
      · Downsampling min/max inteligente por columna
      · Clipping visualization (zona roja suave cuando peak ≥ 0.99)
      · Repaint solo cuando los datos cambian (_dirty flag)
      · Visualización espectral con colores por rango de frecuencia (v0.20.11)
    """
    SCROLL_BLOCKS = 400

    # Rangos de frecuencia para la colorización espectral (Hz)
    # Sub-bass → azul profundo, bass → azul, bajo-mid → verde, mid → verde-amarillo,
    # alto-mid → amarillo-naranja, presencia → naranja-rojo, aire → rojo-magenta
    _FREQ_BANDS = [
        (   0,   80, (  0,  80, 255)),   # sub-bass     → azul profundo
        (  80,  250, (  0, 160, 255)),   # bass         → azul claro
        ( 250,  600, (  0, 230, 160)),   # bajo-mid     → verde-cian
        ( 600, 2000, ( 80, 230,  40)),   # mid          → verde
        (2000, 4000, (200, 230,   0)),   # alto-mid     → verde-amarillo
        (4000, 8000, (255, 140,   0)),   # presencia    → naranja
        (8000, 24000,(255,  30,  80)),   # aire/hiss    → rojo-magenta
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._wave_data = np.zeros(256, dtype=np.float32)
        self._freq_hue  = None   # array float32 [0..1] — color espectral por columna
        self._sample_rate = 48000
        self._mode      = "idle"
        self._play_pos  = 0.0
        self._dirty     = False
        self._peak_clip = False    # para visualización de clipping
        self._rms       = 0.0     # RMS suavizado para glow de borde
        # FIX-WAVEFORM-THREAD-CRASH-2: ancho en píxeles legible desde hilos no-GUI.
        # _waveform_compute() NO puede llamar self.width() desde un worker thread
        # (SIGSEGV en Qt/Wayland). Guardamos el ancho aquí y lo actualizamos en
        # resizeEvent() que siempre ocurre en el GUI thread.
        self._cached_width: int = 1024
        # ── Wayland-safe widget attributes ───────────────────────────────────
        # WA_OpaquePaintEvent=False: no borramos el fondo — el compositor lo
        #   gestiona. Correcto para subsurfaces con alpha en Wayland.
        # WA_TranslucentBackground=True: necesario para esquinas redondeadas.
        # WA_NoSystemBackground=True: evita rect de fondo extra del parent.
        # setAutoFillBackground(False): sin relleno automático — paintEvent
        #   dibuja TODO, incluyendo el fondo.
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)
        # _pending_update: True cuando hay datos nuevos sin redibujar aún.
        # Evita repaints extra en resizeEvent o cambios de modo sin datos nuevos.
        self._pending_update: bool = False
        # ── Scrub por arrastre sobre la forma de onda ─────────────────────────
        # onSeek / onRelease son asignados desde LoritoAldhiroStudio tras crear el widget,
        # igual que en ScrubBarPlay. El drag solo se activa si el modo es "playback".
        self.onSeek    : Optional[Callable] = None
        self.onRelease : Optional[Callable] = None
        self._wf_drag  : bool = False   # True mientras el botón izquierdo está presionado

    def resizeEvent(self, event):
        """Actualiza _cached_width para que _waveform_compute() pueda leerlo sin llamar Qt."""
        self._cached_width = max(self.width(), 256)
        super().resizeEvent(event)

    # ── Scrub por arrastre sobre la línea de playback ─────────────────────────

    def _wf_pct(self, x: float) -> float:
        """Convierte coordenada X del ratón a fracción 0..1 dentro del widget."""
        return max(0.0, min(1.0, x / max(self.width(), 1)))

    def mousePressEvent(self, e):
        """Inicia drag de scrub si hay callback registrado y audio disponible.
        FIX-SCRUB-CRAC-PARK (v0.22.47): el drag se activa tanto en modo
        "playback" (reproducción activa) como en modo "idle" (señal parada).
        En modo idle, mover el waveform-scrub actualiza _scrub_parked_offset
        igual que el CAROLALDHIRA ESCANEADOR, sin arrancar reproducción.
        """
        if e.button() != Qt.LeftButton:
            return
        if self.onSeek is None:
            return
        # Activar en playback (seek en tiempo real), idle e idle_scrub (parking)
        if self._mode not in ("playback", "idle", "idle_scrub"):
            return
        self._wf_drag = True
        pct = self._wf_pct(e.position().x())
        self.setCursor(Qt.SizeHorCursor)
        # En idle / idle_scrub: activar modo visual para mostrar la línea de posición
        if self._mode in ("idle", "idle_scrub"):
            self._mode = "idle_scrub"   # modo interno: línea visible, sin reproducir
            self._play_pos = pct
            self._dirty = True
            self.update()
        self.onSeek(pct)

    def mouseMoveEvent(self, e):
        """Continúa el drag de scrub mientras el botón izquierdo está presionado."""
        if not self._wf_drag or self.onSeek is None:
            return
        pct = self._wf_pct(e.position().x())
        if self._mode == "idle_scrub":
            self._play_pos = pct
            self._dirty = True
            self.update()
        self.onSeek(pct)

    def mouseReleaseEvent(self, e):
        """Finaliza el drag y consolida la posición con onRelease."""
        if not self._wf_drag:
            return
        self._wf_drag = False
        self.setCursor(Qt.ArrowCursor)
        if self._mode == "idle_scrub":
            # Restaurar idle pero mantener la línea de posición visible
            # El paintEvent dibuja la línea cuando _mode == "idle_scrub"
            pass
        if self.onRelease is None:
            return
        pct = self._wf_pct(e.position().x())
        self.onRelease(pct)

    def setSampleRate(self, rate: int):
        """Informa la tasa de muestreo para el análisis espectral correcto."""
        self._sample_rate = max(8000, rate)

    def setRms(self, rms: float):
        """Recibe RMS normalizado 0..1 para el glow analógico del borde."""
        self._rms = max(0.0, min(1.0, rms))

    def setMode(self, mode):
        # FIX-SCRUB-CRAC-PARK (v0.22.47): "idle_scrub" es un estado interno
        # transitorio en el que la línea de posición se muestra mientras el
        # usuario arrastra sobre la forma de onda en estado parado. Al recibir
        # "playback" (Play pulsado) o "idle" explícito (Stop), el modo vuelve
        # al valor externo recibido; "idle_scrub" nunca se recibe desde fuera.
        if self._mode == "idle_scrub" and mode in ("idle", "playback", "rec"):
            # Salir del estado de arrastre en parado: transición normal
            self._mode  = mode
            self._dirty = True
            self.update()
            return
        if self._mode != mode:
            self._mode = mode; self._dirty = True; self.update()

    def setPlayPos(self, v):
        """Actualiza posición de playback. WAYLAND-NATIVE: solo marca pendiente.
        El repaint real ocurre en _tick_vu_redraw() (GUI timer, main thread).
        Llamar update() directamente desde _scrub_seek_realtime (que puede
        venir de un evento de ratón — siempre main thread) es OK; desde
        callbacks de audio NO. El flag _pending_update cubre ambos casos.
        """
        if abs(self._play_pos - v) > 0.001:
            self._play_pos = v
            self._dirty = True
            self._pending_update = True
            self.update()   # seguro: llamado desde GUI events o GUI timer

    def updateFromBuffer(self, buffer, lock):
        """Downsampling eficiente. PATCH v0.20.13: sin FFT en GUI thread.
        WAYLAND-NATIVE v0.23+: no llama update() directamente — solo marca
        _pending_update=True. El repaint real lo dispara _tick_vu_redraw()
        en el GUI timer (main thread), garantizando que QWaylandShmBackingStore
        nunca se invoca desde hilos secundarios.
        Llamado desde _tick() que ya corre en el main thread (QTimer) — el
        flag es suficiente para desencadenar el repaint en el mismo ciclo.
        """
        with lock:
            recent = list(buffer)[-self.SCROLL_BLOCKS:]
        if not recent:
            return
        arr = np.concatenate(recent, axis=0)[:, 0]
        W   = max(self._cached_width, 1)   # usa cached_width — thread-safe
        n   = len(arr)
        if n > W:
            step = max(1, n // W)
            cut  = step * (n // step)
            arr2 = arr[:cut].reshape(-1, step)
            ds   = arr2.max(axis=1) - arr2.min(axis=1)
            peak = np.max(np.abs(arr))
            self._peak_clip = float(peak) >= 0.99
            denom = np.max(np.abs(ds)) + 1e-9
            self._wave_data = (ds / denom).astype(np.float32)
            # PATCH v0.20.13: _freq_hue siempre None — forma de onda monocromática
            # adaptativa al color del fondo (THEME["accent"]). Sin FFT en GUI thread.
            self._freq_hue = None
        else:
            denom = np.max(np.abs(arr)) + 1e-9
            self._peak_clip = float(denom - 1e-9) >= 0.99
            self._wave_data = (arr / denom).astype(np.float32)
            self._freq_hue = None
        self._dirty = True
        self._pending_update = True
        # update() se emite desde _tick_vu_redraw() (GUI timer) — NO aquí.

    def _compute_spectral_hue(self, arr_full, arr2_col, step):
        """
        Calcula el color espectral dominante para cada columna.
        Usa FFT por columna (ventana = step muestras) y determina
        el rango de frecuencia con mayor energía.
        Retorna array uint8 [N_cols x 3] con RGB del color dominante.
        """
        try:
            rate = self._sample_rate
            n_cols = arr2_col.shape[0]
            colors = np.zeros((n_cols, 3), dtype=np.uint8)
            bands = self._FREQ_BANDS
            # Frecuencias del FFT para ventana de tamaño step
            freqs = np.fft.rfftfreq(step, d=1.0 / rate)
            # Indices de cada banda
            band_masks = []
            for flo, fhi, rgb in bands:
                mask = (freqs >= flo) & (freqs < fhi)
                band_masks.append((mask, rgb))
            # Por eficiencia: FFT sobre todas las columnas a la vez
            # arr2_col shape: (n_cols, step)
            win = np.hanning(step).astype(np.float32)
            fft_mag = np.abs(np.fft.rfft(arr2_col * win, axis=1))  # (n_cols, n_freq)
            fft_pow = fft_mag ** 2
            total_pow = fft_pow.sum(axis=1, keepdims=True) + 1e-12
            # Para cada columna: hallar banda con mayor energía relativa
            band_pows = np.array([
                fft_pow[:, mask].sum(axis=1) / total_pow[:, 0]
                for mask, _ in band_masks
            ])  # shape: (n_bands, n_cols)
            dominant = np.argmax(band_pows, axis=0)  # (n_cols,)
            rgb_table = np.array([rgb for _, rgb in bands], dtype=np.uint8)
            colors = rgb_table[dominant]  # (n_cols, 3)
            return colors
        except Exception:
            return None

    def updateFromRaw(self, raw_or_path, sr):
        """
        v0.07: Acepta array numpy O ruta de archivo (str/Path).
        Si recibe una ruta, lee en chunks para construir el envelope
        progresivamente, sin cargar el archivo completo en RAM.
        Si recibe array (compatibilidad), opera igual que antes pero
        limita la resolución al máximo WAVEFORM_CACHE_MAX_POINTS.
        """
        if isinstance(raw_or_path, str):
            # Modo streaming: leer archivo por chunks
            self._update_from_file(raw_or_path, sr)
            return

        # Modo array (compatibilidad con código existente)
        raw = raw_or_path
        if raw is None or len(raw) == 0:
            self._wave_data = np.zeros(256, dtype=np.float32)
            self._freq_hue = None
            self._dirty = True
            self._pending_update = True
            return

        W    = min(max(self.width(), 256), WAVEFORM_CACHE_MAX_POINTS)
        arr  = raw[:, 0]
        step = max(1, len(arr) // W)
        cut  = step * (len(arr) // step)
        if cut == 0:
            self._wave_data = np.zeros(256, dtype=np.float32)
            self._freq_hue = None
            self._dirty = True
            self._pending_update = True
            return
        arr2 = arr[:cut].reshape(-1, step)
        mx   = arr2.max(axis=1); mn = arr2.min(axis=1)
        denom = max(float(np.max(np.abs(arr))), 1e-9)
        self._wave_mn   = (mn / denom).astype(np.float32)
        self._wave_mx   = (mx / denom).astype(np.float32)
        self._wave_data = None
        self._peak_clip = (denom - 1e-9) >= 0.99
        # PATCH v0.20.13: _freq_hue siempre None — forma de onda monocromática
        # adaptativa al fondo. Sin FFT en el GUI thread.
        self._freq_hue = None
        # Liberar referencia al array original inmediatamente
        del arr, arr2, mx, mn
        self._dirty = True
        self._pending_update = True
        # update() disparado por _tick_vu_redraw() (GUI timer) — NO aquí.

    def _update_from_file(self, path: str, sr: int):
        """Lee archivo por chunks y construye envelope min/max progresivo."""
        try:
            W         = min(max(self.width(), 256), WAVEFORM_CACHE_MAX_POINTS)
            mn_accum  = []
            mx_accum  = []
            peak_abs  = 0.0
            CHUNK     = 65_536   # frames por iteración de lectura

            with sf.SoundFile(path, "r") as f:
                total = f.frames
                if total == 0:
                    self._wave_data = np.zeros(256, dtype=np.float32)
                    self._dirty = True
                    self._pending_update = True
                    return

                # cuántos frames por punto de envelope
                fpp = max(1, total // W)

                for chunk in f.blocks(blocksize=fpp, dtype="float32",
                                       always_2d=True, fill_value=0):
                    col = chunk[:, 0]
                    mn_accum.append(float(col.min()))
                    mx_accum.append(float(col.max()))
                    pa = float(np.max(np.abs(col)))
                    if pa > peak_abs:
                        peak_abs = pa

            denom = max(peak_abs, 1e-9)
            mn_arr = np.array(mn_accum, dtype=np.float32) / denom
            mx_arr = np.array(mx_accum, dtype=np.float32) / denom
            # Limitar al máximo de puntos
            if len(mn_arr) > W:
                step2 = len(mn_arr) // W
                mn_arr = mn_arr[:step2*W].reshape(-1, step2).min(axis=1)
                mx_arr = mx_arr[:step2*W].reshape(-1, step2).max(axis=1)

            self._wave_mn   = mn_arr
            self._wave_mx   = mx_arr
            self._wave_data = None
            self._peak_clip = peak_abs >= 0.99
            # PATCH v0.20.13: _freq_hue siempre None — forma de onda monocromática
            # adaptativa al fondo. _compute_spectral_hue() ya no se invoca.
            self._freq_hue = None
            del mn_accum, mx_accum, mn_arr, mx_arr
        except Exception as e:
            _log.error("WaveformDisplay._update_from_file: %s", e)
            self._wave_data = np.zeros(256, dtype=np.float32)
        self._dirty = True
        self._pending_update = True
        # update() disparado por _tick_vu_redraw() (GUI timer) — nunca desde worker.

    def clearWave(self):
        """Limpia la forma de onda. Solo llamado desde el GUI thread."""
        self._wave_data = np.zeros(256, dtype=np.float32)
        self._peak_clip = False
        for attr in ("_wave_mn", "_wave_mx"):
            if hasattr(self, attr): delattr(self, attr)
        self._dirty = True
        self._pending_update = False
        self.update()   # seguro: siempre llamado desde el GUI thread

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height(); cy = h//2
        br = THEME["bright"]; ac = THEME["accent"]

        # Fondo redondeado — transparente fuera del rect gracias a WA_TranslucentBackground
        bg = QColor(int(THEME["dark"][0]),int(THEME["dark"][1]),int(THEME["dark"][2]),180)
        p.setPen(Qt.NoPen); p.setBrush(bg)
        p.drawRoundedRect(0, 0, w, h, 6, 6)

        # Zona clipping suave
        if self._peak_clip:
            clip_c = QColor(int(THEME["vu_red"][1:3],16),
                            int(THEME["vu_red"][3:5],16),
                            int(THEME["vu_red"][5:7],16), 18)
            p.setBrush(clip_c); p.drawRoundedRect(0,0,w,h,6,6)

        # Línea central
        p.setPen(QPen(QColor(int(br[0]),int(br[1]),int(br[2]),22), 1))
        p.drawLine(0, cy, w, cy)

        # ── Forma de onda monocromática adaptativa al fondo (v0.20.13) ──────────
        # PATCH v0.20.13: _freq_hue siempre None → path monocromático.
        # El color wave_color = THEME["accent"] se deriva de la imagen de fondo
        # via _build_theme_from_image(), adaptándose automáticamente al fondo
        # sin ningún cambio adicional aquí. Sin FFT en el GUI thread.
        # _compute_spectral_hue() sigue disponible pero no se invoca.
        has_env = (self._wave_data is None
                   and hasattr(self,"_wave_mn") and hasattr(self,"_wave_mx"))
        wave_color = QColor(int(ac[0]),int(ac[1]),int(ac[2]),200)
        fill_color = QColor(int(ac[0]),int(ac[1]),int(ac[2]),55)
        freq_hue   = getattr(self, "_freq_hue", None)   # (N,3) uint8 o None

        if has_env:
            mn = self._wave_mn; mx = self._wave_mx; N = len(mn)
            if N > 1:
                poly_top = []; poly_bot = []
                for i,(lo,hi) in enumerate(zip(mn,mx)):
                    x = int(i*w/N)
                    poly_top.append((x, cy - int(hi*cy*0.92)))
                    poly_bot.append((x, cy - int(lo*cy*0.92)))

                if freq_hue is not None and len(freq_hue) == N:
                    # v0.20.12: relleno espectral del envelope — cada columna con su
                    # color dominante (igual que el modo _wave_data con freq_hue).
                    p.setBrush(Qt.NoBrush)
                    for i in range(N - 1):
                        r2, g2, b2 = int(freq_hue[i, 0]), int(freq_hue[i, 1]), int(freq_hue[i, 2])
                        # Relleno vertical tenue entre las líneas superior e inferior
                        if abs(poly_top[i][1] - poly_bot[i][1]) > 1:
                            p.setPen(Qt.NoPen)
                            p.setBrush(QColor(r2, g2, b2, 28))
                            poly_col = QPolygon([
                                QPoint(poly_top[i][0], poly_top[i][1]),
                                QPoint(poly_top[i+1][0], poly_top[i+1][1]),
                                QPoint(poly_bot[i+1][0], poly_bot[i+1][1]),
                                QPoint(poly_bot[i][0], poly_bot[i][1]),
                            ])
                            p.drawPolygon(poly_col)
                        # Línea superior con color espectral
                        p.setPen(QPen(QColor(r2, g2, b2, 200), 1))
                        p.setBrush(Qt.NoBrush)
                        p.drawLine(poly_top[i][0], poly_top[i][1],
                                   poly_top[i+1][0], poly_top[i+1][1])
                        # Línea inferior más tenue
                        p.setPen(QPen(QColor(r2, g2, b2, 140), 1))
                        p.drawLine(poly_bot[i][0], poly_bot[i][1],
                                   poly_bot[i+1][0], poly_bot[i+1][1])
                else:
                    # Fallback monocromático cuando no hay datos espectrales
                    pts = [QPoint(x,y) for x,y in poly_top] + \
                          [QPoint(x,y) for x,y in reversed(poly_bot)]
                    p.setPen(Qt.NoPen); p.setBrush(fill_color)
                    p.drawPolygon(QPolygon(pts))
                    pen = QPen(wave_color, 1); p.setPen(pen); p.setBrush(Qt.NoBrush)
                    for i in range(len(poly_top)-1):
                        p.drawLine(poly_top[i][0],poly_top[i][1],
                                   poly_top[i+1][0],poly_top[i+1][1])
        elif self._wave_data is not None and len(self._wave_data) > 1:
            arr = self._wave_data; N = len(arr)
            # Modo espectral: cada columna con su color dominante
            if freq_hue is not None and len(freq_hue) == N:
                p.setBrush(Qt.NoBrush)
                for i in range(N - 1):
                    x0 = int(i * w / N);   x1 = int((i+1) * w / N)
                    y0 = cy - int(arr[i]   * cy * 0.88)
                    y1 = cy - int(arr[i+1] * cy * 0.88)
                    yr0 = cy + int(arr[i]   * cy * 0.88)
                    yr1 = cy + int(arr[i+1] * cy * 0.88)
                    r, g, b = int(freq_hue[i, 0]), int(freq_hue[i, 1]), int(freq_hue[i, 2])
                    # Línea superior (positiva)
                    pen_top = QPen(QColor(r, g, b, 200), 1)
                    p.setPen(pen_top)
                    p.drawLine(x0, y0, x1, y1)
                    # Línea inferior (simétrica, misma frecuencia)
                    pen_bot = QPen(QColor(r, g, b, 140), 1)
                    p.setPen(pen_bot)
                    p.drawLine(x0, yr0, x1, yr1)
                    # Relleno vertical tenue entre positiva e inferior
                    if abs(y0 - yr0) > 2:
                        fill_r = QColor(r, g, b, 28)
                        p.setPen(Qt.NoPen)
                        p.setBrush(fill_r)
                        poly = QPolygon([
                            QPoint(x0, y0), QPoint(x1, y1),
                            QPoint(x1, yr1), QPoint(x0, yr0)
                        ])
                        p.drawPolygon(poly)
                        p.setBrush(Qt.NoBrush)
            else:
                # Fallback monocromático si no hay datos espectrales
                pen = QPen(wave_color, 1); p.setPen(pen)
                for i in range(N - 1):
                    x0 = int(i*w/N); x1 = int((i+1)*w/N)
                    y0 = cy - int(arr[i]*cy*0.88); y1 = cy - int(arr[i+1]*cy*0.88)
                    p.drawLine(x0,y0,x1,y1)

        # Línea de posición playback / idle_scrub
        if self._mode == "playback" and 0 < self._play_pos < 1:
            px = int(self._play_pos*w)
            p.setPen(QPen(QColor(int(br[0]),int(br[1]),int(br[2]),180), 1,
                          Qt.SolidLine, Qt.RoundCap))
            p.drawLine(px, 2, px, h-2)
        elif self._mode == "idle_scrub" and 0 <= self._play_pos <= 1:
            # FIX-SCRUB-CRAC-PARK (v0.22.47): línea de posición en estado parado.
            # Misma línea que en playback pero ligeramente atenuada (alpha 110)
            # para indicar que es solo el marcador de inicio, no reproducción activa.
            px = int(self._play_pos * w)
            p.setPen(QPen(QColor(int(ac[0]), int(ac[1]), int(ac[2]), 130), 1,
                          Qt.DashLine, Qt.RoundCap))
            p.drawLine(px, 2, px, h-2)

        # Borde
        p.setPen(QPen(QColor(int(br[0]),int(br[1]),int(br[2]),28), 1))
        p.setBrush(Qt.NoBrush); p.drawRoundedRect(0,0,w-1,h-1,6,6)

        # Glow analógico de borde proporcional al RMS
        if self._rms > 0.04:
            _ga = int(min(45, self._rms * 85))
            _wr = int(THEME["vu_red"][1:3],16)
            _wg_col = int(THEME["vu_green"][3:5],16)
            _wb = int(THEME["vu_green"][5:7],16)
            # Interpolar color verde→amarillo→rojo según RMS
            if self._rms > 0.72:
                _gr = int(THEME["vu_red"][1:3],16)
                _gg = int(THEME["vu_red"][3:5],16)
                _gb = int(THEME["vu_red"][5:7],16)
            elif self._rms > 0.42:
                _gr = int(THEME["vu_yellow"][1:3],16)
                _gg = int(THEME["vu_yellow"][3:5],16)
                _gb = int(THEME["vu_yellow"][5:7],16)
            else:
                _gr = int(THEME["vu_green"][1:3],16)
                _gg = int(THEME["vu_green"][3:5],16)
                _gb = int(THEME["vu_green"][5:7],16)
            p.setBrush(Qt.NoBrush)
            for _off in (3, 2, 1):
                _alpha = int(_ga * _off / 3)
                p.setPen(QPen(QColor(_gr, _gg, _gb, _alpha), 1))
                p.drawRoundedRect(-_off, -_off, w+_off*2-1, h+_off*2-1, 6+_off, 6+_off)

        # Etiqueta de modo
        mode_txt = {"rec":"GRABANDO","playback":"PLAYBACK","idle":""}.get(self._mode,"")
        if mode_txt:
            fnt = font_ui(size=6, bold=True)
            fnt.setLetterSpacing(QFont.AbsoluteSpacing, 2); p.setFont(fnt)
            p.setPen(QColor(int(ac[0]),int(ac[1]),int(ac[2]),110))
            p.drawText(QRect(6,3,w-12,12), Qt.AlignLeft|Qt.AlignVCenter, mode_txt)

        self._dirty = False
        p.end()



def _waveform_compute(path: str, rate: int, waveform_widget) -> tuple:
    """
    FIX-WAVEFORM-THREAD-CRASH: funcion pura sin dependencias Qt.
    Calcula mn_arr, mx_arr y peak_clip desde archivo de audio.
    Puede llamarse desde cualquier hilo; no toca ningun objeto Qt.
    """
    try:
        try:
            WMAX = 4096
            # FIX-WAVEFORM-THREAD-CRASH-2: waveform_widget.width() es una llamada Qt
            # y NO puede ejecutarse desde un hilo no-GUI (SIGSEGV en Wayland).
            # Usamos el atributo _last_known_width que el GUI thread actualiza en
            # resizeEvent, o el valor de geometría guardado en _cached_width.
            # Si no existe, caemos a 1024 (valor seguro sin llamada Qt).
            W = min(max(
                getattr(waveform_widget, '_cached_width', 1024),
                256), WMAX)
        except Exception:
            W = 1024
        mn_accum = []
        mx_accum = []
        peak_abs = 0.0
        with sf.SoundFile(path, "r") as f:
            total = f.frames
            if total == 0:
                return (np.zeros(256, dtype=np.float32),
                        np.zeros(256, dtype=np.float32), False)
            fpp = max(1, total // W)
            for chunk in f.blocks(blocksize=fpp, dtype="float32",
                                   always_2d=True, fill_value=0):
                col = chunk[:, 0]
                mn_accum.append(float(col.min()))
                mx_accum.append(float(col.max()))
                pa = float(np.max(np.abs(col)))
                if pa > peak_abs:
                    peak_abs = pa
        denom  = max(peak_abs, 1e-9)
        mn_arr = np.array(mn_accum, dtype=np.float32) / denom
        mx_arr = np.array(mx_accum, dtype=np.float32) / denom
        if len(mn_arr) > W:
            step2  = len(mn_arr) // W
            mn_arr = mn_arr[:step2 * W].reshape(-1, step2).min(axis=1)
            mx_arr = mx_arr[:step2 * W].reshape(-1, step2).max(axis=1)
        return mn_arr, mx_arr, peak_abs >= 0.99
    except Exception as e:
        _log.error("_waveform_compute: %s", e)
        return (np.zeros(256, dtype=np.float32),
                np.zeros(256, dtype=np.float32), False)

class _WaveformUpdateWorker:
    """
    OPT-07: Worker persistente para actualización asíncrona de WaveformDisplay.
    Reemplaza los 3 hilos efímeros (aecct2-waveform, aecct2-waveform-stop,
    aecct2-waveform-recovery) que se lanzaban con threading.Thread + lambda.
    Los lambdas capturaban variables locales → presión en GC por closures.
    Hilo daemon único; recibe (waveform_widget, path, rate) via submit().
    Las peticiones más recientes desplazan a las anteriores si la cola está llena
    (solo interesa la última posición — waveform más reciente).
    """
    def __init__(self):
        self._queue: queue.Queue = queue.Queue(maxsize=4)
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="crac-waveform"
        )
        self._thread.start()

    def submit(self, waveform_widget, path: str, rate: int) -> None:
        """Encola actualización. Si cola llena descarta la más antigua."""
        # Vaciar cola para quedarnos solo con la solicitud más reciente
        while True:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break
        try:
            self._queue.put_nowait((waveform_widget, path, rate))
        except queue.Full:
            pass

    def _loop(self) -> None:
        while True:
            item = self._queue.get()
            waveform_widget, path, rate = item
            try:
                # FIX-WAVEFORM-THREAD-CRASH: calcular datos en el worker thread
                # pero NUNCA tocar atributos Qt ni llamar self.update() aquí.
                # Qt/Wayland no es thread-safe para operaciones de pintura:
                # llamar update() desde un hilo no-GUI produce SIGSEGV en
                # QWaylandShmBackingStore::finalizeBackBuffer (Signal 11).
                mn_arr, mx_arr, peak_clip = _waveform_compute(path, rate,
                                                               waveform_widget)
                # Emitir al GUI thread para que aplique los datos y repinte.
                _bridge.waveform_ready.emit(waveform_widget, mn_arr, mx_arr,
                                            peak_clip)
            except Exception as exc:
                _log.debug("_WaveformUpdateWorker: %s", exc)

_waveform_worker = _WaveformUpdateWorker()
