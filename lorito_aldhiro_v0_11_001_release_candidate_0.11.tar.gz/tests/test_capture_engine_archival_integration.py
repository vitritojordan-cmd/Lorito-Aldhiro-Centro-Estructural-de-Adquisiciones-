"""
test_capture_engine_archival_integration.py — GAP-052, FASE 2
("Archival State", §8/§9) de la Orden Maestra de Saneamiento,
Integración y Consolidación de Lorito Aldhiro.

Verifica `CaptureEngineV2.classify_session()` (nuevo — antes,
`classify_session()` de `backend/archival/` solo se ejercitaba con
telemetría sintética en tests, nunca conectado al motor real) contra
un `CaptureEngineV2` REAL, con segmentos WAV REALES en disco y
checksums REALES (`compute_segment_checksum()`, la misma función que
usa `DiskWriterV2._close_segment()` en producción) — pero SIN correr
el ciclo completo `start()`/callback de audio/hilos en tiempo real.

Nota de diseño (hallazgo real de esta sesión, ver GAP-052 para el
detalle): se intentó primero ejercitar esto de punta a punta con el
mismo arnés de captura simulada de GAP-037 (`_audio_callback` real vía
`sounddevice` funcional). Resultó genuinamente intermitente en este
sandbox — confirmado con `faulthandler` que el hilo de `DiskWriterV2.
_write_loop` a veces no sale de `ColaElasticaDisco.get_batch()` a
tiempo tras `stop()`, incluso con un ÚNICO ciclo real por archivo de
test, en un proceso Python fresco. Es una fragilidad de timing de
hilos real (reproducible también con el test YA EXISTENTE de GAP-037
corrido en aislamiento, `test_real_pipeline_writes_audio_to_disk` —
no es un defecto introducido en esta fase), y perseguirla tocaría el
propio `DiskWriterV2`/watchdog — código de captura en tiempo real que
esta Orden pide no tocar sin poder verificarlo con hardware real.
Este archivo verifica en su lugar el CABLEADO real de
`classify_session()` (¿reúne correctamente status/segment_paths/
segment_checksums del motor real y se los pasa a `backend.archival.
classify_session()`?) construyendo el estado del motor directamente
— mismo patrón ya establecido en GAP-036/041 para `_build_export_
array` (`tests/test_main_window_export_exploration.py`: `app._engine.
_disk_writer._segment_paths = seg_paths`, sin correr una captura real).
La LÓGICA de clasificación en sí (todas las ramas SAFE/DEGRADED/
INVALID, campos cuantitativos) ya está cubierta exhaustivamente y sin
ninguna fragilidad en `tests/test_archival_result_contract.py` (pura
E/S de archivos, sin hilos).
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import numpy as np  # noqa: E402

import lorito_aldhiro.backend.capture.lorito_capture_engine as ce_mod  # noqa: E402
from lorito_aldhiro.backend.archival import ArchivalState  # noqa: E402
from lorito_aldhiro.backend.archival.lorito_segment_checksum import (
    compute_segment_checksum,
)  # noqa: E402
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator  # noqa: E402


def _write_real_wav(path, rate=48000, channels=2, sampwidth=3, n_frames=1000):
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sampwidth)
        wf.setframerate(rate)
        wf.writeframesraw(bytes(n_frames * channels * sampwidth))


class TestCaptureEngineClassifySessionWiring(unittest.TestCase):
    """`CaptureEngineV2()` se instancia real (sin `.start()` — el
    `__init__` no toca hardware ni arranca ningún hilo, ver
    `lorito_capture_engine.py`), y se pueblan sus estructuras internas
    con segmentos WAV y checksums REALES, exactamente con la forma que
    `DiskWriterV2` produciría tras una captura de verdad."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_archival_wiring_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _engine_with_real_segments(self, n_segments=2, frames_per_segment=1000):
        engine = ce_mod.CaptureEngineV2()
        paths = []
        checksums = []
        for i in range(n_segments):
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_real_wav(p, n_frames=frames_per_segment)
            paths.append(p)
            # Misma función real que `DiskWriterV2._close_segment()`
            # usa en producción (GAP-035) — no un stub ni un valor
            # inventado.
            checksums.append(compute_segment_checksum(p))
        engine._disk_writer._segment_paths = paths
        engine._disk_writer._segment_checksums = checksums
        engine._status.frames_received = n_segments * frames_per_segment
        engine._status.frames_written = n_segments * frames_per_segment
        return engine, paths

    def test_classify_session_delegates_with_real_segments_and_checksums(self):
        engine, paths = self._engine_with_real_segments(n_segments=3)

        result = engine.classify_session()

        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertTrue(result.checksum_verified)
        self.assertEqual(result.segments_expected, 3)
        self.assertEqual(result.segments_valid, 3)
        self.assertEqual(result.segments_invalid, 0)
        self.assertEqual(result.frames_expected, 3000)
        self.assertEqual(result.frames_written, 3000)

    def test_classify_session_reflects_real_telemetry_mutations(self):
        engine, _ = self._engine_with_real_segments(n_segments=1)
        engine._status.xrun_count = 5

        result = engine.classify_session()
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertTrue(any("xrun_count=5" in r for r in result.reasons))

    def test_classify_session_detects_real_bit_corruption_after_close(self):
        engine, paths = self._engine_with_real_segments(n_segments=1)
        # Corromper el segmento YA "cerrado" (checksum ya calculado
        # sobre el contenido original) — exactamente el escenario de
        # bit rot entre la captura y una clasificación posterior que
        # motivó GAP-035.
        with open(paths[0], "r+b") as f:
            f.seek(50)
            byte = f.read(1)
            f.seek(50)
            f.write(bytes([byte[0] ^ 0xFF]))

        result = engine.classify_session()
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertFalse(result.checksum_verified)
        self.assertEqual(result.segments_invalid, 1)

    def test_classify_session_missing_segment_file_is_invalid(self):
        engine, paths = self._engine_with_real_segments(n_segments=2)
        os.remove(paths[0])

        result = engine.classify_session()
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertEqual(result.segments_invalid, 1)
        self.assertEqual(result.segments_valid, 1)


class TestCaptureEngineClassifySessionNonfiniteWiring(unittest.TestCase):
    """GAP-062 (§16, FASE 6) — `nr_coordinator.nonfinite_counts` REAL
    (no simulado) debe llegar a `classify_session()` y degradar la
    clasificación, política confirmada por el usuario vía
    cuestionario. Usa un `NRCoordinator` real, con `process_chunk()`
    real sobre un bloque con NaN real — no se inyecta el contador a
    mano."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_archival_nonfinite_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _engine_with_real_segment(self, n_frames=1000):
        engine = ce_mod.CaptureEngineV2()
        p = os.path.join(self.tmpdir, "seg0000.wav")
        _write_real_wav(p, n_frames=n_frames)
        checksum = compute_segment_checksum(p)
        engine._disk_writer._segment_paths = [p]
        engine._disk_writer._segment_checksums = [checksum]
        engine._status.frames_received = n_frames
        engine._status.frames_written = n_frames
        return engine

    def test_no_nr_coordinator_assigned_behaves_exactly_as_before_gap062(self):
        engine = self._engine_with_real_segment()
        self.assertIsNone(engine.nr_coordinator)  # default real del motor

        result = engine.classify_session()
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertEqual(result.dsp_nonfinite_total, 0)

    def test_real_nan_sanitized_by_nr_coordinator_degrades_classification(self):
        engine = self._engine_with_real_segment()
        engine.nr_coordinator = NRCoordinator(sample_rate=48000, channels=2)

        # Bloque REAL con un NaN real — dispara sanitize_finite() de
        # verdad dentro de process_chunk(), exactamente como lo haría
        # el drain loop de producción si le llegara un glitch.
        chunk = np.zeros((256, 2), dtype=np.float32)
        chunk[10, 0] = np.nan
        chunk[20, 1] = np.inf
        engine.nr_coordinator.process_chunk(chunk)
        self.assertEqual(sum(engine.nr_coordinator.nonfinite_counts.values()), 2)

        result = engine.classify_session()
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertEqual(result.dsp_nonfinite_total, 2)
        self.assertTrue(any("DSP_NONFINITE_SANITIZED" in r.code for r in result.reasons))

    def test_nr_coordinator_with_zero_nonfinite_stays_archival_safe(self):
        engine = self._engine_with_real_segment()
        engine.nr_coordinator = NRCoordinator(sample_rate=48000, channels=2)

        # Bloque limpio real — process_chunk() real, sin NaN/Inf.
        chunk = (0.2 * np.ones((256, 2), dtype=np.float32))
        engine.nr_coordinator.process_chunk(chunk)

        result = engine.classify_session()
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertEqual(result.dsp_nonfinite_total, 0)


if __name__ == "__main__":
    unittest.main()
