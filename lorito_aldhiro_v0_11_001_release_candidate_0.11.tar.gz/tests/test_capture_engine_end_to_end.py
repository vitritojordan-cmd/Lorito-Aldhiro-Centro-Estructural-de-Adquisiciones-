"""
test_capture_engine_end_to_end.py — GAP-037, cierre de los frentes que
quedaban "bloqueados por hardware real" usando un stub funcional de
`sounddevice.InputStream` (`tests/_functional_sounddevice_stub.py`) y
el stub funcional de `soundfile` ya construido en GAP-036
(`tests/_functional_soundfile_stub.py`).

Con ambos, `CaptureEngineV2` se puede correr de PUNTA A PUNTA en este
sandbox: `_audio_callback` real recibe bloques de un hilo que simula
el driver de audio, los escribe en `RingBufferAbsorcion` real, el
drain loop real los mueve a `ColaElasticaDisco` real, y `DiskWriterV2`
real los escribe a un archivo WAV real en disco — sin ningún mock de
la lógica intermedia, solo los dos puntos de entrada/salida con el
hardware (el driver de audio y `soundfile`) están simulados.

No reemplaza la verificación con hardware real (timing exacto del
sistema operativo, jitter real del scheduler) — pero SÍ verifica, con
ejecución real, la mecánica completa del pipeline, incluida la
integración de `LockFreeSPSCRingBuffer` como reemplazo de
`RingBufferAbsorcion` (Fase 3, GAP-031) bajo la misma carga.
"""

import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from tests._functional_soundfile_stub import install_functional_soundfile_stub
from tests._functional_sounddevice_stub import (
    install_functional_sounddevice_stub, FunctionalInputStream,
)

install_functional_soundfile_stub()
install_functional_sounddevice_stub(block_interval=0.0)

import lorito_aldhiro.backend.capture.lorito_capture_engine as ce_mod  # noqa: E402
from lorito_aldhiro.backend.rt import LockFreeSPSCRingBuffer  # noqa: E402
from lorito_aldhiro.backend.core.lorito_constants import CE_RBA_SLOTS  # noqa: E402

# GAP-041 — si `lorito_capture_engine` ya fue importado por OTRO
# archivo de test antes que este (el orden de `unittest discover` es
# alfabético y puede variar según qué archivos existan), `ce_mod.sd`/
# `ce_mod.sf` pueden seguir apuntando a un stub distinto (p. ej. el
# dummy de `_install_stub_modules`) — reinstalar `sys.modules` arriba
# no alcanza para un módulo YA importado (mismo patrón ya documentado
# en GAP-036/037). Se reasignan los atributos directamente para
# garantizar el stub funcional en este archivo, sin importar el orden.
ce_mod.sd = sys.modules["sounddevice"]
ce_mod.sf = sys.modules["soundfile"]


def _read_wav_frames(path):
    import wave
    with wave.open(path, "rb") as wf:
        return wf.getnframes(), wf.getnchannels(), wf.getframerate()


class TestCaptureEndToEnd(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_e2e_")
        self.path = os.path.join(self.tmpdir, "captura.wav")
        self._orig_input_stream_factory = ce_mod.sd.InputStream

    def tearDown(self):
        ce_mod.sd.InputStream = self._orig_input_stream_factory
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_real_pipeline_writes_audio_to_disk(self):
        engine = ce_mod.CaptureEngineV2()
        engine.set_output(self.path, rate=48000, channels=2)
        ok = engine.start(rate=48000, blocksize=1024)
        self.assertTrue(ok)

        # Dejar correr la captura simulada un momento — con
        # block_interval=0.0 el stub entrega bloques tan rápido como
        # puede, así que unas pocas décimas de segundo ya representan
        # miles de bloques procesados de verdad por todo el pipeline.
        time.sleep(0.3)

        engine.stop()
        engine.flush_disk()
        engine._disk_writer.stop()  # cierra y finaliza el segmento en disco

        status = engine.get_status()
        self.assertGreater(status.frames_received, 0)
        self.assertGreater(status.frames_written, 0)
        self.assertEqual(status.frames_dropped, 0)

        n_frames, channels, rate = _read_wav_frames(self.path)
        self.assertGreater(n_frames, 0)
        self.assertEqual(channels, 2)
        self.assertEqual(rate, 48000)
        # El pipeline no debe perder frames entre lo recibido y lo escrito.
        self.assertEqual(n_frames, status.frames_written)

    def test_recovery_triggers_on_simulated_stream_death(self):
        # El stub de InputStream puede "morir" tras N bloques — el
        # watchdog real de CaptureEngineV2 debe notarlo y disparar
        # _auto_recover(), que reabre el stream (uno nuevo, también
        # simulado) y la captura continúa.
        #
        # IMPORTANTE: reinstalar `sys.modules['sounddevice']` con
        # `install_functional_sounddevice_stub()` NO alcanza aquí —
        # `ce_mod.sd` ya quedó vinculado al módulo original desde el
        # primer `import sounddevice as sd` de este archivo de test;
        # reasignar `sys.modules[...]` después no cambia esa
        # referencia ya vinculada (mismo patrón ya visto con
        # `soundfile` en GAP-036). Hay que mutar el ATRIBUTO del
        # módulo ya vinculado directamente.
        def _dying_factory(*a, **k):
            k["n_blocks_before_death"] = 20
            return FunctionalInputStream(*a, **k)
        ce_mod.sd.InputStream = _dying_factory

        engine = ce_mod.CaptureEngineV2()
        engine.set_output(self.path, rate=48000, channels=2)
        ok = engine.start(rate=48000, blocksize=512)
        self.assertTrue(ok)

        # Esperar lo suficiente para que el stream simulado muera y el
        # watchdog dispare recovery — el watchdog tiene su propio tick,
        # damos tiempo real de sobra (no es un test de timing exacto).
        deadline = time.monotonic() + 15.0
        while engine.get_status().recovery_count == 0 and time.monotonic() < deadline:
            time.sleep(0.1)

        status = engine.get_status()
        engine.stop()
        engine._disk_writer.stop()
        ce_mod.sd.InputStream = self._orig_input_stream_factory

        self.assertGreater(status.recovery_count, 0,
                           "el watchdog debió detectar la muerte del stream "
                           "y disparar recovery")


class TestLockFreeRingBufferUnderRealPipeline(unittest.TestCase):
    """Fase 3 (GAP-031) — el swap real de `RingBufferAbsorcion` por
    `LockFreeSPSCRingBuffer` sigue sin hacerse en el código de
    producción (cambiaría la firma que usa `_audio_callback`/drain
    loop), pero aquí se verifica, bajo la MISMA carga simulada de
    audio real que ejercita el resto de este archivo, que el ring
    buffer alternativo se comporta correctamente como reemplazo
    directo: se le puede alimentar con los mismos bloques que
    `_audio_callback` produciría y drenar con la misma disciplina."""

    def test_spsc_ring_buffer_survives_same_load_as_rba(self):
        rb = LockFreeSPSCRingBuffer(n_slots=CE_RBA_SLOTS, frames_max=2048, channels=2)

        received_frames = {"n": 0}

        def _fake_callback(indata, frames, t, status):
            rb.write(indata.copy())

        stream = FunctionalInputStream(
            samplerate=48000, channels=2, dtype="float32", blocksize=1024,
            callback=_fake_callback, block_interval=0.0)

        # Drenar EN PARALELO con la producción — el mismo patrón
        # SPSC concurrente ya validado en GAP-031 (drenar solo
        # DESPUÉS de que el productor termine, a máxima velocidad,
        # no es un escenario SPSC realista: varias vueltas completas
        # se solaparían antes de que exista ningún lector, y el
        # conteo de overrun no reconstruye ese historial completo de
        # sobrescrituras — es un defecto del diseño del test, no del
        # ring buffer, ya verificado exhaustivamente en GAP-031).
        stop_reading = threading.Event()

        def _drain():
            while not stop_reading.is_set():
                item = rb.read()
                if item is None:
                    time.sleep(0.0001)
                    continue
                data, n = item
                received_frames["n"] += n

        reader = threading.Thread(target=_drain, daemon=True)
        reader.start()
        stream.start()
        time.sleep(0.2)
        stream.stop()
        # Drenar cualquier resto pendiente tras detener el productor.
        time.sleep(0.05)
        stop_reading.set()
        reader.join(timeout=2.0)

        self.assertGreater(received_frames["n"], 0)
        total_delivered = stream._blocks_delivered * 1024
        self.assertEqual(received_frames["n"] + rb.overrun_total, total_delivered)


class TestDiskWriterFlushSettleBound(unittest.TestCase):
    """GAP-064 — regresión del defecto real medido en `DiskWriterV2.
    flush()`: antes de este GAP, `flush()` esperaba el `timeout`
    COMPLETO (30s por defecto) cada vez que se llamaba con el hilo de
    escritura AÚN ACTIVO (el caso previsto por esta API pública —
    vaciar la cola sin detener la captura), porque internamente
    esperaba sobre `_flush_done`, un Event que solo se marca cuando el
    hilo TERMINA. Confirmado con medición real: `test_real_pipeline_
    writes_audio_to_disk` (arriba) tardaba ~36s en total por esta
    única llamada, capturando solo 0.3s de audio. Este test ejercita
    `DiskWriterV2` de forma aislada (sin pasar por `CaptureEngineV2`
    completo) para acotar exactamente el tiempo de `flush()` en el
    caso común: hilo vivo, cola ya vacía."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_flush_")
        self.path = os.path.join(self.tmpdir, "flush_test.wav")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_flush_returns_promptly_when_writer_active_and_queue_empty(self):
        status = ce_mod.CaptureEngineStatus()
        ced    = ce_mod.ColaElasticaDisco()
        writer = ce_mod.DiskWriterV2(ced, status)
        writer.start(self.path, rate=48000, channels=2)
        try:
            block = np.zeros((4096, 2), dtype=np.float32)
            self.assertTrue(ced.put_nowait(block))

            t0 = time.monotonic()
            writer.flush(timeout=30.0)  # el hilo SIGUE activo — no se llamó stop()
            dt = time.monotonic() - t0

            self.assertLess(
                dt, 5.0,
                f"flush() tardó {dt:.1f}s con el hilo de escritura aún "
                f"activo — debería acotarse a CE_DISK_FLUSH_SETTLE_MAX_S "
                f"(2.0s), no al timeout completo de 30s (regresión del "
                f"defecto real de GAP-064)")
            self.assertGreater(status.frames_written, 0)
            self.assertEqual(ced.frame_count, 0)
        finally:
            writer.stop()


if __name__ == "__main__":
    unittest.main()
