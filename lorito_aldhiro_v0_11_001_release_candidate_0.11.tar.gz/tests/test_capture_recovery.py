"""
test_capture_recovery.py — Fase 6 (recovery no-destructivo) de la
Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic.

Mismo mecanismo de stubs que `test_cola_elastica_disco.py` para poder
importar `lorito_capture_engine.py` en este sandbox. La lógica de
`_auto_recover` (backoff exponencial, cooldown, rotación de
blocksize, preservación de RBA/CED) es pura — no requiere audio real
para verificarse — se mockean `time.sleep`/`time.monotonic` y
`_open_stream`/`_close_stream` para hacerla determinista y rápida.
"""

import sys
import types
import unittest
from unittest.mock import patch


def _install_stubs():
    if "sounddevice" not in sys.modules or getattr(sys.modules["sounddevice"], "__lorito_stub__", False):
        stub_sd = types.ModuleType("sounddevice")
        stub_sd.__lorito_stub__ = True
        stub_sd.InputStream = object
        stub_sd.query_devices = lambda *a, **k: []
        sys.modules["sounddevice"] = stub_sd
    if "soundfile" not in sys.modules or getattr(sys.modules["soundfile"], "__lorito_stub__", False):
        stub_sf = types.ModuleType("soundfile")
        stub_sf.__lorito_stub__ = True
        stub_sf.SoundFile = object
        sys.modules["soundfile"] = stub_sf


_install_stubs()

import lorito_aldhiro.backend.capture.lorito_capture_engine as ce_mod  # noqa: E402
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2  # noqa: E402


class _FakeClock:
    """Reloj monotónico falso — avanza manualmente, sin esperar tiempo real."""

    def __init__(self, start=1000.0):
        self.t = start

    def monotonic(self):
        return self.t

    def sleep(self, secs):
        self.t += secs  # el backoff SÍ avanza el reloj lógico, sin esperar de verdad


class TestAutoRecoverLogic(unittest.TestCase):
    def setUp(self):
        self.engine = CaptureEngineV2()
        self.clock = _FakeClock()
        self._patches = [
            patch.object(ce_mod.time, "sleep", self.clock.sleep),
            patch.object(ce_mod.time, "monotonic", self.clock.monotonic),
        ]
        for p in self._patches:
            p.start()

    def tearDown(self):
        for p in self._patches:
            p.stop()

    def test_succeeds_on_first_attempt_no_blocksize_rotation(self):
        original_bs = self.engine.blocksize
        with patch.object(self.engine, "_open_stream", return_value=True) as m_open, \
             patch.object(self.engine, "_close_stream") as m_close:
            self.engine._auto_recover()
        m_close.assert_called_once()
        self.assertEqual(m_open.call_count, 1)
        self.assertEqual(self.engine.blocksize, original_bs)
        self.assertTrue(self.engine._status.stream_alive)
        self.assertEqual(self.engine._status.wd_phase, "OK")
        self.assertEqual(self.engine._status.recovery_count, 1)

    def test_blocksize_rotates_starting_at_attempt_4(self):
        # Falla 4 veces (intentos 1-4, índices 0-3), tiene éxito en el 5º.
        attempts = {"n": 0}

        def _fake_open():
            attempts["n"] += 1
            return attempts["n"] >= 5

        with patch.object(self.engine, "_open_stream", side_effect=_fake_open), \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()

        # bs_candidates tras dedup (mantiene orden): [2048, 512, 1024, 4096]
        # (2048 es self.blocksize inicial, aparece dos veces en la lista
        # original y el dedup se queda con la primera aparición).
        # attempt=3 (4º intento, 0-based) → bs_idx=(3-3)%4=0 → 2048 (sin
        # cambio visible). attempt=4 (5º intento) → bs_idx=(4-3)%4=1 →
        # candidates[1]=512, y ese intento es el que tiene éxito.
        self.assertEqual(self.engine.blocksize, 512)
        self.assertTrue(self.engine._status.stream_alive)

    def test_cooldown_blocks_immediate_reentry(self):
        with patch.object(self.engine, "_open_stream", return_value=True), \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()
        self.assertEqual(self.engine._status.recovery_count, 1)

        # Sin avanzar el reloj — segunda llamada inmediata debe
        # bloquearse por cooldown (CE_RECOVERY_COOLDOWN=45s).
        with patch.object(self.engine, "_open_stream", return_value=True) as m_open2, \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()
        self.assertEqual(self.engine._status.recovery_count, 1,
                         msg="el cooldown debe impedir un segundo recovery inmediato")
        m_open2.assert_not_called()

    def test_reentry_allowed_after_cooldown_elapses(self):
        with patch.object(self.engine, "_open_stream", return_value=True), \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()
        self.assertEqual(self.engine._status.recovery_count, 1)

        self.clock.t += 46.0  # más que CE_RECOVERY_COOLDOWN=45.0

        with patch.object(self.engine, "_open_stream", return_value=True), \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()
        self.assertEqual(self.engine._status.recovery_count, 2)

    def test_exhausts_all_attempts_without_crashing(self):
        with patch.object(self.engine, "_open_stream", return_value=False) as m_open, \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()  # no debe lanzar excepción
        from lorito_aldhiro.backend.core.lorito_constants import CE_RECOVERY_MAX_ATTEMPTS
        self.assertEqual(m_open.call_count, CE_RECOVERY_MAX_ATTEMPTS)
        self.assertFalse(self.engine._status.stream_alive)

    def test_recovery_never_clears_rba_or_ced(self):
        # No-destructivo: `_auto_recover` no debe tocar el contenido de
        # RBA/CED — se verifica escribiendo datos en ambos ANTES del
        # recovery y confirmando que siguen intactos después.
        import numpy as np
        self.engine._rba.write(np.zeros((100, 2), dtype=np.float32))
        self.engine._ced.put_nowait(np.zeros((50, 2), dtype=np.float32))
        rba_count_before = self.engine._rba._count
        ced_frames_before = self.engine._ced.frame_count

        with patch.object(self.engine, "_open_stream", return_value=True), \
             patch.object(self.engine, "_close_stream"):
            self.engine._auto_recover()

        self.assertEqual(self.engine._rba._count, rba_count_before)
        self.assertEqual(self.engine._ced.frame_count, ced_frames_before)

    def test_on_stream_dead_delegates_to_auto_recover_under_lock(self):
        with patch.object(self.engine, "_open_stream", return_value=True), \
             patch.object(self.engine, "_close_stream"):
            self.engine._on_stream_dead()
        self.assertEqual(self.engine._status.recovery_count, 1)


if __name__ == "__main__":
    unittest.main()
