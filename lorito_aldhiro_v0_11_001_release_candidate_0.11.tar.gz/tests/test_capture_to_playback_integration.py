"""
test_capture_to_playback_integration.py -- GAP-072, FASE 9
("Integration tests", Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro, §19).

Hueco que cierra este archivo: hasta ahora, ningún test verificaba
"Capture -> Playback del mismo audio" -- es decir, que el CONTENIDO
que la mitad "Capture" del pipeline escribe a disco (un segmento WAV
PCM24 real, el mismo formato/escritor que usa `DiskWriterV2`) sobrevive
intacto al cruzar la frontera hacia la mitad "Playback"
(`PlaybackEngine` real, con sus propios hilos de prefetch/bridge/
driver-de-audio).

Cobertura existente que NO cierra este hueco (deslindado explícitamente
para justificar por qué se necesita un archivo nuevo, no una extensión
de uno de estos dos):

- `tests/test_integration_capture_segment_export_archive.py` (GAP-055):
  Capture -> Export y Capture -> Archive -- nunca llega a Playback.
- `tests/test_playback_engine_integration.py` (GAP-062/063): instancia
  `PlaybackEngine` real con hilos reales y verifica que no crashea y
  que el audio entregado al driver simulado no tiene NaN/Inf -- pero
  usa un fixture ESTÁTICO ajeno a Capture
  (`tests/fixtures/sotalomafer1_scrub_5s.wav`) y nunca compara el
  CONTENIDO entregado contra lo originalmente escrito. Es una prueba
  de integridad mecánica ("no truena"), no de fidelidad de contenido
  a través de la frontera Capture->Playback.

Diseño (mismo criterio de "patrón confiable" que GAP-055 estableció
para "Capture -> X": en vez de correr la captura viva completa con
hilos reales -- documentada como intermitente en este sandbox, ver
`test_capture_engine_end_to_end.py` -- se construye un segmento WAV
real y determinista directamente con `FunctionalSoundFile` (el mismo
escritor PCM24 que usa `DiskWriterV2` de verdad), con contenido
verificable (dos tonos distinguibles por canal, no ruido ni silencio).
Ese archivo se entrega tal cual a un `PlaybackEngine()` real (mismo
arnés que `test_playback_engine_integration.py`: stubs funcionales de
`soundfile`/`sounddevice` reasignados directamente sobre el módulo ya
importado, GAP-036/037/041/063), y se compara el audio que el driver
simulado (`FunctionalOutputStream.captured`) recibió REALMENTE contra
el contenido originalmente escrito.

`speed_ratio=1.0` se eligió porque, confirmado leyendo
`_prefetch()` (líneas ~910-966 de `lorito_playback_engine.py`), el
resampleador se salta por completo cuando
`abs(abs_ratio - 1.0) <= 0.0005` -- es decir, a ratio=1.0 el camino es
un passthrough real: lectura de disco -> `_adapt_channels` (identidad
cuando los canales ya coinciden, confirmado en su propio código,
líneas 283-291) -> cola -> callback. La única transformación real que
sufre el audio es la cuantización PCM24 ida-y-vuelta del propio
`FunctionalSoundFile` (ver `_functional_soundfile_stub.py`) -- por eso
la comparación se hace en el dominio ya cuantizado, mismo criterio ya
usado en `tests/test_normalization_streaming.py` ("comparar en el
dominio PCM24, ambos ya cuantizados igual"), no una igualdad ingenua
contra el float32 original.
"""

import os
import shutil
import sys
import tempfile
import time
import unittest

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)
_ROOT_DIR = os.path.dirname(_TESTS_DIR)
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)

import numpy as np  # noqa: E402

from _functional_soundfile_stub import (  # noqa: E402
    FunctionalSoundFile, install_functional_soundfile_stub,
)
install_functional_soundfile_stub()

from _functional_sounddevice_output_stub import (  # noqa: E402
    install_functional_sounddevice_output_stub,
)
install_functional_sounddevice_output_stub(callback_interval=0.002)

import lorito_aldhiro.backend.playback.lorito_playback_engine as pe  # noqa: E402

# GAP-063 / GAP-072: mismo problema documentado en GAP-036/037/041 --
# si otro archivo de test ya importó `lorito_playback_engine` antes
# (bajo `unittest discover`, orden alfabético de todo el árbol), su
# `sd`/`sf` quedan enlazados al stub/dummy vigente EN ESE MOMENTO.
# Reasignar los atributos directamente sobre el módulo ya importado
# garantiza el stub funcional sin importar el orden de descubrimiento.
pe.sd = sys.modules["sounddevice"]
pe.sf = sys.modules["soundfile"]

FS = 48000
CHANNELS = 2
_PCM24_FULL_SCALE = 8388608.0  # 2**23


def _wait_until(predicate, timeout=3.0, interval=0.01):
    """Sondeo breve -- mismo patrón ya usado en GAP-061/062 para evitar
    carreras reales de hilos."""
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if predicate():
            return True
        time.sleep(interval)
    return predicate()


def _pcm24_roundtrip(x: np.ndarray) -> np.ndarray:
    """Réplica EXACTA (misma expresión, mismo orden de operaciones) de
    la cuantización ida-y-vuelta PCM24 que aplica `FunctionalSoundFile`
    al escribir (`_float32_to_pcm24_bytes`) y volver a leer
    (`_pcm24_bytes_to_float32`) -- ver `tests/_functional_soundfile_stub.py`.
    Se usa para construir la señal "esperada" sin pasar por disco dos
    veces: comparar contra ESTO, no contra el float32 original crudo,
    es el mismo criterio que `tests/test_normalization_streaming.py`
    ya documenta como correcto para este stub."""
    clipped = np.clip(x, -1.0, 1.0)
    pcm = np.clip(np.round(clipped.astype(np.float64) * _PCM24_FULL_SCALE),
                  -_PCM24_FULL_SCALE, _PCM24_FULL_SCALE - 1)
    return (pcm / _PCM24_FULL_SCALE).astype(np.float32)


def _build_segment_wav(path, n_frames, fs=FS, channels=CHANNELS):
    """Construye un segmento WAV real y determinista -- dos tonos de
    frecuencia y fase distintos en L/R (nunca ruido puro ni silencio),
    para que una comparación de contenido sea significativa y capaz de
    detectar un canal invertido/desalineado, no solo "hay algo de
    audio". Se escribe con el MISMO escritor (`FunctionalSoundFile`,
    PCM24) que usa `DiskWriterV2` en producción real."""
    t = np.arange(n_frames, dtype=np.float64) / fs
    left = 0.5 * np.sin(2 * np.pi * 440.0 * t)
    right = 0.35 * np.sin(2 * np.pi * 660.0 * t + 0.3)
    sig = np.stack([left, right], axis=1).astype(np.float32)
    with FunctionalSoundFile(path, "w", samplerate=fs, channels=channels) as f:
        f.write(sig)
    return sig


class TestCaptureToPlaybackContentFidelity(unittest.TestCase):
    """§19: "Capture -> Playback del mismo audio" -- el hueco real que
    ni GAP-055 (Capture->Export/Archive) ni GAP-062
    (Playback con fixture estático) cierran."""

    def setUp(self):
        self._tmpdir = tempfile.mkdtemp(prefix="lorito_cap2play_")
        self._path = os.path.join(self._tmpdir, "segment.wav")
        self.engine = pe.PlaybackEngine()

    def tearDown(self):
        # stop() es idempotente y con timeout -- nunca debe colgar el test.
        self.engine.stop()
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def _start_and_wait_stream(self, speed_ratio, start_frame=0):
        self.engine.start(
            path=self._path, rate=FS, channels=CHANNELS,
            start_frame=start_frame, speed_ratio=speed_ratio, on_done=None,
        )
        self.assertTrue(
            _wait_until(lambda: self.engine.is_active(), timeout=3.0),
            "el hilo de PlaybackEngine no arrancó a tiempo")
        self.assertTrue(
            _wait_until(lambda: self.engine._stream is not None, timeout=3.0),
            "el OutputStream (preload de prefetch) no se abrió a tiempo")
        return self.engine._stream  # referencia propia -- sobrevive a engine.stop()

    def test_forward_playback_at_ratio_1_reproduces_captured_content(self):
        """El caso central del hueco: contenido real escrito por
        "Capture" (segmento PCM24) reproducido a velocidad neutra
        (ratio=1.0, el passthrough real confirmado en `_prefetch()`)
        debe llegar al driver de audio BYTE-a-byte igual (en el
        dominio ya cuantizado PCM24) a lo que se escribió."""
        original = _build_segment_wav(self._path, n_frames=96_000)  # 2s
        expected = _pcm24_roundtrip(original)

        stream = self._start_and_wait_stream(speed_ratio=1.0)

        # 40 callbacks * 512 frames/callback ~= 20480 frames (~0.43s de
        # audio real) -- suficiente para una comparación de contenido
        # significativa sin depender de correr el segmento hasta EOF.
        target_callbacks = 40
        self.assertTrue(_wait_until(
            lambda: stream.callbacks_delivered >= target_callbacks,
            timeout=5.0),
            "el driver de audio simulado no recibió suficientes "
            "callbacks reales")

        self.engine.stop()

        # Se descarta el último bloque capturado: puede incluir el
        # zero-padding del apagado (my_gen != self._gen tras stop(),
        # ver `_audio_cb`) -- no es parte del contenido real de Capture.
        blocks = stream.captured[:-1] if len(stream.captured) > 1 else stream.captured
        self.assertGreater(len(blocks), 0,
                           "el stub de audio no capturó ningún bloque real")
        delivered = np.concatenate(blocks, axis=0)
        n = delivered.shape[0]
        self.assertGreaterEqual(
            n, target_callbacks * 512 // 2,
            "muy poco audio real entregado para una comparación de "
            "contenido significativa")

        np.testing.assert_allclose(
            delivered, expected[:n], atol=1e-6,
            err_msg="el audio entregado al driver de Playback no "
                    "coincide con el contenido originalmente escrito "
                    "por Capture (frontera Capture->Playback rota)")

        # Confirma también que no es una coincidencia trivial (todo
        # silencio, por ejemplo): el segmento real tiene energía.
        self.assertGreater(float(np.abs(delivered).mean()), 0.05)

    def test_forward_playback_content_matches_at_nonneutral_ratio(self):
        """Ejercita también un ratio != 1.0 (resampleador real activo,
        GAP-055/060 ya insisten en no probar solo el caso trivial) --
        aquí no se puede exigir igualdad muestra a muestra (el
        resampleador cúbico introduce interpolación real), pero SÍ que
        el contenido entregado no es silencio/ruido desconectado de lo
        escrito: se verifica correlación fuerte con una versión del
        original re-muestreada al mismo ratio con `numpy.interp` como
        referencia independiente (no reutiliza el código de producción
        bajo prueba)."""
        n_frames = 96_000
        original = _build_segment_wav(self._path, n_frames=n_frames)

        ratio = 1.5
        stream = self._start_and_wait_stream(speed_ratio=ratio)

        target_callbacks = 40
        self.assertTrue(_wait_until(
            lambda: stream.callbacks_delivered >= target_callbacks,
            timeout=5.0),
            "el driver de audio simulado no recibió suficientes "
            "callbacks reales (ratio no neutro)")

        self.engine.stop()

        blocks = stream.captured[:-1] if len(stream.captured) > 1 else stream.captured
        self.assertGreater(len(blocks), 0)
        delivered = np.concatenate(blocks, axis=0)
        n = delivered.shape[0]
        self.assertGreater(n, 0)

        # Referencia INDEPENDIENTE (no es el código bajo prueba):
        # interpolación lineal simple de la señal original cuantizada
        # PCM24, muestreada a ratio*n puntos -- solo para confirmar
        # que el contenido entregado sigue la MISMA envolvente/fase
        # aproximada de la fuente real, no una señal desconectada.
        expected_pcm24 = _pcm24_roundtrip(original)
        src_idx = np.arange(n, dtype=np.float64) * ratio
        src_idx = np.clip(src_idx, 0, n_frames - 1)
        ref_l = np.interp(src_idx, np.arange(n_frames), expected_pcm24[:, 0])
        ref_r = np.interp(src_idx, np.arange(n_frames), expected_pcm24[:, 1])
        ref = np.stack([ref_l, ref_r], axis=1).astype(np.float32)

        corr_l = np.corrcoef(delivered[:, 0], ref[:, 0])[0, 1]
        corr_r = np.corrcoef(delivered[:, 1], ref[:, 1])[0, 1]
        self.assertGreater(corr_l, 0.95,
                           "canal L entregado no correlaciona con el "
                           "contenido de Capture re-muestreado al ratio")
        self.assertGreater(corr_r, 0.95,
                           "canal R entregado no correlaciona con el "
                           "contenido de Capture re-muestreado al ratio")

    def test_stereo_channels_are_not_swapped_across_the_boundary(self):
        """Detector explícito de un bug de canal-invertido (L<->R) al
        cruzar Capture->Playback: L y R llevan tonos de frecuencia MUY
        distinta (440Hz vs 660Hz) precisamente para que un swap sea
        mecánicamente detectable comparando correlación cruzada, no
        solo "ambos canales tienen audio"."""
        original = _build_segment_wav(self._path, n_frames=48_000)
        expected = _pcm24_roundtrip(original)

        stream = self._start_and_wait_stream(speed_ratio=1.0)
        self.assertTrue(_wait_until(
            lambda: stream.callbacks_delivered >= 20, timeout=5.0))
        self.engine.stop()

        blocks = stream.captured[:-1] if len(stream.captured) > 1 else stream.captured
        delivered = np.concatenate(blocks, axis=0)
        n = delivered.shape[0]
        self.assertGreater(n, 0)

        same_channel_l = np.corrcoef(delivered[:, 0], expected[:n, 0])[0, 1]
        same_channel_r = np.corrcoef(delivered[:, 1], expected[:n, 1])[0, 1]
        cross_l_vs_r = np.corrcoef(delivered[:, 0], expected[:n, 1])[0, 1]
        cross_r_vs_l = np.corrcoef(delivered[:, 1], expected[:n, 0])[0, 1]

        self.assertGreater(same_channel_l, 0.99)
        self.assertGreater(same_channel_r, 0.99)
        self.assertLess(cross_l_vs_r, same_channel_l,
                        "el canal L entregado correlaciona mejor con el "
                        "R original que con el L original -- posible swap")
        self.assertLess(cross_r_vs_l, same_channel_r,
                        "el canal R entregado correlaciona mejor con el "
                        "L original que con el R original -- posible swap")


if __name__ == "__main__":
    unittest.main()
