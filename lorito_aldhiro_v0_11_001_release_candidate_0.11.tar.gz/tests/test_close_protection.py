"""
test_close_protection.py — GAP-038, mecanismos de protección ante
crasheos fatales por condición de carrera al cerrar el sistema con
"motores corriendo", replicados desde CRAC (tarball
crac_v0_37_416_quad_previ_chain_derived_export) a pedido del usuario.

Defecto real encontrado y corregido: `LoritoAldhiroStudio.closeEvent`
NUNCA detenía `DiskWriterV2` en las ramas GUARDAR/DESCARTAR de
`CierreAbruptoDialog` — un comentario (`FIX-STOP-DOUBLE`) afirmaba
falsamente que `CaptureEngineV2.stop()` ya lo hacía internamente; no
era así. El hilo de escritura a disco (daemon) quedaba vivo mientras
la app cerraba — la misma familia de condición de carrera que CRAC
saneó con `wait_for_pending_stream_close()`/`FIX-CIERRE-FATAL-
DEFERRED-CLOSE`, adaptada aquí a la arquitectura real de Lorito
(`CaptureEngineV2.wait_for_background_threads()`).
"""

import os
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from tests._functional_soundfile_stub import install_functional_soundfile_stub
from tests._functional_sounddevice_stub import install_functional_sounddevice_stub

install_functional_soundfile_stub()
install_functional_sounddevice_stub(block_interval=0.0)

from tests.test_stability_patch import _install_stub_modules  # noqa: E402
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
import lorito_aldhiro.backend.capture.lorito_capture_engine as ce_mod  # noqa: E402

# GAP-041 — mismo fix que test_capture_engine_end_to_end.py: garantizar
# el stub funcional en este archivo sin depender del orden de import
# entre archivos de test.
ce_mod.sd = sys.modules["sounddevice"]
ce_mod.sf = sys.modules["soundfile"]
mw.sf = sys.modules["soundfile"]


class _FakeCloseEvent:
    def __init__(self):
        self._accepted = None

    def ignore(self):
        self._accepted = False

    def accept(self):
        self._accepted = True


class TestWaitForBackgroundThreads(unittest.TestCase):
    def test_returns_true_when_no_threads_running(self):
        engine = ce_mod.CaptureEngineV2()
        self.assertTrue(engine.wait_for_background_threads(timeout=1.0))

    def test_joins_alive_thread_within_timeout(self):
        import threading
        engine = ce_mod.CaptureEngineV2()
        finished = {"v": False}

        def _work():
            time.sleep(0.2)
            finished["v"] = True

        engine._drain_t = threading.Thread(target=_work, daemon=True)
        engine._drain_t.start()
        ok = engine.wait_for_background_threads(timeout=2.0)
        self.assertTrue(ok)
        self.assertTrue(finished["v"])

    def test_reports_false_if_thread_exceeds_timeout(self):
        import threading
        engine = ce_mod.CaptureEngineV2()
        stop_flag = threading.Event()

        def _work():
            stop_flag.wait(timeout=5.0)

        engine._watchdog_t = threading.Thread(target=_work, daemon=True)
        engine._watchdog_t.start()
        try:
            ok = engine.wait_for_background_threads(timeout=0.1)
            self.assertFalse(ok)
        finally:
            stop_flag.set()
            engine._watchdog_t.join(timeout=2.0)

    def test_stop_calls_wait_for_background_threads(self):
        engine = ce_mod.CaptureEngineV2()
        engine.set_output(tempfile.mktemp(suffix=".wav"), rate=48000, channels=2)
        ok = engine.start(rate=48000, blocksize=1024)
        self.assertTrue(ok)
        time.sleep(0.1)
        engine.stop()
        engine._disk_writer.stop()
        self.assertFalse(engine._drain_t.is_alive())
        self.assertFalse(engine._watchdog_t.is_alive())


class TestCloseEventStopsDiskWriter(unittest.TestCase):
    """El defecto real: GUARDAR/DESCARTAR nunca detenían DiskWriterV2."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_close_")
        self.path = os.path.join(self.tmpdir, "captura.wav")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _make_app_with_recording(self):
        app = mw.LoritoAldhiroStudio()
        app._disk_tmp_path = self.path
        app._engine.set_output(self.path, rate=48000, channels=2)
        app._engine.start(rate=48000, blocksize=1024)
        block = (np.random.default_rng(0).uniform(-0.2, 0.2, size=(2000, 2))
                ).astype(np.float32)
        for _ in range(3):
            app._engine._ced.put_nowait(block)
        time.sleep(0.2)
        app._engine.stop()  # detiene el stream de audio, pero NO el disk_writer
        return app

    def test_guardar_branch_stops_disk_writer(self):
        app = self._make_app_with_recording()
        self.assertTrue(app._engine._disk_writer._thread is not None
                        and app._engine._disk_writer._thread.is_alive(),
                        msg="precondición: el hilo de disco debe seguir vivo "
                            "antes del closeEvent, para poder detectar el defecto")

        with patch.object(mw.CierreAbruptoDialog, "exec", return_value=None), \
             patch.object(mw.CierreAbruptoDialog, "resultado",
                          return_value=mw.CierreAbruptoDialog.GUARDAR):
            event = _FakeCloseEvent()
            app.closeEvent(event)

        self.assertTrue(event._accepted)
        self.assertFalse(app._engine._disk_writer._thread is not None
                         and app._engine._disk_writer._thread.is_alive(),
                         msg="defecto real: el hilo de disco seguía vivo tras "
                             "cerrar por la rama GUARDAR")

    def test_descartar_branch_stops_disk_writer(self):
        app = self._make_app_with_recording()

        with patch.object(mw.CierreAbruptoDialog, "exec", return_value=None), \
             patch.object(mw.CierreAbruptoDialog, "resultado",
                          return_value=mw.CierreAbruptoDialog.DESCARTAR):
            event = _FakeCloseEvent()
            app.closeEvent(event)

        self.assertTrue(event._accepted)
        self.assertFalse(app._engine._disk_writer._thread is not None
                         and app._engine._disk_writer._thread.is_alive(),
                         msg="defecto real: el hilo de disco seguía vivo tras "
                             "cerrar por la rama DESCARTAR")

    def test_guardar_branch_duration_reflects_fully_flushed_data(self):
        app = self._make_app_with_recording()

        with patch.object(mw.CierreAbruptoDialog, "exec", return_value=None), \
             patch.object(mw.CierreAbruptoDialog, "resultado",
                          return_value=mw.CierreAbruptoDialog.GUARDAR):
            event = _FakeCloseEvent()
            app.closeEvent(event)

        # Medido DESPUÉS de closeEvent (que es quien detiene el disk_writer
        # con el fix) — antes del fix, el hilo de escritura podía seguir
        # drenando la CED en paralelo, por lo que "frames_written" podía
        # seguir subiendo después de haber leído la duración del archivo.
        expected_frames = app._engine.get_status().frames_written
        import wave
        with wave.open(self.path, "rb") as wf:
            real_frames = wf.getnframes()
        self.assertEqual(real_frames, expected_frames)
        self.assertGreater(real_frames, 0)


if __name__ == "__main__":
    unittest.main()
