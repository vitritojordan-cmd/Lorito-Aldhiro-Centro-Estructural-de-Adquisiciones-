"""
test_cola_elastica_disco.py — Fase 5 (CED) de la Orden Maestra de
Saneamiento Pre-Auditoría Aldhira Phonographic.

`lorito_capture_engine.py` importa `sounddevice`/`soundfile` a nivel
de módulo (para `sd.InputStream`/`sf.SoundFile`, usados solo DENTRO de
funciones, nunca en la definición de clases) — en este sandbox
`sounddevice` falla al importar (`PortAudio library not found`) y
`soundfile` no está instalado. Se inyectan stubs mínimos en
`sys.modules` ANTES de importar el módulo real — mismo patrón ya usado
en sesiones previas para `lorito_bootstrap.py` (ver GAP-001 y
siguientes). Los stubs nunca se ejecutan de verdad: `ColaElasticaDisco`
no los toca en ningún método.
"""

import sys
import types
import unittest


def _install_stubs():
    if "sounddevice" not in sys.modules or getattr(sys.modules["sounddevice"], "__lorito_stub__", False):
        stub_sd = types.ModuleType("sounddevice")
        stub_sd.__lorito_stub__ = True
        stub_sd.InputStream = object
        stub_sd.query_devices = lambda *a, **k: []
        sys.modules["sounddevice"] = stub_sd
    if "soundfile" not in sys.modules or getattr(sys.modules["soundfile"], "__lorito_stub__", False):
        stub_sf = types.ModuleType("soundfile")
        stub_sf.__lorito_stub__ = True
        stub_sf.SoundFile = object
        sys.modules["soundfile"] = stub_sf


_install_stubs()

from lorito_aldhiro.backend.capture.lorito_capture_engine import ColaElasticaDisco  # noqa: E402

import numpy as np  # noqa: E402


class TestColaElasticaDiscoDroppedFrames(unittest.TestCase):
    """Defecto real (GAP-031): `dropped_frames` nunca se incrementaba
    pese a que la clase promete explícitamente "NUNCA descarta
    silenciosamente" — `put_nowait` retornaba False sin registrar
    nada en `_dropped`."""

    def test_dropped_frames_starts_at_zero(self):
        ced = ColaElasticaDisco(capacity=100)
        self.assertEqual(ced.dropped_frames, 0)

    def test_put_nowait_within_capacity_does_not_count_as_dropped(self):
        ced = ColaElasticaDisco(capacity=100)
        ok = ced.put_nowait(np.zeros((50, 2), dtype=np.float32))
        self.assertTrue(ok)
        self.assertEqual(ced.dropped_frames, 0)
        self.assertEqual(ced.frame_count, 50)

    def test_put_nowait_over_capacity_is_reported_as_dropped(self):
        ced = ColaElasticaDisco(capacity=100)
        ced.put_nowait(np.zeros((80, 2), dtype=np.float32))
        ok = ced.put_nowait(np.zeros((30, 2), dtype=np.float32))  # 80+30 > 100
        self.assertFalse(ok)
        self.assertEqual(ced.dropped_frames, 30,
                         msg="el defecto real: dropped_frames se quedaba en 0")

    def test_dropped_frames_accumulates_across_multiple_drops(self):
        ced = ColaElasticaDisco(capacity=100)
        ced.put_nowait(np.zeros((100, 1), dtype=np.float32))  # llena la cola
        ced.put_nowait(np.zeros((10, 1), dtype=np.float32))   # drop 1: 10
        ced.put_nowait(np.zeros((25, 1), dtype=np.float32))   # drop 2: 25
        self.assertEqual(ced.dropped_frames, 35)

    def test_get_batch_frees_capacity_so_next_put_succeeds(self):
        ced = ColaElasticaDisco(capacity=50)
        ced.put_nowait(np.zeros((50, 1), dtype=np.float32))
        self.assertFalse(ced.put_nowait(np.zeros((10, 1), dtype=np.float32)))
        self.assertEqual(ced.dropped_frames, 10)

        batch = ced.get_batch(max_frames=50, timeout=0.01)
        self.assertEqual(batch.shape[0], 50)
        self.assertEqual(ced.frame_count, 0)

        # Ahora SÍ debe caber — y no debe sumar más drops.
        self.assertTrue(ced.put_nowait(np.zeros((10, 1), dtype=np.float32)))
        self.assertEqual(ced.dropped_frames, 10)

    def test_total_in_out_accounting_matches_puts_and_gets(self):
        ced = ColaElasticaDisco(capacity=200)
        ced.put_nowait(np.zeros((60, 1), dtype=np.float32))
        ced.put_nowait(np.zeros((40, 1), dtype=np.float32))
        self.assertEqual(ced._total_in, 100)
        ced.get_batch(max_frames=100, timeout=0.01)
        self.assertEqual(ced._total_out, 100)


if __name__ == "__main__":
    unittest.main()
