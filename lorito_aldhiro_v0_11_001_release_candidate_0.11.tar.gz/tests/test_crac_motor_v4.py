"""
Tests reales del motor CRAC v4 integrado (§GAP-013) — módulo que
faltaba en el tarball, entregado por el usuario e integrado como
`lorito_crac_motor_v4.py`. Lógica pura (sin Qt/audio), verificable
directamente.

Ejecutar: python3 -m unittest tests.test_crac_motor_v4 -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import (
    CRACMotorV3, CRACMotorV4, TapeSide, MotorAction, make_motor,
)


class TestCracMotorIntegration(unittest.TestCase):

    def test_crac_motor_v3_alias_is_v4(self):
        """lorito_tape_log_panel.py importa CRACMotorV3 — debe ser
        exactamente CRACMotorV4 (drop-in), no una clase distinta."""
        self.assertIs(CRACMotorV3, CRACMotorV4)

    def test_make_motor_c60_c90_known_otros_unknown(self):
        m60 = make_motor("C-60")
        m90 = make_motor("C-90")
        m_otros = make_motor("OTROS")
        self.assertIsInstance(m60, CRACMotorV4)
        self.assertIsInstance(m90, CRACMotorV4)
        self.assertIsNone(m_otros)

    def test_c60_c90_preset_values_match_lorito_aldhiro_spec(self):
        """Confirma que los presets del motor coinciden con los valores
        ya hardcodeados en lorito_main_window.py/lorito_tape_log_panel.py
        (auditados en GAP-009, actualizados en GAP-014: FIX-LADO-B-
        TOLERANCIA-EXT3MIN — total 3960s/5700s, ventana C-90 (43,48)min
        sin cambios en Lado A) — el motor es la fuente de verdad real de
        esos números, no una coincidencia."""
        m60 = make_motor("C-60")
        m90 = make_motor("C-90")
        self.assertEqual(m60._preset.tol_max_b_s, 66 * 60)   # 3960s
        self.assertEqual(m90._preset.tol_max_b_s, 95 * 60)   # 5700s
        self.assertEqual(m90._preset.tol_min_a_s, 43 * 60)
        self.assertEqual(m90._preset.tol_max_a_s, 48 * 60)

    def test_lado_b_tolerance_extended_3min_only_at_max_edge(self):
        """FIX-LADO-B-TOLERANCIA-EXT3MIN (§GAP-014, mismo fix ya
        aplicado en CRAC [0.37.348]): el mínimo de la ventana de
        tolerancia de Lado B NO se mueve, solo el máximo (+3 min) — la
        ventana pasa de 5 a 8 minutos."""
        m60 = make_motor("C-60")
        m90 = make_motor("C-90")
        # Mínimos sin cambios respecto a la spec anterior (GAP-009).
        self.assertEqual(m60._preset.tol_min_b_s, 58 * 60)
        self.assertEqual(m90._preset.tol_min_b_s, 87 * 60)
        # Ventana (max - min) = 8 min en ambos, antes 5 min.
        self.assertEqual(m60._preset.tol_max_b_s - m60._preset.tol_min_b_s, 8 * 60)
        self.assertEqual(m90._preset.tol_max_b_s - m90._preset.tol_min_b_s, 8 * 60)

    def test_side_starts_at_a(self):
        m = make_motor("C-60")
        self.assertEqual(m.side, TapeSide.A)
        self.assertFalse(m.flip_pending)
        self.assertFalse(m.stop_triggered)

    def test_tick_forced_pause_then_flip_to_side_b(self):
        import time
        m = make_motor("C-60")
        flipped = []
        m.on_flip_side_b = lambda: flipped.append(True)

        # Con audio (sin autopausa) hasta el tope de tolerancia A (33min):
        action = m.tick(elapsed_secs=33 * 60, autopause_active=False)
        self.assertEqual(action, MotorAction.FORCED_PAUSE_A)
        self.assertTrue(m.forced_pause_active)
        self.assertTrue(m.flip_pending)

        # Silencio real confirmado ≥1s en pausa forzada → conmuta a
        # escape (el motor mide el silencio con time.monotonic() real,
        # no con elapsed_secs — requiere un tick con autopause_active=True
        # y esperar el umbral real).
        m.tick(elapsed_secs=33 * 60, autopause_active=True)
        time.sleep(1.05)
        action = m.tick(elapsed_secs=33 * 60, autopause_active=True)
        self.assertEqual(action, MotorAction.AUTOPAUSE)

        # El usuario reanuda tras la pausa (ya en escape) → volteo inmediato.
        m.notify_autopause_deactivated(elapsed_secs=33 * 60)
        self.assertEqual(m.side, TapeSide.B)
        self.assertTrue(m.flip_done)
        self.assertTrue(flipped)
        self.assertTrue(m.query_counter_reset())   # single-shot
        self.assertFalse(m.query_counter_reset())  # ya consumido

    def test_tick_excedente_stops(self):
        m = make_motor("C-60")
        stopped = []
        m.on_auto_stop = lambda: stopped.append(True)
        action = m.tick(elapsed_secs=(66 * 60) + 5, autopause_active=False)
        self.assertEqual(action, MotorAction.STOP)
        self.assertEqual(m.side, TapeSide.EXCEDENTE)
        self.assertTrue(stopped)

    def test_reset_returns_to_initial_state(self):
        m = make_motor("C-90")
        m.tick(elapsed_secs=48 * 60, autopause_active=False)
        self.assertTrue(m.flip_pending)
        m.reset()
        self.assertEqual(m.side, TapeSide.A)
        self.assertFalse(m.flip_pending)
        self.assertFalse(m.forced_pause_active)


    def test_tape_log_panel_stop_intervals_consistent_with_motor(self):
        """`_STOP_INTERVALS` (fallback/documental en TapeLogPanel, ver
        GAP-014) debe seguir en sincronía manual con los presets reales
        del motor: ventana 8 min en ambos modos."""
        from tests.test_stability_patch import _install_stub_modules
        _install_stub_modules()
        from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
        self.assertEqual(TapeLogPanel._STOP_INTERVALS["C-60"], (8 * 60,))
        self.assertEqual(TapeLogPanel._STOP_INTERVALS["C-90"], (8 * 60,))


if __name__ == "__main__":
    unittest.main()
