"""
test_cristhi_cosh_ui.py — GAP-040, integración de UI de "Florecedor de
Cristhi Cosh (PREVI)": menú OPTAPE, leyenda "PREVI DSP" en la celda
"DOLBY B", leyenda "FNESP DSP" alternando con "DOLBY C" cuando ambos
están activos, y panel de ajustes con deslizadores.

Usa `LoritoAldhiroStudio` instanciada REAL bajo los stubs de PySide6
ya establecidos (GAP-036/037).
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
from lorito_aldhiro.frontend.widgets.lorito_indicators import DigitalClock  # noqa: E402


class TestCristhiCoshToggle(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_toggle_activates_dsp_in_coordinator(self):
        self.assertFalse(self.app._nr_coordinator.cristhi_cosh_active)
        self.app._on_cristhi_cosh_toggle()
        self.assertTrue(self.app._nr_coordinator.cristhi_cosh_active)
        self.app._on_cristhi_cosh_toggle()
        self.assertFalse(self.app._nr_coordinator.cristhi_cosh_active)

    def test_toggle_sets_previ_legend_on_clock(self):
        self.app._on_cristhi_cosh_toggle()
        self.assertTrue(self.app.clock._previ_dsp_active)
        self.app._on_cristhi_cosh_toggle()
        self.assertFalse(self.app.clock._previ_dsp_active)

    def test_panel_updates_live_params(self):
        self.app._on_cristhi_cosh_toggle()  # arma el DSP
        dsp = self.app._nr_coordinator._cristhi_cosh
        self.assertIsNotNone(dsp)
        dsp.set_params(correction_intensity=0.77)
        self.assertAlmostEqual(dsp.correction_intensity, 0.77)


class TestPreviDspLegend(unittest.TestCase):
    def test_dolby_b_cell_shows_previ_dsp_when_active(self):
        clock = DigitalClock()
        labels_before = {token: label for label, token in clock.TOP_CELLS}
        self.assertEqual(labels_before["DOLBY_B"], "DOLBY B")

        clock.set_previ_dsp_active(True)
        self.assertTrue(clock._previ_dsp_active)

    def test_dolby_b_cell_reverts_when_previ_inactive(self):
        clock = DigitalClock()
        clock.set_previ_dsp_active(True)
        clock.set_previ_dsp_active(False)
        self.assertFalse(clock._previ_dsp_active)


class TestFnespDolbyCAlternation(unittest.TestCase):
    def test_fnesp_only_shows_fnesp_without_alternating(self):
        clock = DigitalClock()
        clock.set_fnesp_dsp_active(True)
        for _ in range(6):
            clock.tick_legend_alternation()
        self.assertTrue(clock._legend_alt_on)

    def test_fnesp_and_dolby_c_both_active_alternate(self):
        clock = DigitalClock()
        clock.set_cell_lit("DOLBY_C", True)
        clock.set_fnesp_dsp_active(True)

        initial = clock._legend_alt_on
        clock.tick_legend_alternation()
        self.assertEqual(clock._legend_alt_on, initial)
        clock.tick_legend_alternation()
        self.assertNotEqual(clock._legend_alt_on, initial)
        clock.tick_legend_alternation()
        self.assertNotEqual(clock._legend_alt_on, initial)
        clock.tick_legend_alternation()
        self.assertEqual(clock._legend_alt_on, initial)

    def test_deactivating_fnesp_resets_alternation_state(self):
        clock = DigitalClock()
        clock.set_cell_lit("DOLBY_C", True)
        clock.set_fnesp_dsp_active(True)
        clock.tick_legend_alternation()
        clock.tick_legend_alternation()
        clock.set_fnesp_dsp_active(False)
        self.assertTrue(clock._legend_alt_on)
        self.assertEqual(clock._legend_alt_tick_count, 0)


class TestBlinkTickWiresLegendAlternation(unittest.TestCase):
    def test_blink_calls_tick_legend_alternation(self):
        app = mw.LoritoAldhiroStudio()
        app.clock.set_cell_lit("DOLBY_C", True)
        app.clock.set_fnesp_dsp_active(True)
        initial = app.clock._legend_alt_on
        app._blink()
        app._blink()
        self.assertNotEqual(app.clock._legend_alt_on, initial)


if __name__ == "__main__":
    unittest.main()
