"""
test_dsp_antipestal_lola_grillo.py -- GAP-041, DSP "Antipestal de Lola
Grillo (PREVI)" adaptado desde CRAC.
"""

import unittest

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_antipestal_lola_grillo import (
    AntipestalLolaProfile, VolterraColorizer, PrePostEcho,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite


def _clean_block(n=2048, ch=2, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.uniform(-0.4, 0.4, size=(n, ch))).astype(np.float32)


class TestBasics(unittest.TestCase):
    def test_bypass_transparent(self):
        dsp = AntipestalLolaProfile(mode="BYPASS")
        block = _clean_block()
        np.testing.assert_array_equal(dsp.process_chunk(block), block)

    def test_striker_stays_finite_and_bounded(self):
        dsp = AntipestalLolaProfile(mode="STRIKER", sample_rate=48000, channels=2)
        for i in range(15):
            out = dsp.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())
            self.assertTrue(np.all(np.abs(out) <= 1.0))

    def test_kari_stays_finite_and_bounded(self):
        dsp = AntipestalLolaProfile(mode="KARI", sample_rate=48000, channels=2)
        for i in range(15):
            out = dsp.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())

    def test_set_params_clamps(self):
        dsp = AntipestalLolaProfile(mode="STRIKER")
        dsp.set_params(excitacion_ruido=5.0, raspado=-3.0)
        self.assertEqual(dsp.params["excitacion_ruido"], 1.0)
        self.assertEqual(dsp.params["raspado"], 0.0)

    def test_reset_clears_state(self):
        dsp = AntipestalLolaProfile(mode="KARI", sample_rate=48000, channels=2)
        for i in range(5):
            dsp.process_chunk(_clean_block(seed=i))
        dsp.reset()
        for st in dsp._channel_states:
            self.assertEqual(st.lowpass.z1, 0.0)
            self.assertEqual(st.wow_flutter._wow_phase, 0.0)


class TestNonFiniteGuard(unittest.TestCase):
    def test_recovers_with_sanitize_and_reset(self):
        dsp = AntipestalLolaProfile(mode="STRIKER", sample_rate=48000, channels=2)
        for i in range(3):
            dsp.process_chunk(_clean_block(seed=i))
        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = dsp.process_chunk(poisoned)
        clean_out, n_bad = sanitize_finite(out_poisoned)
        self.assertGreater(n_bad, 0)
        dsp.reset()
        out_after = dsp.process_chunk(_clean_block(seed=100))
        self.assertTrue(np.isfinite(out_after).all())


class TestPrintThroughCorrection(unittest.TestCase):
    def test_default_delays_are_second_scale_not_millisecond_scale(self):
        echo = PrePostEcho(sample_rate=48000)
        pre_ms = echo._pre_delay / 48000 * 1000
        post_ms = echo._post_delay / 48000 * 1000
        self.assertGreater(pre_ms, 1000, "el pre-eco corregido debe ser de escala de segundos")
        self.assertGreater(post_ms, 1000, "el post-eco corregido debe ser de escala de segundos")

    def test_echo_appears_at_corrected_delay(self):
        rate = 48000
        echo = PrePostEcho(sample_rate=rate, pre_delay_ms=100.0, pre_gain=0.5,
                           post_delay_ms=200.0, post_gain=0.5)
        n = 20000
        impulse = np.zeros(n)
        impulse[5000] = 1.0
        out = echo.process(impulse)
        pre_pos = 5000 + int(0.1 * rate)
        self.assertGreater(abs(out[pre_pos]), 0.1)


class TestEquivalenceWithCracComponents(unittest.TestCase):
    def test_volterra_matches_reference_formula(self):
        vc = VolterraColorizer(k2=0.1, k3=-0.06)
        x = np.array([0.3, 0.2, -0.1], dtype=np.float64)
        out = vc.process(x, intensity=1.0)
        y0 = np.tanh(0.3 + 0.1 * 0.3 * 0.0 + (-0.06) * 0.3 ** 3)
        self.assertAlmostEqual(out[0], y0, places=10)


if __name__ == "__main__":
    unittest.main()
