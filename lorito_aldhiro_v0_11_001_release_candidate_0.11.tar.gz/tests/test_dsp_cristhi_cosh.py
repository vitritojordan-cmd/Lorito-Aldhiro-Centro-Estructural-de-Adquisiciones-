"""
test_dsp_cristhi_cosh.py — GAP-039, DSP "Florecedor de Cristhi Cosh
(PREVI)" adaptado desde CRAC.

Verifica: comportamiento transparente en BYPASS, parametros/reset,
integracion con el guard DSP_NONFINITE_OUTPUT ya existente en Lorito
(reemplaza la guarda propia de CRAC, PREVIDSPBlockGuard - ver
docstring del modulo portado), y comportamiento esperado de cada
banda segun la documentacion del algoritmo original - complementario
a la comparacion directa con el codigo fuente de CRAC ya realizada
manualmente (ver GAP-039: diff=0.0 en 30 bloques con artefactos
simulados).
"""

import unittest

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_cristhi_cosh import (
    CristhiCoshProfile, AzucenaAnalyzer, AzucenaMap, NicoleCorrectionEngine,
    DanielaSoftLimiter, PochaSIRFEngine, RommyFinalStage,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite


def _clean_block(n=2048, ch=2, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.uniform(-0.4, 0.4, size=(n, ch))).astype(np.float32)


class TestBypassAndBasics(unittest.TestCase):
    def test_bypass_is_transparent(self):
        dsp = CristhiCoshProfile(mode="BYPASS")
        block = _clean_block()
        out = dsp.process_chunk(block)
        np.testing.assert_array_equal(out, block)

    def test_active_processes_and_stays_finite(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        for i in range(10):
            out = dsp.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())
            self.assertTrue(np.all(np.abs(out) <= 1.0))

    def test_set_params_updates_all_bands(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        dsp.set_params(correction_intensity=0.9, softness=0.1,
                      reconstruction_intensity=0.8, dnl_strength=0.2)
        self.assertAlmostEqual(dsp.nicole.correction_intensity, 0.9)
        self.assertAlmostEqual(dsp.daniela.softness, 0.1)
        self.assertAlmostEqual(dsp.pocha.reconstruction_intensity, 0.8)
        self.assertAlmostEqual(dsp.rommy.dnl.strength, 0.2)

    def test_set_params_clamps_out_of_range(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        dsp.set_params(correction_intensity=5.0, softness=-3.0)
        self.assertEqual(dsp.correction_intensity, 1.0)
        self.assertEqual(dsp.softness, 0.0)

    def test_reset_clears_internal_state(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        for i in range(5):
            dsp.process_chunk(_clean_block(seed=i))
        dsp.reset()
        self.assertEqual(dsp._last_correction_ratio, 0.0)
        self.assertEqual(dsp._last_reconstruction_ratio, 0.0)
        np.testing.assert_array_equal(dsp.azucena._ref_level, np.full(2, 1e-4))

    def test_processing_flag_reflects_artifact_detection(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        quiet = np.zeros((2048, 2), dtype=np.float32)
        for _ in range(3):
            dsp.process_chunk(quiet.copy())
        quiet_ratio = dsp._last_correction_ratio

        rng = np.random.default_rng(1)
        noisy = (rng.uniform(-0.3, 0.3, size=(2048, 2))).astype(np.float32)
        noisy[500:510] = 0.99
        for _ in range(3):
            dsp.process_chunk(noisy.copy())
        # El artefacto real (click abrupto) debe reportar una relación
        # de corrección claramente mayor que el silencio.
        self.assertGreater(dsp._last_correction_ratio, quiet_ratio)
        self.assertTrue(dsp.processing)


class TestNonFiniteGuardIntegration(unittest.TestCase):
    """El propio comentario del controlador original de CRAC confirma
    el defecto: un NaN envenena permanentemente la cadena de 5 bandas.
    Se verifica aquí que el patrón de guard ya usado por NRCoordinator
    (sanitize_finite + reset() de la etapa) resuelve el problema."""

    def test_nan_input_poisons_state_without_guard(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        for i in range(3):
            dsp.process_chunk(_clean_block(seed=i))

        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = dsp.process_chunk(poisoned)
        self.assertFalse(np.isfinite(out_poisoned).all())

        out_after = dsp.process_chunk(_clean_block(seed=100))
        self.assertFalse(np.isfinite(out_after).all(),
                         "defecto esperado: sin guard, envenenamiento permanente")

    def test_sanitize_finite_and_reset_recovers(self):
        dsp = CristhiCoshProfile(mode="ACTIVE")
        for i in range(3):
            sanitize_finite(dsp.process_chunk(_clean_block(seed=i)))

        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = dsp.process_chunk(poisoned)
        clean_out, n_bad = sanitize_finite(out_poisoned)
        self.assertGreater(n_bad, 0)
        self.assertTrue(np.isfinite(clean_out).all())
        dsp.reset()

        out_after = dsp.process_chunk(_clean_block(seed=100))
        self.assertTrue(np.isfinite(out_after).all(),
                        "tras reset(), el estado ya no debe seguir envenenado")


class TestBandBehavior(unittest.TestCase):
    def test_azucena_artifact_ratio_near_zero_on_silence(self):
        analyzer = AzucenaAnalyzer(sample_rate=48000, n_channels=1)
        silent = np.zeros((4096, 1), dtype=np.float32)
        amap = analyzer.analyze(silent)
        # Prácticamente cero — no exactamente 0.0 por el estado inicial
        # de la referencia de energía (comportamiento del algoritmo
        # original, ya verificado bit a bit contra CRAC en GAP-039).
        self.assertLess(amap.artifact_ratio, 0.01)

    def test_nicole_gain_reduces_with_higher_artifact_ratio(self):
        nicole_low = NicoleCorrectionEngine(sample_rate=48000, n_channels=1,
                                            correction_intensity=1.0)
        nicole_high = NicoleCorrectionEngine(sample_rate=48000, n_channels=1,
                                             correction_intensity=1.0)
        block = np.full((4096, 1), 0.5, dtype=np.float32)
        low_map = AzucenaMap(artifact_ratio=0.0, saturation_level=0.0)
        high_map = AzucenaMap(artifact_ratio=1.0, saturation_level=0.0)

        out_low = nicole_low.process(block.copy(), low_map)
        out_high = nicole_high.process(block.copy(), high_map)
        self.assertLess(np.mean(np.abs(out_high[-100:])), np.mean(np.abs(out_low[-100:])))

    def test_pocha_reconstruction_ratio_zero_without_gate(self):
        pocha = PochaSIRFEngine(sample_rate=48000, n_channels=1)
        block = _clean_block(n=4096, ch=1)
        no_gate = AzucenaMap(artifact_ratio=0.0)
        pocha.process(block, no_gate)
        self.assertEqual(pocha.last_reconstruction_ratio, 0.0)

    def test_daniela_never_exceeds_unity(self):
        daniela = DanielaSoftLimiter(sample_rate=48000, n_channels=1)
        loud = np.full((4096, 1), 1.0, dtype=np.float32)
        out = daniela.process(loud)
        self.assertTrue(np.all(np.abs(out) <= 1.0))

    def test_rommy_stabilizes_toward_target_peak(self):
        rommy = RommyFinalStage(sample_rate=48000, n_channels=1, target_peak=0.5)
        quiet = np.full((4096, 1), 0.9, dtype=np.float32)
        out = None
        for _ in range(50):
            out = rommy.process(quiet.copy())
        self.assertLess(np.max(np.abs(out)), 0.9)


if __name__ == "__main__":
    unittest.main()
