"""
test_dsp_finite_guard.py — Fase 10 (DSP_NONFINITE_OUTPUT) de la Orden
Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic.

Dos cosas se verifican con ejecución real de NumPy (sin PySide6, sin
sounddevice, sin Numba — el fallback puro de `lorito_dsp_numba_utils`
ya se ejerce en el resto de la batería):

1. Que el defecto que motiva esta fase es REAL, no hipotético: sin el
   guard, un único NaN en un bloque envenena el estado IIR de una
   etapa (MPX/EQ-BIAS) de forma PERMANENTE — todo bloque limpio
   posterior también sale en NaN.
2. Que `NRCoordinator.process_chunk` (que ahora aplica el guard en
   cada etapa) corrige exactamente ese defecto: el bloque envenenado
   sale finito y los bloques limpios posteriores se recuperan.
"""

import unittest
import warnings

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import (
    sanitize_finite, DSP_SANITIZE_CLIP,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_mpx import MpxProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_eq_bias import TapeEqBiasProfile
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator


def _clean_block(n=256, ch=2, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.uniform(-0.3, 0.3, size=(n, ch))).astype(np.float32)


class TestSanitizeFiniteUnit(unittest.TestCase):
    def test_all_finite_returns_same_object_zero_copy(self):
        block = _clean_block()
        clean, n_bad = sanitize_finite(block)
        self.assertEqual(n_bad, 0)
        self.assertIs(clean, block)  # camino sano: sin copiar

    def test_nan_replaced_with_zero(self):
        block = _clean_block().copy()
        block[10, 0] = np.nan
        clean, n_bad = sanitize_finite(block)
        self.assertEqual(n_bad, 1)
        self.assertEqual(clean[10, 0], 0.0)
        self.assertTrue(np.isfinite(clean).all())

    def test_posinf_and_neginf_clipped(self):
        block = _clean_block().copy()
        block[3, 1] = np.inf
        block[7, 0] = -np.inf
        clean, n_bad = sanitize_finite(block)
        self.assertEqual(n_bad, 2)
        self.assertEqual(clean[3, 1], DSP_SANITIZE_CLIP)
        self.assertEqual(clean[7, 0], -DSP_SANITIZE_CLIP)

    def test_empty_chunk_is_noop(self):
        block = np.zeros((0, 2), dtype=np.float32)
        clean, n_bad = sanitize_finite(block)
        self.assertEqual(n_bad, 0)
        self.assertIs(clean, block)

    def test_dtype_preserved(self):
        block = _clean_block().copy()
        block[0, 0] = np.nan
        clean, _ = sanitize_finite(block)
        self.assertEqual(clean.dtype, block.dtype)


class TestRealDefectWithoutGuard(unittest.TestCase):
    """Demuestra que el defecto es real: llamando a las etapas
    DIRECTAMENTE (sin pasar por el coordinador ni por el guard), un
    NaN puntual envenena el estado IIR para siempre."""

    def test_mpx_state_permanently_poisoned_without_guard(self):
        mpx = MpxProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        # Bloques limpios de calentamiento — estado interno normal.
        for i in range(3):
            out = mpx.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())

        # Un único bloque con un NaN, procesado SIN guard.
        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = mpx.process_chunk(poisoned)
        self.assertFalse(np.isfinite(out_poisoned).all())  # np.clip no lo salva

        # Bloques limpios DESPUÉS del NaN — sin guard, siguen saliendo
        # en NaN porque el estado del biquad (y1/y2) quedó envenenado.
        for i in range(5):
            out_after = mpx.process_chunk(_clean_block(seed=100 + i))
            self.assertFalse(
                np.isfinite(out_after).all(),
                "defecto esperado: sin guard, el envenenamiento es permanente",
            )

    def test_eq_bias_state_permanently_poisoned_without_guard(self):
        eqb = TapeEqBiasProfile("METAL", sample_rate=48000, channels=2)
        for i in range(3):
            out = eqb.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())

        poisoned = _clean_block(seed=99).copy()
        poisoned[20, 1] = np.inf
        # Aritmética con Inf/NaN en el estado emite RuntimeWarning de
        # NumPy — esperado y parte de lo que este test demuestra (el
        # defecto real, que el guard de la Fase 10 corrige más abajo).
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            out_poisoned = eqb.process_chunk(poisoned)
        self.assertFalse(np.isfinite(out_poisoned).all())

        out_after = eqb.process_chunk(_clean_block(seed=200))
        self.assertFalse(np.isfinite(out_after).all())


class TestCoordinatorAppliesGuard(unittest.TestCase):
    """Mismo escenario que arriba, pero a través de
    `NRCoordinator.process_chunk`, que ahora aplica el contrato
    DSP_NONFINITE_OUTPUT en cada etapa."""

    def test_mpx_recovers_after_nan_at_raw_input(self):
        # El NaN llega en el bloque crudo (glitch simulado del motor de
        # captura). El guard "finite-in" lo sanea ANTES de que MPX lo
        # vea siquiera — por eso lo que sube es el contador "input", no
        # "mpx": MPX nunca llega a ver el valor no finito.
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.set_mpx(True)

        for i in range(3):
            out = coord.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())

        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = coord.process_chunk(poisoned)
        self.assertTrue(np.isfinite(out_poisoned).all(),
                         "el bloque envenenado debe salir saneado")
        self.assertEqual(coord.nonfinite_counts["input"], 1)
        self.assertEqual(coord.nonfinite_counts["mpx"], 0)

        for i in range(5):
            out_after = coord.process_chunk(_clean_block(seed=100 + i))
            self.assertTrue(np.isfinite(out_after).all())

    def test_mpx_stage_reset_when_its_own_state_is_corrupt(self):
        # Escenario distinto: el bloque de ENTRADA llega limpio, pero
        # el estado interno de MPX ya está corrupto (p. ej. por un bug
        # de coeficientes en una reconfiguración futura, o cualquier
        # vía que no sea el bloque de entrada crudo — el guard
        # "finite-in" NO puede protegerte de esto, porque el dato de
        # entrada en sí es perfecto). El guard POR ETAPA debe detectar
        # que MPX devolvió NaN, sanear ese bloque y resetear su
        # estado, para que el bloque limpio siguiente ya no arrastre
        # el envenenamiento.
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.set_mpx(True)
        for i in range(3):
            coord.process_chunk(_clean_block(seed=i))

        coord._mpx._state_pilot[:] = np.nan  # corrupción directa del estado

        clean_input = _clean_block(seed=50)
        self.assertTrue(np.isfinite(clean_input).all())
        n_samples_expected = clean_input.size
        out_poisoned = coord.process_chunk(clean_input)
        self.assertTrue(np.isfinite(out_poisoned).all(),
                         "la salida de esta etapa debe salir saneada")
        # El bloque entero sale contaminado (recursión IIR: un y1/y2 en
        # NaN arrastra cada muestra del bloque) — de ahí el conteo por
        # bloque completo, no un único valor puntual.
        self.assertEqual(coord.nonfinite_counts["mpx"], n_samples_expected)
        self.assertEqual(coord.nonfinite_counts["input"], 0)

        for i in range(5):
            out_after = coord.process_chunk(_clean_block(seed=100 + i))
            self.assertTrue(np.isfinite(out_after).all(),
                             "el estado debió resetearse, no seguir envenenado")

    def test_eq_bias_stage_reset_when_its_own_state_is_corrupt(self):
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.select_eq_bias("METAL")
        for i in range(3):
            coord.process_chunk(_clean_block(seed=i))

        # Nota: un estado en ±Inf NO alcanza a probar el defecto en esta
        # etapa concreta — el soft-clip `tanh` de EQ/BIAS satura Inf de
        # forma acotada por diseño (tanh(inf) = 1.0), a diferencia del
        # `np.clip` de las demás etapas. NaN sí atraviesa el tanh sin
        # saturar (tanh(nan) = nan), que es el caso real que este guard
        # cubre.
        coord._eq_bias._state_hf[:] = np.nan  # corrupción directa del estado
        clean_input = _clean_block(seed=50)

        out_poisoned = coord.process_chunk(clean_input)
        self.assertTrue(np.isfinite(out_poisoned).all())
        self.assertEqual(coord.nonfinite_counts["eq_bias"], clean_input.size)

        out_after = coord.process_chunk(_clean_block(seed=200))
        self.assertTrue(np.isfinite(out_after).all())

    def test_finite_in_guard_sanitizes_already_corrupt_input(self):
        # Sin ninguna etapa activa: el propio bloque de entrada llega
        # con un NaN (glitch simulado del motor de captura). El
        # coordinador debe devolverlo saneado igual, vía el guard
        # "finite-in" aplicado antes de la primera etapa.
        coord = NRCoordinator(sample_rate=48000, channels=2)
        block = _clean_block().copy()
        block[5, 0] = np.nan
        out = coord.process_chunk(block)
        self.assertTrue(np.isfinite(out).all())
        self.assertEqual(coord.nonfinite_counts["input"], 1)

    def test_clean_chain_counters_stay_zero(self):
        # Caso normal (la inmensa mayoría de los bloques reales): el
        # guard no debe incrementar ningún contador ni alterar la
        # salida de una cadena con varias etapas activas a la vez.
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.select_eq_bias("NORMAL")
        coord.set_mpx(True)
        coord.set_hx_pro(True)
        coord.set_alc(True)
        coord.set_cristhi_cosh(True)

        for i in range(5):
            out = coord.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())

        counts = coord.nonfinite_counts
        self.assertTrue(all(v == 0 for v in counts.values()), counts)

    def test_cristhi_cosh_stage_reset_when_its_own_state_is_corrupt(self):
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.set_cristhi_cosh(True)
        for i in range(3):
            coord.process_chunk(_clean_block(seed=i))

        coord._cristhi_cosh.azucena._ref_level[:] = np.nan

        clean_input = _clean_block(seed=50)
        out_poisoned = coord.process_chunk(clean_input)
        self.assertTrue(np.isfinite(out_poisoned).all(),
                        "la salida de esta etapa debe salir saneada")
        self.assertGreater(coord.nonfinite_counts["cristhi_cosh"], 0)

        for i in range(5):
            out_after = coord.process_chunk(_clean_block(seed=100 + i))
            self.assertTrue(np.isfinite(out_after).all(),
                            "el estado debió resetearse, no seguir envenenado")

    def test_muscle_eq_stage_reset_when_its_own_state_is_corrupt(self):
        from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import get_preset_bands
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.set_muscle_eq_active(True, preset_id="ROCK")
        for i in range(3):
            coord.process_chunk(_clean_block(seed=i))

        coord._muscle_eq._channels_state[0][0]._z1 = np.nan

        clean_input = _clean_block(seed=50)
        out_poisoned = coord.process_chunk(clean_input)
        self.assertTrue(np.isfinite(out_poisoned).all())
        self.assertGreater(coord.nonfinite_counts["muscle_eq"], 0)

        for i in range(5):
            out_after = coord.process_chunk(_clean_block(seed=100 + i))
            self.assertTrue(np.isfinite(out_after).all())

    def test_muscle_eq_runs_first_in_the_chain(self):
        # orden §21 -- Muscle Eq Samir debe ser la PRIMERA etapa,
        # antes que cualquier otro procesador de OPTAPE.
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord.set_muscle_eq_active(True, preset_id="ROCK")
        coord.set_cristhi_cosh(True)
        for i in range(5):
            out = coord.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())
        counts = coord.nonfinite_counts
        self.assertEqual(counts["muscle_eq"], 0)
        self.assertEqual(counts["cristhi_cosh"], 0)


if __name__ == "__main__":
    unittest.main()
