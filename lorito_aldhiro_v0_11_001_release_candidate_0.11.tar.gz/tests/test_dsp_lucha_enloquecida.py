"""
test_dsp_lucha_enloquecida.py -- GAP-042, DSP "Lucha Enloquecida
(PREVI)" -- 20 sub-perfiles adaptados desde CRAC.
"""

import os
import sys
import unittest

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida import (
    LUCHA_PROFILE_ORDER, LuchaEnloquecidaProfile,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite

CRAC_SRC = "/home/claude/crac_src/src"


def _clean_block(n=2048, ch=2, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.uniform(-0.4, 0.4, size=(n, ch))).astype(np.float32)


class TestAllProfilesProcessCleanly(unittest.TestCase):
    def test_all_20_profiles_stay_finite_and_bounded(self):
        for code, label, tech, cls in LUCHA_PROFILE_ORDER:
            dsp = LuchaEnloquecidaProfile(mode=code, sample_rate=48000, channels=2)
            for i in range(8):
                out = dsp.process_chunk(_clean_block(seed=i))
                self.assertTrue(np.isfinite(out).all(), msg=f"perfil {code}: no finito")
                self.assertTrue(np.all(np.abs(out) <= 1.0 + 1e-6), msg=f"perfil {code}: excede rango")

    def test_registry_has_exactly_20_profiles_in_order(self):
        codes = [c for c, _, _, _ in LUCHA_PROFILE_ORDER]
        self.assertEqual(len(codes), 20)
        self.assertEqual(codes, sorted(codes))
        self.assertEqual(codes[0], "A")
        self.assertEqual(codes[-1], "T")

    def test_bypass_transparent(self):
        dsp = LuchaEnloquecidaProfile(mode="BYPASS")
        block = _clean_block()
        np.testing.assert_array_equal(dsp.process_chunk(block), block)

    def test_unknown_code_is_inactive(self):
        dsp = LuchaEnloquecidaProfile(mode="Z")
        block = _clean_block()
        np.testing.assert_array_equal(dsp.process_chunk(block), block)

    def test_reset_does_not_raise_for_any_profile(self):
        for code, _, _, _ in LUCHA_PROFILE_ORDER:
            dsp = LuchaEnloquecidaProfile(mode=code, sample_rate=48000, channels=2)
            dsp.process_chunk(_clean_block())
            dsp.reset()


class TestNonFiniteGuardIntegration(unittest.TestCase):
    def test_a_few_profiles_recover_with_guard_and_reset(self):
        for code in ("A", "J", "T"):
            dsp = LuchaEnloquecidaProfile(mode=code, sample_rate=48000, channels=2)
            for i in range(3):
                dsp.process_chunk(_clean_block(seed=i))
            poisoned = _clean_block(seed=99).copy()
            poisoned[50, 0] = np.nan
            out_poisoned = dsp.process_chunk(poisoned)
            clean_out, n_bad = sanitize_finite(out_poisoned)
            self.assertTrue(np.isfinite(clean_out).all(), msg=code)
            dsp.reset()
            out_after = dsp.process_chunk(_clean_block(seed=100))
            self.assertTrue(np.isfinite(out_after).all(), msg=code)


class TestEquivalenceWithCracOriginal(unittest.TestCase):
    """Verificación de equivalencia numérica exacta contra el código
    fuente original de CRAC, extraído del tarball subido por el
    usuario. Se salta si el árbol fuente de CRAC no está presente en
    este sandbox (no forma parte del repositorio de Lorito)."""

    _NAME_MAP = {
        "A": "lucha_profile_a_spring_reverb_abuse.SpringReverbAbuseProfile",
        "B": "lucha_profile_b_acoustic_damping.AcousticDampingProfile",
        "C": "lucha_profile_c_starving_voltage.StarvingVoltageProfile",
        "D": "lucha_profile_d_tape_loops.TapeLoopsProfile",
        "E": "lucha_profile_e_pipe_echo_chamber.PipeEchoChamberProfile",
        "F": "lucha_profile_f_toy_capsule.ToyCapsuleProfile",
        "G": "lucha_profile_g_circuit_bending.CircuitBendingProfile",
        "H": "lucha_profile_h_impedance_mismatch.ImpedanceMismatchProfile",
        "I": "lucha_profile_i_megaphone.MegaphoneProfile",
        "J": "lucha_profile_j_generation_loss.GenerationLossProfile",
        "K": "lucha_profile_k_wire_recording.WireRecordingProfile",
        "L": "lucha_profile_l_ground_hum.GroundHumProfile",
        "M": "lucha_profile_m_tape_warping.TapeWarpingProfile",
        "N": "lucha_profile_n_baked_tape.BakedTapeProfile",
        "O": "lucha_profile_o_carbon_mic.CarbonMicProfile",
        "P": "lucha_profile_p_piezo_contact.PiezoContactProfile",
        "Q": "lucha_profile_q_am_radio_detune.AmRadioDetuneProfile",
        "R": "lucha_profile_r_portastudio_overdrive.PortastudioOverdriveProfile",
        "S": "lucha_profile_s_under_biasing.UnderBiasingProfile",
        "T": "lucha_profile_t_vinyl_damage.VinylDamageProfile",
    }

    @classmethod
    def setUpClass(cls):
        cls._crac_available = os.path.isdir(CRAC_SRC)
        if cls._crac_available and CRAC_SRC not in sys.path:
            sys.path.insert(0, CRAC_SRC)

    def test_all_20_profiles_match_crac_source_exactly(self):
        if not self._crac_available:
            self.skipTest("árbol fuente de CRAC no presente en este sandbox")
        import importlib
        lorito_classes = {code: cls for code, _, _, cls in LUCHA_PROFILE_ORDER}
        rng = np.random.default_rng(0)
        fs = 48000
        for code, spec in self._NAME_MAP.items():
            modname, clsname = spec.rsplit(".", 1)
            mod = importlib.import_module(
                f"crac.dsp_previ.lucha_enloquecida.{modname}")
            orig_cls = getattr(mod, clsname)
            orig = orig_cls(sample_rate=fs, channels=2)
            lorito = lorito_classes[code](sample_rate=fs, channels=2)
            for i in range(10):
                block = (rng.uniform(-0.4, 0.4, size=(2048, 2))).astype(np.float32)
                a = orig.process(block.copy())
                b = lorito.process(block.copy())
                np.testing.assert_array_equal(
                    a.astype(np.float64), b.astype(np.float64),
                    err_msg=f"perfil {code} difiere del original de CRAC")


if __name__ == "__main__":
    unittest.main()
