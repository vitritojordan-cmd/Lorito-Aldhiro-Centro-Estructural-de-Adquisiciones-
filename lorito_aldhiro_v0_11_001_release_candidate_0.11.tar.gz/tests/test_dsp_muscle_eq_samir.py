"""
test_dsp_muscle_eq_samir.py -- GAP-043, DSP "MUSCLE EQ SAMIR
(VITRITO)" -- motor de ecualización en caliente, diseño nuevo para
Lorito Aldhiro (Orden de Ingeniería aportada por el usuario).
"""

import unittest

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import (
    MuscleEqSamirProfile, EqBand, EqBandType, MuscleEqError, TRANSITION_SAMPLES,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import (
    list_presets_flat, get_preset_bands, MUSCLE_EQ_PRESET_CATEGORIES,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite


def _clean_block(n=2048, ch=2, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.uniform(-0.4, 0.4, size=(n, ch))).astype(np.float32)


class TestBasics(unittest.TestCase):
    def test_bypass_is_transparent(self):
        eq = MuscleEqSamirProfile(mode="BYPASS")
        block = _clean_block()
        out = eq.process_chunk(block)
        np.testing.assert_array_equal(out, block)

    def test_active_flat_stays_finite_and_bounded(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        for i in range(10):
            out = eq.process_chunk(_clean_block(seed=i))
            self.assertTrue(np.isfinite(out).all())
            self.assertTrue(np.all(np.abs(out) <= 1.0))

    def test_bypass_never_uses_zero_gain_as_substitute(self):
        eq = MuscleEqSamirProfile(mode="BYPASS", sample_rate=48000, channels=2)
        eq.set_band(0, type="PEAKING", freq_hz=1000, gain_db=18.0, q=1.0, enabled=True)
        block = _clean_block()
        out = eq.process_chunk(block)
        np.testing.assert_array_equal(out, block)


class TestAllSixFilterTypes(unittest.TestCase):
    def test_each_filter_type_processes_without_error(self):
        for ftype in EqBandType:
            eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
            eq.set_band(0, type=ftype.value, freq_hz=1000, gain_db=6.0, q=0.9, enabled=True)
            for i in range(10):
                out = eq.process_chunk(_clean_block(seed=i))
                self.assertTrue(np.isfinite(out).all(), msg=ftype.value)


class TestSmoothTransition(unittest.TestCase):
    def test_activating_a_band_has_no_large_sample_jump(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        block = np.full((4096, 2), 0.3, dtype=np.float32)
        eq.process_chunk(block)
        eq.set_band(0, type="PEAKING", freq_hz=1000, gain_db=15.0, q=1.0, enabled=True)
        out = eq.process_chunk(block)
        max_jump = np.max(np.abs(np.diff(out[:, 0].astype(np.float64))))
        self.assertLess(max_jump, 0.01,
                        msg="salto de muestra a muestra demasiado grande — posible click")

    def test_toggle_active_ramps_dry_wet(self):
        eq = MuscleEqSamirProfile(mode="BYPASS", sample_rate=48000, channels=2)
        eq.set_band(0, type="LOW_SHELF", freq_hz=200, gain_db=12.0, q=0.707, enabled=True)
        block = np.full((TRANSITION_SAMPLES * 2, 2), 0.3, dtype=np.float32)
        eq.set_active(True)
        out = eq.process_chunk(block)
        self.assertAlmostEqual(float(out[0, 0]), 0.3, places=2)
        self.assertNotAlmostEqual(float(out[-1, 0]), 0.3, places=2)
        max_jump = np.max(np.abs(np.diff(out[:, 0].astype(np.float64))))
        self.assertLess(max_jump, 0.01)

    def test_preset_switch_is_atomic_and_smooth(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        eq.load_preset("ROCK", get_preset_bands("ROCK"))
        block = np.full((8192, 2), 0.2, dtype=np.float32)
        eq.process_chunk(block)
        eq.load_preset("JAZZ", get_preset_bands("JAZZ"))
        out = eq.process_chunk(block)
        self.assertTrue(np.isfinite(out).all())
        max_jump = np.max(np.abs(np.diff(out[:, 0].astype(np.float64))))
        self.assertLess(max_jump, 0.01)


class TestValidation(unittest.TestCase):
    def test_invalid_frequency_falls_back_to_pass_through_not_crash(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        eq.set_band(0, type="PEAKING", freq_hz=999999, gain_db=6.0, q=1.0, enabled=True)
        out = eq.process_chunk(_clean_block())
        self.assertTrue(np.isfinite(out).all())

    def test_set_band_invalid_index_raises_typed_error(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE")
        with self.assertRaises(MuscleEqError) as ctx:
            eq.set_band(99, gain_db=3.0)
        self.assertEqual(ctx.exception.code, "MUSCLE_EQ_INVALID_BAND")


class TestResetToFlat(unittest.TestCase):
    def test_reset_to_flat_deactivates_and_clears_bands(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        eq.load_preset("ROCK", get_preset_bands("ROCK"))
        eq.reset_to_flat()
        self.assertFalse(eq.active)
        self.assertEqual(eq.preset_id, "FLAT")
        self.assertTrue(all(not b.enabled for b in eq.bands))

    def test_hecho_does_not_reset_anything(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        eq.load_preset("VOCAL", get_preset_bands("VOCAL"))
        preset_before = eq.preset_id
        active_before = eq.active
        eq.process_chunk(_clean_block())
        self.assertEqual(eq.preset_id, preset_before)
        self.assertEqual(eq.active, active_before)


class TestNonFiniteGuard(unittest.TestCase):
    def test_recovers_with_sanitize_and_reset(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        eq.load_preset("ROCK", get_preset_bands("ROCK"))
        for i in range(3):
            eq.process_chunk(_clean_block(seed=i))
        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = eq.process_chunk(poisoned)
        clean_out, n_bad = sanitize_finite(out_poisoned)
        self.assertTrue(np.isfinite(clean_out).all())
        eq.reset()
        out_after = eq.process_chunk(_clean_block(seed=100))
        self.assertTrue(np.isfinite(out_after).all())


class TestAllPresetsLoadCleanly(unittest.TestCase):
    def test_44_presets_across_5_categories(self):
        self.assertEqual(len(MUSCLE_EQ_PRESET_CATEGORIES), 5)
        presets = list_presets_flat()
        self.assertGreater(len(presets), 40)

    def test_every_preset_processes_without_fault(self):
        eq = MuscleEqSamirProfile(mode="ACTIVE", sample_rate=48000, channels=2)
        for _, preset_id in list_presets_flat():
            eq.load_preset(preset_id, get_preset_bands(preset_id))
            out = eq.process_chunk(_clean_block())
            self.assertTrue(np.isfinite(out).all(), msg=preset_id)

    def test_riaa_uses_real_corner_frequencies(self):
        bands = get_preset_bands("RIAA")
        freqs = {b["freq_hz"] for b in bands}
        self.assertIn(500.5, freqs)
        self.assertIn(2122.0, freqs)

    def test_nab_uses_real_corner_frequencies(self):
        bands = get_preset_bands("NAB")
        freqs = {b["freq_hz"] for b in bands}
        self.assertIn(50.0, freqs)
        self.assertIn(3180.0, freqs)


if __name__ == "__main__":
    unittest.main()
