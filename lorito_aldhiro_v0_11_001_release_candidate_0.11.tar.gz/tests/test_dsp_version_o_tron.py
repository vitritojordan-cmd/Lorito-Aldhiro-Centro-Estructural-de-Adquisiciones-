"""
test_dsp_version_o_tron.py -- GAP-041, DSP "Versión O Tron (FNESP)"
adaptado desde CRAC como streaming con estado persistente.
"""

import unittest

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import (
    VersionOTronProfile, VOT_CONFIGS, _StatefulBiquad, _design_butterworth_lp_2nd,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite


def _clean_block(n=2048, ch=2, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.uniform(-0.4, 0.4, size=(n, ch))).astype(np.float32)


class TestBasics(unittest.TestCase):
    def test_bypass_transparent(self):
        dsp = VersionOTronProfile(mode="BYPASS")
        block = _clean_block()
        np.testing.assert_array_equal(dsp.process_chunk(block), block)

    def test_all_real_profiles_stay_finite_and_bounded(self):
        for mode in VOT_CONFIGS:
            dsp = VersionOTronProfile(mode=mode, sample_rate=48000, channels=2)
            for i in range(10):
                out = dsp.process_chunk(_clean_block(seed=i))
                self.assertTrue(np.isfinite(out).all(), msg=mode)
                self.assertTrue(np.all(np.abs(out) <= 1.0), msg=mode)

    def test_unknown_mode_is_inactive(self):
        dsp = VersionOTronProfile(mode="NO_EXISTE")
        block = _clean_block()
        np.testing.assert_array_equal(dsp.process_chunk(block), block)

    def test_reset_clears_biquad_state(self):
        dsp = VersionOTronProfile(mode="BARRIL", sample_rate=48000, channels=2)
        for i in range(5):
            dsp.process_chunk(_clean_block(seed=i))
        dsp.reset()
        for st in dsp._channel_states:
            np.testing.assert_array_equal(st["hp"]._zi, np.zeros_like(st["hp"]._zi))
            self.assertEqual(st["comp_env_state"], 0.0)
            self.assertEqual(st["fluct_phase"], 0.0)


class TestStreamingMatchesSinglePass(unittest.TestCase):
    def test_stateful_biquad_matches_single_pass(self):
        rate = 48000
        b, a = _design_butterworth_lp_2nd(3000.0, rate)
        rng = np.random.default_rng(0)
        full_signal = rng.uniform(-0.5, 0.5, size=6000)

        single_pass = _StatefulBiquad(b, a)
        gold = single_pass.process(full_signal.copy())

        chunked_filter = _StatefulBiquad(b, a)
        chunks_out = []
        pos = 0
        block_size = 512
        while pos < len(full_signal):
            take = min(block_size, len(full_signal) - pos)
            chunks_out.append(chunked_filter.process(full_signal[pos:pos + take]))
            pos += take
        chunked = np.concatenate(chunks_out)

        np.testing.assert_allclose(gold, chunked, atol=1e-10)


class TestNonFiniteGuard(unittest.TestCase):
    def test_recovers_with_sanitize_and_reset(self):
        dsp = VersionOTronProfile(mode="SIFON", sample_rate=48000, channels=2)
        for i in range(3):
            dsp.process_chunk(_clean_block(seed=i))
        poisoned = _clean_block(seed=99).copy()
        poisoned[50, 0] = np.nan
        out_poisoned = dsp.process_chunk(poisoned)
        clean_out, n_bad = sanitize_finite(out_poisoned)
        self.assertTrue(np.isfinite(clean_out).all())
        dsp.reset()
        out_after = dsp.process_chunk(_clean_block(seed=100))
        self.assertTrue(np.isfinite(out_after).all())


class TestResearchedBandwidths(unittest.TestCase):
    def test_barril_matches_researched_am_bandwidth(self):
        self.assertEqual(VOT_CONFIGS["BARRIL"]["band_hi_hz"], 5000.0)

    def test_sifon_matches_researched_ssb_bandwidth(self):
        self.assertEqual(VOT_CONFIGS["SIFON"]["band_lo_hz"], 300.0)
        self.assertEqual(VOT_CONFIGS["SIFON"]["band_hi_hz"], 3800.0)


if __name__ == "__main__":
    unittest.main()
