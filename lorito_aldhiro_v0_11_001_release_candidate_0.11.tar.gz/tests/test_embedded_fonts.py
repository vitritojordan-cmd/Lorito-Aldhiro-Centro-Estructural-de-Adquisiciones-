"""
Verifica, con fontTools (lectura real de la tabla `name` de cada
archivo), que los assets embebidos bajo
`lorito_aldhiro/frontend/assets/fonts/` realmente contienen la familia
que `lorito_fonts.py` espera para cada rol. No requiere PySide6 — cubre
la parte de esta entrega que SÍ se puede verificar con ejecución real en
este sandbox (sin PySide6/QFontDatabase, ver GAP-006 §4 para lo que
queda pendiente de verificar con Qt real).

Ejecutar: python3 -m unittest tests.test_embedded_fonts -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fontTools.ttLib import TTFont

from lorito_aldhiro.frontend.support.lorito_fonts import (
    _ASSETS_DIR, _FAMILY_DIRS, _FONT_EXTENSIONS,
    FONT_FAMILY_CONTOMETRO, FONT_FAMILY_CUENTAVUELTAS,
    FONT_FAMILY_UI, FONT_FAMILY_LEYENDAS, FONT_FAMILY_MEDIA_ANIM,
    FONT_FAMILY_CELDAS_COMPARTIDAS,
)


def _family_name_of(path: str) -> str:
    f = TTFont(path, fontNumber=0)
    return f["name"].getDebugName(1)


class TestEmbeddedFontAssets(unittest.TestCase):

    def test_all_six_expected_families_have_a_directory(self):
        """
        Actualizado en la Orden Maestra de Saneamiento 0.06.005→0.06.006
        (Fase 11, ítem 1 — "familias de fuentes"): el contrato original
        (GAP-006) solo conocía 4 familias; sesiones posteriores (GAP-018,
        GAP-023) añadieron Helvetica (Media Anim) y Utendo (celdas
        compartidas del contómetro) sin actualizar esta prueba, que
        seguía verificando un conjunto desactualizado — quedaba en FAIL
        contra el comportamiento actualmente contratado, no porque el
        registro de fuentes estuviera roto.
        """
        expected = {FONT_FAMILY_CONTOMETRO, FONT_FAMILY_CUENTAVUELTAS,
                    FONT_FAMILY_UI, FONT_FAMILY_LEYENDAS,
                    FONT_FAMILY_MEDIA_ANIM, FONT_FAMILY_CELDAS_COMPARTIDAS}
        self.assertEqual(set(_FAMILY_DIRS.keys()), expected)
        for family, subdir in _FAMILY_DIRS.items():
            dirpath = os.path.join(_ASSETS_DIR, subdir)
            self.assertTrue(os.path.isdir(dirpath),
                            f"falta el directorio de assets para {family}: {dirpath}")

    def test_every_registered_family_matches_its_font_files(self):
        """
        Para cada familia, AL MENOS un archivo dentro de su directorio
        debe declarar exactamente esa familia en su tabla `name`
        (nameID 1) — la misma comprobación que hace
        `register_embedded_fonts()` en tiempo de ejecución con Qt real,
        aquí verificada de forma independiente con fontTools.
        """
        for family, subdir in _FAMILY_DIRS.items():
            dirpath = os.path.join(_ASSETS_DIR, subdir)
            files = [f for f in os.listdir(dirpath)
                     if f.lower().endswith(_FONT_EXTENSIONS)]
            self.assertGreater(len(files), 0,
                               f"sin archivos de fuente para {family} en {dirpath}")
            found_families = set()
            for fname in files:
                found_families.add(_family_name_of(os.path.join(dirpath, fname)))
            self.assertIn(family, found_families,
                          f"ningún archivo en {dirpath} declara la familia "
                          f"'{family}' — declaran: {found_families}")

    def test_patopian_is_single_weight_regular(self):
        """Patopian 1986 solo trae Regular — confirma que
        font_contometro() no puede pedir un peso que no existe."""
        path = os.path.join(_ASSETS_DIR, "patopian_1986", "Patopian 1986.ttf")
        f = TTFont(path)
        self.assertEqual(f["name"].getDebugName(2), "Regular")

    def test_exo2_and_creato_have_multiple_weights(self):
        for subdir in ("exo2", "creato_display"):
            dirpath = os.path.join(_ASSETS_DIR, subdir)
            files = [f for f in os.listdir(dirpath) if f.lower().endswith(".otf")]
            self.assertGreater(len(files), 5,
                               f"{subdir}: se esperaban varios pesos, hay {len(files)}")


if __name__ == "__main__":
    unittest.main()
