"""
test_export_array_truncation_abort.py — GAP-051, FASE 1 ("Contratos +
errores") + P0.4 de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Reproduce con ejecución real (mismo arnés que GAP-036/GAP-041,
`tests/test_main_window_export_exploration.py`) el defecto confirmado
esta sesión en `_build_export_array()` (`lorito_mw_export.py`, el
método que la GUI usa HOY para exportar):

Antes de esta fase, un segmento TRUNCADO (header que declara más
frames de los que el archivo físicamente contiene — el mismo escenario
real de un crash a mitad de captura que motivó `SegmentReadError` en
GAP-034 para el camino streaming) no producía ningún error observable:
`sf.SoundFile.read()`/`wave.readframes()` no lanzan excepción ante una
lectura corta, solo devuelven menos datos. El bucle de
`_build_export_array` seguía adelante, la siguiente lectura devolvía
un bloque vacío, el `break` cortaba el segmento en silencio, y el
segmento SIGUIENTE se escribía a continuación en `write_pos` —
desplazando en el tiempo el resto de la sesión sin ningún aviso. El
`except Exception` que sí rellenaba con silencio nunca llegaba a
ejecutarse en este escenario exacto.

Estos tests verifican el comportamiento CORREGIDO: la exportación
aborta con `SegmentReadError` (tipificado, con `segment_id`/`path`
estructurados), nombrando el segmento exacto — nunca corrompe ni
desplaza el resto de la sesión en silencio.
"""

import os
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from tests._functional_soundfile_stub import (
    install_functional_soundfile_stub, FunctionalSoundFile,
)

install_functional_soundfile_stub()

from tests.test_stability_patch import _install_stub_modules  # noqa: E402
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
from lorito_aldhiro.backend.errors import SegmentReadError  # noqa: E402

# Mismo fix de rebinding que GAP-036/GAP-041 — ver comentario extenso
# en test_main_window_export_exploration.py.
import lorito_aldhiro.frontend.main_window.lorito_mw_export as _export_mixin_mod  # noqa: E402
import soundfile as _sf_functional  # noqa: E402
_export_mixin_mod.sf = _sf_functional
mw.sf = sys.modules["soundfile"]


def _corrupt_header_frame_count(path, claimed_extra_frames, channels, sampwidth):
    """Idéntico en técnica a `tests/test_segment_read_errors.py` —
    reescribe el campo de tamaño del chunk 'data' (offset 40 en un WAV
    canónico de 44 bytes: RIFF+fmt+data, sin chunks extra, igual con
    cualquier profundidad de bits) para que declare MÁS frames de los
    que el archivo físicamente contiene."""
    with open(path, "r+b") as f:
        f.seek(40)
        current = struct.unpack("<I", f.read(4))[0]
        f.seek(40)
        f.write(struct.pack("<I", current + claimed_extra_frames * channels * sampwidth))


class TestBuildExportArrayAbortsOnTruncation(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_trunc_")
        self.rate = 48000
        self.channels = 2
        self.sampwidth = 3  # PCM_24 — único subtype real del stub funcional

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _make_segment(self, name, n_frames, seed=1):
        rng = np.random.default_rng(seed)
        audio = rng.uniform(-0.3, 0.3, size=(n_frames, self.channels)).astype(np.float32)
        p = os.path.join(self.tmpdir, name)
        with FunctionalSoundFile(p, mode="w", samplerate=self.rate,
                                  channels=self.channels) as f:
            f.write(audio)
        return p

    def test_single_truncated_segment_raises_segment_read_error(self):
        p = self._make_segment("seg0.wav", n_frames=1000)
        _corrupt_header_frame_count(p, claimed_extra_frames=500,
                                     channels=self.channels, sampwidth=self.sampwidth)

        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = [p]

        with self.assertRaises(SegmentReadError) as ctx:
            app._build_export_array(p)

        self.assertIn(p, str(ctx.exception))
        self.assertIn("truncado", str(ctx.exception).lower())
        self.assertEqual(ctx.exception.path, p)
        self.assertEqual(ctx.exception.segment_id, p)
        self.assertEqual(ctx.exception.frame_count, 1500)  # el header mentiroso

    def test_truncated_segment_among_several_identified_by_name_no_shift(self):
        # El caso central del defecto: SIN el fix, el segundo/tercer
        # segmento se habrían escrito desplazados sobre la posición
        # del truncamiento, sin ningún aviso. Con el fix, la
        # exportación completa aborta ANTES de escribir nada del
        # segmento sano posterior a partir de una posición incorrecta.
        p_ok = self._make_segment("seg0_ok.wav", n_frames=500, seed=1)
        p_bad = self._make_segment("seg1_truncado.wav", n_frames=300, seed=2)
        _corrupt_header_frame_count(p_bad, claimed_extra_frames=700,
                                     channels=self.channels, sampwidth=self.sampwidth)
        p_ok2 = self._make_segment("seg2_ok.wav", n_frames=400, seed=3)

        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = [p_ok, p_bad, p_ok2]

        with self.assertRaises(SegmentReadError) as ctx:
            app._build_export_array(p_ok)

        msg = str(ctx.exception)
        self.assertIn(p_bad, msg, msg="el error debe nombrar el segmento exacto")
        self.assertNotIn(p_ok, msg, msg="no debe confundirse con el segmento sano previo")
        self.assertNotIn(p_ok2, msg)
        # frame_start debe coincidir con dónde termina el primer segmento
        # sano (500 frames ya escritos) — confirma que el error se
        # detecta en la posición real, no en una desplazada.
        self.assertEqual(ctx.exception.frame_start, 500)

    def test_healthy_multi_segment_session_still_builds_correctly(self):
        # Control negativo — sin truncamiento, el comportamiento no
        # debe cambiar (ya cubierto por GAP-036/test_main_window_
        # export_exploration.py; se repite aquí como cinturón y
        # tirantes específico de esta fase).
        p1 = self._make_segment("sano0.wav", n_frames=300, seed=1)
        p2 = self._make_segment("sano1.wav", n_frames=700, seed=2)

        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = [p1, p2]

        audio, rate = app._build_export_array(p1)
        self.assertIsNotNone(audio)
        self.assertEqual(rate, self.rate)
        self.assertEqual(audio.shape[0], 1000)


if __name__ == "__main__":
    unittest.main()
