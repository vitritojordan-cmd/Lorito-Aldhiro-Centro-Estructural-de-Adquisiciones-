"""
test_export_end_to_end_with_spec_file.py — GAP-056, FASE 7
("Controllers / God Object", §13) de la Orden Maestra de Saneamiento,
Integración y Consolidación de Lorito Aldhiro.

Verificación de mayor rigor que `tests/test_export_session_spec.py`
(que prueba las funciones extraídas en aislamiento): dispara
`ExportMixin.export()` REAL — no solo `_build_export_array()` — sobre
una `LoritoAldhiroStudio()` real instanciada bajo stubs (mismo arnés
de GAP-036/041/051), forzando que el hilo de fondo (`_do_export`,
lanzado normalmente vía `QTimer.singleShot` + `threading.Thread`)
corra de verdad, y confirma que el archivo de exportación Y el archivo
"Aldhira de Especificación de CRAC" se escriben correctamente en
disco — la prueba real de que la extracción de GAP-056 (`compute_
integrity_check`/`build_session_spec_text`) quedó bien conectada al
camino de producción, no solo bien probada en aislamiento.
"""

import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests._functional_soundfile_stub import install_functional_soundfile_stub
install_functional_soundfile_stub()

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
import lorito_aldhiro.frontend.main_window.lorito_mw_export as _export_mod  # noqa: E402
import lorito_aldhiro.backend.export.lorito_exporters as _exporters_mod  # noqa: E402
import soundfile as _sf_functional  # noqa: E402

# Mismo fix de rebinding que GAP-036/041/051 — el stub funcional de
# soundfile debe usarse tanto en el mixin (para leer segmentos) como
# en el exportador legado (para escribir el archivo final).
_export_mod.sf = _sf_functional
_exporters_mod.sf = _sf_functional
mw.sf = sys.modules["soundfile"]


class TestExportEndToEndWritesSpecFile(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_e2e_")
        self.outdir = tempfile.mkdtemp(prefix="lorito_export_e2e_out_")

    def tearDown(self):
        for d in (self.tmpdir, self.outdir):
            for f in os.listdir(d):
                os.remove(os.path.join(d, f))
            os.rmdir(d)

    def _make_segment(self, n_frames=4000, seed=7):
        from tests._functional_soundfile_stub import FunctionalSoundFile
        import numpy as np

        seg_path = os.path.join(self.tmpdir, f"seg_{seed}.wav")
        rng = np.random.default_rng(seed)
        audio = rng.uniform(-0.3, 0.3, size=(n_frames, 2)).astype(np.float32)
        with FunctionalSoundFile(seg_path, mode="w", samplerate=48000,
                                 channels=2) as f:
            f.write(audio)
        return seg_path

    def _run_real_export(self, seg_path, *, speed_ratio=1.0, norm_text=None):
        """Dispara `export()` real de punta a punta y devuelve
        (wav_files, spec_text) — mismo arnés en los 3 tests de esta
        clase, parametrizado por lo que cada uno quiere ejercitar."""
        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = [seg_path]
        app._disk_tmp_path = seg_path
        app._export_output_dir = self.outdir
        app._speed_ratio = speed_ratio
        if norm_text is not None:
            app.norm_box.setCurrentText(norm_text)

        _export_mod.QTimer.singleShot = lambda _ms, cb: cb()

        before_threads = set(threading.enumerate())
        app.export()

        new_threads = [t for t in threading.enumerate() if t not in before_threads]
        export_threads = [t for t in new_threads if t.name == "crac-export"]
        self.assertEqual(len(export_threads), 1,
                         "export() debía lanzar exactamente 1 hilo crac-export")
        export_threads[0].join(timeout=15)
        self.assertFalse(export_threads[0].is_alive(),
                         "el hilo de export no terminó a tiempo")

        wav_files = [f for f in os.listdir(self.outdir) if f.endswith(".wav")]
        spec_files = [f for f in os.listdir(self.outdir)
                      if f.endswith("_aldhira_spec_crac.txt")]
        self.assertEqual(len(wav_files), 1, f"contenido de outdir: {os.listdir(self.outdir)}")
        self.assertEqual(len(spec_files), 1, f"contenido de outdir: {os.listdir(self.outdir)}")
        with open(os.path.join(self.outdir, spec_files[0]), encoding="utf-8") as f:
            spec_text = f.read()
        return wav_files, spec_text

    def test_export_writes_wav_and_spec_file_with_correct_content(self):
        seg_path = self._make_segment(n_frames=2000, seed=7)
        _wav_files, spec_text = self._run_real_export(seg_path, speed_ratio=1.0)

        self.assertIn("Aldhira de Especificación de CRAC", spec_text)
        self.assertIn("Frames recibidos", spec_text)
        self.assertIn("Frames escritos", spec_text)
        self.assertIn("Frames exportados", spec_text)
        self.assertIn("CUENTAVUELTAS", spec_text)
        # Confirma que el chequeo de integridad extraído (GAP-056)
        # corrió de verdad como parte del flujo real: sin pérdida
        # (mismo frame count en captura/disco/export), no debe
        # aparecer ninguna línea de fallo de integridad en el log —
        # se confirma indirectamente por la presencia normal del
        # resto del spec (si `compute_integrity_check` hubiera
        # lanzado una excepción, el bloque completo del spec habría
        # quedado sin escribir, por el try/except que lo envuelve).
        self.assertTrue(len(spec_text) > 200)

    def test_export_with_speed_resample_completes_end_to_end(self):
        """GAP-060 — hueco real: la rama de resampleo por velocidad
        (`PlaybackEngine._resample_chunk`, §3c de `_do_export`) nunca
        se había ejercitado con una exportación real completa — solo
        la función en aislamiento (`test_resample_continuity.py`).
        `ratio != 1.0` toma un camino de código distinto (incluye
        `del audio_raw` explícito y el tag `_x{ratio}` en el nombre de
        archivo) que ningún test end-to-end había recorrido."""
        seg_path = self._make_segment(n_frames=4000, seed=11)
        wav_files, spec_text = self._run_real_export(seg_path, speed_ratio=1.5)

        self.assertIn("_x1p50", wav_files[0],
                      "el tag de velocidad debe aparecer en el nombre del archivo")
        self.assertIn("Velocidad ratio   : ×1.5000", spec_text)

    def test_export_with_normalization_completes_end_to_end(self):
        """GAP-060 — hueco real: la rama de normalización avanzada
        (§3b de `_do_export`, ~57 líneas incluidas 18 asignaciones a
        `_status.normalization_*`) nunca se había ejercitado con una
        exportación real completa — el test original usaba "Sin
        normalizar" por defecto, saltándose todo este bloque."""
        seg_path = self._make_segment(n_frames=4000, seed=13)
        _wav_files, spec_text = self._run_real_export(
            seg_path, norm_text="Norm -0.2 dBFS")

        self.assertIn("Modo              : Norm -0.2 dBFS", spec_text)
        self.assertIn("Ganancia aplicada", spec_text)
        self.assertIn("Peak resultante", spec_text)

    def test_export_with_flac_codec_completes_end_to_end(self):
        """GAP-060 — hueco real: el test original solo ejercitaba WAV.
        FLAC usa un camino de código completamente distinto
        (`FLACExporter`, re-encode real vía subproceso `ffmpeg` — ver
        `lorito_exporters.py`), nunca antes probado con una exportación
        real completa. `ffmpeg` SÍ está disponible en este sandbox
        (confirmado antes de escribir este test) — verificación real,
        no salteada por falta de la dependencia externa."""
        seg_path = self._make_segment(n_frames=4000, seed=17)
        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = [seg_path]
        app._disk_tmp_path = seg_path
        app._export_output_dir = self.outdir
        app._speed_ratio = 1.0
        app.codec_box.setCurrentText("FLAC")

        _export_mod.QTimer.singleShot = lambda _ms, cb: cb()
        before_threads = set(threading.enumerate())
        app.export()
        new_threads = [t for t in threading.enumerate() if t not in before_threads]
        export_threads = [t for t in new_threads if t.name == "crac-export"]
        self.assertEqual(len(export_threads), 1)
        export_threads[0].join(timeout=30)  # ffmpeg real — algo más lento
        self.assertFalse(export_threads[0].is_alive())

        flac_files = [f for f in os.listdir(self.outdir) if f.endswith(".flac")]
        self.assertEqual(len(flac_files), 1, f"contenido de outdir: {os.listdir(self.outdir)}")
        self.assertGreater(os.path.getsize(os.path.join(self.outdir, flac_files[0])), 0)

    def test_export_with_ogg_codec_completes_end_to_end(self):
        """Mismo motivo que el test de FLAC — OGG usa su propio
        `OGGExporter` (también vía `ffmpeg`), nunca antes ejercitado
        con una exportación real completa."""
        seg_path = self._make_segment(n_frames=4000, seed=19)
        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = [seg_path]
        app._disk_tmp_path = seg_path
        app._export_output_dir = self.outdir
        app._speed_ratio = 1.0
        app.codec_box.setCurrentText("OGG")

        _export_mod.QTimer.singleShot = lambda _ms, cb: cb()
        before_threads = set(threading.enumerate())
        app.export()
        new_threads = [t for t in threading.enumerate() if t not in before_threads]
        export_threads = [t for t in new_threads if t.name == "crac-export"]
        self.assertEqual(len(export_threads), 1)
        export_threads[0].join(timeout=30)
        self.assertFalse(export_threads[0].is_alive())

        ogg_files = [f for f in os.listdir(self.outdir) if f.endswith(".ogg")]
        self.assertEqual(len(ogg_files), 1, f"contenido de outdir: {os.listdir(self.outdir)}")
        self.assertGreater(os.path.getsize(os.path.join(self.outdir, ogg_files[0])), 0)


if __name__ == "__main__":
    unittest.main()
