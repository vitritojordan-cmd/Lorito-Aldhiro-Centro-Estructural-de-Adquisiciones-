"""
§30/§36 — verificación de que el RSS pico de una exportación NO escala
proporcionalmente con la duración de la sesión.

`ru_maxrss` es monótono creciente DENTRO de un mismo proceso (no baja
entre llamadas), así que comparar dos exportaciones en el mismo proceso
de test (como hace `TestSegmentProvider.test_block_memory_bounded_...`)
no demuestra nada sobre memoria — por eso ahí solo se verifica el tamaño
acotado de cada bloque. Este script SÍ mide lo que pide §30: lanza dos
exportaciones reales en subprocesos frescos e independientes (una
sesión ~1x, otra ~20x más larga) y compara su RSS pico real de proceso.
"""

import json
import os
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_WORKER = r"""
import sys, os, resource, json, wave
import numpy as np
sys.path.insert(0, {root!r})
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_export_session import ExportSession

tmpdir = {tmpdir!r}
n_segments = {n_segments!r}
frames_per_segment = {frames_per_segment!r}
rate, channels = 48000, 2

paths = []
for i in range(n_segments):
    p = os.path.join(tmpdir, f"seg{{i:04d}}.wav")
    t = np.arange(frames_per_segment) / rate
    tone = (0.4 * np.sin(2*np.pi*(200+i)*t)).astype(np.float32)
    data = np.tile(tone.reshape(-1,1), (1, channels))
    pcm32 = (np.clip(data,-1,1) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1,4)
    pcm24 = np.ascontiguousarray(u8[:,0:3]).tobytes()
    with wave.open(p, "wb") as wf:
        wf.setnchannels(channels); wf.setsampwidth(3); wf.setframerate(rate)
        wf.writeframesraw(pcm24)
    paths.append(p)

final_path = os.path.join(tmpdir, "out.wav")
session = ExportSession(paths, encoder_cls=WavEncoder, final_path=final_path,
                         encoder_kwargs={{"subtype": "PCM_24"}}, block_frames=8192)
report = session.run()
peak_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps({{"ok": report.ok, "error": report.error,
                   "frames_in": report.frames_in, "peak_kb": peak_kb}}))
"""


def _run_worker(n_segments: int, frames_per_segment: int) -> dict:
    with tempfile.TemporaryDirectory(prefix="lorito_mem_scaling_") as tmpdir:
        code = _WORKER.format(root=ROOT, tmpdir=tmpdir,
                               n_segments=n_segments,
                               frames_per_segment=frames_per_segment)
        out = subprocess.run([sys.executable, "-c", code],
                              capture_output=True, text=True, timeout=120)
        if out.returncode != 0:
            raise RuntimeError(f"worker falló: {out.stderr[-2000:]}")
        return json.loads(out.stdout.strip().splitlines()[-1])


def main():
    small = _run_worker(n_segments=2, frames_per_segment=50_000)      # ~2.1 s
    large = _run_worker(n_segments=40, frames_per_segment=50_000)     # ~41.7 s (20x)

    assert small["ok"], small["error"]
    assert large["ok"], large["error"]
    assert large["frames_in"] == 20 * small["frames_in"]

    ratio_duration = large["frames_in"] / small["frames_in"]
    ratio_rss = large["peak_kb"] / max(small["peak_kb"], 1)

    print(f"duración: {ratio_duration:.1f}x más larga")
    print(f"RSS pico: {small['peak_kb']} KB → {large['peak_kb']} KB "
          f"({ratio_rss:.2f}x)")

    # Si la memoria escalara con la duración (O(total_capture_duration),
    # el defecto que la orden prohíbe en §19), ratio_rss ≈ ratio_duration
    # (≈20x). Con arquitectura de bloque acotado, ratio_rss debe quedar
    # muy por debajo de eso.
    assert ratio_rss < ratio_duration / 3, (
        f"RSS escaló casi proporcionalmente a la duración "
        f"(RSS x{ratio_rss:.2f} vs duración x{ratio_duration:.1f}) — "
        f"sugiere que el pipeline NO es O(block_size)")

    print("OK — RSS pico no escala proporcionalmente con la duración.")


if __name__ == "__main__":
    main()
