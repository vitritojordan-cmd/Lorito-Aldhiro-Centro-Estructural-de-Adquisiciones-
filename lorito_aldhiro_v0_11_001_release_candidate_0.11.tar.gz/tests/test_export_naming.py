"""
test_export_naming.py — GAP-071, FASE 7 ("Controllers / God Object",
§13) de la Orden Maestra de Saneamiento, Integración y Consolidación
de Lorito Aldhiro.

Verifica `backend/export/lorito_export_naming.py` — la extracción
MECÁNICA de 4 fragmentos puros que vivían inline dentro de
`_do_export()` (`ExportMixin`, `lorito_mw_export.py`), mismo patrón de
GAP-056/062/070. A diferencia de esas extracciones, esta no elimina
duplicación (los fragmentos no se repetían) sino que da cobertura de
test DIRECTA a lógica de formato solo verificada antes de forma
indirecta a través de una exportación real completa
(`tests/test_export_end_to_end_with_spec_file.py`).
"""

import unittest

from lorito_aldhiro.backend.export.lorito_export_naming import (
    export_codec_extension, export_speed_filename_tag,
    export_speed_display_suffix, export_clip_tag,
)


class TestExportCodecExtension(unittest.TestCase):

    def test_known_codecs(self):
        self.assertEqual(export_codec_extension("WAV"), "wav")
        self.assertEqual(export_codec_extension("FLAC"), "flac")
        self.assertEqual(export_codec_extension("OGG"), "ogg")
        self.assertEqual(export_codec_extension("WV"), "wv")

    def test_unknown_codec_defaults_to_wav(self):
        # Mismo default que el `.get(codec, "wav")` original.
        self.assertEqual(export_codec_extension("MP3"), "wav")
        self.assertEqual(export_codec_extension(""), "wav")


class TestExportSpeedFilenameTag(unittest.TestCase):

    def test_neutral_ratio_is_empty(self):
        self.assertEqual(export_speed_filename_tag(1.0), "")

    def test_accelerated_ratio(self):
        self.assertEqual(export_speed_filename_tag(1.5), "_x1p50")

    def test_decelerated_ratio(self):
        self.assertEqual(export_speed_filename_tag(0.75), "_x0p75")

    def test_threshold_boundary_1_005_is_inside_neutral_band(self):
        # abs(1.005 - 1.0) en float64 es 0.004999999999999893 (< 0.005
        # por representación binaria, no matemáticamente) → NO supera
        # el umbral estricto `>` del original → cadena vacía. Mismo
        # tipo de nota de precisión de punto flotante ya documentado
        # en GAP-062 (`test_speed_zone_labels.py`, zona neutra 1.005).
        self.assertEqual(export_speed_filename_tag(1.005), "")

    def test_threshold_boundary_0_995_is_just_outside_neutral_band(self):
        # abs(0.995 - 1.0) en float64 es 0.0050000000000000044 (> 0.005
        # por el mismo motivo de representación binaria) → SÍ supera
        # el umbral → tag aplicado. Verificado contra la aritmética
        # real de Python, no asumido — misma expresión EXACTA
        # (`abs(ratio - 1.0) > 0.005`) que el código original.
        self.assertEqual(export_speed_filename_tag(0.995), "_x0p99")

    def test_threshold_boundary_just_outside(self):
        self.assertEqual(export_speed_filename_tag(1.0051), "_x1p01")


class TestExportSpeedDisplaySuffix(unittest.TestCase):

    def test_neutral_ratio_is_empty(self):
        self.assertEqual(export_speed_display_suffix(1.0), "")

    def test_accelerated_ratio(self):
        self.assertEqual(export_speed_display_suffix(1.5), "  ×1.50")

    def test_threshold_boundary_inside_is_empty(self):
        self.assertEqual(export_speed_display_suffix(1.005), "")


class TestExportClipTag(unittest.TestCase):

    def test_no_clips_is_empty(self):
        self.assertEqual(export_clip_tag(0, 0), "")

    def test_left_only(self):
        self.assertEqual(export_clip_tag(3, 0), "  clips:L3/R0")

    def test_right_only(self):
        self.assertEqual(export_clip_tag(0, 5), "  clips:L0/R5")

    def test_both_channels(self):
        self.assertEqual(export_clip_tag(3, 1), "  clips:L3/R1")


if __name__ == "__main__":
    unittest.main()
