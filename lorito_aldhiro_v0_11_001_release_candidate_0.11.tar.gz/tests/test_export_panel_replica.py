"""
Tests reales de la réplica completa del panel "LORITO EXPORTADOR"
(§GAP-017): las 3 secciones de normalización con exclusión mutua real
(idéntico mecanismo a CRAC), derivadas de los enums reales de Lorito
Aldhiro (`NormalizationMode`/`NormalizationModeV21`), no de listas
fabricadas a mano.

Ejecutar: python3 -m unittest tests.test_export_panel_replica -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules


class TestNormalizationSectionSplit(unittest.TestCase):
    """Confirma que la separación en 3 secciones de CRAC (básica/
    avanzada/preset de cinta) es exactamente reproducible a partir de
    los enums reales de Lorito Aldhiro — no listas nuevas inventadas."""

    def test_advanced_values_are_last_three_of_normalization_mode(self):
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        expected = {NormalizationMode.MID_SIDE.value, NormalizationMode.CREST_GUARD.value,
                    NormalizationMode.AUTO.value}
        self.assertEqual(LoritoExportadorDialog._ADV_NORM_VALUES, expected)

    def test_tape_preset_values_match_v21_enum_exactly(self):
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import NormalizationModeV21
        tape_values = {m.value for m in NormalizationModeV21}
        self.assertEqual(len(tape_values), 10)
        self.assertIn("Preset: Type I Ferric", tape_values)
        self.assertIn("Análisis 2-pass (profundo)", tape_values)
        self.assertIn("Soft-limit (protección overs)", tape_values)

    def test_no_overlap_between_basic_advanced_and_tape_sets(self):
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import NormalizationModeV21
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        adv = LoritoExportadorDialog._ADV_NORM_VALUES
        tape = {m.value for m in NormalizationModeV21}
        basic = {m.value for m in NormalizationMode if m.value not in adv}
        self.assertEqual(adv & tape, set())
        self.assertEqual(adv & basic, set())
        self.assertEqual(tape & basic, set())


class TestDialogStructureAndMutualExclusion(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        _install_stub_modules()

    def _make_fake_studio(self):
        """Doble mínimo de LoritoAldhiroStudio: solo los atributos que
        LoritoExportadorDialog reparenta/lee — no requiere construir la
        ventana principal completa (bloqueada de todos modos por los
        límites de los propios stubs, ver GAP-013/GAP-015)."""
        from PySide6.QtWidgets import QComboBox, QLabel

        class _FakeStudio:
            pass

        studio = _FakeStudio()
        studio.codec_box = QComboBox()
        studio.codec_box.addItems(["WAV", "FLAC", "OGG", "WV"])
        studio.opt1_box = QComboBox()
        studio.opt1_box.addItems(["16-bit", "24-bit", "32-bit float"])
        studio.opt2_box = QComboBox()
        studio.opt2_label = QLabel("")
        studio.opt1_label = QLabel("")
        studio.norm_box = QComboBox()
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import NormalizationModeV21
        for m in NormalizationMode:
            studio.norm_box.addItem(m.value)
        for m in NormalizationModeV21:
            studio.norm_box.addItem(m.value)
        studio._export_output_dir = "/tmp"
        return studio

    def test_dialog_constructs_with_three_norm_combos(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        self.assertTrue(hasattr(dlg, "_norm_box"))
        self.assertTrue(hasattr(dlg, "_norm_adv_box"))
        self.assertTrue(hasattr(dlg, "_norm_tape_box"))
        self.assertGreater(dlg._norm_box.count(), 5)
        self.assertEqual(dlg._norm_adv_box.count(), 4)   # placeholder + 3
        self.assertEqual(dlg._norm_tape_box.count(), 11)  # placeholder + 10

    def test_selecting_advanced_resets_basic_and_tape(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        dlg._norm_tape_box.setCurrentIndex(2)   # algo distinto del placeholder
        dlg._norm_adv_box.setCurrentText(NormalizationMode.MID_SIDE.value)
        self.assertEqual(dlg._norm_box.currentIndex(), 0)
        self.assertEqual(dlg._norm_tape_box.currentIndex(), 0)
        self.assertEqual(dlg._active_norm(), NormalizationMode.MID_SIDE.value)

    def test_selecting_tape_preset_resets_basic_and_advanced(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import NormalizationModeV21
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        dlg._norm_adv_box.setCurrentIndex(1)
        preset = NormalizationModeV21.PRESET_TYPE_II.value
        dlg._norm_tape_box.setCurrentText(preset)
        self.assertEqual(dlg._norm_box.currentIndex(), 0)
        self.assertEqual(dlg._norm_adv_box.currentIndex(), 0)
        self.assertEqual(dlg._active_norm(), preset)

    def test_selecting_basic_resets_advanced_and_tape(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        dlg._norm_adv_box.setCurrentIndex(1)
        dlg._norm_box.setCurrentIndex(2)
        self.assertEqual(dlg._norm_adv_box.currentIndex(), 0)
        self.assertEqual(dlg._norm_tape_box.currentIndex(), 0)

    def test_priority_advanced_over_tape_over_basic(self):
        """Idéntico criterio que get_params() de CRAC: avanzada > cinta
        > básica, si por algún motivo dos quedaran seleccionadas a la
        vez (no debería ocurrir con la exclusión mutua, pero la
        prioridad de _active_norm() debe respetar este orden de todos
        modos, como salvaguarda)."""
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        # Forzar sin pasar por los slots de exclusión mutua (blockSignals)
        dlg._norm_adv_box.blockSignals(True)
        dlg._norm_adv_box.setCurrentIndex(1)
        dlg._norm_adv_box.blockSignals(False)
        dlg._norm_tape_box.blockSignals(True)
        dlg._norm_tape_box.setCurrentIndex(1)
        dlg._norm_tape_box.blockSignals(False)
        self.assertEqual(dlg._active_norm(), dlg._norm_adv_box.currentText())

    def test_iniciar_writes_active_norm_back_to_studio_norm_box(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        dlg._norm_adv_box.setCurrentText(NormalizationMode.CREST_GUARD.value)
        emitted = []
        dlg.export_requested.connect(lambda: emitted.append(True))
        dlg._on_iniciar()
        self.assertEqual(studio.norm_box.currentText(), NormalizationMode.CREST_GUARD.value)
        self.assertTrue(emitted)

    def test_output_dir_written_back_on_iniciar(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        dlg.dir_edit.setText("/mnt/nuevo_destino")
        dlg._on_iniciar()
        self.assertEqual(studio._export_output_dir, "/mnt/nuevo_destino")

    def test_reparented_widgets_hidden_after_abortar(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        for w in dlg._reparented:
            self.assertTrue(w.isVisible())
        dlg.reject()
        for w in dlg._reparented:
            self.assertFalse(w.isVisible())

    def test_info_panel_reflects_current_selection(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        studio = self._make_fake_studio()
        dlg = LoritoExportadorDialog(studio)
        studio.codec_box.setCurrentText("FLAC")
        dlg._refresh_info_panel()
        self.assertIn("FLAC", dlg._info_label.text())


if __name__ == "__main__":
    unittest.main()
