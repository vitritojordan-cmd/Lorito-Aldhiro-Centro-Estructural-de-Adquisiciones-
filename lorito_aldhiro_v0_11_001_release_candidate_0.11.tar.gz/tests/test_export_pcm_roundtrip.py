"""
test_export_pcm_roundtrip.py — auditoría de Fase 1 (migración del
export a `backend/export_streaming/`) de la Orden Maestra de
Saneamiento Pre-Auditoría Aldhira Phonographic.

Antes de considerar seguro wirear el camino streaming ya construido
(`SegmentProvider` + `WavEncoder` + `AtomicFinalizer` + `ExportSession`)
al `export()` real de la GUI, esta sesión audita si ese camino es
FIEL bit a bit para el caso sin ningún DSP (sin normalización, sin
resampleo) — el caso más simple posible, y aun así el más importante
para un proyecto de digitalización patrimonial donde "sin tocar" debe
significar literalmente eso.

Defecto real encontrado (no hipotético): `WavEncoder._float32_to_pcm_bytes`
usaba una escala ASIMÉTRICA respecto a `SegmentProvider.
_pcm_bytes_to_float32` (divide por 2^(bits-1), multiplica por
2^(bits-1)-1) combinada con truncación (`.astype(...)` en vez de
`np.round`) — el resultado: TODO el archivo re-exportado sin ningún
DSP salía con un error sistemático de hasta ±1 LSB en cada muestra,
nunca bit-exacto. Corregido con escala simétrica + redondeo + clip
final al único caso borde (+1.0 exacto).
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider,
)
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
    ExportSession,
)

_SUBTYPE_SPEC = {
    "PCM_16": (2, 32768, -32768, 32767),
    "PCM_24": (3, 8388608, -8388608, 8388607),
    "PCM_32": (4, 2147483648, -2147483648, 2147483647),
}


def _write_pcm_wav(path, rate, channels, pcm_samples, sample_width):
    """Escribe un WAV PCM entero crudo a partir de muestras int32 ya en
    el rango del subtipo — mismo helper de bajo nivel que
    `tests/test_export_streaming.py`, pero partiendo de enteros
    conocidos (no de un tono sintetizado) para poder comparar bit a
    bit después."""
    if sample_width == 2:
        raw = pcm_samples.astype("<i2").tobytes()
    elif sample_width == 3:
        u8 = np.frombuffer(pcm_samples.astype(np.int32).tobytes(),
                            dtype=np.uint8).reshape(-1, 4)
        raw = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    elif sample_width == 4:
        raw = pcm_samples.astype("<i4").tobytes()
    else:
        raise ValueError(sample_width)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(rate)
        wf.writeframesraw(raw)


def _read_pcm_wav_samples(path, sample_width):
    with wave.open(path, "rb") as wf:
        n = wf.getnframes()
        ch = wf.getnchannels()
        raw = wf.readframes(n)
    if sample_width == 2:
        return np.frombuffer(raw, dtype="<i2").astype(np.int32).reshape(n, ch)
    elif sample_width == 3:
        u8 = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
        buf32 = np.zeros((u8.shape[0], 4), dtype=np.uint8)
        buf32[:, 0:3] = u8
        buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
        return np.frombuffer(buf32.tobytes(), dtype="<i4").reshape(n, ch)
    elif sample_width == 4:
        return np.frombuffer(raw, dtype="<i4").astype(np.int64).reshape(n, ch)
    else:
        raise ValueError(sample_width)


class TestPcmFloatRoundtripUnit(unittest.TestCase):
    """Reproduce el defecto a nivel de la aritmética pura, sin tocar
    disco — aislando exactamente dónde vivía el problema."""

    def test_old_asymmetric_truncating_scale_was_lossy(self):
        rng = np.random.default_rng(0)
        pcm_in = rng.integers(-8388608, 8388608, size=50000,
                              dtype=np.int64).astype(np.int32)
        f32 = pcm_in.astype(np.float32) / 8388608.0
        # Aritmética EXACTA que tenía el encoder antes de esta sesión.
        old_pcm_out = (np.clip(f32, -1.0, 1.0) * 8388607.0).astype(np.int32)
        diff = old_pcm_out - pcm_in
        self.assertGreater(np.count_nonzero(diff), 0,
                            "el defecto debe ser real, no hipotético")
        self.assertLessEqual(int(np.max(np.abs(diff))), 1)

    def test_current_encoder_scale_is_bit_exact_for_16_and_24_bit(self):
        # PCM_32 se prueba aparte con tolerancia — ver
        # test_pcm32_limited_by_float32_mantissa_not_a_bug más abajo.
        enc = WavEncoder.__new__(WavEncoder)
        for subtype in ("PCM_16", "PCM_24"):
            width, _, lo, hi = _SUBTYPE_SPEC[subtype]
            enc.sample_width = width
            rng = np.random.default_rng(hash(subtype) & 0xFFFF)
            pcm_in = rng.integers(lo, hi + 1, size=20000, dtype=np.int64)
            scale = {2: 32768.0, 3: 8388608.0}[width]
            f32 = (pcm_in.astype(np.float64) / scale).astype(np.float32).reshape(-1, 1)
            raw = enc._float32_to_pcm_bytes(f32)
            if width == 3:
                u8 = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
                buf32 = np.zeros((u8.shape[0], 4), dtype=np.uint8)
                buf32[:, 0:3] = u8
                buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
                pcm_out = np.frombuffer(buf32.tobytes(), dtype="<i4")
            else:
                pcm_out = np.frombuffer(raw, dtype="<i2").astype(np.int64)
            np.testing.assert_array_equal(
                pcm_out, pcm_in,
                err_msg=f"round-trip no bit-exacto para {subtype}")

    def test_pcm32_limited_by_float32_mantissa_not_a_bug(self):
        # `Block.data` es SIEMPRE float32 por contrato (§`lorito_export_
        # blocks.py`) — float32 tiene 24 bits de mantisa, así que un
        # entero de 32 bits NO puede sobrevivir el viaje de ida y vuelta
        # de forma bit-exacta pase lo que pase en el encoder: es un
        # límite del propio contrato del pipeline, no un bug de escala.
        # Se verifica aquí que el error queda acotado a lo que la
        # precisión de float32 permite (unas pocas decenas de LSB sobre
        # 32 bits, error relativo ~1.2e-7 — muy por debajo de cualquier
        # umbral audible), NO que sea bit-exacto.
        enc = WavEncoder.__new__(WavEncoder)
        width, _, lo, hi = _SUBTYPE_SPEC["PCM_32"]
        enc.sample_width = width
        rng = np.random.default_rng(hash("PCM_32") & 0xFFFF)
        pcm_in = rng.integers(lo, hi + 1, size=20000, dtype=np.int64)
        f32 = (pcm_in.astype(np.float64) / 2147483648.0).astype(np.float32).reshape(-1, 1)
        raw = enc._float32_to_pcm_bytes(f32)
        pcm_out = np.frombuffer(raw, dtype="<i4").astype(np.int64)
        max_abs_err = int(np.max(np.abs(pcm_out - pcm_in)))
        max_rel_err = float(np.max(np.abs((pcm_out - pcm_in) / np.maximum(np.abs(pcm_in), 1))))
        self.assertLess(max_rel_err, 2 ** -23,
                         "el error debe explicarse por la mantisa de "
                         "float32 (24 bits), no por un bug de escala")


class TestFullChainRoundtrip(unittest.TestCase):
    """SegmentProvider (lectura) → WavEncoder (escritura) vía
    ExportSession, extremo a extremo, para los 3 subtipos soportados
    — la ruta real que usaría un export sin normalización ni
    resampleo."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_pcm_roundtrip_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _run_case(self, subtype):
        width, _, lo, hi = _SUBTYPE_SPEC[subtype]
        rng = np.random.default_rng(hash(subtype) & 0xFFFF)
        channels = 2

        seg_paths = []
        originals = []
        for i, n_frames in enumerate([4000, 3000, 5000]):
            pcm = rng.integers(lo, hi + 1, size=(n_frames, channels),
                               dtype=np.int64)
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_pcm_wav(p, 48000, channels, pcm, width)
            seg_paths.append(p)
            originals.append(pcm)
        original_concat = np.concatenate(originals, axis=0)

        out_path = os.path.join(self.tmpdir, f"final_{subtype}.wav")
        session = ExportSession(
            seg_paths, encoder_cls=WavEncoder, final_path=out_path,
            encoder_kwargs={"subtype": subtype}, block_frames=1500,
        )
        report = session.run()
        self.assertTrue(report.ok, msg=report.error)

        result = _read_pcm_wav_samples(out_path, width)
        np.testing.assert_array_equal(
            result.astype(np.int64), original_concat,
            err_msg=f"export streaming ({subtype}) no es bit-exacto "
                    f"para audio sin ningún DSP aplicado")

    def test_roundtrip_pcm16(self):
        self._run_case("PCM_16")

    def test_roundtrip_pcm24(self):
        self._run_case("PCM_24")

    def test_roundtrip_pcm32_bounded_by_float32_mantissa(self):
        # Ver `test_pcm32_limited_by_float32_mantissa_not_a_bug` — mismo
        # límite arquitectónico, ahora verificado en la cadena completa
        # (SegmentProvider + WavEncoder), con tolerancia en vez de
        # igualdad exacta.
        width, _, lo, hi = _SUBTYPE_SPEC["PCM_32"]
        rng = np.random.default_rng(hash("PCM_32") & 0xFFFF)
        channels = 2
        seg_paths, originals = [], []
        for i, n_frames in enumerate([4000, 3000, 5000]):
            pcm = rng.integers(lo, hi + 1, size=(n_frames, channels), dtype=np.int64)
            p = os.path.join(self.tmpdir, f"seg32_{i:04d}.wav")
            _write_pcm_wav(p, 48000, channels, pcm, width)
            seg_paths.append(p)
            originals.append(pcm)
        original_concat = np.concatenate(originals, axis=0)

        out_path = os.path.join(self.tmpdir, "final_PCM_32.wav")
        session = ExportSession(
            seg_paths, encoder_cls=WavEncoder, final_path=out_path,
            encoder_kwargs={"subtype": "PCM_32"}, block_frames=1500,
        )
        report = session.run()
        self.assertTrue(report.ok, msg=report.error)

        result = _read_pcm_wav_samples(out_path, width).astype(np.int64)
        max_rel_err = float(np.max(np.abs(
            (result - original_concat) / np.maximum(np.abs(original_concat), 1))))
        self.assertLess(max_rel_err, 2 ** -23)


if __name__ == "__main__":
    unittest.main()
