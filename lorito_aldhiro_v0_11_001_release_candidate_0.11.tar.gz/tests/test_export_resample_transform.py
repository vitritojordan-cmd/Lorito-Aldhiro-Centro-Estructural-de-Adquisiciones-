"""
test_export_resample_transform.py — GAP-065 (FASE 3, hueco (a): "el
resampleo por velocidad no tiene equivalente streaming").

Verifica, con ejecución real (no solo lectura de código):

  1. `expected_resampled_frames()` — el conteo exacto de frames de
     salida para una sesión completa a un `ratio` fijo.
  2. `StreamingSpeedResampleTransform` de forma AISLADA (sin
     `ExportSession`), alimentada con `Block`s sintéticos, verificando
     la garantía central: conteo de frames de salida EXACTO, con CERO
     deriva acumulada, sin importar cuántos bloques se procesen — en
     contraste explícito con el enfoque naíf (cada bloque calculando
     su propio `n_out` de forma independiente), que SÍ deriva de forma
     medible y creciente (mismo estilo de "medir el defecto real" que
     `tests/test_resample_continuity.py` usa para GAP-037).
  3. `ExportSession` real de punta a punta (`WavEncoder` +
     `AtomicFinalizer`, sin soundfile ni PySide6) con
     `block_transform=StreamingSpeedResampleTransform(...)` y
     `expected_output_frames=expected_resampled_frames(...)` cableados
     — incluyendo una sesión "larga" (muchos bloques pequeños) que es
     precisamente el caso donde el enfoque naíf fallaría el chequeo
     estricto de §28 (`frames_in == total_frames_expected`) de
     `AtomicFinalizer`.

Ejecutar:  python3 -m unittest tests.test_export_resample_transform -v
(desde la raíz del proyecto, con `lorito_aldhiro` en el PYTHONPATH).
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_export_session import ExportSession
from lorito_aldhiro.backend.dsp.lorito_dsp_resample_continuous import (
    resample_stateful_continuous,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_resample_transform import (
    expected_resampled_frames, StreamingSpeedResampleTransform,
)


def _write_pcm24_wav(path: str, rate: int, channels: int, n_frames: int,
                      freq_hz: float = 440.0, amplitude: float = 0.5):
    """Sintetiza un segmento WAV PCM_24 real (mismo helper que
    `tests/test_export_streaming.py`, duplicado a propósito — cada
    archivo de test de este proyecto es autocontenido, sin depender de
    imports cruzados entre módulos de test)."""
    t = np.arange(n_frames) / rate
    tone = (amplitude * np.sin(2 * np.pi * freq_hz * t)).astype(np.float32)
    data = np.tile(tone.reshape(-1, 1), (1, channels))
    pcm32 = (np.clip(data, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()

    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)
    return data


def _split_into_blocks(data: np.ndarray, block_frames: int) -> list:
    """Construye una lista de `Block` sintéticos a partir de un array
    completo — mismo troceo que `SegmentProvider.iter_blocks()` hace
    sobre segmentos reales, pero sin pasar por disco (para los tests
    "aislados" que no necesitan `ExportSession`)."""
    n_total = data.shape[0]
    blocks = []
    pos = 0
    while pos < n_total:
        take = min(block_frames, n_total - pos)
        chunk = data[pos:pos + take]
        pos += take
        blocks.append(Block(data=chunk, frame_offset=0, is_last=(pos >= n_total)))
    if not blocks:
        blocks = [Block(data=data[0:0], frame_offset=0, is_last=True)]
    return blocks


def _naive_total_output_frames(n_total_in: int, ratio: float, block_frames: int) -> int:
    """Reproduce el enfoque naíf que este módulo NO usa — cada bloque
    calculando `round(n_in_bloque / ratio)` de forma independiente, sin
    objetivo acumulado — para medir la deriva real que produce y
    documentar por contraste por qué se necesitó la técnica de
    "objetivo acumulado". Usa la misma función compartida
    (`resample_stateful_continuous`) que la solución real, así que la
    ÚNICA diferencia es la ausencia de la corrección de conteo."""
    cursor = 0.0
    history = None
    pos = 0
    total_out = 0
    while pos < n_total_in:
        take = min(block_frames, n_total_in - pos)
        chunk = np.zeros((take, 1), dtype=np.float32)
        out, cursor, history = resample_stateful_continuous(chunk, ratio, cursor, history)
        total_out += out.shape[0]
        pos += take
    return total_out


class TestExpectedResampledFrames(unittest.TestCase):

    def test_zero_or_negative_input_frames_yields_zero(self):
        self.assertEqual(expected_resampled_frames(0, 1.5), 0)
        self.assertEqual(expected_resampled_frames(-100, 1.5), 0)

    def test_ratio_one_is_identity(self):
        self.assertEqual(expected_resampled_frames(48000, 1.0), 48000)

    def test_slower_ratio_increases_frame_count(self):
        # ratio < 1.0 == reproducción más lenta == MÁS frames de salida
        # que de entrada (mismo signo que `PlaybackEngine`/`_resample_chunk`).
        n_in = 100_000
        ratio = 0.5
        n_out = expected_resampled_frames(n_in, ratio)
        self.assertEqual(n_out, 200_000)

    def test_faster_ratio_decreases_frame_count(self):
        n_in = 100_000
        ratio = 2.0
        n_out = expected_resampled_frames(n_in, ratio)
        self.assertEqual(n_out, 50_000)

    def test_rounds_to_nearest_and_floors_at_one(self):
        # Con `total_in_frames` muy pequeño y `ratio` grande, el
        # resultado matemático puede ser <1 — el piso de "al menos 1"
        # documentado en el docstring del módulo debe respetarse.
        self.assertEqual(expected_resampled_frames(1, 50.0), 1)


class TestStreamingSpeedResampleTransformDirect(unittest.TestCase):
    """Alimenta la transform directamente con `Block`s sintéticos —
    sin `ExportSession` ni disco — para aislar la garantía de conteo
    de frames de cualquier otra parte del pipeline."""

    def _run_transform(self, n_total_in: int, ratio: float, block_frames: int,
                        n_channels: int = 1):
        rng = np.random.default_rng(7)
        data = rng.uniform(-0.3, 0.3, size=(n_total_in, n_channels)).astype(np.float32)
        blocks_in = _split_into_blocks(data, block_frames)

        transform = StreamingSpeedResampleTransform(ratio=ratio, total_in_frames=n_total_in)
        total_out = 0
        n_blocks = 0
        for blk in blocks_in:
            out_blk = transform(blk)
            self.assertTrue(np.all(np.isfinite(out_blk.data)),
                             msg="salida no finita del resampleo streaming")
            total_out += out_blk.n_frames
            n_blocks += 1
        return total_out, transform.total_out_frames, n_blocks

    def test_short_session_matches_expected_exactly(self):
        total_out, expected, n_blocks = self._run_transform(
            n_total_in=50_000, ratio=0.85, block_frames=8192)
        self.assertGreater(n_blocks, 1)
        self.assertEqual(total_out, expected)

    def test_long_session_many_small_blocks_zero_cumulative_drift(self):
        """El caso que expone la deriva sistemática del enfoque naíf:
        miles de bloques pequeños con el MISMO tamaño (salvo el
        último), a un `ratio` que no es una fracción exacta de 1 en
        aritmética de punto flotante. La técnica de objetivo acumulado
        debe seguir dando el conteo EXACTO sin importar cuántos
        bloques haya."""
        n_total_in = 2_000_000
        ratio = 0.977  # deliberadamente "feo" para maximizar el redondeo por bloque
        block_frames = 512  # bloques pequeños → ~3900 bloques → deriva
                             # naíf grande si la técnica no funcionara
        total_out, expected, n_blocks = self._run_transform(
            n_total_in=n_total_in, ratio=ratio, block_frames=block_frames)
        self.assertGreater(n_blocks, 3000)
        self.assertEqual(total_out, expected,
                          msg="conteo de frames de salida debe ser EXACTO "
                              "sin deriva acumulada, sin importar el "
                              "número de bloques procesados")

    def test_naive_per_block_approach_actually_drifts(self):
        """Ancla de regresión: demuestra, con números reales, que el
        problema que este módulo resuelve es real — el enfoque naíf
        (sin objetivo acumulado) SÍ se desvía del conteo exacto
        esperado en una sesión larga con bloques pequeños. Si esta
        aserción alguna vez empezara a fallar (deriva == 0 también en
        el enfoque naíf), sería señal de que el defecto ya no está
        presente en `resample_stateful_continuous` por otra vía — pero
        hoy, documentado y medido, la deriva es real y measurable."""
        n_total_in = 2_000_000
        ratio = 0.977
        block_frames = 512
        expected = expected_resampled_frames(n_total_in, ratio)
        naive_total = _naive_total_output_frames(n_total_in, ratio, block_frames)
        self.assertNotEqual(
            naive_total, expected,
            msg="se esperaba que el enfoque naíf derivara del conteo "
                "exacto — si esto falla, revisar si sigue siendo "
                "necesaria la técnica de objetivo acumulado")

    def test_invalid_ratio_raises(self):
        with self.assertRaises(ValueError):
            StreamingSpeedResampleTransform(ratio=0.0, total_in_frames=1000)
        with self.assertRaises(ValueError):
            StreamingSpeedResampleTransform(ratio=-1.0, total_in_frames=1000)


class TestExportSessionWithResampleTransform(unittest.TestCase):
    """`ExportSession` real de punta a punta (WavEncoder +
    AtomicFinalizer, sin soundfile ni PySide6) con el transform de
    resampleo cableado — el camino que GAP-065 habilita."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_resample_test_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            try:
                os.remove(os.path.join(self.tmpdir, f))
            except OSError:
                pass
        os.rmdir(self.tmpdir)

    def _run_session(self, n_in_frames: int, ratio: float, block_frames: int):
        seg_path = os.path.join(self.tmpdir, "seg0000.wav")
        _write_pcm24_wav(seg_path, rate=48000, channels=2, n_frames=n_in_frames,
                          freq_hz=330.0)
        final_path = os.path.join(self.tmpdir, "captura_resampleada.wav")

        expected_out = expected_resampled_frames(n_in_frames, ratio)
        transform = StreamingSpeedResampleTransform(
            ratio=ratio, total_in_frames=n_in_frames)

        session = ExportSession(
            [seg_path], encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"},
            block_frames=block_frames,
            block_transform=transform,
            expected_output_frames=expected_out,
        )
        report = session.run()
        return report, final_path, expected_out

    def test_slower_ratio_end_to_end(self):
        # ratio < 1.0 == más lento == más frames de salida que de entrada
        report, final_path, expected_out = self._run_session(
            n_in_frames=20_000, ratio=0.75, block_frames=4096)

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, expected_out)
        self.assertEqual(report.frames_out, expected_out)
        self.assertEqual(report.total_frames_expected, expected_out)
        self.assertGreater(expected_out, 20_000)
        self.assertTrue(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))

        with wave.open(final_path, "rb") as wf:
            self.assertEqual(wf.getnframes(), expected_out)

    def test_faster_ratio_end_to_end(self):
        # ratio > 1.0 == más rápido == menos frames de salida que de entrada
        report, final_path, expected_out = self._run_session(
            n_in_frames=20_000, ratio=1.5, block_frames=4096)

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, expected_out)
        self.assertEqual(report.frames_out, expected_out)
        self.assertLess(expected_out, 20_000)

        with wave.open(final_path, "rb") as wf:
            self.assertEqual(wf.getnframes(), expected_out)

    def test_long_session_many_blocks_end_to_end_exact_frame_accounting(self):
        """El caso end-to-end que EXPONDRÍA el fallo de
        `AtomicFinalizer` (§28, `FrameAccountingError`) si la técnica
        de objetivo acumulado no funcionara: muchos bloques pequeños
        (~200) a un ratio "feo", verificado a través del pipeline
        REAL completo (SegmentProvider → transform → WavEncoder →
        AtomicFinalizer), no solo de forma aislada."""
        report, final_path, expected_out = self._run_session(
            n_in_frames=200_000, ratio=0.933, block_frames=1024)

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, expected_out)
        self.assertEqual(report.frames_out, expected_out)

        with wave.open(final_path, "rb") as wf:
            self.assertEqual(wf.getnframes(), expected_out)

    def test_ratio_one_behaves_like_identity_pass_through(self):
        report, final_path, expected_out = self._run_session(
            n_in_frames=15_000, ratio=1.0, block_frames=4096)
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(expected_out, 15_000)
        self.assertEqual(report.frames_out, 15_000)

    def test_default_behavior_unchanged_without_transform(self):
        """No-regresión explícita: una `ExportSession` SIN
        `block_transform` ni `expected_output_frames` (el uso
        preexistente, cubierto también por
        `tests/test_export_streaming.py`) debe seguir comportándose
        exactamente igual que antes de GAP-065."""
        seg_path = os.path.join(self.tmpdir, "seg_plain.wav")
        _write_pcm24_wav(seg_path, rate=48000, channels=2, n_frames=10_000)
        final_path = os.path.join(self.tmpdir, "captura_plain.wav")

        session = ExportSession(
            [seg_path], encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"},
            block_frames=4096,
        )
        report = session.run()
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, 10_000)
        self.assertEqual(report.frames_out, 10_000)
        self.assertEqual(report.total_frames_expected, 10_000)


if __name__ == "__main__":
    unittest.main()
