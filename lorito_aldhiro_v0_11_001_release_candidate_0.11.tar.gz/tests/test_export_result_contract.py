"""
test_export_result_contract.py — GAP-051, FASE 1 ("Contratos +
errores", §4) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Cubre los campos NUEVOS y aditivos de `ExportSessionReport`
(`status`, `checksum_status`, `segments_read`, `segments_failed`,
`output_path`, `duration_seconds`, y los alias `frames_expected`/
`frames_read`/`frames_written` con el nombre exacto del contrato §4),
y el campo `exception` (estructurado) que `AtomicFinalizer.run()`
adjunta ahora junto al `error` (string) ya existente.

Ejecutar:  python3 -m unittest tests.test_export_result_contract -v
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import (
    FormatMismatchError,
)
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider,
)
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import (
    AtomicFinalizer,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
    ExportSession,
)
from lorito_aldhiro.backend.errors import ExportError, FrameAccountingError


def _write_pcm24_wav(path: str, rate: int, channels: int, n_frames: int,
                      freq_hz: float = 440.0, amplitude: float = 0.5):
    """Idéntico al helper de `tests/test_export_streaming.py`."""
    t = np.arange(n_frames) / rate
    tone = (amplitude * np.sin(2 * np.pi * freq_hz * t)).astype(np.float32)
    data = np.tile(tone.reshape(-1, 1), (1, channels))
    pcm32 = (np.clip(data, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)


class TestExportSessionReportContractOnSuccess(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_contract_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_success_populates_all_new_fields(self):
        seg_paths = []
        total = 0
        for i, n in enumerate([4000, 6000]):
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_pcm24_wav(p, 48000, 2, n)
            seg_paths.append(p)
            total += n

        final_path = os.path.join(self.tmpdir, "final.wav")
        report = ExportSession(
            seg_paths, encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"}, block_frames=2048,
        ).run()

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.status, "SUCCESS")
        self.assertEqual(report.checksum_status, "verified")
        self.assertEqual(report.output_path, final_path)
        self.assertEqual(report.segments_read, 2)
        self.assertEqual(report.segments_failed, 0)
        self.assertIsNone(report.exception)
        self.assertGreaterEqual(report.duration_seconds, 0.0)
        # Alias exactos del contrato §4 — mismo valor que los campos
        # originales, nunca un cálculo distinto.
        self.assertEqual(report.frames_expected, report.total_frames_expected)
        self.assertEqual(report.frames_read, report.frames_in)
        self.assertEqual(report.frames_written, report.frames_out)
        self.assertEqual(report.frames_expected, total)


class TestExportSessionReportContractOnFailure(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_contract_fail_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_format_mismatch_reports_correct_segments_read_and_failed(self):
        p_ok = os.path.join(self.tmpdir, "seg0_ok.wav")
        p_bad = os.path.join(self.tmpdir, "seg1_bad_rate.wav")
        _write_pcm24_wav(p_ok, 48000, 2, 1000)
        _write_pcm24_wav(p_bad, 44100, 2, 1000)  # rate distinto → FormatMismatchError

        final_path = os.path.join(self.tmpdir, "final.wav")
        report = ExportSession(
            [p_ok, p_bad], encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"},
        ).run()

        self.assertFalse(report.ok)
        self.assertEqual(report.status, "ABORTED")
        self.assertEqual(report.checksum_status, "not_computed")
        self.assertIsInstance(report.exception, FormatMismatchError)
        # p_ok (índice 0) ya se "leyó" (su header pasó la validación
        # antes de llegar al segmento con el formato distinto);
        # exactamente 1 segmento falló.
        self.assertEqual(report.segments_read, 1)
        self.assertEqual(report.segments_failed, 1)
        self.assertEqual(report.output_path, final_path)


class TestAtomicFinalizerExceptionField(unittest.TestCase):
    """Prueba `AtomicFinalizer.run()` directamente (mismo patrón que
    `tests/test_export_streaming.py`) para verificar `report["exception"]`
    con precisión, sin depender de poder reproducir cada condición vía
    corrupción de archivo real."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_finalizer_exc_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_frame_accounting_mismatch_attaches_frame_accounting_error(self):
        p = os.path.join(self.tmpdir, "seg0000.wav")
        _write_pcm24_wav(p, 48000, 1, 1000)
        provider = SegmentProvider([p])

        final_path = os.path.join(self.tmpdir, "final.wav")
        finalizer = AtomicFinalizer(
            encoder_cls=WavEncoder, fmt=provider.fmt, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24", "total_frames_hint": provider.total_frames},
        )
        # `total_frames_expected` deliberadamente distinto de lo que el
        # iterable realmente entrega — dispara la rama de frame
        # accounting sin necesitar corromper ningún archivo.
        result = finalizer.run(provider.iter_blocks(block_frames=256),
                                total_frames_expected=provider.total_frames + 500)

        self.assertFalse(result["ok"])
        self.assertIsInstance(result["exception"], FrameAccountingError)
        self.assertIn("frame accounting", result["error"])
        self.assertFalse(os.path.exists(final_path))

    def test_underlying_export_error_from_iterable_is_preserved_not_rewrapped(self):
        """Si el iterable de bloques ya lanza una excepción de nuestra
        familia (el caso real: `SegmentReadError` propagado desde
        `SegmentProvider.iter_blocks()`), `AtomicFinalizer` debe
        preservarla TAL CUAL en `report["exception"]` — nunca
        reenvolverla en un `ExportError` genérico, para no perder sus
        campos estructurados (segment_id/path/frame_start)."""
        from lorito_aldhiro.backend.errors import SegmentReadError

        def _bad_iterable():
            raise SegmentReadError("simulado: segmento truncado",
                                    segment_id="/x/seg.wav", path="/x/seg.wav")
            yield  # pragma: no cover — nunca se alcanza; hace de esto un generador

        p = os.path.join(self.tmpdir, "seg0000.wav")
        _write_pcm24_wav(p, 48000, 1, 100)
        provider = SegmentProvider([p])
        final_path = os.path.join(self.tmpdir, "final.wav")
        finalizer = AtomicFinalizer(
            encoder_cls=WavEncoder, fmt=provider.fmt, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"},
        )
        result = finalizer.run(_bad_iterable(), total_frames_expected=100)

        self.assertFalse(result["ok"])
        self.assertIsInstance(result["exception"], SegmentReadError)
        self.assertEqual(result["exception"].path, "/x/seg.wav")


if __name__ == "__main__":
    unittest.main()
