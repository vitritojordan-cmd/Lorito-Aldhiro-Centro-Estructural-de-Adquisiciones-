"""
test_export_session_spec.py — GAP-056, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Verifica `backend/export/lorito_export_session_spec.py` — la
extracción MECÁNICA de dos piezas puras que antes vivían inline dentro
de `_do_export()` (`lorito_mw_export.py`). El estándar de estos tests
no es "produce algo razonable" sino texto EXACTO, carácter a carácter,
contra transcripciones directas del código original que reemplaza —
cualquier diferencia de formato sería una regresión real para quien ya
lee estos archivos de especificación de sesiones anteriores.
"""

import unittest

from lorito_aldhiro.backend.export.lorito_export_session_spec import (
    IntegrityCheckResult, compute_integrity_check, build_session_spec_text,
)


class TestComputeIntegrityCheck(unittest.TestCase):
    def test_perfect_match_is_ok_with_no_messages(self):
        r = compute_integrity_check(frames_received=48000, frames_written=48000,
                                    frames_exported=48000)
        self.assertTrue(r.ok)
        self.assertEqual(r.messages, [])
        self.assertEqual(r.summary, "")

    def test_small_loss_under_one_percent_still_ok(self):
        # 0.5% de pérdida — bajo el umbral del 1%, no debe marcar fallo.
        r = compute_integrity_check(frames_received=100000, frames_written=99500,
                                    frames_exported=99500)
        self.assertTrue(r.ok)

    def test_capture_to_disk_loss_over_one_percent_flagged(self):
        r = compute_integrity_check(frames_received=100000, frames_written=98000,
                                    frames_exported=98000)
        self.assertFalse(r.ok)
        self.assertEqual(len(r.messages), 1)
        self.assertIn("pérdida captura→disco: 2.00%", r.messages[0])

    def test_disk_to_export_loss_over_one_percent_flagged(self):
        r = compute_integrity_check(frames_received=100000, frames_written=100000,
                                    frames_exported=97000)
        self.assertFalse(r.ok)
        self.assertIn("pérdida disco→export: 3.00%", r.messages[0])

    def test_both_losses_flagged_together_same_order_as_original(self):
        r = compute_integrity_check(frames_received=100000, frames_written=95000,
                                    frames_exported=90000)
        self.assertFalse(r.ok)
        self.assertEqual(len(r.messages), 2)
        self.assertIn("captura→disco", r.messages[0])
        self.assertIn("disco→export", r.messages[1])
        self.assertEqual(r.summary,
                         "pérdida captura→disco: 5.00% | pérdida disco→export: 5.26%")

    def test_zero_frames_received_skips_first_check_no_division_by_zero(self):
        r = compute_integrity_check(frames_received=0, frames_written=0,
                                    frames_exported=0)
        self.assertTrue(r.ok)


class TestBuildSessionSpecText(unittest.TestCase):
    """Cada aserción compara contra una transcripción directa del
    formato exacto de `_do_export()` §3j — ver el módulo bajo prueba
    para la correspondencia línea a línea con el original."""

    def _base_kwargs(self, **overrides):
        kwargs = dict(
            app_brand="Lorito Aldhiro", app_version="0.10.008",
            out_filename="aecct2_20260917_120000.wav",
            timestamp_str="2026-09-17 12:00:00",
            tape_label="C-90", sha256="abc123",
            codec="WAV", rate=48000, duration_s=125.5, size_bytes=24096000,
            total_frames=6024000, speed_ratio=1.0,
            norm_mode_label="Sin normalizar",
            frames_received=6024000, frames_written=6024000, frames_exported=6024000,
            clip_l=0, clip_r=0,
            is_otros=False, tape_counter_data={"flip_done": False, "final_value": 512},
        )
        kwargs.update(overrides)
        return kwargs

    def test_header_and_identification_block_exact(self):
        text = build_session_spec_text(**self._base_kwargs())
        sep = "═" * 60
        self.assertIn(f"{sep}\n  Aldhira de Especificación de CRAC\n"
                      f"  Lorito Aldhiro v0.10.008\n{sep}\n", text)
        self.assertIn("  Archivo exportado : aecct2_20260917_120000.wav\n", text)
        self.assertIn("  Fecha/hora        : 2026-09-17 12:00:00\n", text)
        self.assertIn("  Tipo de cassette  : C-90\n", text)
        self.assertIn("  SHA-256           : abc123\n", text)

    def test_sha256_missing_shows_no_disponible(self):
        text = build_session_spec_text(**self._base_kwargs(sha256=""))
        self.assertIn("  SHA-256           : no disponible\n", text)

    def test_audio_specs_block_exact_formatting(self):
        text = build_session_spec_text(**self._base_kwargs(
            duration_s=90.333, size_bytes=1048576, total_frames=4335984))
        self.assertIn("  Codec             : WAV\n", text)
        self.assertIn("  Sample rate       : 48000 Hz\n", text)
        self.assertIn("  Duración          : 90.33 s  (1.51 min)\n", text)
        self.assertIn("  Tamaño            : 1048576 bytes  (1024 KB)\n", text)
        self.assertIn("  Frames totales    : 4335984\n", text)

    def test_speed_ratio_line_only_when_not_1x(self):
        text_normal = build_session_spec_text(**self._base_kwargs(speed_ratio=1.0))
        self.assertNotIn("Velocidad ratio", text_normal)
        text_sped = build_session_spec_text(**self._base_kwargs(speed_ratio=1.5))
        self.assertIn("  Velocidad ratio   : ×1.5000\n", text_sped)
        # Umbral exacto del original: abs(ratio - 1.0) > 0.005
        text_edge = build_session_spec_text(**self._base_kwargs(speed_ratio=1.004))
        self.assertNotIn("Velocidad ratio", text_edge)

    def test_codec_options_only_when_truthy(self):
        text = build_session_spec_text(**self._base_kwargs(
            codec_opt1="", codec_opt2=""))
        self.assertNotIn("Opción codec", text)
        text2 = build_session_spec_text(**self._base_kwargs(
            codec_opt1="alta calidad", codec_opt2="16 bit"))
        self.assertIn("  Opción codec 1    : alta calidad\n", text2)
        self.assertIn("  Opción codec 2    : 16 bit\n", text2)

    def test_normalization_block_suppressed_when_no_normalization(self):
        text = build_session_spec_text(**self._base_kwargs(
            norm_mode_label="Sin normalizar", norm_gain_db=5.0))
        self.assertIn("  Modo              : Sin normalizar\n", text)
        self.assertNotIn("Ganancia aplicada", text)

    def test_normalization_block_shown_with_gain_and_peak(self):
        text = build_session_spec_text(**self._base_kwargs(
            norm_mode_label="LUFS -16", norm_gain_db=3.25, norm_peak_db=-1.2,
            norm_lufs=float("-inf")))
        self.assertIn("  Modo              : LUFS -16\n", text)
        self.assertIn("  Ganancia aplicada : 3.25 dB\n", text)
        self.assertIn("  Peak resultante   : -1.20 dBFS\n", text)
        self.assertNotIn("LUFS integrado", text)  # -inf se omite

    def test_normalization_block_shows_lufs_when_finite(self):
        text = build_session_spec_text(**self._base_kwargs(
            norm_mode_label="LUFS -16", norm_lufs=-15.8))
        self.assertIn("  LUFS integrado    : -15.80 LUFS\n", text)

    def test_integrity_and_clips_block_exact(self):
        text = build_session_spec_text(**self._base_kwargs(
            frames_received=1000, frames_written=999, frames_exported=999,
            clip_l=3, clip_r=7))
        self.assertIn("  Frames recibidos  : 1000\n", text)
        self.assertIn("  Frames escritos   : 999\n", text)
        self.assertIn("  Frames exportados : 999\n", text)
        self.assertIn("  Clips detectados  : L=3  R=7\n", text)

    def test_tape_counter_c60_c90_case1_truncated_side_a(self):
        text = build_session_spec_text(**self._base_kwargs(
            is_otros=False,
            tape_counter_data={"flip_done": False, "final_value": 512}))
        self.assertIn(
            "  C.R.A.C - Tape Counter - Punto de Truncamiento: (512)\n", text)

    def test_tape_counter_c60_c90_case2_side_a_done_side_b_truncated(self):
        text = build_session_spec_text(**self._base_kwargs(
            is_otros=False,
            tape_counter_data={"flip_done": True, "surplus_a": 120, "surplus_b": 0,
                               "phase": "B", "final_value": 300, "wrap_a_count": 1}))
        self.assertIn("  C.R.A.C Tape Counter: 120 (LADO A)\n", text)
        self.assertIn(
            "  [Nota] Contador pasó por 000 en Lado A: 1 vez/veces\n", text)
        self.assertIn(
            "  C.R.A.C - Tape Counter - Punto de Truncamiento: (300) EN EL LADO B\n",
            text)

    def test_tape_counter_c60_c90_case3_both_sides_complete(self):
        text = build_session_spec_text(**self._base_kwargs(
            is_otros=False,
            tape_counter_data={"flip_done": True, "surplus_a": 45, "surplus_b": 60,
                               "phase": "B", "wrap_a_count": 0, "wrap_b_count": 2}))
        self.assertIn("  C.R.A.C Tape Counter: 045 (LADO A)\n", text)
        self.assertIn("  C.R.A.C Tape Counter: 060 (LADO B)\n", text)
        self.assertIn(
            "  [Nota] Contador pasó por 000 en Lado B: 2 vez/veces\n", text)
        self.assertNotIn("Lado A: 0", text)  # wrap_a_count=0 no genera nota

    def test_tape_counter_otros_case(self):
        text = build_session_spec_text(**self._base_kwargs(
            is_otros=True,
            tape_counter_data={"wrap_count": 4, "final_value": 77}))
        self.assertIn("  C.R.A.C Tape Counter - Reinicios: 4\n", text)
        self.assertIn("  C.R.A.C Tape Counter - Posición Quedada: 077\n", text)

    def test_ends_with_footer_and_trailing_newline(self):
        text = build_session_spec_text(**self._base_kwargs())
        sep = "═" * 60
        self.assertTrue(text.endswith(f"{sep}\n  Fin del informe\n{sep}\n"))

    def test_tape_counter_data_defaults_to_empty_dict_when_none(self):
        # No debe lanzar si tape_counter_data es None (mismo criterio
        # que el original: `_spec_data = ... if _tape_panel else {}`).
        text = build_session_spec_text(**self._base_kwargs(
            is_otros=True, tape_counter_data=None))
        self.assertIn("Reinicios: 0", text)


if __name__ == "__main__":
    unittest.main()
