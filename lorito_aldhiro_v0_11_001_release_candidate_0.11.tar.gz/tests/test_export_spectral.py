"""
Tests reales del generador de imagen espectral post-export (§GAP-016)
y del cableado de "LORITO EXPORTADOR". El motor backend
(`lorito_export_spectral_engine.py`) es DSP puro con numpy — verificado
con ejecución real. El frontend Qt (`lorito_export_spectral_render.py`)
y el diálogo (`LoritoExportadorDialog`) se verifican con los stubs de
PySide6 ya establecidos en el proyecto.

Ejecutar: python3 -m unittest tests.test_export_spectral -v
"""

import os
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lorito_aldhiro.backend.export.lorito_export_spectral_engine import (
    compute_spectrogram_rgba, SpectralImageLayout, DEFAULT_LAYOUT,
)


class TestSpectralEngine(unittest.TestCase):

    def test_output_shape_and_dtype(self):
        t = np.arange(48000) / 48000
        sig = (0.3 * np.sin(2 * np.pi * 1000 * t)).astype(np.float32)
        rgba = compute_spectrogram_rgba(sig, 48000, win_size=1024)
        self.assertEqual(rgba.shape, (1080, 1920, 4))
        self.assertEqual(rgba.dtype, np.uint8)

    def test_header_and_footer_stripes_are_black(self):
        t = np.arange(48000) / 48000
        sig = (0.3 * np.sin(2 * np.pi * 1000 * t)).astype(np.float32)
        rgba = compute_spectrogram_rgba(sig, 48000, win_size=1024)
        layout = DEFAULT_LAYOUT
        header = rgba[:layout.hdr_h, :, :3]
        footer = rgba[layout.hdr_h + layout.spec_h:, :, :3]
        self.assertTrue(np.all(header == 0))
        self.assertTrue(np.all(footer == 0))

    def test_alpha_always_opaque(self):
        sig = (0.1 * np.random.default_rng(0).standard_normal(24000)).astype(np.float32)
        rgba = compute_spectrogram_rgba(sig, 48000, win_size=1024)
        self.assertTrue(np.all(rgba[:, :, 3] == 255))

    def test_stereo_input_averaged_to_mono(self):
        t = np.arange(24000) / 48000
        left = (0.3 * np.sin(2 * np.pi * 1000 * t)).astype(np.float32)
        right = left.copy()
        stereo = np.stack([left, right], axis=1)
        rgba_stereo = compute_spectrogram_rgba(stereo, 48000, win_size=1024)
        rgba_mono = compute_spectrogram_rgba(left, 48000, win_size=1024)
        np.testing.assert_array_equal(rgba_stereo, rgba_mono)

    def test_silence_does_not_crash(self):
        silence = np.zeros(24000, dtype=np.float32)
        rgba = compute_spectrogram_rgba(silence, 48000, win_size=1024)
        self.assertEqual(rgba.shape, (1080, 1920, 4))

    def test_custom_layout_respected(self):
        layout = SpectralImageLayout(img_w=640, img_h=360, hdr_h=30, footer_h=20)
        t = np.arange(24000) / 48000
        sig = (0.2 * np.sin(2 * np.pi * 500 * t)).astype(np.float32)
        rgba = compute_spectrogram_rgba(sig, 48000, win_size=512, layout=layout)
        self.assertEqual(rgba.shape, (360, 640, 4))


class TestSpectralRenderAndDialog(unittest.TestCase):
    """Requiere PySide6 (stubs si no está instalado)."""

    @classmethod
    def setUpClass(cls):
        from tests.test_stability_patch import _install_stub_modules
        _install_stub_modules()

    def test_platform_renamed_to_lorito_aldhiro_in_yellow(self):
        import inspect
        from lorito_aldhiro.frontend.spectral import lorito_export_spectral_render as mod
        self.assertEqual(mod._PLATFORM, "Lorito Aldhiro")
        # QColor real requiere PySide6 real (los stubs de este sandbox no
        # simulan QColor) — se verifica el literal en el código fuente.
        src = inspect.getsource(mod)
        self.assertIn("_PLATFORM_COLOR = QColor(255, 220, 0)", src)
        self.assertNotIn('_PLATFORM = "Carola Records Aldhira Capture"', src)

    def test_render_spectral_png_writes_file(self):
        """QImage/QPainter reales son necesarios para escribir un PNG de
        verdad — los stubs de este sandbox no simulan I/O de imagen.
        Se verifica que la función se ejecuta sin lanzar y que el
        contrato (llamar a img.save) está en el código fuente."""
        import inspect
        from lorito_aldhiro.frontend.spectral.lorito_export_spectral_render import render_spectral_png
        t = np.arange(24000) / 48000
        sig = (0.2 * np.sin(2 * np.pi * 800 * t)).astype(np.float32)
        rgba = compute_spectrogram_rgba(sig, 48000, win_size=512)
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "test_spectral.png")
            render_spectral_png(rgba, out, filename="prueba.wav", codec_name="WAV")
        src = inspect.getsource(render_spectral_png)
        self.assertIn("img.save(out_path", src)

    def test_export_flow_opens_dialog_before_export(self):
        """§GAP-016: el botón de exportación debe abrir LORITO
        EXPORTADOR antes de llamar a export() directamente — mismo
        mecanismo de dos pasos que CRAC (elegir parámetros → INICIAR)."""
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._build_ui)
        self.assertIn("_open_lorito_exportador", src)
        self.assertNotIn("self.btn_export.clicked.connect(self.export)", src)

    def test_codec_menu_removed_from_menu_bar(self):
        """Pedido explícito: "retira esa entrada de codecs de la barra
        de menú"."""
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._build_menu_bar)
        self.assertNotIn('_mbar_btn("CODEC")', src)

    def test_host_muestra_still_wired_in_menu_bar(self):
        """HOST y MUESTRA deben seguir actualizando de verdad (pedido
        explícito de esta sesión: no deben regresar a decorativos)."""
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._build_menu_bar)
        self.assertIn('_mbar_btn("HOST")', src)
        self.assertIn('_mbar_btn("MUESTRA")', src)
        self.assertIn('_mbar_btn("BITDEPH")', src)

    def test_bitdeph_menu_attempts_real_match_before_fnc_no_disp(self):
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._on_bitdeph_menu)
        self.assertIn("opt1_box", src)
        self.assertIn("_show_fnc_no_disp", src)

    def test_lorito_exportador_dialog_class_exists(self):
        from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog
        self.assertTrue(hasattr(LoritoExportadorDialog, "_on_iniciar"))
        self.assertTrue(hasattr(LoritoExportadorDialog, "export_requested"))

    def test_spectral_generation_wired_after_successful_export(self):
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio.export)
        self.assertIn("compute_spectrogram_rgba", src)
        self.assertIn("render_spectral_png", src)


if __name__ == "__main__":
    unittest.main()
