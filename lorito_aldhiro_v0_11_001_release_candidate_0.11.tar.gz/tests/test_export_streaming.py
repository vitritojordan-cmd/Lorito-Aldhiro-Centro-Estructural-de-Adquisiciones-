"""
Tests reales (ejecutables, sin PySide6 ni soundfile) del subsistema nuevo
`lorito_aldhiro/backend/export_streaming/` — FASE 6/7/8 de la Orden
Maestra de Refundación. Cubre §21 (format mismatch), §28 (frame
accounting), §24/§37/§38 (finalización atómica / aborto / limpieza), y
una verificación aproximada de §16/§19 (memoria acotada por bloque).

Ejecutar:  python3 -m unittest tests.test_export_streaming -v
(desde la raíz del proyecto, con `lorito_aldhiro` en el PYTHONPATH).
"""

import os
import struct
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import (
    AudioFormat, FormatMismatchError,
)
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider, DEFAULT_BLOCK_FRAMES,
)
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import (
    WavEncoder, WAV_SAFE_LIMIT_BYTES,
)
from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import (
    AtomicFinalizer,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
    ExportSession,
)


def _write_pcm24_wav(path: str, rate: int, channels: int, n_frames: int,
                      freq_hz: float = 440.0, amplitude: float = 0.5):
    """Sintetiza un segmento WAV PCM_24 real — mismo subtype que
    DiskWriterV2 usa para segmentos de captura."""
    t = np.arange(n_frames) / rate
    tone = (amplitude * np.sin(2 * np.pi * freq_hz * t)).astype(np.float32)
    data = np.tile(tone.reshape(-1, 1), (1, channels))
    pcm32 = (np.clip(data, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()

    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)
    return data


class TestSegmentProvider(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_test_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _seg_path(self, idx: int) -> str:
        return os.path.join(self.tmpdir, f"seg{idx:04d}.wav")

    def test_format_mismatch_aborts_before_reading_any_block(self):
        p1 = self._seg_path(0)
        p2 = self._seg_path(1)
        _write_pcm24_wav(p1, rate=48000, channels=2, n_frames=1000)
        _write_pcm24_wav(p2, rate=44100, channels=2, n_frames=1000)  # rate distinto
        with self.assertRaises(FormatMismatchError):
            SegmentProvider([p1, p2])

    def test_missing_segment_aborts(self):
        p1 = self._seg_path(0)
        _write_pcm24_wav(p1, rate=48000, channels=2, n_frames=100)
        with self.assertRaises(FormatMismatchError):
            SegmentProvider([p1, self._seg_path(99)])

    def test_total_frames_from_headers_only(self):
        p1, p2, p3 = self._seg_path(0), self._seg_path(1), self._seg_path(2)
        _write_pcm24_wav(p1, 48000, 2, 5000)
        _write_pcm24_wav(p2, 48000, 2, 3000)
        _write_pcm24_wav(p3, 48000, 2, 7000)
        provider = SegmentProvider([p1, p2, p3])
        self.assertEqual(provider.total_frames, 15000)
        self.assertEqual(provider.rate, 48000)
        self.assertEqual(provider.channels, 2)

    def test_blocks_are_sequential_and_bounded(self):
        p1, p2 = self._seg_path(0), self._seg_path(1)
        expected1 = _write_pcm24_wav(p1, 48000, 1, 10000, freq_hz=220.0)
        expected2 = _write_pcm24_wav(p2, 48000, 1, 6000, freq_hz=880.0)
        expected_all = np.concatenate([expected1, expected2], axis=0)

        provider = SegmentProvider([p1, p2])
        block_frames = 4096
        collected = []
        max_block_len = 0
        for blk in provider.iter_blocks(block_frames=block_frames):
            self.assertLessEqual(blk.n_frames, block_frames)
            max_block_len = max(max_block_len, blk.n_frames)
            collected.append(blk.data)
        self.assertEqual(max_block_len, block_frames)  # al menos un bloque lleno

        reconstructed = np.concatenate(collected, axis=0)
        self.assertEqual(reconstructed.shape[0], 16000)
        # Reconstrucción fiel dentro de la precisión de PCM_24 (~2^-23)
        np.testing.assert_allclose(reconstructed, expected_all, atol=2e-6)

    def test_block_memory_bounded_regardless_of_total_duration(self):
        """
        No es un test de RSS del proceso (ru_maxrss es monótono creciente
        y no baja entre llamadas dentro del mismo proceso, así que no
        sirve para medir "memoria constante" de forma fiable en un solo
        proceso de test). En su lugar se verifica la garantía real que
        SegmentProvider ofrece: ningún bloque individual excede
        `block_frames`, sin importar cuántos segmentos ni cuán larga sea
        la sesión total — la propiedad que hace posible memoria O(bloque).
        """
        paths = []
        for i in range(20):  # sesión "larga" simulada: 20 segmentos
            p = self._seg_path(i)
            _write_pcm24_wav(p, 48000, 2, 50_000, freq_hz=100 + i)
            paths.append(p)
        provider = SegmentProvider(paths)
        self.assertEqual(provider.total_frames, 20 * 50_000)

        block_frames = 8192
        n_blocks = 0
        for blk in provider.iter_blocks(block_frames=block_frames):
            self.assertLessEqual(blk.n_frames, block_frames)
            n_blocks += 1
        self.assertGreater(n_blocks, 20 * 50_000 // block_frames)


class TestWavEncoderAndAtomicFinalizer(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_test_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            try:
                os.remove(os.path.join(self.tmpdir, f))
            except OSError:
                pass
        os.rmdir(self.tmpdir)

    def test_end_to_end_export_session_frame_accounting(self):
        seg_paths = []
        total_expected = 0
        for i, n in enumerate([12000, 9000, 15000]):
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_pcm24_wav(p, 48000, 2, n, freq_hz=300 + i * 50)
            seg_paths.append(p)
            total_expected += n

        final_path = os.path.join(self.tmpdir, "captura_final.wav")
        session = ExportSession(
            seg_paths, encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"},
            block_frames=4096,
        )
        report = session.run()

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, total_expected)
        self.assertEqual(report.frames_out, total_expected)
        self.assertEqual(report.total_frames_expected, total_expected)
        self.assertTrue(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))
        self.assertTrue(os.path.exists(report.checksum_path))
        self.assertTrue(len(report.sha256) == 64)

        with wave.open(final_path, "rb") as wf:
            self.assertEqual(wf.getnframes(), total_expected)
            self.assertEqual(wf.getframerate(), 48000)
            self.assertEqual(wf.getnchannels(), 2)

    def test_encoder_failure_leaves_no_final_file_and_no_orphan_partial(self):
        """§37: encoder failure → no corrupted final file, no orphan temp."""
        p = os.path.join(self.tmpdir, "seg0000.wav")
        _write_pcm24_wav(p, 48000, 1, 5000)

        class _FailingEncoder(WavEncoder):
            def write(self, block):
                if block.frame_offset > 0:
                    raise RuntimeError("fallo simulado de encoder a mitad de stream")
                super().write(block)

        final_path = os.path.join(self.tmpdir, "captura_falla.wav")
        provider = SegmentProvider([p])
        finalizer = AtomicFinalizer(
            encoder_cls=_FailingEncoder, fmt=provider.fmt, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24", "total_frames_hint": provider.total_frames},
        )
        result = finalizer.run(provider.iter_blocks(block_frames=1024),
                                total_frames_expected=provider.total_frames)

        self.assertFalse(result["ok"])
        self.assertFalse(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))

    def test_orphan_partial_from_previous_crash_is_cleaned_before_run(self):
        """§38: recuperación de un .partial huérfano de una corrida previa
        (simulando SIGTERM/crash) — no debe interferir con la nueva corrida."""
        p = os.path.join(self.tmpdir, "seg0000.wav")
        _write_pcm24_wav(p, 48000, 1, 2000)
        final_path = os.path.join(self.tmpdir, "captura_recovery.wav")

        with open(final_path + ".partial", "wb") as orphan:
            orphan.write(b"BASURA_DE_UNA_CORRIDA_ANTERIOR_INCOMPLETA")

        provider = SegmentProvider([p])
        finalizer = AtomicFinalizer(
            encoder_cls=WavEncoder, fmt=provider.fmt, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24", "total_frames_hint": provider.total_frames},
        )
        result = finalizer.run(provider.iter_blocks(block_frames=1024),
                                total_frames_expected=provider.total_frames)
        self.assertTrue(result["ok"], msg=result["error"])
        with wave.open(final_path, "rb") as wf:
            self.assertEqual(wf.getnframes(), 2000)

    def test_oversized_wav_writes_rf64_instead_of_raising(self):
        """§17/§25 (Fase 8, GAP-033): desde que RF64 está implementado,
        un tamaño estimado por encima del límite RIFF de 32 bits ya NO
        lanza `NotImplementedError` — el encoder escribe un header
        RF64 (EBU Tech 3306) desde el principio, en vez de fallar o de
        producir un WAV truncado silencioso. Ver
        `tests/test_rf64_encoder.py` para la verificación completa del
        formato RF64."""
        fmt = AudioFormat(rate=192000, channels=2, sample_width_bytes=4)
        huge_frames = (WAV_SAFE_LIMIT_BYTES // (fmt.channels * fmt.sample_width_bytes)) + 1000
        enc = WavEncoder(fmt, os.path.join(self.tmpdir, "huge.wav"),
                          subtype="PCM_32", total_frames_hint=huge_frames)
        enc.open()  # ya no lanza — decide RF64 internamente
        self.assertTrue(enc._rf64)
        enc.finalize()
        with open(os.path.join(self.tmpdir, "huge.wav"), "rb") as f:
            self.assertEqual(f.read(4), b"RF64")


if __name__ == "__main__":
    unittest.main()
