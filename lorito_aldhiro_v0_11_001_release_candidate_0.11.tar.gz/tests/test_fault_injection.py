"""
test_fault_injection.py — Fase 14 (inyección de fallos) de la Orden
Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic.

Ejercita `DiskWriterV2._write_loop` REAL (el thread de escritura a
disco, no un sustituto) contra fallos forzados: ENOSPC, fallos
transitorios que se recuperan con reintentos, fallos que agotan todos
los reintentos, y disco casi lleno detectado antes de escribir.

Usa el mismo mecanismo de stubs de sounddevice/soundfile ya establecido
(`tests/test_cola_elastica_disco.py`), pero reemplaza el stub de
`sf.SoundFile` (que es un simple `object`, no funcional) por una
implementación mínima REAL respaldada por el módulo `wave` de la
librería estándar — para poder escribir bytes de verdad a disco y
forzar fallos de escritura de forma controlada, exactamente en el
punto donde `_write_block_retry` los vería en producción.
"""

import errno
import os
import sys
import tempfile
import time
import types
import unittest
import wave

import numpy as np


def _install_stubs():
    if "sounddevice" not in sys.modules or getattr(sys.modules["sounddevice"], "__lorito_stub__", False):
        stub_sd = types.ModuleType("sounddevice")
        stub_sd.__lorito_stub__ = True
        stub_sd.InputStream = object
        stub_sd.query_devices = lambda *a, **k: []
        sys.modules["sounddevice"] = stub_sd
    if "soundfile" not in sys.modules or getattr(sys.modules["soundfile"], "__lorito_stub__", False):
        stub_sf = types.ModuleType("soundfile")
        stub_sf.__lorito_stub__ = True
        stub_sf.SoundFile = object
        sys.modules["soundfile"] = stub_sf


_install_stubs()

import lorito_aldhiro.backend.capture.lorito_capture_engine as ce_mod  # noqa: E402
from lorito_aldhiro.backend.capture.lorito_capture_engine import (  # noqa: E402
    ColaElasticaDisco, DiskWriterV2, CaptureEngineStatus,
)
from lorito_aldhiro.backend.core.lorito_constants import (  # noqa: E402
    CE_DISK_WRITE_RETRY_MAX,
)


class _FaultQueue:
    """Cola de fallos a inyectar en la próxima(s) llamada(s) a
    `write()` del `SoundFile` falso — cada test la puebla a medida."""
    def __init__(self):
        self.pending = []  # lista de excepciones a lanzar, en orden

    def push(self, exc):
        self.pending.append(exc)

    def maybe_raise(self):
        if self.pending:
            raise self.pending.pop(0)


class _FunctionalFakeSoundFile:
    """Sustituto de `sf.SoundFile` respaldado por el módulo `wave` de
    la librería estándar — escribe bytes REALES a disco (no un dummy
    que solo permite import), para poder verificar el contenido final
    y forzar fallos exactamente en el punto de `f.write(block)`."""

    def __init__(self, path, mode="w", samplerate=48000, channels=2,
                subtype="PCM_24", format="WAV", fault_queue=None):
        self.path = path
        self.channels = channels
        self._fault_queue = fault_queue or _FaultQueue()
        self._wf = wave.open(path, "wb")
        self._wf.setnchannels(channels)
        self._wf.setsampwidth(3)
        self._wf.setframerate(samplerate)
        self._closed = False

    def write(self, block):
        self._fault_queue.maybe_raise()
        pcm32 = np.clip(np.round(np.clip(block, -1.0, 1.0) * 8388608.0),
                        -8388608, 8388607).astype(np.int32)
        u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
        raw = np.ascontiguousarray(u8[:, 0:3]).tobytes()
        self._wf.writeframesraw(raw)

    def flush(self):
        pass

    def close(self):
        if not self._closed:
            self._wf.close()
            self._closed = True


class TestFaultInjection(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_faults_")
        self.path_tmp = os.path.join(self.tmpdir, "captura.wav")
        self.status = CaptureEngineStatus()
        self.ced = ColaElasticaDisco(capacity=1_000_000)
        self.fault_queue = _FaultQueue()

        def _fake_soundfile_factory(path, mode="w", samplerate=48000,
                                    channels=2, subtype="PCM_24", format="WAV"):
            return _FunctionalFakeSoundFile(
                path, mode, samplerate, channels, subtype, format,
                fault_queue=self.fault_queue)

        self._orig_soundfile = getattr(ce_mod.sf, "SoundFile", None)
        ce_mod.sf.SoundFile = _fake_soundfile_factory

        self.writer = DiskWriterV2(self.ced, self.status)

    def tearDown(self):
        ce_mod.sf.SoundFile = self._orig_soundfile
        if self.writer._thread is not None:
            self.writer.stop()
        for root, _dirs, files in os.walk(self.tmpdir):
            for f in files:
                os.remove(os.path.join(root, f))
        os.rmdir(self.tmpdir)

    def _start_and_feed(self, blocks):
        self.writer.start(self.path_tmp, rate=48000, channels=2)
        for blk in blocks:
            self.ced.put_nowait(blk)

    def test_transient_failure_recovers_within_retry_budget(self):
        # Falla 2 veces (dentro del presupuesto de CE_DISK_WRITE_RETRY_MAX=3),
        # la 3ª vez escribe bien — el bloque debe terminar escrito, sin
        # frames descartados.
        self.assertLess(2, CE_DISK_WRITE_RETRY_MAX)
        self.fault_queue.push(OSError("fallo transitorio simulado #1"))
        self.fault_queue.push(OSError("fallo transitorio simulado #2"))

        block = np.zeros((4000, 2), dtype=np.float32)
        self._start_and_feed([block])
        self.writer.flush(timeout=5.0)
        self.writer.stop()

        self.assertEqual(self.status.frames_dropped, 0)
        self.assertEqual(self.status.frames_written, 4000)

    def test_failure_exhausting_all_retries_drops_block_and_continues(self):
        # Falla las CE_DISK_WRITE_RETRY_MAX veces seguidas para el
        # PRIMER batch — ese batch se descarta, pero el writer sigue
        # vivo y escribe el SIGUIENTE con normalidad (no debe morir
        # por un solo batch perdido). Los dos bloques se envían con una
        # pausa entre medio para que el drain de la CED los procese
        # como dos batches SEPARADOS (si llegan juntos, `get_batch`
        # los concatena en un único batch — comportamiento real y
        # correcto de `ColaElasticaDisco`, no algo a evitar, pero para
        # este test específico se necesitan dos batches distintos).
        for _ in range(CE_DISK_WRITE_RETRY_MAX):
            self.fault_queue.push(OSError("fallo persistente simulado"))

        block_perdido = np.zeros((2000, 2), dtype=np.float32)
        block_ok = np.ones((3000, 2), dtype=np.float32) * 0.1

        self.writer.start(self.path_tmp, rate=48000, channels=2)
        self.ced.put_nowait(block_perdido)
        # Esperar a que el writer consuma y agote los reintentos del
        # primer batch antes de encolar el segundo.
        deadline = time.monotonic() + 5.0
        while self.status.frames_dropped == 0 and time.monotonic() < deadline:
            time.sleep(0.02)
        self.ced.put_nowait(block_ok)

        self.writer.flush(timeout=5.0)
        self.writer.stop()

        self.assertEqual(self.status.frames_dropped, 2000)
        self.assertEqual(self.status.frames_written, 3000)

    def test_enospc_stops_writer_immediately_without_retrying(self):
        # ENOSPC es un caso especial: NO se reintenta (a diferencia de
        # un OSError genérico) — el writer se detiene de inmediato.
        enospc = OSError("disco lleno simulado")
        enospc.errno = errno.ENOSPC
        self.fault_queue.push(enospc)

        block = np.zeros((1500, 2), dtype=np.float32)
        self._start_and_feed([block])
        deadline = time.monotonic() + 5.0
        while self.writer._active and time.monotonic() < deadline:
            time.sleep(0.05)

        self.assertFalse(self.writer._active,
                         "ENOSPC debe desactivar el writer sin reintentar")
        self.assertEqual(self.status.frames_dropped, 1500)
        self.writer.stop()

    def test_low_disk_space_precheck_drops_without_ever_calling_write(self):
        # El chequeo de espacio libre (os.statvfs) ocurre ANTES de
        # intentar escribir — si detecta muy poco espacio, descarta el
        # bloque sin haber llamado a f.write() en absoluto.
        class _FakeStatvfs:
            f_bavail = 1
            f_frsize = 1  # ~1 byte libre — fuerza la rama de disco casi lleno

        orig_statvfs = ce_mod.os.statvfs
        ce_mod.os.statvfs = lambda path: _FakeStatvfs()
        try:
            block = np.zeros((1000, 2), dtype=np.float32)
            self._start_and_feed([block])
            deadline = time.monotonic() + 5.0
            while self.writer._active and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertFalse(self.writer._active)
            self.assertEqual(self.status.frames_dropped, 1000)
            self.assertEqual(self.status.frames_written, 0)
        finally:
            ce_mod.os.statvfs = orig_statvfs
            self.writer.stop()

    def test_segment_open_failure_shuts_down_cleanly(self):
        # Si sf.SoundFile() falla al ABRIR (no al escribir), el writer
        # debe terminar limpiamente sin lanzar excepción no controlada
        # ni dejar el thread colgado.
        def _failing_factory(*a, **k):
            raise OSError("no se pudo abrir el archivo de captura")
        ce_mod.sf.SoundFile = _failing_factory

        self.writer.start(self.path_tmp, rate=48000, channels=2)
        self.writer._thread.join(timeout=5.0)
        self.assertFalse(self.writer._thread.is_alive(),
                         "el thread debe terminar solo si _open_segment falla")

    def test_written_audio_is_correct_after_recovering_from_failures(self):
        # No solo "no crashea" — el contenido final en disco debe ser
        # exactamente el bloque que sobrevivió, bit a bit.
        self.fault_queue.push(OSError("fallo transitorio simulado"))
        rng = np.random.default_rng(0)
        block = (rng.uniform(-0.3, 0.3, size=(2000, 2))).astype(np.float32)

        self._start_and_feed([block])
        self.writer.flush(timeout=5.0)
        self.writer.stop()

        with wave.open(self.path_tmp, "rb") as wf:
            n = wf.getnframes()
            raw = wf.readframes(n)
        u8 = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
        buf32 = np.zeros((u8.shape[0], 4), dtype=np.uint8)
        buf32[:, 0:3] = u8
        buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
        pcm = np.frombuffer(buf32.tobytes(), dtype="<i4").astype(np.float64)
        decoded = (pcm / 8388608.0).astype(np.float32).reshape(n, 2)

        expected_pcm = np.clip(np.round(np.clip(block, -1.0, 1.0) * 8388608.0),
                               -8388608, 8388607)
        actual_pcm = np.clip(np.round(np.clip(decoded, -1.0, 1.0) * 8388608.0),
                             -8388608, 8388607)
        np.testing.assert_array_equal(actual_pcm, expected_pcm)

    def test_disk_writer_computes_real_segment_checksum_on_close(self):
        # GAP-035 — DiskWriterV2 debe calcular un checksum real
        # (releyendo el segmento de disco) al cerrarlo, y ese checksum
        # debe efectivamente verificar contra el archivo final.
        from lorito_aldhiro.backend.archival import verify_segment_checksum

        block = np.ones((3000, 2), dtype=np.float32) * 0.2
        self._start_and_feed([block])
        self.writer.flush(timeout=5.0)
        self.writer.stop()

        checksums = self.writer.get_segment_checksums()
        self.assertEqual(len(checksums), 1)
        self.assertEqual(checksums[0]["frames"], 3000)
        self.assertEqual(checksums[0]["path"], self.path_tmp)

        result = verify_segment_checksum(self.path_tmp, checksums[0])
        self.assertTrue(result["ok"], msg=result.get("reason"))

    def test_disk_writer_checksum_detects_post_write_corruption(self):
        from lorito_aldhiro.backend.archival import verify_segment_checksum

        block = np.ones((2500, 2), dtype=np.float32) * 0.15
        self._start_and_feed([block])
        self.writer.flush(timeout=5.0)
        self.writer.stop()

        checksums = self.writer.get_segment_checksums()
        # Corromper el archivo DESPUÉS de que DiskWriterV2 ya calculó
        # su checksum de referencia al cerrarlo.
        with open(self.path_tmp, "r+b") as f:
            f.seek(60)
            byte = f.read(1)
            f.seek(60)
            f.write(bytes([byte[0] ^ 0xFF]))

        result = verify_segment_checksum(self.path_tmp, checksums[0])
        self.assertFalse(result["ok"])
        self.assertIn("corrupción real", result["reason"])




if __name__ == "__main__":
    unittest.main()
