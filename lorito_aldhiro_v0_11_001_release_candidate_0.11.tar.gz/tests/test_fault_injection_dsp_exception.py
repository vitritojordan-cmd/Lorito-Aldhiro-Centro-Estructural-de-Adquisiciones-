"""
test_fault_injection_dsp_exception.py — GAP-058, FASE 10 ("Fault
injection", §22 Suite E) de la Orden Maestra de Saneamiento,
Integración y Consolidación de Lorito Aldhiro.

Inyecta una excepción REAL de una etapa DSP dentro del drain loop de
producción (`_drain_loop_fn`, `lorito_capture_engine.py`) — no una
reimplementación del patrón, la función real que usa `CaptureEngineV2`
en producción, corrida en un hilo real con `RingBufferAbsorcion`/
`ColaElasticaDisco` reales. Confirma con ejecución real lo que el
propio código ya documenta en un comentario (§GAP-012): "cualquier
excepción del motor NR se registra y esa iteración cae a los bloques
sin procesar, en vez de perder la sesión de captura completa por un
fallo DSP" — no se asume que el comentario es correcto, se verifica.

`_set_rt_priority()`/`_mlockall()` (llamados al inicio de `_drain_loop_fn`)
degradan con gracia si no hay privilegios RT — confirmado leyendo su
código antes de escribir este test; no necesitan ningún stub.
"""

import os
import sys
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

from lorito_aldhiro.backend.capture.lorito_capture_engine import (
    RingBufferAbsorcion, ColaElasticaDisco, CaptureEngineStatus,
    _drain_loop_fn,
)


class _FaultyStage:
    """Sustituto mínimo de una etapa DSP real (p. ej. Muscle Eq Samir)
    — expone la misma interfaz (`process_chunk`) que consume
    `NRCoordinator`, pero falla deliberadamente a partir de la N-ésima
    llamada, simulando una excepción real de una etapa DSP."""

    def __init__(self, fail_after: int = 2):
        self.fail_after = fail_after
        self.calls = 0

    def process_chunk(self, chunk):
        self.calls += 1
        if self.calls > self.fail_after:
            raise ValueError("simulado: etapa DSP falló procesando este bloque")
        return chunk


class _MinimalFaultyCoordinator:
    """No usa `NRCoordinator` completo (evita construir toda la cadena
    real de 10 etapas) — expone exactamente la interfaz que `_drain_
    loop_fn` consume (`process_chunk(blk) -> np.ndarray`), delegando en
    `_FaultyStage` para inyectar el fallo de forma controlada."""

    def __init__(self, fail_after: int = 2):
        self._stage = _FaultyStage(fail_after=fail_after)

    def process_chunk(self, chunk):
        return self._stage.process_chunk(chunk)


class TestDspExceptionDoesNotCrashDrainLoop(unittest.TestCase):
    def _run_drain_loop(self, nr_coordinator, n_blocks_to_push: int,
                        rate=48000, channels=2, block_frames=256):
        rba = RingBufferAbsorcion(n_slots=64, frames_max=block_frames,
                                  channels=channels, name="RBA-test")
        ced = ColaElasticaDisco(capacity=100_000)
        status = CaptureEngineStatus()
        stop_evt = threading.Event()

        for i in range(n_blocks_to_push):
            block = np.full((block_frames, channels), 0.1 * (i + 1), dtype=np.float32)
            ok = rba.write(block)
            self.assertTrue(ok, f"RBA rechazó el bloque {i} (¿capacidad insuficiente?)")

        t = threading.Thread(
            target=_drain_loop_fn,
            args=(rba, ced, status, stop_evt, None, None, nr_coordinator),
            daemon=True, name="drain-loop-fault-test",
        )
        t.start()

        try:
            # Esperar (con timeout generoso, por sondeo — no un sleep
            # fijo) a que el drain haya consumido todo el RBA.
            deadline = time.monotonic() + 10.0
            while time.monotonic() < deadline:
                if rba.count == 0 and ced.frame_count >= n_blocks_to_push * block_frames:
                    break
                time.sleep(0.02)
        finally:
            # Pase lo que pase en el sondeo de arriba (incluida una
            # excepción de aserción), el hilo de fondo SIEMPRE debe
            # recibir la señal de parada — evita hilos huérfanos entre
            # tests si algo falla antes de llegar aquí.
            stop_evt.set()
            t.join(timeout=5.0)
        self.assertFalse(t.is_alive(), "el drain loop no terminó a tiempo tras stop_evt")
        return ced, status

    def test_dsp_exception_logged_and_batch_falls_back_to_unprocessed(self):
        coordinator = _MinimalFaultyCoordinator(fail_after=2)
        ced, status = self._run_drain_loop(coordinator, n_blocks_to_push=6)

        # La sesión NO se pierde: todos los frames empujados llegan a
        # la cola de disco (procesados o no), nunca se descartan por
        # el fallo DSP.
        self.assertEqual(ced.frame_count, 6 * 256)
        # La etapa falló de verdad al menos una vez (confirma que el
        # escenario de fallo realmente se ejercitó, no que se saltó).
        self.assertGreater(coordinator._stage.calls, 2)

    def test_healthy_coordinator_control_case_still_works(self):
        """Control negativo — sin fallo inyectado, mismo camino, mismo
        resultado de frame count (confirma que el arnés en sí no
        pierde frames por su cuenta, solo el escenario CON fallo)."""
        coordinator = _MinimalFaultyCoordinator(fail_after=10_000)  # nunca falla
        ced, status = self._run_drain_loop(coordinator, n_blocks_to_push=4)
        self.assertEqual(ced.frame_count, 4 * 256)

    def test_drain_loop_survives_every_single_block_failing(self):
        """Caso extremo real de §22: no solo 1 fallo aislado — la etapa
        DSP falla en TODAS las llamadas, no solo después de N. El
        drain loop debe seguir sin caerse ni perder frames."""
        coordinator = _MinimalFaultyCoordinator(fail_after=0)  # falla desde la 1ª
        ced, status = self._run_drain_loop(coordinator, n_blocks_to_push=5)
        self.assertEqual(ced.frame_count, 5 * 256)
        self.assertGreaterEqual(coordinator._stage.calls, 5)


if __name__ == "__main__":
    unittest.main()
