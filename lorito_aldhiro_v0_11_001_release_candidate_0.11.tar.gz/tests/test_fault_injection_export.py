"""
test_fault_injection_export.py — GAP-058, FASE 10 ("Fault injection",
§22 Suite E) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Inyecta fallos REALES de disco (ENOSPC, EIO) en la ruta de exportación
streaming (`AtomicFinalizer`/`ExportSession`, FASE 1) — no simulados
con mocks genéricos de alto nivel, sino mediante un `WavEncoder` real
cuyo `write()` fallará de verdad tras N llamadas (misma técnica que
§22 pide: "Introducir deliberadamente: ENOSPC, EIO... Cada fallo deberá
producir un resultado determinista").

No requiere ningún stub (`WavEncoder` usa `open()`/archivos planos de
Python, no `soundfile` — confirmado en FASE 1/GAP-051). No toca
`DiskWriterV2`/captura en tiempo real — GAP-052 documentó una
fragilidad de timing real en ese camino bajo hilos; este archivo se
mantiene deliberadamente en el lado no-threaded (exportación), donde
la inyección de fallos es determinista y segura de verdad.

Ejecutar: python3 -m unittest tests.test_fault_injection_export -v
"""

import errno
import os
import struct
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_session import ExportSession
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import AtomicFinalizer
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import SegmentProvider
from lorito_aldhiro.backend.errors import ExportError, ExportFinalizeError


def _write_real_segment(path, rate=48000, channels=2, n_frames=4000, seed=1):
    rng = np.random.default_rng(seed)
    audio = rng.uniform(-0.4, 0.4, size=(n_frames, channels)).astype(np.float32)
    pcm32 = (np.clip(audio, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)


def make_faulty_encoder_cls(fail_after_writes: int, errno_code: int):
    """Fábrica: subclase de WavEncoder cuyo `write()` real funciona
    normalmente las primeras `fail_after_writes` llamadas, y en la
    siguiente lanza `OSError(errno_code, ...)` — simula un disco que
    se queda sin espacio (o un fallo de E/S) A MITAD de una
    codificación real, no antes de empezar."""

    class FaultyWavEncoder(WavEncoder):
        _write_calls = 0

        def write(self, block):
            type(self)._write_calls += 1
            if type(self)._write_calls > fail_after_writes:
                raise OSError(errno_code, os.strerror(errno_code))
            super().write(block)

    return FaultyWavEncoder


class TestExportFaultInjectionEnospcDuringEncoding(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_fault_enospc_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_enospc_mid_encoding_aborts_cleanly_no_partial_no_final(self):
        p1 = os.path.join(self.tmpdir, "seg0.wav")
        p2 = os.path.join(self.tmpdir, "seg1.wav")
        _write_real_segment(p1, n_frames=8000, seed=1)
        _write_real_segment(p2, n_frames=8000, seed=2)
        final_path = os.path.join(self.tmpdir, "final.wav")

        # block_frames pequeño para forzar VARIAS llamadas a write() —
        # el fallo debe ocurrir a mitad de un segmento, no en el primero.
        FaultyEncoder = make_faulty_encoder_cls(
            fail_after_writes=3, errno_code=errno.ENOSPC)
        report = ExportSession(
            [p1, p2], encoder_cls=FaultyEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"}, block_frames=1000,
        ).run()

        self.assertFalse(report.ok)
        self.assertEqual(report.status, "ABORTED")
        self.assertFalse(os.path.exists(final_path),
                         "§37: nunca debe quedar un .final tras un fallo de disco")
        self.assertFalse(os.path.exists(final_path + ".partial"),
                         "§37: nunca debe quedar un .partial huérfano")
        self.assertIsInstance(report.exception, ExportError)
        self.assertTrue(
            "No space left" in report.error or "ENOSPC" in report.error.upper(),
            msg=f"error real: {report.error!r}")

    def test_eio_mid_encoding_aborts_cleanly(self):
        p1 = os.path.join(self.tmpdir, "seg0.wav")
        _write_real_segment(p1, n_frames=8000, seed=3)
        final_path = os.path.join(self.tmpdir, "final.wav")

        FaultyEncoder = make_faulty_encoder_cls(
            fail_after_writes=2, errno_code=errno.EIO)
        report = ExportSession(
            [p1], encoder_cls=FaultyEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"}, block_frames=1000,
        ).run()

        self.assertFalse(report.ok)
        self.assertFalse(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))
        self.assertIn("Input/output error", report.error)

    def test_result_is_deterministic_across_repeated_runs(self):
        """§22: "Cada fallo deberá producir un resultado determinista"
        — repite el mismo escenario de fallo varias veces y confirma
        que el resultado (no solo "falla", sino el mensaje/atributos
        exactos) es idéntico cada vez, no dependiente de orden de
        hilos ni de ningún estado compartido entre corridas."""
        p1 = os.path.join(self.tmpdir, "seg0.wav")
        _write_real_segment(p1, n_frames=5000, seed=9)
        results = []
        for i in range(3):
            final_path = os.path.join(self.tmpdir, f"final_{i}.wav")
            FaultyEncoder = make_faulty_encoder_cls(
                fail_after_writes=1, errno_code=errno.ENOSPC)
            report = ExportSession(
                [p1], encoder_cls=FaultyEncoder, final_path=final_path,
                encoder_kwargs={"subtype": "PCM_24"}, block_frames=1000,
            ).run()
            results.append((report.ok, report.status, report.frames_written))

        self.assertEqual(len(set(results)), 1,
                         f"resultados no deterministas entre corridas: {results}")


class TestExportFaultInjectionAtomicRename(unittest.TestCase):
    """Inyecta el fallo en la etapa de finalización (§37) en vez de
    durante la codificación — punto de fallo distinto, contrato de
    error distinto (`ExportFinalizeError`, no un `ExportError`
    genérico)."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_fault_rename_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_enospc_during_atomic_rename_reports_export_finalize_error(self):
        p1 = os.path.join(self.tmpdir, "seg0.wav")
        _write_real_segment(p1, n_frames=2000, seed=5)
        provider = SegmentProvider([p1])
        final_path = os.path.join(self.tmpdir, "final.wav")

        finalizer = AtomicFinalizer(
            encoder_cls=WavEncoder, fmt=provider.fmt, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"},
        )

        real_replace = os.replace

        def _faulty_replace(src, dst):
            if dst == final_path:
                raise OSError(errno.ENOSPC, "No space left on device")
            return real_replace(src, dst)

        os.replace = _faulty_replace
        try:
            result = finalizer.run(provider.iter_blocks(block_frames=500),
                                   total_frames_expected=provider.total_frames)
        finally:
            os.replace = real_replace

        self.assertFalse(result["ok"])
        self.assertIsInstance(result["exception"], ExportFinalizeError)
        self.assertIn("rename atómico falló", result["error"])
        self.assertFalse(os.path.exists(final_path))
        # El .partial tampoco debe sobrevivir — _cleanup_partial() debe
        # correr incluso cuando el fallo es en el rename, no solo
        # durante la codificación.
        self.assertFalse(os.path.exists(final_path + ".partial"))


if __name__ == "__main__":
    unittest.main()
