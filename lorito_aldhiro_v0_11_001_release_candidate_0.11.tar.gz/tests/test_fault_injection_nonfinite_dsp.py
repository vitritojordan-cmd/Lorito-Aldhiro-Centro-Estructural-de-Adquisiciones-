"""
test_fault_injection_nonfinite_dsp.py — GAP-059, FASE 10 ("Fault
injection", §22 Suite E) de la Orden Maestra de Saneamiento,
Integración y Consolidación de Lorito Aldhiro.

Inyecta NaN/Inf REALES en la cadena DSP (`NRCoordinator`, backend/nr/)
usando las clases de producción (`NRCoordinator` real, `sanitize_
finite` real) — no una reimplementación. A diferencia de `DSPIntegrity
Error` (§16, creada en GAP-051 pero deliberadamente NO conectada — ver
ese GAP para la decisión de política pendiente sobre si NaN/Inf debería
ABORTAR en vez de sanear), este archivo verifica el comportamiento
EXISTENTE (sanear + contar + resetear la etapa) tal como está hoy,
sin cambiar ninguna política — exactamente lo que pide §22 ("inyectar
NaN/Inf, resultado determinista"), sin reabrir la decisión pendiente
de FASE 6.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite


class _FakeStage:
    """Etapa DSP mínima e inyectable — expone `process_chunk`/`reset`
    (el contrato exacto que `NRCoordinator._sanitize_stage` consume).
    `output_override`, si se provee, es lo que `process_chunk`
    devuelve SIN IMPORTAR la entrada — simula una etapa cuyo cómputo
    interno produjo NaN/Inf de verdad (p. ej. un filtro IIR inestable),
    no un simple passthrough del NaN de entrada."""

    def __init__(self, output_override=None):
        self.output_override = output_override
        self.reset_calls = 0
        self.process_calls = 0

    def process_chunk(self, chunk):
        self.process_calls += 1
        if self.output_override is not None:
            return self.output_override.copy()
        return chunk

    def reset(self):
        self.reset_calls += 1


class TestSanitizeFiniteDirect(unittest.TestCase):
    """La función pura en aislamiento — base de todo lo demás."""

    def test_nan_replaced_with_zero(self):
        chunk = np.array([0.1, np.nan, 0.3], dtype=np.float32)
        clean, n_bad = sanitize_finite(chunk)
        self.assertEqual(n_bad, 1)
        self.assertEqual(clean[1], 0.0)
        self.assertEqual(clean[0], np.float32(0.1))

    def test_inf_clipped_not_replaced_with_zero(self):
        chunk = np.array([np.inf, -np.inf, 0.5], dtype=np.float32)
        clean, n_bad = sanitize_finite(chunk)
        self.assertEqual(n_bad, 2)
        self.assertTrue(np.isfinite(clean).all())
        self.assertGreater(clean[0], 0)   # +inf → clip positivo, no 0
        self.assertLess(clean[1], 0)      # -inf → clip negativo, no 0

    def test_healthy_chunk_returned_unchanged_same_object(self):
        chunk = np.array([0.1, 0.2, -0.3], dtype=np.float32)
        clean, n_bad = sanitize_finite(chunk)
        self.assertEqual(n_bad, 0)
        self.assertIs(clean, chunk)  # mismo objeto, sin copiar (documentado)

    def test_result_deterministic_across_repeated_calls(self):
        chunk = np.array([np.nan, np.inf, -np.inf, 1.0], dtype=np.float32)
        results = [sanitize_finite(chunk.copy()) for _ in range(5)]
        n_bads = {n for _, n in results}
        self.assertEqual(n_bads, {3})
        cleans = [tuple(c.tolist()) for c, _ in results]
        self.assertEqual(len(set(cleans)), 1, "resultados no deterministas")


class TestNRCoordinatorNonfiniteInputInjection(unittest.TestCase):
    def test_nan_at_input_sanitized_before_any_stage_sees_it(self):
        coord = NRCoordinator(sample_rate=48000, channels=2)
        fake = _FakeStage()  # passthrough — si recibe NaN, lo devolvería tal cual
        coord._muscle_eq = fake

        chunk = np.array([[np.nan, 0.2], [0.3, np.inf]], dtype=np.float32)
        out = coord.process_chunk(chunk)

        self.assertTrue(np.isfinite(out).all(),
                        "la salida final debe ser finita")
        self.assertEqual(coord.nonfinite_counts["input"], 2)
        # La etapa NO debió recibir NaN — sanitize_finite corre en la
        # entrada ANTES de llegar a self._muscle_eq.process_chunk().
        self.assertEqual(fake.process_calls, 1)

    def test_deterministic_input_count_across_repeated_calls(self):
        coord = NRCoordinator(sample_rate=48000, channels=2)
        coord._muscle_eq = _FakeStage()
        chunk = np.array([[np.nan, np.inf]], dtype=np.float32)

        counts = []
        for _ in range(4):
            coord.process_chunk(chunk.copy())
            counts.append(coord.nonfinite_counts["input"])

        # Acumulativo y determinista: +2 por llamada, nunca decrece
        # (documentado: "Nunca decrecen dentro de una sesión").
        self.assertEqual(counts, [2, 4, 6, 8])


class TestNRCoordinatorStageOutputInjection(unittest.TestCase):
    """La etapa en sí produce NaN/Inf en su salida (no un passthrough
    del NaN de entrada) — simula un filtro IIR/EMA real que se volvió
    inestable, el escenario real que motivó `stage.reset()` (ver
    docstring de `_sanitize_stage`)."""

    def test_stage_producing_nan_output_is_sanitized_and_stage_reset(self):
        coord = NRCoordinator(sample_rate=48000, channels=2)
        poisoned_output = np.array([[np.nan, 1e30]], dtype=np.float32)
        fake = _FakeStage(output_override=poisoned_output)
        coord._muscle_eq = fake

        healthy_input = np.array([[0.1, 0.2]], dtype=np.float32)
        out = coord.process_chunk(healthy_input)

        self.assertTrue(np.isfinite(out).all())
        self.assertEqual(coord.nonfinite_counts["muscle_eq"], 1)
        self.assertEqual(coord.nonfinite_counts["input"], 0,
                         "la entrada era sana — el conteo debe atribuirse "
                         "a la etapa correcta, no a 'input'")
        self.assertEqual(fake.reset_calls, 1,
                         "una etapa que produce NaN/Inf debe resetearse "
                         "para no envenenar su recursión permanentemente")

    def test_stage_producing_all_inf_every_call_never_crashes_pipeline(self):
        """Caso extremo real de §22: no un NaN puntual — la etapa
        produce basura no finita en TODAS las llamadas (simula un
        filtro totalmente divergido, no un glitch aislado)."""
        coord = NRCoordinator(sample_rate=48000, channels=2)
        fake = _FakeStage(output_override=np.array([[np.inf, -np.inf]], dtype=np.float32))
        coord._muscle_eq = fake

        for i in range(10):
            out = coord.process_chunk(np.array([[0.1, 0.1]], dtype=np.float32))
            self.assertTrue(np.isfinite(out).all(), f"iteración {i}: salida no finita")

        self.assertEqual(coord.nonfinite_counts["muscle_eq"], 20)  # 2 muestras × 10
        self.assertEqual(fake.reset_calls, 10)  # se resetea CADA vez que ensucia

    def test_healthy_stage_never_triggers_reset_or_count(self):
        """Control negativo — sin inyectar nada, ninguna etapa debe
        resetearse ni contarse."""
        coord = NRCoordinator(sample_rate=48000, channels=2)
        fake = _FakeStage()  # passthrough sano
        coord._muscle_eq = fake

        for _ in range(5):
            coord.process_chunk(np.array([[0.1, -0.1]], dtype=np.float32))

        self.assertEqual(coord.nonfinite_counts["muscle_eq"], 0)
        self.assertEqual(fake.reset_calls, 0)


if __name__ == "__main__":
    unittest.main()
