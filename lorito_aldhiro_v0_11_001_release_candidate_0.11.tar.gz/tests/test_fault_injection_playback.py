"""
test_fault_injection_playback.py -- GAP-073, FASE 10 ("Fault
injection", Orden Maestra de Saneamiento, Integración y Consolidación
de Lorito Aldhiro, §20).

Cierra los 4 escenarios que quedaban pendientes de FASE 10 (ver
`ESTADO_MAESTRO_CONSOLIDACION.md`, fila 10: "Faltan: disco lento, seek
tardío, scrub rápido, desconexión de dispositivo (requieren timing
real de hardware)"). A diferencia de `test_fault_injection.py`
(`DiskWriterV2`, mitad Capture) y `test_fault_injection_export.py`
(exportación), estos 4 escenarios ejercitan la mitad PLAYBACK
(`PlaybackEngine` real, con sus hilos reales de `_prefetch`/`_bridge`/
driver-de-audio) -- exactamente el motor con más historial de bugs de
pops/saltos/glitches del proyecto (FIX-1..FIX-G4, BUG-C), y el único
lugar donde la Orden pide simular timing real de hardware sin
hardware real disponible en este sandbox.

Mecanismo de inyección (nuevo en este GAP, local a este archivo, sin
tocar los stubs compartidos):

- `_SlowFunctionalSoundFile` -- subclase de `FunctionalSoundFile`
  (`tests/_functional_soundfile_stub.py`) que añade una latencia
  artificial ANTES de `.read()`/`.seek()` -- el punto EXACTO donde
  `PlaybackEngine._prefetch()` la experimentaría con un disco lento de
  verdad (HDD con seek time alto, red saturada, etc.), confirmado
  leyendo `_prefetch()` completo (líneas ~758-966 de
  `lorito_playback_engine.py`: cada rama -- lectura normal, tras seek,
  tras cambio de velocidad -- hace exactamente un `f.seek()` seguido
  de un `f.read()` por ciclo).
- Envoltura local del callback de `FunctionalOutputStream` que, tras
  N invocaciones reales exitosas, lanza una excepción genérica (no
  `sd.CallbackStop`) -- la señal real que produce PortAudio cuando el
  dispositivo de salida desaparece a mitad de stream (cualquier
  excepción que no sea `CallbackStop`/`CallbackAbort` aborta el
  stream; el propio stub ya lo replica con
  `except Exception: break` en `FunctionalOutputStream._run()`).

Criterio de verificación (igual que el resto de la batería de fault
injection del proyecto): no "suena bien" (imposible de automatizar)
sino integridad mecánica real bajo condiciones adversas reales --
ningún hilo crashea sin control, ningún NaN/Inf llega al driver, el
motor se recupera o se apaga limpiamente según el caso, sin threads
zombie.
"""

import os
import shutil
import sys
import tempfile
import time
import unittest

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)
_ROOT_DIR = os.path.dirname(_TESTS_DIR)
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)

import numpy as np  # noqa: E402

from _functional_soundfile_stub import (  # noqa: E402
    FunctionalSoundFile, install_functional_soundfile_stub,
)
install_functional_soundfile_stub()

from _functional_sounddevice_output_stub import (  # noqa: E402
    FunctionalOutputStream, install_functional_sounddevice_output_stub,
)
install_functional_sounddevice_output_stub(callback_interval=0.002)

import lorito_aldhiro.backend.playback.lorito_playback_engine as pe  # noqa: E402

# GAP-063/072/073: reasignar directamente sobre el módulo ya importado
# -- bajo `unittest discover` (orden alfabético de todo el árbol),
# `pe.sd`/`pe.sf` pueden haber quedado enlazados al stub/dummy vigente
# en el momento en que OTRO archivo importó `lorito_playback_engine`
# por primera vez.
pe.sd = sys.modules["sounddevice"]
pe.sf = sys.modules["soundfile"]

FS = 48000
CHANNELS = 2


def _wait_until(predicate, timeout=3.0, interval=0.01):
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if predicate():
            return True
        time.sleep(interval)
    return predicate()


def _build_segment_wav(path, n_frames, fs=FS, channels=CHANNELS):
    """Mismo contenido determinista (nunca ruido ni silencio) que
    GAP-072 -- dos tonos distinguibles por canal."""
    t = np.arange(n_frames, dtype=np.float64) / fs
    left = 0.5 * np.sin(2 * np.pi * 440.0 * t)
    right = 0.35 * np.sin(2 * np.pi * 660.0 * t + 0.3)
    sig = np.stack([left, right], axis=1).astype(np.float32)
    with FunctionalSoundFile(path, "w", samplerate=fs, channels=channels) as f:
        f.write(sig)
    return sig


class _SlowFunctionalSoundFile(FunctionalSoundFile):
    """`FunctionalSoundFile` real (PCM24 vía `wave`, sin diferencias
    de contenido) con una latencia artificial configurable ANTES de
    `.read()`/`.seek()` -- simula un disco lento en el punto exacto
    donde `_prefetch()` lo experimenta en producción real."""

    _read_delay = 0.0
    _seek_delay = 0.0

    def read(self, n, dtype="float32", always_2d=True):
        if self._read_delay > 0:
            time.sleep(self._read_delay)
        return super().read(n, dtype=dtype, always_2d=always_2d)

    def seek(self, frame):
        if self._seek_delay > 0:
            time.sleep(self._seek_delay)
        super().seek(frame)


def _install_slow_soundfile_factory(read_delay=0.0, seek_delay=0.0):
    """Reemplaza `pe.sf.SoundFile` (el objeto módulo que
    `PlaybackEngine`/`_prefetch()` usa REALMENTE -- el nombre `sf`
    ligado dentro de `lorito_playback_engine.py`, no necesariamente
    `sys.modules['soundfile']`) por una fábrica que construye
    `_SlowFunctionalSoundFile` con la latencia dada -- mismo patrón de
    fábrica configurable que `_FunctionalFakeSoundFile` ya usa en
    `tests/test_fault_injection.py`. Devuelve la fábrica ORIGINAL para
    que el test pueda restaurarla en `tearDown`.

    GAP-073, hallazgo real bajo la suite completa: bajo
    `unittest discover`, cada archivo que llama a
    `install_functional_soundfile_stub()` en su import crea un
    `types.ModuleType("soundfile")` NUEVO y lo instala en
    `sys.modules["soundfile"]` -- si eso ocurre en la fase de
    IMPORTACIÓN de un archivo posterior (alfabéticamente) al de este,
    `sys.modules["soundfile"]` en el momento en que un test EJECUTA ya
    NO es el mismo objeto que `pe.sf` (fijado una sola vez, en el
    import de ESTE archivo). Mutar `sys.modules["soundfile"].SoundFile`
    en ese caso no tiene ningún efecto sobre lo que `_prefetch()`
    realmente llama -- el disco lento nunca se inyectaba de verdad, un
    falso negativo confirmado con dos corridas reales de la suite
    completa. Mutar `pe.sf` directamente es inmune a ese problema
    porque es el objeto que el código bajo prueba usa, sea cual sea el
    estado de `sys.modules` en ese momento."""
    mod = pe.sf
    original = mod.SoundFile

    def _factory(path, mode="r", samplerate=48000, channels=2,
                 subtype="PCM_24", format="WAV"):
        if mode != "r":
            # La escritura del segmento de prueba usa siempre la
            # fábrica RÁPIDA original -- solo la LECTURA (el camino de
            # PlaybackEngine) debe sufrir la latencia inyectada.
            return original(path, mode, samplerate, channels, subtype, format)
        f = _SlowFunctionalSoundFile(path, mode, samplerate, channels,
                                     subtype, format)
        f._read_delay = read_delay
        f._seek_delay = seek_delay
        return f

    mod.SoundFile = _factory
    return original


class _DisconnectingOutputStreamFactory:
    """Fábrica de `sounddevice.OutputStream` que envuelve el callback
    real de `PlaybackEngine` (`_audio_cb`) para que, tras
    `disconnect_after` invocaciones reales exitosas, la SIGUIENTE
    lance una excepción genérica -- simula el dispositivo de salida
    desapareciendo a mitad de stream. Delega en `FunctionalOutputStream`
    real para todo lo demás (sin duplicar su mecánica de hilo/captura)."""

    def __init__(self, disconnect_after=15, **stream_kwargs):
        self.disconnect_after = disconnect_after
        self.stream_kwargs = stream_kwargs
        self.streams = []
        self.disconnect_triggered = False

    def __call__(self, *args, **kwargs):
        real_callback = kwargs.pop("callback")
        call_count = [0]

        def _wrapped_callback(outdata, frames, time_info, status):
            call_count[0] += 1
            if call_count[0] > self.disconnect_after:
                self.disconnect_triggered = True
                raise OSError(
                    "PortAudio: dispositivo de salida desconectado (simulado)")
            real_callback(outdata, frames, time_info, status)

        merged = dict(self.stream_kwargs)
        merged.update(kwargs)
        stream = FunctionalOutputStream(*args, callback=_wrapped_callback,
                                        **merged)
        self.streams.append(stream)
        return stream


class _PlaybackFaultInjectionBase(unittest.TestCase):
    """Base común: segmento real determinista + ciclo de vida del
    `PlaybackEngine` -- comparte setUp/tearDown, cada subclase inyecta
    su propio fallo."""

    def setUp(self):
        self._tmpdir = tempfile.mkdtemp(prefix="lorito_pb_faults_")
        self._path = os.path.join(self._tmpdir, "segment.wav")
        _build_segment_wav(self._path, n_frames=96_000)  # 2s reales
        self.engine = pe.PlaybackEngine()
        self._orig_soundfile_factory = None
        # GAP-073: guardar/restaurar sobre `pe.sd`/`pe.sf` -- el
        # objeto que `PlaybackEngine` usa REALMENTE -- nunca sobre
        # `sys.modules[...]` directamente (puede haber sido
        # reemplazado por el import de otro archivo bajo
        # `unittest discover`, ver docstring de
        # `_install_slow_soundfile_factory`).
        self._orig_output_stream_factory = pe.sd.OutputStream

    def tearDown(self):
        self.engine.stop()
        # Restaurar SIEMPRE los atributos de `pe.sd`/`pe.sf` -- mutarlos
        # afecta a todo el proceso bajo `unittest discover` mientras
        # sigan siendo el objeto vigente (GAP-036/037/041/063/072/073).
        if self._orig_soundfile_factory is not None:
            pe.sf.SoundFile = self._orig_soundfile_factory
        pe.sd.OutputStream = self._orig_output_stream_factory
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def _start_and_wait_stream(self, speed_ratio=1.0, timeout=5.0):
        self.engine.start(
            path=self._path, rate=FS, channels=CHANNELS,
            start_frame=0, speed_ratio=speed_ratio, on_done=None,
        )
        self.assertTrue(
            _wait_until(lambda: self.engine.is_active(), timeout=timeout),
            "el hilo de PlaybackEngine no arrancó a tiempo")
        self.assertTrue(
            _wait_until(lambda: self.engine._stream is not None, timeout=timeout),
            "el OutputStream (preload de prefetch) no se abrió a tiempo")
        return self.engine._stream


class TestSlowDiskDuringPlayback(_PlaybackFaultInjectionBase):
    """Escenario 1: disco lento. Cada `.read()` real de `_prefetch()`
    se demora 50ms -- suficiente para que el consumo del callback
    (mucho más rápido en tiempo real de reloj bajo el stub) agote el
    colchón de `PE_RING_CHUNKS` y fuerce underruns reales repetidos.
    El motor debe degradar (silencio, contadores de underrun) sin
    crashear ni corromper el stream con NaN/Inf."""

    def test_playback_survives_sustained_slow_disk_reads(self):
        self._orig_soundfile_factory = _install_slow_soundfile_factory(
            read_delay=0.05)

        stream = self._start_and_wait_stream()
        time.sleep(0.6)  # varios ciclos reales bajo disco lento
        self.engine.stop()

        self.assertGreater(stream.callbacks_delivered, 0,
                           "el driver simulado nunca recibió callbacks")
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all(),
                            "bloque con NaN/Inf entregado bajo disco lento")

        # Evidencia de que el fallo se ejerció DE VERDAD (no fue tan
        # rápido que nunca se notó): al menos algunas muestras de
        # silencio real (relleno de underrun) en el audio entregado --
        # con un tono real de 440/660Hz calculado matemáticamente
        # (nunca cuantizado exactamente a 0.0 por azar, confirmado con
        # ejecución real), CUALQUIER muestra en 0.0 exacto solo puede
        # venir del relleno de underrun (`outdata[out_written:] = 0`),
        # nunca de la señal misma. No se exige que un bloque COMPLETO
        # de 512 frames sea silencio -- tras la corrección de
        # FIX-UNDERRUN-SPIN, un underrun real casi siempre solo cubre
        # el REMANENTE de un bloque que ya tenía audio real al
        # principio (relleno parcial), que es el comportamiento
        # correcto, no una señal más débil de que el escenario se
        # ejerció.
        all_delivered = np.concatenate(stream.captured, axis=0)
        zero_frames = int(np.all(all_delivered == 0.0, axis=1).sum())
        self.assertGreater(zero_frames, 0,
                           "no se observó ningún underrun real bajo disco "
                           "lento -- el escenario no se ejerció de verdad")

    def test_engine_stops_cleanly_after_slow_disk_session(self):
        self._orig_soundfile_factory = _install_slow_soundfile_factory(
            read_delay=0.05)
        self._start_and_wait_stream()
        time.sleep(0.3)
        self.engine.stop()

        self.assertFalse(self.engine.is_active())
        self.assertIsNone(self.engine._stream)


class TestLateSeekUnderSlowDisk(_PlaybackFaultInjectionBase):
    """Escenario 2: seek tardío. El disco es tan lento (400ms por
    lectura, mayor que el presupuesto de espera de `_bridge()`:
    200ms + 30ms de retry = 230ms, ver FIX-BRIDGE-TIMEOUT/FIX-BRIDGE-
    RETRY) que un `seek_to()` real dispara la rama de fallback
    (fade-out de seguridad, `POP_RISK_FLUSH_EMPTY_DEQUE`) en vez de
    completar el hot-swap a tiempo. El motor debe seguir vivo, sin
    NaN/Inf, y recuperar contenido real una vez que la lectura lenta
    finalmente termina."""

    def test_seek_under_slow_disk_does_not_hang_or_crash(self):
        self._orig_soundfile_factory = _install_slow_soundfile_factory(
            read_delay=0.4, seek_delay=0.4)

        stream = self._start_and_wait_stream(timeout=10.0)
        time.sleep(0.3)

        self.engine.seek_to(48000)  # 1s dentro del segmento de 2s
        # Ventana generosa: 2 lecturas lentas encadenadas (seek+read)
        # pueden tardar ~0.8s en el caso ideal, pero bajo la suite
        # completa (`unittest discover`, cientos de hilos daemon de
        # otros archivos pudiendo seguir vivos/uniéndose) la
        # contención real de CPU/GIL puede estirar eso varias veces --
        # el criterio de este test es corrección (nunca se cuelga, sin
        # excepción), no velocidad, así que el timeout se da generoso
        # a propósito en vez de acoplarlo al peor caso teórico exacto.
        self.assertTrue(_wait_until(
            lambda: not self.engine._seek_evt.is_set(), timeout=15.0),
            "el prefetch nunca procesó el seek bajo disco lento")

        # El motor debe seguir vivo y entregando callbacks durante
        # TODA la espera -- nunca debe colgarse ni el hilo del
        # callback ni el de bridge/prefetch.
        self.assertTrue(self.engine.is_active(),
                        "el motor murió mientras esperaba el seek lento")

        time.sleep(0.5)  # deja que el contenido real vuelva a fluir
        self.engine.stop()

        self.assertGreater(stream.callbacks_delivered, 0)
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all(),
                            "bloque con NaN/Inf durante seek tardío")


class TestRapidScrub(_PlaybackFaultInjectionBase):
    """Escenario 3: scrub rápido. Simula un arrastre de mouse muy
    rápido -- muchas llamadas a `set_speed_live()` en sucesión rápida
    (más rápido que `PE_LIVE_DEBOUNCE`, mezclando ráfagas que SÍ
    cruzan el debounce con otras que no) -- estresa el mecanismo de
    live-flush/preservación de fase (FIX-P5) con un volumen de eventos
    muy por encima de lo que cualquier test existente ejercita."""

    def test_rapid_live_speed_changes_do_not_crash_or_corrupt_phase(self):
        stream = self._start_and_wait_stream()
        time.sleep(0.1)

        rng = np.random.default_rng(42)
        ratios = rng.uniform(-1.5, 2.0, size=60)
        last_ratio = 1.0
        for r in ratios:
            # Evitar ratio≈0 (caso degenerado documentado en
            # FIX-SNAP-FROZEN-HEAD, fuera del alcance de este escenario).
            if abs(r) < 0.05:
                r = 0.05 if r >= 0 else -0.05
            self.engine.set_speed_live(float(r))
            last_ratio = float(r)
            time.sleep(0.005)  # ráfaga rápida -- ~5ms entre eventos

        time.sleep(0.2)  # deja asentar el último flush real
        ph = self.engine._ss.phase_history
        self.assertTrue(
            ph is None or isinstance(ph, np.ndarray),
            f"phase_history con tipo inesperado tras scrub rápido: {type(ph)}")
        if isinstance(ph, np.ndarray):
            self.assertLessEqual(len(ph), 2)  # HISTORY_LEN

        self.assertEqual(self.engine._ss.live_ratio, last_ratio,
                         "el último ratio del scrub rápido no se conservó "
                         "-- posible carrera de estado")

        self.engine.stop()
        self.assertGreater(stream.callbacks_delivered, 0)
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all(),
                            "bloque con NaN/Inf durante scrub rápido")


class TestOutputDeviceDisconnect(_PlaybackFaultInjectionBase):
    """Escenario 4: desconexión de dispositivo de salida. Tras N
    callbacks reales exitosos, el callback lanza una excepción
    genérica (no `sd.CallbackStop`) -- la señal real de un error de
    driver/dispositivo. El stub (`FunctionalOutputStream._run()`) ya
    la atrapa igual que lo haría PortAudio real (`except Exception:
    break`); lo que este test verifica es que `PlaybackEngine` mismo
    se apaga limpio cuando el stream deja de estar activo por esa vía
    -- sin excepción no controlada, con `on_done` disparado, sin hilos
    zombie -- SIN que el propio test tenga que llamar a `stop()`."""

    def test_engine_shuts_down_cleanly_when_output_device_disconnects(self):
        factory = _DisconnectingOutputStreamFactory(
            disconnect_after=15, callback_interval=0.002)
        pe.sd.OutputStream = factory  # GAP-073: sobre pe.sd, no sys.modules[...]

        done_evt = __import__("threading").Event()
        self.engine.start(
            path=self._path, rate=FS, channels=CHANNELS,
            start_frame=0, speed_ratio=1.0,
            on_done=done_evt.set,
        )
        self.assertTrue(
            _wait_until(lambda: self.engine.is_active(), timeout=5.0),
            "el hilo de PlaybackEngine no arrancó a tiempo")
        self.assertTrue(
            _wait_until(lambda: self.engine._stream is not None, timeout=5.0))

        # El motor debe DETECTAR la "desconexión" y apagarse SOLO, sin
        # que el test llame a stop() -- exactamente como reaccionaría
        # ante un fallo real de hardware en medio de la reproducción.
        self.assertTrue(_wait_until(
            lambda: factory.disconnect_triggered, timeout=5.0),
            "la desconexión simulada nunca se disparó")
        self.assertTrue(_wait_until(
            lambda: not self.engine.is_active(), timeout=5.0),
            "el motor no se apagó tras la desconexión simulada del "
            "dispositivo de salida")
        self.assertTrue(_wait_until(lambda: done_evt.is_set(), timeout=3.0),
                        "on_done nunca se disparó tras la desconexión")
        self.assertIsNone(self.engine._stream)

        # Ningún bloque real entregado ANTES de la desconexión debe
        # tener NaN/Inf -- el fallo debe ser el único evento anómalo.
        self.assertGreater(len(factory.streams), 0)
        for blk in factory.streams[0].captured:
            self.assertTrue(np.isfinite(blk).all())

    def test_stop_after_disconnect_is_idempotent_and_safe(self):
        """`engine.stop()` llamado DESPUÉS de que el motor ya se
        auto-apagó por la desconexión no debe lanzar ni colgarse --
        mismo criterio de idempotencia que ya exige
        `test_playback_engine_integration.py::test_stop_is_clean_no_lingering_thread`."""
        factory = _DisconnectingOutputStreamFactory(
            disconnect_after=8, callback_interval=0.002)
        pe.sd.OutputStream = factory  # GAP-073: sobre pe.sd, no sys.modules[...]

        self._start_and_wait_stream()
        self.assertTrue(_wait_until(
            lambda: not self.engine.is_active(), timeout=5.0),
            "el motor no se apagó tras la desconexión simulada")

        # No debe lanzar ni colgarse -- idempotente por diseño.
        self.engine.stop()
        self.engine.stop()
        self.assertFalse(self.engine.is_active())


if __name__ == "__main__":
    unittest.main()
