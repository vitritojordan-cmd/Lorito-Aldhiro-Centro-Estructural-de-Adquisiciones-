"""
test_ffmpeg_stream_encoders.py — GAP-066 (cierre de FASE 3, hueco (b):
encoders streaming FLAC/OGG/WV, ver
`lorito_ffmpeg_stream_encoder.py`).

Ejecución REAL contra el `ffmpeg` instalado en este sandbox
(confirmado: `/usr/bin/ffmpeg`, con flac/libvorbis/wavpack disponibles)
— no hay stub aquí: si ffmpeg no estuviera disponible, estos tests se
saltan explícitamente (`unittest.skipUnless`), igual que el resto del
proyecto salta lo que depende de recursos externos ausentes (ver el
único skip preexistente de la suite, árbol fuente de CRAC ausente).

Cubre:
  1. Cada encoder de forma aislada (`Encoder.encode_all()`): round-trip
     encode→decode exacto en conteo de frames, vía `validate()`.
  2. `ExportSession` real de punta a punta con cada encoder, incluida
     una sesión con varios segmentos y bloques pequeños (varias
     fronteras de bloque, no solo un bloque único).
  3. Fallback de candidatos (`_pick_encoder_name`) y el caso "ffmpeg no
     disponible"/"sin encoder" (simulado sin tocar el ffmpeg real del
     sistema — parcheando `FFMPEG_CAPS` de forma aislada por test).

Ejecutar:  python3 -m unittest tests.test_ffmpeg_stream_encoders -v
(desde la raíz del proyecto, con `lorito_aldhiro` en el PYTHONPATH).
"""

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.audio.lorito_audio_backend import FFMPEG_CAPS
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import AudioFormat, Block
from lorito_aldhiro.backend.export_streaming.lorito_ffmpeg_stream_encoder import (
    FlacEncoder, OggEncoder, WvEncoder, _FfmpegPipeEncoder,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_session import ExportSession
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import ExportAbortError

import wave


def _write_pcm24_wav(path: str, rate: int, channels: int, n_frames: int,
                      freq_hz: float = 440.0, amplitude: float = 0.4):
    t = np.arange(n_frames) / rate
    tone = (amplitude * np.sin(2 * np.pi * freq_hz * t)).astype(np.float32)
    data = np.tile(tone.reshape(-1, 1), (1, channels))
    pcm32 = (np.clip(data, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)


def _make_blocks(n_total: int, n_channels: int, block_frames: int, seed=3):
    rng = np.random.default_rng(seed)
    data = rng.uniform(-0.4, 0.4, size=(n_total, n_channels)).astype(np.float32)
    pos = 0
    blocks = []
    while pos < n_total:
        take = min(block_frames, n_total - pos)
        chunk = data[pos:pos + take]
        pos += take
        blocks.append(Block(data=chunk, frame_offset=0, is_last=(pos >= n_total)))
    return blocks


_FFMPEG_OK = bool(FFMPEG_CAPS.get("available"))
_HAS_FLAC = _FFMPEG_OK and FFMPEG_CAPS.get("flac")
_HAS_OGG = _FFMPEG_OK and (FFMPEG_CAPS.get("libvorbis") or FFMPEG_CAPS.get("vorbis"))
_HAS_WV = _FFMPEG_OK and (FFMPEG_CAPS.get("libwavpack") or FFMPEG_CAPS.get("wavpack"))


class _EncoderRoundTripMixin:
    """Mixin común: encode_all() aislado con `Block`s sintéticos,
    verificado con `validate()` real (decodifica el archivo final de
    vuelta a PCM crudo y cuenta los frames exactos)."""

    encoder_cls = None
    encoder_kwargs = {}

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_ffmpeg_enc_test_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            try:
                os.remove(os.path.join(self.tmpdir, f))
            except OSError:
                pass
        os.rmdir(self.tmpdir)

    def _out_path(self, name: str) -> str:
        return os.path.join(self.tmpdir, name)

    def test_encode_all_round_trip_exact_frame_count(self):
        fmt = AudioFormat(rate=48000, channels=2, sample_width_bytes=4, is_float=True)
        n_total = 60_000
        blocks = _make_blocks(n_total, 2, block_frames=8192)
        out_path = self._out_path(f"out.{self.encoder_cls.codec_name.lower()}")

        enc = self.encoder_cls(fmt, out_path, total_frames_hint=n_total,
                                **self.encoder_kwargs)
        result = enc.encode_all(blocks)

        self.assertTrue(result["ok"], msg=result.get("error"))
        self.assertEqual(result["actual_frames"], n_total)
        self.assertEqual(result["actual_rate"], 48000)
        self.assertEqual(result["actual_channels"], 2)
        self.assertTrue(os.path.exists(out_path))
        self.assertGreater(os.path.getsize(out_path), 0)

    def test_mono_round_trip(self):
        fmt = AudioFormat(rate=44100, channels=1, sample_width_bytes=4, is_float=True)
        n_total = 20_000
        blocks = _make_blocks(n_total, 1, block_frames=4096)
        out_path = self._out_path(f"mono.{self.encoder_cls.codec_name.lower()}")

        enc = self.encoder_cls(fmt, out_path, total_frames_hint=n_total,
                                **self.encoder_kwargs)
        result = enc.encode_all(blocks)
        self.assertTrue(result["ok"], msg=result.get("error"))
        self.assertEqual(result["actual_frames"], n_total)
        self.assertEqual(result["actual_channels"], 1)

    def test_many_small_blocks_exact_frame_count(self):
        """Muchas fronteras de bloque — el caso donde un bug de
        buffering/streaming en el pipe sería más probable de aparecer
        que con un único bloque grande."""
        fmt = AudioFormat(rate=48000, channels=2, sample_width_bytes=4, is_float=True)
        n_total = 200_000
        blocks = _make_blocks(n_total, 2, block_frames=512)  # ~391 bloques
        self.assertGreater(len(blocks), 300)
        out_path = self._out_path(f"many.{self.encoder_cls.codec_name.lower()}")

        enc = self.encoder_cls(fmt, out_path, total_frames_hint=n_total,
                                **self.encoder_kwargs)
        result = enc.encode_all(blocks)
        self.assertTrue(result["ok"], msg=result.get("error"))
        self.assertEqual(result["actual_frames"], n_total)


@unittest.skipUnless(_HAS_FLAC, "ffmpeg sin encoder flac disponible en este sistema")
class TestFlacEncoderRoundTrip(_EncoderRoundTripMixin, unittest.TestCase):
    encoder_cls = FlacEncoder
    encoder_kwargs = {"compression_level": 4}


@unittest.skipUnless(_HAS_OGG, "ffmpeg sin encoder vorbis/libvorbis disponible en este sistema")
class TestOggEncoderRoundTrip(_EncoderRoundTripMixin, unittest.TestCase):
    encoder_cls = OggEncoder
    encoder_kwargs = {"quality": 5.0}


@unittest.skipUnless(_HAS_WV, "ffmpeg sin encoder wavpack/libwavpack disponible en este sistema")
class TestWvEncoderRoundTrip(_EncoderRoundTripMixin, unittest.TestCase):
    encoder_cls = WvEncoder
    encoder_kwargs = {"compression_level": "5"}


class TestEncoderSelectionAndFailureModes(unittest.TestCase):
    """Casos de fallo — parcheando `FFMPEG_CAPS` de forma AISLADA (una
    copia local, restaurada en `tearDown`) para simular escenarios que
    no dependen de si el ffmpeg real del sistema tiene o no cada
    encoder — reproducible en cualquier sandbox, con o sin ffmpeg."""

    def setUp(self):
        import lorito_aldhiro.backend.export_streaming.lorito_ffmpeg_stream_encoder as mod
        self._mod = mod
        self._orig_caps = dict(mod.FFMPEG_CAPS)
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_ffmpeg_fail_test_")

    def tearDown(self):
        self._mod.FFMPEG_CAPS.clear()
        self._mod.FFMPEG_CAPS.update(self._orig_caps)
        for f in os.listdir(self.tmpdir):
            try:
                os.remove(os.path.join(self.tmpdir, f))
            except OSError:
                pass
        os.rmdir(self.tmpdir)

    def test_ffmpeg_unavailable_raises_on_open(self):
        self._mod.FFMPEG_CAPS.clear()
        self._mod.FFMPEG_CAPS.update({"available": False})
        fmt = AudioFormat(rate=48000, channels=2, sample_width_bytes=4, is_float=True)
        enc = FlacEncoder(fmt, os.path.join(self.tmpdir, "x.flac"))
        with self.assertRaises(ExportAbortError):
            enc.open()

    def test_no_matching_encoder_raises_on_open(self):
        self._mod.FFMPEG_CAPS.clear()
        self._mod.FFMPEG_CAPS.update({
            "available": True, "path": FFMPEG_CAPS.get("path", "ffmpeg"),
            "flac": False,
        })
        fmt = AudioFormat(rate=48000, channels=2, sample_width_bytes=4, is_float=True)
        enc = FlacEncoder(fmt, os.path.join(self.tmpdir, "x.flac"))
        with self.assertRaises(ExportAbortError):
            enc.open()

    @unittest.skipUnless(_FFMPEG_OK, "ffmpeg no disponible en este sistema")
    def test_falls_back_to_second_candidate_when_first_unavailable(self):
        """`OggEncoder` prueba primero libvorbis y luego vorbis — si
        se fuerza `libvorbis=False` pero el `vorbis` nativo SÍ está
        disponible en este ffmpeg real, debe usarlo sin fallar.

        Estéreo a propósito (NO mono): se descubrió con ejecución real
        que el encoder nativo "vorbis" de ffmpeg (a diferencia de
        libvorbis) solo admite 2 canales — limitación real del propio
        ffmpeg, documentada en el docstring de `OggEncoder`, y sin
        impacto práctico aquí porque la producción de este proyecto
        captura siempre en estéreo (`CE_CHANNELS=2`, sin ruta de
        captura mono hoy)."""
        if not FFMPEG_CAPS.get("vorbis"):
            self.skipTest("este ffmpeg no tiene el encoder 'vorbis' nativo para probar el fallback")
        self._mod.FFMPEG_CAPS.clear()
        self._mod.FFMPEG_CAPS.update(self._orig_caps)
        self._mod.FFMPEG_CAPS["libvorbis"] = False

        fmt = AudioFormat(rate=44100, channels=2, sample_width_bytes=4, is_float=True)
        blocks = _make_blocks(10_000, 2, block_frames=4096)
        out_path = os.path.join(self.tmpdir, "fallback.ogg")
        enc = OggEncoder(fmt, out_path, quality=5.0)
        result = enc.encode_all(blocks)
        self.assertTrue(result["ok"], msg=result.get("error"))
        self.assertEqual(result["encoder"], "vorbis")

    def test_write_without_open_raises(self):
        fmt = AudioFormat(rate=48000, channels=1, sample_width_bytes=4, is_float=True)
        enc = FlacEncoder(fmt, os.path.join(self.tmpdir, "never_opened.flac"))
        blk = Block(data=np.zeros((100, 1), dtype=np.float32), frame_offset=0)
        with self.assertRaises(ExportAbortError):
            enc.write(blk)


class TestExportSessionWithFfmpegEncoders(unittest.TestCase):
    """`ExportSession` real de punta a punta con cada encoder
    streaming nuevo — el pipeline completo (`SegmentProvider` →
    encoder → `AtomicFinalizer`), no solo el encoder aislado."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_ffmpeg_test_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            try:
                os.remove(os.path.join(self.tmpdir, f))
            except OSError:
                pass
        os.rmdir(self.tmpdir)

    def _run_session(self, encoder_cls, encoder_kwargs, ext: str,
                      segment_sizes=(12000, 9000), block_frames=4096):
        seg_paths = []
        total_expected = 0
        for i, n in enumerate(segment_sizes):
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_pcm24_wav(p, 48000, 2, n, freq_hz=300 + i * 40)
            seg_paths.append(p)
            total_expected += n

        final_path = os.path.join(self.tmpdir, f"captura_final.{ext}")
        session = ExportSession(
            seg_paths, encoder_cls=encoder_cls, final_path=final_path,
            encoder_kwargs=encoder_kwargs, block_frames=block_frames,
        )
        report = session.run()
        return report, final_path, total_expected

    @unittest.skipUnless(_HAS_FLAC, "ffmpeg sin encoder flac disponible en este sistema")
    def test_flac_export_session_end_to_end(self):
        report, final_path, total_expected = self._run_session(
            FlacEncoder, {"compression_level": 5}, "flac")
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, total_expected)
        self.assertEqual(report.frames_out, total_expected)
        self.assertTrue(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))
        self.assertTrue(len(report.sha256) == 64)

    @unittest.skipUnless(_HAS_OGG, "ffmpeg sin encoder vorbis/libvorbis disponible en este sistema")
    def test_ogg_export_session_end_to_end(self):
        report, final_path, total_expected = self._run_session(
            OggEncoder, {"quality": 6.0}, "ogg")
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, total_expected)
        self.assertEqual(report.frames_out, total_expected)
        self.assertTrue(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))

    @unittest.skipUnless(_HAS_WV, "ffmpeg sin encoder wavpack/libwavpack disponible en este sistema")
    def test_wv_export_session_end_to_end(self):
        report, final_path, total_expected = self._run_session(
            WvEncoder, {"compression_level": "5"}, "wv")
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, total_expected)
        self.assertEqual(report.frames_out, total_expected)
        self.assertTrue(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))

    @unittest.skipUnless(_HAS_FLAC, "ffmpeg sin encoder flac disponible en este sistema")
    def test_encoder_failure_leaves_no_final_file_and_no_orphan_partial(self):
        """§37, mismo criterio que `test_export_streaming.py` para
        `WavEncoder`: un fallo de codificación no debe dejar ni un
        archivo final corrupto ni un `.partial` huérfano."""
        seg_path = os.path.join(self.tmpdir, "seg0000.wav")
        _write_pcm24_wav(seg_path, 48000, 1, 5000)
        final_path = os.path.join(self.tmpdir, "captura_falla.flac")

        from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
            SegmentProvider,
        )
        from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import (
            AtomicFinalizer,
        )

        class _FailingFlacEncoder(FlacEncoder):
            def write(self, block):
                if block.frame_offset > 0 or self.frames_written > 0:
                    raise RuntimeError("fallo simulado a mitad de stream")
                super().write(block)

        provider = SegmentProvider([seg_path])
        finalizer = AtomicFinalizer(
            encoder_cls=_FailingFlacEncoder, fmt=provider.fmt, final_path=final_path,
            encoder_kwargs={"total_frames_hint": provider.total_frames},
        )
        result = finalizer.run(provider.iter_blocks(block_frames=1024),
                                total_frames_expected=provider.total_frames)
        self.assertFalse(result["ok"])
        self.assertFalse(os.path.exists(final_path))
        self.assertFalse(os.path.exists(final_path + ".partial"))


if __name__ == "__main__":
    unittest.main()
