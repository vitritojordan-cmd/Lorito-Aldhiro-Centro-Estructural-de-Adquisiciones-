"""
test_integration_capture_segment_export_archive.py — GAP-055, FASE 9
("Integration tests", §19, Suite B) de la Orden Maestra de
Saneamiento, Integración y Consolidación de Lorito Aldhiro.

Hasta esta sesión, `backend/export_streaming/` (FASE 1, GAP-051) y
`backend/archival/` (FASE 2, GAP-052) tenían cobertura real y sólida
cada uno POR SEPARADO, pero ningún test ejercitaba los MISMOS
segmentos de una sesión de captura a través de AMBOS subsistemas en el
mismo escenario — exactamente lo que pide §19: "Capture → Segment →
Export", "Capture → Archive → Classification", "Corruption → Abort",
"Checksum mismatch → INVALID". Este archivo cierra ese hueco.

Construye segmentos reales en disco con la misma técnica ya
establecida (GAP-036/041/051/052: WAV real vía `wave`, checksums
reales vía `compute_segment_checksum()` — la misma función que usa
`DiskWriterV2._close_segment()` en producción) y confirma que
`ExportSession` (exportación) y `classify_session()` (clasificación
patrimonial) llegan a conclusiones CONSISTENTES sobre la misma sesión:
una sesión sana exporta Y clasifica bien; una sesión con un segmento
corrupto aborta la exportación Y clasifica INVALID — nunca una cosa
sin la otra, que sería el tipo de inconsistencia que rompe la garantía
de §29 ("¿el archivo final corresponde exactamente a la fuente?").

No usa el arnés de captura real con hilos (`CaptureEngineV2.start()`)
— GAP-052 documentó una fragilidad de timing real y preexistente en
ese camino (`DiskWriterV2`/`ColaElasticaDisco`); estos tests evitan
esa fragilidad por diseño, igual que los de GAP-052, sin perder
realismo en los datos (WAV reales, checksums reales, ambos subsistemas
reales sin ningún mock).

Ejecutar: python3 -m unittest tests.test_integration_capture_segment_export_archive -v
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_session import ExportSession
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.archival import ArchivalState, classify_session
from lorito_aldhiro.backend.archival.lorito_segment_checksum import compute_segment_checksum


def _write_real_segment(path, rate=48000, channels=2, n_frames=2000, seed=1):
    """WAV PCM24 real con contenido determinista (no silencio — permite
    distinguir una exportación correcta de una corrupta comparando
    muestras, no solo conteo de frames)."""
    rng = np.random.default_rng(seed)
    audio = rng.uniform(-0.5, 0.5, size=(n_frames, channels)).astype(np.float32)
    pcm32 = (np.clip(audio, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)
    return audio


def _simulate_captured_session(tmpdir, n_segments=3, frames_per_segment=2000,
                               rate=48000, channels=2):
    """Simula lo que `DiskWriterV2` deja en disco al cerrar una sesión:
    N segmentos WAV reales + su checksum real (misma función que usa
    producción). Devuelve (segment_paths, segment_checksums,
    total_frames)."""
    paths, checksums = [], []
    for i in range(n_segments):
        p = os.path.join(tmpdir, f"seg{i:04d}.wav")
        _write_real_segment(p, rate=rate, channels=channels,
                            n_frames=frames_per_segment, seed=100 + i)
        paths.append(p)
        checksums.append(compute_segment_checksum(p))
    return paths, checksums, n_segments * frames_per_segment


class TestCaptureSegmentExportIntegration(unittest.TestCase):
    """§19: "Capture → Segment → Export"."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_integ_export_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_healthy_session_segments_export_successfully_via_export_session(self):
        paths, _checksums, total_frames = _simulate_captured_session(self.tmpdir)
        final_path = os.path.join(self.tmpdir, "export_final.wav")

        report = ExportSession(paths, encoder_cls=WavEncoder, final_path=final_path,
                               encoder_kwargs={"subtype": "PCM_24"}).run()

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.status, "SUCCESS")
        self.assertEqual(report.frames_written, total_frames)
        self.assertTrue(os.path.exists(final_path))

    def test_corrupted_segment_aborts_export_via_export_session(self):
        paths, _checksums, _total = _simulate_captured_session(self.tmpdir)
        # Corromper el header del segundo segmento (mismo patrón que
        # tests/test_segment_read_errors.py — mentir sobre el tamaño real).
        import struct
        with open(paths[1], "r+b") as f:
            f.seek(40)
            current = struct.unpack("<I", f.read(4))[0]
            f.seek(40)
            f.write(struct.pack("<I", current + 5000 * 2 * 3))

        final_path = os.path.join(self.tmpdir, "export_final.wav")
        report = ExportSession(paths, encoder_cls=WavEncoder, final_path=final_path,
                               encoder_kwargs={"subtype": "PCM_24"}).run()

        self.assertFalse(report.ok)
        self.assertEqual(report.status, "ABORTED")
        self.assertFalse(os.path.exists(final_path),
                         "P0.4: nunca debe quedar un archivo final a medio escribir")


class TestCaptureArchiveClassificationIntegration(unittest.TestCase):
    """§19: "Capture → Archive → Classification"."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_integ_archive_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_healthy_session_classifies_archival_safe(self):
        paths, checksums, total_frames = _simulate_captured_session(self.tmpdir)
        status = {"frames_dropped": 0, "recovery_count": 0, "wd_phase": "OK",
                  "frames_received": total_frames, "frames_written": total_frames}

        result = classify_session(status, segment_paths=paths,
                                  segment_checksums=checksums)

        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertTrue(result.checksum_verified)
        self.assertEqual(result.segments_valid, len(paths))


class TestCorruptionConsistencyAcrossSubsystems(unittest.TestCase):
    """§19: "Corruption → Abort" y "Checksum mismatch → INVALID" — sobre
    los MISMOS segmentos, verificando que exportación y archival NUNCA
    discrepan sobre si una sesión es válida (§29)."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_integ_consistency_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_bit_corruption_after_close_is_invalid_in_archive_and_still_exports_bytes_ok(self):
        # Caso sutil y real: un segmento se corrompe DESPUÉS de cerrado
        # (bit rot) — el tamaño/frames siguen siendo correctos (por eso
        # ExportSession, que no verifica checksum por diseño — esa es
        # la responsabilidad de Archival, no de Export — exporta sin
        # abortar), pero el CONTENIDO ya no coincide con lo capturado.
        # Archival, que SÍ verifica checksum, debe ser quien lo detecte.
        # Confirma la división de responsabilidades: Export garantiza
        # "cada frame declarado se leyó completo"; Archival garantiza
        # "el contenido no cambió desde el cierre".
        paths, checksums, total_frames = _simulate_captured_session(
            self.tmpdir, n_segments=2)
        with open(paths[0], "r+b") as f:
            f.seek(80)
            byte = f.read(1)
            f.seek(80)
            f.write(bytes([byte[0] ^ 0xFF]))

        final_path = os.path.join(self.tmpdir, "final.wav")
        export_report = ExportSession(
            paths, encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"}).run()
        self.assertTrue(export_report.ok,
                        "un bit-flip que no cambia el tamaño no debe "
                        "impedir la lectura frame-a-frame")

        status = {"frames_dropped": 0, "recovery_count": 0, "wd_phase": "OK",
                  "frames_received": total_frames, "frames_written": total_frames}
        archive_result = classify_session(status, segment_paths=paths,
                                          segment_checksums=checksums)
        self.assertEqual(archive_result.state, ArchivalState.INVALID)
        self.assertFalse(archive_result.checksum_verified)
        self.assertEqual(archive_result.segments_invalid, 1)

    def test_missing_segment_is_abort_in_export_and_invalid_in_archive(self):
        paths, checksums, total_frames = _simulate_captured_session(
            self.tmpdir, n_segments=3)
        os.remove(paths[1])

        final_path = os.path.join(self.tmpdir, "final.wav")
        export_report = ExportSession(
            paths, encoder_cls=WavEncoder, final_path=final_path,
            encoder_kwargs={"subtype": "PCM_24"}).run()
        self.assertFalse(export_report.ok)
        self.assertFalse(os.path.exists(final_path))

        status = {"frames_dropped": 0, "recovery_count": 0, "wd_phase": "OK",
                  "frames_received": total_frames, "frames_written": total_frames}
        archive_result = classify_session(status, segment_paths=paths,
                                          segment_checksums=checksums)
        self.assertEqual(archive_result.state, ArchivalState.INVALID)
        self.assertEqual(archive_result.segments_invalid, 1)


if __name__ == "__main__":
    unittest.main()
