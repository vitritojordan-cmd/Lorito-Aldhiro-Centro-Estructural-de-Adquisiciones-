"""
Reproduce el bug histórico ("nunca se podía voltear a Lado B") sobre el
motor `_CLCCEngine` integrado en esta sesión (`lorito_itl_integration.py`,
antes `aecct2_itl_integration.py`) y confirma el fix FIX-FORCED-PAUSE-
ESCAPE — ver GAP-008.

Escenario reproducido: cinta llega al tope máximo de tolerancia del Lado A
con señal todavía presente → pausa forzada. Sin el fix, cualquier ruido
breve dentro de la ventana de 1s reiniciaba `silence_timer` a 0.0 y la
conmutación a pausa ordinaria (y por lo tanto el volteo a Lado B) nunca
ocurría. Con el fix, un único tick de silencio real (~67ms) basta.

No requiere PySide6 — `_CLCCEngine` es lógica pura (el import opcional de
QTimer en el módulo se degrada a None si PySide6 no está disponible).

Ejecutar: python3 -m unittest tests.test_itl_integration -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lorito_aldhiro.frontend.integration.lorito_itl_integration import (
    _CLCCEngine, _MASTER_DT, _FORCED_PAUSE_ESCAPE_SECS,
)


class TestForcedPauseEscapeFix(unittest.TestCase):

    def _engine_at_forced_pause(self) -> _CLCCEngine:
        eng = _CLCCEngine(profile="C-60")
        eng.start_recording()
        # Avanzar el reloj hasta el tope máximo de Lado A con señal presente
        # (fuerza _activate_forced_pause()).
        eng.elapsed_time = eng.lado_a_max_tol
        eng.update_audio_sensor(-10.0)   # señal alta, no silencio
        eng.tick(dt=_MASTER_DT)
        self.assertTrue(eng.is_forced_pause, "no entró en pausa forzada")
        return eng

    def test_bug_reproduced_without_fix_intermittent_noise_never_flips(self):
        """
        Reproduce el bug histórico DESACTIVANDO el fix (monkeypatch del
        umbral a 1.0, el valor original con bug) — confirma que, con ruido
        breve intermitente que nunca deja 1s continuo de silencio real, la
        cinta se queda indefinidamente en pausa forzada sin voltear.
        """
        import lorito_aldhiro.frontend.integration.lorito_itl_integration as itl_mod
        original = itl_mod._FORCED_PAUSE_ESCAPE_SECS
        itl_mod._FORCED_PAUSE_ESCAPE_SECS = 1.0   # valor histórico con bug
        try:
            eng = self._engine_at_forced_pause()
            # 14 ticks de silencio (~933ms, < 1s) interrumpidos por un tick
            # de ruido breve justo antes de completar el segundo — patrón
            # realista de "casi silencio pero no silencio perfecto".
            for _ in range(14):
                eng.update_audio_sensor(-80.0)   # silencio
                eng.tick(dt=_MASTER_DT)
            eng.update_audio_sensor(-10.0)   # ruido breve — resetea silence_timer
            eng.tick(dt=_MASTER_DT)
            for _ in range(14):
                eng.update_audio_sensor(-80.0)
                eng.tick(dt=_MASTER_DT)
            # Nunca se acumuló 1s continuo real → nunca conmutó → sigue
            # en pausa forzada, cinta nunca volteó.
            self.assertTrue(eng.is_forced_pause)
            self.assertEqual(eng.side, "A")
        finally:
            itl_mod._FORCED_PAUSE_ESCAPE_SECS = original

    def test_fix_single_silent_tick_unblocks_flip(self):
        """Con el fix real (módulo tal como se entrega), UN solo tick de
        silencio ya conmuta la pausa forzada — y con señal de regreso,
        el volteo a Lado B ocurre de inmediato."""
        eng = self._engine_at_forced_pause()

        # Un único tick de silencio real: ya debe conmutar.
        eng.update_audio_sensor(-80.0)
        eng.tick(dt=_MASTER_DT)
        self.assertFalse(eng.is_forced_pause, "no conmutó con un solo tick silencioso")
        self.assertTrue(eng.paused_by_silence)

        # La señal regresa → debe voltear a Lado B.
        eng.update_audio_sensor(-10.0)
        eng.tick(dt=_MASTER_DT)
        self.assertEqual(eng.side, "B")
        self.assertFalse(eng.is_paused)
        self.assertEqual(eng.counter, 0)

    def test_intermittent_noise_still_flips_with_fix(self):
        """Mismo patrón de ruido intermitente que en el test del bug, pero
        con el fix real activo — cada tick de silencio real, aislado,
        ya es suficiente, así que eventualmente conmuta y voltea."""
        eng = self._engine_at_forced_pause()
        for _ in range(14):
            eng.update_audio_sensor(-80.0)
            eng.tick(dt=_MASTER_DT)
            if not eng.is_forced_pause:
                break
        self.assertFalse(eng.is_forced_pause)
        self.assertTrue(eng.paused_by_silence)
        eng.update_audio_sensor(-10.0)
        eng.tick(dt=_MASTER_DT)
        self.assertEqual(eng.side, "B")

    def test_forced_pause_escape_constant_matches_one_tick(self):
        self.assertAlmostEqual(_FORCED_PAUSE_ESCAPE_SECS, _MASTER_DT)


if __name__ == "__main__":
    unittest.main()
