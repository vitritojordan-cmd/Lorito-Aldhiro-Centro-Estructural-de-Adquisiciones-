"""
test_lorito_errors.py — GAP-051, FASE 1 ("Contratos + errores") de la
Orden Maestra de Saneamiento, Integración y Consolidación de Lorito
Aldhiro.

Cubre `backend/errors/` en aislamiento (sin necesitar PySide6/audio):
la raíz `LoritoError` y sus 7 categorías (§15), la familia
`ExportError` con sus campos estructurados (§11), y `DSPIntegrityError`
(§16, sin conectar todavía — solo se prueba la clase en sí). También
confirma, contra las clases REALES ya retroadaptadas (no una copia),
que las 5 excepciones ad-hoc preexistentes (`FormatMismatchError`,
`ExportAbortError`, `SegmentReadError`, `InvalidTransitionError`,
`MuscleEqError`) ahora heredan de esta taxonomía sin haber cambiado su
comportamiento externo.
"""

import unittest

from lorito_aldhiro.backend.errors import (
    LoritoError, RecoverableError, DegradedError, FatalError,
    IntegrityError, CorruptionError, LoritoEnvironmentError, UserAbortError,
    ExportError, FormatMismatchError, ExportAbortError, SegmentReadError,
    SegmentIntegrityError, FrameAccountingError, ChecksumMismatchError,
    ExportFinalizeError, DSPIntegrityError,
)


class TestLoritoErrorBase(unittest.TestCase):
    def test_is_a_runtime_error(self):
        # Decisión de diseño explícita (§15, ver docstring del módulo):
        # preserva cualquier `except RuntimeError` legado.
        self.assertTrue(issubclass(LoritoError, RuntimeError))

    def test_message_preserved_verbatim(self):
        e = LoritoError("mensaje exacto")
        self.assertEqual(str(e), "mensaje exacto")

    def test_default_recoverable_is_false(self):
        e = LoritoError("x")
        self.assertFalse(e.recoverable)
        self.assertIsNone(e.cause)

    def test_cause_sets_dunder_cause(self):
        orig = ValueError("original")
        e = LoritoError("envuelto", cause=orig)
        self.assertIs(e.cause, orig)
        self.assertIs(e.__cause__, orig)

    def test_cause_does_not_override_explicit_raise_from(self):
        orig = ValueError("original")
        other = KeyError("explicito")
        try:
            raise LoritoError("x", cause=orig) from other
        except LoritoError as e:
            # `raise ... from other` ya fija __cause__ antes de que el
            # __init__ corra — no debe pisarse con `cause=orig`.
            self.assertIs(e.__cause__, other)
            self.assertIs(e.cause, orig)  # el atributo propio sí es el pasado


class TestPolicyCategories(unittest.TestCase):
    """§15 — las 7 categorías son hermanas directas de LoritoError."""

    def test_all_seven_are_lorito_error_subclasses(self):
        for cls in (RecoverableError, DegradedError, FatalError,
                    IntegrityError, CorruptionError, LoritoEnvironmentError,
                    UserAbortError):
            with self.subTest(cls=cls):
                self.assertTrue(issubclass(cls, LoritoError))

    def test_recoverable_error_is_recoverable(self):
        self.assertTrue(RecoverableError("x").recoverable)

    def test_other_categories_default_not_recoverable(self):
        for cls in (DegradedError, FatalError, IntegrityError,
                    CorruptionError, LoritoEnvironmentError, UserAbortError):
            with self.subTest(cls=cls):
                self.assertFalse(cls("x").recoverable)

    def test_environment_error_renamed_does_not_shadow_builtin(self):
        # La propia clase se llama `LoritoEnvironmentError`, no
        # `EnvironmentError` — confirma que el builtin de Python sigue
        # siendo el builtin.
        self.assertIs(EnvironmentError, OSError)
        self.assertIsNot(LoritoEnvironmentError, EnvironmentError)


class TestExportErrorFamily(unittest.TestCase):
    """§11 — campos estructurados obligatorios, siempre presentes."""

    def test_export_error_is_lorito_error_not_a_policy_category(self):
        self.assertTrue(issubclass(ExportError, LoritoError))
        # Decisión documentada: NO hereda también de IntegrityError/etc.
        self.assertFalse(issubclass(ExportError, IntegrityError))

    def test_all_fields_present_with_defaults(self):
        e = ExportError("x")
        for attr in ("segment_id", "frame_start", "frame_count", "path"):
            self.assertTrue(hasattr(e, attr))
            self.assertIsNone(getattr(e, attr))
        self.assertIsNone(e.cause)
        self.assertFalse(e.recoverable)

    def test_fields_populated_when_provided(self):
        e = SegmentReadError("segmento truncado: /a/seg.wav",
                              segment_id="/a/seg.wav", path="/a/seg.wav",
                              frame_start=500, frame_count=1000)
        self.assertEqual(e.segment_id, "/a/seg.wav")
        self.assertEqual(e.path, "/a/seg.wav")
        self.assertEqual(e.frame_start, 500)
        self.assertEqual(e.frame_count, 1000)

    def test_six_leaf_classes_are_export_error_subclasses(self):
        for cls in (FormatMismatchError, ExportAbortError, SegmentReadError,
                    SegmentIntegrityError, FrameAccountingError,
                    ChecksumMismatchError, ExportFinalizeError):
            with self.subTest(cls=cls):
                self.assertTrue(issubclass(cls, ExportError))
                self.assertTrue(issubclass(cls, RuntimeError))


class TestDspIntegrityError(unittest.TestCase):
    def test_is_integrity_error_subclass(self):
        self.assertTrue(issubclass(DSPIntegrityError, IntegrityError))

    def test_stage_field(self):
        e = DSPIntegrityError("NaN detectado", stage="muscle_eq")
        self.assertEqual(e.stage, "muscle_eq")


class TestPreexistingExceptionsRetrofitted(unittest.TestCase):
    """Confirma, importando las clases REALES de sus módulos
    originales (no una copia aquí), que la retroadaptación no cambió
    ni el nombre ni la ascendencia RuntimeError ni el import surface."""

    def test_format_mismatch_and_export_abort_from_export_blocks(self):
        from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import (
            FormatMismatchError as FME, ExportAbortError as EAE,
        )
        self.assertIs(FME, FormatMismatchError)
        self.assertIs(EAE, ExportAbortError)

    def test_segment_read_error_from_segment_provider(self):
        from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
            SegmentReadError as SRE,
        )
        self.assertIs(SRE, SegmentReadError)

    def test_invalid_transition_error_from_transport_machine(self):
        from lorito_aldhiro.backend.transport.lorito_transport_machine import (
            InvalidTransitionError,
        )
        self.assertTrue(issubclass(InvalidTransitionError, LoritoError))
        self.assertTrue(issubclass(InvalidTransitionError, RuntimeError))
        # Un solo string, exactamente como antes de GAP-051.
        e = InvalidTransitionError("comando desconocido: FOO")
        self.assertEqual(str(e), "comando desconocido: FOO")

    def test_muscle_eq_error_from_dsp_module_keeps_code_message_contract(self):
        from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import (
            MuscleEqError,
        )
        self.assertTrue(issubclass(MuscleEqError, LoritoError))
        e = MuscleEqError("MUSCLE_EQ_INVALID_FREQUENCY", "frecuencia fuera de rango: -5")
        self.assertEqual(e.code, "MUSCLE_EQ_INVALID_FREQUENCY")
        self.assertEqual(str(e), "MUSCLE_EQ_INVALID_FREQUENCY: frecuencia fuera de rango: -5")


if __name__ == "__main__":
    unittest.main()
