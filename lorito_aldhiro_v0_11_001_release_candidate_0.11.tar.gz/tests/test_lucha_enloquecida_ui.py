"""
test_lucha_enloquecida_ui.py -- GAP-042, integración de UI de "Lucha
Enloquecida (PREVI)": submenú OPTAPE con 20 sub-perfiles, leyenda
compartida "PREVI DSP".
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
from lorito_aldhiro.backend.dsp.lucha_enloquecida import LUCHA_PROFILE_ORDER  # noqa: E402


class TestLuchaMenuToggle(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_selecting_a_profile_activates_it(self):
        self.app._on_lucha_menu("M")
        self.assertEqual(self.app._nr_coordinator._lucha_enloquecida.mode, "M")
        self.assertTrue(self.app.clock._previ_dsp_active)

    def test_selecting_same_profile_twice_toggles_off(self):
        self.app._on_lucha_menu("Q")
        self.app._on_lucha_menu("Q")
        self.assertIsNone(self.app._nr_coordinator._lucha_enloquecida)
        self.assertFalse(self.app.clock._previ_dsp_active)

    def test_switching_profile_directly_without_bypass(self):
        self.app._on_lucha_menu("A")
        self.app._on_lucha_menu("T")
        self.assertEqual(self.app._nr_coordinator._lucha_enloquecida.mode, "T")

    def test_all_20_profiles_selectable_via_menu_handler(self):
        for code, _, _, _ in LUCHA_PROFILE_ORDER:
            self.app._on_lucha_menu(code)
            self.assertEqual(self.app._nr_coordinator._lucha_enloquecida.mode, code)
            self.app._on_lucha_menu(code)

    def test_previ_legend_shared_with_cristhi_cosh(self):
        self.app._on_cristhi_cosh_toggle()
        self.app._on_lucha_menu("A")
        self.app._on_lucha_menu("A")
        self.assertTrue(self.app.clock._previ_dsp_active,
                        "Cristhi Cosh sigue activo, la leyenda no debe apagarse")

    def test_previ_legend_shared_with_antipestal(self):
        self.app._on_antipestal_menu("KARI")
        self.app._on_lucha_menu("B")
        self.app._on_lucha_menu("B")
        self.assertTrue(self.app.clock._previ_dsp_active,
                        "Antipestal sigue activo, la leyenda no debe apagarse")


if __name__ == "__main__":
    unittest.main()
