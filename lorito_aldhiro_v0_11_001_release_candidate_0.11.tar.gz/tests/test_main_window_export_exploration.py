"""
test_main_window_export_exploration.py — GAP-036, exploración del
hallazgo de GAP-034: ¿hasta dónde es realmente testeable
`lorito_main_window.py` bajo los stubs de PySide6 ya existentes
(`tests/test_stability_patch.py`)?

Confirma que `LoritoAldhiroStudio()` se puede INSTANCIAR completa bajo
los stubs, y que `_build_export_array()` (el método RAM-unbounded que
motivó la Fase 1 desde el principio) se puede ejercitar con datos
reales instalando un stub funcional de `soundfile` (lectura+escritura
reales vía `wave`, no el dummy de `_install_stub_modules`) ANTES de
importar el módulo.

Esto NO es la integración real de Fase 1 (seguir usando
`_build_export_array` en vez de `SegmentProvider`/`ExportSession`) —
es la prueba de que existe un camino para, en una sesión futura,
verificar esa integración con ejecución real en vez de solo lectura
de código. Como primer paso concreto en esa dirección, se compara el
resultado de `_build_export_array` contra `SegmentProvider` streaming
para el mismo conjunto de segmentos — mismo criterio de verificación
usado en toda esta cadena de sesiones (comparar contra el camino real,
nunca solo contra uno mismo).
"""

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from tests._functional_soundfile_stub import (
    install_functional_soundfile_stub, FunctionalSoundFile,
)

install_functional_soundfile_stub()

from tests.test_stability_patch import _install_stub_modules  # noqa: E402
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
from lorito_aldhiro.backend.export_streaming import SegmentProvider  # noqa: E402

# GAP-046 — desde la modularización de main_window.py en mixins,
# `_build_export_array` vive en su propio módulo
# (`lorito_aldhiro.frontend.main_window.lorito_mw_export`), con su
# propia importación INDEPENDIENTE de `soundfile` — reinstalar
# `sys.modules['soundfile']` (como hace `install_functional_
# soundfile_stub()` arriba) no rebindea ese `sf` si el módulo ya fue
# importado por OTRO archivo de test antes que este (mismo patrón ya
# conocido de GAP-036/037: hay que mutar el atributo del módulo ya
# vinculado directamente, no reasignar `sys.modules`).
import lorito_aldhiro.frontend.main_window.lorito_mw_export as _export_mixin_mod  # noqa: E402
import soundfile as _sf_functional  # noqa: E402
_export_mixin_mod.sf = _sf_functional

# GAP-041 — mismo fix que test_capture_engine_end_to_end.py/
# test_close_protection.py: garantizar el stub funcional de soundfile
# en este archivo sin depender del orden de import entre archivos de
# test (reinstalar sys.modules no alcanza para un módulo ya importado).
# `_build_export_array` usa el `sf` propio de `lorito_main_window.py`
# (import soundfile as sf), no el de `lorito_capture_engine`.
mw.sf = sys.modules["soundfile"]


class TestMainWindowInstantiation(unittest.TestCase):
    def test_lorito_aldhiro_studio_instantiates_under_stubs(self):
        app = mw.LoritoAldhiroStudio()
        self.assertIsNotNone(app)


class TestBuildExportArrayVsStreaming(unittest.TestCase):
    """Compara `_build_export_array` (legado, RAM-unbounded) contra
    `SegmentProvider` (streaming) para el MISMO conjunto de segmentos
    — deben producir exactamente el mismo audio concatenado."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_export_explore_")
        self.rate = 48000
        self.channels = 2

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _make_segments(self, seed, n_frames_list):
        rng = np.random.default_rng(seed)
        paths = []
        for i, n in enumerate(n_frames_list):
            audio = (rng.uniform(-0.3, 0.3, size=(n, self.channels))).astype(np.float32)
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            with FunctionalSoundFile(p, mode="w", samplerate=self.rate,
                                     channels=self.channels) as f:
                f.write(audio)
            paths.append(p)
        return paths

    def test_build_export_array_matches_segment_provider_streaming(self):
        seg_paths = self._make_segments(seed=1, n_frames_list=[3000, 5000, 2000])

        app = mw.LoritoAldhiroStudio()
        # `_build_export_array` lee `self._engine._disk_writer.
        # get_segment_paths()` — se apunta directamente sin necesitar
        # una captura real en curso.
        app._engine._disk_writer._segment_paths = seg_paths

        legacy_audio, legacy_rate = app._build_export_array(seg_paths[0])
        self.assertIsNotNone(legacy_audio)
        self.assertEqual(legacy_rate, self.rate)

        provider = SegmentProvider(seg_paths)
        streaming_blocks = list(provider.iter_blocks(block_frames=4096))
        streaming_audio = np.concatenate([b.data for b in streaming_blocks], axis=0)

        self.assertEqual(legacy_audio.shape, streaming_audio.shape)
        np.testing.assert_array_equal(legacy_audio, streaming_audio)

    def test_build_export_array_returns_none_when_no_segments(self):
        app = mw.LoritoAldhiroStudio()
        app._engine._disk_writer._segment_paths = []
        result_audio, result_rate = app._build_export_array(
            os.path.join(self.tmpdir, "no_existe.wav"))
        self.assertIsNone(result_audio)
        self.assertEqual(result_rate, 0)


if __name__ == "__main__":
    unittest.main()
