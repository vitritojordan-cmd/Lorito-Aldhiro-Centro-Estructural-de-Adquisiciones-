"""
tests/test_module_decomposition_regression.py — test de regresión que
NO existía en Lorito Aldhiro (pedido explícito del usuario, §GAP-012):
recorre TODOS los módulos del árbol `lorito_aldhiro/` (backend +
frontend + widgets) — el resultado de la descomposición del monolito
original (`aecct2_v22_55.py`) en la modularización actual — e intenta
importar cada uno, para detectar errores de traceback que solo
aparecen al construir la aplicación real desde `lorito_bootstrap.py`
(imports circulares, nombres no importados, dependencias externas
faltantes tras la modularización).

Esta clase de bug ya apareció varias veces en sesiones anteriores sin
que hubiera un test que las detectara automáticamente:
  · `font_leyendas` usado en `lorito_indicators.py` sin importar (GAP-010).
  · `aecct2_itl_integration` — módulo externo nunca incluido (GAP-008,
    ya resuelto: internalizado como `lorito_itl_integration.py`).
  · `aecct2_stability_patch` — mismo patrón (GAP-009, ya resuelto).
  · `aecct2_crac_motor_v4` — mismo patrón, encontrado por ESTE test,
    **todavía sin resolver** (ver `KNOWN_BLOCKING_IMPORTS` abajo).

No importa literalmente `lorito_bootstrap.py` (arrancaría una
`QApplication` real) — en su lugar recorre el árbol de paquetes con
`pkgutil` e importa cada submódulo individualmente, con los mismos
stubs mínimos de PySide6/sounddevice/soundfile que el resto de la
batería de tests usa para poder ejercitar el código real.

Ejecutar: python3 -m unittest tests.test_module_decomposition_regression -v
"""

import importlib
import os
import pkgutil
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules

import lorito_aldhiro


# Dependencias externas conocidas, faltantes en este tarball, que hacen
# fallar el import de un módulo concreto por una razón YA DIAGNOSTICADA
# (no un regresión nueva). Mapeo módulo → substring esperado del error.
# Si algún día se resuelve (como ya pasó con el ITL bridge y el
# stability patch), este test empezará a fallar de forma "positiva"
# (el módulo importa bien) — hay que quitar la entrada de este dict en
# ese momento, no ignorarlo.
# Dependencias externas conocidas, faltantes en este tarball, que hacen
# fallar el import de un módulo concreto por una razón YA DIAGNOSTICADA
# (no un regresión nueva). Mapeo módulo → substring esperado del error.
# Si algún día se resuelve (como ya pasó con el ITL bridge, el stability
# patch, y — en esta misma sesión — el motor CRAC v4), este test empieza
# a fallar de forma "positiva" (el módulo importa bien) y hay que quitar
# la entrada de este dict, no ignorarlo. Vacío por ahora: sin bloqueos
# conocidos (§GAP-013 — `aecct2_crac_motor_v4` resuelto, integrado como
# `lorito_crac_motor_v4.py`).
KNOWN_BLOCKING_IMPORTS: dict[str, str] = {}


def _iter_all_lorito_modules():
    """Nombres de módulo completos de TODO el árbol `lorito_aldhiro`,
    recursivo (backend, frontend, frontend.widgets, export_streaming,
    transport, nr, ...)."""
    names = []
    for finder, name, is_pkg in pkgutil.walk_packages(
        lorito_aldhiro.__path__, prefix="lorito_aldhiro."
    ):
        names.append(name)
    return sorted(names)


class TestModuleDecompositionRegression(unittest.TestCase):
    """Recorre el árbol modularizado completo — sin PySide6/sounddevice/
    soundfile reales (stubs instalados), para poder ejercitar el import
    real de cada módulo en este sandbox."""

    @classmethod
    def setUpClass(cls):
        _install_stub_modules()
        cls.all_modules = _iter_all_lorito_modules()

    def test_at_least_one_module_discovered(self):
        # Guarda contra un pkgutil mal configurado que no encuentre nada
        # y haga que el resto de este test pase "por accidente" sin
        # haber probado un solo módulo real.
        self.assertGreater(len(self.all_modules), 15,
                           "pkgutil no encontró el árbol de módulos esperado")

    def test_every_module_imports_without_unexpected_traceback(self):
        unexpected_failures = {}
        known_failures_confirmed = set()
        newly_fixed = []

        for name in self.all_modules:
            try:
                importlib.import_module(name)
            except Exception as e:
                if name in KNOWN_BLOCKING_IMPORTS:
                    expected_substr = KNOWN_BLOCKING_IMPORTS[name]
                    if expected_substr in str(e):
                        known_failures_confirmed.add(name)
                        continue
                    # Falló, pero por una razón DISTINTA a la ya
                    # diagnosticada — eso SÍ es una regresión nueva.
                    unexpected_failures[name] = f"{type(e).__name__}: {e}"
                else:
                    unexpected_failures[name] = f"{type(e).__name__}: {e}"
            else:
                if name in KNOWN_BLOCKING_IMPORTS:
                    # El módulo que se sabía roto ahora importa bien —
                    # buena noticia, pero hay que actualizar
                    # KNOWN_BLOCKING_IMPORTS en vez de dejarlo así.
                    newly_fixed.append(name)

        if newly_fixed:
            self.fail(
                "Módulo(s) que figuraban en KNOWN_BLOCKING_IMPORTS ahora "
                f"importan sin error — actualizar ese dict: {newly_fixed}")

        self.assertEqual(
            unexpected_failures, {},
            f"Regresión real de import detectada en: {unexpected_failures}")

        # Confirma que el test realmente ejercitó el caso conocido (si
        # este assert alguna vez falla junto con newly_fixed vacío,
        # significa que KNOWN_BLOCKING_IMPORTS quedó desactualizado de
        # otra forma — p. ej. el módulo fue renombrado).
        self.assertEqual(known_failures_confirmed, set(KNOWN_BLOCKING_IMPORTS.keys()))

    def test_lorito_main_window_imports_cleanly(self):
        """Antes de GAP-013, este mismo test documentaba que
        `LoritoAldhiroStudio` NO podía construirse por el import roto de
        `aecct2_crac_motor_v4`. Con el motor integrado
        (`lorito_crac_motor_v4.py`), el módulo debe importar limpio — si
        esto vuelve a romperse, es una regresión real que hay que
        investigar, no un bloqueo conocido a documentar y saltar."""
        mod = importlib.import_module("lorito_aldhiro.frontend.lorito_main_window")
        self.assertTrue(hasattr(mod, "LoritoAldhiroStudio"))

    def test_lorito_aldhiro_studio_constructs_completely(self):
        """§GAP-017: desde que los stubs de Qt ganaron estado real
        (QComboBox/QLineEdit/QLabel) y una metaclase que resuelve
        cualquier constante de clase no listada (QSizePolicy.Fixed,
        QToolButton.InstantPopup, etc.), `LoritoAldhiroStudio()`
        construye de punta a punta sin excepción — primera vez en el
        historial de este proyecto que esto se pudo verificar. NO
        confirma apariencia visual (los stubs no dibujan nada real),
        solo que la construcción no lanza."""
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        w = LoritoAldhiroStudio()
        self.assertIsInstance(w, LoritoAldhiroStudio)

    def test_backend_only_modules_all_import_cleanly(self):
        """Los módulos puramente backend (sin depender de widgets Qt con
        el bloqueador conocido) deben importar SIEMPRE limpios — este es
        el subconjunto que de verdad no tiene excusa para fallar."""
        backend_modules = [n for n in self.all_modules
                           if n.startswith("lorito_aldhiro.backend.")]
        self.assertGreater(len(backend_modules), 10)
        failures = {}
        for name in backend_modules:
            try:
                importlib.import_module(name)
            except Exception as e:
                failures[name] = f"{type(e).__name__}: {e}"
        self.assertEqual(failures, {})

    def test_lorito_bootstrap_module_level_code_runs_without_traceback(self):
        """GAP-053 — hueco de cobertura real, encontrado por el usuario
        ejecutando el tarball en su propia máquina: `lorito_bootstrap.py`
        vive en la RAÍZ del tarball, fuera del árbol `lorito_aldhiro/`
        — `pkgutil.walk_packages(lorito_aldhiro.__path__, ...)`
        (`_iter_all_lorito_modules()` arriba) nunca lo alcanza, así que
        ninguno de los tests de esta clase lo ejercitaba jamás, pese a
        que este archivo existe específicamente para esta clase de bug
        (ver docstring del módulo). Resultado real: 7 imports de
        `lorito_bootstrap.py` quedaron con la ruta PLANA anterior a la
        arborización (`lorito_aldhiro.backend.lorito_app_logging` en vez
        de `lorito_aldhiro.backend.core.lorito_app_logging`, y 6 más
        igual) — rotos desde la arborización, nunca detectados,
        `ModuleNotFoundError` inmediato al arrancar la app real.

        Este test cierra el hueco: ejecuta el código A NIVEL DE MÓDULO
        de `lorito_bootstrap.py` (los imports + `_patch_backend_status()`
        + el try/except del stability patch) vía `runpy.run_path(...,
        run_name="__not_main__")` — deliberadamente NO `"__main__"`, para
        que el bloque `if __name__ == "__main__":` (que sí arrancaría una
        `QApplication` real) nunca se ejecute. Es exactamente lo que el
        docstring del módulo decía que se evitaba, pero cubriendo ahora
        la parte que SÍ es segura y determinista de ejecutar bajo stubs."""
        import runpy
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        bootstrap_path = os.path.join(root, "lorito_bootstrap.py")
        self.assertTrue(os.path.exists(bootstrap_path),
                        "lorito_bootstrap.py no está donde se esperaba")
        try:
            runpy.run_path(bootstrap_path, run_name="__not_main__")
        except Exception as e:
            self.fail(f"lorito_bootstrap.py falló al importar: "
                     f"{type(e).__name__}: {e}")

    def test_status_global_is_imported_everywhere_it_is_used(self):
        """GAP-056 — hueco de cobertura real, encontrado mientras se
        verificaba de punta a punta (no solo en aislamiento) la
        extracción de FASE 7: 4 archivos (`lorito_mw_export.py`,
        `lorito_mw_recording.py`, `lorito_mw_silence_autopause.py`,
        `lorito_mw_telemetry.py`, 112 usos en total) usaban `_status.X`
        (el `BackendStatus` global de `backend/audio/lorito_audio_
        backend.py`) como nombre libre sin haberlo importado NUNCA —
        `NameError` garantizado en tiempo de ejecución real, en rutas
        tan centrales como el flujo de exportación y el cierre de
        grabación. Ningún test lo detectó porque ninguno ejercitaba esas
        rutas con ejecución real hasta ahora (los tests de `_build_
        export_array` no llegan tan lejos en `_do_export()`), y el
        `NameError` caía dentro de un `try/except Exception` amplio que
        lo atrapaba en silencio.

        Comprobación ESTÁTICA acotada específicamente a `_status` (no un
        detector genérico de nombres libres — un intento inicial de
        generalizar esto a cualquier nombre con guion bajo dio decenas
        de falsos positivos con variables locales legítimas, que
        requeriría análisis de ámbito real vía `ast` para distinguir
        correctamente; se deja como posible trabajo futuro, no forzado
        aquí). Recorre `lorito_aldhiro/` en busca de `_status.` usado
        como referencia libre (no `self._status`, no `engine._status` —
        esos SÍ son válidos, son atributos de instancia distintos del
        global) sin una línea de import real del `_status` global en el
        mismo archivo."""
        import re

        free_status_re = re.compile(r'(?<![.\w])_status\.')
        import_re = re.compile(
            r'^\s*from\s+\S+\s+import\s+.*\b_status\b|^\s*_status\s*=',
            re.MULTILINE)

        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        lorito_root = os.path.join(root, "lorito_aldhiro")
        failures = {}

        for dirpath, _dirs, files in os.walk(lorito_root):
            for fname in files:
                if not fname.endswith(".py"):
                    continue
                path = os.path.join(dirpath, fname)
                with open(path, encoding="utf-8") as fh:
                    content = fh.read()
                n_uses = len(free_status_re.findall(content))
                if n_uses and not import_re.search(content):
                    failures[os.path.relpath(path, root)] = n_uses

        self.assertEqual(
            failures, {},
            "Archivo(s) que usan '_status.X' sin importar el global "
            f"'_status' de backend.audio.lorito_audio_backend: {failures}")


if __name__ == "__main__":
    unittest.main()
