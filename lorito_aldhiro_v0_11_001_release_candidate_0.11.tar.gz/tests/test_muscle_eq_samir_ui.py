"""
test_muscle_eq_samir_ui.py -- GAP-043, integración de UI de "MUSCLE EQ
SAMIR (VITRITO)": menú OPTAPE, panel de bandas/presets, HECHO/
RESTABLECER, leyenda "MUSC EQ" (parpadeo simple y alternancia con
"DOLBY S").
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
from lorito_aldhiro.frontend.widgets.lorito_indicators import DigitalClock  # noqa: E402


class TestMuscleEqToggleAndPanel(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_activation_creates_engine_with_preset(self):
        self.app._nr_coordinator.set_muscle_eq_active(True, preset_id="ROCK")
        self.assertTrue(self.app._nr_coordinator.muscle_eq_active)
        self.assertEqual(self.app._nr_coordinator._muscle_eq.preset_id, "ROCK")

    def test_panel_opens_and_closes_without_error(self):
        self.app._open_muscle_eq_panel()
        self.assertIsNotNone(self.app._nr_coordinator._muscle_eq)

    def test_panel_does_not_reset_state_on_open(self):
        self.app._nr_coordinator.set_muscle_eq_active(True, preset_id="VOCAL")
        self.app._open_muscle_eq_panel()
        self.assertEqual(self.app._nr_coordinator._muscle_eq.preset_id, "VOCAL")
        self.assertTrue(self.app._nr_coordinator.muscle_eq_active)

    def test_restablecer_deactivates_and_returns_to_flat(self):
        self.app._nr_coordinator.set_muscle_eq_active(True, preset_id="ROCK")
        self.app.clock.set_muscle_eq_active(True)
        self.app._on_muscle_eq_reset()
        self.assertFalse(self.app._nr_coordinator.muscle_eq_active)
        self.assertEqual(self.app._nr_coordinator._muscle_eq.preset_id, "FLAT")
        self.assertFalse(self.app.clock._muscle_eq_active)


class TestMuscleEqLegend(unittest.TestCase):
    def test_blinks_alone_when_dolby_s_inactive(self):
        clock = DigitalClock()
        clock.set_muscle_eq_active(True)
        states = []
        for _ in range(4):
            clock.tick_muscle_eq_alternation()
            states.append(clock._muscle_eq_alt_on)
        self.assertTrue(any(s != states[0] for s in states[1:]))

    def test_alternates_with_dolby_s_when_both_active(self):
        clock = DigitalClock()
        clock.set_cell_lit("DOLBY_S", True)
        clock.set_muscle_eq_active(True)
        initial = clock._muscle_eq_alt_on
        clock.tick_muscle_eq_alternation()
        self.assertEqual(clock._muscle_eq_alt_on, initial)
        clock.tick_muscle_eq_alternation()
        self.assertNotEqual(clock._muscle_eq_alt_on, initial)

    def test_deactivating_resets_alternation_state(self):
        clock = DigitalClock()
        clock.set_muscle_eq_active(True)
        clock.tick_muscle_eq_alternation()
        clock.tick_muscle_eq_alternation()
        clock.set_muscle_eq_active(False)
        self.assertTrue(clock._muscle_eq_alt_on)
        self.assertEqual(clock._muscle_eq_alt_tick_count, 0)


if __name__ == "__main__":
    unittest.main()
