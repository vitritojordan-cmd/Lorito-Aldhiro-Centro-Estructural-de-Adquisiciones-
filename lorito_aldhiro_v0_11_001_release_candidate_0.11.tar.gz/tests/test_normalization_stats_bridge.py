"""
test_normalization_stats_bridge.py — GAP-066 (cierre de FASE 3, hueco
(c): puente `ExportSessionReport` ↔ `_status.normalization_*`).

Verifica, con ejecución real (no solo lectura de código):
  1. `export_resolved_mode_with_stats()` produce el MISMO resultado de
     exportación que `export_resolved_mode()` (mismo `frames_in`/
     `frames_out`/`sha256`) para varios modos, incluido ADAPTIVE_BLOCK
     — el bridge no cambia el comportamiento de exportación, solo
     añade el dict de diagnósticos.
  2. El dict de diagnósticos tiene la MISMA ganancia/peak que el
     camino legado (`_apply_normalization_advanced`) aplicado al
     mismo audio, para los modos donde la comparación es directa.
  3. `export_mid_side_with_stats()` — mismo criterio, + diagnósticos
     MID_SIDE razonables (mid_rms/side_rms/stereo_balance_index).
  4. `apply_normalization_stats_to_status()` copia todas las claves
     esperadas a un objeto `_status`-like, con los defaults correctos
     para claves ausentes del dict de origen (igual que el bloque
     real de `lorito_mw_export.py`).
  5. `USE_STREAMING_EXPORT` existe y es `False` por defecto (no
     cableada a producción todavía — ver docstring del módulo).

Ejecutar:  python3 -m unittest tests.test_normalization_stats_bridge -v
(desde la raíz del proyecto, con `lorito_aldhiro` en el PYTHONPATH).
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_normalization_streaming import (
    export_resolved_mode, resolve_auto_mode,
)
from lorito_aldhiro.backend.export_streaming.lorito_normalization_stats_bridge import (
    USE_STREAMING_EXPORT,
    export_resolved_mode_with_stats, export_mid_side_with_stats,
    apply_normalization_stats_to_status,
)
from lorito_aldhiro.backend.export.lorito_normalization import (
    _apply_normalization_advanced, NormalizationMode, _norm_linear_to_db,
)


def _write_float_wav_pcm24(path, rate, channels, audio_f32):
    clipped = np.clip(audio_f32, -1.0, 1.0)
    pcm32 = (clipped * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)


class _StatsBridgeTestBase(unittest.TestCase):
    rate = 48000

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_norm_bridge_test_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            try:
                os.remove(os.path.join(self.tmpdir, f))
            except OSError:
                pass
        os.rmdir(self.tmpdir)

    def _make_segment(self, seed=1, n_frames=48000 * 4, amplitude=0.3, channels=2):
        rng = np.random.default_rng(seed)
        t = np.arange(n_frames) / self.rate
        tone = (amplitude * np.sin(2 * np.pi * 220.0 * t)).astype(np.float32)
        noise = (amplitude * 0.05 * rng.standard_normal(n_frames)).astype(np.float32)
        mono = np.clip(tone + noise, -1.0, 1.0)
        audio = np.tile(mono.reshape(-1, 1), (1, channels)).astype(np.float32)
        p = os.path.join(self.tmpdir, "seg0000.wav")
        _write_float_wav_pcm24(p, self.rate, channels, audio)
        return [p], audio


class TestExportResolvedModeWithStatsMatchesPlainReport(_StatsBridgeTestBase):

    def _compare(self, resolved_mode):
        seg_paths, _audio = self._make_segment(seed=hash(resolved_mode) % 1000)
        out_plain = os.path.join(self.tmpdir, f"plain_{resolved_mode}.wav")
        out_stats = os.path.join(self.tmpdir, f"stats_{resolved_mode}.wav")

        report_plain = export_resolved_mode(
            seg_paths, WavEncoder, out_plain, resolved_mode, self.rate,
            encoder_kwargs={"subtype": "PCM_24"})
        report_stats, stats = export_resolved_mode_with_stats(
            seg_paths, WavEncoder, out_stats, resolved_mode, self.rate,
            encoder_kwargs={"subtype": "PCM_24"})

        self.assertTrue(report_plain.ok, msg=report_plain.error)
        self.assertTrue(report_stats.ok, msg=report_stats.error)
        self.assertEqual(report_plain.frames_in, report_stats.frames_in)
        self.assertEqual(report_plain.frames_out, report_stats.frames_out)
        self.assertEqual(report_plain.sha256, report_stats.sha256,
                         msg="el bridge no debe cambiar el audio exportado")
        self.assertEqual(stats["mode"], resolved_mode)
        return stats

    def test_peak_simple(self):
        stats = self._compare("PEAK_SIMPLE")
        self.assertNotEqual(stats["peak_db"], float("-inf"))

    def test_preservative(self):
        self._compare("PRESERVATIVE")

    def test_rms_18(self):
        self._compare("RMS_18")

    def test_lufs_16(self):
        stats = self._compare("LUFS_16")
        self.assertNotEqual(stats["lufs"], float("-inf"))

    def test_noise_aware(self):
        stats = self._compare("NOISE_AWARE")
        self.assertNotEqual(stats["noise_floor_db"], float("-inf"))

    def test_adaptive_block(self):
        stats = self._compare("ADAPTIVE_BLOCK")
        self.assertNotEqual(stats["peak_db"], float("-inf"))
        # gain_db es la MEDIA de ganancias por bloque -- puede ser
        # positiva o negativa, pero debe ser un número finito real.
        self.assertTrue(np.isfinite(stats["gain_db"]))

    def test_auto_resolved_mode_end_to_end(self):
        """El camino real que usaría AUTO: `resolve_auto_mode()` decide
        el modo base, y ese modo se pasa tal cual — ejercita la
        integración completa, no solo un modo fijo a mano."""
        seg_paths, audio = self._make_segment(seed=99, n_frames=48000 * 6)
        resolved = resolve_auto_mode(seg_paths, self.rate, audio.shape[0])
        self._compare(resolved)


class TestDiagnosticsMatchLegacyGain(_StatsBridgeTestBase):
    """Compara la ganancia/peak del bridge streaming contra el camino
    legado (`_apply_normalization_advanced`, array completo en RAM)
    aplicado al MISMO audio -- deben coincidir, porque ambos llaman a
    las mismas fórmulas `_norm_db_to_linear`/`_norm_linear_to_db`."""

    def _legacy_stats(self, audio, mode: "NormalizationMode"):
        _out, stats = _apply_normalization_advanced(audio.copy(), mode, self.rate)
        return stats

    def test_peak_simple_gain_matches_legacy(self):
        seg_paths, audio = self._make_segment(seed=5)
        _report, stats = export_resolved_mode_with_stats(
            seg_paths, WavEncoder, os.path.join(self.tmpdir, "out.wav"),
            "PEAK_SIMPLE", self.rate, encoder_kwargs={"subtype": "PCM_24"})
        legacy = self._legacy_stats(audio, NormalizationMode.PEAK_SIMPLE)
        self.assertAlmostEqual(stats["gain_db"], legacy["gain_db"], places=1)
        self.assertAlmostEqual(stats["peak_db"], legacy["peak_db"], places=1)

    def test_rms_18_gain_matches_legacy(self):
        seg_paths, audio = self._make_segment(seed=6)
        _report, stats = export_resolved_mode_with_stats(
            seg_paths, WavEncoder, os.path.join(self.tmpdir, "out.wav"),
            "RMS_18", self.rate, encoder_kwargs={"subtype": "PCM_24"})
        legacy = self._legacy_stats(audio, NormalizationMode.RMS_18)
        self.assertAlmostEqual(stats["gain_db"], legacy["gain_db"], places=1)


class TestExportMidSideWithStats(_StatsBridgeTestBase):

    def test_mid_side_end_to_end_and_diagnostics_sane(self):
        seg_paths, audio = self._make_segment(seed=11, channels=2)
        out_path = os.path.join(self.tmpdir, "out_ms.wav")
        report, stats = export_mid_side_with_stats(
            seg_paths, WavEncoder, out_path, self.rate,
            encoder_kwargs={"subtype": "PCM_24"})

        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(stats["mode"], "MID_SIDE")
        self.assertIn("mid_rms", stats)
        self.assertIn("side_rms", stats)
        self.assertIn("stereo_balance_index", stats)
        self.assertGreaterEqual(stats["stereo_balance_index"], 0.0)
        self.assertLessEqual(stats["stereo_balance_index"], 1.0)

        with wave.open(out_path, "rb") as wf:
            self.assertEqual(wf.getnframes(), audio.shape[0])


class TestApplyNormalizationStatsToStatus(unittest.TestCase):

    class _FakeStatus:
        """Objeto mínimo con los mismos 16 atributos que
        `BackendStatus` real (`lorito_audio_backend.py`) inicializa —
        no importa el módulo real para no acoplar este test a Qt/PySide6."""
        def __init__(self):
            self.normalization_mode = "Sin normalizar"
            self.normalization_gain_db = 0.0
            self.normalization_peak_db = 0.0
            self.normalization_lufs = float("-inf")
            self.normalization_noise_floor_db = float("-inf")
            self.normalization_true_peak_db = 0.0
            self.normalization_stats = {}
            self.normalization_pre_gain_db = 0.0
            self.normalization_post_gain_db = 0.0
            self.normalization_mid_rms = float("-inf")
            self.normalization_side_rms = float("-inf")
            self.normalization_stereo_balance = 0.0
            self.normalization_crest_factor_db = float("inf")
            self.normalization_dynamic_range = 0.0
            self.normalization_histogram_density = 0.0
            self.normalization_silence_ratio = 0.0
            self.normalization_auto_mode = ""

    def test_full_stats_dict_copies_all_fields(self):
        status = self._FakeStatus()
        stats = {
            "mode": "RMS_18", "gain_db": 3.5, "peak_db": -6.2, "lufs": -18.0,
            "noise_floor_db": -50.0, "true_peak_db": -2.7,
            "mid_rms": -20.0, "side_rms": -30.0, "stereo_balance_index": 0.2,
            "crest_factor_db": 12.0, "auto_selected_mode": "RMS_18",
        }
        apply_normalization_stats_to_status(status, stats)
        self.assertEqual(status.normalization_mode, "RMS_18")
        self.assertEqual(status.normalization_gain_db, 3.5)
        self.assertEqual(status.normalization_peak_db, -6.2)
        self.assertEqual(status.normalization_lufs, -18.0)
        self.assertEqual(status.normalization_mid_rms, -20.0)
        self.assertEqual(status.normalization_side_rms, -30.0)
        self.assertEqual(status.normalization_stereo_balance, 0.2)
        self.assertEqual(status.normalization_crest_factor_db, 12.0)
        self.assertEqual(status.normalization_auto_mode, "RMS_18")
        self.assertIs(status.normalization_stats, stats)

    def test_missing_keys_fall_back_to_same_defaults_as_legacy_block(self):
        status = self._FakeStatus()
        minimal_stats = {"mode": "PEAK_SIMPLE", "gain_db": 0.0, "peak_db": -0.2,
                         "lufs": float("-inf"), "noise_floor_db": float("-inf"),
                         "true_peak_db": -0.2}
        apply_normalization_stats_to_status(status, minimal_stats)
        # Claves ausentes del dict de origen -> mismos defaults que el
        # bloque real de lorito_mw_export.py usa con .get(clave, default).
        self.assertEqual(status.normalization_pre_gain_db, 0.0)
        self.assertEqual(status.normalization_post_gain_db, 0.0)
        self.assertEqual(status.normalization_mid_rms, float("-inf"))
        self.assertEqual(status.normalization_side_rms, float("-inf"))
        self.assertEqual(status.normalization_stereo_balance, 0.0)
        self.assertEqual(status.normalization_crest_factor_db, float("inf"))
        self.assertEqual(status.normalization_dynamic_range, 0.0)
        self.assertEqual(status.normalization_histogram_density, 0.0)
        self.assertEqual(status.normalization_silence_ratio, 0.0)
        self.assertEqual(status.normalization_auto_mode, "")


class TestUseStreamingExportFlag(unittest.TestCase):

    def test_flag_exists_and_defaults_false(self):
        self.assertFalse(USE_STREAMING_EXPORT)


if __name__ == "__main__":
    unittest.main()
