"""
test_normalization_streaming.py — prueba de concepto de GAP-028 (dos
pasadas, PEAK_SIMPLE y RMS_*) frente al camino legado real
(`_apply_normalization_advanced` / `_norm_rms`, `lorito_normalization.py`)
aplicado al array completo materializado.

Ambos caminos deben producir el mismo resultado (misma ganancia, mismas
muestras de salida) — el streaming NO es una reimplementación con su
propia fórmula, es la misma matemática (`_norm_db_to_linear`/
`_norm_linear_to_db` importados directamente) ejecutada en dos pasadas
sobre disco en vez de sobre un array en RAM.
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_normalization_streaming import (
    measure_peak_streaming, measure_rms_streaming,
    compute_peak_simple_gain, compute_rms_gain,
    export_with_scalar_gain,
)
from lorito_aldhiro.backend.export.lorito_normalization import (
    _apply_normalization_advanced, NormalizationMode,
)


def _write_float_wav_pcm24(path, rate, channels, audio_f32):
    """Escribe `audio_f32` (ya en [-1,1]) como PCM_24 real, usando la
    MISMA aritmética que `WavEncoder` (simétrica, redondeada — ver
    GAP-026) para que los segmentos de entrada sean representables sin
    su propia pérdida de precisión al comparar resultados."""
    clipped = np.clip(audio_f32, -1.0, 1.0)
    pcm32 = np.clip(np.round(clipped * 8388608.0), -8388608, 8388607).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    raw = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(raw)


def _read_pcm24_as_float(path):
    with wave.open(path, "rb") as wf:
        n = wf.getnframes()
        ch = wf.getnchannels()
        raw = wf.readframes(n)
    u8 = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
    buf32 = np.zeros((u8.shape[0], 4), dtype=np.uint8)
    buf32[:, 0:3] = u8
    buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
    pcm = np.frombuffer(buf32.tobytes(), dtype="<i4").astype(np.float64)
    return (pcm / 8388608.0).astype(np.float32).reshape(n, ch)


class TestNormalizationStreamingVsLegacy(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_norm_stream_")
        self.rate = 48000
        self.channels = 2

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _make_segments(self, seed, n_segments_frames, amplitude=0.4):
        rng = np.random.default_rng(seed)
        seg_paths = []
        originals = []
        for i, n in enumerate(n_segments_frames):
            audio = (rng.uniform(-amplitude, amplitude,
                                 size=(n, self.channels))).astype(np.float32)
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_float_wav_pcm24(p, self.rate, self.channels, audio)
            seg_paths.append(p)
            originals.append(_read_pcm24_as_float(p))  # tal como quedó cuantizado
        return seg_paths, np.concatenate(originals, axis=0)

    def test_peak_simple_matches_legacy_full_array(self):
        seg_paths, original_concat = self._make_segments(
            seed=1, n_segments_frames=[3000, 4000, 2500], amplitude=0.3)

        # ── Camino LEGADO: array completo + _apply_normalization_advanced ──
        legacy_out, legacy_stats = _apply_normalization_advanced(
            original_concat.copy(), NormalizationMode.PEAK_SIMPLE, self.rate)

        # ── Camino STREAMING: dos pasadas sobre disco ───────────────────────
        peak = measure_peak_streaming(seg_paths)
        gain = compute_peak_simple_gain(peak)
        out_path = os.path.join(self.tmpdir, "out_peak_simple.wav")
        report = export_with_scalar_gain(
            seg_paths, WavEncoder, out_path, gain,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)

        self.assertAlmostEqual(gain, legacy_stats["gain_db"] and
                               10 ** (legacy_stats["gain_db"] / 20.0), places=5)
        # Comparar en el dominio PCM24 (ambos ya cuantizados igual) —
        # deben coincidir bit a bit, no solo "aproximadamente".
        legacy_pcm = np.clip(np.round(
            np.clip(legacy_out, -1.0, 1.0) * 8388608.0), -8388608, 8388607)
        streaming_pcm = np.clip(np.round(
            np.clip(streaming_out, -1.0, 1.0) * 8388608.0), -8388608, 8388607)
        np.testing.assert_array_equal(streaming_pcm, legacy_pcm)

    def test_rms_matches_legacy_full_array(self):
        seg_paths, original_concat = self._make_segments(
            seed=2, n_segments_frames=[5000, 3500, 6000], amplitude=0.15)

        legacy_out, legacy_stats = _apply_normalization_advanced(
            original_concat.copy(), NormalizationMode.RMS_18, self.rate)

        rms_lin, peak_lin = measure_rms_streaming(seg_paths)
        gain = compute_rms_gain(rms_lin, peak_lin, target_rms_db=-18.0)
        out_path = os.path.join(self.tmpdir, "out_rms18.wav")
        report = export_with_scalar_gain(
            seg_paths, WavEncoder, out_path, gain,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)

        self.assertAlmostEqual(20 * np.log10(gain), legacy_stats["gain_db"], places=4)
        legacy_pcm = np.clip(np.round(
            np.clip(legacy_out, -1.0, 1.0) * 8388608.0), -8388608, 8388607)
        streaming_pcm = np.clip(np.round(
            np.clip(streaming_out, -1.0, 1.0) * 8388608.0), -8388608, 8388607)
        np.testing.assert_array_equal(streaming_pcm, legacy_pcm)

    def test_rms_gain_respects_ceiling_like_legacy(self):
        # Señal casi silenciosa con un único pico alto — fuerza el
        # camino del ceiling-check (gain limitado por el pico, no por
        # el RMS objetivo), mismo escenario que documenta _norm_rms.
        rng = np.random.default_rng(3)
        n = 8000
        audio = (rng.uniform(-0.01, 0.01, size=(n, 2))).astype(np.float32)
        audio[100, 0] = 0.9  # pico aislado
        p = os.path.join(self.tmpdir, "seg_ceiling.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)

        legacy_out, legacy_stats = _apply_normalization_advanced(
            original.copy(), NormalizationMode.RMS_18, self.rate)

        rms_lin, peak_lin = measure_rms_streaming(seg_paths)
        gain = compute_rms_gain(rms_lin, peak_lin, target_rms_db=-18.0)

        self.assertAlmostEqual(20 * np.log10(gain), legacy_stats["gain_db"], places=4)

    def test_measure_peak_matches_full_array_max(self):
        seg_paths, original_concat = self._make_segments(
            seed=4, n_segments_frames=[2000, 2000], amplitude=0.6)
        expected = float(np.max(np.abs(original_concat)))
        got = measure_peak_streaming(seg_paths)
        self.assertAlmostEqual(got, expected, places=6)

    def test_export_session_default_behavior_unchanged_without_transform(self):
        # Confirma que el nuevo parámetro `block_transform` de
        # ExportSession no altera el comportamiento existente cuando no
        # se usa (None por defecto) — no debe romper GAP-025/026.
        from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
            ExportSession,
        )
        seg_paths, original_concat = self._make_segments(
            seed=5, n_segments_frames=[1000, 1500], amplitude=0.2)
        out_path = os.path.join(self.tmpdir, "out_notransform.wav")
        session = ExportSession(seg_paths, encoder_cls=WavEncoder,
                                final_path=out_path,
                                encoder_kwargs={"subtype": "PCM_24"})
        report = session.run()
        self.assertTrue(report.ok, msg=report.error)
        result = _read_pcm24_as_float(out_path)
        np.testing.assert_array_equal(result, original_concat)


if __name__ == "__main__":
    unittest.main()
