"""
test_normalization_streaming_full.py — GAP-029, cierre completo del
frente de normalización streaming (18 modos restantes tras GAP-028).

Mismo método de verificación que `test_normalization_streaming.py`:
comparar el resultado streaming (dos pasadas sobre segmentos en disco)
contra el camino legado real (`_apply_normalization_advanced` y las
funciones `_norm_*`/v21) aplicado al array completo materializado —
NUNCA una reimplementación con su propia fórmula.
"""

import os
import sys
import tempfile
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import SegmentProvider
from lorito_aldhiro.backend.export_streaming import lorito_normalization_streaming as nstream
from lorito_aldhiro.backend.export.lorito_normalization import (
    _apply_normalization_advanced, NormalizationMode,
    _norm_lufs, _norm_true_peak, _norm_intelligent_peak,
    _norm_adaptive_block, _analyze_mid_side, _norm_mid_side,
    _apply_with_crest_guard,
)
from lorito_aldhiro.backend.export.lorito_normalization_v21 import _soft_limiter_conservative


def _write_float_wav_pcm24(path, rate, channels, audio_f32):
    clipped = np.clip(audio_f32, -1.0, 1.0)
    pcm32 = np.clip(np.round(clipped * 8388608.0), -8388608, 8388607).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    raw = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(raw)


def _read_pcm24_as_float(path):
    with wave.open(path, "rb") as wf:
        n = wf.getnframes()
        ch = wf.getnchannels()
        raw = wf.readframes(n)
    u8 = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
    buf32 = np.zeros((u8.shape[0], 4), dtype=np.uint8)
    buf32[:, 0:3] = u8
    buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
    pcm = np.frombuffer(buf32.tobytes(), dtype="<i4").astype(np.float64)
    return (pcm / 8388608.0).astype(np.float32).reshape(n, ch)


def _pcm24_domain(audio_f32):
    return np.clip(np.round(np.clip(audio_f32, -1.0, 1.0) * 8388608.0), -8388608, 8388607)


class _StreamingNormTestBase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_norm_full_")
        self.rate = 48000
        self.channels = 2

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _make_segments(self, seed, n_segments_frames, amplitude=0.3, prefix="seg"):
        rng = np.random.default_rng(seed)
        seg_paths, originals = [], []
        for i, n in enumerate(n_segments_frames):
            audio = (rng.uniform(-amplitude, amplitude,
                                 size=(n, self.channels))).astype(np.float32)
            p = os.path.join(self.tmpdir, f"{prefix}{i:04d}.wav")
            _write_float_wav_pcm24(p, self.rate, self.channels, audio)
            seg_paths.append(p)
            originals.append(_read_pcm24_as_float(p))
        return seg_paths, np.concatenate(originals, axis=0)

    def _assert_gain_matches(self, streaming_gain, legacy_stats, places=4):
        self.assertAlmostEqual(20 * np.log10(streaming_gain),
                               legacy_stats["gain_db"], places=places)

    def _assert_export_matches_legacy(self, seg_paths, legacy_audio_out, streaming_gain, tag):
        out_path = os.path.join(self.tmpdir, f"out_{tag}.wav")
        report = nstream.export_with_scalar_gain(
            seg_paths, WavEncoder, out_path, streaming_gain,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)
        np.testing.assert_array_equal(
            _pcm24_domain(streaming_out), _pcm24_domain(legacy_audio_out))


class TestPreservative(_StreamingNormTestBase):
    def test_matches_legacy(self):
        seg_paths, original = self._make_segments(seed=10, n_segments_frames=[3000, 4000])
        legacy_out, stats = _apply_normalization_advanced(
            original.copy(), NormalizationMode.PRESERVATIVE, self.rate)
        peak, _ = nstream.measure_peak_rms_streaming(seg_paths)
        gain = nstream.compute_preservative_gain(peak)
        self._assert_gain_matches(gain, stats)
        self._assert_export_matches_legacy(seg_paths, legacy_out, gain, "preservative")


class TestNoiseAware(_StreamingNormTestBase):
    def test_matches_legacy(self):
        seg_paths, original = self._make_segments(seed=11, n_segments_frames=[8000, 6000, 9000],
                                                   amplitude=0.15)
        legacy_out, stats = _apply_normalization_advanced(
            original.copy(), NormalizationMode.NOISE_AWARE, self.rate)

        block_f = max(1, int(0.100 * self.rate))
        block_rmss = sorted(nstream.measure_block_rms_streaming(seg_paths, block_f, subsample=4))
        peak, rms = nstream.measure_peak_rms_streaming(seg_paths)
        gain = nstream.compute_noise_aware_gain(rms, peak, block_rmss)

        self._assert_gain_matches(gain, stats)
        self._assert_export_matches_legacy(seg_paths, legacy_out, gain, "noise_aware")


class TestCrestGuard(_StreamingNormTestBase):
    def test_matches_legacy(self):
        seg_paths, original = self._make_segments(seed=12, n_segments_frames=[5000, 5000],
                                                   amplitude=0.5)
        legacy_out, stats = _apply_with_crest_guard(
            original.copy(), self.rate, norm_mode=NormalizationMode.RMS_18)
        peak, rms = nstream.measure_peak_rms_streaming(seg_paths)
        gain = nstream.compute_crest_guard_gain(rms, peak)
        self._assert_gain_matches(gain, stats)
        self._assert_export_matches_legacy(seg_paths, legacy_out, gain, "crest_guard")


class TestTruePeak(_StreamingNormTestBase):
    def test_matches_legacy_single_segment(self):
        # Un único segmento: sin fronteras de segmento — el caso donde
        # la nota de GAP-029 garantiza bit-exactitud total.
        seg_paths, original = self._make_segments(seed=13, n_segments_frames=[20000],
                                                   amplitude=0.4)
        legacy_out, stats = _apply_normalization_advanced(
            original.copy(), NormalizationMode.TRUE_PEAK, self.rate)
        tp = nstream.measure_true_peak_streaming(seg_paths, oversample=2)
        gain = nstream.compute_true_peak_gain(tp, ceiling_db=-1.0)
        self._assert_gain_matches(gain, stats)
        self._assert_export_matches_legacy(seg_paths, legacy_out, gain, "true_peak_single")

    def test_multi_segment_boundary_discrepancy_is_bounded(self):
        # Multi-segmento: la nota de GAP-029 predice una posible
        # pequeña discrepancia SOLO en los límites de segmento — se
        # mide aquí explícitamente en vez de asumir bit-exactitud.
        seg_paths, original = self._make_segments(seed=14, n_segments_frames=[9000, 11000, 7000],
                                                   amplitude=0.4)
        _, stats = _apply_normalization_advanced(
            original.copy(), NormalizationMode.TRUE_PEAK, self.rate)
        tp = nstream.measure_true_peak_streaming(seg_paths, oversample=2)
        gain = nstream.compute_true_peak_gain(tp, ceiling_db=-1.0)
        diff_db = abs(20 * np.log10(gain) - stats["gain_db"])
        # Acotado: la discrepancia (si existe) debe ser una fracción de
        # dB, nunca un error grande — de lo contrario indicaría un bug
        # real, no el límite de posición documentado.
        self.assertLess(diff_db, 0.5, msg=f"discrepancia inesperadamente grande: {diff_db} dB")


class TestIntelligentPeak(_StreamingNormTestBase):
    def test_gain_close_to_legacy_within_documented_tolerance(self):
        seg_paths, original = self._make_segments(seed=15, n_segments_frames=[15000, 15000],
                                                   amplitude=0.3)
        # Insertar algunos "clicks" para ejercitar el percentil de verdad
        original_mod = original.copy()
        rng = np.random.default_rng(99)
        click_idx = rng.choice(len(original_mod), size=20, replace=False)
        original_mod[click_idx, 0] = 0.95
        for p, seg in zip(seg_paths, [original_mod[:15000], original_mod[15000:]]):
            _write_float_wav_pcm24(p, self.rate, self.channels, seg)

        legacy_out, stats = _norm_intelligent_peak(original_mod.copy(), self.rate)
        eff_peak, true_peak = nstream.measure_intelligent_peak_streaming(seg_paths)
        gain = nstream.compute_intelligent_peak_gain(eff_peak)

        diff_db = abs(20 * np.log10(gain) - stats["gain_db"])
        # NO bit-exacto por diseño (ver docstring del módulo) — se
        # exige una tolerancia acotada y documentada, no igualdad.
        self.assertLess(diff_db, 0.05,
                        msg=f"aproximación de histograma fuera de tolerancia: {diff_db} dB")
        self.assertAlmostEqual(true_peak, float(np.max(np.abs(original_mod))), places=5)


class TestLufs(_StreamingNormTestBase):
    def test_matches_legacy_single_segment(self):
        seg_paths, original = self._make_segments(seed=16, n_segments_frames=[48000 * 3],
                                                   amplitude=0.2)
        legacy_out, stats = _norm_lufs(original.copy(), self.rate, target_lufs=-23.0)
        lufs, peak = nstream.measure_lufs_streaming(seg_paths, self.rate)
        gain = nstream.compute_lufs_gain(lufs, peak, target_lufs=-23.0)
        self.assertAlmostEqual(lufs, stats["lufs"], places=3)
        self._assert_gain_matches(gain, stats, places=3)
        self._assert_export_matches_legacy(seg_paths, legacy_out, gain, "lufs_single")

    def test_matches_legacy_multi_segment(self):
        # Multi-segmento: el filtro K-weighting lleva estado (zi/zf)
        # encadenado a través de límites de segmento y de bloque de
        # lectura — debe seguir siendo bit-exacto (a diferencia de
        # TRUE_PEAK, aquí NO hay reset de estado en los límites,
        # confirmado con scipy.signal.lfilter en GAP-029).
        seg_paths, original = self._make_segments(
            seed=17, n_segments_frames=[48000, 48000, 48000], amplitude=0.2)
        legacy_out, stats = _norm_lufs(original.copy(), self.rate, target_lufs=-16.0)
        lufs, peak = nstream.measure_lufs_streaming(seg_paths, self.rate)
        gain = nstream.compute_lufs_gain(lufs, peak, target_lufs=-16.0)
        self.assertAlmostEqual(lufs, stats["lufs"], places=3)
        self._assert_gain_matches(gain, stats, places=3)


class TestMidSide(_StreamingNormTestBase):
    def test_matches_legacy(self):
        seg_paths, original = self._make_segments(seed=18, n_segments_frames=[6000, 6000],
                                                   amplitude=0.3)
        legacy_out, stats = _norm_mid_side(original.copy(), self.rate)

        mid_rms, side_rms = nstream.measure_mid_side_streaming(seg_paths)
        before = _analyze_mid_side(original)
        expected_mid_rms = (10 ** (before["mid_rms"] / 20.0)
                            if before["mid_rms"] != float("-inf") else 0.0)
        # Tolerancia relativa laxa: la suma en streaming se acumula en
        # otro orden/agrupación que `np.mean` sobre el array completo
        # — reasociación de punto flotante, no un error de fórmula
        # (la fórmula en sí, mid=(L+R)/sqrt2, es idéntica).
        self.assertAlmostEqual(mid_rms, expected_mid_rms, delta=expected_mid_rms * 1e-4)

        mid_gain, side_gain = nstream.compute_mid_side_gains(mid_rms, side_rms)
        self.assertAlmostEqual(20 * np.log10(mid_gain), stats["ms_mid_gain_db"], places=3)
        self.assertAlmostEqual(20 * np.log10(side_gain), stats["ms_side_gain_db"], places=3)

        out_path = os.path.join(self.tmpdir, "out_mid_side.wav")
        report = nstream.export_with_mid_side_gain(
            seg_paths, WavEncoder, out_path, mid_gain, side_gain,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)
        # Tolerancia de 1 LSB PCM24: la ruta M/S hace más operaciones
        # en float64/float32 con orden ligeramente distinto
        # (decodificar M/S por bloque vs. sobre el array completo).
        diff = np.abs(_pcm24_domain(streaming_out) - _pcm24_domain(legacy_out))
        self.assertLessEqual(int(np.max(diff)), 1)


class TestAdaptiveBlock(_StreamingNormTestBase):
    def test_matches_legacy(self):
        seg_paths, original = self._make_segments(
            seed=19, n_segments_frames=[self.rate * 4, self.rate * 4, self.rate * 4],
            amplitude=0.25)
        legacy_out, stats = _norm_adaptive_block(
            original.copy(), self.rate, block_secs=1.0, target_rms_db=-18.0)

        block_gains, block_f = nstream.measure_adaptive_block_gains(
            seg_paths, self.rate, block_secs=1.0, target_rms_db=-18.0)

        out_path = os.path.join(self.tmpdir, "out_adaptive.wav")
        report = nstream.export_adaptive_block(
            seg_paths, WavEncoder, out_path, self.rate,
            encoder_kwargs={"subtype": "PCM_24"}, block_secs=1.0, target_rms_db=-18.0)
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)

        diff = np.abs(_pcm24_domain(streaming_out) - _pcm24_domain(legacy_out))
        # Tolerancia de 2 LSB: el crossfade se recalcula por bloque de
        # lectura streaming en vez de sobre el array completo (orden
        # de operaciones ligeramente distinto en la mezcla ponderada).
        self.assertLessEqual(int(np.max(diff)), 2,
                             msg="ADAPTIVE_BLOCK: discrepancia mayor a la tolerancia esperada")


class TestSoftLimiter(_StreamingNormTestBase):
    def test_no_overs_is_transparent(self):
        seg_paths, original = self._make_segments(seed=20, n_segments_frames=[4000, 4000],
                                                   amplitude=0.1)
        needed = nstream.measure_soft_limiter_needed(seg_paths, ceiling_db=-0.2)
        self.assertFalse(needed)

    def test_matches_legacy_with_overs(self):
        rng = np.random.default_rng(21)
        n = 20000
        audio = (rng.uniform(-0.3, 0.3, size=(n, 2))).astype(np.float32)
        # Forzar overs reales por encima del ceiling
        over_idx = rng.choice(n, size=50, replace=False)
        audio[over_idx, 0] = 0.99
        p = os.path.join(self.tmpdir, "seg_overs.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)

        legacy_out, stats = _soft_limiter_conservative(original.copy(), ceiling_db=-0.2)
        self.assertTrue(stats["triggered"])

        needed = nstream.measure_soft_limiter_needed(seg_paths, ceiling_db=-0.2)
        self.assertTrue(needed)

        transform = nstream.make_soft_limiter_transform(ceiling_db=-0.2)
        out_path = os.path.join(self.tmpdir, "out_softlimit.wav")
        report = nstream.export_with_block_transform(
            seg_paths, WavEncoder, out_path, transform,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)

        diff = np.abs(_pcm24_domain(streaming_out) - _pcm24_domain(legacy_out))
        self.assertLessEqual(int(np.max(diff)), 1)
        # Nota: el limiter NO garantiza cero overs residuales para picos
        # de 1 sola muestra (la ventana de ataque de 64 frames no
        # reacciona a tiempo por diseño) — el propio legado deja
        # `n_overs_output == n_overs_input` en este escenario
        # (confirmado con `stats`). El criterio real de corrección es
        # la equivalencia streaming/legado ya verificada arriba, no
        # "cero overs" — eso no es lo que el legado promete.
        self.assertEqual(stats["n_overs_input"], stats["n_overs_output"],
                         msg="si esto cambia, el escenario de prueba dejó de "
                             "ejercitar el caso de pico de 1 muestra")

    def test_state_carries_across_provider_blocks(self):
        # Verifica que el estado (g_prev) realmente viaja entre bloques
        # de SegmentProvider — sin esto, cada bloque reiniciaría en
        # g_prev=1.0 y el release/attack no sería continuo.
        rng = np.random.default_rng(22)
        n = 200000  # varios bloques de SegmentProvider (32768 frames c/u)
        audio = (rng.uniform(-0.2, 0.2, size=(n, 2))).astype(np.float32)
        audio[100, 0] = 0.99
        audio[150000, 1] = 0.99  # over en un bloque muy posterior
        p = os.path.join(self.tmpdir, "seg_long_overs.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)

        legacy_out, stats = _soft_limiter_conservative(original.copy(), ceiling_db=-0.2)
        transform = nstream.make_soft_limiter_transform(ceiling_db=-0.2)
        out_path = os.path.join(self.tmpdir, "out_long.wav")
        report = nstream.export_with_block_transform(
            seg_paths, WavEncoder, out_path, transform,
            encoder_kwargs={"subtype": "PCM_24"}, block_frames=32768)
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)
        diff = np.abs(_pcm24_domain(streaming_out) - _pcm24_domain(legacy_out))
        self.assertLessEqual(int(np.max(diff)), 1)


class TestAutoMode(_StreamingNormTestBase):
    def _resolve_and_check(self, seg_paths, original, tag):
        from lorito_aldhiro.backend.export.lorito_normalization import (
            _norm_auto_intelligent, NormalizationMode,
        )
        legacy_out, stats = _norm_auto_intelligent(original.copy(), self.rate)
        resolved = nstream.resolve_auto_mode(seg_paths, self.rate, len(original))
        legacy_mode_name = NormalizationMode.from_label(stats["auto_selected_mode"]).name
        self.assertEqual(resolved, legacy_mode_name,
                         msg=f"[{tag}] AUTO eligió un modo distinto al legado")
        return resolved

    def test_normal_material_resolves_to_lufs16(self):
        seg_paths, original = self._make_segments(seed=30, n_segments_frames=[48000 * 8],
                                                   amplitude=0.1)
        self._resolve_and_check(seg_paths, original, "normal")

    def test_high_rms_resolves_to_preservative(self):
        rng = np.random.default_rng(31)
        n = 48000 * 8
        audio = (rng.uniform(-0.9, 0.9, size=(n, 2))).astype(np.float32)
        p = os.path.join(self.tmpdir, "seg_loud.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)
        self._resolve_and_check(seg_paths, original, "high_rms")

    def test_dominant_silence_resolves_to_adaptive_block(self):
        rng = np.random.default_rng(32)
        n = 48000 * 8
        audio = np.zeros((n, 2), dtype=np.float32)
        # 30% del audio con señal real, resto silencio
        signal_region = rng.uniform(-0.2, 0.2, size=(int(n * 0.3), 2)).astype(np.float32)
        audio[:signal_region.shape[0]] = signal_region
        p = os.path.join(self.tmpdir, "seg_silence.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)
        self._resolve_and_check(seg_paths, original, "silence")

    def test_export_resolved_mode_end_to_end(self):
        seg_paths, original = self._make_segments(seed=33, n_segments_frames=[48000 * 8],
                                                   amplitude=0.1)
        resolved = nstream.resolve_auto_mode(seg_paths, self.rate, len(original))
        out_path = os.path.join(self.tmpdir, "out_auto.wav")
        report = nstream.export_resolved_mode(
            seg_paths, WavEncoder, out_path, resolved, self.rate,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, len(original))


class TestTapePreset(_StreamingNormTestBase):
    """Presets de cinta (v21) — `resolve_tape_preset_mode` +
    `export_tape_preset` frente a `_norm_with_tape_preset` real."""

    def _preset(self, key):
        from lorito_aldhiro.backend.playback.lorito_tape_presets import TAPE_PRESETS
        return TAPE_PRESETS[key]

    def test_type_i_ferric_decision_and_gain_match_legacy(self):
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import _norm_with_tape_preset
        preset = self._preset("TYPE_I_FERRIC")
        seg_paths, original = self._make_segments(
            seed=40, n_segments_frames=[48000 * 6], amplitude=0.08)
        legacy_out, stats = _norm_with_tape_preset(original.copy(), self.rate, preset)

        decision = nstream.resolve_tape_preset_mode(seg_paths, self.rate, preset)
        self.assertEqual(decision, stats["auto_normalization_decision"])

        out_path = os.path.join(self.tmpdir, "out_preset_ferric.wav")
        report = nstream.export_tape_preset(
            seg_paths, WavEncoder, out_path, self.rate, preset,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        streaming_out = _read_pcm24_as_float(out_path)
        diff = np.abs(_pcm24_domain(streaming_out) - _pcm24_domain(legacy_out))
        self.assertLessEqual(int(np.max(diff)), 1)

    def test_noisy_material_triggers_noise_aware_decision(self):
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import _norm_with_tape_preset
        preset = self._preset("TYPE_I_FERRIC")  # hiss_tolerance_db = -48.0
        rng = np.random.default_rng(41)
        n = self.rate * 6
        # Piso de ruido alto (por encima de la tolerancia del preset)
        # + señal ocasional — fuerza la rama noise_aware.
        noise = (rng.normal(0.0, 0.02, size=(n, 2))).astype(np.float32)
        p = os.path.join(self.tmpdir, "seg_hiss.wav")
        _write_float_wav_pcm24(p, self.rate, 2, noise)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)

        legacy_out, stats = _norm_with_tape_preset(original.copy(), self.rate, preset)
        decision = nstream.resolve_tape_preset_mode(seg_paths, self.rate, preset)
        self.assertEqual(decision, stats["auto_normalization_decision"])


class TestTwoPass(_StreamingNormTestBase):
    """TWO_PASS (v21) — última pieza del catálogo de 20 modos.
    `resolve_two_pass_mode` frente a `_two_pass_analysis` real."""

    def _check(self, seg_paths, original, tag):
        from lorito_aldhiro.backend.export.lorito_normalization_v21 import _two_pass_analysis
        legacy_out, stats = _two_pass_analysis(original.copy(), self.rate)
        resolved = nstream.resolve_two_pass_mode(seg_paths, self.rate)
        self.assertEqual(resolved, stats["two_pass_suggested_mode"],
                         msg=f"[{tag}] TWO_PASS eligió un modo distinto al legado")
        return resolved, legacy_out

    def test_normal_material_resolves_correctly(self):
        seg_paths, original = self._make_segments(seed=50, n_segments_frames=[48000 * 8],
                                                   amplitude=0.1)
        self._check(seg_paths, original, "normal")

    def test_high_p95_resolves_to_preservative(self):
        rng = np.random.default_rng(51)
        n = 48000 * 8
        audio = (rng.uniform(-0.7, 0.7, size=(n, 2))).astype(np.float32)
        p = os.path.join(self.tmpdir, "seg_loud_2p.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)
        self._check(seg_paths, original, "high_p95")

    def test_dominant_silence_resolves_to_adaptive_block(self):
        rng = np.random.default_rng(52)
        n = 48000 * 8
        audio = np.zeros((n, 2), dtype=np.float32)
        signal_region = rng.uniform(-0.2, 0.2, size=(int(n * 0.25), 2)).astype(np.float32)
        audio[:signal_region.shape[0]] = signal_region
        p = os.path.join(self.tmpdir, "seg_silence_2p.wav")
        _write_float_wav_pcm24(p, self.rate, 2, audio)
        seg_paths = [p]
        original = _read_pcm24_as_float(p)
        self._check(seg_paths, original, "silence")

    def test_export_two_pass_end_to_end(self):
        seg_paths, original = self._make_segments(seed=53, n_segments_frames=[48000 * 8],
                                                   amplitude=0.1)
        out_path = os.path.join(self.tmpdir, "out_two_pass.wav")
        report = nstream.export_two_pass(
            seg_paths, WavEncoder, out_path, self.rate,
            encoder_kwargs={"subtype": "PCM_24"})
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, len(original))


if __name__ == "__main__":
    unittest.main()
