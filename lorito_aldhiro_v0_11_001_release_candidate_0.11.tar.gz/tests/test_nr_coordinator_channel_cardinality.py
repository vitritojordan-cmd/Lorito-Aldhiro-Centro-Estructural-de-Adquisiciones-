"""
FASE 6 (§16 de la Orden) — auditoría de cardinalidad de canales,
cierre del pendiente dejado abierto desde GAP-062 ("Cardinalidad de
canales sigue sin auditar").

Toda la cadena DSP de `NRCoordinator` fue construida, desde el inicio,
tomando `channels` como parámetro explícito en cada perfil
(`Biquad`/`RmsCompander`/`VariableLowpass`/`TwoBandAdaptiveGate` en
`lorito_nr_dsp_core.py`, y cada perfil de `lorito_nr_profiles.py`,
`lorito_nr_hxpro.py`, `lorito_nr_alc.py`, `lorito_dsp_*.py`, los 20
sub-perfiles de `lucha_enloquecida/`) y cada uno maneja explícitamente
`mono = x.ndim == 1` — confirmado por lectura exhaustiva de todo
`backend/nr/` y `backend/dsp/` antes de escribir este test (`grep` de
`ndim == 1` en cada archivo con `process_chunk`/`process`). Lo que
faltaba, y es lo que exige §29 de la Orden ("EJECUCIÓN REAL, no
lectura de código"), era EJERCITAR de verdad `NRCoordinator(channels=1)`
con chunks `ndim==1` reales a través de cada etapa (y de la cadena
COMPLETA con todas activas a la vez) para confirmar que ese diseño
funciona en la práctica, no solo que el código parece correcto.

Producción SIEMPRE usa `CE_CHANNELS = 2` (`lorito_constants.py`) — no
existe ninguna ruta de captura mono hoy (ver también el docstring de
`OggEncoder` en `lorito_ffmpeg_stream_encoder.py`, que documenta la
misma constante por el mismo motivo). Este test NO cablea ninguna ruta
mono a producción — audita que la cadena DSP, tal como fue diseñada,
sería segura si channels=1 se usara alguna vez (una previsualización
mono, una herramienta de diagnóstico, o una futura ruta de captura
mono), sin que produzca crashes ni NaN/Inf.

Ejecutar: python3 -m unittest tests.test_nr_coordinator_channel_cardinality -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import numpy as np  # noqa: E402

from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator  # noqa: E402
from lorito_aldhiro.backend.nr.lorito_nr_profiles import NR_PROFILE_CLASSES  # noqa: E402
from lorito_aldhiro.backend.core.lorito_constants import CE_CHANNELS  # noqa: E402

FS = 48000


def _mono_signal(seconds=0.2, freq=440.0, amp=0.3, fs=FS, seed=0):
    """Señal mono REAL ndim==1 (no `(N, 1)`) — la forma exacta que
    tendría un chunk de un dispositivo de captura mono real."""
    rng = np.random.default_rng(seed)
    t = np.arange(int(fs * seconds)) / fs
    tone = amp * np.sin(2 * np.pi * freq * t)
    noise = 0.01 * rng.standard_normal(t.shape[0])
    return (tone + noise).astype(np.float32)


def _stereo_signal(seconds=0.2, freq=440.0, amp=0.3, fs=FS, seed=0):
    mono = _mono_signal(seconds, freq, amp, fs, seed)
    return np.tile(mono.reshape(-1, 1), (1, 2))


class TestProductionHardcodesStereo(unittest.TestCase):
    """Documenta, con una aserción real (no un comentario), que
    producción sigue fijada a estéreo — este GAP audita la cadena DSP
    para el caso channels=1, no introduce una ruta de captura mono."""

    def test_ce_channels_constant_is_two(self):
        self.assertEqual(CE_CHANNELS, 2)

    def test_nr_coordinator_default_channels_is_two(self):
        coord = NRCoordinator(sample_rate=FS)
        self.assertEqual(coord.channels, 2)


class TestMonoChunkThroughEachNRProfile(unittest.TestCase):
    """Cada uno de los 8 perfiles NR (§GAP-011) con
    `NRCoordinator(channels=1)` y un chunk mono real ndim==1."""

    def test_each_profile_survives_mono_chunk(self):
        sig = _mono_signal()
        for token in NR_PROFILE_CLASSES:
            with self.subTest(token=token):
                coord = NRCoordinator(sample_rate=FS, channels=1)
                coord.select(token)
                out = coord.process_chunk(sig)
                self.assertEqual(out.ndim, 1)
                self.assertEqual(out.shape, sig.shape)
                self.assertTrue(np.all(np.isfinite(out)))

    def test_dbx_three_types_survive_mono_chunk(self):
        sig = _mono_signal(freq=1500.0)
        for dbx_type in ("I", "II", "224"):
            with self.subTest(dbx_type=dbx_type):
                coord = NRCoordinator(sample_rate=FS, channels=1)
                coord.select("DBX", dbx_type=dbx_type)
                out = coord.process_chunk(sig)
                self.assertEqual(out.shape, sig.shape)
                self.assertTrue(np.all(np.isfinite(out)))


class TestMonoChunkThroughIndependentStages(unittest.TestCase):
    """HX Pro / ALC / MPX / Focus / EQ-BIAS — independientes del
    selector NR, cada uno con su propio manejo de `channels`."""

    def test_hx_pro_mono(self):
        coord = NRCoordinator(sample_rate=FS, channels=1)
        coord.set_hx_pro(True)
        out = coord.process_chunk(_mono_signal())
        self.assertEqual(out.ndim, 1)
        self.assertTrue(np.all(np.isfinite(out)))

    def test_alc_mono(self):
        coord = NRCoordinator(sample_rate=FS, channels=1)
        coord.set_alc(True)
        out = coord.process_chunk(_mono_signal(amp=0.02))
        self.assertEqual(out.ndim, 1)
        self.assertTrue(np.all(np.isfinite(out)))

    def test_mpx_mono(self):
        coord = NRCoordinator(sample_rate=FS, channels=1)
        coord.set_mpx(True)
        out = coord.process_chunk(_mono_signal())
        self.assertEqual(out.ndim, 1)
        self.assertTrue(np.all(np.isfinite(out)))

    def test_focus_disables_itself_and_passes_through_when_mono(self):
        """FOCUS (corrección de azimuth) es intrínsecamente estéreo —
        `_build()` ya fija `self._active = ... and self.channels >= 2`.
        Con channels=1 debe pasar la señal sin tocarla, sin crashear —
        confirmado con ejecución real, no solo leyendo `_build()`."""
        coord = NRCoordinator(sample_rate=FS, channels=1)
        coord.set_focus(True)
        sig = _mono_signal()
        out = coord.process_chunk(sig)
        self.assertEqual(out.ndim, 1)
        np.testing.assert_allclose(out, sig.astype(np.float32))

    def test_eq_bias_all_tape_types_mono(self):
        for token in ("NORMAL", "CrO2", "FeCr", "Metal"):
            with self.subTest(token=token):
                coord = NRCoordinator(sample_rate=FS, channels=1)
                coord.select_eq_bias(token)
                out = coord.process_chunk(_mono_signal())
                self.assertEqual(out.ndim, 1)
                self.assertTrue(np.all(np.isfinite(out)))


class TestMonoChunkThroughPreviAndSpecialDSP(unittest.TestCase):
    """Muscle Eq Samir, PREVI (Cristhi Cosh / Antipestal / Lucha
    Enloquecida) y Funciones Especiales (Versión O Tron) — todos
    procesan por canal internamente (`for ch in range(...)`)."""

    def test_muscle_eq_flat_mono(self):
        coord = NRCoordinator(sample_rate=FS, channels=1)
        coord.set_muscle_eq_active(True)
        out = coord.process_chunk(_mono_signal())
        self.assertEqual(out.ndim, 1)
        self.assertTrue(np.all(np.isfinite(out)))

    def test_cristhi_cosh_mono(self):
        coord = NRCoordinator(sample_rate=FS, channels=1)
        coord.set_cristhi_cosh(True)
        out = coord.process_chunk(_mono_signal())
        self.assertEqual(out.ndim, 1)
        self.assertTrue(np.all(np.isfinite(out)))

    def test_antipestal_both_modes_mono(self):
        for mode in ("STRIKER", "KARI"):
            with self.subTest(mode=mode):
                coord = NRCoordinator(sample_rate=FS, channels=1)
                coord.set_antipestal(mode)
                out = coord.process_chunk(_mono_signal())
                self.assertEqual(out.ndim, 1)
                self.assertTrue(np.all(np.isfinite(out)))

    def test_version_o_tron_all_modes_mono(self):
        for mode in ("AA_MO", "BARRIL", "SIFON"):
            with self.subTest(mode=mode):
                coord = NRCoordinator(sample_rate=FS, channels=1)
                coord.set_version_o_tron(mode)
                out = coord.process_chunk(_mono_signal())
                self.assertEqual(out.ndim, 1)
                self.assertTrue(np.all(np.isfinite(out)))

    def test_lucha_enloquecida_all_twenty_subprofiles_mono(self):
        """Los 20 sub-perfiles A-T — auditoría exhaustiva real, no una
        muestra, porque cada uno es un módulo DSP independiente con su
        propio estado interno por canal."""
        modes = [chr(c) for c in range(ord("A"), ord("T") + 1)]
        self.assertEqual(len(modes), 20)
        for mode in modes:
            with self.subTest(mode=mode):
                coord = NRCoordinator(sample_rate=FS, channels=1)
                coord.set_lucha_enloquecida(mode)
                out = coord.process_chunk(_mono_signal())
                self.assertEqual(out.ndim, 1)
                self.assertTrue(np.all(np.isfinite(out)))


class TestFullChainMonoVsStereo(unittest.TestCase):
    """La cadena COMPLETA (§21: EQ/BIAS → MPX → PREVI → NR → HX Pro →
    ALC → FOCUS → Versión O Tron, todo activo a la vez), en mono y en
    estéreo, contra el MISMO material — ni crashea, ni produce NaN/Inf,
    en ninguno de los dos casos."""

    def _build_full_chain(self, channels):
        coord = NRCoordinator(sample_rate=FS, channels=channels)
        coord.select_eq_bias("CrO2")
        coord.set_mpx(True)
        coord.set_cristhi_cosh(True)
        coord.set_muscle_eq_active(True)
        coord.select("DOLBY_C")
        coord.set_hx_pro(True)
        coord.set_alc(True)
        coord.set_focus(True)
        coord.set_version_o_tron("BARRIL")
        return coord

    def test_full_chain_mono_real_execution(self):
        coord = self._build_full_chain(channels=1)
        sig = _mono_signal(seconds=0.5, freq=880.0)
        out = coord.process_chunk(sig)
        self.assertEqual(out.ndim, 1)
        self.assertEqual(out.shape, sig.shape)
        self.assertTrue(np.all(np.isfinite(out)))
        # Ningún saneamiento NaN/Inf debería haberse disparado con una
        # señal de entrada limpia — la cardinalidad de canales, por sí
        # sola, no debe generar no-finitos en ninguna etapa.
        self.assertEqual(sum(coord.nonfinite_counts.values()), 0)

    def test_full_chain_stereo_unaffected_regression_guard(self):
        """Guarda de regresión: el mismo encadenamiento en estéreo
        (el caso de producción real, `CE_CHANNELS=2`) sigue funcionando
        exactamente igual que antes de esta auditoría."""
        coord = self._build_full_chain(channels=2)
        sig = _stereo_signal(seconds=0.5, freq=880.0)
        out = coord.process_chunk(sig)
        self.assertEqual(out.ndim, 2)
        self.assertEqual(out.shape, sig.shape)
        self.assertTrue(np.all(np.isfinite(out)))
        self.assertEqual(sum(coord.nonfinite_counts.values()), 0)

    def test_full_chain_mono_multiple_chunks_sustained(self):
        """Varios bloques consecutivos (estado interno con recursión
        IIR/EMA por canal) — no solo un único chunk aislado, para
        confirmar que el estado por canal (dimensionado con
        `np.full(channels, ...)`, `channels=1` en este caso) no se
        desalinea ni degrada con chunks sucesivos."""
        coord = self._build_full_chain(channels=1)
        block = int(FS * 0.05)
        sig = _mono_signal(seconds=1.0, freq=660.0)
        for start in range(0, len(sig) - block, block):
            chunk = sig[start:start + block]
            out = coord.process_chunk(chunk)
            self.assertEqual(out.ndim, 1)
            self.assertTrue(np.all(np.isfinite(out)))
        self.assertEqual(sum(coord.nonfinite_counts.values()), 0)

    def test_reconfigure_from_stereo_to_mono_mid_session(self):
        """`reconfigure()` es el único camino real por el que
        `channels` podría cambiar en caliente (p. ej. si una futura
        ruta de diagnóstico mono se cableara) — ejercitado con
        ejecución real, no solo argumentado."""
        coord = self._build_full_chain(channels=2)
        out_stereo = coord.process_chunk(_stereo_signal())
        self.assertEqual(out_stereo.ndim, 2)

        coord.reconfigure(sample_rate=FS, channels=1)
        self.assertEqual(coord.channels, 1)
        out_mono = coord.process_chunk(_mono_signal())
        self.assertEqual(out_mono.ndim, 1)
        self.assertTrue(np.all(np.isfinite(out_mono)))


if __name__ == "__main__":
    unittest.main()
