"""
Tests reales (con audio sintético, numpy) de los 8 sistemas de
reducción de ruido, HX Pro y ALC (§GAP-011). No requieren PySide6 — todo
el paquete `lorito_aldhiro/backend/nr/` es DSP puro.

Ejecutar: python3 -m unittest tests.test_nr_systems -v
"""

import math
import os
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lorito_aldhiro.backend.nr.lorito_nr_dsp_core import (
    shelving_high, RmsCompander, VariableLowpass, TwoBandAdaptiveGate,
)
from lorito_aldhiro.backend.nr.lorito_nr_profiles import (
    NR_PROFILE_CLASSES, DolbyBProfile, DolbyCProfile, DbxProfile, DnlProfile, DnrProfile,
)
from lorito_aldhiro.backend.nr.lorito_nr_hxpro import HxProProfile
from lorito_aldhiro.backend.nr.lorito_nr_alc import AlcProfile
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator

FS = 48000


def _tone(freq, seconds, amp=0.2, fs=FS, channels=2):
    t = np.arange(int(fs * seconds)) / fs
    sig = (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)
    return np.tile(sig.reshape(-1, 1), (1, channels))


def _rms(x):
    return float(np.sqrt(np.mean(x.astype(np.float64) ** 2)))


class TestCorePrimitives(unittest.TestCase):

    def test_shelving_high_boosts_hf_leaves_lf_alone(self):
        hf = _tone(8000, 0.3)
        lf = _tone(200, 0.3)
        f1 = shelving_high(800.0, 10.0, FS, 2)
        out_hf = f1.process(hf)
        f2 = shelving_high(800.0, 10.0, FS, 2)
        out_lf = f2.process(lf)
        ratio_hf = _rms(out_hf[4000:]) / _rms(hf[4000:])
        ratio_lf = _rms(out_lf[4000:]) / _rms(lf[4000:])
        self.assertGreater(ratio_hf, 2.5)   # ~+10dB esperado (~3.16x)
        self.assertLess(abs(ratio_lf - 1.0), 0.15)

    def test_compander_reduces_dynamic_range_below_threshold(self):
        quiet = _tone(1000, 0.5, amp=0.005)
        loud = _tone(1000, 0.5, amp=0.5)
        c1 = RmsCompander(FS, 2, threshold_db=-40.0, ratio=2.0, attack_ms=10, release_ms=350)
        c2 = RmsCompander(FS, 2, threshold_db=-40.0, ratio=2.0, attack_ms=10, release_ms=350)
        out_q = c1.process(quiet)
        out_l = c2.process(loud)
        in_ratio_db = 20 * math.log10(_rms(loud[10000:]) / _rms(quiet[10000:]))
        out_ratio_db = 20 * math.log10(_rms(out_l[10000:]) / max(_rms(out_q[10000:]), 1e-9))
        # Compresión 2:1 real: el rango dinámico de salida debe ser
        # notablemente MENOR que el de entrada.
        self.assertLess(out_ratio_db, in_ratio_db)

    def test_variable_lowpass_attenuates_hf_noise_when_quiet(self):
        noise = (0.002 * np.random.default_rng(0).standard_normal(FS)).astype(np.float32)
        noise = np.tile(noise.reshape(-1, 1), (1, 2))
        vlp = VariableLowpass(FS, 2, cutoff_min_hz=3500, cutoff_max_hz=18000,
                              threshold_db=-40, attack_ms=0.3, release_ms=80)
        out = vlp.process(noise)
        hf_in = np.mean(np.abs(np.diff(noise, axis=0)))
        hf_out = np.mean(np.abs(np.diff(out[8000:], axis=0)))
        self.assertLess(hf_out, hf_in)

    def test_two_band_gate_transparent_above_threshold(self):
        loud = _tone(1000, 0.3, amp=0.3)
        gate = TwoBandAdaptiveGate(FS, 2, crossover_hz=2000, threshold_db=-42,
                                   max_atten_db=10, attack_ms=2, release_ms=120)
        out = gate.process(loud)
        # Señal por encima del umbral: la atenuación debe ser mínima
        # (transparente por diseño, según la física documentada de DNR).
        ratio_db = 20 * math.log10(_rms(out[8000:]) / _rms(loud[8000:]))
        self.assertGreater(ratio_db, -3.0)


class TestAllEightProfiles(unittest.TestCase):

    def test_all_profiles_produce_finite_output_in_every_mode(self):
        sig = _tone(1500, 0.2) + _tone(6000, 0.2, amp=0.05)
        for name, cls in NR_PROFILE_CLASSES.items():
            for mode in ("ENCODE", "DECODE", "BYPASS"):
                p = cls(mode=mode, sample_rate=FS, channels=2)
                out = p.process_chunk(sig)
                self.assertTrue(np.all(np.isfinite(out)), f"{name}/{mode}: no finito")
                self.assertTrue(np.all(np.abs(out) <= 1.0001), f"{name}/{mode}: clip mal aplicado")

    def test_bypass_is_passthrough(self):
        sig = _tone(1000, 0.05)
        for name, cls in NR_PROFILE_CLASSES.items():
            p = cls(mode="BYPASS", sample_rate=FS, channels=2)
            out = p.process_chunk(sig)
            np.testing.assert_allclose(out, sig, atol=1e-5, err_msg=f"{name}: BYPASS altera la señal")

    def test_encode_decode_are_gain_inverses_for_static_shelving_systems(self):
        """Dolby B/C y ANRS son shelving estático: ENCODE seguido de
        DECODE debe devolver (aprox.) la señal original."""
        for cls in (DolbyBProfile, DolbyCProfile):
            sig = _tone(3000, 0.2, amp=0.1)
            enc = cls(mode="ENCODE", sample_rate=FS, channels=2)
            dec = cls(mode="DECODE", sample_rate=FS, channels=2)
            roundtrip = dec.process_chunk(enc.process_chunk(sig))
            # Tolerancia amplia: hay transitorio de asentamiento del IIR
            # al principio del bloque — se compara solo la cola estable.
            np.testing.assert_allclose(roundtrip[6000:], sig[6000:], atol=0.02)

    def test_reset_clears_iir_state(self):
        p = DolbyBProfile(mode="DECODE", sample_rate=FS, channels=2)
        p.process_chunk(_tone(3000, 0.1, amp=0.3))
        p.reset()
        # Tras reset, procesar silencio debe devolver (casi) silencio —
        # confirma que no quedó energía residual en el estado IIR.
        silence = np.zeros((480, 2), dtype=np.float32)
        out = p.process_chunk(silence)
        self.assertLess(_rms(out), 1e-3)


class TestHxPro(unittest.TestCase):

    def test_boosts_hf_content_relative_to_bypass(self):
        sig = _tone(7000, 0.3, amp=0.1)
        hx = HxProProfile(mode="ACTIVE", sample_rate=FS, channels=2)
        bypass = HxProProfile(mode="BYPASS", sample_rate=FS, channels=2)
        out_active = hx.process_chunk(sig)
        out_bypass = bypass.process_chunk(sig)
        self.assertGreater(_rms(out_active[8000:]), _rms(out_bypass[8000:]))

    def test_bypass_is_passthrough(self):
        sig = _tone(1000, 0.1)
        hx = HxProProfile(mode="BYPASS", sample_rate=FS, channels=2)
        out = hx.process_chunk(sig)
        np.testing.assert_allclose(out, sig, atol=1e-6)


class TestAlcBreathing(unittest.TestCase):
    """Verifica el efecto de respiro real (pedido explícito del
    usuario): ganancia que sube perceptiblemente durante un silencio
    tras un pasaje fuerte, con recuperación lenta y audible — no un
    limitador transparente."""

    def test_gain_recovers_slowly_after_loud_passage(self):
        fs = FS
        loud = _tone(1000, 0.5, amp=0.4, fs=fs)
        silence = np.zeros((int(fs * 1.5), 2), dtype=np.float32)
        alc = AlcProfile(mode="ACTIVE", sample_rate=fs, channels=2)
        alc.FLOOR_NOISE_LEVEL = 0.0  # desactivar ruido sintético para medir ganancia pura
        alc.process_chunk(loud)   # asienta la ganancia reducida por el pasaje fuerte
        gain_right_after = alc.gain_smooth[0]

        # Alimentar silencio real (0.0) no sirve para medir "recuperación
        # de ganancia" porque 0 * cualquier_ganancia = 0 — en su lugar,
        # alimentamos una señal MUY baja (ruido de piso real de cinta)
        # para observar cómo la ganancia sube con el tiempo.
        low_floor = (0.0008 * np.random.default_rng(2).standard_normal((fs, 2))).astype(np.float32)
        alc.process_chunk(low_floor[: fs // 3])
        gain_mid = alc.gain_smooth[0]
        alc.process_chunk(low_floor[fs // 3:])
        gain_late = alc.gain_smooth[0]

        # La ganancia debe subir progresivamente (recuperación lenta,
        # no instantánea) tras el pasaje fuerte — eso ES el "respiro".
        self.assertGreater(gain_mid, gain_right_after)
        self.assertGreater(gain_late, gain_mid)
        self.assertLessEqual(gain_late, alc.max_gain + 1e-6)

    def test_attack_is_fast_release_is_slow(self):
        """La firma característica del ALC analógico: el ataque (bajar
        ganancia ante un pico) es mucho más rápido que el release
        (recuperarla) — lo contrario sonaría "bombeado" al revés."""
        alc = AlcProfile(mode="ACTIVE", sample_rate=FS, channels=2)
        # att/rel son coeficientes de suavizado exponencial (más cerca de
        # 1.0 = más lento); att debe ser MENOR que rel (ataque más rápido).
        self.assertLess(alc.att, alc.rel)

    def test_floor_noise_present_when_enabled(self):
        alc = AlcProfile(mode="ACTIVE", sample_rate=FS, channels=2)
        silence = np.zeros((FS, 2), dtype=np.float32)
        out = alc.process_chunk(silence)
        # Con FLOOR_NOISE_LEVEL activo, el silencio digital puro ya no
        # debe seguir siendo silencio perfecto (es, a propósito, "ruido
        # de piso" que sube/baja con el respiro).
        self.assertGreater(_rms(out), 0.0)

    def test_bypass_is_passthrough(self):
        alc = AlcProfile(mode="BYPASS", sample_rate=FS, channels=2)
        sig = _tone(1000, 0.1)
        out = alc.process_chunk(sig)
        np.testing.assert_allclose(out, sig, atol=1e-6)


class TestNRCoordinator(unittest.TestCase):

    def test_single_active_selection(self):
        coord = NRCoordinator(sample_rate=FS, channels=2)
        coord.select("DOLBY_B")
        self.assertEqual(coord.active_token, "DOLBY_B")
        coord.select("DBX")
        self.assertEqual(coord.active_token, "DBX")
        coord.select(None)
        self.assertIsNone(coord.active_token)

    def test_hx_pro_and_alc_independent_of_nr_selection(self):
        coord = NRCoordinator(sample_rate=FS, channels=2)
        coord.select("DOLBY_C")
        coord.set_hx_pro(True)
        coord.set_alc(True)
        self.assertEqual(coord.active_token, "DOLBY_C")
        self.assertTrue(coord.hx_pro_active)
        self.assertTrue(coord.alc_active)

    def test_process_chunk_chains_nr_then_hxpro_then_alc(self):
        coord = NRCoordinator(sample_rate=FS, channels=2)
        coord.select("DOLBY_B")
        coord.set_hx_pro(True)
        coord.set_alc(True)
        sig = _tone(2000, 0.1, amp=0.2)
        out = coord.process_chunk(sig)
        self.assertEqual(out.shape, sig.shape)
        self.assertTrue(np.all(np.isfinite(out)))

    def test_unknown_token_does_not_crash(self):
        coord = NRCoordinator(sample_rate=FS, channels=2)
        coord.select("TOKEN_INVENTADO")
        self.assertIsNone(coord.active_token)
        sig = _tone(1000, 0.05)
        out = coord.process_chunk(sig)
        np.testing.assert_allclose(out, sig)


class TestDbxThreeTypes(unittest.TestCase):
    """DBX I/II/224 (§GAP-012, pedido explícito 'igual que CRAC') —
    verifica que los tres tipos son físicamente distintos entre sí."""

    def test_three_types_selectable(self):
        from lorito_aldhiro.backend.nr.lorito_nr_profiles import DbxProfile
        for t in ("I", "II", "224"):
            p = DbxProfile(mode="DECODE", sample_rate=FS, channels=2, dbx_type=t)
            self.assertEqual(p.dbx_type, t)
            out = p.process_chunk(_tone(2000, 0.05))
            self.assertTrue(np.all(np.isfinite(out)))

    def test_invalid_type_falls_back_to_ii(self):
        from lorito_aldhiro.backend.nr.lorito_nr_profiles import DbxProfile
        p = DbxProfile(mode="DECODE", sample_rate=FS, channels=2, dbx_type="TIPO_INVENTADO")
        self.assertEqual(p.dbx_type, "II")

    def test_type_224_has_two_preemphasis_bands_others_have_one(self):
        from lorito_aldhiro.backend.nr.lorito_nr_profiles import DbxProfile
        p1 = DbxProfile(mode="ENCODE", sample_rate=FS, channels=2, dbx_type="I")
        p2 = DbxProfile(mode="ENCODE", sample_rate=FS, channels=2, dbx_type="II")
        p224 = DbxProfile(mode="ENCODE", sample_rate=FS, channels=2, dbx_type="224")
        self.assertEqual(len(p1._preemph), 1)
        self.assertEqual(len(p2._preemph), 1)
        self.assertEqual(len(p224._preemph), 2)

    def test_types_produce_different_output_for_same_input(self):
        from lorito_aldhiro.backend.nr.lorito_nr_profiles import DbxProfile
        sig = _tone(2500, 0.15, amp=0.15)
        outs = {}
        for t in ("I", "II", "224"):
            p = DbxProfile(mode="ENCODE", sample_rate=FS, channels=2, dbx_type=t)
            outs[t] = p.process_chunk(sig)
        self.assertFalse(np.allclose(outs["I"], outs["II"], atol=1e-4))
        self.assertFalse(np.allclose(outs["II"], outs["224"], atol=1e-4))

    def test_coordinator_passes_dbx_type_through(self):
        coord = NRCoordinator(sample_rate=FS, channels=2)
        coord.select("DBX", dbx_type="224")
        self.assertEqual(coord.active_token, "DBX")
        self.assertEqual(coord._active_profile.dbx_type, "224")


class TestDrainLoopNRIntegration(unittest.TestCase):
    """Verifica, con las clases REALES de lorito_capture_engine.py (no
    dobles), que el drain loop aplica de verdad el NRCoordinator a los
    bloques que pasan por él (§GAP-012) — no solo que el código lo
    llame por inspección de fuente, sino que el AUDIO SALE DISTINTO."""

    @classmethod
    def setUpClass(cls):
        from tests.test_stability_patch import _install_stub_modules
        _install_stub_modules()

    def test_batches_reaching_ced_are_nr_processed(self):
        import threading
        import time as _time
        from lorito_aldhiro.backend.capture.lorito_capture_engine import (
            _drain_loop_fn, RingBufferAbsorcion, ColaElasticaDisco, CaptureEngineStatus,
        )

        rba = RingBufferAbsorcion(n_slots=8, frames_max=4096, channels=2, name="test-RBA")
        ced = ColaElasticaDisco(capacity=200000)
        status = CaptureEngineStatus()
        stop_evt = threading.Event()

        raw_block = _tone(800, 0.05, amp=0.3)  # dentro de la banda de Dolby B (800Hz)
        rba.write(raw_block)

        coord = NRCoordinator(sample_rate=FS, channels=2, mode="DECODE")
        coord.select("DOLBY_B")   # DECODE de Dolby B: -10dB en 800Hz+ — debe atenuar

        t = threading.Thread(target=_drain_loop_fn,
                             args=(rba, ced, status, stop_evt, None, None, coord),
                             daemon=True)
        t.start()
        # Poll en vez de sleep fijo — más robusto bajo carga del sistema
        # que un time.sleep(0.3) fijo (podía dar falsos negativos si el
        # hilo no llegó a drenar a tiempo).
        deadline = _time.monotonic() + 3.0
        while ced.frame_count == 0 and _time.monotonic() < deadline:
            _time.sleep(0.02)
        stop_evt.set()
        t.join(timeout=2.0)

        out = ced.get_batch(max_frames=len(raw_block) * 4, timeout=0.1)
        self.assertIsNotNone(out, "el drain loop no produjo ningún bloque")
        n = min(len(out), len(raw_block))
        # Dolby B DECODE en 800Hz debe atenuar (~-10dB) frente al bloque crudo.
        self.assertLess(_rms(out[:n]), _rms(raw_block[:n]) * 0.9)

    def test_without_coordinator_blocks_pass_through_unchanged(self):
        import threading
        import time as _time
        from lorito_aldhiro.backend.capture.lorito_capture_engine import (
            _drain_loop_fn, RingBufferAbsorcion, ColaElasticaDisco, CaptureEngineStatus,
        )

        rba = RingBufferAbsorcion(n_slots=8, frames_max=4096, channels=2, name="test-RBA2")
        ced = ColaElasticaDisco(capacity=200000)
        status = CaptureEngineStatus()
        stop_evt = threading.Event()
        raw_block = _tone(800, 0.05, amp=0.3)
        rba.write(raw_block)

        t = threading.Thread(target=_drain_loop_fn,
                             args=(rba, ced, status, stop_evt, None, None, None),
                             daemon=True)
        t.start()
        deadline = _time.monotonic() + 3.0
        while ced.frame_count == 0 and _time.monotonic() < deadline:
            _time.sleep(0.02)
        stop_evt.set()
        t.join(timeout=2.0)

        out = ced.get_batch(max_frames=len(raw_block) * 4, timeout=0.1)
        self.assertIsNotNone(out)
        n = min(len(out), len(raw_block))
        np.testing.assert_allclose(out[:n], raw_block[:n], atol=1e-6)


if __name__ == "__main__":
    unittest.main()
