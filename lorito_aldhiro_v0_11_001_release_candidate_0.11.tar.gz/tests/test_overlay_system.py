"""
Tests reales del sistema de overlays del contómetro (§GAP-010): el
registro de vocabulario (`lorito_overlay_registry.py`, lógica pura) y la
integración con `DigitalClock` (requiere PySide6 — se instalan los mismos
stubs mínimos de `tests/test_stability_patch.py`).

Ejecutar: python3 -m unittest tests.test_overlay_system -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules


class TestOverlayRegistry(unittest.TestCase):
    """Lógica pura — sin PySide6."""

    def test_exact_calco_tokens_present(self):
        """
        Actualizado en la Orden Maestra de Saneamiento 0.06.005→0.06.006
        (Fase 11, ítem 2 — "overlay de exportación"): el token EXPORT se
        corrigió de "Export" a "Expn Signal" en GAP-022 (auditoría real
        contra `crac_export_controller.py`/`setOverlayExpnSignal()` de
        CRAC — "Export" es un overlay CRAC distinto, de menor prioridad,
        que Lorito Aldhiro no usa). Se añaden también los tokens de
        Seek/Morpher/MPX auditados en la misma sesión (GAP-021/GAP-022),
        que antes no tenían cobertura en esta prueba.
        """
        from lorito_aldhiro.backend.export.lorito_overlay_registry import OVERLAY_MESSAGES
        expected = {
            "OVFLOW_TP": "OvFlow TP",
            "SIDE_A": "Side A",
            "SIDE_B": "Side B",
            "FN_SIDE_A": "FnSide A",
            "FN_TAPE_ALDH": "FnTape Aldh",
            "FNC_NO_DISP": "Fnc No Disp",
            "SIPACTIV": "SIPActiV",
            "PAUSE": "Pause",
            "EXPORT": "Expn Signal",
            "SEEK_YNG": "SeekYng",
            "SC_CUE": "ScCue",
            "SC_REW": "ScRew",
            "MPX": "MPX FI",
        }
        for token, exact_text in expected.items():
            self.assertIn(token, OVERLAY_MESSAGES)
            text, _color = OVERLAY_MESSAGES[token]
            self.assertEqual(text, exact_text,
                             f"{token}: calco no idéntico al de CRAC")

    def test_unknown_token_falls_back_to_fnc_no_disp(self):
        from lorito_aldhiro.backend.export.lorito_overlay_registry import message_for
        text, _color = message_for("TOKEN_INVENTADO_QUE_NO_EXISTE")
        self.assertEqual(text, "Fnc No Disp")

    def test_all_messages_have_valid_rgba_color(self):
        from lorito_aldhiro.backend.export.lorito_overlay_registry import OVERLAY_MESSAGES
        for token, (text, color) in OVERLAY_MESSAGES.items():
            self.assertTrue(color.startswith("rgba("), f"{token}: color no es rgba()")
            nums = color[color.find("(")+1:color.find(")")].split(",")
            self.assertEqual(len(nums), 4, f"{token}: rgba con {len(nums)} componentes")


class TestDigitalClockOverlayIntegration(unittest.TestCase):
    """Requiere PySide6 (stubs si no está instalado)."""

    @classmethod
    def setUpClass(cls):
        _install_stub_modules()

    def _make_clock(self):
        from lorito_aldhiro.frontend.widgets.lorito_indicators import DigitalClock
        return DigitalClock()

    def test_fnc_no_disp_wins_over_everything(self):
        clock = self._make_clock()
        clock.setOverlay("SIPA", True, "SIPActiV", "rgba(255,20,147,210)")
        clock.setOverlay("EXPORT", True, "Export", "rgba(255,255,255,230)")
        clock.setOverlay("FNC_NO_DISP", True, "Fnc No Disp", "rgba(255,120,60,220)")
        text, _color = clock._active_overlay()
        self.assertEqual(text, "Fnc No Disp")

    def test_clearing_top_priority_reveals_next(self):
        clock = self._make_clock()
        clock.setOverlay("SIPA", True, "SIPActiV", "rgba(255,20,147,210)")
        clock.setOverlay("ITL", True, "FnSide A", "rgba(255,140,0,220)")
        text, _color = clock._active_overlay()
        self.assertEqual(text, "FnSide A")
        clock.setOverlay("ITL", False)
        text, _color = clock._active_overlay()
        self.assertEqual(text, "SIPActiV")

    def test_no_overlay_active_returns_none(self):
        clock = self._make_clock()
        self.assertIsNone(clock._active_overlay())

    def test_registry_convenience_method(self):
        clock = self._make_clock()
        clock.setOverlayFromRegistry("OVFLOW_TP", True, "OVFLOW_TP")
        text, _color = clock._active_overlay()
        self.assertEqual(text, "OvFlow TP")
        clock.setOverlayFromRegistry("OVFLOW_TP", False)
        self.assertIsNone(clock._active_overlay())

    def test_cell_lit_tracks_tokens(self):
        clock = self._make_clock()
        self.assertFalse(clock._cell_lit["DOLBY_B"])
        clock.set_cell_lit("DOLBY_B", True)
        self.assertTrue(clock._cell_lit["DOLBY_B"])
        clock.set_cell_lit("TOKEN_QUE_NO_EXISTE", True)  # no-op, no debe lanzar

    def test_host_cell_mutually_exclusive(self):
        clock = self._make_clock()
        clock.set_host_cell("ALSA")
        self.assertTrue(clock._cell_lit["ALSA"])
        self.assertFalse(clock._cell_lit["JACK"])
        clock.set_host_cell("JACK")
        self.assertFalse(clock._cell_lit["ALSA"])
        self.assertTrue(clock._cell_lit["JACK"])

    def test_tape_label_cell_switches(self):
        clock = self._make_clock()
        self.assertEqual(clock._tape_label_text, "C-60")
        clock.set_tape_label_cell("C-90")
        self.assertEqual(clock._tape_label_text, "C-90")

    def test_side_cells_start_with_contracted_defaults(self):
        """
        Actualizado en la Orden Maestra de Saneamiento 0.06.005→0.06.006
        (Fase 11, ítems 3/4 — "etiqueta inicial LADO A"/"LADO B"):
        §GAP-015 originalmente dejaba las 4+4 celdas vacías; GAP-018
        (pedido explícito del usuario) fijó valores por defecto reales
        para las 8 celdas — L1=LADO A/L2=STEREO/L4=MON 1 encendidas,
        R1-R4 apagadas — sin actualizar esta prueba, que seguía
        verificando el estado "vacío" ya superado por el contrato
        vigente.
        """
        clock = self._make_clock()
        expected_text = {
            "L1": "LADO A", "L2": "STEREO", "L3": "MONO", "L4": "MON 1",
            "R1": "MPX", "R2": "NORMAL", "R3": "DITHER", "R4": "FOCUS",
        }
        expected_lit = {
            "L1": True, "L2": True, "L3": False, "L4": True,
            "R1": False, "R2": False, "R3": False, "R4": False,
        }
        for token in clock.LEFT_CELLS + clock.RIGHT_CELLS:
            self.assertEqual(clock._side_cell_text[token], expected_text[token])
            self.assertEqual(clock._side_cell_lit[token], expected_lit[token])

    def test_set_side_cell_updates_text_and_lit_state(self):
        """Actualizado en la misma pasada de saneamiento: L1 ya no
        arranca vacío (ver `test_side_cells_start_with_contracted_
        defaults`) — la celda "sin tocar" que se usa aquí como control
        es L3 (MONO, apagada por defecto), no L1."""
        clock = self._make_clock()
        clock.set_side_cell("L2", "X", True)
        self.assertEqual(clock._side_cell_text["L2"], "X")
        self.assertTrue(clock._side_cell_lit["L2"])
        # Resto de celdas sin tocar — L1 conserva su default contratado
        self.assertEqual(clock._side_cell_text["L1"], "LADO A")

    def test_set_side_cell_unknown_token_is_noop(self):
        clock = self._make_clock()
        clock.set_side_cell("TOKEN_INVENTADO", "X", True)  # no debe lanzar
        self.assertNotIn("TOKEN_INVENTADO", clock._side_cell_text)

    def test_four_left_and_four_right_cells_exactly(self):
        clock = self._make_clock()
        self.assertEqual(len(clock.LEFT_CELLS), 4)
        self.assertEqual(len(clock.RIGHT_CELLS), 4)

    def test_itl_overlay_backward_compat(self):
        """setITLOverlay() (API de GAP-007/008) sigue funcionando como
        delegado de la categoría 'ITL'."""
        clock = self._make_clock()
        clock.setITLOverlay(True, "FnSide A", "rgba(255,140,0,220)")
        text, _color = clock._active_overlay()
        self.assertEqual(text, "FnSide A")
        clock.setITLOverlay(False)
        self.assertIsNone(clock._active_overlay())


class TestMainWindowOverlayWiring(unittest.TestCase):
    """Verifica, contra el código fuente REAL de lorito_main_window.py,
    que los disparadores de overlay quedaron efectivamente conectados."""

    @classmethod
    def setUpClass(cls):
        _install_stub_modules()
        try:
            import lorito_aldhiro.frontend.lorito_main_window  # noqa: F401
        except ModuleNotFoundError as e:
            # Hallazgo colateral (ajeno a §GAP-010): lorito_tape_log_panel.py
            # importa `aecct2_crac_motor_v4`, un módulo externo que no está
            # incluido en ningún tarball de Lorito Aldhiro — mismo patrón
            # exacto que el motor ITL (GAP-008) y el stability patch
            # (GAP-009) antes de integrarse. No es parte de este encargo;
            # se documenta en GAP-010 §pendiente y se saltan estos 3 tests
            # de inspección de fuente en vez de fallar por una dependencia
            # ajena al overlay system.
            raise unittest.SkipTest(f"dependencia externa faltante, ajena a este "
                                    f"encargo (ver GAP-010): {e}")

    def test_flip_pending_wires_fn_side_a(self):
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._build_ui)
        self.assertIn('"FN_SIDE_A"', src)
        self.assertIn('"FN_TAPE_ALDH"', src)

    def test_menu_bar_method_exists_and_wires_acerca_to_fnc_no_disp(self):
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        self.assertTrue(hasattr(LoritoAldhiroStudio, "_build_menu_bar"))
        src = inspect.getsource(LoritoAldhiroStudio._build_menu_bar)
        self.assertIn("_show_fnc_no_disp", src)
        for token in ("CINTA", "HOST", "MUESTRA", "BITDEPH", "NR", "OPTAPE", "ACERCA"):
            self.assertIn(token, src)

    def test_overflow_tick_wires_ovflow_tp(self):
        # GAP-051 — actualizado: `tickITLOverlayBlink()` fue retirado de
        # `_on_overflow_blink_tick` por FIX-OVERLAY-BLINK-AUTOSUFICIENTE
        # (el overlay "OvFlow TP" del contómetro ya parpadea solo, vía el
        # QTimer interno de `DigitalClock` — ver comentario real en el
        # propio método). El tick real que SÍ sigue vigente es
        # `tick_overflow_blink()` sobre cada panel de cuentavueltas
        # (`tape_c60`/`tape_c90`/`tape_otros`); esta aserción quedó
        # desactualizada tras ese refactor y fallaba contra el código
        # fuente real — no era una regresión de esta sesión.
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._on_overflow_blink_tick)
        self.assertIn("tick_overflow_blink", src)
        self.assertIn("tape_c60", src)


if __name__ == "__main__":
    unittest.main()
