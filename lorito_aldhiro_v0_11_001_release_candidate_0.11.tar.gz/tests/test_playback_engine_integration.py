"""
test_playback_engine_integration.py — GAP-062.

Hasta este GAP, `PlaybackEngine` (`lorito_playback_engine.py` — el
motor de reproducción REAL en producción, no el Transport Core nuevo
sin cablear de `test_transport_core.py`) no tenía NINGÚN test que lo
instanciara y lo corriera de verdad: `test_resample_continuity*.py`
solo prueban las funciones de resampleo puras en aislamiento, nunca el
motor completo con sus hilos reales (`_prefetch`, `_bridge`, el driver
de audio). Es, según su propio docstring, el archivo con más historial
de bugs de pops/saltos/glitches del proyecto (FIX-1..FIX-G4, BUG-C) —
exactamente el tipo de código que la Orden pide verificar con
EJECUCIÓN REAL, no solo lectura de código o tests unitarios aislados
(§29: "UNIT TEST + INTEGRATION TEST + REAL APPLICATION PATH").

Este módulo cierra ese hueco: instancia `PlaybackEngine()` real, con
el fixture de audio REAL del usuario (`tests/fixtures/
sotalomafer1_scrub_5s.wav`), corriendo sus hilos reales de prefetch/
bridge/driver-de-audio (el último simulado por
`_functional_sounddevice_output_stub.py`, hermano del stub ya
existente para `InputStream`/`CaptureEngineV2`). Ejercita exactamente
los sitios tocados en GAP-062: los 2 puntos de reset de
`phase_cursor`/`phase_history` (seek, commit-flush de velocidad) y los
4 sitios de llamada al resampleador (prefetch tras seek, prefetch tras
commit-flush, lectura normal forward, lectura normal reversa vía
velocidad negativa).

Criterio de verificación: sin excepciones/crashes en ningún hilo, el
audio realmente entregado al "driver" (capturado por el stub) no
contiene NaN/Inf en ningún bloque, y `_ss.phase_history` tiene en todo
momento el tipo esperado (`None` o `np.ndarray` de longitud
≤HISTORY_LEN=2) — no una prueba de "suena bien" (imposible de
automatizar) sino de integridad mecánica real bajo concurrencia real.
"""

import os
import sys
import time
import unittest

import numpy as np

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)

from _functional_soundfile_stub import install_functional_soundfile_stub
install_functional_soundfile_stub()

from _functional_sounddevice_output_stub import (
    install_functional_sounddevice_output_stub,
)
install_functional_sounddevice_output_stub(callback_interval=0.002)

import lorito_aldhiro.backend.playback.lorito_playback_engine as pe  # noqa: E402

# GAP-063 — mismo problema ya documentado en GAP-041/GAP-036/037 para
# `lorito_capture_engine`: `unittest discover` importa TODOS los
# archivos test_*.py en un único proceso, en orden alfabético. Si
# `lorito_playback_engine` ya fue importado por OTRO archivo de test
# ANTES que este (p. ej. vía `lorito_main_window` u otro importador
# transitivo), su `sd`/`sf` quedan enlazados PERMANENTEMENTE al stub
# (o dummy) que estuviera instalado en `sys.modules` en ESE momento —
# reinstalar `sys.modules["sounddevice"]`/`["soundfile"]` arriba no
# alcanza para un módulo ya importado, porque `import X as sd` liga el
# nombre `sd` al objeto módulo vigente en el momento del import, no a
# una referencia viva a `sys.modules`. Confirmado real: al correr esta
# suite AISLADA los 6 tests pasan, pero al correr la suite COMPLETA
# (`unittest discover`) fallan con "el hilo de PlaybackEngine no
# arrancó a tiempo" — el dummy stub instalado por otro archivo antes
# (p. ej. `_install_stub_modules()` de `test_stability_patch.py`, que
# NO implementa `OutputStream` de forma funcional) queda enlazado en
# `pe.sd`. Se reasignan los atributos directamente, igual que
# `ce_mod.sd = sys.modules["sounddevice"]` en
# `test_capture_engine_end_to_end.py`/`test_close_protection.py`, para
# garantizar el stub funcional en este archivo sin importar el orden.
pe.sd = sys.modules["sounddevice"]
pe.sf = sys.modules["soundfile"]

_FIXTURE_PATH = os.path.join(_TESTS_DIR, "fixtures", "sotalomafer1_scrub_5s.wav")


def _wait_until(predicate, timeout=3.0, interval=0.01):
    """Sondeo breve en vez de una única comprobación inmediata — mismo
    patrón ya usado en GAP-061 para evitar carreras reales de hilos."""
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if predicate():
            return True
        time.sleep(interval)
    return predicate()


@unittest.skipUnless(os.path.exists(_FIXTURE_PATH),
                     f"fixture de audio real no encontrado: {_FIXTURE_PATH}")
class TestPlaybackEngineRealThreadedIntegration(unittest.TestCase):

    def setUp(self):
        self.engine = pe.PlaybackEngine()

    def tearDown(self):
        # stop() es idempotente y con timeout — nunca debe colgar el test.
        self.engine.stop()

    def _start_and_wait_stream(self, speed_ratio=0.75, start_frame=0):
        self.engine.start(
            path=_FIXTURE_PATH, rate=48000, channels=2,
            start_frame=start_frame, speed_ratio=speed_ratio, on_done=None,
        )
        self.assertTrue(
            _wait_until(lambda: self.engine.is_active(), timeout=3.0),
            "el hilo de PlaybackEngine no arrancó a tiempo")
        self.assertTrue(
            _wait_until(lambda: self.engine._stream is not None, timeout=3.0),
            "el OutputStream (preload de prefetch) no se abrió a tiempo")
        return self.engine._stream  # referencia propia — sobrevive a engine.stop()

    def test_forward_playback_no_crash_no_nonfinite_output(self):
        stream = self._start_and_wait_stream(speed_ratio=0.75)
        time.sleep(0.3)  # deja correr varios ciclos reales de prefetch/callback
        self.engine.stop()

        self.assertGreater(stream.callbacks_delivered, 0,
                           "el driver de audio simulado nunca recibió callbacks")
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all(),
                            "bloque de audio real entregado al driver con NaN/Inf")

    def test_seek_mid_playback_resets_phase_in_lockstep(self):
        """Ejercita el reset de phase_cursor/phase_history del seek
        (línea ~786 de lorito_playback_engine.py) con un seek REAL a
        mitad de reproducción."""
        stream = self._start_and_wait_stream(speed_ratio=0.75)
        time.sleep(0.15)

        self.engine.seek_to(48000)  # 1s dentro del fixture de 5s
        # phase_history debe quedar en el tipo correcto tras el reset
        # (None, o ya reescrito por el siguiente resample real) — nunca
        # un tipo inconsistente ni una excepción en el hilo de prefetch.
        self.assertTrue(_wait_until(
            lambda: not self.engine._seek_evt.is_set(), timeout=2.0),
            "el prefetch nunca procesó el seek")

        time.sleep(0.2)
        self.engine.stop()

        self.assertGreater(stream.callbacks_delivered, 0)
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all())

    def test_discrete_speed_change_resets_phase_in_lockstep(self):
        """Ejercita el reset de phase_cursor/phase_history del
        commit-flush de set_speed() (línea ~868, dentro de
        `if not captured_live_flag`) con un cambio de velocidad
        DISCRETO real."""
        stream = self._start_and_wait_stream(speed_ratio=1.0)
        time.sleep(0.15)

        self.engine.set_speed(1.5)  # discreto → dispara _speed_change_evt
        self.assertTrue(_wait_until(
            lambda: not self.engine._speed_change_evt.is_set(), timeout=2.0),
            "el prefetch nunca procesó el cambio de velocidad discreto")

        time.sleep(0.2)
        self.engine.stop()

        self.assertGreater(stream.callbacks_delivered, 0)
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all())

    def test_live_speed_change_preserves_phase_history_type(self):
        """set_speed_live() (drag en curso) NO debe resetear
        phase_cursor/phase_history — solo el flush discreto lo hace.
        Verifica que, tras un live-flush, phase_history sigue siendo
        un tipo válido (preservado o ya reescrito por el próximo
        resample), nunca None Y a la vez un estado inconsistente."""
        stream = self._start_and_wait_stream(speed_ratio=1.0)
        time.sleep(0.15)

        self.engine.set_speed_live(0.6)
        time.sleep(0.15)
        self.engine.set_speed_live(0.5)
        time.sleep(0.2)

        ph = self.engine._ss.phase_history
        self.assertTrue(
            ph is None or isinstance(ph, np.ndarray),
            f"phase_history con tipo inesperado tras set_speed_live: {type(ph)}")
        if isinstance(ph, np.ndarray):
            self.assertLessEqual(len(ph), 2,  # HISTORY_LEN
                                 "phase_history más largo que HISTORY_LEN")

        self.engine.stop()
        self.assertGreater(stream.callbacks_delivered, 0)
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all())

    def test_reverse_playback_no_crash_no_nonfinite_output(self):
        """ratio negativo → rama is_reverse del prefetch (línea ~925),
        el sitio de llamada al resampleador que invierte el chunk
        ANTES de resamplear."""
        stream = self._start_and_wait_stream(speed_ratio=-0.8, start_frame=96000)
        time.sleep(0.3)
        self.engine.stop()

        self.assertGreater(stream.callbacks_delivered, 0)
        for blk in stream.captured:
            self.assertTrue(np.isfinite(blk).all())

    def test_stop_is_clean_no_lingering_thread(self):
        self._start_and_wait_stream(speed_ratio=1.0)
        time.sleep(0.1)
        self.engine.stop()
        self.assertFalse(self.engine.is_active())
        self.assertIsNone(self.engine._stream)


if __name__ == "__main__":
    unittest.main()
