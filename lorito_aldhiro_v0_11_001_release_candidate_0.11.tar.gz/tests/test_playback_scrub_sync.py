"""
test_playback_scrub_sync.py — GAP-070, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Verifica `backend/playback/lorito_playback_scrub_sync.py` — la
extracción MECÁNICA de dos fragmentos puros duplicados (4 y 3 sitios
respectivamente) que vivían inline dentro de `_on_speed_changed()`/
`_on_morpher_changed()` (`PlaybackMixin`, `lorito_mw_playback.py`),
mismo patrón de GAP-056/GAP-062: sin cobertura de test alguna antes de
esta extracción pese a estar activamente en uso (sincronización real
del scrub/waveform y del contómetro durante Velocista/Morpher).
"""

import unittest

from lorito_aldhiro.backend.playback.lorito_playback_scrub_sync import (
    clamp_position_fraction, speed_status_text,
)


class TestClampPositionFractionBasic(unittest.TestCase):

    def test_midpoint(self):
        self.assertAlmostEqual(clamp_position_fraction(500.0, 1000.0), 0.5)

    def test_start(self):
        self.assertEqual(clamp_position_fraction(0.0, 1000.0), 0.0)

    def test_end_exact(self):
        self.assertEqual(clamp_position_fraction(1000.0, 1000.0), 1.0)

    def test_clamps_above_one(self):
        # src_pos > total_frames (puede ocurrir transitoriamente en el
        # último bloque antes de EOF) — el mismo `min(1.0, ...)` que ya
        # tenía cada sitio de llamada original.
        self.assertEqual(clamp_position_fraction(5000.0, 1000.0), 1.0)

    def test_clamps_below_zero(self):
        self.assertEqual(clamp_position_fraction(-5.0, 1000.0), 0.0)


class TestClampPositionFractionGuards(unittest.TestCase):
    """Las guardas que cada uno de los 4 sitios de llamada originales
    ya aplicaba ANTES de calcular la fracción — replicadas EXACTAS,
    ver docstring del módulo."""

    def test_none_total_frames_returns_none(self):
        self.assertIsNone(clamp_position_fraction(500.0, None))

    def test_zero_total_frames_returns_none(self):
        self.assertIsNone(clamp_position_fraction(500.0, 0.0))

    def test_negative_total_frames_returns_none(self):
        self.assertIsNone(clamp_position_fraction(500.0, -10.0))

    def test_total_secs_omitted_does_not_gate(self):
        """2 de los 4 sitios originales (Morpher forward/reverse) NO
        comprobaban `total_secs` — omitir el parámetro reproduce
        exactamente ese caso."""
        self.assertAlmostEqual(clamp_position_fraction(500.0, 1000.0), 0.5)

    def test_total_secs_zero_gates_even_with_valid_frames(self):
        """Los otros 2 sitios (commit del Velocista, consolidación del
        Morpher) SÍ exigían `total_secs > 0` además de `total_frames`
        — replicado con el parámetro opcional."""
        self.assertIsNone(clamp_position_fraction(500.0, 1000.0, total_secs=0.0))

    def test_total_secs_negative_gates(self):
        self.assertIsNone(clamp_position_fraction(500.0, 1000.0, total_secs=-1.0))

    def test_total_secs_positive_does_not_gate(self):
        self.assertAlmostEqual(
            clamp_position_fraction(500.0, 1000.0, total_secs=30.0), 0.5)


class TestSpeedStatusText(unittest.TestCase):
    """Texto exacto que reemplazaba los 3 sitios de llamada
    duplicados — mismo formato, misma leyenda de `_carol_speed_label`."""

    def test_format_matches_legacy_string_exactly(self):
        ratio = 1.5
        expected = (
            "__CAROLAMOTION_SPEED__LORITO PICOTEA EL CASSETTE ×1.50"
            " — Pactorald"
        )
        self.assertEqual(speed_status_text(ratio), expected)

    def test_two_decimal_rounding(self):
        self.assertIn("×0.77", speed_status_text(0.7654))

    def test_uses_carol_speed_label_for_legend(self):
        from lorito_aldhiro.backend.export.lorito_normalization import _carol_speed_label
        for ratio in (0.55, 0.95, 1.0, 1.05, 1.5, 1.95):
            with self.subTest(ratio=ratio):
                self.assertIn(_carol_speed_label(ratio), speed_status_text(ratio))


if __name__ == "__main__":
    unittest.main()
