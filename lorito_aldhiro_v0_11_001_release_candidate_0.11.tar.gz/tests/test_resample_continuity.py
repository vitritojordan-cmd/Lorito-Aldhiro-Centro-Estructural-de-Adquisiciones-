"""
test_resample_continuity.py — GAP-037, medición real de la deriva de
fase en `_resample_stateful` (documentada sin medir desde GAP-026) y
verificación de la corrección propuesta
(`resample_stateful_continuous`).

Requiere poder importar `lorito_playback_engine.py`, bloqueado hasta
esta sesión por `sounddevice`/`soundfile` no instalables — se
resuelve con stubs mínimos (no necesitan ser funcionales: la función
medida es matemática pura, no toca disco ni audio real).
"""

import sys
import types
import unittest

import numpy as np


def _install_stubs():
    if "sounddevice" not in sys.modules or getattr(sys.modules["sounddevice"], "__lorito_stub__", False):
        stub_sd = types.ModuleType("sounddevice")
        stub_sd.__lorito_stub__ = True
        sys.modules["sounddevice"] = stub_sd
    if "soundfile" not in sys.modules or getattr(sys.modules["soundfile"], "__lorito_stub__", False):
        stub_sf = types.ModuleType("soundfile")
        stub_sf.__lorito_stub__ = True
        sys.modules["soundfile"] = stub_sf


_install_stubs()

import lorito_aldhiro.backend.playback.lorito_playback_engine as pe  # noqa: E402
from lorito_aldhiro.backend.dsp.lorito_dsp_resample_continuous import (  # noqa: E402
    resample_stateful_continuous,
)


def _make_signal(n_total, seed=0):
    t = np.arange(n_total) / 48000.0
    sig = (0.5 * np.sin(2 * np.pi * 440.0 * t)
           + 0.3 * np.sin(2 * np.pi * 1200.0 * t)).astype(np.float32)
    return sig.reshape(-1, 1)


def _resample_chunked_legacy(signal, ratio, block_size):
    n_total = len(signal)
    cursor = 0.0
    parts = []
    pos = 0
    while pos < n_total:
        take = min(block_size, n_total - pos)
        out, cursor = pe._resample_stateful(signal[pos:pos + take], ratio, cursor)
        parts.append(out)
        pos += take
    return np.concatenate(parts, axis=0)


def _resample_chunked_continuous(signal, ratio, block_size):
    n_total = len(signal)
    cursor = 0.0
    history = None
    parts = []
    pos = 0
    while pos < n_total:
        take = min(block_size, n_total - pos)
        out, cursor, history = resample_stateful_continuous(
            signal[pos:pos + take], ratio, cursor, history)
        parts.append(out)
        pos += take
    return np.concatenate(parts, axis=0)


class TestMeasureLegacyDrift(unittest.TestCase):
    """Documenta, con números reales, el defecto que GAP-026 solo
    había podido especular sin medir."""

    def test_legacy_resample_drifts_progressively_with_small_chunks(self):
        n_total = 200_000
        signal = _make_signal(n_total)
        ratio = 0.85
        gold, _ = pe._resample_stateful(signal.copy(), ratio, 0.0)

        chunked_small = _resample_chunked_legacy(signal, ratio, block_size=512)
        n = min(len(gold), len(chunked_small))

        # Primeras muestras: prácticamente idénticas (aún no hay deriva).
        early_diff = np.max(np.abs(gold[:500] - chunked_small[:500]))
        self.assertLess(early_diff, 1e-5)

        # Muestras tardías: la deriva ya es grande — este es el defecto
        # real, medido por primera vez.
        late_diff = np.max(np.abs(gold[n - 2000:n] - chunked_small[n - 2000:n]))
        self.assertGreater(late_diff, 0.05,
                           msg="se esperaba deriva medible tardía con "
                               "chunks pequeños — si esto falla, el "
                               "defecto documentado ya no está presente")

    def test_larger_chunks_drift_less_but_still_measurably(self):
        n_total = 200_000
        signal = _make_signal(n_total)
        ratio = 1.25
        gold, _ = pe._resample_stateful(signal.copy(), ratio, 0.0)

        chunked_large = _resample_chunked_legacy(signal, ratio, block_size=8192)
        n = min(len(gold), len(chunked_large))
        diff = np.abs(gold[:n] - chunked_large[:n])
        # Con chunks grandes hay MENOS fronteras, por ende menos
        # oportunidades de deriva — pero sigue habiendo alguna.
        self.assertGreater(np.max(diff), 0.0)


class TestContinuousResamplerFixesTheDrift(unittest.TestCase):
    """Verifica que `resample_stateful_continuous` (la corrección)
    reproduce el valor Catmull-Rom REAL (calculado a mano sobre el
    array completo, sin ningún clamp de borde) en cada frontera de
    chunk — a diferencia de la comparación por índice de más arriba,
    esto NO se confunde con el desfase de longitud inherente al
    redondeo de `n_out` por chunk (una propiedad independiente del
    artefacto de borde, presente en ambas versiones por igual, y ya
    documentada como el "por qué" de las longitudes ligeramente
    distintas entre pases — no es lo que este fix corrige)."""

    @staticmethod
    def _catmull_rom_ref(full_flat, t):
        i1 = int(np.floor(t))
        mu = t - i1
        i0, i2, i3 = i1 - 1, i1 + 1, i1 + 2
        mu2, mu3 = mu * mu, mu ** 3
        c0 = -0.5 * mu3 + mu2 - 0.5 * mu
        c1 = 1.5 * mu3 - 2.5 * mu2 + 1.0
        c2 = -1.5 * mu3 + 2.0 * mu2 + 0.5 * mu
        c3 = 0.5 * mu3 - 0.5 * mu2
        return c0 * full_flat[i0] + c1 * full_flat[i1] + c2 * full_flat[i2] + c3 * full_flat[i3]

    def test_continuous_resampler_matches_true_value_at_every_chunk_boundary(self):
        rng = np.random.default_rng(2)
        chunk_len = 1000
        n_chunks = 15
        chunks = [(rng.uniform(-0.3, 0.3, size=(chunk_len, 1))).astype(np.float32)
                 for _ in range(n_chunks)]
        full = np.concatenate(chunks, axis=0)[:, 0].astype(np.float64)
        ratio = 0.85

        cursor = 0.0
        history = None
        max_err_continuous = 0.0
        max_err_legacy = 0.0
        abs_offset = 0
        for chunk in chunks:
            out_c, cursor_c_next, history_next = resample_stateful_continuous(
                chunk.copy(), ratio, cursor, history)
            out_legacy, cursor_legacy_next = pe._resample_stateful(
                chunk.copy(), ratio, cursor)

            # Verificar los primeros puntos de salida de este chunk
            # (los más sensibles al borde) contra la referencia real —
            # el primer índice puede coincidir por casualidad (según
            # dónde caiga exactamente el cursor), así que se revisan
            # varios, no solo el primero.
            if abs_offset > 0 and len(out_c) > 0:
                n_check = min(4, len(out_c), len(out_legacy))
                for k in range(n_check):
                    t_abs = cursor + abs_offset + k * ratio
                    if t_abs >= 1 and t_abs < len(full) - 2:
                        ref = self._catmull_rom_ref(full, t_abs)
                        err_c = abs(out_c[k, 0] - ref)
                        err_legacy = abs(out_legacy[k, 0] - ref)
                        max_err_continuous = max(max_err_continuous, err_c)
                        max_err_legacy = max(max_err_legacy, err_legacy)

            cursor = cursor_c_next
            history = history_next
            abs_offset += chunk_len

        # La corrección debe reproducir el valor real con precisión de
        # float32; el legado, con su artefacto de borde, se espera que
        # difiera mucho más.
        self.assertLess(max_err_continuous, 1e-4,
                        msg="la versión continua debería coincidir con "
                            "la referencia real en cada frontera")
        self.assertGreater(max_err_legacy, 1e-3,
                           msg="se esperaba que el legado mostrara el "
                               "artefacto de borde conocido — si esto "
                               "falla, el defecto documentado ya no "
                               "está presente")

    def test_neutral_zone_unchanged(self):
        # ratio≈1.0 (zona neutra) no debe verse afectado por el
        # historial — mismo comportamiento que el legado (paso directo).
        n_total = 10_000
        signal = _make_signal(n_total)
        out, cursor, history = resample_stateful_continuous(signal, 1.0, 0.0, None)
        np.testing.assert_array_equal(out, signal)


if __name__ == "__main__":
    unittest.main()
