"""
test_resample_continuity_real_audio.py — GAP-062.

`tests/test_resample_continuity.py` verifica `resample_stateful_continuous`
contra ruido sintético. Este módulo repite EXACTAMENTE la misma
metodología (referencia Catmull-Rom real, sin clamps de borde, en
posiciones fraccionarias exactas) pero contra un fragmento de audio
REAL: 5s extraídos de `Sotalomafer1.mp3`, un cassette transdigitalizado
en CRAC 0.10 que el usuario adjuntó explícitamente para las
comparativas de sonido de los Scrubs (fixture embebido en
`tests/fixtures/sotalomafer1_scrub_5s.wav`, PCM24 48kHz estéreo).

Objetivo: que la deriva de fase de `_resample_stateful` (legado, el
resampleador que hoy usa `PlaybackEngine` en producción) y su ausencia
en `resample_stateful_continuous` (la corrección) no sean solo un
efecto de ruido sintético sincronizado con el propio muestreo, sino
que se repliquen con música/voz real, en los mismos ratios y
escenarios (forward, reverse, post-seek-reset) que el motor real
ejercita en el pipeline de scrub/varispeed.
"""

import os
import sys
import types
import unittest

import numpy as np

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)

_FIXTURE_PATH = os.path.join(_TESTS_DIR, "fixtures", "sotalomafer1_scrub_5s.wav")


def _install_stubs():
    if "sounddevice" not in sys.modules or getattr(sys.modules["sounddevice"], "__lorito_stub__", False):
        stub_sd = types.ModuleType("sounddevice")
        stub_sd.__lorito_stub__ = True
        sys.modules["sounddevice"] = stub_sd
    if "soundfile" not in sys.modules or getattr(sys.modules["soundfile"], "__lorito_stub__", False):
        stub_sf = types.ModuleType("soundfile")
        stub_sf.__lorito_stub__ = True
        sys.modules["soundfile"] = stub_sf


_install_stubs()

import lorito_aldhiro.backend.playback.lorito_playback_engine as pe  # noqa: E402
from lorito_aldhiro.backend.dsp.lorito_dsp_resample_continuous import (  # noqa: E402
    resample_stateful_continuous,
)
from _wav_pcm24_extensible_reader import RealAudioPCM24Fixture  # noqa: E402

PE_CHUNK_FRAMES = pe.PE_CHUNK_FRAMES  # 4096, el tamaño de chunk real de producción


def _catmull_rom_ref(full_flat, t):
    """Idéntica a TestContinuousResamplerFixesTheDrift._catmull_rom_ref
    de tests/test_resample_continuity.py — no se reinventa el cálculo
    de referencia, se reutiliza el mismo ya verificado."""
    i1 = int(np.floor(t))
    mu = t - i1
    i0, i2, i3 = i1 - 1, i1 + 1, i1 + 2
    mu2, mu3 = mu * mu, mu ** 3
    c0 = -0.5 * mu3 + mu2 - 0.5 * mu
    c1 = 1.5 * mu3 - 2.5 * mu2 + 1.0
    c2 = -1.5 * mu3 + 2.0 * mu2 + 0.5 * mu
    c3 = 0.5 * mu3 - 0.5 * mu2
    return c0 * full_flat[i0] + c1 * full_flat[i1] + c2 * full_flat[i2] + c3 * full_flat[i3]


def _chunk_it(mono, chunk_len):
    n_total = len(mono)
    chunks, pos = [], 0
    while pos < n_total:
        take = min(chunk_len, n_total - pos)
        chunks.append(mono[pos:pos + take])
        pos += take
    return chunks


@unittest.skipUnless(os.path.exists(_FIXTURE_PATH),
                     f"fixture de audio real no encontrado: {_FIXTURE_PATH}")
class TestRealAudioResamplerComparison(unittest.TestCase):
    """Compara legado vs continuo, chunk a chunk, contra la referencia
    Catmull-Rom real calculada sobre el fragmento COMPLETO de
    Sotalomafer1.mp3 (5s, canal izquierdo, PE_CHUNK_FRAMES=4096)."""

    @classmethod
    def setUpClass(cls):
        fixture = RealAudioPCM24Fixture(_FIXTURE_PATH)
        data = fixture.read_frames(fixture.frames)
        cls.mono = data[:, :1].copy()  # canal izquierdo, mismo shape que usa el motor
        cls.assertTrue_ = None  # placeholder no usado

    def _compare(self, ratio, reverse=False, chunk_len=PE_CHUNK_FRAMES):
        mono = self.mono[::-1].copy() if reverse else self.mono
        chunks = _chunk_it(mono, chunk_len)
        full = mono[:, 0].astype(np.float64)

        cursor_c, history = 0.0, None
        cursor_legacy = 0.0
        max_err_continuous = 0.0
        max_err_legacy = 0.0
        abs_offset = 0

        for chunk in chunks:
            out_c, cursor_c_next, history_next = resample_stateful_continuous(
                chunk.copy(), ratio, cursor_c, history)
            out_legacy, cursor_legacy_next = pe._resample_stateful(
                chunk.copy(), ratio, cursor_legacy)

            if abs_offset > 0 and len(out_c) > 0:
                n_check = min(8, len(out_c), len(out_legacy))
                for k in range(n_check):
                    t_abs = cursor_c + abs_offset + k * ratio
                    if 1 <= t_abs < len(full) - 2:
                        ref = _catmull_rom_ref(full, t_abs)
                        max_err_continuous = max(max_err_continuous, abs(out_c[k, 0] - ref))
                        max_err_legacy = max(max_err_legacy, abs(out_legacy[k, 0] - ref))

            cursor_c, history, cursor_legacy = cursor_c_next, history_next, cursor_legacy_next
            abs_offset += len(chunk)

        return max_err_continuous, max_err_legacy

    def test_forward_slow_0_75_continuous_matches_reference_legacy_drifts(self):
        err_c, err_legacy = self._compare(0.75)
        self.assertLess(err_c, 1e-4,
                        msg="el continuo debe coincidir con la referencia real "
                            "en cada frontera de chunk, con audio real")
        self.assertGreater(err_legacy, err_c * 10,
                           msg="con audio real, el legado debe mostrar un error "
                               "muchas veces mayor que el continuo (el defecto "
                               "de deriva de fase documentado en GAP-037)")

    def test_forward_fast_1_5_continuous_matches_reference_legacy_drifts(self):
        err_c, err_legacy = self._compare(1.5)
        self.assertLess(err_c, 1e-4)
        self.assertGreater(err_legacy, err_c * 10)

    def test_forward_half_speed_0_5_continuous_matches_reference_legacy_drifts(self):
        err_c, err_legacy = self._compare(0.5)
        self.assertLess(err_c, 1e-4)
        self.assertGreater(err_legacy, err_c * 10)

    def test_reverse_0_8_continuous_matches_reference_legacy_drifts(self):
        # Igual que el motor real: la señal se invierte por chunk ANTES
        # de resamplear (ver lorito_playback_engine.py, rama is_reverse).
        err_c, err_legacy = self._compare(0.8, reverse=True)
        self.assertLess(err_c, 1e-4)
        self.assertGreater(err_legacy, err_c * 10)

    def test_seek_reset_no_bleed_through_with_real_audio(self):
        """Tras un seek simulado (reset explícito de cursor/historial,
        igual que hace el motor real en el punto de seek), el primer
        chunk post-seek no debe arrastrar fase del segmento anterior."""
        ratio = 0.75
        chunks = _chunk_it(self.mono, PE_CHUNK_FRAMES)
        mid = len(chunks) // 2
        self.assertGreater(mid, 0, "fixture demasiado corto para simular seek a mitad")

        cursor_c, history = 0.0, None
        for chunk in chunks[:mid]:
            _, cursor_c, history = resample_stateful_continuous(
                chunk.copy(), ratio, cursor_c, history)

        # SEEK → reset (igual que ss.phase_cursor = PE_PHASE_RESET;
        # ss.phase_history = None en los dos puntos de reset del motor real)
        cursor_c, history = 0.0, None

        seek_chunk = chunks[mid]
        out_c, _, _ = resample_stateful_continuous(seek_chunk.copy(), ratio, cursor_c, history)
        seek_chunk_flat = seek_chunk[:, 0].astype(np.float64)

        n_check = min(8, len(out_c))
        max_err = 0.0
        for k in range(n_check):
            t_abs = k * ratio
            if 1 <= t_abs < len(seek_chunk_flat) - 2:
                ref = _catmull_rom_ref(seek_chunk_flat, t_abs)
                max_err = max(max_err, abs(out_c[k, 0] - ref))

        self.assertLess(max_err, 1e-4,
                        msg="tras el reset de seek, el primer chunk no debe "
                            "arrastrar fase del segmento anterior")


if __name__ == "__main__":
    unittest.main()
