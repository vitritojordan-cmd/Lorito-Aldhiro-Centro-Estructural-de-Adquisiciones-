"""
test_rf64_encoder.py — Fase 8 (RF64) de la Orden Maestra de
Saneamiento Pre-Auditoría Aldhira Phonographic.

Verifica:
1. La decisión RIFF vs RF64 en `open()` según `total_frames_hint`.
2. Que un archivo RF64 escrito de verdad (con datos reales, tamaño
   pequeño — el formato no depende del tamaño real para ser válido,
   solo la DECISIÓN de usarlo depende del tamaño estimado) es
   parseable y coherente: header 'RF64', chunk 'ds64' con los 3
   campos de 64 bits correctos, 'fmt ' y 'data' con los sentinelas
   0xFFFFFFFF intactos.
3. Que el módulo estándar `wave` de Python (que no entiende RF64)
   falla al leerlo, confirmando que `_validate_rf64` es necesario
   (no es un parser redundante).
4. Round-trip completo vía `ExportSession` con `total_frames_hint`
   forzado a un valor que dispara RF64, sin escribir 4GB reales a
   disco (el tamaño estimado se basa en el HINT, no en los bytes
   escritos de verdad — se explota esto deliberadamente para probar
   RF64 con archivos pequeños en este sandbox).
"""

import os
import struct
import tempfile
import unittest
import wave

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import (
    WavEncoder, WAV_SAFE_LIMIT_BYTES,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block


class _FakeFmt:
    def __init__(self, rate=48000, channels=2):
        self.rate = rate
        self.channels = channels


class TestRf64Decision(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_rf64_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _make_encoder(self, total_frames_hint):
        out_path = os.path.join(self.tmpdir, "out.wav")
        enc = WavEncoder(_FakeFmt(), out_path, subtype="PCM_24",
                         total_frames_hint=total_frames_hint)
        return enc

    def test_small_hint_uses_plain_riff(self):
        enc = self._make_encoder(total_frames_hint=48000 * 10)  # 10s, diminuto
        enc.open()
        self.assertFalse(enc._rf64)
        enc.finalize()

    def test_hint_over_limit_uses_rf64(self):
        # frames * channels * sample_width > WAV_SAFE_LIMIT_BYTES
        frames_needed = (WAV_SAFE_LIMIT_BYTES // (2 * 3)) + 1_000_000
        enc = self._make_encoder(total_frames_hint=frames_needed)
        enc.open()
        self.assertTrue(enc._rf64)
        enc.finalize()

    def test_no_hint_defaults_to_plain_riff(self):
        enc = self._make_encoder(total_frames_hint=0)
        enc.open()
        self.assertFalse(enc._rf64)
        enc.finalize()


class TestRf64FileStructure(unittest.TestCase):
    """Escribe un archivo RF64 real (pequeño) y verifica su estructura
    byte a byte — no solo que `validate()` diga OK, sino el layout
    exacto del header."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_rf64_struct_")
        self.out_path = os.path.join(self.tmpdir, "big.wav")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _write_rf64_forced(self, n_frames=1000, channels=2, subtype="PCM_24"):
        # Fuerza la decisión RF64 con un hint grande, pero escribe
        # datos reales pequeños — la decisión RIFF/RF64 depende del
        # HINT (conocido de antemano por ExportSession), no de cuánto
        # se escriba realmente; esto permite probar el formato RF64
        # sin generar archivos de varios GB en el sandbox.
        huge_hint = (WAV_SAFE_LIMIT_BYTES // (channels * 3)) + 1_000_000
        enc = WavEncoder(_FakeFmt(channels=channels), self.out_path,
                         subtype=subtype, total_frames_hint=huge_hint)
        enc.open()
        self.assertTrue(enc._rf64)
        rng = np.random.default_rng(0)
        block = (rng.uniform(-0.3, 0.3, size=(n_frames, channels))).astype(np.float32)
        enc.write(Block(data=block, frame_offset=0, is_last=True))
        enc.finalize()
        return enc, block

    def test_header_layout_bytes(self):
        enc, block = self._write_rf64_forced(n_frames=500, channels=2)
        block_align = 2 * 3  # PCM_24 stereo
        expected_data_bytes = 500 * block_align

        with open(self.out_path, "rb") as f:
            raw = f.read()

        self.assertEqual(raw[0:4], b"RF64")
        self.assertEqual(struct.unpack("<I", raw[4:8])[0], 0xFFFFFFFF)
        self.assertEqual(raw[8:12], b"WAVE")
        self.assertEqual(raw[12:16], b"ds64")
        ds64_size = struct.unpack("<I", raw[16:20])[0]
        self.assertEqual(ds64_size, 28)
        riff_size_64, data_size_64, sample_count_64 = struct.unpack(
            "<QQQ", raw[20:44])
        table_length = struct.unpack("<I", raw[44:48])[0]
        self.assertEqual(table_length, 0)
        self.assertEqual(data_size_64, expected_data_bytes)
        self.assertEqual(sample_count_64, 500)
        self.assertEqual(raw[48:52], b"fmt ")
        self.assertEqual(raw[72:76], b"data")
        self.assertEqual(struct.unpack("<I", raw[76:80])[0], 0xFFFFFFFF)

        actual_file_size = len(raw)
        self.assertEqual(riff_size_64, actual_file_size - 8)

    def test_pcm_data_readable_bit_exact(self):
        enc, block = self._write_rf64_forced(n_frames=300, channels=2)
        with open(self.out_path, "rb") as f:
            raw = f.read()
        pcm_bytes = raw[80:]  # data_start=80 según el layout fijo de _write_placeholder_header_rf64
        u8 = np.frombuffer(pcm_bytes, dtype=np.uint8).reshape(-1, 3)
        buf32 = np.zeros((u8.shape[0], 4), dtype=np.uint8)
        buf32[:, 0:3] = u8
        buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
        pcm_actual = np.frombuffer(buf32.tobytes(), dtype="<i4")
        # Comparar en el dominio PCM24 (igual que GAP-026) — `block` es
        # float32 puro, todavía sin cuantizar; cuantizarlo con la MISMA
        # aritmética simétrica del encoder da la comparación bit-exacta
        # real, en vez de una diferencia de ±1 LSB esperada por el
        # redondeo de cuantización (no un defecto).
        pcm_expected = np.clip(np.round(np.clip(block, -1.0, 1.0) * 8388608.0),
                               -8388608, 8388607).astype(np.int32).ravel()
        np.testing.assert_array_equal(pcm_actual, pcm_expected)

    def test_python_wave_module_cannot_read_rf64(self):
        # Confirma que _validate_rf64 es necesario — `wave` de Python
        # no entiende RF64 (magic distinto de 'RIFF').
        self._write_rf64_forced(n_frames=100)
        with self.assertRaises(Exception):
            with wave.open(self.out_path, "rb") as wf:
                wf.getnframes()

    def test_validate_reports_correct_frames_and_rf64_flag(self):
        enc, block = self._write_rf64_forced(n_frames=777, channels=2)
        result = enc.validate()
        self.assertTrue(result["ok"], msg=result.get("error"))
        self.assertEqual(result["actual_frames"], 777)
        self.assertEqual(result["actual_rate"], 48000)
        self.assertTrue(result.get("rf64"))

    def test_validate_mono_rf64(self):
        enc, block = self._write_rf64_forced(n_frames=400, channels=1)
        result = enc.validate()
        self.assertTrue(result["ok"], msg=result.get("error"))
        self.assertEqual(result["actual_channels"], 1)
        self.assertEqual(result["actual_frames"], 400)


class TestRf64ThroughExportSession(unittest.TestCase):
    """Round-trip completo vía SegmentProvider + ExportSession,
    forzando RF64 con segmentos reales — la ruta que usaría un export
    real de una sesión larga."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_rf64_session_")
        self.rate = 48000
        self.channels = 2

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _write_float_wav_pcm24(self, path, audio_f32):
        clipped = np.clip(audio_f32, -1.0, 1.0)
        pcm32 = np.clip(np.round(clipped * 8388608.0), -8388608, 8388607).astype(np.int32)
        u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
        raw = np.ascontiguousarray(u8[:, 0:3]).tobytes()
        with wave.open(path, "wb") as wf:
            wf.setnchannels(self.channels)
            wf.setsampwidth(3)
            wf.setframerate(self.rate)
            wf.writeframesraw(raw)

    def test_export_session_writes_rf64_when_hint_forces_it(self):
        from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
            ExportSession,
        )

        rng = np.random.default_rng(1)
        seg_paths = []
        originals = []
        for i, n in enumerate([2000, 3000]):
            audio = (rng.uniform(-0.2, 0.2, size=(n, self.channels))).astype(np.float32)
            p = os.path.join(self.tmpdir, f"seg{i}.wav")
            self._write_float_wav_pcm24(p, audio)
            seg_paths.append(p)
            originals.append(audio)
        total_frames_real = sum(a.shape[0] for a in originals)

        out_path = os.path.join(self.tmpdir, "final_rf64.wav")
        # encoder_kwargs.total_frames_hint tiene prioridad sobre el
        # `provider.total_frames` real que ExportSession calcularía —
        # se fuerza aquí para disparar RF64 sin escribir GBs reales.
        huge_hint = (WAV_SAFE_LIMIT_BYTES // (self.channels * 3)) + 1_000_000
        session = ExportSession(
            seg_paths, encoder_cls=WavEncoder, final_path=out_path,
            encoder_kwargs={"subtype": "PCM_24", "total_frames_hint": huge_hint},
        )
        report = session.run()
        self.assertTrue(report.ok, msg=report.error)
        self.assertEqual(report.frames_in, total_frames_real)
        self.assertEqual(report.frames_out, total_frames_real)

        with open(out_path, "rb") as f:
            magic = f.read(4)
        self.assertEqual(magic, b"RF64")


if __name__ == "__main__":
    unittest.main()
