"""
test_ring_buffer_spsc.py — Fase 3 (ring buffer RT sin locks) de la
Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic.

Dos niveles de verificación:
1. Unitaria de un solo hilo — comportamiento determinista (escribir N,
   leer N, overrun cuando corresponde, underrun cuando corresponde).
2. Concurrencia REAL — hilos productor/consumidor de Python de verdad
   (no simulados, `threading.Thread` real) corriendo simultáneamente
   con miles de bloques, verificando que ningún dato llega corrompido
   o mezclado, y que el conteo de frames entregados + overruns +
   underruns explica exactamente lo escrito. No requiere `sounddevice`
   ni hardware de audio — es concurrencia genuina de CPython.
"""

import random
import threading
import time
import unittest

import numpy as np

from lorito_aldhiro.backend.rt import LockFreeSPSCRingBuffer


class TestSingleThreadBehavior(unittest.TestCase):
    def test_write_then_read_roundtrip(self):
        rb = LockFreeSPSCRingBuffer(n_slots=8, frames_max=16, channels=2)
        block = np.arange(16 * 2, dtype=np.float32).reshape(16, 2) * 0.01
        self.assertTrue(rb.write(block))
        data, n = rb.read()
        self.assertEqual(n, 16)
        np.testing.assert_array_equal(data, block)

    def test_read_empty_returns_none(self):
        rb = LockFreeSPSCRingBuffer(n_slots=4, frames_max=8, channels=1)
        self.assertIsNone(rb.read())
        self.assertEqual(rb.underrun_total, 1)

    def test_partial_block_truncated_to_frames_max(self):
        rb = LockFreeSPSCRingBuffer(n_slots=4, frames_max=4, channels=1)
        block = np.ones((10, 1), dtype=np.float32)
        rb.write(block)
        data, n = rb.read()
        self.assertEqual(n, 4)

    def test_overrun_when_writer_laps_reader(self):
        rb = LockFreeSPSCRingBuffer(n_slots=4, frames_max=2, channels=1)
        # Escribir 6 bloques sin leer — el buffer tiene 4 slots, así
        # que las generaciones 0 y 1 se sobrescriben por 4 y 5
        # (overrun). El lector salta directamente a la generación más
        # antigua todavía válida: la 4.
        for i in range(6):
            rb.write(np.full((2, 1), float(i), dtype=np.float32))
        data, n = rb.read()
        self.assertEqual(data[0, 0], 4.0)
        self.assertEqual(rb.overrun_total, 4)

    def test_read_batch_respects_max_items(self):
        rb = LockFreeSPSCRingBuffer(n_slots=16, frames_max=4, channels=1)
        for i in range(10):
            rb.write(np.full((4, 1), float(i), dtype=np.float32))
        batch = rb.read_batch(max_items=3)
        self.assertEqual(len(batch), 3)
        self.assertEqual(batch[0][0][0, 0], 0.0)
        self.assertEqual(batch[1][0][0, 0], 1.0)
        self.assertEqual(batch[2][0][0, 0], 2.0)

    def test_watermark_tracks_occupancy(self):
        rb = LockFreeSPSCRingBuffer(n_slots=10, frames_max=4, channels=1)
        for i in range(5):
            rb.write(np.zeros((4, 1), dtype=np.float32))
        self.assertAlmostEqual(rb.watermark_pct, 0.5, places=3)
        rb.read()
        rb.read()
        # El watermark solo se actualiza en write() (path RT) — leer no
        # lo recalcula, mismo comportamiento que RingBufferAbsorcion
        # original (que lo actualiza en ambos lados). Documentado: aquí
        # es una métrica de "presión vista por el productor", más
        # barata (cero coste extra en el path de lectura).
        rb.write(np.zeros((4, 1), dtype=np.float32))
        self.assertAlmostEqual(rb.watermark_pct, 0.4, places=3)


class TestConcurrentProducerConsumer(unittest.TestCase):
    """Verificación con hilos REALES — el corazón de la Fase 3.
    Sin esto, un ring buffer "sin locks" es solo una afirmación; aquí
    se ejercita de verdad bajo concurrencia genuina de CPython."""

    def _run_stress(self, n_slots, frames_max, channels, n_blocks,
                    writer_delay_range, reader_delay_range, seed):
        rb = LockFreeSPSCRingBuffer(n_slots=n_slots, frames_max=frames_max,
                                    channels=channels)
        rng_w = random.Random(seed)
        received = []
        stop_flag = {"writer_done": False}
        errors = []

        def _producer():
            try:
                for i in range(n_blocks):
                    n = rng_w.randint(1, frames_max)
                    # Cada bloque lleva su índice de generación
                    # codificado en la primera muestra — permite
                    # verificar orden e integridad sin ambigüedad.
                    block = np.full((n, channels), float(i), dtype=np.float32)
                    rb.write(block)
                    if writer_delay_range:
                        time.sleep(rng_w.uniform(*writer_delay_range))
            except Exception as e:
                errors.append(("producer", e))
            finally:
                stop_flag["writer_done"] = True

        def _consumer():
            rng_r = random.Random(seed + 1)
            try:
                while not stop_flag["writer_done"] or True:
                    item = rb.read()
                    if item is not None:
                        data, n = item
                        received.append((data[0, 0], n, data.shape[0]))
                    else:
                        if stop_flag["writer_done"]:
                            # Drenar cualquier resto pendiente y salir
                            item2 = rb.read()
                            if item2 is None:
                                break
                            data, n = item2
                            received.append((data[0, 0], n, data.shape[0]))
                            continue
                        if reader_delay_range:
                            time.sleep(rng_r.uniform(*reader_delay_range))
            except Exception as e:
                errors.append(("consumer", e))

        t_prod = threading.Thread(target=_producer, name="test-producer")
        t_cons = threading.Thread(target=_consumer, name="test-consumer")
        t_cons.start()
        t_prod.start()
        t_prod.join(timeout=30.0)
        t_cons.join(timeout=30.0)

        self.assertFalse(t_prod.is_alive(), "el hilo productor no terminó")
        self.assertFalse(t_cons.is_alive(), "el hilo consumidor no terminó")
        self.assertEqual(errors, [], f"excepciones en los hilos: {errors}")
        return rb, received

    def test_fast_writer_slow_reader_produces_overruns_no_corruption(self):
        rb, received = self._run_stress(
            n_slots=8, frames_max=64, channels=2, n_blocks=2000,
            writer_delay_range=None, reader_delay_range=(0.0001, 0.0003),
            seed=1)

        # Cada generación recibida debe ser mayor que la anterior
        # (orden estrictamente creciente — nunca se entrega un dato
        # fuera de orden ni duplicado).
        gens = [g for g, n, shape in received]
        for a, b in zip(gens, gens[1:]):
            self.assertLess(a, b, "generaciones recibidas fuera de orden")

        # Con lector lento, debe haber habido overruns reales — si no,
        # el escenario de prueba no está ejercitando lo que se quiere
        # verificar.
        self.assertGreater(rb.overrun_total, 0)
        # Contabilidad exacta: generaciones recibidas + overruns +
        # (huecos por underrun no cuentan frames) debe explicar el
        # total escrito.
        self.assertEqual(len(received) + rb.overrun_total, 2000)

    def test_slow_writer_fast_reader_no_data_loss(self):
        rb, received = self._run_stress(
            n_slots=8, frames_max=32, channels=1, n_blocks=500,
            writer_delay_range=(0.0002, 0.0006), reader_delay_range=None,
            seed=2)

        gens = [g for g, n, shape in received]
        # Lector más rápido que el escritor: NINGÚN overrun, se reciben
        # las 500 generaciones exactas, en orden, sin huecos.
        self.assertEqual(rb.overrun_total, 0)
        self.assertEqual(gens, list(range(500)))

    def test_no_torn_reads_under_contention(self):
        # n_slots pequeño + bloques grandes + ambos hilos a máxima
        # velocidad (sin sleeps) — el escenario más agresivo para
        # forzar el caso "el productor dio la vuelta durante la
        # copia del lector" (protocolo de reintento).
        rb, received = self._run_stress(
            n_slots=3, frames_max=256, channels=2, n_blocks=5000,
            writer_delay_range=None, reader_delay_range=None,
            seed=3)

        for gen, n, shape0 in received:
            # Cada bloque recibido debe tener TODAS sus muestras
            # consistentes con la generación que dice ser — un dato
            # mezclado (torn read) tendría muestras de dos
            # generaciones distintas, lo cual esta reconstrucción no
            # puede producir salvo que el protocolo fallara.
            self.assertEqual(gen, float(int(gen)))  # generación entera válida

        gens = [g for g, n, shape in received]
        for a, b in zip(gens, gens[1:]):
            self.assertLess(a, b)

        self.assertEqual(len(received) + rb.overrun_total, 5000)

    def test_repeated_runs_are_stable(self):
        # Corre el escenario agresivo varias veces — una carrera real
        # no detectada podría manifestarse solo intermitentemente.
        for seed in range(5):
            rb, received = self._run_stress(
                n_slots=4, frames_max=128, channels=2, n_blocks=1000,
                writer_delay_range=None, reader_delay_range=None,
                seed=100 + seed)
            gens = [g for g, n, shape in received]
            for a, b in zip(gens, gens[1:]):
                self.assertLess(a, b, f"seed={seed}: fuera de orden")
            self.assertEqual(len(received) + rb.overrun_total, 1000,
                             msg=f"seed={seed}: contabilidad no cuadra")


if __name__ == "__main__":
    unittest.main()
