"""
test_segment_checksum.py — GAP-035, conexión real de integridad de
segmento (continuación de la Fase 7, GAP-032).

Verifica el módulo de checksums en aislamiento (sin stubs necesarios,
es lógica pura sobre archivos WAV reales vía `wave`), la detección
real de corrupción, y la integración con `classify_session`.
"""

import os
import tempfile
import unittest
import wave

from lorito_aldhiro.backend.archival.lorito_segment_checksum import (
    compute_segment_checksum, verify_segment_checksum,
)
from lorito_aldhiro.backend.archival import ArchivalState, classify_session


def _write_wav(path, rate, channels, sampwidth, frames_data: bytes):
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sampwidth)
        wf.setframerate(rate)
        wf.writeframesraw(frames_data)


class TestComputeAndVerify(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_checksum_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_same_content_produces_same_checksum(self):
        p = os.path.join(self.tmpdir, "a.wav")
        data = bytes(range(256)) * 20
        _write_wav(p, 48000, 2, 2, data)
        c1 = compute_segment_checksum(p)
        c2 = compute_segment_checksum(p)
        self.assertEqual(c1["sha256"], c2["sha256"])
        self.assertEqual(c1["crc32"], c2["crc32"])

    def test_different_content_produces_different_checksum(self):
        p1 = os.path.join(self.tmpdir, "a.wav")
        p2 = os.path.join(self.tmpdir, "b.wav")
        _write_wav(p1, 48000, 2, 2, bytes(range(256)) * 20)
        _write_wav(p2, 48000, 2, 2, bytes((i % 256) for i in range(1, 257)) * 20)
        c1 = compute_segment_checksum(p1)
        c2 = compute_segment_checksum(p2)
        self.assertNotEqual(c1["sha256"], c2["sha256"])

    def test_verify_matches_unmodified_file(self):
        p = os.path.join(self.tmpdir, "sano.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 20)
        expected = compute_segment_checksum(p)
        result = verify_segment_checksum(p, expected)
        self.assertTrue(result["ok"])

    def test_verify_detects_real_bit_corruption(self):
        # Simula bit rot real: el archivo se modifica DESPUÉS de
        # calcular el checksum de referencia (exactamente el escenario
        # que este módulo existe para detectar).
        p = os.path.join(self.tmpdir, "corrompido.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 20)
        expected = compute_segment_checksum(p)

        with open(p, "r+b") as f:
            f.seek(60)  # dentro de los datos PCM, no del header
            byte = f.read(1)
            f.seek(60)
            f.write(bytes([byte[0] ^ 0xFF]))  # invertir un byte

        result = verify_segment_checksum(p, expected)
        self.assertFalse(result["ok"])
        self.assertIn("corrupción real", result["reason"])

    def test_verify_detects_truncation(self):
        p = os.path.join(self.tmpdir, "truncado.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 20)
        expected = compute_segment_checksum(p)

        with open(p, "r+b") as f:
            f.truncate(os.path.getsize(p) - 40)

        result = verify_segment_checksum(p, expected)
        self.assertFalse(result["ok"])
        self.assertIn("truncado", result["reason"])

    def test_verify_missing_file_reports_reason_not_exception(self):
        expected = {"sha256": "x", "crc32": "y", "frames": 10}
        result = verify_segment_checksum(
            os.path.join(self.tmpdir, "no_existe.wav"), expected)
        self.assertFalse(result["ok"])
        self.assertIn("no se pudo releer", result["reason"])


class TestClassifySessionWithChecksums(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_checksum_classify_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_clean_session_with_matching_checksums_is_archival_safe(self):
        p = os.path.join(self.tmpdir, "seg0.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 20)
        checksum = compute_segment_checksum(p)
        checksum["path"] = p

        result = classify_session({}, segment_checksums=[checksum])
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)

    def test_corrupted_segment_makes_session_invalid(self):
        p = os.path.join(self.tmpdir, "seg0.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 20)
        checksum = compute_segment_checksum(p)
        checksum["path"] = p

        with open(p, "r+b") as f:
            f.seek(60)
            byte = f.read(1)
            f.seek(60)
            f.write(bytes([byte[0] ^ 0xFF]))

        result = classify_session({}, segment_checksums=[checksum])
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertTrue(any("corrupción de integridad" in r for r in result.reasons))

    def test_classify_session_without_checksums_still_works_as_before(self):
        result = classify_session({})
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)


if __name__ == "__main__":
    unittest.main()
