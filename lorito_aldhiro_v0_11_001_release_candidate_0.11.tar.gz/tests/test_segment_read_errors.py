"""
test_segment_read_errors.py — Fase 2 (política de errores de lectura)
de la Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic.

Defecto real confirmado antes de esta fase: `wave.readframes(n)` NO
lanza ninguna excepción cuando el archivo físicamente contiene menos
datos de los que su propio header declara — simplemente devuelve
menos bytes de los pedidos. `SegmentProvider.iter_blocks()` entregaba
ese bloque corto silenciosamente y lo marcaba como `is_last=True`,
dejando que el defecto se descubriera varias capas más abajo (en
`AtomicFinalizer`, comparando conteos de frames) sin nombrar el
segmento responsable.
"""

import os
import struct
import tempfile
import unittest
import wave

from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider, SegmentReadError,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import (
    FormatMismatchError,
)


def _write_wav(path, rate, channels, sampwidth, n_frames):
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sampwidth)
        wf.setframerate(rate)
        wf.writeframes(bytes(n_frames * channels * sampwidth))


def _corrupt_header_frame_count(path, claimed_extra_frames, channels, sampwidth):
    """Simula un segmento truncado por un crash: reescribe el campo de
    tamaño del chunk 'data' del header para que declare MÁS frames de
    los que el archivo físicamente contiene, sin tocar los datos
    reales — exactamente lo que un proceso de captura interrumpido a
    mitad de escritura, antes de corregir el header final, dejaría en
    disco."""
    with open(path, "r+b") as f:
        f.seek(40)  # offset estándar del campo de tamaño de 'data' en un WAV de 44 bytes
        current = struct.unpack("<I", f.read(4))[0]
        f.seek(40)
        f.write(struct.pack("<I", current + claimed_extra_frames * channels * sampwidth))


class TestConstructionTimeErrors(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_segread_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_missing_segment_raises_format_mismatch(self):
        # Sin cambios de comportamiento — ya existía, se confirma que
        # sigue funcionando tras esta fase.
        with self.assertRaises(FormatMismatchError):
            SegmentProvider([os.path.join(self.tmpdir, "no_existe.wav")])

    def test_not_a_wav_file_raises_segment_read_error(self):
        p = os.path.join(self.tmpdir, "no_es_wav.wav")
        with open(p, "wb") as f:
            f.write(b"esto no es un archivo WAV en absoluto")
        with self.assertRaises(SegmentReadError) as ctx:
            SegmentProvider([p])
        self.assertIn(p, str(ctx.exception))

    def test_empty_file_raises_segment_read_error(self):
        p = os.path.join(self.tmpdir, "vacio.wav")
        open(p, "wb").close()
        with self.assertRaises(SegmentReadError):
            SegmentProvider([p])


class TestTruncatedSegmentDetection(unittest.TestCase):
    """El caso central de esta fase: un header que miente sobre cuántos
    frames contiene realmente el archivo."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_segread_trunc_")
        self.rate = 48000
        self.channels = 2
        self.sampwidth = 2

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_truncated_single_segment_raises_segment_read_error(self):
        p = os.path.join(self.tmpdir, "truncado.wav")
        _write_wav(p, self.rate, self.channels, self.sampwidth, n_frames=200)
        _corrupt_header_frame_count(p, claimed_extra_frames=800,
                                    channels=self.channels, sampwidth=self.sampwidth)

        # La construcción NO falla (el header, aunque mentiroso, es
        # sintácticamente válido) — el error debe surgir al iterar,
        # que es cuando se descubre la discrepancia real.
        provider = SegmentProvider([p])
        self.assertEqual(provider.total_frames, 1000)  # cree el header mentiroso

        with self.assertRaises(SegmentReadError) as ctx:
            list(provider.iter_blocks(block_frames=32768))
        msg = str(ctx.exception)
        self.assertIn(p, msg, msg="el error debe nombrar el segmento exacto")
        self.assertIn("truncado", msg.lower())

    def test_truncated_segment_among_several_is_identified_by_name(self):
        p_ok1 = os.path.join(self.tmpdir, "seg0_ok.wav")
        p_bad = os.path.join(self.tmpdir, "seg1_truncado.wav")
        p_ok2 = os.path.join(self.tmpdir, "seg2_ok.wav")
        _write_wav(p_ok1, self.rate, self.channels, self.sampwidth, n_frames=500)
        _write_wav(p_bad, self.rate, self.channels, self.sampwidth, n_frames=300)
        _corrupt_header_frame_count(p_bad, claimed_extra_frames=700,
                                    channels=self.channels, sampwidth=self.sampwidth)
        _write_wav(p_ok2, self.rate, self.channels, self.sampwidth, n_frames=400)

        provider = SegmentProvider([p_ok1, p_bad, p_ok2])
        with self.assertRaises(SegmentReadError) as ctx:
            list(provider.iter_blocks(block_frames=32768))
        self.assertIn(p_bad, str(ctx.exception))
        self.assertNotIn(p_ok1, str(ctx.exception))
        self.assertNotIn(p_ok2, str(ctx.exception))

    def test_blocks_before_truncation_point_are_still_yielded(self):
        # Con un block_frames pequeño que fuerza varias iteraciones
        # ANTES de llegar al punto de corte, los bloques previos deben
        # entregarse con normalidad — el error surge exactamente en el
        # bloque donde la lectura real queda corta.
        p = os.path.join(self.tmpdir, "truncado_multi.wav")
        _write_wav(p, self.rate, self.channels, self.sampwidth, n_frames=1000)
        _corrupt_header_frame_count(p, claimed_extra_frames=500,
                                    channels=self.channels, sampwidth=self.sampwidth)

        provider = SegmentProvider([p])
        blocks = []
        with self.assertRaises(SegmentReadError):
            for blk in provider.iter_blocks(block_frames=200):
                blocks.append(blk)
        # 5 bloques de 200 frames caben en los 1000 reales — deben
        # haberse entregado ANTES de que el 6º intente leer más allá
        # del final físico del archivo.
        self.assertEqual(len(blocks), 5)
        self.assertEqual(sum(b.n_frames for b in blocks), 1000)

    def test_not_truncated_segment_reads_normally(self):
        # Control negativo — un segmento sin corromper no debe disparar
        # jamás SegmentReadError.
        p = os.path.join(self.tmpdir, "sano.wav")
        _write_wav(p, self.rate, self.channels, self.sampwidth, n_frames=1000)
        provider = SegmentProvider([p])
        blocks = list(provider.iter_blocks(block_frames=200))
        self.assertEqual(sum(b.n_frames for b in blocks), 1000)
        self.assertTrue(blocks[-1].is_last)


if __name__ == "__main__":
    unittest.main()
