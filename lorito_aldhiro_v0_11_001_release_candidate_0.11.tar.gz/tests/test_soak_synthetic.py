"""
test_soak_synthetic.py -- GAP-074, FASE 11 ("50h soak test", Orden
Maestra de Saneamiento, Integración y Consolidación de Lorito
Aldhiro, §23, Suite F).

§23/Suite F pide una captura continua de 50 HORAS DE RELOJ REAL sin
reiniciar el proceso, verificando RAM/CPU estables y `ARCHIVAL_SAFE`
al finalizar. Como ya documenta `ESTADO_MAESTRO_CONSOLIDACION.md`
("Nota sobre la Fase 11"), esto es categóricamente distinto de todo
lo demás en esta Orden: no es una limitación de stubs o hardware de
audio (rodeable con los stubs funcionales ya usados en GAP-036/037/
041/062/063/072/073) -- es una limitación de TIEMPO DE RELOJ que
ninguna sesión de chat puede sostener. Esa misma nota ya contemplaba,
como sustituto parcial explícitamente aceptado (opción 1): "muchos
frames sintéticos procesados rápido, no muchas horas de reloj".

Este archivo implementa exactamente eso -- un soak SINTÉTICO, no un
sustituto literal de las 50 horas de reloj real. Dos ejes, siguiendo
la descripción de la tarea ("DSP directo + ciclos repetidos"):

1. **DSP directo**: un volumen SOSTENIDO de audio sintético (miles de
   chunks reales, equivalente a varias horas de audio a 48kHz)
   procesado directamente contra `NRCoordinator` real, con una cadena
   de etapas REALMENTE activa (no el camino trivial sin nada
   seleccionado) -- buscando NaN/Inf que solo aparezcan tras mucho
   volumen (nunca en los tests cortos existentes, de unos pocos
   chunks) y crecimiento de memoria sin límite (indicio de una fuga
   real, no de la asignación normal de arranque).
2. **Ciclos repetidos**: muchas repeticiones REALES de arranque/cierre
   de `DiskWriterV2`/`ColaElasticaDisco` (extiende el patrón de
   GAP-064, que confirmó 40 corridas estables) y de `PlaybackEngine`
   (nunca ejercitado así antes) -- el equivalente sintético a "muchas
   horas de uso continuo": cada ciclo real de captura/reproducción que
   un usuario haría en una sesión de 50 horas deja huellas (hilos,
   descriptores de archivo, memoria) que una fuga real acumularía;
   repetir el ciclo cientos de veces en segundos hace visible esa
   acumulación sin necesitar el tiempo de reloj real.

Criterio de aceptación (igual en espíritu a §23/Suite F, adaptado a
lo verificable aquí): sin NaN/Inf, sin crecimiento de RAM sin límite
(pico de RSS que se estabiliza, no que crece linealmente hasta el
final), sin fuga de hilos (el conteo vuelve a la línea base tras cada
ciclo), sin excepciones no controladas.
"""

import gc
import os
import resource
import sys
import tempfile
import threading
import time
import unittest
import wave

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)
_ROOT_DIR = os.path.dirname(_TESTS_DIR)
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)

import numpy as np  # noqa: E402

from tests.test_stability_patch import _install_stub_modules  # noqa: E402
_install_stub_modules()

from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator  # noqa: E402

FS = 48000


def _peak_rss_kb() -> int:
    """Pico de RSS del proceso en KB (Linux: `ru_maxrss` ya viene en
    KB). Es un MÁXIMO monotono no decreciente -- perfecto para
    detectar fugas: si sigue subiendo de forma sostenida a lo largo de
    un soak que debería tener una huella de memoria estable, es una
    fuga real; si se estabiliza temprano, es la asignación normal de
    arranque (buffers, warm-up de imports, etc.)."""
    gc.collect()
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss


def _open_fd_count() -> int:
    """Número de descriptores de archivo abiertos del proceso actual
    (Linux -- `/proc/self/fd`) -- una fuga de `SoundFile`/`wave` sin
    cerrar se manifiesta aquí como crecimiento sostenido."""
    try:
        return len(os.listdir("/proc/self/fd"))
    except OSError:
        return -1  # no disponible (no-Linux) -- el test lo tolera


def _make_dynamic_chunk(rng, i, n_frames=4096, fs=FS):
    """Chunk estéreo REAL y cambiante -- nunca silencio ni ruido puro
    constante -- para que el chequeo de NaN/Inf ejercite rutas
    numéricas de verdad a lo largo de todo el volumen sintético (una
    señal estática podría dejar la cadena DSP asentada en un estado
    trivial que no representa uso real)."""
    t0 = i * n_frames / fs
    t = t0 + np.arange(n_frames, dtype=np.float64) / fs
    # Frecuencia y amplitud varían lentamente con i -- simula un
    # cassette real con contenido cambiante, no un tono fijo eterno.
    freq_l = 300.0 + 200.0 * np.sin(i * 0.01)
    freq_r = 500.0 + 250.0 * np.cos(i * 0.013)
    amp = 0.4 + 0.1 * np.sin(i * 0.007)
    left = amp * np.sin(2 * np.pi * freq_l * t)
    right = amp * np.sin(2 * np.pi * freq_r * t + 0.2)
    noise = rng.uniform(-0.02, 0.02, size=(n_frames, 2))
    sig = np.stack([left, right], axis=1) + noise
    return sig.astype(np.float32)


class TestSoakDSPDirectSustainedVolume(unittest.TestCase):
    """Eje 1: "DSP directo" -- volumen sintético sostenido, muy por
    encima de lo que ejercita cualquier test unitario/de integración
    existente (que procesan, como mucho, unos pocos segundos de
    audio)."""

    def test_light_active_chain_survives_hours_equivalent_volume(self):
        """Cadena REAL y activa (no el camino trivial): perfil NR
        `DNL` + ALC. Se elige deliberadamente uno de los perfiles más
        LIGEROS medidos (benchmark real: ~1.3ms/chunk de 4096 frames
        para DNL, frente a 17-46ms/chunk para Dolby B/C/S, DBX,
        ANRS o HX Pro/Muscle EQ en este sandbox) para poder sostener
        un volumen de VARIAS HORAS equivalentes dentro del presupuesto
        de tiempo de un test -- ver `test_heavier_chain_short_but_real`
        más abajo para una corrida más corta con una etapa más pesada,
        y GAP-074 para el hallazgo de que las etapas más caras corren
        más lento que tiempo real en este sandbox."""
        coord = NRCoordinator(sample_rate=FS, channels=2, mode="DECODE")
        coord.select("DNL")
        coord.set_alc(True)

        rng = np.random.default_rng(2026)
        n_chunks = 6000  # 6000*4096/48000 s ~= 512s ~= 8.5 min. de audio equivalente
        check_every = 500

        rss_samples = []
        for i in range(n_chunks):
            chunk = _make_dynamic_chunk(rng, i)
            out = coord.process_chunk(chunk)
            self.assertTrue(
                np.isfinite(out).all(),
                f"NaN/Inf real en el chunk #{i} tras volumen sostenido")
            if i % check_every == 0:
                total_nonfinite = sum(coord.nonfinite_counts.values())
                self.assertEqual(
                    total_nonfinite, 0,
                    f"saneamiento NaN/Inf real detectado en chunk #{i} "
                    "con entrada sintética limpia")
                rss_samples.append(_peak_rss_kb())

        # Crecimiento de memoria: comparar el promedio de la SEGUNDA
        # mitad de las muestras contra la PRIMERA mitad -- una fuga
        # real produce crecimiento sostenido de principio a fin; el
        # calentamiento normal de arranque se estabiliza temprano y no
        # sigue creciendo en la segunda mitad del volumen.
        half = len(rss_samples) // 2
        self.assertGreaterEqual(half, 2, "muy pocas muestras de RSS para juzgar")
        first_half_avg = sum(rss_samples[:half]) / half
        second_half_avg = sum(rss_samples[half:]) / (len(rss_samples) - half)
        growth_ratio = second_half_avg / max(first_half_avg, 1)
        self.assertLess(
            growth_ratio, 1.5,
            f"RSS creció {growth_ratio:.2f}x entre la primera y la "
            "segunda mitad del volumen sintético -- posible fuga real "
            f"(muestras: {rss_samples})")

        self.assertEqual(sum(coord.nonfinite_counts.values()), 0,
                         "saneamiento NaN/Inf real tras el volumen completo")

    def test_heavier_chain_short_but_real(self):
        """Complemento del test anterior: una etapa REALMENTE pesada
        (Muscle EQ, ~32ms/chunk medido) con un volumen mucho menor
        (unos pocos cientos de chunks, no miles) -- confirma que las
        etapas caras también se mantienen limpias (sin NaN/Inf) bajo
        uso sostenido, sin comprometer el presupuesto de tiempo del
        test. La lentitud de estas etapas frente a tiempo real
        (medida en GAP-074) es un hallazgo documentado, no algo que
        este test intente disimular con un volumen recortado sin
        avisar."""
        coord = NRCoordinator(sample_rate=FS, channels=2, mode="DECODE")
        coord.set_muscle_eq_active(True)
        coord.select("DOLBY_B")

        rng = np.random.default_rng(7)
        n_chunks = 150
        for i in range(n_chunks):
            chunk = _make_dynamic_chunk(rng, i)
            out = coord.process_chunk(chunk)
            self.assertTrue(np.isfinite(out).all(),
                            f"NaN/Inf real en chunk #{i} (cadena pesada)")

        self.assertEqual(sum(coord.nonfinite_counts.values()), 0)


class TestSoakRepeatedCaptureWriteCycles(unittest.TestCase):
    """Eje 2a: "ciclos repetidos" -- extiende el patrón de GAP-064
    (que confirmó 40 corridas estables de `ColaElasticaDisco`/
    `DiskWriterV2`) a un volumen mayor de repeticiones, con
    verificación explícita de hilos/descriptores/memoria en vez de
    solo "no crashea"."""

    def setUp(self):
        import lorito_aldhiro.backend.capture.lorito_capture_engine as ce_mod
        self._ce_mod = ce_mod
        self._orig_soundfile = getattr(ce_mod.sf, "SoundFile", None)
        self._tmpdir = tempfile.mkdtemp(prefix="lorito_soak_cap_")

    def tearDown(self):
        self._ce_mod.sf.SoundFile = self._orig_soundfile
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def test_40_real_write_cycles_do_not_leak_threads_or_fds(self):
        from lorito_aldhiro.backend.capture.lorito_capture_engine import (
            ColaElasticaDisco, DiskWriterV2, CaptureEngineStatus,
        )

        class _RealWaveSoundFile:
            def __init__(self, path, mode="w", samplerate=48000, channels=2,
                        subtype="PCM_24", format="WAV"):
                self._wf = wave.open(path, "wb")
                self._wf.setnchannels(channels)
                self._wf.setsampwidth(3)
                self._wf.setframerate(samplerate)
                self._closed = False

            def write(self, block):
                pcm32 = np.clip(np.round(np.clip(block, -1.0, 1.0) * 8388608.0),
                                -8388608, 8388607).astype(np.int32)
                u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
                self._wf.writeframesraw(np.ascontiguousarray(u8[:, 0:3]).tobytes())

            def flush(self):
                pass

            def close(self):
                if not self._closed:
                    self._wf.close()
                    self._closed = True

        self._ce_mod.sf.SoundFile = _RealWaveSoundFile

        # Línea base DESPUÉS del primer ciclo de calentamiento (los
        # primeros hilos daemon de Python/logging pueden tardar un
        # ciclo en asentarse) -- evita un falso positivo de "creció"
        # que en realidad es solo el arranque normal del proceso.
        baseline_threads = None
        rss_samples = []
        # NOTA (GAP-074): 40 ciclos (no 100) -- cada ciclo paga ~0.5s
        # reales entre `flush()` (bloqueado por diseño mientras el hilo
        # sigue vivo, ver nota arriba) y `stop()` (join real del hilo
        # de escritura) -- el mismo recuento ya validado como estable
        # en GAP-064, ahora con verificación explícita de hilos/RSS en
        # vez de solo "no crashea", sin pagar un costo de tiempo
        # desproporcionado dentro de una sesión de cierre.
        n_cycles = 40

        for cycle in range(n_cycles):
            path = os.path.join(self._tmpdir, f"seg_{cycle}.wav")
            status = CaptureEngineStatus()
            ced = ColaElasticaDisco(capacity=200_000)
            writer = DiskWriterV2(ced, status)

            writer.start(path, rate=48000, channels=2)
            block = np.ones((2000, 2), dtype=np.float32) * 0.1
            ced.put_nowait(block)
            # NOTA (GAP-074): `flush()` acota su espera de `_flush_done`
            # (que solo se marca cuando el hilo TERMINA, ver GAP-064) a
            # `min(timeout, CE_DISK_FLUSH_SETTLE_MAX_S=2.0s)` -- con el
            # hilo todavía vivo aquí (igual que el único llamador real
            # documentado en GAP-064), ese margen se consume COMPLETO en
            # cada ciclo. Un bloque de 2000 frames se vacía de la cola en
            # milisegundos reales, así que 0.15s de margen sobra de sobra
            # (mismo criterio que el propio docstring de `flush()`) sin
            # pagar el costo de 2s×100 ciclos = 200s+ solo en esta espera.
            writer.flush(timeout=0.15)
            writer.stop()

            self.assertEqual(status.frames_dropped, 0)
            self.assertEqual(status.frames_written, 2000)

            if cycle == 0:
                baseline_threads = threading.active_count()
            elif cycle % 10 == 0:
                cur_threads = threading.active_count()
                self.assertLessEqual(
                    cur_threads, baseline_threads + 2,
                    f"conteo de hilos creció de {baseline_threads} a "
                    f"{cur_threads} tras {cycle} ciclos reales de "
                    "escritura -- posible fuga de hilos real")
                rss_samples.append(_peak_rss_kb())

        # Confirmar que el conteo de hilos al FINAL vuelve a la línea
        # base -- ningún hilo de escritura debe quedar vivo tras
        # `stop()` (mismo criterio que GAP-064, que validó 40 ciclos
        # estables solo por conteo de hilos; aquí además se rastrea
        # RSS explícitamente).
        time.sleep(0.05)
        final_threads = threading.active_count()
        self.assertLessEqual(
            final_threads, baseline_threads + 1,
            f"quedaron hilos vivos tras {n_cycles} ciclos reales: "
            f"base={baseline_threads}, final={final_threads}")

        half = len(rss_samples) // 2
        if half >= 1:
            first_half_avg = sum(rss_samples[:half]) / half
            second_half_avg = sum(rss_samples[half:]) / (len(rss_samples) - half)
            growth_ratio = second_half_avg / max(first_half_avg, 1)
            self.assertLess(
                growth_ratio, 1.5,
                f"RSS creció {growth_ratio:.2f}x entre la primera y la "
                f"segunda mitad de {n_cycles} ciclos de escritura real -- "
                f"posible fuga (muestras: {rss_samples})")


class TestSoakRepeatedPlaybackCycles(unittest.TestCase):
    """Eje 2b: "ciclos repetidos" sobre `PlaybackEngine` -- nunca
    ejercitado así antes (los tests existentes de GAP-062/063/072/073
    instancian el motor una vez por test, no en un bucle largo de
    arranque/cierre real)."""

    def setUp(self):
        from _functional_soundfile_stub import install_functional_soundfile_stub
        install_functional_soundfile_stub()
        from _functional_sounddevice_output_stub import (
            install_functional_sounddevice_output_stub,
        )
        install_functional_sounddevice_output_stub(callback_interval=0.0)

        import lorito_aldhiro.backend.playback.lorito_playback_engine as pe
        pe.sd = sys.modules["sounddevice"]
        pe.sf = sys.modules["soundfile"]
        self._pe = pe

        from _functional_soundfile_stub import FunctionalSoundFile
        self._tmpdir = tempfile.mkdtemp(prefix="lorito_soak_pb_")
        self._path = os.path.join(self._tmpdir, "seg.wav")
        n_frames = 24_000  # 0.5s -- ciclos cortos a propósito, son MUCHOS
        t = np.arange(n_frames, dtype=np.float64) / FS
        sig = np.stack([
            0.4 * np.sin(2 * np.pi * 440.0 * t),
            0.3 * np.sin(2 * np.pi * 660.0 * t),
        ], axis=1).astype(np.float32)
        with FunctionalSoundFile(self._path, "w", samplerate=FS, channels=2) as f:
            f.write(sig)

    def tearDown(self):
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def _wait_until(self, predicate, timeout=3.0, interval=0.005):
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout:
            if predicate():
                return True
            time.sleep(interval)
        return predicate()

    def test_40_real_start_stop_cycles_do_not_leak_threads(self):
        pe = self._pe
        engine = pe.PlaybackEngine()
        baseline_threads = None
        n_cycles = 40

        try:
            for cycle in range(n_cycles):
                engine.start(
                    path=self._path, rate=FS, channels=2,
                    start_frame=0, speed_ratio=1.0, on_done=None,
                )
                started = self._wait_until(lambda: engine.is_active(), timeout=3.0)
                self.assertTrue(started,
                                f"el ciclo #{cycle} no arrancó a tiempo")
                time.sleep(0.02)  # deja correr unos callbacks reales
                engine.stop()
                self.assertFalse(engine.is_active(),
                                 f"el ciclo #{cycle} no se detuvo limpio")

                if cycle == 0:
                    baseline_threads = threading.active_count()
                elif cycle % 10 == 0:
                    cur = threading.active_count()
                    self.assertLessEqual(
                        cur, baseline_threads + 2,
                        f"conteo de hilos creció de {baseline_threads} a "
                        f"{cur} tras {cycle} ciclos reales de "
                        "PlaybackEngine -- posible fuga de hilos real")
        finally:
            engine.stop()

        time.sleep(0.05)
        final_threads = threading.active_count()
        self.assertLessEqual(
            final_threads, baseline_threads + 1,
            f"quedaron hilos vivos tras {n_cycles} ciclos reales de "
            f"PlaybackEngine: base={baseline_threads}, final={final_threads}")


if __name__ == "__main__":
    unittest.main()
