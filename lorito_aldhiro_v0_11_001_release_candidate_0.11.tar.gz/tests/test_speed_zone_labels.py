"""
test_speed_zone_labels.py — GAP-062, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Verifica `backend/playback/lorito_speed_zone_labels.py` — la
extracción MECÁNICA de `PlaybackMixin._speed_zone_coded_name()`
(antes en `lorito_mw_playback.py`), mismo patrón de GAP-056
(`lorito_export_session_spec.py`): sin cobertura de test alguna antes
de esta extracción pese a estar activamente en uso (overlay real del
Scrub Velocista). El estándar de estos tests es exacto en cada
FRONTERA de zona documentada, no solo un valor representativo por
zona — incluida la corrección explícita del usuario sobre el texto
real de la zona Aguilar ("Aguilr", no "Aguilar").
"""

import unittest

from lorito_aldhiro.backend.playback.lorito_speed_zone_labels import (
    speed_zone_coded_name,
)


class TestNeutralZone(unittest.TestCase):
    def test_ratio_exactly_1_0_is_neutral(self):
        self.assertEqual(speed_zone_coded_name(1.0), "")

    def test_ratio_just_inside_neutral_band_is_neutral(self):
        # |ratio - 1.0| < 0.005
        self.assertEqual(speed_zone_coded_name(1.0049), "")
        self.assertEqual(speed_zone_coded_name(0.9951), "")

    def test_ratio_just_outside_neutral_band_is_not_neutral(self):
        # Nota de precisión de punto flotante: 1.005 - 1.0 representa
        # en float64 como ~0.0049999999998927, que SÍ es < 0.005 — por
        # eso se usa 1.006/0.994 aquí (claramente fuera de la banda),
        # no el borde matemático exacto (ver test_calibrante_just_above_neutral
        # para el comportamiento verificado justo en ese borde).
        self.assertNotEqual(speed_zone_coded_name(1.006), "")
        self.assertNotEqual(speed_zone_coded_name(0.994), "")


class TestFasterThanNormalZones(unittest.TestCase):
    def test_calibrante_just_above_neutral(self):
        # 1.005 exacto cae DENTRO de la zona neutra por representación
        # de punto flotante (1.005-1.0 ≈ 0.0049999... < 0.005) — mismo
        # comportamiento del código original, documentado aquí en vez
        # de asumido; 1.006 es el primer valor claramente en CaLibrt.
        self.assertEqual(speed_zone_coded_name(1.005), "")
        self.assertEqual(speed_zone_coded_name(1.006), "CaLibrt")
        self.assertEqual(speed_zone_coded_name(1.05), "CaLibrt")
        self.assertEqual(speed_zone_coded_name(1.1099), "CaLibrt")

    def test_verilucha_at_1_11_boundary(self):
        self.assertEqual(speed_zone_coded_name(1.11), "VerLcha")
        self.assertEqual(speed_zone_coded_name(1.30), "VerLcha")
        self.assertEqual(speed_zone_coded_name(1.4099), "VerLcha")

    def test_pactorald_at_1_41_boundary(self):
        self.assertEqual(speed_zone_coded_name(1.41), "JayaquTe")
        self.assertEqual(speed_zone_coded_name(1.50), "JayaquTe")
        self.assertEqual(speed_zone_coded_name(1.6099), "JayaquTe")

    def test_pactorald_plus_at_1_61_boundary(self):
        self.assertEqual(speed_zone_coded_name(1.61), "UltrJayaqute")
        self.assertEqual(speed_zone_coded_name(2.0), "UltrJayaqute")
        self.assertEqual(speed_zone_coded_name(10.0), "UltrJayaqute")


class TestSlowerThanNormalZones(unittest.TestCase):
    def test_calibrante_just_below_neutral(self):
        self.assertEqual(speed_zone_coded_name(0.995), "CaLibrt")
        self.assertEqual(speed_zone_coded_name(0.95), "CaLibrt")
        self.assertEqual(speed_zone_coded_name(0.90), "CaLibrt")

    def test_aguilar_at_0_70_to_0_899_boundary(self):
        # Corrección explícita del usuario: overlay real "Aguilr", no "Aguilar".
        self.assertEqual(speed_zone_coded_name(0.8999), "Aguilr")
        self.assertEqual(speed_zone_coded_name(0.80), "Aguilr")
        self.assertEqual(speed_zone_coded_name(0.70), "Aguilr")

    def test_cromantina_at_0_60_to_0_699_boundary(self):
        self.assertEqual(speed_zone_coded_name(0.6999), "CromTn")
        self.assertEqual(speed_zone_coded_name(0.65), "CromTn")
        self.assertEqual(speed_zone_coded_name(0.60), "CromTn")

    def test_superprador_below_0_60(self):
        self.assertEqual(speed_zone_coded_name(0.5999), "SupRpdr")
        self.assertEqual(speed_zone_coded_name(0.55), "SupRpdr")
        self.assertEqual(speed_zone_coded_name(0.50), "SupRpdr")


class TestAllSevenCodedNamesAreReachable(unittest.TestCase):
    """Regresión de registro: los 7 nombres codificados deben coincidir
    EXACTAMENTE con las claves fijas en
    `backend/export/lorito_overlay_registry.py` (SEEK_YNG/SC_CUE/SC_REW
    son de otros controles, no de este — los 7 de Velocista son los
    que se listan aquí)."""

    EXPECTED_NAMES = {
        "CaLibrt", "Aguilr", "CromTn", "SupRpdr",
        "VerLcha", "JayaquTe", "UltrJayaqute",
    }

    def test_representative_ratio_per_zone_covers_all_seven_names(self):
        ratios = [1.05, 1.20, 1.50, 2.0, 0.95, 0.80, 0.65, 0.55]
        produced = {speed_zone_coded_name(r) for r in ratios} - {""}
        self.assertEqual(produced, self.EXPECTED_NAMES)


if __name__ == "__main__":
    unittest.main()
