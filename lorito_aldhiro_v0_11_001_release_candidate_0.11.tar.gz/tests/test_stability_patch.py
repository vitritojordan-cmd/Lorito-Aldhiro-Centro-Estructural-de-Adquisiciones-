"""
Ejercita `apply_stability_patch()` contra el código REAL de Lorito Aldhiro
(no una copia sintética) instalando stubs mínimos de `soundfile`,
`sounddevice` y `PySide6` en `sys.modules` — mismo patrón
`_DummyQtModule`/`_DummyQtObj` ya usado en el proyecto hermano (CRAC)
para poder importar módulos que dependen de Qt/audio reales sin tenerlos
instalados en el sandbox de verificación.

Los stubs son deliberadamente permisivos (devuelven objetos dummy para
cualquier atributo pedido) — no simulan comportamiento de audio/Qt real,
solo permiten que el CÓDIGO FUENTE de Lorito Aldhiro se importe y se
pueda inspeccionar con `inspect.getsource()`, que es todo lo que
`apply_stability_patch()` necesita.

Ejecutar: python3 -m unittest tests.test_stability_patch -v
"""

import os
import sys
import types
import unittest


def _install_stub_modules():
    """Instala stubs mínimos si los paquetes reales no están disponibles.
    No pisa un import real si ya existe (p. ej. en un entorno con
    PySide6/soundfile reales, donde esto es un no-op)."""

    class _DummyAttr:
        """Objeto comodín: cualquier atributo/llamada/subclase devuelve
        otro `_DummyAttr`. Suficiente para que el código se IMPORTE
        (definiciones de clase, decoradores, constantes) sin ejecutar
        comportamiento real de audio/Qt."""
        def __init__(self, *a, **k): pass
        def __call__(self, *a, **k): return _DummyAttr()
        def __getattr__(self, name): return _DummyAttr()
        def __or__(self, other): return self
        def __ror__(self, other): return self

    def _make_dummy_module(name):
        mod = types.ModuleType(name)
        mod.__getattr__ = lambda attr: _DummyAttr()  # type: ignore[attr-defined]
        return mod

    if "soundfile" not in sys.modules:
        try:
            import soundfile  # noqa: F401
        except ImportError:
            sys.modules["soundfile"] = _make_dummy_module("soundfile")

    if "sounddevice" not in sys.modules:
        try:
            import sounddevice  # noqa: F401
        except (ImportError, OSError):
            sys.modules["sounddevice"] = _make_dummy_module("sounddevice")

    if "PySide6" not in sys.modules:
        try:
            import PySide6  # noqa: F401
        except ImportError:
            for sub in ("PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets"):
                sys.modules[sub] = _make_dummy_module(sub)

            class _QObjectStub:
                def __init__(self, *a, **k): pass
                def __getattr__(self, name): return _DummyAttr()

            class _SignalStub:
                """Signal/slot mínimo pero real: `connect()` guarda el
                callback, `emit()` lo invoca — suficiente para probar
                lógica de exclusión mutua entre widgets sin PySide6 real.

                GAP-060: `emit()` trunca los argumentos a la aridad real
                del callback antes de invocarlo — replica el
                comportamiento genuino de Qt, donde un slot conectado a
                una señal puede aceptar MENOS parámetros de los que la
                señal emite (Qt descarta los sobrantes; es un patrón
                válido y común, no un error — p. ej. `currentTextChanged
                .connect(self._update_codec_ui)` con un slot que no
                necesita el texto). Antes, `emit()` pasaba siempre TODOS
                los argumentos sin importar la firma del callback,
                lanzando un `TypeError` real ante ese patrón — un falso
                positivo de la infraestructura de test, no un defecto
                del código bajo prueba."""
                def __init__(self):
                    self._callbacks = []
                def connect(self, fn):
                    self._callbacks.append(fn)
                def emit(self, *args):
                    import inspect
                    for fn in list(self._callbacks):
                        try:
                            sig = inspect.signature(fn)
                            params = list(sig.parameters.values())
                            has_var_positional = any(
                                p.kind is inspect.Parameter.VAR_POSITIONAL
                                for p in params)
                            if has_var_positional:
                                call_args = args
                            else:
                                n_positional = sum(
                                    1 for p in params
                                    if p.kind in (inspect.Parameter.POSITIONAL_ONLY,
                                                  inspect.Parameter.POSITIONAL_OR_KEYWORD))
                                call_args = args[:n_positional]
                        except (TypeError, ValueError):
                            # No se pudo introspeccionar (p. ej. algunos
                            # builtins) — mejor esfuerzo: pasar todo,
                            # igual que el comportamiento anterior.
                            call_args = args
                        fn(*call_args)

            class _QWidgetStubMeta(type):
                """Cualquier atributo de CLASE no definido explícitamente
                (p. ej. QSizePolicy.Fixed, QToolButton.InstantPopup,
                QFont.Weight.Normal) devuelve un valor comodín en vez de
                lanzar AttributeError — necesario porque Qt usa constantes
                de enum accedidas directamente sobre la clase en todo su
                código idiomático."""
                def __getattr__(cls, name):
                    return _DummyAttr()

            class _QWidgetStub(_QObjectStub, metaclass=_QWidgetStubMeta):
                def __init__(self, *a, **k):
                    self._visible = True
                def setVisible(self, v): self._visible = v
                def isVisible(self): return self._visible
                def setObjectName(self, n): self._object_name = n
                def setStyleSheet(self, s): pass
                def setGeometry(self, *a): pass
                def setFixedSize(self, *a): pass
                def setFixedWidth(self, *a): pass
                def setFixedHeight(self, *a): pass
                def accept(self): pass
                def reject(self): pass
                def exec(self): pass
                def exec_(self): pass

            class _QComboBoxStub(_QWidgetStub):
                """Estado real de lista + índice — suficiente para
                ejercitar addItem/currentText/findText/setCurrentIndex/
                blockSignals/currentTextChanged tal como los usa
                LoritoExportadorDialog de verdad."""
                def __init__(self, *a, **k):
                    super().__init__(*a, **k)
                    self._items: list = []
                    self._data: list = []
                    self._current_index = -1
                    self._blocked = False
                    self.currentTextChanged = _SignalStub()
                    self.currentIndexChanged = _SignalStub()
                def addItem(self, text, userData=None):
                    self._items.append(text)
                    self._data.append(userData)
                    if self._current_index == -1:
                        self._current_index = 0
                def addItems(self, texts):
                    for t in texts:
                        self.addItem(t)
                def count(self):
                    return len(self._items)
                def itemText(self, i):
                    return self._items[i] if 0 <= i < len(self._items) else ""
                def itemData(self, i):
                    return self._data[i] if 0 <= i < len(self._data) else None
                def findData(self, data):
                    try:
                        return self._data.index(data)
                    except ValueError:
                        return -1
                def currentText(self):
                    if 0 <= self._current_index < len(self._items):
                        return self._items[self._current_index]
                    return ""
                def currentIndex(self):
                    return self._current_index
                def setCurrentIndex(self, i):
                    if i == self._current_index:
                        return
                    self._current_index = i
                    if not self._blocked:
                        self.currentTextChanged.emit(self.currentText())
                        self.currentIndexChanged.emit(i)
                def setCurrentText(self, text):
                    idx = self.findText(text)
                    if idx >= 0:
                        self.setCurrentIndex(idx)
                def findText(self, text):
                    try:
                        return self._items.index(text)
                    except ValueError:
                        return -1
                def blockSignals(self, b):
                    prev, self._blocked = self._blocked, b
                    return prev

            class _QLineEditStub(_QWidgetStub):
                def __init__(self, initial="", *a, **k):
                    super().__init__(*a, **k)
                    self._text = initial if isinstance(initial, str) else ""
                def text(self): return self._text
                def setText(self, t): self._text = t
                def setPlaceholderText(self, t): pass

            class _QLabelStub(_QWidgetStub):
                def __init__(self, text="", *a, **k):
                    super().__init__(*a, **k)
                    self._text = text if isinstance(text, str) else ""
                def text(self): return self._text
                def setText(self, t): self._text = t
                def setWordWrap(self, w): pass
                def setAlignment(self, a): pass

            # Todas las clases de QtWidgets deben ser subclasseables (los
            # widgets propios de Lorito Aldhiro heredan de QWidget,
            # QDialog, QPushButton, QFrame, etc. indistintamente) — en vez
            # de enumerar cada una, cualquier atributo pedido a QtWidgets
            # devuelve la MISMA clase stub subclasseable, EXCEPTO las
            # marcadas abajo con estado real (QComboBox/QLineEdit/QLabel).
            _real_stubs = {
                "QComboBox": _QComboBoxStub,
                "QLineEdit": _QLineEditStub,
                "QLabel": _QLabelStub,
            }
            sys.modules["PySide6.QtWidgets"].__getattr__ = (
                lambda attr: _real_stubs.get(attr, _QWidgetStub))
            sys.modules["PySide6.QtCore"].QObject = _QObjectStub
            sys.modules["PySide6.QtCore"].Signal = lambda *a, **k: _SignalStub()


class TestStabilityPatchAudit(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        _install_stub_modules()

    def test_apply_stability_patch_runs_without_raising(self):
        from lorito_aldhiro.backend.core.lorito_stability_patch import apply_stability_patch
        result = apply_stability_patch(verbose=False)
        for key in ("confirmed", "applied_this_session", "deferred", "unknown"):
            self.assertIn(key, result)
            self.assertIsInstance(result[key], list)

    def test_d4_and_e3_confirmed_applied_against_real_source(self):
        """Verifica, contra el código fuente REAL (no una copia), que los
        dos fixes aplicados en esta sesión (D-4, E-3) se detectan."""
        from lorito_aldhiro.backend.core.lorito_stability_patch import apply_stability_patch
        result = apply_stability_patch(verbose=False)
        applied_joined = " | ".join(result["applied_this_session"])
        self.assertIn("D-4", applied_joined, msg=f"unknown={result['unknown']}")
        self.assertIn("E-3", applied_joined, msg=f"unknown={result['unknown']}")

    def test_k1_k2_not_falsely_applied_regression_guard(self):
        """K-1/K-2 nunca deben aparecer como 'aplicados' — Lorito Aldhiro
        tiene una especificación MÁS reciente que la que esos parches
        asumen; aplicarlos sería un retroceso (ver GAP-009)."""
        from lorito_aldhiro.backend.core.lorito_stability_patch import apply_stability_patch
        result = apply_stability_patch(verbose=False)
        applied_joined = " | ".join(result["applied_this_session"])
        self.assertNotIn("K-1", applied_joined)
        self.assertNotIn("K-2", applied_joined)

    def test_h2_not_reverted(self):
        """H-2 no debe forzar PE_SPEED_DEBOUNCE a 0.005 — Lorito Aldhiro
        lo cambió deliberadamente a 0.030 por FIX-DOUBLE-FLUSH."""
        from lorito_aldhiro.backend.playback import lorito_playback_engine as _pe
        self.assertEqual(_pe.PE_SPEED_DEBOUNCE, 0.030)


class TestCheckSourceContainsHelper(unittest.TestCase):
    """Prueba el helper de detección de forma aislada, sin depender de
    ningún módulo real de Lorito Aldhiro."""

    def test_detects_marker_present(self):
        from lorito_aldhiro.backend.core.lorito_stability_patch import _check_source_contains

        class _Fake:
            def method(self):
                # FIX-EJEMPLO
                return 1

        self.assertTrue(_check_source_contains(_Fake, "method", "FIX-EJEMPLO"))
        self.assertFalse(_check_source_contains(_Fake, "method", "MARCADOR-INEXISTENTE"))

    def test_missing_method_returns_false_not_raise(self):
        from lorito_aldhiro.backend.core.lorito_stability_patch import _check_source_contains

        class _Fake:
            pass

        self.assertFalse(_check_source_contains(_Fake, "no_existe", "X"))


if __name__ == "__main__":
    unittest.main()
