"""
test_status_fix_real_execution.py — GAP-057, seguimiento de GAP-056
(Orden de Saneamiento, Integración y Consolidación de Lorito Aldhiro).

GAP-056 corrigió el `_status` sin importar en 4 archivos (112 usos) y
lo verificó de punta a punta SOLO en la ruta de exportación (el test
end-to-end que encontró el bug). Quedó pendiente, explícitamente,
confirmar con ejecución real que los otros 3 archivos (`lorito_mw_
recording.py`, `lorito_mw_telemetry.py`, `lorito_mw_silence_
autopause.py`) también funcionan tras el fix — no solo que el import
no lance error al cargar el módulo (eso ya lo cubre `test_status_
global_is_imported_everywhere_it_is_used`), sino que los métodos que
de verdad ejecutan esas líneas corran limpios.

Hallazgo de esta sesión, documentado aquí porque motiva por qué estos
tests importan: `_update_internal_status()`/`_archival_tick()` están
conectados a `QTimer` reales (1 Hz y cada 5 s respectivamente,
arrancados incondicionalmente en `__init__` de `LoritoAldhiroStudio`,
ver `lorito_main_window.py`) — antes del fix, esto habría producido un
`NameError` recurrente, indefinidamente, durante TODA sesión de uso
real de la aplicación, no solo al exportar. `start_record()` resetea
`_status.frames_received`/etc. como una de sus primeras operaciones —
antes del fix, iniciar una grabación real también habría fallado.

Instancia `LoritoAldhiroStudio()` real bajo los mismos stubs que el
resto de la batería (GAP-036/041/051/056). `app.waveform.clearWave`/
`setMode` se sustituyen por no-ops en el test que llama a
`start_record()` — limitación conocida y no relacionada del stub
dummy de `WaveformDisplay` (`hasattr`/`delattr` no se llevan bien con
un mock genérico), no algo relacionado con `_status`.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests._functional_soundfile_stub import install_functional_soundfile_stub
install_functional_soundfile_stub()

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
import soundfile as _sf_functional  # noqa: E402
mw.sf = sys.modules["soundfile"]


class TestStatusFixAcrossAllAffectedMethods(unittest.TestCase):
    """Cada test llama al método REAL (no una copia/reimplementación) y
    solo pasa si NO se lanza ninguna excepción — antes del fix de
    GAP-056, cada uno de estos lanzaba `NameError: name '_status' is
    not defined` de forma determinista."""

    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()
        # Limitación del stub dummy de WaveformDisplay, no relacionada
        # con _status — ver docstring del módulo.
        self.app.waveform.clearWave = lambda: None
        self.app.waveform.setMode = lambda *a, **k: None

    def test_start_record_resets_status_counters_without_nameerror(self):
        self.app.start_record()
        # No solo "no lanzó" — confirma que de verdad tocó _status
        # (evidencia de que la línea se ejecutó, no que se saltó).
        from lorito_aldhiro.backend.audio.lorito_audio_backend import _status
        self.assertEqual(_status.frames_received, 0)
        self.assertEqual(_status.frames_dropped, 0)

    def test_update_internal_status_runs_clean(self):
        # Timer real de 1 Hz (`_timer_status`, lorito_main_window.py) —
        # antes del fix, esto fallaba cada segundo de uso real de la app.
        self.app._update_internal_status()

    def test_archival_tick_runs_clean(self):
        # Timer real de 5 s (`_timer_archival`) — 32 usos de _status en
        # este único método, el de mayor concentración de los 4 archivos.
        self.app._archival_tick()

    def test_activate_and_deactivate_silence_autopause_run_clean(self):
        self.app._activate_silence_autopause()
        self.app._deactivate_silence_autopause()

    def test_toggle_pause_runs_clean(self):
        self.app.toggle_pause()

    def test_on_rec_engine_ready_runs_clean(self):
        self.app._on_rec_engine_ready(True)
        self.app._on_rec_engine_ready(False)


if __name__ == "__main__":
    unittest.main()
