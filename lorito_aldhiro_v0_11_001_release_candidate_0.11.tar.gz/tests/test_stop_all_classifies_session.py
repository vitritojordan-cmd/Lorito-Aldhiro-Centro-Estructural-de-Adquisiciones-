"""
test_stop_all_classifies_session.py — GAP-061, FASE 2 (§8) de la
Orden Maestra de Saneamiento, Integración y Consolidación de Lorito
Aldhiro.

Verifica que `stop_all()` ahora llama a `CaptureEngineV2.classify_
session()` (FASE 2, GAP-052) como parte OBLIGATORIA del cierre de
sesión — pendiente explícito desde GAP-052, cerrado en GAP-061.

No dispara el ciclo real de hilos de `DiskWriterV2.flush()`/`.stop()`
— GAP-052 documentó una fragilidad de timing real en ese camino. Los
segmentos se pueblan directamente (mismo patrón seguro ya establecido
en GAP-052/055 para `CaptureEngineV2`), y `flush()`/`stop()` se
sustituyen por no-ops — los segmentos ya están "cerrados" por
construcción, no hace falta que el mecanismo real de cierre corra para
verificar el CABLEADO de `classify_session()` al flujo de `stop_all()`.
"""

import os
import sys
import tempfile
import threading
import time
import unittest
import wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from tests._functional_soundfile_stub import install_functional_soundfile_stub
install_functional_soundfile_stub()

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402
import soundfile as _sf_functional  # noqa: E402
from lorito_aldhiro.backend.archival import ArchivalState  # noqa: E402
from lorito_aldhiro.backend.archival.lorito_segment_checksum import (
    compute_segment_checksum,
)  # noqa: E402

mw.sf = sys.modules["soundfile"]


def _write_real_segment(path, rate=48000, channels=2, n_frames=1000, seed=1):
    rng = np.random.default_rng(seed)
    audio = rng.uniform(-0.3, 0.3, size=(n_frames, channels)).astype(np.float32)
    pcm32 = (np.clip(audio, -1.0, 1.0) * 8388607.0).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    pcm24_bytes = np.ascontiguousarray(u8[:, 0:3]).tobytes()
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(3)
        wf.setframerate(rate)
        wf.writeframesraw(pcm24_bytes)


class TestStopAllCallsClassifySession(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_stopall_archival_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def _run_stop_all(self, n_segments=2, corrupt_last=False):
        app = mw.LoritoAldhiroStudio()
        paths, checksums = [], []
        for i in range(n_segments):
            p = os.path.join(self.tmpdir, f"seg{i:04d}.wav")
            _write_real_segment(p, n_frames=1000, seed=100 + i)
            paths.append(p)
            checksums.append(compute_segment_checksum(p))
        if corrupt_last:
            with open(paths[-1], "r+b") as f:
                f.seek(60)
                b = f.read(1)
                f.seek(60)
                f.write(bytes([b[0] ^ 0xFF]))
            # NO recalcular checksums[-1] aquí — el checksum guardado
            # (calculado ANTES de corromper, arriba en el bucle) debe
            # seguir siendo el "esperado" contra el que classify_session()
            # compara; si se recalculara ahora coincidiría con el
            # contenido YA corrupto y la prueba no probaría nada.

        app._engine._disk_writer._segment_paths = paths
        app._engine._disk_writer._segment_checksums = checksums
        app._engine._status.frames_received = n_segments * 1000
        app._engine._status.frames_written = n_segments * 1000
        app._engine.recording = True
        app._disk_tmp_path = paths[0]

        # Los segmentos ya están "cerrados" por construcción — no hace
        # falta el ciclo real de hilos de flush()/stop() (fragilidad
        # documentada en GAP-052) para verificar el cableado de
        # classify_session().
        app._engine._disk_writer.flush = lambda timeout=30.0, progress_cb=None: None
        app._engine._disk_writer.stop = lambda: None
        app._engine._disk_writer.get_path = lambda: paths[0]

        before_threads = set(threading.enumerate())
        app.stop_all()

        # Ventana de carrera real entre `Thread.start()` (que retorna en
        # el hilo padre) y que el hilo nuevo se registre a sí mismo en
        # `threading.enumerate()` (ocurre dentro de `_bootstrap_inner`,
        # en el hilo hijo) — sondear brevemente en vez de una sola
        # comprobación inmediata evita un falso negativo intermitente.
        stop_threads = []
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            new_threads = [t for t in threading.enumerate() if t not in before_threads]
            stop_threads = [t for t in new_threads if t.name == "aecct2-stop"]
            if stop_threads:
                break
            time.sleep(0.01)
        self.assertEqual(len(stop_threads), 1,
                         "stop_all() debía lanzar exactamente 1 hilo aecct2-stop")
        stop_threads[0].join(timeout=10)
        self.assertFalse(stop_threads[0].is_alive(), "el hilo de stop no terminó a tiempo")
        return app

    def test_healthy_session_gets_classified_as_archival_safe(self):
        app = self._run_stop_all(n_segments=3)

        self.assertTrue(hasattr(app, "_last_archival_classification"))
        result = app._last_archival_classification
        self.assertIsNotNone(result, "classify_session() no corrió durante stop_all()")
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertTrue(result.checksum_verified)
        self.assertEqual(result.segments_expected, 3)

    def test_corrupted_session_gets_classified_as_invalid(self):
        app = self._run_stop_all(n_segments=2, corrupt_last=True)

        result = app._last_archival_classification
        self.assertIsNotNone(result)
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertEqual(result.segments_invalid, 1)


if __name__ == "__main__":
    unittest.main()
