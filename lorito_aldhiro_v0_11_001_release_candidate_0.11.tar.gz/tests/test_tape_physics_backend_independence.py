"""
test_tape_physics_backend_independence.py — GAP-054, FASE 8
("Backend/frontend separation", §14) de la Orden Maestra de
Saneamiento, Integración y Consolidación de Lorito Aldhiro.

Antes de esta fase, `backend/playback/lorito_tape_physics.py` tenía un
import a nivel de módulo de `lorito_aldhiro.frontend.integration.
lorito_itl_bridge` (`_ITL_AVAILABLE`) — una dependencia backend→frontend
prohibida por §14, y además una bandera que no tenía relación real con
lo que efectivamente se usaba (el plugin externo opcional `aecct2_itl_
integration`, nunca incluido en el tarball). Este test verifica DOS
cosas con ejecución real, no solo lectura del código:

  1. El módulo importa y se usa sin que `lorito_aldhiro.frontend` (ni
     PySide6) esté disponible en absoluto — la prueba de independencia
     real: se ejecuta en un subproceso limpio con `sys.modules`
     purgado de cualquier cosa relacionada con frontend/PySide6.
  2. El comportamiento observable NO cambió: sin el plugin externo
     `aecct2_itl_integration` (que no existe en este tarball, igual
     que antes de esta fase), `CassetteTransportPhysics` sigue
     cayendo en la física simplificada (`_itl_active == False`) —
     mismo resultado que antes del fix, verificado explícitamente en
     vez de solo asumido.
"""

import os
import subprocess
import sys
import textwrap
import unittest

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestTapePhysicsImportsWithoutFrontend(unittest.TestCase):
    def test_module_imports_and_instantiates_in_subprocess_without_any_frontend_or_pyside6(self):
        # Subproceso limpio (no el intérprete de este test runner, que
        # puede tener PySide6/frontend ya cacheados en sys.modules por
        # otros tests que corrieron antes) — la prueba real de
        # independencia es que esto funcione en un Python recién
        # arrancado, sin ningún stub instalado a propósito.
        script = textwrap.dedent("""
            import sys
            # Confirmar de entrada que nada de frontend/PySide6 está
            # precargado — si lo estuviera, la prueba no probaría nada.
            assert not any(m.startswith("PySide6") for m in sys.modules), (
                "PySide6 ya estaba en sys.modules antes de empezar")
            assert not any("lorito_aldhiro.frontend" in m for m in sys.modules), (
                "lorito_aldhiro.frontend ya estaba en sys.modules antes de empezar")

            from lorito_aldhiro.backend.playback.lorito_tape_physics import (
                CassetteTransportPhysics, _CassetteType_Enum,
            )

            # Confirma que, tras importar y usar el módulo, PySide6 y
            # frontend SIGUEN sin haberse importado nunca — no solo que
            # el import de tape_physics en sí no falló.
            assert not any(m.startswith("PySide6") for m in sys.modules), (
                "importar tape_physics disparó un import de PySide6")
            assert not any("lorito_aldhiro.frontend" in m for m in sys.modules), (
                "importar tape_physics disparó un import de lorito_aldhiro.frontend")

            ctp = CassetteTransportPhysics()
            ctp.insert_cassette(_CassetteType_Enum.C60)
            # El plugin externo `aecct2_itl_integration` no existe en
            # este tarball (igual que antes del fix) — el resultado
            # observable debe ser exactamente el mismo: fallback activo.
            assert ctp._itl_active is False, (
                f"se esperaba _itl_active=False (fallback), fue {ctp._itl_active!r}")
            assert ctp._total_duration_s > 0, "insert_cassette no calculó duración"

            print("OK")
        """)
        result = subprocess.run(
            [sys.executable, "-c", script],
            cwd=_REPO_ROOT,
            capture_output=True, text=True, timeout=30,
        )
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout}\nstderr={result.stderr}")
        self.assertIn("OK", result.stdout)


if __name__ == "__main__":
    unittest.main()
