"""
Tests reales del contrato de transporte nuevo (§3-§14, FASE 1) —
`lorito_aldhiro/backend/transport/`. No requiere PySide6/sounddevice:
es lógica pura, deliberadamente aislada del motor de audio real para
poder verificarse aquí (ver GAP-005 §4 sobre qué queda pendiente de
cablear a `PlaybackEngine`/`lorito_scrub_bars.py`).

Ejecutar: python3 -m unittest tests.test_transport_core -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lorito_aldhiro.backend.transport.lorito_transport_state import (
    TransportState, TransportMode, Direction,
)
from lorito_aldhiro.backend.transport.lorito_transport_commands import (
    TransportCommand, CommandKind,
)
from lorito_aldhiro.backend.transport.lorito_transport_machine import (
    TransportMachine, InvalidTransitionError, GenerationGuard, TaggedBlock,
)
from lorito_aldhiro.backend.transport.lorito_speed_planner import (
    SpeedPlanner, SpeedPlannerConfig,
)

M = TransportMode
D = Direction


class TestTransportMachineBasics(unittest.TestCase):

    def test_idle_to_play_forward(self):
        tm = TransportMachine()
        st = tm.apply(TransportCommand.play(D.FORWARD))
        self.assertEqual(st.mode, M.PLAY_FORWARD)
        self.assertEqual(st.direction, D.FORWARD)
        self.assertEqual(st.playback_generation, 1)

    def test_play_bumps_playback_and_transport_generation(self):
        tm = TransportMachine()
        st1 = tm.apply(TransportCommand.play(D.FORWARD))
        st2 = tm.apply(TransportCommand.stop())
        st3 = tm.apply(TransportCommand.play(D.FORWARD))
        self.assertEqual(st3.playback_generation, 2)
        self.assertGreater(st3.transport_generation, st1.transport_generation)

    def test_seek_invalid_from_idle(self):
        tm = TransportMachine()
        with self.assertRaises(InvalidTransitionError):
            tm.apply(TransportCommand.seek(1000))

    def test_double_click_stop_from_stopping_is_rejected(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        tm.apply(TransportCommand.stop())
        with self.assertRaises(InvalidTransitionError):
            tm.apply(TransportCommand.stop())  # §4: transición inválida, nunca silenciosa


class TestSeekMatrix(unittest.TestCase):
    """§32 — matriz de Seek: forward→forward, forward→backward,
    reverse→forward, reverse→backward."""

    def _playing(self, direction: Direction) -> TransportMachine:
        tm = TransportMachine()
        tm.apply(TransportCommand.play(direction))
        return tm

    def test_seek_forward_while_forward(self):
        tm = self._playing(D.FORWARD)
        st = tm.apply(TransportCommand.seek(5000))
        self.assertEqual(st.mode, M.SEEKING_FORWARD)
        self.assertEqual(st.direction, D.FORWARD)   # §10: Seek no cambia dirección
        self.assertEqual(st.requested_frame, 5000)

    def test_seek_while_reverse_keeps_reverse_direction(self):
        """§10 — 'Seek hacia N durante reversa' debe mantener
        direction=REVERSE y no forzar N→N+1→... (forward) primero."""
        tm = self._playing(D.REVERSE)
        st = tm.apply(TransportCommand.seek(2000))
        self.assertEqual(st.mode, M.SEEKING_REVERSE)
        self.assertEqual(st.direction, D.REVERSE)
        self.assertEqual(st.requested_frame, 2000)

    def test_seek_done_resumes_original_direction(self):
        tm = self._playing(D.REVERSE)
        tm.apply(TransportCommand.seek(2000))
        st = tm.apply(TransportCommand(kind=CommandKind.SEEK_DONE))
        self.assertEqual(st.mode, M.PLAY_REVERSE)
        self.assertEqual(st.head_frame, 2000)


class TestDirectionChange(unittest.TestCase):
    """§9 — cambio de dirección como operación de primera clase."""

    def test_forward_to_reverse_is_first_class_transition(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        g0 = tm.state.transport_generation
        st = tm.apply(TransportCommand.set_direction(D.REVERSE))
        self.assertEqual(st.mode, M.PLAY_REVERSE)
        self.assertEqual(st.direction, D.REVERSE)
        self.assertGreater(st.transport_generation, g0)  # nunca un no-op silencioso

    def test_reverse_to_forward(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.REVERSE))
        st = tm.apply(TransportCommand.set_direction(D.FORWARD))
        self.assertEqual(st.mode, M.PLAY_FORWARD)


class TestSpeedAndMorphCombinations(unittest.TestCase):
    """§32 — combinaciones reverse+seek, reverse+velocista, reverse+morpher,
    seek+morpher, seek+velocista, seek+reverse+morpher."""

    def test_reverse_plus_speed(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.REVERSE))
        st = tm.apply(TransportCommand.set_target_speed(1.5))
        self.assertEqual(st.mode, M.SPEED_LIVE)
        self.assertEqual(st.direction, D.REVERSE)  # velocidad no toca dirección

    def test_speed_commit_resumes_correct_direction(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.REVERSE))
        tm.apply(TransportCommand.set_target_speed(2.0))
        st = tm.apply(TransportCommand.commit_speed())
        self.assertEqual(st.mode, M.PLAY_REVERSE)
        self.assertEqual(st.speed_ratio, 2.0)

    def test_reverse_plus_morph_then_cancel_resumes_reverse(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.REVERSE))
        tm.apply(TransportCommand.begin_morph())
        st = tm.apply(TransportCommand.cancel_morph())
        self.assertEqual(st.mode, M.PLAY_REVERSE)
        self.assertEqual(st.speed_ratio, 1.0)

    def test_seek_then_morph_then_end_morph(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        tm.apply(TransportCommand.seek(1000))
        st = tm.apply(TransportCommand.begin_morph())
        self.assertEqual(st.mode, M.MORPHER_LIVE)
        st = tm.apply(TransportCommand.end_morph())
        self.assertEqual(st.mode, M.MORPHER_RETURN)

    def test_multiple_set_target_speed_do_not_each_bump_generation(self):
        """§12 — coalescing: varios SET_TARGET_SPEED consecutivos en modo
        live no deben generar una transición estructural nueva cada vez."""
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        tm.apply(TransportCommand.set_target_speed(1.1))
        g_after_first = tm.state.transport_generation
        for r in (1.11, 1.12, 1.13, 1.14):
            tm.apply(TransportCommand.set_target_speed(r))
        self.assertEqual(tm.state.transport_generation, g_after_first)
        self.assertEqual(tm.state.target_speed, 1.14)


class TestGenerationGuard(unittest.TestCase):
    """§5 — bloques de una generación vieja se descartan antes de sonar."""

    def test_stale_block_discarded_after_seek(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        guard = GenerationGuard(tm)
        stale_gen = tm.state.transport_generation
        stale_block = TaggedBlock(generation=stale_gen, payload=b"viejo")

        tm.apply(TransportCommand.seek(9000))  # cambio estructural → nueva generación
        self.assertFalse(guard.accept(stale_block))

        fresh_block = TaggedBlock(generation=tm.state.transport_generation, payload=b"nuevo")
        self.assertTrue(guard.accept(fresh_block))

    def test_direction_change_invalidates_old_generation(self):
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        guard = GenerationGuard(tm)
        old_block = TaggedBlock(generation=tm.state.transport_generation, payload=None)
        tm.apply(TransportCommand.set_direction(D.REVERSE))
        self.assertFalse(guard.accept(old_block))

    def test_seek_durante_prefetch(self):
        """Fase 9 (GAP-034) — caso nombrado por la orden: un bloque ya
        estaba en vuelo (prefetch en curso para la posición vieja)
        cuando llega un Seek que cambia la generación. El bloque
        prefetcheado, aunque llegue DESPUÉS del Seek, debe rechazarse
        — nunca debe sonar audio de la posición anterior al seek."""
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        guard = GenerationGuard(tm)

        # El prefetch pide un bloque para la posición actual — se
        # etiqueta con la generación de ESE momento.
        gen_antes_del_seek = tm.state.transport_generation
        bloque_en_vuelo = TaggedBlock(generation=gen_antes_del_seek,
                                      payload="audio de la posición vieja")

        # El usuario hace Seek ANTES de que el prefetch en vuelo llegue
        # — la generación cambia mientras el bloque todavía viaja.
        tm.apply(TransportCommand.seek(50_000))

        # El bloque en vuelo llega TARDE, después del seek — debe
        # rechazarse sin importar que ya esté "en camino" desde antes.
        self.assertFalse(guard.accept(bloque_en_vuelo))

        # El prefetch se vuelve a pedir para la NUEVA posición — ese sí
        # debe aceptarse.
        bloque_nuevo = TaggedBlock(generation=tm.state.transport_generation,
                                   payload="audio de la posición nueva")
        self.assertTrue(guard.accept(bloque_nuevo))

    def test_scrub_con_underrun_descarta_todos_los_bloques_atrasados(self):
        """Fase 9 (GAP-034) — caso nombrado por la orden: scrub rápido
        (varios Seeks consecutivos, como arrastrar el Morpher/Velocista
        sin soltar) combinado con un underrun del prefetch — los
        bloques pedidos para cada posición intermedia del scrub llegan
        TARDE y DESORDENADOS (justo lo que un buffer hambriento
        produciría). El guard debe rechazar TODOS salvo, como mucho,
        uno que coincida exactamente con la generación final vigente —
        nunca debe colarse audio de ninguna posición intermedia."""
        tm = TransportMachine()
        tm.apply(TransportCommand.play(D.FORWARD))
        guard = GenerationGuard(tm)

        bloques_en_vuelo = []
        # Simula 6 posiciones de scrub consecutivas — cada Seek pide su
        # propio prefetch, etiquetado con la generación de ese instante,
        # pero NINGUNO llega todavía (underrun: el productor no puede
        # seguirle el ritmo al usuario arrastrando el scrub).
        for pos in (1000, 2000, 3000, 4000, 5000, 6000):
            tm.apply(TransportCommand.seek(pos))
            bloques_en_vuelo.append(
                TaggedBlock(generation=tm.state.transport_generation,
                           payload=f"scrub pos={pos}"))

        generacion_final = tm.state.transport_generation

        # Los bloques llegan TARDE y DESORDENADOS (el del medio antes
        # que el primero, etc.) — solo el de la ÚLTIMA generación debe
        # aceptarse, sin importar el orden de llegada.
        orden_de_llegada_desordenado = [
            bloques_en_vuelo[3], bloques_en_vuelo[0], bloques_en_vuelo[5],
            bloques_en_vuelo[1], bloques_en_vuelo[4], bloques_en_vuelo[2],
        ]
        aceptados = [b for b in orden_de_llegada_desordenado if guard.accept(b)]

        self.assertEqual(len(aceptados), 1,
                         msg="solo el bloque de la generación final vigente "
                             "debe aceptarse, ninguna posición intermedia del scrub")
        self.assertEqual(aceptados[0].generation, generacion_final)
        self.assertEqual(aceptados[0].payload, "scrub pos=6000")


class TestSpeedPlanner(unittest.TestCase):
    """§7, §11, §12, §13."""

    def test_no_jump_beyond_max_step(self):
        planner = SpeedPlanner(SpeedPlannerConfig(max_step_per_tick=0.05))
        planner.update_desired(1.40)
        prev = planner.applied_ratio
        steps = []
        for _ in range(20):
            cur = planner.step()
            self.assertLessEqual(abs(cur - prev), 0.05 + 1e-9)  # §7: nunca salto arbitrario
            steps.append(cur)
            prev = cur
            if planner.is_settled():
                break
        self.assertAlmostEqual(planner.applied_ratio, 1.40, places=6)
        self.assertGreater(len(steps), 1)  # confirma que hubo curva, no salto directo

    def test_coalescing_keeps_only_latest_desired(self):
        planner = SpeedPlanner()
        for r in (1.10, 1.11, 1.12, 1.13, 1.14):
            planner.update_desired(r)
        self.assertEqual(planner.desired_ratio, 1.14)  # §12: solo sobrevive la última

    def test_desired_applied_rendered_are_distinct(self):
        planner = SpeedPlanner(initial_ratio=1.0)
        planner.update_desired(2.0)
        planner.step()
        planner.report_rendered(1.0)  # el motor real todavía no llegó ahí
        self.assertNotEqual(planner.desired_ratio, planner.rendered_ratio)
        self.assertNotEqual(planner.applied_ratio, planner.rendered_ratio)

    def test_clamped_to_config_range(self):
        planner = SpeedPlanner(SpeedPlannerConfig(min_ratio=0.5, max_ratio=2.0))
        planner.update_desired(10.0)
        self.assertEqual(planner.desired_ratio, 2.0)
        planner.update_desired(-5.0)
        self.assertEqual(planner.desired_ratio, 0.5)


class TestSharedPlannerBetweenMorpherAndVelocista(unittest.TestCase):
    """§13 — un único SpeedPlanner, no dos algoritmos independientes."""

    def test_both_ui_sources_feed_same_planner_consistently(self):
        planner = SpeedPlanner()

        # Simula Velocista pidiendo 1.5...
        planner.update_desired(1.5)
        planner.step()
        after_velocista = planner.applied_ratio

        # ...y luego Morpher pidiendo 0.8 sobre el MISMO planner.
        planner.update_desired(0.8)
        for _ in range(200):
            planner.step()
            if planner.is_settled():
                break

        self.assertAlmostEqual(planner.applied_ratio, 0.8, places=6)
        # Continuidad: el segundo tramo parte de donde terminó el primero,
        # no de 1.0 (§7 — nunca reinicia el cursor de la curva).
        self.assertNotEqual(after_velocista, 1.0)


if __name__ == "__main__":
    unittest.main()
