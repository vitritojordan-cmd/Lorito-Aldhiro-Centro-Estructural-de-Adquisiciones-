"""
tests/test_ui_layout_geometry.py — verifica, con la MISMA aritmética que
`LoritoAldhiroStudio._build_ui()` usa realmente (§GAP-015: barra de
menú, contómetro estirado, botones→scrub→morpher→velocista→waveform→
logs→cinta), que ningún bloque se superpone y que todo cabe dentro del
lienzo. No requiere PySide6 — es aritmética pura, replicada línea por
línea contra el código fuente real (ver
test_matches_actual_build_ui_source para la verificación cruzada).

Ejecutar: python3 -m unittest tests.test_ui_layout_geometry -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _compute_cascade(W=960, H=570, MENU_BAR_H=26):
    """Réplica exacta de la aritmética de `_build_ui()` — mantener en
    sincronía manual si esa función cambia (mismo criterio que
    `_STOP_INTERVALS` vs. el motor CRAC real en GAP-014)."""
    TIMER_Y = MENU_BAR_H + 22
    _LEGEND_ROW_H = 12  # DigitalClock.LEGEND_ROW_H

    PAD = 7
    BTN_H = 36
    SCRUB_LBL_RISE = 12; SCRUB_BAR_H = 24
    MORPHER_LBL_H = 9; MORPHER_GAP = 2; MORPHER_BAR_H = 26
    SPEED_LBL_H = 9; SPEED_GAP = 2; SPEED_BAR_H = 26
    WAVE_LBL_RISE = 11; WAVE_BAR_H = 58
    STATUS_H = 34
    TAPE_H = 28
    block_heights = [
        BTN_H,
        SCRUB_LBL_RISE + SCRUB_BAR_H,
        MORPHER_LBL_H + MORPHER_GAP + MORPHER_BAR_H,
        SPEED_LBL_H + SPEED_GAP + SPEED_BAR_H,
        WAVE_LBL_RISE + WAVE_BAR_H,
        STATUS_H,
        TAPE_H,
    ]
    VU_BOT = H - 22
    bottom_limit = VU_BOT - 4
    available = (bottom_limit - TIMER_Y - 2 * _LEGEND_ROW_H
                 - sum(block_heights) - PAD * (len(block_heights) + 1))
    TIMER_H = max(80, available)

    BTN_Y = TIMER_Y + 2 * _LEGEND_ROW_H + TIMER_H + PAD
    SCRUB_Y = BTN_Y + BTN_H + PAD + SCRUB_LBL_RISE
    MORPHER_Y = SCRUB_Y + SCRUB_BAR_H + PAD + MORPHER_LBL_H + MORPHER_GAP
    SPEED_Y = MORPHER_Y + MORPHER_BAR_H + PAD + SPEED_LBL_H + SPEED_GAP
    WAVE_Y = SPEED_Y + SPEED_BAR_H + PAD + WAVE_LBL_RISE
    STATUS_Y = WAVE_Y + WAVE_BAR_H + PAD
    TAPE_Y1 = STATUS_Y + STATUS_H + PAD

    return {
        "TIMER_Y": TIMER_Y, "TIMER_H": TIMER_H,
        "TIMER_BOTTOM": TIMER_Y + 2 * _LEGEND_ROW_H + TIMER_H,
        "BTN_Y": BTN_Y, "BTN_BOTTOM": BTN_Y + BTN_H,
        "SCRUB_Y": SCRUB_Y, "SCRUB_BOTTOM": SCRUB_Y + SCRUB_BAR_H,
        "MORPHER_Y": MORPHER_Y, "MORPHER_BOTTOM": MORPHER_Y + MORPHER_BAR_H,
        "SPEED_Y": SPEED_Y, "SPEED_BOTTOM": SPEED_Y + SPEED_BAR_H,
        "WAVE_Y": WAVE_Y, "WAVE_BOTTOM": WAVE_Y + WAVE_BAR_H,
        "STATUS_Y": STATUS_Y, "STATUS_BOTTOM": STATUS_Y + STATUS_H,
        "TAPE_Y1": TAPE_Y1, "TAPE_BOTTOM": TAPE_Y1 + TAPE_H,
        "VU_BOT": VU_BOT, "H": H, "PAD": PAD,
    }


class TestCascadeGeometry(unittest.TestCase):

    def test_timer_h_stretched_well_beyond_original(self):
        c = _compute_cascade()
        self.assertGreater(c["TIMER_H"], 62 * 1.5,
                           "el contómetro debería estirarse notablemente "
                           "al liberar el espacio de los combos legados")

    def test_blocks_in_correct_order_top_to_bottom(self):
        c = _compute_cascade()
        order = ["TIMER_Y", "BTN_Y", "SCRUB_Y", "MORPHER_Y",
                 "SPEED_Y", "WAVE_Y", "STATUS_Y", "TAPE_Y1"]
        ys = [c[k] for k in order]
        self.assertEqual(ys, sorted(ys), "el orden de bloques no es estrictamente creciente")

    def test_no_two_blocks_overlap(self):
        c = _compute_cascade()
        pairs = [
            ("TIMER", "BTN"), ("BTN", "SCRUB"), ("SCRUB", "MORPHER"),
            ("MORPHER", "SPEED"), ("SPEED", "WAVE"), ("WAVE", "STATUS"),
            ("STATUS", "TAPE"),
        ]
        for top, bottom in pairs:
            top_edge = c[f"{top}_BOTTOM"]
            bottom_start = c["TAPE_Y1"] if bottom == "TAPE" else c[f"{bottom}_Y"]
            self.assertLessEqual(top_edge, bottom_start,
                                 f"{top} se superpone con {bottom}")

    def test_last_block_fits_within_canvas(self):
        c = _compute_cascade()
        self.assertLessEqual(c["TAPE_BOTTOM"], c["VU_BOT"],
                             "el panel de duración de cinta se sale del lienzo "
                             "(colisiona con el medidor VU)")
        self.assertLessEqual(c["TAPE_BOTTOM"], c["H"])

    def test_pad_gap_between_timer_and_buttons_is_positive(self):
        """Pedido explícito del usuario: 'límite perfecto con un pad de
        separación entre los botones... y el panel de contómetro'."""
        c = _compute_cascade()
        gap = c["BTN_Y"] - c["TIMER_BOTTOM"]
        self.assertEqual(gap, c["PAD"])
        self.assertGreater(gap, 0)

    def test_larger_canvas_grows_timer_h_not_other_blocks(self):
        """Si el lienzo crece, el espacio extra debe ir al contómetro
        (el único bloque de altura variable), no a los demás."""
        c1 = _compute_cascade(H=570)
        c2 = _compute_cascade(H=670)
        self.assertGreater(c2["TIMER_H"], c1["TIMER_H"])
        self.assertEqual(c2["BTN_BOTTOM"] - c2["BTN_Y"],
                         c1["BTN_BOTTOM"] - c1["BTN_Y"])


class TestMatchesActualSource(unittest.TestCase):
    """Verifica, contra el código fuente REAL de _build_ui(), que las
    constantes usadas en `_compute_cascade()` (PAD, alturas de bloque)
    siguen siendo las mismas — si alguien cambia una en el código real
    sin actualizar este test, esto debe fallar (mismo patrón que
    `test_tape_log_panel_stop_intervals_consistent_with_motor` en
    GAP-014)."""

    @classmethod
    def setUpClass(cls):
        from tests.test_stability_patch import _install_stub_modules
        _install_stub_modules()

    def test_pad_and_block_constants_present_in_source(self):
        import inspect
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        src = inspect.getsource(LoritoAldhiroStudio._build_ui)
        for needle in ("PAD = 7", "BTN_H = 36", "SCRUB_BAR_H = 24",
                      "MORPHER_BAR_H = 26", "SPEED_BAR_H = 26",
                      "WAVE_BAR_H = 58", "STATUS_H = 34", "TAPE_H = 28"):
            self.assertIn(needle, src, f"constante '{needle}' no encontrada en _build_ui real")


if __name__ == "__main__":
    unittest.main()
