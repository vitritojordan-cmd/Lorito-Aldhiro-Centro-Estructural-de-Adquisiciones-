#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arborizar_modulos_planos.py -- GAP-046, script pedido explícitamente
por el usuario: "arboriza en estructura de fichero, todo módulo que se
encuentre en base plana".

Mueve cada módulo listado en MAPEO de su ubicación plana actual
(directamente bajo backend/frontend/) a un subpaquete por
responsabilidad, y reescribe TODAS las referencias de import a la
ruta vieja (en lorito_aldhiro/, tests/, y tools/) a la ruta nueva --
tanto "from lorito_aldhiro.backend.X import ..." como "import
lorito_aldhiro.backend.X as ..." y cualquier referencia
"lorito_aldhiro.backend.X.algo" usada de forma dinámica.

lorito_main_window.py (706 líneas tras GAP-046) queda EXENTO
deliberadamente -- ya actúa como núcleo/índice de su propio subpaquete
(frontend/main_window/), arborizado en la primera parte de este mismo
GAP; moverlo de nuevo solo añadiría una capa de indirección sin
beneficio real.

Uso:
    python3 tools/arborizar_modulos_planos.py
"""

import os
import re

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAQUETE_ROOT = os.path.join(REPO_ROOT, "lorito_aldhiro")

MAPEO = [
    ("backend/lorito_app_logging.py", "backend/core/lorito_app_logging.py"),
    ("backend/lorito_constants.py", "backend/core/lorito_constants.py"),
    ("backend/lorito_version.py", "backend/core/lorito_version.py"),
    ("backend/lorito_patches.py", "backend/core/lorito_patches.py"),
    ("backend/lorito_stability_patch.py", "backend/core/lorito_stability_patch.py"),
    ("backend/lorito_timing.py", "backend/core/lorito_timing.py"),

    ("backend/lorito_audio_backend.py", "backend/audio/lorito_audio_backend.py"),
    ("backend/lorito_audio_utils.py", "backend/audio/lorito_audio_utils.py"),
    ("backend/lorito_ring_buffers.py", "backend/audio/lorito_ring_buffers.py"),
    ("backend/lorito_rt_priorities.py", "backend/audio/lorito_rt_priorities.py"),

    ("backend/lorito_capture_engine.py", "backend/capture/lorito_capture_engine.py"),
    ("backend/lorito_snapshot.py", "backend/capture/lorito_snapshot.py"),
    ("backend/lorito_forensics.py", "backend/capture/lorito_forensics.py"),

    ("backend/lorito_playback_engine.py", "backend/playback/lorito_playback_engine.py"),
    ("backend/lorito_monitor_engine.py", "backend/playback/lorito_monitor_engine.py"),
    ("backend/lorito_tape_physics.py", "backend/playback/lorito_tape_physics.py"),
    ("backend/lorito_tape_presets.py", "backend/playback/lorito_tape_presets.py"),

    ("backend/lorito_export_integrity.py", "backend/export/lorito_export_integrity.py"),
    ("backend/lorito_export_spectral_engine.py", "backend/export/lorito_export_spectral_engine.py"),
    ("backend/lorito_exporters.py", "backend/export/lorito_exporters.py"),
    ("backend/lorito_normalization.py", "backend/export/lorito_normalization.py"),
    ("backend/lorito_normalization_v21.py", "backend/export/lorito_normalization_v21.py"),
    ("backend/lorito_reports.py", "backend/export/lorito_reports.py"),
    ("backend/lorito_overlay_registry.py", "backend/export/lorito_overlay_registry.py"),

    ("frontend/lorito_dialogs.py", "frontend/dialogs/lorito_dialogs.py"),

    ("frontend/lorito_fonts.py", "frontend/support/lorito_fonts.py"),
    ("frontend/lorito_theme.py", "frontend/support/lorito_theme.py"),

    ("frontend/lorito_bridge.py", "frontend/integration/lorito_bridge.py"),
    ("frontend/lorito_itl_bridge.py", "frontend/integration/lorito_itl_bridge.py"),
    ("frontend/lorito_itl_integration.py", "frontend/integration/lorito_itl_integration.py"),

    ("frontend/lorito_export_spectral_render.py", "frontend/spectral/lorito_export_spectral_render.py"),
]

_MODULO_VIEJO_A_NUEVO = {
    "lorito_aldhiro." + viejo[:-3].replace("/", "."):
        "lorito_aldhiro." + nuevo[:-3].replace("/", ".")
    for viejo, nuevo in MAPEO
}


def _mover_archivos():
    subpaquetes_nuevos = set()
    for viejo, nuevo in MAPEO:
        src = os.path.join(PAQUETE_ROOT, viejo)
        dst = os.path.join(PAQUETE_ROOT, nuevo)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        subpaquetes_nuevos.add(os.path.dirname(dst))
        os.rename(src, dst)
        print(f"movido  {viejo}  ->  {nuevo}")

    for d in subpaquetes_nuevos:
        init_path = os.path.join(d, "__init__.py")
        if not os.path.exists(init_path):
            with open(init_path, "w", encoding="utf-8"):
                pass
            print(f"creado  {os.path.relpath(init_path, REPO_ROOT)}")


def _reescribir_referencias():
    viejos_ordenados = sorted(_MODULO_VIEJO_A_NUEVO, key=len, reverse=True)

    archivos_tocados = 0
    for carpeta in ("lorito_aldhiro", "tests", "tools"):
        base = os.path.join(REPO_ROOT, carpeta)
        for raiz, _dirs, nombres in os.walk(base):
            if "__pycache__" in raiz:
                continue
            for nombre in nombres:
                if not nombre.endswith(".py"):
                    continue
                ruta = os.path.join(raiz, nombre)
                with open(ruta, encoding="utf-8") as f:
                    contenido = f.read()
                original = contenido
                for viejo in viejos_ordenados:
                    nuevo = _MODULO_VIEJO_A_NUEVO[viejo]
                    patron = re.compile(re.escape(viejo) + r"\b(?!\.\w)")
                    contenido = patron.sub(nuevo, contenido)
                if contenido != original:
                    with open(ruta, "w", encoding="utf-8") as f:
                        f.write(contenido)
                    archivos_tocados += 1
    print(f"\nReferencias reescritas en {archivos_tocados} archivos.")


if __name__ == "__main__":
    _mover_archivos()
    _reescribir_referencias()
