#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
insertar_banner_registro.py -- GAP-043/044, script pedido explicitamente
por el usuario: "usando un script, elabora titulos y conceptos de cada
modulo en los docstrings, similar a como lleva CRAC" -- y luego
extendido a "absolutamente todos los modulos de Lorito Aldhiro,
obviamente omitiendo los Init", con "la silueta de un lorito... como
huevo de pascua interno".

Inserta, en el docstring de MODULO (nunca en un docstring de clase o
funcion mas abajo en el archivo) de cada .py listado en `CONCEPTOS`
(todos los modulos de `lorito_aldhiro/`, excepto `__init__.py`), un
marco decorativo con el nombre de registro pedido ("Lorito Aldhiro de
Registros Alternativos C.E.A"), UNICAMENTE el concepto breve de ese
modulo, y la silueta de un lorito. Nunca borra el resto del docstring
existente -- si el archivo no tenia ningun docstring de modulo (varios
no lo tienen: van directo a imports), se crea uno nuevo que contiene
solo el banner.

Deteccion correcta del punto de insercion (evita el bug de buscar la
PRIMERA comilla triple en TODO el archivo, que en un modulo sin
docstring propio encontraria por error el docstring de la primera
clase/funcion): se analizan las lineas iniciales saltando shebang,
declaracion de codificacion, y `from __future__ import ...`; solo si
la siguiente linea no vacia empieza con \"\"\" o ''' se trata como
docstring de modulo ya existente.

Idempotente: si un archivo ya tiene el marco (detectado por la cadena
"REGISTROS ALTERNATIVOS C.E.A"), se lo salta sin duplicarlo.

Uso:
    python3 tools/insertar_banner_registro.py
"""

import os
import re

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAQUETE_ROOT = os.path.join(REPO_ROOT, "lorito_aldhiro")

_MARCA = "LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A"
_LINEA = "═" * 68

# Silueta de lorito (huevo de pascua interno, pedido explícito del
# usuario) — perfil simple: pico curvo, ojo, cuerpo, cola de plumas.
_LORITO = (
    "        ,,__\n"
    "      <(o )---.\n"
    "       ( ._>   `--.\n"
    "        `--'\\\\      `-.\n"
    "             \\\\_/\\\\_/\\\\_/"
)


def _banner(concepto: str) -> str:
    return (
        f"{_LINEA}\n"
        f"  {_MARCA}\n"
        f"{_LINEA}\n"
        f"  Concepto: {concepto}\n"
        f"{_LINEA}\n"
        f"{_LORITO}\n"
        f"{_LINEA}\n\n"
    )


_SHEBANG_RE = re.compile(r"#!.*\n")
_CODING_RE = re.compile(r"#.*coding[:=].*\n")
_FUTURE_RE = re.compile(r"from __future__ import [^\n]*\n")
_DOCSTRING_START_RE = re.compile(r'\s*("""|\'\'\')')


def _punto_insercion(contenido: str):
    """Devuelve (offset, ya_tiene_docstring). `offset` es la posicion
    donde insertar: justo despues de las comillas de apertura del
    docstring de modulo si ya existe, o el punto donde CREAR uno nuevo
    (despues de shebang/coding/future imports) si no."""
    pos = 0
    while True:
        m = _SHEBANG_RE.match(contenido, pos) or _CODING_RE.match(contenido, pos) \
            or _FUTURE_RE.match(contenido, pos)
        if not m:
            break
        pos = m.end()
    # saltar lineas en blanco
    resto = contenido[pos:]
    m_blank = re.match(r"(\s*\n)*", resto)
    pos += m_blank.end() if m_blank else 0

    m_doc = _DOCSTRING_START_RE.match(contenido, pos)
    if m_doc:
        return m_doc.end(), True
    return pos, False


def _insertar_en_archivo(ruta_absoluta: str, concepto: str) -> str:
    with open(ruta_absoluta, "r", encoding="utf-8") as f:
        contenido = f.read()

    if _MARCA in contenido:
        return "saltado (ya tiene marco)"

    offset, ya_tenia = _punto_insercion(contenido)
    bloque = _banner(concepto)
    if ya_tenia:
        nuevo = contenido[:offset] + "\n" + bloque + contenido[offset:]
    else:
        nuevo = contenido[:offset] + '"""\n' + bloque + '"""\n\n' + contenido[offset:]

    with open(ruta_absoluta, "w", encoding="utf-8") as f:
        f.write(nuevo)
    return "insertado" if ya_tenia else "insertado (docstring nuevo)"


# ═══════════════════════════════════════════════════════════════════
#  Conceptos -- ruta relativa a lorito_aldhiro/ -> concepto de 1 linea
# ═══════════════════════════════════════════════════════════════════
CONCEPTOS = {
    # backend/ (nivel superior)
    "backend/lorito_app_logging.py": "Configuración central de logging de la aplicación.",
    "backend/lorito_audio_backend.py": "Selección y abstracción del backend de audio real (PortAudio/sounddevice).",
    "backend/lorito_audio_utils.py": "Utilidades de conversión y manipulación de audio compartidas.",
    "backend/lorito_capture_engine.py": "Motor de captura de audio en tiempo real — callback, ring buffer, escritura a disco.",
    "backend/lorito_constants.py": "Constantes compartidas de todo el backend (tamaños de buffer, umbrales, timeouts).",
    "backend/lorito_export_integrity.py": "Verificación de integridad del archivo exportado contra la sesión capturada.",
    "backend/lorito_export_spectral_engine.py": "Motor de análisis espectral para el visor de espectro de exportación.",
    "backend/lorito_exporters.py": "Exportadores de audio a los formatos soportados (WAV/FLAC/OGG/WavPack) — camino legado.",
    "backend/lorito_forensics.py": "Registro forense de eventos de la sesión de captura para auditoría posterior.",
    "backend/lorito_monitor_engine.py": "Motor de monitorización en vivo de la señal durante la captura.",
    "backend/lorito_normalization.py": "Los 20 modos de normalización de exportación — implementación de referencia.",
    "backend/lorito_normalization_v21.py": "Extensión de los modos de normalización a la versión 21 del catálogo.",
    "backend/lorito_overlay_registry.py": "Registro de mensajes overlay disponibles para mostrar sobre la pantalla principal.",
    "backend/lorito_patches.py": "Parches de compatibilidad aplicados al arrancar la aplicación.",
    "backend/lorito_playback_engine.py": "Motor de reproducción en tiempo real — velocidad variable, scrub, resampleo.",
    "backend/lorito_reports.py": "Generación de reportes de calidad/estado de una sesión de captura.",
    "backend/lorito_ring_buffers.py": "Ring buffer de absorción (RBA) entre el callback de audio y el hilo de escritura a disco.",
    "backend/lorito_rt_priorities.py": "Ajuste de prioridades de tiempo real del sistema operativo para los hilos de audio.",
    "backend/lorito_snapshot.py": "Instantánea del estado de la sesión para recuperación ante crash.",
    "backend/lorito_stability_patch.py": "Parches de estabilidad aplicados a dependencias de terceros.",
    "backend/lorito_tape_physics.py": "Modelo físico de la cinta magnética (velocidad, wow/flutter, saturación) para reproducción.",
    "backend/lorito_tape_presets.py": "Presets de tipo de cinta (Normal/CrO2/Metal) para el motor de física de cinta.",
    "backend/lorito_timing.py": "Reloj de captura monotónico y utilidades de sincronización temporal.",
    "backend/lorito_version.py": "Cálculo de la versión de la aplicación a partir del historial de CHANGELOG.md.",

    # backend/archival/
    "backend/archival/lorito_archival_state.py": "Clasificación de sesiones de captura finalizadas en ARCHIVAL_SAFE/DEGRADED/INVALID.",
    "backend/archival/lorito_segment_checksum.py": "Checksums SHA-256/CRC32 reales por segmento para detectar corrupción entre captura y verificación.",

    # backend/dsp/ (los que no llevan ya el banner de GAP-043)
    "backend/dsp/lorito_dsp_finite_guard.py": "Guard de saneamiento numérico (NaN/Inf) compartido por toda la cadena DSP.",
    "backend/dsp/lorito_dsp_numba_utils.py": "Utilidad compartida de compilación JIT opcional (Numba) para los núcleos DSP.",
    "backend/dsp/lorito_dsp_resample_continuous.py": "Resampleo con continuidad de fase entre bloques, sin salto en los límites de chunk.",
    "backend/dsp/lorito_dsp_muscle_eq_presets.py": "Catálogo de presets de ecualización de Muscle Eq Samir en 5 categorías.",

    # backend/dsp/lucha_enloquecida/ (infraestructura, los 20 perfiles
    # ya llevan banner propio desde GAP-043)
    "backend/dsp/lucha_enloquecida/biquad.py": "Filtro biquad Direct Form II Transposed compartido por los 20 emuladores Lucha Enloquecida.",
    "backend/dsp/lucha_enloquecida/lucha_profile_contract.py": "Contrato mínimo (reset/process) que implementan los 20 emuladores Lucha Enloquecida.",

    # backend/export_streaming/
    "backend/export_streaming/lorito_atomic_finalizer.py": "Finalización atómica de exportación — nunca deja un archivo final a medias.",
    "backend/export_streaming/lorito_encoder_base.py": "Interfaz base de encoder de exportación streaming.",
    "backend/export_streaming/lorito_export_blocks.py": "Tipos de datos compartidos del pipeline de exportación streaming (Block, AudioFormat).",
    "backend/export_streaming/lorito_export_session.py": "Orquestador de una sesión de exportación streaming completa.",
    "backend/export_streaming/lorito_normalization_streaming.py": "Los 20 modos de normalización de exportación, en streaming de dos pasadas.",
    "backend/export_streaming/lorito_segment_provider.py": "Lectura secuencial de segmentos de captura en bloques acotados, sin cargar la sesión completa.",
    "backend/export_streaming/lorito_wav_encoder.py": "Encoder WAV/RF64 streaming, bit-exacto, con soporte para sesiones mayores a 4GB.",

    # backend/nr/
    "backend/nr/lorito_nr_alc.py": "Control automático de nivel (ALC) del catálogo NR.",
    "backend/nr/lorito_nr_coordinator.py": "Orquestador de toda la cadena DSP en tiempo real — un solo punto de entrada por bloque.",
    "backend/nr/lorito_nr_dsp_core.py": "Núcleo DSP compartido de reducción de ruido (Dolby B/C/S, dbx, etc.).",
    "backend/nr/lorito_nr_hxpro.py": "Emulación de HX Pro (extensión dinámica de bias) del catálogo NR.",
    "backend/nr/lorito_nr_profiles.py": "Perfiles seleccionables del sistema de reducción de ruido.",

    # backend/rt/
    "backend/rt/lorito_ring_buffer_spsc.py": "Ring buffer SPSC sin locks (wait-free) — alternativa verificada a RingBufferAbsorcion.",

    # backend/transport/
    "backend/transport/lorito_speed_planner.py": "Planificador de velocidad de reproducción compartido por Morpher y Velocista.",
    "backend/transport/lorito_transport_commands.py": "Comandos del transporte (play/seek/stop/velocidad) como datos inmutables.",
    "backend/transport/lorito_transport_machine.py": "Máquina de estados del transporte — coordina reproducción, scrub y generación de bloques válidos.",
    "backend/transport/lorito_transport_state.py": "Estado inmutable del transporte en un instante dado.",

    # frontend/
    "frontend/lorito_bridge.py": "Puente entre el motor de captura/reproducción backend y la interfaz Qt.",
    "frontend/lorito_dialogs.py": "Diálogos de la aplicación (bienvenida, cierre abrupto, recuperación de crash).",
    "frontend/lorito_export_spectral_render.py": "Renderizado visual del análisis espectral en la interfaz de exportación.",
    "frontend/lorito_fonts.py": "Carga y registro de las fuentes tipográficas de la interfaz.",
    "frontend/lorito_itl_bridge.py": "Puente de integración con el sistema ITL.",
    "frontend/lorito_itl_integration.py": "Integración del flujo ITL con la ventana principal.",
    "frontend/lorito_main_window.py": "Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.",
    "frontend/lorito_theme.py": "Paleta de colores y estilo visual general de la interfaz.",

    # frontend/widgets/
    "frontend/widgets/lorito_buttons.py": "Botones estilizados reutilizables de la interfaz.",
    "frontend/widgets/lorito_crac_motor_v4.py": "Animación del motor/carrete de cinta en la interfaz.",
    "frontend/widgets/lorito_indicators.py": "Panel de indicadores tipo VU/contómetro — celdas de leyenda, VU-meter, reloj digital.",
    "frontend/widgets/lorito_media_anim.py": "Animaciones de estado de reproducción/grabación en la interfaz.",
    "frontend/widgets/lorito_scrub_bars.py": "Barras de scrub/velocidad interactivas de la interfaz.",
    "frontend/widgets/lorito_status_display.py": "Panel de estado general de la sesión en la interfaz.",
    "frontend/widgets/lorito_tape_log_panel.py": "Panel de bitácora de eventos de la sesión.",
    "frontend/widgets/lorito_waveform.py": "Renderizado de forma de onda en la interfaz.",
}

# Los 7 DSP de nivel superior + los 20 perfiles de Lucha Enloquecida ya
# llevan el banner desde GAP-043 -- se detectan y se saltan solos por
# la marca ya presente, no hace falta excluirlos aqui a mano.
_ARCHIVO_POR_CODIGO_LUCHA = {
    "A": "lucha_profile_a_spring_reverb_abuse.py", "B": "lucha_profile_b_acoustic_damping.py",
    "C": "lucha_profile_c_starving_voltage.py", "D": "lucha_profile_d_tape_loops.py",
    "E": "lucha_profile_e_pipe_echo_chamber.py", "F": "lucha_profile_f_toy_capsule.py",
    "G": "lucha_profile_g_circuit_bending.py", "H": "lucha_profile_h_impedance_mismatch.py",
    "I": "lucha_profile_i_megaphone.py", "J": "lucha_profile_j_generation_loss.py",
    "K": "lucha_profile_k_wire_recording.py", "L": "lucha_profile_l_ground_hum.py",
    "M": "lucha_profile_m_tape_warping.py", "N": "lucha_profile_n_baked_tape.py",
    "O": "lucha_profile_o_carbon_mic.py", "P": "lucha_profile_p_piezo_contact.py",
    "Q": "lucha_profile_q_am_radio_detune.py", "R": "lucha_profile_r_portastudio_overdrive.py",
    "S": "lucha_profile_s_under_biasing.py", "T": "lucha_profile_t_vinyl_damage.py",
}

_CONCEPTOS_DSP_TOP = {
    "backend/dsp/lorito_dsp_mpx.py": "Filtro de piloto FM (19kHz) para fuentes con sintonizador MPX integrado.",
    "backend/dsp/lorito_dsp_eq_bias.py": "Perfil de voicing y headroom según el tipo de cinta (Normal/CrO2/Metal).",
    "backend/dsp/lorito_dsp_focus.py": "Corrección automática de azimut (alineación de cabezal) en tiempo real.",
    "backend/dsp/lorito_dsp_cristhi_cosh.py": "Restauración de artefactos de distorsión de Bias del fonograma crudo (PREVI).",
    "backend/dsp/lorito_dsp_antipestal_lola_grillo.py": "Emulación arqueosónica de degradación de cinta \"Gancha Striker/Kari\" (PREVI).",
    "backend/dsp/lorito_dsp_version_o_tron.py": "Color de sonido de radiograbadora doméstica, AM y onda corta (Funciones Especiales).",
    "backend/dsp/lorito_dsp_muscle_eq_samir.py": "Ecualización en caliente con bandas manuales, presets y curvas técnicas (Vitrito).",
}


def _todos_los_conceptos():
    todos = dict(CONCEPTOS)
    todos.update(_CONCEPTOS_DSP_TOP)
    import sys
    sys.path.insert(0, REPO_ROOT)
    from lorito_aldhiro.backend.dsp.lucha_enloquecida import LUCHA_PROFILE_ORDER
    for code, label, tecnica, _cls in LUCHA_PROFILE_ORDER:
        fname = _ARCHIVO_POR_CODIGO_LUCHA[code]
        todos[f"backend/dsp/lucha_enloquecida/{fname}"] = f"{label} — {tecnica} (PREVI)."
    return todos


def main():
    todos = _todos_los_conceptos()

    # Verificación de cobertura: todo .py bajo lorito_aldhiro/, salvo
    # __init__.py, debe tener un concepto -- si falta alguno, se avisa
    # explícitamente en vez de dejarlo pasar en silencio.
    encontrados = set()
    for raiz, _dirs, archivos in os.walk(PAQUETE_ROOT):
        for nombre in archivos:
            if nombre == "__init__.py" or not nombre.endswith(".py"):
                continue
            ruta_rel = os.path.relpath(os.path.join(raiz, nombre), PAQUETE_ROOT)
            encontrados.add(ruta_rel)

    faltantes = encontrados - set(todos.keys())
    if faltantes:
        print("AVISO -- módulos sin concepto definido (no se tocan):")
        for f in sorted(faltantes):
            print("  ", f)

    for ruta_relativa, concepto in sorted(todos.items()):
        ruta_absoluta = os.path.join(PAQUETE_ROOT, ruta_relativa)
        if not os.path.isfile(ruta_absoluta):
            print(f"{'NO EXISTE':28s} lorito_aldhiro/{ruta_relativa}")
            continue
        resultado = _insertar_en_archivo(ruta_absoluta, concepto)
        print(f"{resultado:28s} lorito_aldhiro/{ruta_relativa}")

    print(f"\nTotal módulos con concepto: {len(todos)} / {len(encontrados)} encontrados en el árbol.")


if __name__ == "__main__":
    main()
