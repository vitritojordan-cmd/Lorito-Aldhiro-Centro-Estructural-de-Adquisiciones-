#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
modularizar_main_window.py -- GAP-046, script pedido explícitamente
por el usuario: "Modulariza por responsabilidades Lorito Main Window,
es un módulo enorme, hazlo mediante un script, manteniendo siempre la
convención de crear su banner decorativo para cada sub módulo".

Estrategia: `lorito_main_window.py` (6376 líneas, una sola clase
`LoritoAldhiroStudio(QWidget)` con 86 métodos) se divide usando el
patrón de MIXINS -- cada grupo de métodos por responsabilidad se
convierte en una clase mixin en su propio archivo; la clase final
hereda de TODOS los mixins + QWidget. Esto es deliberadamente el
enfoque de MENOR riesgo posible: ningún cuerpo de método se modifica
ni una sola línea (se extraen con `ast`, por rango de línea exacto,
incluidos decoradores) -- todos los métodos siguen compartiendo la
MISMA instancia `self` en tiempo de ejecución sin importar en qué
archivo esté definido cada uno, así que ninguna referencia cruzada
entre métodos (`self._foo()`, atributos puestos en `__init__` y
leídos en otros métodos, etc.) se rompe.

Cada archivo nuevo recibe el MISMO bloque de imports que tenía el
original (en vez de calcular un subconjunto mínimo por archivo) --
genera algunos imports no usados por archivo, pero elimina por
completo el riesgo de un `NameError` por un import olvidado en un
refactor de este tamaño.

Uso:
    python3 tools/modularizar_main_window.py
"""

import ast
import os

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIGINAL = os.path.join(REPO_ROOT, "lorito_aldhiro/frontend/lorito_main_window.py")
DEST_DIR = os.path.join(REPO_ROOT, "lorito_aldhiro/frontend/main_window")

_MARCA = "LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A"
_LINEA = "═" * 68
_LORITO = (
    "        ,,__\n"
    "      <(o )---.\n"
    "       ( ._>   `--.\n"
    "        `--'\\\\      `-.\n"
    "             \\\\_/\\\\_/\\\\_/"
)


def _banner(concepto: str) -> str:
    return (
        f'"""\n'
        f"{_LINEA}\n"
        f"  {_MARCA}\n"
        f"{_LINEA}\n"
        f"  Concepto: {concepto}\n"
        f"{_LINEA}\n"
        f"{_LORITO}\n"
        f"{_LINEA}\n"
        f'"""\n\n'
    )


# ═══════════════════════════════════════════════════════════════════
#  Grupos de responsabilidad -- (nombre_archivo, NombreClaseMixin,
#  concepto, [métodos en este grupo])
# ═══════════════════════════════════════════════════════════════════
GRUPOS = [
    ("lorito_mw_session_startup", "SessionStartupMixin",
     "Arranque de sesión: bienvenida, información patrimonial, recuperación tras crash.",
     ["_check_crash_recovery", "_check_bienvenida", "_check_informacion_patrimonial",
      "_do_crash_recovery"]),

    ("lorito_mw_telemetry", "TelemetryMixin",
     "Telemetría en vivo: estado del motor, progreso de exportación, VU, forma de onda, archival.",
     ["_on_backend_status", "_on_export_progress", "_on_vu_ready", "_on_tape_update",
      "_tick_vu_redraw", "_on_waveform_ready", "_on_recovery_msg", "_on_stream_died",
      "_update_internal_status", "_emergency_free_memory", "_archival_tick",
      "_get_counter_manifest_fields", "_toggle_archival_safe"]),

    ("lorito_mw_optape_menu", "OptapeMenuMixin",
     "Manejadores del menú OPTAPE: DSP de PREVI/FNESP, NR, ecualización, monitor.",
     ["_on_dsp_dither_menu", "_on_host_menu", "_on_muestra_menu", "_on_bitdeph_menu",
      "_on_nr_menu", "_on_optape_menu", "_on_cristhi_cosh_toggle", "_open_cristhi_cosh_panel",
      "_on_antipestal_menu", "_open_antipestal_panel", "_on_lucha_menu",
      "_on_muscle_eq_reset", "_open_muscle_eq_panel", "_on_o_tron_menu",
      "_on_monitor_menu", "_on_eqbias_menu"]),

    ("lorito_mw_ui_build", "UiBuildMixin",
     "Construcción de la interfaz: barra de menús, layout principal, ticks de refresco visual.",
     ["_build_menu_bar", "_build_ui", "_update_codec_ui", "_btn_idle_css", "_set_ui_state",
      "_sync_buttons", "_has_audio", "_on_rate_changed", "_on_cassette_dur_changed",
      "_blink", "_tick_cassette", "_tick"]),

    ("lorito_mw_recording", "RecordingMixin",
     "Ciclo de vida de la grabación: iniciar, pausar, detener motor de captura.",
     ["start_record", "_start_record_engine", "_on_rec_engine_ready", "toggle_pause",
      "stop_all", "_on_stop_ready", "_probe_disk_file"]),

    ("lorito_mw_silence_autopause", "SilenceAutopauseMixin",
     "Auto-pausa por silencio (SIPA): detección, activación, desactivación.",
     ["_on_cafe_blink_tick", "set_silence_autopause", "_crac_classify_profile",
      "_check_silence_autopause", "_activate_silence_autopause",
      "_deactivate_silence_autopause", "_on_carola_waiting_blink",
      "_on_overflow_blink_tick", "_show_fnc_no_disp"]),

    ("lorito_mw_playback", "PlaybackMixin",
     "Reproducción: velocidad variable, scrub, Morpher, resampleo cúbico, caché de audio.",
     ["_toggle_play_stop", "_scrub_reset_to_start", "_apply_normalization", "_get_audio",
      "_resample_full_cubic", "_resample_block_cubic", "_invalidate_speed_cache",
      "_trigger_speed_cache", "_get_cached_audio", "_speed_zone_coded_name",
      "_on_speed_changed", "_on_morpher_changed", "play_audio", "_on_seek_ready",
      "_on_play_done_signal", "_scrub_seek_realtime", "_scrub_commit", "_scrub_released"]),

    ("lorito_mw_export", "ExportMixin",
     "Exportación: construcción del array de audio, diálogo exportador, orquestación de codecs.",
     ["_build_export_array", "_open_lorito_exportador", "export", "_fmt_short"]),
]

#: Métodos que quedan en el archivo "núcleo" (constructor y eventos
#: Qt de más alto nivel -- se mantienen en el archivo principal por
#: ser el punto de entrada natural de la clase).
NUCLEO = ["__init__", "closeEvent", "keyPressEvent"]


def _extraer_metodos(path):
    with open(path, encoding="utf-8") as f:
        lineas = f.readlines()
    src = "".join(lineas)
    tree = ast.parse(src)

    class_node = next(n for n in tree.body
                      if isinstance(n, ast.ClassDef) and n.name == "LoritoAldhiroStudio")

    metodos = {}
    lineas_otros = set()  # números de línea (1-indexado) de class-body que NO son métodos
    for node in class_node.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            inicio = node.decorator_list[0].lineno if node.decorator_list else node.lineno
            fin = node.end_lineno
            metodos[node.name] = "".join(lineas[inicio - 1:fin])
        else:
            lineas_otros.update(range(node.lineno, node.end_lineno + 1))

    # Statements que comparten línea física (p.ej. "W = 1040; H = 710"
    # son dos nodos Assign con el MISMO rango de línea) se deduplican
    # solos al recolectar números de línea en un set antes de extraer.
    otros_statements = ["".join(lineas[n - 1:n]) for n in sorted(lineas_otros)]

    header = "".join(lineas[:79])  # líneas 1-79 (antes de "class LoritoAldhiroStudio")
    return header, metodos, class_node, otros_statements


def main():
    os.makedirs(DEST_DIR, exist_ok=True)
    init_path = os.path.join(DEST_DIR, "__init__.py")
    if not os.path.exists(init_path):
        with open(init_path, "w", encoding="utf-8") as f:
            f.write("")

    header, metodos, class_node, otros_statements = _extraer_metodos(ORIGINAL)

    todos_los_nombres = {n.name for n in class_node.body
                         if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    usados = set(NUCLEO)
    for _fname, _cls, _concepto, nombres in GRUPOS:
        usados.update(nombres)
    faltantes = todos_los_nombres - usados
    if faltantes:
        raise SystemExit(f"AVISO: métodos sin grupo asignado: {sorted(faltantes)}")
    sobrantes = usados - todos_los_nombres
    if sobrantes:
        raise SystemExit(f"AVISO: nombres de método listados que no existen: {sorted(sobrantes)}")

    nombres_clases_mixin = []
    for fname, clsname, concepto, nombres in GRUPOS:
        cuerpo = "\n".join(metodos[n].rstrip("\n") for n in nombres)
        contenido = (
            _banner(concepto)
            + header
            + f"\nclass {clsname}:\n"
            f'    """Mixin de responsabilidad — ver banner de cabecera. Solo '
            f'cobra sentido\n    mezclado con QWidget (o algo que ya provea '
            f'sus atributos) dentro de\n    `LoritoAldhiroStudio` — no se '
            f'instancia de forma independiente."""\n\n'
            + cuerpo + "\n"
        )
        dest = os.path.join(DEST_DIR, f"{fname}.py")
        with open(dest, "w", encoding="utf-8") as f:
            f.write(contenido)
        nombres_clases_mixin.append((fname, clsname))
        print(f"escrito  {len(nombres):2d} métodos  lorito_aldhiro/frontend/main_window/{fname}.py")

    # ── Archivo núcleo ────────────────────────────────────────────────
    imports_mixins = "\n".join(
        f"from lorito_aldhiro.frontend.main_window.{fname} import {clsname}"
        for fname, clsname in nombres_clases_mixin
    )
    bases = ", ".join(clsname for _f, clsname in nombres_clases_mixin) + ", QWidget"
    cuerpo_nucleo = "\n".join(metodos[n].rstrip("\n") for n in NUCLEO)
    atributos_clase = "".join(otros_statements)
    if atributos_clase:
        cuerpo_nucleo = atributos_clase + "\n" + cuerpo_nucleo

    concepto_nucleo = ("Ventana principal de Lorito Aldhiro — núcleo (constructor + eventos "
                       "Qt de alto nivel); el resto de la clase vive en "
                       "frontend/main_window/ (mixins por responsabilidad).")
    nuevo_contenido = (
        _banner(concepto_nucleo)
        + header
        + "\n"
        + imports_mixins
        + "\n\n\n"
        + f"class LoritoAldhiroStudio({bases}):\n"
        + cuerpo_nucleo + "\n"
    )
    with open(ORIGINAL, "w", encoding="utf-8") as f:
        f.write(nuevo_contenido)
    print(f"escrito  {len(NUCLEO):2d} métodos  lorito_aldhiro/frontend/lorito_main_window.py (núcleo)")


if __name__ == "__main__":
    main()
