from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de reproducción en tiempo real — velocidad variable, scrub, resampleo.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Orden Golden Scrubs Morpher / Velocista / Seek (SMV-01…SMV-14) —
refundación del motor. El Transport Core (`TransportMachine`,
`SpeedPlanner`, generaciones) es la ÚNICA autoridad productiva.

Pipeline (ver SCRUBS_TRANSPORT_ARCHITECTURE_GOLDEN.md):

    UI ──TransportTransaction──▶ cola de comandos (deque, sin locks)
                                   │  (aplicación EN ORDEN, coalescing
                                   ▼   explícito, seek supersedido)
    hilo `pe-render`: TransportMachine + SpeedPlanner
       └─ VariableRateReader (cursor absoluto, rampa de ratio por muestra)
       └─ TransitionPolicy (rampas precalculadas; DIP/XFADE/EOF/STOP)
       └─ publica bloques ETIQUETADOS (sesión, transporte, epoch de ratio)
                                   │
                                   ▼
    ring SPSC preasignado de PE_RING_SLOTS × PE_BLOCKSIZE frames
                                   │
                                   ▼
    callback RT: SOLO copia frames válidos, descarta generaciones por
    debajo del mínimo válido, rellena silencio declarado en underrun y
    actualiza contadores/cursor audible. Sin lecturas de disco, sin
    logs, sin forenses, sin locks, sin crossfades.

Semántica de corte: un comando surte efecto en la CABEZA de escritura
del ring (el audio ya encolado, ≤ PE_TARGET_LEAD bloques ≈ 64 ms a
48 kHz, se reproduce íntegro y es válido para la generación vigente al
publicarse). Nunca se vacía la cola audible por debajo del callback, de
modo que ningún bloque viejo puede aparecer DESPUÉS de uno nuevo.

Cursores canónicos (CURSOR_AND_GENERATION_LEDGER.md):
    requested_frame   último destino pedido por la UI (seek)
    read_head_frame   cursor del lector (hilo de render)
    queued_head_frame fin del último bloque publicado
    audible_frame     posición del frame que el callback entrega ahora
    ui_frame          = audible_frame (la UI muestra lo audible)
"""

import collections
import logging
import math as _math
import threading
import time
from typing import Callable, Optional

import numpy as np
import sounddevice as sd
import soundfile as sf

from lorito_aldhiro.backend.playback.lorito_varispeed_reader import (
    VariableRateReader, _adapt_channels,
)
from lorito_aldhiro.backend.transport.lorito_transport_state import Direction, TransportMode
from lorito_aldhiro.backend.transport.lorito_transport_commands import TransportCommand
from lorito_aldhiro.backend.transport.lorito_transport_machine import (
    TransportMachine, InvalidTransitionError,
)
from lorito_aldhiro.backend.transport.lorito_speed_planner import (
    SpeedPlanner, SpeedPlannerConfig,
)
from lorito_aldhiro.backend.transport.lorito_transition_policy import (
    TransitionPolicy, TransitionRecord, DIP, XFADE_EQUAL_POWER, XFADE_LINEAR, CUT,
    FADE_OUT_END, CONTINUOUS,
)
from lorito_aldhiro.backend.transport.lorito_transport_ledger import (
    TransportTransaction, TransportLedger, APPLIED, CONFIRMED, SUPERSEDED, REJECTED,
)

__all__ = ["PlaybackEngine", "_adapt_channels", "PE_BLOCKSIZE", "PE_RING_SLOTS",
           "PE_TARGET_LEAD", "PE_SLEW_PER_S", "PE_MAX_RATIO"]

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES DEL MOTOR (contrato declarado)
# ─────────────────────────────────────────────────────────────────────────────
PE_BLOCKSIZE = 512          # frames por bloque del ring y por callback
PE_RING_SLOTS = 16          # capacidad del ring (bloques preasignados)
PE_TARGET_LEAD = 6          # bloques que el render mantiene por delante (~64 ms @48k)
PE_CACHE_FRAMES = 65_536    # caché de lectura de la fuente
PE_SLEW_PER_S = 8.0         # velocidad máxima de cambio del ratio (unidades/s)
PE_MAX_RATIO = 4.0          # |ratio| máximo aceptado
PE_PRELOAD_TIMEOUT = 2.0    # s — sin datos en este plazo, la sesión aborta
PE_STOP_TIMEOUT = 1.5       # s — espera del cierre con fundido antes del corte duro
PE_UNDERRUN_LIMIT = 5       # underruns consecutivos antes de avisar (fuera del callback)
PE_CB_TIMING_SAMPLES = 4096

_FLAG_END = 1
_FLAG_TRANSITION = 2
_FLAG_DEGRADED = 4

_plog = logging.getLogger("aecct2.playback_engine")


class _Session:
    """Estado de UNA sesión de reproducción (generación de sesión). Nada
    de este estado es global de módulo (SMV-08)."""

    def __init__(self, gen: int, channels: int, rate: int, total: int):
        n, b = PE_RING_SLOTS, PE_BLOCKSIZE
        self.gen = gen
        self.channels = channels
        self.rate = rate
        self.total = total
        self.data = np.zeros((n, b, channels), dtype=np.float32)
        self.n = np.zeros(n, dtype=np.int64)
        self.tgen = np.zeros(n, dtype=np.int64)
        self.epoch = np.zeros(n, dtype=np.int64)
        self.src0 = np.zeros(n, dtype=np.float64)
        self.src1 = np.zeros(n, dtype=np.float64)
        self.ratio1 = np.zeros(n, dtype=np.float64)
        self.flags = np.zeros(n, dtype=np.int64)
        self.rms = np.zeros((n, 2), dtype=np.float64)
        self.w = 0                 # solo escribe el render
        self.r = 0                 # solo escribe el callback
        self.min_valid_gen = 0     # generación mínima aceptable en el callback
        # Estado del callback (solo lo toca el callback salvo lecturas).
        self.cb_pos = 0
        self.cb_last_tgen = -1
        self.cb_underrun_consec = 0
        self.cb_done = False
        self.cb_hard_stop = False
        self.audible_frame = 0.0
        self.audible_generation = -1
        self.audible_ratio = 1.0
        self.last_consumed_slot = -1
        self.cb_durations = np.zeros(PE_CB_TIMING_SAMPLES, dtype=np.float64)
        self.cb_count = 0
        # Render.
        self.stop_requested = False
        self.render_done = False
        self.eof = False
        self.ledger = TransportLedger()
        self.cmd_q = collections.deque()
        self.history = collections.deque(maxlen=256)
        self.transition_log = collections.deque(maxlen=256)
        self.requested_frame = 0.0
        self.read_head_frame = 0.0
        self.queued_head_frame = 0.0
        self.ratio_epoch = 0


class PlaybackEngine:
    """
    Motor de reproducción streaming con velocidad variable y Transport Core
    como autoridad única. NUNCA carga el archivo completo en RAM.

    API pública (comandos semánticos, todos asíncronos y no bloqueantes
    salvo `start`/`stop`):
      start(path, rate, channels, start_frame, speed_ratio, on_done)
      stop()                      fundido STOP tras el audio encolado (espera)
      request_stop()              ídem, no bloqueante (GUI)
      set_speed(ratio)            SPEED_COMMIT (soltar Velocista / fin Morpher)
      set_speed_live(ratio)       SPEED_LIVE (arrastre; coalescing explícito)
      set_speed_live_noflush(r)   alias de SPEED_LIVE (retorno elástico)
      seek_to(frame)              SEEK transaccional (supersede al anterior)
      transport_snapshot()        cursores, generaciones, contadores, timing
      is_active()

    Atributos de solo lectura: src_pos (= audible_frame), src_total,
    src_rate, vu_l, vu_r.
    """

    def __init__(self, seek_policy: str = DIP):
        self._thread: Optional[threading.Thread] = None
        self._render_thread: Optional[threading.Thread] = None
        self._stream = None
        self._gen = 0
        self._lock = threading.Lock()          # solo start/stop (nunca el callback)
        self._sess: Optional[_Session] = None
        self._on_done: Optional[Callable] = None
        self.seek_policy = seek_policy
        self._policy = TransitionPolicy(seek_policy=seek_policy)
        self._start_frame = 0.0
        self.src_total = 0
        self.src_rate = 48000
        self.vu_l = 0.0
        self.vu_r = 0.0
        self.event_log = None                  # ForensicEventLog opcional (fuera del RT)
        self.last_session_snapshot: Optional[dict] = None

    # ── Propiedades de cursor ────────────────────────────────────────────────
    @property
    def src_pos(self) -> float:
        """Posición AUDIBLE (lo que la UI debe mostrar)."""
        s = self._sess
        return float(s.audible_frame) if s is not None else float(self._start_frame)

    # ── API pública ──────────────────────────────────────────────────────────
    def start(self, path: str, rate: int, channels: int, start_frame: int,
              speed_ratio: float, on_done: Optional[Callable] = None) -> None:
        self.stop()
        try:
            with sf.SoundFile(path, "r") as probe:
                total = int(probe.frames)
        except Exception as exc:
            _plog.error("PlaybackEngine: no se pudo abrir %s: %s", path, exc)
            return
        ratio = self._clamp_ratio(speed_ratio)
        with self._lock:
            self._gen += 1
            sess = _Session(self._gen, int(channels), int(rate), total)
            sf0 = float(max(0, min(int(start_frame), max(total - 1, 0))))
            sess.audible_frame = sess.requested_frame = sess.read_head_frame = sf0
            sess.queued_head_frame = sf0
            sess.audible_ratio = ratio
            self._sess = sess
        self.src_total = total
        self.src_rate = int(rate)
        self._start_frame = float(start_frame)
        self._on_done = on_done
        self.vu_l = self.vu_r = 0.0
        self._thread = threading.Thread(
            target=self._play_loop, args=(sess, path, ratio),
            daemon=True, name="pe-play")
        self._thread.start()

    def request_stop(self) -> None:
        """STOP no bloqueante (hilo de GUI): encola el comando; el render
        publica el fundido + fin y la sesión termina sola."""
        sess = self._sess
        if sess is not None:
            self._submit(sess, "STOP", None, "UI")
            sess.stop_requested = True

    def stop(self) -> None:
        """Cierre ordenado: comando STOP → el render publica un fundido de
        salida y el marcador de fin; el callback termina el stream. Si no
        llega a tiempo (dispositivo colgado), corte duro declarado."""
        sess = self._sess
        if sess is not None:
            self._submit(sess, "STOP", None, "UI")
            sess.stop_requested = True
        t = self._thread
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=PE_STOP_TIMEOUT)
            if t.is_alive() and sess is not None:
                sess.cb_hard_stop = True
                stream = self._stream
                if stream is not None:
                    try:
                        stream.stop()
                    except Exception:
                        pass
                t.join(timeout=2.0)
        self._thread = None
        self._stream = None
        self.vu_l = 0.0
        self.vu_r = 0.0

    def set_speed(self, ratio: float) -> None:
        self._submit(self._sess, "COMMIT", self._clamp_ratio(ratio), "COMMIT")

    def set_speed_live(self, ratio: float) -> None:
        self._submit(self._sess, "LIVE", self._clamp_ratio(ratio), "LIVE")

    def set_speed_live_noflush(self, ratio: float) -> None:
        self._submit(self._sess, "LIVE", self._clamp_ratio(ratio), "ELASTIC")

    def seek_to(self, frame: int) -> None:
        sess = self._sess
        if sess is None:
            return
        target = float(max(0, int(frame)))
        sess.requested_frame = target
        self._submit(sess, "SEEK", target, "SEEK")

    def is_active(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def transport_snapshot(self) -> dict:
        s = self._sess
        if s is None:
            return dict(self.last_session_snapshot or {})
        return self._snapshot(s)

    # ── Internos: comandos ───────────────────────────────────────────────────
    @staticmethod
    def _clamp_ratio(ratio: float) -> float:
        r = float(ratio)
        if not _math.isfinite(r):
            r = 1.0
        return max(-PE_MAX_RATIO, min(PE_MAX_RATIO, r))

    def _submit(self, sess: Optional[_Session], kind: str, value, source: str) -> None:
        if sess is None:
            return
        tx = TransportTransaction(kind=kind, value=value, source=source,
                                  session_generation=sess.gen)
        sess.ledger.commands_submitted += 1
        sess.cmd_q.append(tx)

    def _record(self, sess: _Session, tx: TransportTransaction, status: str,
                reason: str = "") -> None:
        tx.status = status
        tx.reason = reason
        if status == APPLIED:
            tx.t_apply = time.monotonic()
            if tx.command_id < sess.ledger.last_command_id_applied:
                sess.ledger.commands_out_of_order += 1
            sess.ledger.last_command_id_applied = tx.command_id
            sess.ledger.commands_applied += 1
        elif status == SUPERSEDED:
            sess.ledger.commands_superseded += 1
        elif status == REJECTED:
            sess.ledger.commands_rejected += 1
        sess.history.append(tx)

    def _drain_commands(self, sess, machine, planner, pending):
        """Aplica la cola EN ORDEN. Devuelve (seek_tx|None, confirm_list).
        `pending` = seek aún no renderizado (puede quedar supersedido)."""
        to_confirm = []
        last_live = None
        while sess.cmd_q:
            tx = sess.cmd_q.popleft()
            try:
                if tx.kind == "SEEK":
                    if pending is not None:
                        self._record(sess, pending, SUPERSEDED, f"reemplazado por #{tx.command_id}")
                    pending = tx
                elif tx.kind == "LIVE":
                    if last_live is not None:
                        sess.ledger.live_coalesced += 1
                    last_live = tx
                    if machine.state.mode not in (TransportMode.SPEED_LIVE,
                                                  TransportMode.MORPHER_LIVE):
                        machine.apply(TransportCommand.set_target_speed(tx.value))
                    else:
                        machine.state.target_speed = tx.value
                    planner.update_desired(tx.value)
                    sess.ratio_epoch += 1
                    tx.transport_generation = machine.state.transport_generation
                    self._record(sess, tx, APPLIED)
                    to_confirm.append(tx)
                elif tx.kind == "COMMIT":
                    if machine.state.mode not in (TransportMode.SPEED_LIVE,):
                        machine.apply(TransportCommand.set_target_speed(tx.value))
                    machine.state.target_speed = tx.value
                    machine.apply(TransportCommand.commit_speed())
                    planner.update_desired(tx.value)
                    sess.ratio_epoch += 1
                    tx.transport_generation = machine.state.transport_generation
                    self._record(sess, tx, APPLIED)
                    to_confirm.append(tx)
                elif tx.kind == "STOP":
                    if machine.state.mode not in (TransportMode.STOPPING,
                                                  TransportMode.EOF):
                        machine.apply(TransportCommand.stop())
                    tx.transport_generation = machine.state.transport_generation
                    self._record(sess, tx, APPLIED)
                    sess.stop_requested = True
                    if pending is not None:
                        self._record(sess, pending, SUPERSEDED, "STOP")
                        pending = None
                else:
                    self._record(sess, tx, REJECTED, "tipo desconocido")
            except InvalidTransitionError as exc:
                self._record(sess, tx, REJECTED, str(exc))
        return pending, to_confirm

    # ── Internos: ring ───────────────────────────────────────────────────────
    def _publish(self, sess: _Session, slot: int, n: int, tgen: int, src0: float,
                 src1: float, ratio1: float, flags: int) -> None:
        sess.n[slot] = n
        sess.tgen[slot] = tgen
        sess.epoch[slot] = sess.ratio_epoch
        sess.src0[slot] = src0
        sess.src1[slot] = src1
        sess.ratio1[slot] = ratio1
        sess.flags[slot] = flags
        if n:
            blk = sess.data[slot, :n]
            l2 = float(np.mean(blk[:, 0].astype(np.float64) ** 2))
            r2 = float(np.mean(blk[:, -1].astype(np.float64) ** 2))
            sess.rms[slot, 0] = l2 ** 0.5
            sess.rms[slot, 1] = r2 ** 0.5
        # Etiqueta comprobada ANTES de entrar al ring audible.
        if tgen < sess.min_valid_gen:
            sess.ledger.stale_dropped_before_ring += 1
            return
        sess.queued_head_frame = src1
        sess.w += 1                      # publicación (el slot ya está completo)
        sess.ledger.blocks_published += 1

    # ── Hilo de render (no-RT) ───────────────────────────────────────────────
    def _render_loop(self, sess: _Session, path: str, ratio0: float) -> None:
        B = PE_BLOCKSIZE
        policy = self._policy
        machine = TransportMachine()
        machine.apply(TransportCommand.play(
            Direction.REVERSE if ratio0 < 0 else Direction.FORWARD))
        machine.state.speed_ratio = machine.state.target_speed = ratio0
        planner = SpeedPlanner(SpeedPlannerConfig(
            max_step_per_tick=PE_SLEW_PER_S * B / max(sess.rate, 1),
            min_ratio=-PE_MAX_RATIO, max_ratio=PE_MAX_RATIO), initial_ratio=ratio0)
        tmp = np.zeros((B, sess.channels), dtype=np.float32)
        period = B / max(sess.rate, 1)
        pending = None
        try:
            with sf.SoundFile(path, "r") as f:
                reader = VariableRateReader(f, sess.channels, block=B,
                                            cache_frames=PE_CACHE_FRAMES,
                                            max_ratio=PE_MAX_RATIO)
                reader.seek(sess.read_head_frame)
                while not sess.cb_hard_stop:
                    pending, to_confirm = self._drain_commands(sess, machine, planner, pending)
                    if sess.w - sess.r >= PE_TARGET_LEAD and not sess.stop_requested:
                        time.sleep(period / 3)
                        continue
                    if sess.w - sess.r >= PE_RING_SLOTS:
                        time.sleep(period / 3)
                        continue
                    slot = sess.w % PE_RING_SLOTS
                    buf = sess.data[slot]
                    r0 = planner.applied_ratio
                    if sess.stop_requested:
                        # STOP: continuación con fundido + marcador de fin.
                        n_valid, p0, p1 = reader.render(buf, B, r0, r0)
                        m, deg = policy.fade_out_tail(buf, min(n_valid, policy.stop_fade),
                                                      policy.stop_fade)
                        buf[min(n_valid, policy.stop_fade):] = 0.0
                        self._log_transition(sess, "STOP", FADE_OUT_END, policy.stop_fade, m,
                                             deg, "audio insuficiente" if deg else "",
                                             machine.state.transport_generation)
                        self._publish(sess, slot, B, machine.state.transport_generation,
                                      p0, p1, r0, _FLAG_TRANSITION)
                        self._publish_end(sess, machine)
                        break
                    r1 = planner.step()
                    flags = 0
                    if pending is not None:
                        tx = pending
                        pending = None
                        try:
                            machine.apply(TransportCommand.seek(int(tx.value)))
                        except InvalidTransitionError as exc:
                            self._record(sess, tx, REJECTED, str(exc))
                            continue
                        tx.transport_generation = machine.state.transport_generation
                        self._record(sess, tx, APPLIED)
                        p0, p1, n_valid, flags = self._render_seek(
                            sess, reader, policy, buf, tmp, tx.value, r0, r1,
                            machine.state.transport_generation)
                        to_confirm.append(tx)
                        machine.apply(TransportCommand(kind=_SEEK_DONE))
                    else:
                        n_valid, p0, p1 = reader.render(buf, B, r0, r1)
                    planner.report_rendered(r1)
                    machine.state.speed_ratio = r1
                    self._sync_direction(machine, r1)
                    sess.read_head_frame = reader.pos
                    eof = n_valid < B
                    if eof:
                        m, deg = policy.fade_out_tail(buf, n_valid, policy.eof_fade)
                        self._log_transition(sess, "EOF", FADE_OUT_END, policy.eof_fade, m,
                                             deg, "bloque final más corto que el fundido"
                                             if deg else "", machine.state.transport_generation)
                        flags |= _FLAG_TRANSITION | (_FLAG_DEGRADED if deg else 0)
                    if n_valid or not eof:
                        self._publish(sess, slot, n_valid, machine.state.transport_generation,
                                      p0, p1, r1, flags)
                    now = time.monotonic()
                    for tx in to_confirm:
                        if tx.status == APPLIED:
                            tx.status = CONFIRMED
                            tx.t_confirm = now
                            sess.ledger.commands_confirmed += 1
                    if eof:
                        sess.eof = True
                        if machine.state.mode not in (TransportMode.STOPPING,):
                            machine.state.mode = TransportMode.EOF
                        self._publish_end(sess, machine)
                        break
        except Exception as exc:
            _plog.error("PlaybackEngine render: %s", exc)
            sess.cb_hard_stop = True
        finally:
            sess.render_done = True
            sess.final_mode = machine.state.mode.name
            sess.final_tgen = machine.state.transport_generation
            sess.final_ratio_applied = planner.applied_ratio
            sess.final_ratio_desired = planner.desired_ratio

    def _publish_end(self, sess: _Session, machine) -> None:
        while sess.w - sess.r >= PE_RING_SLOTS and not sess.cb_hard_stop:
            time.sleep(0.002)
        slot = sess.w % PE_RING_SLOTS
        self._publish(sess, slot, 0, machine.state.transport_generation,
                      sess.queued_head_frame, sess.queued_head_frame, 0.0, _FLAG_END)

    def _render_seek(self, sess, reader, policy, buf, tmp, target, r0, r1, tgen):
        """Bloque de transición de SEEK según la política declarada."""
        B = PE_BLOCKSIZE
        kind = policy.seek_policy
        flags = _FLAG_TRANSITION
        degraded = False
        reason = ""
        if kind == DIP:
            k_out = policy.dip_out
            nv_old, _, _ = reader.render(buf, k_out, r0, r0)
            buf[:k_out] *= policy.ramp_down(k_out)[:, None]
            reader.seek(target)
            n_new = B - k_out
            nv_new, p0n, p1 = reader.render(tmp, n_new, r0, r1)
            buf[k_out:B] = tmp[:n_new]
            fin = min(policy.dip_in, nv_new)
            if fin < policy.dip_in:
                degraded, reason = True, "destino con menos frames que el fundido de entrada"
            if fin:
                ramp = policy.ramp_up(policy.dip_in) if fin == policy.dip_in else \
                    (0.5 - 0.5 * np.cos(np.pi * (np.arange(fin) + 0.5) / fin)).astype(np.float32)
                buf[k_out:k_out + fin] *= ramp[:, None]
            applied = k_out + fin
            planned = policy.dip_out + policy.dip_in
            n_valid = k_out + nv_new
            p0 = target - k_out * r0
        elif kind in (XFADE_EQUAL_POWER, XFADE_LINEAR):
            xf = policy.xfade
            nv_old, _, _ = reader.render(tmp, xf, r0, r0)
            reader.seek(target)
            nv_new, p0, p1 = reader.render(buf, B, r0, r1)
            n_mix = min(xf, nv_old, nv_new)
            if n_mix < xf:
                degraded, reason = True, "audio insuficiente para la ventana completa"
            if n_mix:
                policy.crossfade(tmp, buf, n_mix, kind)
            applied, planned, n_valid = n_mix, xf, nv_new
        else:  # CUT
            reader.seek(target)
            n_valid, p0, p1 = reader.render(buf, B, r0, r1)
            applied = planned = 0
        if degraded:
            flags |= _FLAG_DEGRADED
        self._log_transition(sess, "SEEK", kind, planned, applied, degraded, reason, tgen)
        return p0, p1, n_valid, flags

    def _log_transition(self, sess, op, kind, planned, applied, degraded, reason, tgen):
        rec = TransitionRecord(op, kind, int(planned), int(applied), bool(degraded), reason, tgen)
        sess.transition_log.append(rec)
        sess.ledger.transitions[f"{op}:{kind}"] += 1
        if degraded:
            sess.ledger.degraded_transitions += 1
        log = self.event_log
        if log is not None:
            try:
                log.emit("playback.transport", "WARNING" if degraded else "INFO",
                         f"TRANSITION_{op}", data=rec.__dict__)
            except Exception:
                pass

    @staticmethod
    def _sync_direction(machine, ratio: float) -> None:
        d = Direction.REVERSE if ratio < 0 else Direction.FORWARD
        if machine.state.direction != d:
            machine.state.direction = d
            if machine.state.mode in (TransportMode.PLAY_FORWARD, TransportMode.PLAY_REVERSE):
                machine.state.mode = (TransportMode.PLAY_REVERSE if d == Direction.REVERSE
                                      else TransportMode.PLAY_FORWARD)

    # ── Callback RT ──────────────────────────────────────────────────────────
    @staticmethod
    def _make_callback(sess: _Session):
        data, nmeta, tgen = sess.data, sess.n, sess.tgen
        src0, src1, flags_a, ratio1 = sess.src0, sess.src1, sess.flags, sess.ratio1
        durs = sess.cb_durations
        NS = PE_RING_SLOTS
        ledger = sess.ledger
        perf = time.perf_counter
        CallbackStop = sd.CallbackStop

        def _audio_cb(outdata, frames, time_info, status):
            t0 = perf()
            if sess.cb_hard_stop or sess.cb_done:
                outdata.fill(0)
                raise CallbackStop()
            written = 0
            while written < frames:
                if sess.r == sess.w:
                    # Underrun: silencio EXPLÍCITO y contabilizado.
                    outdata[written:] = 0
                    ledger.underrun_events += 1
                    ledger.underrun_frames += frames - written
                    ledger.last_underrun_generation = sess.audible_generation
                    sess.cb_underrun_consec += 1
                    break
                slot = sess.r % NS
                g = tgen[slot]
                if g < sess.min_valid_gen:
                    ledger.stale_discarded_in_callback += 1
                    sess.r += 1
                    sess.cb_pos = 0
                    continue
                if flags_a[slot] & _FLAG_END:
                    outdata[written:] = 0
                    sess.cb_done = True
                    sess.r += 1
                    raise CallbackStop()
                if g < sess.cb_last_tgen:
                    ledger.mixed_generation_events += 1
                sess.cb_last_tgen = g
                n = nmeta[slot]
                pos = sess.cb_pos
                take = n - pos
                need = frames - written
                if take > need:
                    take = need
                outdata[written:written + take] = data[slot, pos:pos + take]
                written += take
                pos += take
                a, b = src0[slot], src1[slot]
                sess.audible_frame = a + (b - a) * (pos / n) if n else b
                sess.audible_generation = g
                sess.audible_ratio = ratio1[slot]
                sess.cb_underrun_consec = 0
                if pos >= n:
                    sess.last_consumed_slot = slot
                    ledger.blocks_consumed += 1
                    sess.r += 1
                    sess.cb_pos = 0
                else:
                    sess.cb_pos = pos
            durs[sess.cb_count % PE_CB_TIMING_SAMPLES] = perf() - t0
            sess.cb_count += 1

        return _audio_cb

    # ── Hilo de sesión: render + stream + monitor ────────────────────────────
    def _play_loop(self, sess: _Session, path: str, ratio0: float) -> None:
        render = threading.Thread(target=self._render_loop, args=(sess, path, ratio0),
                                  daemon=True, name="pe-render")
        self._render_thread = render
        render.start()
        t0 = time.monotonic()
        while (sess.w < min(PE_TARGET_LEAD, 2) and not sess.render_done
               and not sess.stop_requested and time.monotonic() - t0 < PE_PRELOAD_TIMEOUT):
            time.sleep(0.002)
        try:
            if sess.w == 0:
                _plog.warning("PlaybackEngine: sin datos en %.1fs, abortando", PE_PRELOAD_TIMEOUT)
                return
            self._stream = sd.OutputStream(
                samplerate=sess.rate, channels=sess.channels, dtype="float32",
                blocksize=PE_BLOCKSIZE, latency="low", callback=self._make_callback(sess))
            # Copia local: otro hilo (stop) puede anular self._stream.
            stream_local = self._stream
            with stream_local:
                warn_last = 0.0
                while stream_local.active:
                    if sess.cb_hard_stop or sess.gen != self._gen:
                        break
                    time.sleep(0.020)
                    slot = sess.last_consumed_slot
                    if slot >= 0:
                        for i, attr in ((0, "vu_l"), (1, "vu_r")):
                            db = max(-60.0, min(0.0, 20.0 * _math.log10(
                                max(sess.rms[slot, i], 1e-12))))
                            cur = getattr(self, attr)
                            setattr(self, attr, cur + 0.35 * ((db + 60) / 60 - cur))
                    uc = sess.cb_underrun_consec
                    now = time.monotonic()
                    if uc >= PE_UNDERRUN_LIMIT and now - warn_last > 5.0:
                        warn_last = now
                        _plog.warning("PE UNDERRUN prolongado: %d callbacks consecutivos", uc)
        except Exception as exc:
            _plog.error("PlaybackEngine OutputStream: %s", exc)
        finally:
            sess.cb_hard_stop = True
            render.join(timeout=3.0)
            self.last_session_snapshot = self._snapshot(sess)
            self.vu_l = self.vu_r = 0.0
            self._stream = None
            if sess.gen == self._gen and self._on_done:
                self._on_done()

    # ── Telemetría (fuera del RT) ────────────────────────────────────────────
    def _snapshot(self, s: _Session) -> dict:
        n = min(s.cb_count, PE_CB_TIMING_SAMPLES)
        timing = {"callbacks": s.cb_count}
        if n:
            d = np.sort(s.cb_durations[:n])
            for name, q in (("p50", 0.5), ("p95", 0.95), ("p99", 0.99), ("p999", 0.999)):
                timing[name + "_ms"] = float(d[min(n - 1, int(q * n))] * 1e3)
            timing["max_ms"] = float(d[-1] * 1e3)
            timing["deadline_ms"] = PE_BLOCKSIZE / max(s.rate, 1) * 1e3
            timing["deadline_misses"] = int(np.count_nonzero(d * 1e3 > timing["deadline_ms"]))
        return {
            "session_generation": s.gen,
            "transport_generation": getattr(s, "final_tgen", None),
            "mode": getattr(s, "final_mode", None),
            "requested_frame": s.requested_frame,
            "read_head_frame": s.read_head_frame,
            "queued_head_frame": s.queued_head_frame,
            "audible_frame": s.audible_frame,
            "ui_frame": s.audible_frame,
            "audible_generation": s.audible_generation,
            "audible_ratio": s.audible_ratio,
            "ratio_epoch": s.ratio_epoch,
            "ring_lead_blocks": s.w - s.r,
            "eof": s.eof,
            "seek_policy": self.seek_policy,
            "ledger": s.ledger.as_dict(),
            "callback_timing": timing,
            "transactions": [tx.as_dict() for tx in list(s.history)[-32:]],
            "transitions": [r.__dict__ for r in list(s.transition_log)[-32:]],
        }


# SEEK_DONE es un comando interno del motor (no lo emite la UI).
from lorito_aldhiro.backend.transport.lorito_transport_commands import CommandKind as _CK  # noqa: E402
_SEEK_DONE = _CK.SEEK_DONE
