"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Arranque de sesión: bienvenida, información patrimonial, recuperación tras crash.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_v21 import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image, paint_wood_canvas,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, SignalPulseCell,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




class SessionStartupMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _check_crash_recovery(self):
        """
        Llamado al arrancar si se detectó un heartbeat sin limpiar.

        Distingue dos orígenes del heartbeat:
          · preserve_reason presente en el manifest → cierre limpio con "No":
            Carga el tmp silenciosamente y muestra CAROLA FELIZ (igual que
            _check_informacion_patrimonial), sin el diálogo CAROLA TRANQUILIZADA.
          · Sin preserve_reason → crash real:
            Muestra CracRecuperandoDatClamitDialog (CAROLA TRANQUILIZADA) y
            actúa según la elección del usuario.

        En ambos casos establece _crash_recovery_ran=True para que
        _check_informacion_patrimonial no se solape.
        """
        self._crash_recovery_ran = True   # suprimir el diálogo patrimonial

        manifest = CrashGuard.load_crash_manifest()
        if manifest is None:
            CrashGuard.dismiss()
            return

        ok, err_msg, candidates = _validate_crash_manifest(manifest)
        if not ok:
            _log.warning("CrashGuard: manifest inválido — %s", err_msg)
            CrashGuard.dismiss()
            self.status_label.setText(
                f"__CAROLA_ARROJO__{err_msg[:80]}")
            return

        # ── Distinguir cierre limpio vs crash real ────────────────────────────
        is_clean_preserve = bool(manifest.get("preserve_reason", ""))

        if is_clean_preserve:
            # Cierre limpio con "No": cargar tmp y mostrar CAROLA FELIZ,
            # sin mostrar el diálogo de crash "CAROLA TRANQUILIZADA".
            _log.info("CrashGuard: cierre limpio preservado — cargando tmp sin diálogo de crash")
            self._do_crash_recovery(manifest, candidates)
            # _do_crash_recovery limpia el heartbeat y carga el tmp;
            # ahora mostrar CAROLA FELIZ si hay audio disponible.
            if self._has_audio():
                dlg = CracInformacionPatrimonialDialog(self)
                dlg.exec()
            return

        # ── Crash real: mostrar CAROLA TRANQUILIZADA ──────────────────────────
        dur_s = manifest.get("duration_secs", 0.0)
        if dur_s > 0:
            h, rem = divmod(int(dur_s), 3600)
            m, s   = divmod(rem, 60)
            dur_hms = f"{h:02d}:{m:02d}:{s:02d}"
        else:
            dur_hms = "desconocida"

        dlg = CracRecuperandoDatClamitDialog(dur_hms, self)
        dlg.exec()
        res = dlg.resultado()

        if res == CracRecuperandoDatClamitDialog.RECUPERAR:
            self._do_crash_recovery(manifest, candidates)
            # FIX-RECOVERY-DIALOG: mostrar el diálogo de guardar sesión también
            # tras un crash real. Antes solo aparecía en el path de cierre limpio.
            if self._has_audio():
                dlg = CracInformacionPatrimonialDialog(self)
                dlg.exec()
        else:
            CrashGuard.dismiss()
            self.status_label.setText("__TRANSDIGITALIZADOR_IDIOTA__")
            QTimer.singleShot(5000, lambda: self.status_label.setText("__CAROLALDHIRA_ACTIVA__"))
    def _check_bienvenida(self):
        """
        Llamado al arrancar (diferido 150 ms), solo cuando no hay crash pendiente.
        Muestra CarolaBienvenidaDialog ÚNICAMENTE si el búfer de sesión está vacío
        (primer arranque limpio, sin información cargada ni recuperada por crasheo).
        Si hay audio en el búfer, la bienvenida se suprime: el usuario ya tiene
        trabajo pendiente y _check_informacion_patrimonial tomará el control.
        """
        if self._has_audio():
            return   # hay audio en búfer → no es un arranque limpio
        dlg = CarolaBienvenidaDialog(APP_VERSION, self)
        dlg.exec()
    def _check_informacion_patrimonial(self):
        """
        Llamado al arrancar (diferido 200 ms).
        Muestra CracInformacionPatrimonialDialog ÚNICAMENTE si hay audio grabado
        en el búfer de sesión activo (_disk_tmp_path con contenido válido).
        Si el búfer está vacío o no existe, la interfaz abre directamente sin
        ninguna interrupción.
        NO se activa si en este mismo arranque ya se procesó un crash recovery
        (_crash_recovery_ran=True), para no solapar diálogos.
        """
        # Suprimir si el arranque viene de un crash — crash recovery ya atendió al usuario
        if getattr(self, "_crash_recovery_ran", False):
            return

        # Condición única: hay audio en el búfer de sesión actual
        if self._has_audio():
            dlg = CracInformacionPatrimonialDialog(self)
            dlg.exec()   # bloquea hasta que el usuario pulse "Ingresar y Continuar"
    def _do_crash_recovery(self, manifest: dict, candidates: list):
        """
        Reconstruye la sesión destruida en la GUI y la deja lista para exportar.
        Si solo hay un archivo, lo carga directamente.
        Si hay múltiples segmentos, usa el flujo de exportación multi-segmento
        existente (_build_export_array) apuntando al directorio de segmentos.

        Después de cargar, dispara el export automáticamente con los parámetros
        de la sesión destruida (codec, opt1, opt2, norm).
        """
        rate  = manifest.get("samplerate", 48000)
        codec = manifest.get("codec_hint", "WAV")
        opt1  = manifest.get("opt1", "")
        opt2  = manifest.get("opt2", "")
        norm  = manifest.get("norm", "Sin normalizar")

        # Seleccionar el path principal: preferir el tmp_file si existe,
        # si no, el primer segmento disponible. _build_export_array puede
        # leer todos los segmentos desde el directorio de segmentos.
        tmp_path = manifest.get("tmp_file", "")
        if not (tmp_path and os.path.exists(tmp_path) and
                os.path.getsize(tmp_path) > 512):
            tmp_path = candidates[0] if candidates else ""

        if not tmp_path:
            QMessageBox.critical(
                self, "Recuperación fallida",
                "No se encontró ningún archivo de audio recuperable en disco.")
            CrashGuard.dismiss()
            return

        # Restaurar estado de la GUI para la sesión recuperada
        self._cache_rate        = rate
        self._disk_tmp_path     = tmp_path
        self._disk_total_secs   = manifest.get("duration_secs", 0.0)
        self._disk_total_frames = int(self._disk_total_secs * max(rate, 1))

        # Intentar probe real desde disco para corregir duración
        try:
            with sf.SoundFile(tmp_path, "r") as f:
                self._disk_total_frames = f.frames
                self._cache_rate        = f.samplerate
                self._disk_total_secs   = f.frames / max(f.samplerate, 1)
        except Exception as e:
            _log.warning("CrashGuard probe error: %s", e)

        # Sincronizar controles de la GUI con los parámetros de la sesión
        for i in range(self.rate_box.count()):
            if str(rate) in self.rate_box.itemText(i):
                self.rate_box.setCurrentIndex(i)
                break
        for i in range(self.codec_box.count()):
            if self.codec_box.itemText(i) == codec:
                self.codec_box.setCurrentIndex(i)
                break
        self._update_codec_ui()
        if opt1:
            for i in range(self.opt1_box.count()):
                if self.opt1_box.itemText(i) == opt1:
                    self.opt1_box.setCurrentIndex(i)
                    break
        if opt2:
            for i in range(self.opt2_box.count()):
                if self.opt2_box.itemText(i) == opt2:
                    self.opt2_box.setCurrentIndex(i)
                    break
        if norm:
            for i in range(self.norm_box.count()):
                if self.norm_box.itemText(i) == norm:
                    self.norm_box.setCurrentIndex(i)
                    break

        # Limpiar el heartbeat ANTES de sincronizar la GUI para que si el export
        # falla el usuario no entre en un bucle de recovery infinito.
        CrashGuard.dismiss()

        # ── Restaurar estado del cuentavueltas ────────────────────────────────
        # El manifest guarda los campos counter_* en cada tick de _archival_tick.
        # Aquí los reinyectamos en el TapeLogPanel correcto para que cuando el
        # usuario exporte, get_spec_log_data() retorne los valores reales
        # (no 000) y el log de especificación quede íntegro.
        _counter_tape_lbl = manifest.get("counter_tape_label", "")
        _panel_map = {
            "C-60":  self.tape_c60,
            "C-90":  self.tape_c90,
            "OTROS": self.tape_otros,
        }
        # Seleccionar panel por etiqueta guardada; si no hay, usar el activo actual
        _restore_panel = _panel_map.get(_counter_tape_lbl) or _panel_map.get(
            self.cassette_dur_box.currentText())
        if _restore_panel is not None and any(
            k in manifest for k in (
                "counter_surplus_a", "counter_surplus_b",
                "counter_final_value", "counter_phase",
            )
        ):
            _restore_panel.restore_counter_state(manifest)
            # Sincronizar cassette_dur_box con la cinta recuperada si hay etiqueta
            if _counter_tape_lbl and _counter_tape_lbl in _panel_map:
                for _i in range(self.cassette_dur_box.count()):
                    if self.cassette_dur_box.itemText(_i) == _counter_tape_lbl:
                        self.cassette_dur_box.setCurrentIndex(_i)
                        break

        self._sync_buttons()

        # FIX-SCRUB-RECOVERY-INIT (v0.22.43): resetear explícitamente el estado
        # del scrub de reproducción tras cualquier recovery (crash o cierre limpio).
        # Garantiza que Play arranca desde 0 y no desde un offset espurio de sesión
        # anterior. Se aplica aquí, antes de que el usuario pueda pulsar Play.
        self._scrub_parked_offset = None
        self.scrub.setValue(0.0)
        self.waveform.setPlayPos(0.0)
        self.waveform.setMode("idle")

        # Actualizar waveform desde disco en background
        # OPT-07: worker persistente en lugar de Thread() efímero con lambda closure
        _waveform_worker.submit(self.waveform, self._disk_tmp_path, self._cache_rate)

        dur_hms = ""
        dur_s = self._disk_total_secs
        if dur_s > 0:
            h, r2 = divmod(int(dur_s), 3600); m, s2 = divmod(r2, 60)
            dur_hms = f" ({h:02d}:{m:02d}:{s2:02d})"

        self.status_label.setText(
            f"__CAROLA_SIRVIO__{dur_hms}")
        _log.info("CrashGuard: sesión recuperada — tmp=%s  dur=%.1fs  codec=%s",
                  tmp_path, self._disk_total_secs, codec)
