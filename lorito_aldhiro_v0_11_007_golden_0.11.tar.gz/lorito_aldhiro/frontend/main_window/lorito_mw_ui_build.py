"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Construcción de la interfaz: barra de menús, layout principal, ticks de refresco visual.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_timing import _monotonic_raw_ns
from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_v21 import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image, paint_wood_canvas,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, SignalPulseCell, CounterMegapanel,
    AluminumTitlePlaque, VUMeterChassis, AluminumChassisPanel,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




class UiBuildMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _build_menu_bar(self, menu_h: int):
        ac = THEME["accent"]; br = THEME["bright"]
        _menu_bar = QFrame(self)
        _menu_bar.setGeometry(0, 0, self.W, menu_h)
        _menu_bar.setStyleSheet(
            f"background:rgba(20,16,10,235);"
            f"border-bottom:1px solid rgba({int(ac[0])},{int(ac[1])},{int(ac[2])},90);")
        self._menu_bar = _menu_bar

        _btn_css = (
            "QToolButton{color:rgba(220,210,190,210);background:transparent;"
            "border:none;padding:0 12px;font-family:'Exo 2';font-size:10px;"
            "font-weight:700;letter-spacing:2px;}"
            "QToolButton::menu-indicator{image:none;width:0px;}"
            "QToolButton:hover{background:rgba(255,255,255,18);}"
            "QToolButton:pressed{background:rgba(255,255,255,30);}"
            "QToolButton:disabled{color:rgba(120,112,100,140);}"
        )
        _menu_css = (
            "QMenu{background:rgba(24,20,14,250);color:rgba(220,210,190,220);"
            "border:1px solid rgba(90,80,60,180);font-family:'Exo 2';font-size:10px;}"
            "QMenu::item{padding:5px 18px;}"
            "QMenu::item:selected{background:rgba(255,255,255,25);}"
        )

        def _mbar_btn(label: str) -> QToolButton:
            tb = QToolButton(_menu_bar)
            tb.setText(label)
            tb.setPopupMode(QToolButton.InstantPopup)
            tb.setFixedHeight(menu_h)
            tb.setStyleSheet(_btn_css)
            return tb

        def _mbar_menu(tb: QToolButton) -> QMenu:
            m = QMenu(tb)
            m.setStyleSheet(_menu_css)
            tb.setMenu(m)
            return m

        x = 0

        # ── CINTA: C-60 / C-90 / OTROS — reutiliza cassette_dur_box real ──────
        _mb_cinta = _mbar_btn("CINTA")
        _mb_cinta.setGeometry(x, 0, 70, menu_h); x += 70
        _m_cinta = _mbar_menu(_mb_cinta)
        for _opt in ("C-60", "C-90", "OTROS"):
            _m_cinta.addAction(_opt, lambda o=_opt: self.cassette_dur_box.setCurrentText(o))

        # ── HOST: ALSA / JACK ──────────────────────────────────────────────
        # NOTA DE ALCANCE (§GAP-010): actualiza la celda de leyenda del
        # contómetro y el estado guardado; NO conmuta el backend de audio
        # real (PortAudio/sounddevice) en caliente — requiere una auditoría
        # propia de `lorito_audio_backend.py`, fuera de alcance de esta
        # sesión. Queda documentado como pendiente, no fingido como hecho.
        _mb_host = _mbar_btn("HOST")
        _mb_host.setGeometry(x, 0, 62, menu_h); x += 62
        _m_host = _mbar_menu(_mb_host)
        for _opt in ("ALSA", "JACK"):
            _m_host.addAction(_opt, lambda o=_opt: self._on_host_menu(o))

        # ── MUESTRA: 44100 / 192000 ────────────────────────────────────────
        _mb_muestra = _mbar_btn("MUESTRA")
        _mb_muestra.setGeometry(x, 0, 82, menu_h); x += 82
        _m_muestra = _mbar_menu(_mb_muestra)
        for _opt in ("44100", "192000"):
            _m_muestra.addAction(_opt, lambda o=_opt: self._on_muestra_menu(o))

        # ── BITDEPH: 16 / 24 / 32 ───────────────────────────────────────────
        _mb_bitdeph = _mbar_btn("BITDEPH")
        _mb_bitdeph.setGeometry(x, 0, 80, menu_h); x += 80
        _m_bitdeph = _mbar_menu(_mb_bitdeph)
        for _opt in ("16", "24", "32"):
            _m_bitdeph.addAction(_opt, lambda o=_opt: self._on_bitdeph_menu(o))

        # ── NR: los 8 sistemas de reducción de ruido ────────────────────────
        # NOTA DE ALCANCE (§GAP-010): la selección enciende la celda de
        # leyenda correspondiente y dispara su overlay — el motor DSP real
        # de cada sistema queda para una sesión dedicada (mismo criterio de
        # catálogo incremental que VitriCarola/PARMOSOC en CRAC). Selección
        # única (excluyente), igual que un selector NR real.
        _mb_nr = _mbar_btn("NR")
        _mb_nr.setGeometry(x, 0, 48, menu_h); x += 48
        _m_nr = _mbar_menu(_mb_nr)
        _nr_items = [
            ("DOLBY B", "DOLBY_B", "NR_DOLBY_B"), ("DOLBY C", "DOLBY_C", "NR_DOLBY_C"),
            ("DOLBY S", "DOLBY_S", "NR_DOLBY_S"), ("ANRS", "ANRS", "NR_ANRS"),
            ("S ANRS", "S_ANRS", "NR_S_ANRS"),
            ("DNL", "DNL", "NR_DNL"), ("DNR", "DNR", "NR_DNR"),
        ]
        for _label, _cell_token, _reg_token in _nr_items:
            _m_nr.addAction(_label, lambda c=_cell_token, r=_reg_token: self._on_nr_menu(c, r))
        # DBX: submenú con los tres tipos reales (I/II/224 — §GAP-012,
        # pedido explícito "igual que CRAC"). Misma celda "DBX" del
        # contómetro para los tres; el tipo seleccionado solo cambia la
        # física interna del motor (pre-énfasis + tiempos), no la leyenda.
        _m_dbx = QMenu("DBX", _m_nr)
        _m_dbx.setStyleSheet(_menu_css)
        for _dbx_type in ("I", "II", "224"):
            _m_dbx.addAction(f"DBX {_dbx_type}",
                            lambda t=_dbx_type: self._on_nr_menu("DBX", "NR_DBX", dbx_type=t))
        _m_nr.addMenu(_m_dbx)
        _m_nr.addSeparator()
        _m_nr.addAction("APAGAR NR", lambda: self._on_nr_menu(None, None))

        # ── OPTAPE: HX PRO / ALC / MPX / FOCUS (MPX y FOCUS: pedido
        # explícito del usuario — viven en este mismo menú) ─────────────────
        _mb_optape = _mbar_btn("OPTAPE")
        _mb_optape.setGeometry(x, 0, 72, menu_h); x += 72
        _m_optape = _mbar_menu(_mb_optape)
        _m_optape.addAction("HX PRO", lambda: self._on_optape_menu("HX_PRO"))
        _m_optape.addAction("ALC", lambda: self._on_optape_menu("ALC"))
        _m_optape.addAction("MPX", lambda: self._on_optape_menu("MPX"))
        _m_optape.addAction("FOCUS", lambda: self._on_optape_menu("FOCUS"))
        _m_optape.addSeparator()
        # DSP de CRAC adaptados (GAP-039/040, pedido explícito del
        # usuario: "todos los DSP deben ir al menú OPTAPE"). Los de
        # PREVI llevan la inscripción "(PREVI)" en el propio nombre.
        _m_optape.addAction("FLORECEDOR CRISTHI COSH (PREVI)",
                            self._on_cristhi_cosh_toggle)
        _m_optape.addAction("FLORECEDOR CRISTHI COSH — Ajustes…",
                            self._open_cristhi_cosh_panel)
        _m_optape.addSeparator()
        _m_optape.addAction("ANTIPESTAL LOLA GRILLO (PREVI) — Striker",
                            lambda: self._on_antipestal_menu("STRIKER"))
        _m_optape.addAction("ANTIPESTAL LOLA GRILLO (PREVI) — Kari",
                            lambda: self._on_antipestal_menu("KARI"))
        _m_optape.addAction("ANTIPESTAL LOLA GRILLO — Ajustes…",
                            self._open_antipestal_panel)
        _m_optape.addSeparator()
        _m_optape.addAction("VERSIÓN O TRON (FNESP) — AA-MO",
                            lambda: self._on_o_tron_menu("AA_MO"))
        _m_optape.addAction("VERSIÓN O TRON (FNESP) — Barril",
                            lambda: self._on_o_tron_menu("BARRIL"))
        _m_optape.addAction("VERSIÓN O TRON (FNESP) — Sifón",
                            lambda: self._on_o_tron_menu("SIFON"))
        _m_optape.addSeparator()
        # LUCHA ENLOQUECIDA (PREVI) — GAP-042, 20 sub-perfiles A-T,
        # submenú dedicado (mismo mecanismo ya usado para DBX/dither)
        # para no saturar OPTAPE con 20 entradas de nivel superior.
        from lorito_aldhiro.backend.dsp.lucha_enloquecida import LUCHA_PROFILE_ORDER as _LUCHA_ORDER
        _m_lucha = QMenu("LUCHA ENLOQUECIDA (PREVI)", self)
        for _code, _label, _tech, _cls in _LUCHA_ORDER:
            _m_lucha.addAction(f"{_label} — {_tech}",
                              lambda checked=False, c=_code: self._on_lucha_menu(c))
        _m_optape.addMenu(_m_lucha)
        _m_optape.addSeparator()
        # MUSCLE EQ SAMIR (VITRITO) — GAP-043, orden de ingeniería del
        # usuario. "RESTABLECER" vive en el propio menú (orden §17:
        # accesible de nuevo por OPTAPE → Muscle Eq Samir → RESTABLECER).
        _m_optape.addAction("MUSCLE EQ SAMIR (VITRITO)…", self._open_muscle_eq_panel)
        _m_optape.addAction("MUSCLE EQ SAMIR — RESTABLECER", self._on_muscle_eq_reset)

        # ── MONITOR: Stereo/Mono L/Mono R/Desactivado (pedido explícito
        # del usuario — Lorito Aldhiro no tiene panel izquierdo de
        # botones físicos de monitor, así que vive en la barra de menú).
        # La leyenda L4 del contómetro ("MON n") avanza cíclicamente
        # 1→2→3→1... con cada selección Stereo/Mono L/Mono R (nunca con
        # Desactivado, que apaga la celda) — igual que especificó el
        # usuario.
        _mb_monitor = _mbar_btn("MONITOR")
        _mb_monitor.setGeometry(x, 0, 82, menu_h); x += 82
        _m_monitor = _mbar_menu(_mb_monitor)
        _m_monitor.addAction("STEREO", lambda: self._on_monitor_menu("STEREO"))
        _m_monitor.addAction("MONO L", lambda: self._on_monitor_menu("MONO_L"))
        _m_monitor.addAction("MONO R", lambda: self._on_monitor_menu("MONO_R"))
        _m_monitor.addSeparator()
        _m_monitor.addAction("DESACTIVADO", lambda: self._on_monitor_menu("OFF"))

        # ── EQ/BIAS: emulador de ecualización/bias por tipo de cinta
        # (pedido explícito del usuario) — selección única, con overlay
        # de la fórmula (constante de tiempo) del tipo elegido en el
        # contómetro durante 4s, luego vuelve al contómetro normal.
        _mb_eqbias = _mbar_btn("EQ/BIAS")
        _mb_eqbias.setGeometry(x, 0, 74, menu_h); x += 74
        _m_eqbias = _mbar_menu(_mb_eqbias)
        for _eq_token, _eq_label in (("NORMAL", "NORMAL"), ("CRO2", "CrO2"),
                                     ("FECR", "FeCr"), ("METAL", "METAL")):
            _m_eqbias.addAction(_eq_label,
                                lambda t=_eq_token: self._on_eqbias_menu(t))
        _m_eqbias.addSeparator()
        _m_eqbias.addAction("APAGAR EQ/BIAS", lambda: self._on_eqbias_menu(None))

        # ── DSP: maquilladores dither (pedido explícito del usuario — en
        # Lorito Aldhiro esta función vive aquí, no en Pañalissu como en
        # CRAC). Selección única; enciende/parpadea la celda "DITHER"
        # (R3) del contómetro mientras hay un maquillador seleccionado.
        # NOTA DE ALCANCE (mismo criterio que NR/OPTAPE arriba): el motor
        # DSP real de cada maquillador queda para una sesión dedicada —
        # esto cablea la celda/parpadeo, no un procesamiento de audio
        # todavía inexistente en este proyecto.
        _mb_dsp = _mbar_btn("DSP")
        _mb_dsp.setGeometry(x, 0, 50, menu_h); x += 50
        _m_dsp = _mbar_menu(_mb_dsp)
        _m_dither = QMenu("DITHER", _m_dsp)
        _m_dither.setStyleSheet(_menu_css)
        for _dither_name in ("RECTANGULAR", "TRIANGULAR", "SHAPED (NOISE-SHAPING)"):
            _m_dither.addAction(_dither_name,
                                lambda n=_dither_name: self._on_dsp_dither_menu(n))
        _m_dsp.addMenu(_m_dither)
        _m_dsp.addSeparator()
        _m_dsp.addAction("APAGAR DITHER", lambda: self._on_dsp_dither_menu(None))

        # ── ACERCA: placeholder — cae con gracia a "Fnc No Disp" ─────────────
        _mb_acerca = _mbar_btn("ACERCA")
        _mb_acerca.setGeometry(x, 0, 66, menu_h); x += 66
        _mb_acerca.clicked.connect(self._show_fnc_no_disp)
    def _build_ui(self):
        W, H = self.W, self.H
        # ── Barra de menú (§GAP-010, pedido explícito del usuario, paridad
        # con CRAC) — desplaza todo el resto del lienzo hacia abajo. Todo lo
        # que sigue en este método deriva sus coordenadas Y de forma
        # relativa (VU_TOP, TIMER_Y, SEP0_Y, ... TAPE_Y1), así que sumar
        # MENU_BAR_H aquí y en el punto de partida (VU_TOP/TIMER_Y) basta —
        # el resto de la cascada se ajusta sola.
        MENU_BAR_H = 26
        self._build_menu_bar(MENU_BAR_H)
        VU_W  = 148; CTR_X = VU_W; CTR_W = W - VU_W*2; CTR_XR = CTR_X + CTR_W
        CMB_CSS = THEME["cmb_css"]
        BTN_BASE= THEME["btn_base"]; SEP_CSS = THEME["sep_css"]

        ac = THEME["accent"]; br = THEME["bright"]
        # Label color: blend accent warmth with bright, slightly emphasised
        _lr = min(255, int(ac[0]*0.50 + br[0]*0.50))
        _lg = min(255, int(ac[1]*0.40 + br[1]*0.45))
        _lb = min(255, int(ac[2]*0.30 + br[2]*0.40))
        LBL_CSS = (
            f"color:rgba({_lr},{_lg},{_lb},165);"
            "font-size:7px;"
            "font-family:'Exo 2';"
            "font-weight:600;letter-spacing:2px;background:transparent;"
        )

        def lbl(txt, x, y, w, h=10):
            lb = QLabel(txt.upper(), self); lb.setGeometry(x, y, w, h)
            lb.setStyleSheet(LBL_CSS); return lb
        def cmb(x, y, w, h=26):
            cb = QComboBox(self); cb.setGeometry(x, y, w, h)
            cb.setStyleSheet(CMB_CSS); return cb
        def btn(txt, x, y, w, h, css=BTN_BASE):
            b = QPushButton(txt, self); b.setGeometry(x, y, w, h)
            b.setStyleSheet(css); return b

        VU_TOP=MENU_BAR_H+22; VU_BOT=H-22; VU_H=VU_BOT-VU_TOP; BARW=VU_W-34
        DB_LBL=[("0",0.0),("-6",0.10),("-12",0.20),("-20",0.33),("-30",0.50),("-inf",1.0)]

        # Colores de escala VU para numeraciones (verde→amarillo→rojo segun posición)
        def _vu_num_color(frac):
            """frac 0=top(0dB/rojo) … 1=bottom(-inf/verde)"""
            if frac < 0.15:   return QColor(220, 50, 50, 200)    # rojo (0, -6 dB)
            if frac < 0.35:   return QColor(220, 180, 30, 180)   # amarillo (-12, -20 dB)
            return QColor(60, 180, 80, 160)                        # verde (-30, -inf dB)

        # VU izquierdo (REC)
        # FIX-VU-CORAZA-ALUMINIO (pedido explícito del usuario): toda la
        # columna de VU (encabezado + escala + barras + L/R) queda
        # empotrada sobre una coraza de aluminio pulido
        # (`VUMeterChassis`), con el encabezado y las etiquetas L/R
        # troquelados en aluminio (`AluminumTitlePlaque`) igual que el
        # resto de nombres del panel.
        self._vu_chassis_rec = VUMeterChassis(self)
        self._vu_chassis_rec.setGeometry(4, MENU_BAR_H+2, VU_W-4, H-MENU_BAR_H-2)
        h_rec = AluminumTitlePlaque("REC VU", self, radius=4, font_size=8, letter_spacing=3)
        h_rec.setGeometry(8, MENU_BAR_H+6, VU_W-8, 13)
        for txt, frac in DB_LBL:
            fy = VU_TOP + int(frac*VU_H)
            c  = _vu_num_color(frac)
            dl = QLabel(txt, self); dl.setGeometry(2, fy-5, 22, 10)
            dl.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
            dl.setStyleSheet(
                f"color:rgba({c.red()},{c.green()},{c.blue()},{c.alpha()});"
                "font-size:7px;"
                "font-family:'Exo 2';"
                "font-weight:700;")
        self.vu_rec = VUBar(self); self.vu_rec.setGeometry(26, VU_TOP, BARW, VU_H)
        bw2 = BARW//2
        for i, ch in enumerate(["L","R"]):
            bxl = 26 + i*(bw2+3)
            ll = AluminumTitlePlaque(ch, self, radius=3, font_size=9, letter_spacing=1)
            ll.setGeometry(bxl, VU_BOT+2, bw2, 10)
        sep_l = QLabel(self); sep_l.setGeometry(VU_W-1, MENU_BAR_H, 1, H-MENU_BAR_H); sep_l.setStyleSheet(SEP_CSS)

        # VU derecho (PLAY)
        self._vu_chassis_play = VUMeterChassis(self)
        self._vu_chassis_play.setGeometry(CTR_XR, MENU_BAR_H+2, VU_W-4, H-MENU_BAR_H-2)
        h_play = AluminumTitlePlaque("PLAY VU", self, radius=4, font_size=8, letter_spacing=3)
        h_play.setGeometry(CTR_XR+4, MENU_BAR_H+6, VU_W-8, 13)
        for txt, frac in DB_LBL:
            fy = VU_TOP + int(frac*VU_H)
            c  = _vu_num_color(frac)
            dl = QLabel(txt, self); dl.setGeometry(CTR_XR+VU_W-26, fy-5, 22, 10)
            dl.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
            dl.setStyleSheet(
                f"color:rgba({c.red()},{c.green()},{c.blue()},{c.alpha()});"
                "font-size:7px;"
                "font-family:'Exo 2';"
                "font-weight:700;")
        self.vu_play = VUBar(self); self.vu_play.setGeometry(CTR_XR+8, VU_TOP, BARW, VU_H)
        for i, ch in enumerate(["L","R"]):
            bxr = CTR_XR+8+i*(bw2+3)
            ll = AluminumTitlePlaque(ch, self, radius=3, font_size=9, letter_spacing=1)
            ll.setGeometry(bxr, VU_BOT+2, bw2, 10)
        sep_r = QLabel(self); sep_r.setGeometry(CTR_XR, MENU_BAR_H, 1, H-MENU_BAR_H); sep_r.setStyleSheet(SEP_CSS)

        # Zona central
        PX = CTR_X+10; PW = CTR_W-20

        # ── Título principal ─────────────────────────────────────────────────
        # FIX-PLACA-ALUMINIO (pedido explícito del usuario, corrección
        # sobre el fondo de madera vintage marrón): el título y los
        # nombres de cada widget ya NO son texto negro plano sobre el
        # lienzo — van troquelados sobre una placa de aluminio pulido
        # (`AluminumTitlePlaque`), igual que el resto de biseles
        # metálicos del proyecto.
        title = AluminumTitlePlaque(f"LORITO ALDHIRO {APP_VERSION}", self,
                                     radius=6, letter_spacing=4, font_size=8)
        title.setGeometry(PX, MENU_BAR_H+8, PW, 13)

        # ── Cascada inferior (§GAP-015, pedido explícito del usuario):
        # calculada por altura de bloque ANTES de fijar PANEL_H (panel
        # fusionado del contómetro), con un PAD de separación constante
        # entre cada bloque.
        PAD = 7
        BTN_H = 36
        SCRUB_LBL_RISE = 12; SCRUB_BAR_H = 24
        MORPHER_LBL_H = 9; MORPHER_GAP = 2; MORPHER_BAR_H = 26
        SPEED_LBL_H = 9; SPEED_GAP = 2; SPEED_BAR_H = 26
        WAVE_LBL_RISE = 11; WAVE_BAR_H = 58
        STATUS_H = 34
        TAPE_H = 28
        _BLOCK_HEIGHTS = [
            BTN_H,
            SCRUB_LBL_RISE + SCRUB_BAR_H,
            MORPHER_LBL_H + MORPHER_GAP + MORPHER_BAR_H,
            SPEED_LBL_H + SPEED_GAP + SPEED_BAR_H,
            WAVE_LBL_RISE + WAVE_BAR_H,
            STATUS_H,
            TAPE_H,
        ]
        TIMER_Y=MENU_BAR_H+22; IND_SZ=LuminousIndicator.SIZE; IND_TOTAL_H=LuminousIndicator.TOTAL_H
        _BOTTOM_LIMIT = (H - 22) - 4   # VU_BOT con un pequeño margen
        # ── PANEL FUSIONADO DEL CONTÓMETRO (§CounterMegapanel) —
        # rediseño de panel único pedido explícito del usuario, en
        # reemplazo del bloque anterior donde el contómetro
        # (`DigitalClock`) y la megacelda ondulante (`SignalPulseCell`)
        # eran dos widgets HERMANOS de la MISMA altura (bug reportado:
        # celdas separadas, empujando el lienzo de forma anormal). Ahora
        # son tres megaceldas de UN SOLO widget fusionado: la fórmula
        # cerrada de reparto de alto/ancho vive en
        # `CounterMegapanel._layout_children()` — aquí solo se calcula
        # PANEL_H (todo el espacio vertical disponible tras el resto de
        # la cascada) y se posiciona el panel como una sola pieza.
        _avail_panel_h = (_BOTTOM_LIMIT - TIMER_Y
                          - sum(_BLOCK_HEIGHTS) - PAD*(len(_BLOCK_HEIGHTS) + 1) - PAD)
        PANEL_H = max(100, _avail_panel_h)

        self.counter_panel = CounterMegapanel(self)
        IND_Y = TIMER_Y + (PANEL_H - IND_TOTAL_H)//2
        self.ind = LuminousIndicator(self)
        self.ind.setGeometry(PX+4, IND_Y, IND_SZ, IND_TOTAL_H)

        CMP_X = PX + IND_SZ + 12
        CMP_W = PW - IND_SZ - 12
        self.counter_panel.setGeometry(CMP_X, TIMER_Y, CMP_W, PANEL_H)
        # Alias de compatibilidad — el resto del código (telemetría,
        # overlays, VFD, animación de cassette, etc.) sigue usando
        # self.clock / self.media_anim / self.signal_pulse sin cambios.
        self.clock = self.counter_panel.digital_clock
        self.media_anim = self.counter_panel.media_anim
        self.signal_pulse = self.counter_panel.signal_pulse

        PULSE_Y = TIMER_Y + PANEL_H + PAD


        # ── Combos legados (§GAP-015): OCULTOS, no eliminados — el resto del
        # código (export, _update_codec_ui, etc.) sigue leyendo su
        # .currentText() sin cambios. CINTA/MUESTRA ya migraron a la barra de
        # menú (GAP-010); CODEC se agrega en esta misma sesión
        # (_build_menu_bar). Profundidad(export)/NORMALIZACION quedan sin
        # entrada de menú equivalente todavía — pendiente, ver GAP-015.
        LH = 9; CH = 25
        self.rate_box = cmb(0, 0, 10, CH); self.rate_box.setVisible(False)
        self.rate_box.addItems(["44100 Hz","48000 Hz","96000 Hz"])
        self.rate_box.setCurrentIndex(1)
        self.rate_box.currentTextChanged.connect(self._on_rate_changed)

        self.codec_box = cmb(0, 0, 10, CH); self.codec_box.setVisible(False)
        self.codec_box.addItems(["WAV","FLAC","OGG","WV"])
        self.codec_box.currentTextChanged.connect(self._update_codec_ui)

        self.opt1_box = cmb(0, 0, 10, CH); self.opt1_box.setVisible(False)
        self.norm_box = cmb(0, 0, 10, CH); self.norm_box.setVisible(False)
        self.norm_box.addItems(NORM_ITEMS)  # v0.20: 17 modos (era 2)
        for label in NORM_ITEMS_V21:
            self.norm_box.addItem(label)

        self.opt2_label = lbl("", 0, 0, 10, LH); self.opt2_label.setVisible(False)
        self.opt2_box   = cmb(0, 0, 10, CH);      self.opt2_box.setVisible(False)
        self.opt1_label = lbl("", 0, 0, 10, LH); self.opt1_label.setVisible(False)

        self.cassette_dur_box = cmb(0, 0, 10, CH); self.cassette_dur_box.setVisible(False)
        self.cassette_dur_box.addItems(["C-60", "C-90", "OTROS"])
        self.cassette_dur_box.currentTextChanged.connect(self._on_cassette_dur_changed)

        # ── Botones de control de grabación principal (rediseño con SVG de
        # referencia del usuario — retroiluminación desde el símbolo, ver
        # `LoritoTransportButton`) ─────────────────────────────────────────
        # PULSE_Y ya marca el borde inferior del panel fusionado
        # (`CounterMegapanel`); los botones arrancan justo debajo, sin
        # depender de una altura de "megacelda de pulso" separada
        # (ese concepto ya no existe como bloque independiente).
        BTN_Y = PULSE_Y
        BTN_SP=5; BTN_W=(PW-4*BTN_SP)//5
        BTN_IDLE = THEME.get("btn_idle", THEME["btn_base"])

        def tbtn(icon, txt, x):
            b = LoritoTransportButton(icon, txt, self)
            b.setGeometry(x, BTN_Y, BTN_W, BTN_H)
            b.setStyleSheet(BTN_IDLE)
            return b

        self.btn_record = tbtn(LoritoTransportButton.ICON_REC,   "● REC",    PX+0*(BTN_W+BTN_SP))
        self.btn_pause  = tbtn(LoritoTransportButton.ICON_PAUSE, "|| PAUSA", PX+1*(BTN_W+BTN_SP))
        # FIX-STOP-DOUBLE-CLICK (v0.22.55): btn_stop usa doble clic para
        # distinguir clic simple (stop_all) de doble clic (_scrub_reset_to_start).
        # C.R.A.C especifica: doble clic en STOP = equivalente a tecla E/e:
        # detiene la reproduccion y retorna el scrub al inicio (posicion 0).
        self.btn_stop = tbtn(LoritoTransportButton.ICON_STOP, "■ STOP", PX+2*(BTN_W+BTN_SP))
        self.btn_play   = tbtn(LoritoTransportButton.ICON_PLAY,   "▶ PLAY",   PX+3*(BTN_W+BTN_SP))
        # Renombrado a "SALIDA" (§GAP-015, pedido explícito del usuario).
        self.btn_export = tbtn(LoritoTransportButton.ICON_EXPORT, "↓ SALIDA", PX+4*(BTN_W+BTN_SP))


        self.btn_record.clicked.connect(self.start_record)
        self.btn_pause.clicked.connect(self.toggle_pause)
        self.btn_stop.clicked.connect(self.stop_all)
        self.btn_stop.onDoubleClick = self._scrub_reset_to_start  # doble clic -> reset al inicio
        self.btn_play.clicked.connect(self.play_audio)
        self.btn_export.clicked.connect(self._open_lorito_exportador)

        self.btn_pause.setEnabled(False); self.btn_stop.setEnabled(False)
        self.btn_play.setEnabled(False);  self.btn_export.setEnabled(False)

        # ── Placa única de aluminio pulido (§AluminumChassisPanel,
        # pedido explícito del usuario: fusiona Scrubs + Visor de Señal
        # + panel de logs + panel de duración de cinta en una sola
        # pieza física) — se crea AQUÍ (antes de `scrub_title`) para
        # quedar detrás de todos ellos en el orden de apilado de Qt; su
        # geometría final se fija más abajo, una vez conocida la altura
        # real del panel de duración de cinta (`TAPE_Y1`/`TAPE_H`).
        self._panel_alu = AluminumChassisPanel(self)

        # ── Control de Escaneo (antes "Scrub Seek" / CAROLALDHIRA ESCANEADOR) ─
        SCRUB_Y = BTN_Y + BTN_H + PAD + SCRUB_LBL_RISE
        scrub_title = AluminumTitlePlaque("CONTROL DE ESCANEO", self, radius=5, font_size=8)
        scrub_title.setGeometry(PX, SCRUB_Y-12, PW, 10)

        self.scrub = ScrubBar(self); self.scrub.setGeometry(PX, SCRUB_Y, PW, SCRUB_BAR_H)
        self.scrub.onSeek    = self._scrub_seek_realtime
        self.scrub.onRelease = self._scrub_released

        # ── Control de Torcedura (antes "Scrub Morpher") ──────────────────────
        MORPHER_Y = SCRUB_Y + SCRUB_BAR_H + PAD + MORPHER_LBL_H + MORPHER_GAP
        morpher_lbl = AluminumTitlePlaque("CONTROL DE TORCEDURA", self, radius=4, font_size=7)
        morpher_lbl.setGeometry(PX, MORPHER_Y-MORPHER_GAP-MORPHER_LBL_H, PW, MORPHER_LBL_H)

        self.morpher_scrub = MorpherScrubBar(self)
        self.morpher_scrub.setGeometry(PX, MORPHER_Y, PW, MORPHER_BAR_H)
        self.morpher_scrub.onChanged = self._on_morpher_changed

        # ── Control Velocista (antes "Scrub Velocista") ───────────────────────
        SPEED_Y = MORPHER_Y + MORPHER_BAR_H + PAD + SPEED_LBL_H + SPEED_GAP
        spd_lbl = AluminumTitlePlaque("CONTROL VELOCISTA", self, radius=4, font_size=7)
        spd_lbl.setGeometry(PX, SPEED_Y-SPEED_GAP-SPEED_LBL_H, PW, SPEED_LBL_H)

        self.speed_scrub = SpeedScrubBar(self)
        self.speed_scrub.setGeometry(PX, SPEED_Y, PW, SPEED_BAR_H)
        self.speed_scrub.onChanged = self._on_speed_changed

        # ── Visor de Señal Interactivo (antes "MONITOR CAROLACTICO DE
        # CAPTURA" / panel de forma de onda) ──────────────────────────────────
        WAVE_Y = SPEED_Y + SPEED_BAR_H + PAD + WAVE_LBL_RISE

        wave_lbl = AluminumTitlePlaque("VISOR DE SEÑAL INTERACTIVO", self, radius=4, font_size=7)
        wave_lbl.setGeometry(PX, WAVE_Y-11, PW, 9)

        self.waveform = WaveformDisplay(self)
        self.waveform.setGeometry(PX, WAVE_Y, PW, WAVE_BAR_H)
        # ── Scrub por arrastre sobre la forma de onda ─────────────────────────
        # La línea de playback que atraviesa la pantalla de onda actúa también
        # como scrubber: arrastrar con el ratón mueve el punto de reproducción
        # exactamente igual que el ScrubBarPlay (CONTROL DE ESCANEO).
        self.waveform.onSeek    = self._scrub_seek_realtime
        self.waveform.onRelease = self._scrub_released

        # ── Panel de logs (StatusDisplay) — auto-pausa por silencio siempre
        # habilitada; STATUS_Y calculado directo desde el visor de señal.
        STATUS_Y = WAVE_Y + WAVE_BAR_H + PAD

        self.status_label = StatusDisplay(self)
        self.status_label.setGeometry(PX, STATUS_Y, PW, STATUS_H)

        # ── Panel de duración de cinta (al final, §GAP-015) ───────────────────
        TAPE_GAP = 4
        TAPE_Y1 = STATUS_Y + STATUS_H + PAD
        TAPE_W  = (PW - TAPE_GAP) // 2
        # Guardar métricas para el método de conmutación
        self._tape_px = PX; self._tape_pw = PW
        self._tape_y1 = TAPE_Y1; self._tape_h = TAPE_H
        self._tape_w  = TAPE_W;  self._tape_gap = TAPE_GAP

        # C-60: Lado A nominal = 30 min (1800 s).
        #   Zona tolerancia Lado A : [28 min, 33 min]  (flip_min/flip_max en _FLIP_INTERVALS)
        #   Zona tolerancia Lado B : [58 min, 66 min]  → total_secs = 66*60 = 3960 s
        #   side_b_dur = 3960 - 1800 = 2160 s = 36 min
        #   _b_tol_min = 2160 - (8*60) = 2160-480 = 1680 s → elapsed_total 58 min ✓
        #   SOBRANTE: pasados los 66 min (flip_max Lado B).
        # FIX-LADO-B-TOLERANCIA-EXT3MIN (§GAP-014): total 3780→3960 s (63→66 min),
        # +3 min únicamente al tope máximo (mismo fix que CRAC [0.37.348]).
        self.tape_c60 = TapeLogPanel("C-60", side_a_secs=1800.0,
                                     total_secs=3960.0, parent=self)
        # Arranca a ancho completo (C-60 es la selección inicial)
        self.tape_c60.setGeometry(PX, TAPE_Y1, PW, TAPE_H)

        # C-90: Lado A nominal = 45 min (2700 s).
        #   Zona tolerancia Lado A : [43 min, 48 min]  CRAC-MOTOR-v2 — ventana 5 min (era [44,47])
        #   Zona tolerancia Lado B : [87 min, 95 min]  → total_secs = 95*60 = 5700 s
        #   side_b_dur = 5700 - 2700 = 3000 s = 50 min
        #   _b_tol_min (de _STOP_INTERVALS): 3000-480=2520 s → elapsed_total 87 min ✓
        #   _b_tol_max = side_b_dur = 3000 s → elapsed_total 2700+3000 = 5700 s = 95 min ✓
        #   SOBRANTE: pasados los 95 min (tol_max Lado B).
        # FIX-LADO-B-TOLERANCIA-EXT3MIN (§GAP-014): total 5520→5700 s (92→95 min),
        # +3 min únicamente al tope máximo (mismo fix que CRAC [0.37.348]).
        self.tape_c90 = TapeLogPanel("C-90", side_a_secs=2700.0,
                                     total_secs=5700.0, parent=self)
        self.tape_c90.setGeometry(PX, TAPE_Y1, PW, TAPE_H)
        # Al arrancar: C-60 visible, C-90 y OTROS ocultos (selector inicia en "C-60")
        self.tape_c90.setVisible(False)

        # OTROS: modo libre — hubs giran a 4.76 cm/s en ambar, parpadeo 1s
        self.tape_otros = TapeLogPanel("OTROS", side_a_secs=0.0,
                                       total_secs=0.0, parent=self)
        self.tape_otros.setGeometry(PX, TAPE_Y1, PW, TAPE_H)
        self.tape_otros.setVisible(False)

        # ── Geometría final de la placa fusionada de aluminio ─────────────────
        # Cubre desde el borde superior de "CONTROL DE ESCANEO" hasta el
        # borde inferior del panel de duración de cinta, con un margen
        # de 6px alrededor. Ancho: EXACTAMENTE la zona central (CTR_X →
        # CTR_XR) — toca sin espacio el borde derecho de la coraza VU
        # izquierda y el borde izquierdo de la coraza VU derecha (pedido
        # explícito: "unida... con el acabado de aluminio pulido de los
        # vumeters"), ambos bordes coinciden exactamente con CTR_X/
        # CTR_XR por diseño de esas dos corazas.
        _ALU_MARGIN = 6
        _alu_y0 = SCRUB_Y - SCRUB_LBL_RISE - _ALU_MARGIN
        _alu_y1 = TAPE_Y1 + TAPE_H + _ALU_MARGIN
        self._panel_alu.setGeometry(CTR_X, _alu_y0, CTR_W, _alu_y1 - _alu_y0)
        # NUNCA lower(): `self._panel_alu` ya nació ANTES que
        # scrub_title/status_label/tape panels (ver su creación más
        # arriba) y DESPUÉS de `self.bg` (WoodCanvasBackground, creado
        # en `__init__`) — el orden de creación en Qt ya lo deja
        # correctamente apilado (visible sobre la madera, detrás de los
        # widgets que aloja) sin necesitar tocar el orden Z a mano;
        # `lower()` aquí lo empujaría por DEBAJO de `self.bg` también,
        # ocultándolo por completo detrás del lienzo de madera.

        # ── Inyectar callbacks de volteo lado B y parada automática ──────────
        # El TapeLogPanel llama a estos callbacks cuando detecta que es hora de
        # voltear la cinta o de detener la grabación automáticamente.
        def _make_flip_cb(tp):
            def _flip():
                # Solo actuar si es el panel activo
                _active_txt = self.cassette_dur_box.currentText()
                if tp._tape_label != _active_txt:
                    return
                # Notificar al motor ITL del volteo manual (GUI → ITL)
                if self._itl_bridge is not None:
                    self._itl_bridge.on_flip_side_b()
                # Activar auto-pausa por volteo (misma mecánica que auto-pausa silencio)
                if self._engine.recording and not self._engine.paused:
                    self._activate_silence_autopause()
                # Marcar que el volteo está pendiente de que el usuario desactive pausa
                tp._flip_pending = True
                # Overlay ITL en el contómetro — calco exacto de "FnSide A"
                # de CRAC (Lorito Aldhiro solo voltea A→B, nunca autoreversa,
                # así que el único caso real es dejar el Lado A — GAP-010).
                if hasattr(self, "clock"):
                    self.clock.setOverlayFromRegistry("ITL", True, "FN_SIDE_A")
                # Celda lateral L1 (§SignalPulseCell/columna izquierda,
                # pedido explícito del usuario): LADO A→B al voltear.
                self.clock.set_tape_side("B")
            return _flip

        def _make_stop_cb(tp):
            def _stop():
                _active_txt = self.cassette_dur_box.currentText()
                if tp._tape_label != _active_txt:
                    return
                if self._engine.recording:
                    # FIX-TAPE-DUR-SILENCE v0.22.22: delegar en _activate_silence_autopause
                    # para que el motor de detención use el mismo umbral de silencio
                    # (SILENCE_REF_CEILING_LIN / -61.46 dBFS) que la auto-pausa dedicada.
                    # Si la auto-pausa ya está activa (silencio confirmado por CRAC),
                    # pasar directamente a detener; si no, activar auto-pausa primero.
                    if not self._silence_autopause_active:
                        self._activate_silence_autopause()
                    # Overlay en el contómetro — calco exacto de "FnTape
                    # Aldh" de CRAC (fin de Lado B, deteniendo la grabación
                    # — ver GAP-010).
                    if hasattr(self, "clock"):
                        self.clock.setOverlayFromRegistry("FN_TAPE_ALDH", True, "FN_TAPE_ALDH")
                    # Detener la grabación en el siguiente ciclo del event loop,
                    # permitiendo que la auto-pausa termine de notificar a los widgets.
                    QTimer.singleShot(0, self.stop_all)
            return _stop

        self.tape_c60.on_flip_side_b = _make_flip_cb(self.tape_c60)
        self.tape_c60.on_auto_stop   = _make_stop_cb(self.tape_c60)
        self.tape_c90.on_flip_side_b = _make_flip_cb(self.tape_c90)
        self.tape_c90.on_auto_stop   = _make_stop_cb(self.tape_c90)

        # ── CRAC-MOTOR-v3: instanciar motor e inyectar callbacks ──────────────
        for _tp_panel in (self.tape_c60, self.tape_c90):
            _tp_panel._crac_motor = make_motor(_tp_panel._tape_label)
            if _tp_panel._crac_motor is not None:
                _tp_panel._crac_motor.on_forced_pause_a   = _tp_panel.on_flip_side_b
                _tp_panel._crac_motor.on_autopause_switch = None   # notificación interna; cb en Studio
                _tp_panel._crac_motor.on_flip_side_b      = _tp_panel.on_flip_side_b
                _tp_panel._crac_motor.on_auto_stop        = _tp_panel.on_auto_stop

        # ── Motor ITL: longitud física virtual de cinta, thread propio ────────
        # Desacoplado del framerate GUI. Reloj maestro = posición en cm.
        # Sin drift. Sin race conditions. Sin dependencia de timers Qt.
        if _ITL_AVAILABLE:
            self._itl_bridge = integrate_itl_into_studio(self)
        else:
            self._itl_bridge = None

        # buf_label: proxy que redirige setText al setAux del StatusDisplay
        class _BufProxy:
            def __init__(self_, disp): self_._d = disp
            def setText(self_, t):     self_._d.setAux(t)
            def text(self_):           return self_._d._aux
        self.buf_label = _BufProxy(self.status_label)

        # Estado inicial de la celda HOST (§GAP-010) — ALSA es el backend
        # más común en Linux; no implica que el backend real se haya
        # conmutado, solo refleja el estado por defecto en la leyenda.
        self.clock.set_host_cell("ALSA")
        self._host_backend = "ALSA"
    def _update_codec_ui(self):
        c = self.codec_box.currentText()
        self.opt1_box.blockSignals(True); self.opt2_box.blockSignals(True)
        self.opt1_box.clear(); self.opt2_box.clear()
        if c == "WAV":
            self.opt1_box.addItems(WAV_DEPTHS); self.opt1_box.setCurrentText("24-bit PCM")
            self.opt2_box.setVisible(False); self.opt2_label.setVisible(False)
            self.opt1_box.setVisible(True)
        elif c == "FLAC":
            self.opt1_box.addItems(FLAC_DEPTHS); self.opt1_box.setCurrentText("24-bit PCM")
            self.opt2_label.setText("COMPRESION")
            self.opt2_box.addItems(FLAC_COMPS); self.opt2_box.setCurrentText("4 (estandar)")
            self.opt1_box.setVisible(True); self.opt2_box.setVisible(True)
            self.opt2_label.setVisible(True)
        elif c == "OGG":
            self.opt1_box.addItems(OGG_QUALS); self.opt1_box.setCurrentText("5 (estandar)")
            self.opt2_box.setVisible(False); self.opt2_label.setVisible(False)
            self.opt1_box.setVisible(True)
            # Aviso si ningún encoder Vorbis disponible
            if not FFMPEG_CAPS["available"]:
                self.opt2_label.setText("sin ffmpeg")
                self.opt2_label.setVisible(True)
        elif c == "WV":
            self.opt1_box.addItems(WV_MODES); self.opt1_box.setCurrentText("Estandar")
            self.opt2_box.setVisible(False); self.opt2_label.setVisible(False)
            self.opt1_box.setVisible(True)
            if not FFMPEG_CAPS["available"]:
                self.opt2_label.setText("sin ffmpeg")
                self.opt2_label.setVisible(True)
        self.opt1_box.blockSignals(False); self.opt2_box.blockSignals(False)
    def _btn_idle_css(self):
        return THEME.get("btn_idle", THEME["btn_base"])
    def _set_ui_state(self, state):
        if self._ui_state == state: return
        self._ui_state = state; self.clock.setState(state)
        idle = self._btn_idle_css()
        # Resetear todos a idle primero
        for b in (self.btn_record, self.btn_pause, self.btn_stop,
                  self.btn_play, self.btn_export):
            b.setStyleSheet(idle)
            b.setIconLit(False)
        # Iluminar el botón activo (bisel QSS + símbolo retroiluminado)
        if state == "rec":
            self.btn_record.setStyleSheet(THEME.get("btn_active_rec", idle))
            self.btn_record.setIconLit(True)
        elif state == "pause":
            self.btn_pause.setStyleSheet(THEME.get("btn_active_pau", idle))
            self.btn_pause.setIconLit(True)
        elif state == "stop":
            self.btn_stop.setStyleSheet(THEME.get("btn_active_stop", idle))
            self.btn_stop.setIconLit(True)
        elif state == "play":
            self.btn_play.setStyleSheet(THEME.get("btn_active_play", idle))
            self.btn_play.setIconLit(True)
        elif state == "export":
            self.btn_export.setStyleSheet(THEME.get("btn_active_exp", idle))
            self.btn_export.setIconLit(True)
    def _sync_buttons(self):
        recording = self._engine.recording
        exporting = (self._ui_state == "export")
        stopping  = (self._ui_state == "stop")
        has = self._has_audio()   # True si hay audio en búfer

        # ── Apariencia tenue: solo durante grabación activa ───────────────────
        self.scrub.setDimmed(recording)
        self.speed_scrub.setDimmed(recording)
        self.morpher_scrub.setDimmed(recording)

        # ── EXPORTANDO: bloquear absolutamente todo ───────────────────────────
        if exporting:
            for b in (self.btn_record, self.btn_pause, self.btn_stop,
                      self.btn_play, self.btn_export):
                b.setEnabled(False)
            self.scrub.setEnabled(False)
            self.rate_box.setEnabled(False)
            self.cassette_dur_box.setEnabled(False)
            self.codec_box.setEnabled(False)
            self.opt1_box.setEnabled(False)
            self.opt2_box.setEnabled(False)
            self.norm_box.setEnabled(False)
            self.speed_scrub.setEnabled(False)
            self.morpher_scrub.setEnabled(False)
            return

        # ── VACIANDO (stop): bloqueo total — idéntico al de "exporting" ────────
        # v0.20.23: durante el vaciado de disco post-grabación, todos los controles
        # deben estar deshabilitados, no solo los scrubs. Interacciones durante el
        # flush pueden corromper el estado interno del engine y el disk writer.
        if stopping:
            for b in (self.btn_record, self.btn_pause, self.btn_stop,
                      self.btn_play, self.btn_export):
                b.setEnabled(False)
            self.scrub.setEnabled(False)
            self.rate_box.setEnabled(False)
            self.cassette_dur_box.setEnabled(False)
            self.codec_box.setEnabled(False)
            self.opt1_box.setEnabled(False)
            self.opt2_box.setEnabled(False)
            self.norm_box.setEnabled(False)
            self.speed_scrub.setEnabled(False)
            self.morpher_scrub.setEnabled(False)
            return

        # ── GRABANDO: todos los menús bloqueados, solo STOP operativo ─────────
        if recording:
            self.btn_record.setEnabled(False)
            self.btn_pause.setEnabled(True)
            self.btn_stop.setEnabled(True)
            self.btn_play.setEnabled(False)
            self.btn_export.setEnabled(False)
            self.scrub.setEnabled(False)
            self.rate_box.setEnabled(False)
            self.cassette_dur_box.setEnabled(False)
            self.codec_box.setEnabled(False)
            self.opt1_box.setEnabled(False)
            self.opt2_box.setEnabled(False)
            self.norm_box.setEnabled(False)
            self.speed_scrub.setEnabled(False)
            self.morpher_scrub.setEnabled(False)
            return

        # ── REPOSO / REPRODUCCIÓN ─────────────────────────────────────────────
        self.btn_record.setEnabled(not self._playing)
        self.btn_pause.setEnabled(False)
        self.btn_stop.setEnabled(self._playing)
        self.btn_play.setEnabled(has and not self._playing)
        self.btn_export.setEnabled(has and not self._playing)
        self.scrub.setEnabled(has)

        # Frecuencia de muestreo: solo si NO hay audio en búfer
        self.rate_box.setEnabled(not has)

        # Duración de cassette: solo si NO hay audio en búfer
        # (debe configurarse antes de grabar)
        self.cassette_dur_box.setEnabled(not has)

        # Codec y tasa de bits (opt1/opt2): habilitados cuando HAY contenido en búfer
        # (solo tiene sentido exportar cuando hay algo grabado)
        codec_ok = has and not self._playing
        self.codec_box.setEnabled(codec_ok)
        self.opt1_box.setEnabled(codec_ok)
        self.opt2_box.setEnabled(codec_ok)

        # Normalización: disponible cuando hay audio y no se está reproduciendo
        self.norm_box.setEnabled(has and not self._playing)

        # Scrubs de velocidad y morpher
        speed_ok  = has and not self._morpher_active
        morpher_ok = self._playing and not self._speed_scrub_active
        self.speed_scrub.setEnabled(speed_ok)
        self.morpher_scrub.setEnabled(morpher_ok)
    def _has_audio(self) -> bool:
        """Devuelve True si hay un archivo temporal válido con audio grabado."""
        p = self._disk_tmp_path
        return bool(p and os.path.exists(p) and os.path.getsize(p) > 512)
    def _on_rate_changed(self, _):
        if self._has_audio():
            self._disk_tmp_path = None
            self._disk_total_frames = 0
            self._disk_total_secs   = 0.0
            self._engine.buffer.clear()
            self._invalidate_speed_cache()
            self.waveform.clearWave(); self._sync_buttons()
    def _on_cassette_dur_changed(self, text):
        """Conmuta la visibilidad de los paneles Tape Log según la selección."""
        # Celda conmutable de la fila inferior del contómetro (§GAP-010,
        # pedido explícito del usuario: la celda "C-60" alterna entre
        # C-60/C-90/OTROS).
        if hasattr(self, "clock"):
            self.clock.set_tape_label_cell(text)
        px  = self._tape_px;  pw  = self._tape_pw
        y1  = self._tape_y1;  th  = self._tape_h
        if text == "C-60":
            self.tape_c60.setGeometry(px, y1, pw, th)
            self.tape_c60.setVisible(True)
            self.tape_c90.setVisible(False)
            self.tape_otros.setVisible(False)
        elif text == "C-90":
            self.tape_c90.setGeometry(px, y1, pw, th)
            self.tape_c60.setVisible(False)
            self.tape_c90.setVisible(True)
            self.tape_otros.setVisible(False)
        else:  # OTROS
            self.tape_otros.setGeometry(px, y1, pw, th)
            self.tape_c60.setVisible(False)
            self.tape_c90.setVisible(False)
            self.tape_otros.setVisible(True)
    def _blink(self):
        self._blink_state = not self._blink_state
        if hasattr(self, "clock"):
            self.clock.tick_dither_blink()
            self.clock.tick_legend_alternation()
            self.clock.tick_muscle_eq_alternation()
        recording = self._engine.recording; paused = self._engine.paused
        # Durante vaciado post-grabación o export no interferir con el estado
        # en curso: _on_stop_ready/_on_backend_status son los únicos responsables
        # de salir de esos estados. Sin esta guardia, _blink puede pisar
        # _ui_state con "standby" antes de que el slot correspondiente termine,
        # activando el guard de _set_ui_state y dejando los botones congelados.
        if self._ui_state in ("stop", "export"):
            # Mantener parpadeo azul del vaciado activo
            self.status_label.setText("__FLUSH_BLINK_TICK__")
            return
        if recording and not paused:
            self._set_ui_state("rec")
            self.ind.setState("rec"); self.ind.setBlink(self._blink_state)
            if hasattr(self, "media_anim"):
                self.media_anim.setState("rec")
                self.media_anim.setBlink(True)
        elif paused:
            self._set_ui_state("pause")
            self.ind.setState("pause"); self.ind.setBlink(self._blink_state)
            if hasattr(self, "media_anim"):
                self.media_anim.setState("pause")
                # NO llamamos setBlink aquí: el parpadeo de la PC en pausa lo
                # sincronizan _on_cafe_blink_tick (pausa manual / BUSYCHAN) y
                # _on_carola_waiting_blink (auto-pausa silencio / CAROLA WAITING)
                # para que la PC y la leyenda de logs parpadeen en fase perfecta.
        elif self._playing:
            self._set_ui_state("play")
            self.ind.setState("play"); self.ind.setBlink(True)
            if hasattr(self, "media_anim"):
                self.media_anim.setState("play")
                self.media_anim.setBlink(True)
        else:
            self._set_ui_state("standby")
            self.ind.setState("standby"); self.ind.setBlink(True)
            if hasattr(self, "media_anim"):
                self.media_anim.setState("idle")
                self.media_anim.setBlink(True)
    def _tick_cassette(self):
        """
        Timer ~24 fps: avanza el ángulo de los hubs y determina el modo
        de la animación de cassette según el estado actual de la sesión.

        Modos:
          "rec"       — grabación activa (sin pausa): rojo encendido, giro constante
          "drift"     — grabación + drift warning detectado: color warn + parpadeo
          "play"      — reproducción activa: color verde-ok, giro proporcional
          "speed"     — velocista activo: púrpura, giro escalado al ratio
          "morph_fwd" — morphing adelante: amarillo, giro escalado al ratio morpher
          "morph_rev" — morphing reversa: cyan, giro invertido
          None        — todo lo demás: animación apagada
        """
        recording = self._engine.recording
        paused    = self._engine.paused
        playing   = self._playing

        morpher_active  = getattr(self, "_morpher_active", False)
        morpher_reverse = getattr(self, "_morpher_reverse", False)
        speed_active    = getattr(self, "_speed_scrub_active", False)

        # Determinar modo — prioridad: rec/drift > morph > speed > play
        reverse_flag = False
        if recording and not paused:
            msg_upper = self.status_label._msg.upper()
            if "LORITO VIO UNA DERIVA" in msg_upper or "LORITO EN PERDIDA FUERTE" in msg_upper or "LORITO EN PERDIDA LEVE" in msg_upper:
                mode = "drift"
            else:
                mode = "rec"
        elif morpher_active:
            if morpher_reverse:
                mode = "morph_rev"
                reverse_flag = True
            else:
                mode = "morph_fwd"
        elif speed_active:
            mode = "speed"
        elif playing:
            mode = "play"
        else:
            mode = None

        # Cuando el log muestra CAROLALDHIRA ACTIVA! (velocista volvió al neutro),
        # suprimir animación de hubs de cassette independientemente del modo
        if getattr(self.status_label, "_level", None) == "activa":
            mode = None

        # FIX-HUB-GHOST (v0.22.41): si el modo es "speed" o "morph_*" pero los
        # flags correspondientes ya están en False (reset asíncrono), suprimir el
        # modo para evitar que el hub quede pintado con el color del scrub inactivo.
        if mode == "speed" and not speed_active:
            mode = None
        elif mode in ("morph_fwd", "morph_rev") and not morpher_active:
            mode = None

        # Avance angular por tick (grados)
        # Velocidad base calibrada a 4.76 cm/s (velocidad nominal IEC de cassette):
        #   hub interior r≈11 mm → RPM = 47.625/(2π×11) ≈ 41.3 rpm
        #   timer 42 ms/tick → ~23.8 ticks/s → delta = 360×0.689/23.8 ≈ 10.4°/tick
        BASE_DELTA = 10.4
        if mode in ("rec", "drift"):
            delta = BASE_DELTA
        elif mode == "play":
            delta = BASE_DELTA * abs(getattr(self, "_speed_ratio", 1.0))
        elif mode == "speed":
            delta = BASE_DELTA * abs(getattr(self, "_speed_ratio", 1.0))
        elif mode in ("morph_fwd", "morph_rev"):
            delta = BASE_DELTA * abs(getattr(self, "_morpher_ratio", 1.0))
        else:
            delta = 0.0

        if delta > 0:
            self._cassette_angle = (self._cassette_angle + delta) % 360.0

        # Parpadeo en modo drift: alternar cada ~6 ticks (~250ms)
        if mode == "drift":
            self._cassette_blink_ctr += 1
            if self._cassette_blink_ctr >= 6:
                self._cassette_blink_ctr = 0
                self._cassette_blink_st  = not self._cassette_blink_st
        else:
            self._cassette_blink_ctr = 0
            self._cassette_blink_st  = True   # siempre visible en otros modos

        self.status_label.tickCassette(
            self._cassette_angle, mode, self._cassette_blink_st,
            reverse=reverse_flag
        )
        # OPT-CASSETTE-DIRTY: guardar modo previo para detectar cambios
        self._cassette_prev_mode = mode

        # ── Avance de animación lateral (MediaAnimWidget) ─────────────────────
        if hasattr(self, "media_anim"):
            self.media_anim.tick(delta, reverse=reverse_flag)

        # ── Actualizar paneles de Tape Log C-60 / C-90 ───────────────────────
        # FIX v0.22.24: capturar time.monotonic() UNA SOLA VEZ por tick para
        # que el contometro principal y el motor de duración de cinta usen el
        # mismo snapshot temporal. Esto elimina errores de corrida de tiempo
        # entre ambas etapas, que son independientes pero paralelas.
        _now_tick = time.monotonic()
        if recording and not paused:
            elapsed = self._rec_elapsed + (_now_tick - self._rec_start_t)
        else:
            elapsed = self._rec_elapsed

        _tape_active = recording and not paused
        _autopause_active = getattr(self, "_silence_autopause_active", False)
        # Motor de duración de cinta — corre paralelo al contometro principal.
        # Ambos usan el mismo elapsed calculado arriba (snapshot único por tick).
        if hasattr(self, "tape_c60"):
            self.tape_c60.update_state(_tape_active, elapsed, _autopause_active)
        if hasattr(self, "tape_c90"):
            self.tape_c90.update_state(_tape_active, elapsed, _autopause_active)
        if hasattr(self, "tape_otros"):
            self.tape_otros.update_state(_tape_active, elapsed, _autopause_active)

        # FIX-OVERFLOW-BLINK-SYNC (v0.22.49): gestionar _overflow_blink_timer.
        # El timer se arranca cuando cualquier panel entra en desbordamiento y se
        # detiene cuando ninguno está en desbordamiento. Esto separa el parpadeo
        # del overflow del tick de update_state (15 Hz) y lo sinroniza con
        # SILENCE_BLINK_INTERVAL_MS (480 ms), mismo ritmo que "¡OYE, ¿DÓNDE TE HAS METIDO?!".
        _any_overflow = any(
            getattr(_tp, "_counter_overflow", False)
            for _tp in (getattr(self, "tape_c60", None),
                        getattr(self, "tape_c90", None),
                        getattr(self, "tape_otros", None))
            if _tp is not None
        )
        _ovf_timer = getattr(self, "_overflow_blink_timer", None)
        if _ovf_timer is not None:
            if _any_overflow and not _ovf_timer.isActive():
                _ovf_timer.start()
            elif not _any_overflow and _ovf_timer.isActive():
                _ovf_timer.stop()
        # Overlay "OvFlow TP" en el contómetro — calco exacto de CRAC
        # (GAP-010), sincronizado con el mismo flag _any_overflow.
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("OVFLOW_TP", _any_overflow, "OVFLOW_TP")

        # ── Repaint de VUBar y WaveformDisplay a 24 Hz ───────────────────────
        # Los valores ya fueron calculados y suavizados en _tick() (15 Hz).
        # Aquí solo se transfieren al widget y se dispara update() — sin cálculo
        # de audio — para que el movimiento visual sea fluido e interpolado.
        if hasattr(self, "vu_rec") and hasattr(self, "vu_play"):
            _vu_now = time.monotonic()
            if getattr(self, "_rec_vu_active", False):
                self.vu_rec.setValues(
                    getattr(self, "_rec_vu_l", 0.0),
                    getattr(self, "_rec_vu_r", 0.0), now=_vu_now)
                self.vu_rec.setQuality(getattr(self, "_rec_vu_quality", "VALID"))
                self.vu_rec.update()   # FIX-VUMETERS-FROZEN: setValues no repinta; update() aquí (GUI thread, seguro)
            else:
                self.vu_rec.decay(now=_vu_now)   # decay() ya incluye su propio update()

            if getattr(self, "_playing", False):
                self.vu_play.setValues(
                    getattr(self, "_play_vu_l", 0.0),
                    getattr(self, "_play_vu_r", 0.0), now=_vu_now)
                self.vu_play.update()  # FIX-VUMETERS-FROZEN: ídem para VU de reproducción
            else:
                self.vu_play.decay(now=_vu_now)   # decay() ya incluye su propio update()

        # Megacelda ondulante de señal (§SignalPulseCell) — CONEXIÓN
        # REAL al motor de captura (corregido en esta sesión, pedido
        # explícito del usuario): mientras se está grabando, se le pasa
        # el bloque de muestras CRUDAS real (`_monitor_block`, el mismo
        # buffer prealocado que ya escribe `_audio_callback` en tiempo
        # real — ver `lorito_capture_engine.py`), mezclado a mono, para
        # que el trazo sea un osciloscopio real de la señal entrante —
        # NO una síntesis decorativa. Sin grabación activa, se usa el
        # nivel de reproducción como fallback (el reproductor no expone
        # todavía un buffer de muestras crudas, ver GAP de referencia);
        # en reposo, `set_level(0, 0)` deja el trazo realmente plano.
        if hasattr(self, "signal_pulse"):
            _mon_n = getattr(self._engine, "_monitor_block_frames", 0)
            if (getattr(self._engine, "recording", False)
                    and not getattr(self._engine, "paused", False)
                    and _mon_n > 0):
                _blk = self._engine._monitor_block[:_mon_n]
                _mono = _blk.mean(axis=1) if _blk.ndim > 1 and _blk.shape[1] > 1 else _blk[:, 0] if _blk.ndim > 1 else _blk
                self.signal_pulse.set_samples(_mono)
            elif getattr(self, "_playing", False):
                self.signal_pulse.set_level(
                    getattr(self, "_play_vu_l", 0.0), getattr(self, "_play_vu_r", 0.0))
            else:
                self.signal_pulse.set_level(0.0, 0.0)

        # Waveform: actualizar pos de reproducción a 24 Hz para cursor suave
        if hasattr(self, "waveform") and getattr(self, "_playing", False):
            _total = getattr(self, "_disk_total_secs", 0.0)
            if _total > 0 and hasattr(self, "_player"):
                _pos_s = self._player.src_pos / max(getattr(self, "_cache_rate", 48000), 1)
                self.waveform.setPlayPos(_pos_s / _total)
                self.waveform.update()
    def _tick(self):
        # ── AIPLO: auditar tick de GUI a 15 Hz ───────────────────────────────
        # firma='aiplo_frn_tick'
        if _AIPLO_FRN_ACTIVE:
            global _aiplo_frn_tick_seq
            _aiplo_frn_tick_seq += 1
            _aiplo_frn_counters["tick_total"] += 1
            _frn_emit("AIPLO_TICK", {
                "seq"  : _aiplo_frn_tick_seq,
                "total": _aiplo_frn_counters["tick_total"],
            })
        # ────────────────────────────────────────────────────────────────────
        recording = self._engine.recording; paused = self._engine.paused
        buf       = self._engine.buffer;    lock   = self._engine.lock

        # VU grabación — Orden Golden UI/ITL (INST-01/02): el nivel lo mide el
        # motor de captura (hilo de drenaje) con ventana de FRAMES por canal
        # (RMS 300 ms, peak de muestra, dBFS); la GUI solo lee el último
        # snapshot inmutable y su antigüedad. Sin EWMA por ticks (dependiente
        # del jitter del temporizador). Dato viejo → STALE visible, no "silencio".
        self._rec_vu_quality = "UNAVAILABLE"
        if recording and not paused:
            _snap = None
            try:
                _snap = self._engine.telemetry_snapshot()
            except Exception:
                _snap = None
            if _snap is not None and _snap.readings:
                self._rec_vu_quality = _snap.quality_at(time.monotonic(), stale_after_s=0.5)
                if self._rec_vu_quality == "VALID":
                    _rd = _snap.readings
                    _l = _rd[0].rms_dbfs
                    _r = _rd[1].rms_dbfs if len(_rd) > 1 else _l
                    self._rec_vu_l = (min(0.0, max(-60.0, _l)) + 60.0) / 60.0
                    self._rec_vu_r = (min(0.0, max(-60.0, _r)) + 60.0) / 60.0
                # STALE: se conserva el último valor (sin inventar silencio)
                self._rec_vu_active = True
                _rms_now = max(self._rec_vu_l, self._rec_vu_r)
            else:
                self._rec_vu_active = False
                _rms_now = 0.0
        else:
            self._rec_vu_l = max(0.0, self._rec_vu_l - VUBar.DECAY_STEP * 2)
            self._rec_vu_r = max(0.0, self._rec_vu_r - VUBar.DECAY_STEP * 2)
            self._rec_vu_active = False
            _rms_now = 0.0

        # VU reproducción — guardar en estado; repaint en _tick_cassette
        if self._playing:
            self._play_vu_l = self._player.vu_l
            self._play_vu_r = self._player.vu_r
            _rms_now = max(_rms_now, self._play_vu_l, self._play_vu_r)
        else:
            self._play_vu_l = 0.0
            self._play_vu_r = 0.0

        # Propagar RMS a waveform y paneles de cinta para glow analógico
        self.waveform.setRms(_rms_now)
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None),
                    getattr(self, "tape_otros", None)):
            if _tp is not None:
                _tp.setRms(_rms_now)

        # ── Auto-pausa por silencio: evaluar en cada tick de grabación ────────
        # CRAC: siempre leer audio crudo float32 — nunca derivar de la escala
        # VU normalizada (que está clippeada a [-60, 0] dBFS y enmascara el
        # silencio real). Se usa _monitor_block en ambos estados (activo / pausa)
        # porque el callback RT lo actualiza en cada llamada independientemente
        # del estado paused. Fallback: leer los últimos bloques de engine.buffer.
        if recording:
            _sil_rms_lin = 0.0
            try:
                # _monitor_block: buffer lateral escrito por el callback RT
                # en CADA llamada, incluso durante auto-pausa. Es la fuente
                # más fresca y no requiere lock (escritura atómica de un bloque).
                _mon_n = self._engine._monitor_block_frames
                if _mon_n > 0:
                    _mon = self._engine._monitor_block[:_mon_n]
                    # OPT-RMS-FLOAT32: usar float32 directamente — la precisión es
                    # suficiente para detección de silencio en el rango -61 dBFS.
                    # Elimina la conversión astype(np.float64) que allocaba un array duplicado.
                    _mon_f = _mon.ravel()
                    _sil_rms_lin = float(_math.sqrt(float((_mon_f @ _mon_f) / max(len(_mon_f), 1))))
                    # ── ITL: transferir métricas al motor inteligente de cinta ───
                    # No bloqueante: escritura atómica de float (GIL-safe).
                    # Nunca lanza excepciones al pipeline RT.
                    if self._itl_bridge is not None:
                        try:
                            _itl_peak = float(np.max(np.abs(_mon)))
                            # Orden Golden UI/ITL (ITL-01/03): tiempo de cinta =
                            # audio ACEPTADO por el motor (frames); sensor con
                            # marca temporal en el MISMO reloj que el callback.
                            _st = self._engine.get_status()
                            self._itl_bridge._gui_tick(
                                rms_lin   = _sil_rms_lin,
                                peak_lin  = _itl_peak,
                                recording = recording,
                                paused    = paused,
                                audio_seconds = self._engine.audio_seconds_accepted(),
                                now = _monotonic_raw_ns() / 1e9,
                                sample_time = _st.last_callback_ns / 1e9,
                            )
                        except Exception:
                            pass
                elif not self._silence_autopause_active and len(buf) >= 1:
                    # Fallback: engine.buffer (últimos bloques del drain loop)
                    with lock:
                        _raw = list(buf)[-4:]
                    if _raw:
                        _cat = np.concatenate(_raw, axis=0)
                        _cat_f = _cat.ravel().astype(np.float32)
                        _sil_rms_lin = float(_math.sqrt(float((_cat_f @ _cat_f) / max(len(_cat_f), 1))))
                        # ── ITL fallback ───────────────────────────────────────────
                        if self._itl_bridge is not None:
                            try:
                                self._itl_bridge._gui_tick(
                                    rms_lin   = _sil_rms_lin,
                                    peak_lin  = _sil_rms_lin,   # aproximación
                                    recording = recording,
                                    paused    = paused,
                                )
                            except Exception:
                                pass
            except Exception:
                pass
            self._check_silence_autopause(_sil_rms_lin)

        # Cronómetro grabación — motor independiente del motor de duración de cinta
        # FIX v0.22.24: snapshot monotonic propio del _tick (15 Hz) para el contometro.
        # El contometro principal opera independiente: no hereda el snapshot de
        # _tick_cassette (24 Hz), evitando corridas de tiempo entre ambas etapas.
        # FIX v0.22.27: durante auto-pausa por silencio (paused=True),
        # mostrar _rec_elapsed congelado en lugar de calcular _now - _rec_start_t.
        # Esto elimina el salto al valor incorrecto que se observaba al activarse
        # la pausa automática en el segundo intento de grabación.
        if recording and not paused:
            # Orden Golden UI/ITL (ITL-01/TAPE-01): el contómetro muestra
            # TIEMPO DE AUDIO (frames aceptados por el motor), no tiempo de
            # pared. Si ambos divergen más de 1 s se deja constancia.
            _now_clock = time.monotonic()
            _wall = self._rec_elapsed + (_now_clock - self._rec_start_t)
            try:
                el = self._engine.audio_seconds_accepted()
                if abs(_wall - el) > 1.0 and not getattr(self, "_clock_drift_logged", False):
                    self._clock_drift_logged = True
                    _log.warning("Contómetro: tiempo de pared %.2fs vs audio %.2fs "
                                 "(se muestra el de AUDIO)", _wall, el)
            except Exception:
                el = _wall
            h,r = divmod(int(el),3600); m,s = divmod(r,60)
            self.clock.setText(f"{h:02d}:{m:02d}:{s:02d}")
            # Waveform: envolvente min/max POR CANAL calculada en el hilo de
            # drenaje (WAVE-01/02) — la GUI solo pinta datos compactos.
            self.waveform.setMode("rec")
            _env = getattr(self._engine, "envelope", None)
            if _env is not None and hasattr(self.waveform, "updateFromEnvelope"):
                self.waveform.updateFromEnvelope(_env)
            else:
                self.waveform.updateFromBuffer(buf, lock)
        elif recording and paused:
            # Pausa (manual o automática): mostrar _rec_elapsed acumulado congelado.
            # No calcular _now - _rec_start_t: _rec_start_t puede no estar
            # sincronizado en este tick si la pausa se activó en el mismo ciclo.
            el = self._rec_elapsed
            h,r = divmod(int(el),3600); m,s = divmod(r,60)
            self.clock.setText(f"{h:02d}:{m:02d}:{s:02d}")

        elif self._playing:
            pos = self._player.src_pos / max(self._cache_rate, 1)
            total = self._disk_total_secs
            h,r = divmod(int(pos),3600); m,s = divmod(r,60)
            self.clock.setText(f"{h:02d}:{m:02d}:{s:02d}")
            self.waveform.setMode("playback")
            # setPlayPos y update de waveform ya ocurren a 24Hz en _tick_cassette

        if self._playing and not self.scrub._drag:
            total = self._disk_total_secs
            if total > 0:
                pos = min(self._player.src_pos / max(self._cache_rate, 1), total)
                self.scrub.setValue(pos/total)
