from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Paleta de colores y estilo visual general de la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import numpy as np
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF



# ─────────────────────────────────────────────────────────────────────────────
#  EXTRACCIÓN AUTOMÁTICA DE PALETA (k-means en miniatura)
# ─────────────────────────────────────────────────────────────────────────────

def _kmeans_colors(qimage, k=5, iterations=12):
    img = qimage.scaled(64, 64, Qt.IgnoreAspectRatio, Qt.FastTransformation)
    img = img.convertToFormat(QImage.Format_RGB888)
    w, h = img.width(), img.height()
    # OPT-KMEANS-NUMPY (v0.22.38): reemplaza el doble bucle Python pixel-por-pixel
    # con extracción vectorizada vía puntero de bytes. El bucle anterior era O(w×h)
    # en Python puro (~4096 iteraciones para imagen 64×64) ejecutándose en el
    # GUI thread al arrancar. La nueva implementación lee los bytes del QImage
    # en un único bloque y los convierte a array en una sola operación numpy.
    ptr = img.bits()
    # In newer PyQt5/Python versions, bits() returns a memoryview which has no
    # setsize(). We convert to bytes using the known buffer size instead.
    if hasattr(ptr, 'setsize'):
        ptr.setsize(h * w * 3)
        buf = ptr
    else:
        buf = bytes(ptr)[: h * w * 3]
    arr = np.frombuffer(buf, dtype=np.uint8).reshape(h * w, 3).astype(np.float32)
    idx = np.linspace(0, len(arr)-1, k, dtype=int)
    centers = arr[idx].copy()
    for _ in range(iterations):
        dists  = np.linalg.norm(arr[:, None] - centers[None], axis=2)
        labels = np.argmin(dists, axis=1)
        new_centers = np.array([
            arr[labels == i].mean(axis=0) if (labels == i).any() else centers[i]
            for i in range(k)
        ])
        if np.allclose(new_centers, centers, atol=1): break
        centers = new_centers
    lum   = 0.299*centers[:,0] + 0.587*centers[:,1] + 0.114*centers[:,2]
    order = np.argsort(lum)
    return centers[order].astype(int)


def build_theme_from_image(pixmap):
    if pixmap is None or pixmap.isNull():
        return None
    img  = pixmap.toImage()
    cols = _kmeans_colors(img, k=6)

    def qc(rgb, a=255):
        return QColor(int(rgb[0]), int(rgb[1]), int(rgb[2]), a)
    def hex3(rgb):
        return f"#{int(rgb[0]):02x}{int(rgb[1]):02x}{int(rgb[2]):02x}"
    def rgba_str(rgb, a):
        return f"rgba({int(rgb[0])},{int(rgb[1])},{int(rgb[2])},{a})"

    dark   = cols[0]; mid = cols[2]; accent = cols[4]; bright = cols[5]

    rec_r = min(255, int(accent[0]*0.6 + 255*0.4))
    rec_g = int(accent[1]*0.15); rec_b = int(accent[2]*0.15)
    rec_hex  = f"#{rec_r:02x}{rec_g:02x}{rec_b:02x}"
    rec_glow = f"#{rec_r:02x}{rec_g:02x}{rec_b:02x}88"
    rec_lcd  = f"#{min(26, rec_r//6):02x}{rec_g//8:02x}{rec_b//8:02x}"

    pau_r = min(255, int(accent[0]*0.7 + 255*0.3))
    pau_g = min(255, int(accent[1]*0.4 + 160*0.6)); pau_b = int(accent[2]*0.1)
    pau_hex  = f"#{pau_r:02x}{pau_g:02x}{pau_b:02x}"
    pau_glow = f"#{pau_r:02x}{pau_g:02x}{pau_b:02x}66"
    pau_lcd  = f"#{min(26, pau_r//6):02x}{min(13, pau_g//8):02x}00"

    pla_r = int(accent[0]*0.1)
    pla_g = min(255, int(accent[1]*0.5 + 180*0.5))
    pla_b = min(255, int(accent[2]*0.3 + 120*0.7))
    pla_hex  = f"#{pla_r:02x}{pla_g:02x}{pla_b:02x}"
    pla_glow = f"#{pla_r:02x}{pla_g:02x}{pla_b:02x}66"
    pla_lcd  = f"#00{min(24, pla_g//8):02x}{min(10, pla_b//12):02x}"

    dark_lcd_hex = f"#{max(4,dark[0]//12):02x}{max(6,dark[1]//10):02x}{max(4,dark[2]//12):02x}"
    ind_off_hex  = f"#{max(22,dark[0]//8):02x}{max(22,dark[1]//8):02x}{max(22,dark[2]//8):02x}"

    states = {
        "standby": dict(ind=ind_off_hex, glow=None,      timer=rgba_str(bright,55),  lcd_bg=dark_lcd_hex, label="STANDBY"),
        "rec":     dict(ind=rec_hex,     glow=rec_glow,  timer=rec_hex,              lcd_bg=rec_lcd,      label="REC"),
        "pause":   dict(ind=pau_hex,     glow=pau_glow,  timer=pau_hex,              lcd_bg=pau_lcd,      label="PAUSA"),
        "play":    dict(ind=pla_hex,     glow=pla_glow,  timer=pla_hex,              lcd_bg=pla_lcd,      label="PLAY"),
        "stop":    dict(ind=ind_off_hex, glow=None,      timer=rgba_str(bright,55),  lcd_bg=dark_lcd_hex, label="STOP"),
    }

    border_rgba  = rgba_str(bright, 218);  hover2_rgba  = rgba_str(bright, 180)
    pressed_rgba = rgba_str(bright, 200);  dis_text     = rgba_str(bright, 90)
    dis_border   = rgba_str(bright, 64);   dis_bg       = rgba_str(bright, 50)
    bg_rgba      = rgba_str(mid, 178);     text_col     = "#b0b0b0"
    sep_rgba     = rgba_str(bright, 20)

    cmb_css = (
        f"QComboBox{{background:{bg_rgba};border:1.5px solid {border_rgba};"
        f"border-radius:7px;color:#b0b0b0;font-size:10px;"
        f"font-family:'Exo 2';"
        f"font-weight:700;padding:1px 6px;letter-spacing:1px;}}"
        f"QComboBox:hover{{background:{hover2_rgba};border-color:{rgba_str(bright,200)};color:#d0d0d0;}}"
        f"QComboBox::drop-down{{border:none;width:12px;}}"
        f"QComboBox QAbstractItemView{{background:#111;color:#b0b0b0;"
        f"border:1px solid {rgba_str(bright,50)};selection-background-color:#2a2a2a;"
        f"font-family:'Exo 2';font-weight:700;}}"
        f"QComboBox:disabled{{color:#707070;background:{dis_bg};border-color:{dis_border};}}"
    )
    btn_base = (
        f"QPushButton{{background:{bg_rgba};border:1.5px solid {border_rgba};"
        f"border-radius:9px;color:#b0b0b0;font-size:10px;"
        f"font-family:'Exo 2';"
        f"font-weight:700;letter-spacing:1px;}}"
        f"QPushButton:hover:!disabled{{background:{hover2_rgba};border-color:{rgba_str(bright,200)};}}"
        f"QPushButton:pressed:!disabled{{background:{pressed_rgba};}}"
        f"QPushButton:disabled{{color:#707070;border-color:{dis_border};background:{dis_bg};}}"
    )
    rec_css = (btn_base
               .replace(border_rgba, rgba_str(np.array([rec_r,rec_g,rec_b]),184))
               .replace(text_col, rec_hex))
    pau_css = (btn_base
               .replace(border_rgba, rgba_str(np.array([pau_r,pau_g,pau_b]),184))
               .replace(text_col, pau_hex))
    pla_css = (btn_base
               .replace(border_rgba, rgba_str(np.array([pla_r,pla_g,pla_b]),184))
               .replace(text_col, pla_hex))

    lbl_css = (
        f"color:{rgba_str(bright,128)};font-size:7px;"
        f"font-family:'Helvetica Neue',Helvetica,Arial,monospace;"
        f"letter-spacing:2px;background:transparent;"
    )
    sep_css   = f"background:{sep_rgba};"
    vu_green  = hex3(np.array([pla_r, pla_g, pla_b]))
    vu_yellow = hex3(np.array([pau_r, pau_g, pau_b]))
    vu_red    = hex3(np.array([rec_r, rec_g, rec_b]))

    _glow_base = (
        "QPushButton{border-radius:9px;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;border-width:2px;border-style:solid;}"
        "QPushButton:disabled{opacity:0.4;}"
    )
    btn_active_rec  = (_glow_base
        + f"QPushButton{{background:rgba({rec_r},{rec_g},{rec_b},0.72);"
          f"border-color:rgba({rec_r},{rec_g},{rec_b},0.95);color:{rec_hex};}}")
    btn_active_pau  = (_glow_base
        + f"QPushButton{{background:rgba({pau_r},{pau_g},{pau_b},0.70);"
          f"border-color:rgba({pau_r},{pau_g},{pau_b},0.95);color:{pau_hex};}}")
    btn_active_stop = (_glow_base
        + "QPushButton{background:rgba(80,80,80,0.72);border-color:rgba(160,160,160,0.90);"
          "color:#cccccc;}")
    btn_active_play = (_glow_base
        + f"QPushButton{{background:rgba({pla_r},{pla_g},{pla_b},0.70);"
          f"border-color:rgba({pla_r},{pla_g},{pla_b},0.95);color:{pla_hex};}}")
    btn_active_exp  = btn_active_stop
    # Vintage translucent idle style — opacidad 70%, texto gris negrita
    vint_r = min(255, int(bright[0]*0.72 + accent[0]*0.28))
    vint_g = min(255, int(bright[1]*0.60 + accent[1]*0.20))
    vint_b = min(255, int(bright[2]*0.45 + accent[2]*0.15))
    btn_idle = (
        "QPushButton{"
        f"background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
        f"stop:0 rgba({vint_r},{vint_g},{vint_b},0.70),"
        f"stop:1 rgba({vint_r//2},{vint_g//2},{vint_b//2},0.75));"
        f"border:1.5px solid rgba({vint_r},{vint_g},{vint_b},0.85);"
        "border-radius:9px;"
        "color:#b0b0b0;"
        "font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;}"
        "QPushButton:hover:!disabled{"
        f"background:{hover2_rgba};"
        f"border-color:{rgba_str(bright,200)};color:#d0d0d0;}}"
        "QPushButton:pressed:!disabled{"
        f"background:rgba({vint_r//2},{vint_g//2},{vint_b//2},0.88);}}"
        "QPushButton:disabled{"
        "color:#707070;"
        f"border-color:rgba({vint_r},{vint_g},{vint_b},0.30);"
        f"background:rgba({vint_r//3},{vint_g//3},{vint_b//3},0.20);}}"
    )

    return {
        "states": states, "cmb_css": cmb_css, "btn_base": btn_base,
        "rec_css": rec_css, "pau_css": pau_css, "pla_css": pla_css,
        "lbl_css": lbl_css, "sep_css": sep_css, "text_col": text_col,
        "bright": bright, "accent": accent, "mid": mid, "dark": dark,
        "vu_green": vu_green, "vu_yellow": vu_yellow, "vu_red": vu_red,
        "border_rgba": border_rgba, "bg_rgba": bg_rgba,
        "btn_active_rec": btn_active_rec, "btn_active_pau": btn_active_pau,
        "btn_active_stop": btn_active_stop, "btn_active_play": btn_active_play,
        "btn_active_exp": btn_active_exp, "btn_idle": btn_idle,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  TEMA POR DEFECTO
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_STATES = {
    "standby": dict(ind="#1c1c1c", glow=None,       timer="rgba(255,255,255,0.22)", lcd_bg="#080c06", label="STANDBY"),
    "rec":     dict(ind="#ff2200", glow="#ff330088", timer="#ff4422",               lcd_bg="#1a0300", label="REC"),
    "pause":   dict(ind="#ff9900", glow="#ff880066", timer="#ffaa00",               lcd_bg="#1a0d00", label="PAUSA"),
    "play":    dict(ind="#00e87a", glow="#00e87a66", timer="#00dd77",               lcd_bg="#00180a", label="PLAY"),
    "stop":    dict(ind="#1c1c1c", glow=None,        timer="rgba(255,255,255,0.22)", lcd_bg="#080c06", label="STOP"),
}
DEFAULT_THEME = {
    "states":  DEFAULT_STATES,
    "cmb_css": (
        "QComboBox{background:rgba(255,255,255,0.70);border:1.5px solid rgba(255,255,255,0.85);"
        "border-radius:7px;color:#b0b0b0;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;padding:1px 6px;letter-spacing:1px;}"
        "QComboBox:hover{background:rgba(255,255,255,0.80);border-color:rgba(255,255,255,0.95);color:#d0d0d0;}"
        "QComboBox::drop-down{border:none;width:12px;}"
        "QComboBox QAbstractItemView{background:#111;color:#b0b0b0;"
        "border:1px solid rgba(255,255,255,0.2);"
        "selection-background-color:#2a2a2a;font-family:'Exo 2';"
        "font-weight:700;}"
        "QComboBox:disabled{color:#707070;background:rgba(255,255,255,0.12);"
        "border-color:rgba(255,255,255,0.25);}"
    ),
    "btn_base": (
        "QPushButton{background:rgba(255,255,255,0.70);border:1.5px solid rgba(255,255,255,0.85);"
        "border-radius:9px;color:#b0b0b0;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;}"
        "QPushButton:hover:!disabled{background:rgba(255,255,255,0.80);border-color:rgba(255,255,255,0.95);}"
        "QPushButton:pressed:!disabled{background:rgba(255,255,255,0.88);}"
        "QPushButton:disabled{color:#707070;border-color:rgba(255,255,255,0.25);"
        "background:rgba(255,255,255,0.12);}"
    ),
    "rec_css": None, "pau_css": None, "pla_css": None,
    "lbl_css": (
        "color:rgba(255,255,255,0.50);font-size:7px;"
        "font-family:'Helvetica Neue',Helvetica,Arial,monospace;"
        "letter-spacing:2px;background:transparent;"
    ),
    "sep_css":     "background:rgba(255,255,255,0.07);",
    "text_col":    "#b0b0b0",
    "bright":      np.array([255, 255, 255]),
    "accent":      np.array([0, 230, 120]),
    "mid":         np.array([80, 80, 80]),
    "dark":        np.array([10, 10, 10]),
    "vu_green":    "#00cc44",
    "vu_yellow":   "#aadd00",
    "vu_red":      "#ff1100",
    "border_rgba": "rgba(255,255,255,0.85)",
    "bg_rgba":     "rgba(255,255,255,0.70)",
}

def _patch_default_theme(t):
    if t["rec_css"] is None:
        b = t["btn_base"]
        t["rec_css"] = (b.replace("rgba(255,255,255,0.85)","rgba(255,70,30,0.90)")
                         .replace("color:#b0b0b0;","color:#ff6644;"))
        t["pau_css"] = (b.replace("rgba(255,255,255,0.85)","rgba(255,160,0,0.90)")
                         .replace("color:#b0b0b0;","color:#ffbb44;"))
        t["pla_css"] = (b.replace("rgba(255,255,255,0.85)","rgba(0,220,110,0.90)")
                         .replace("color:#b0b0b0;","color:#44ffaa;"))

    # ── CSS de estado activo (iluminado) para cada botón ─────────────────────
    _glow_base = (
        "QPushButton{border-radius:9px;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;border-width:2px;border-style:solid;}"
        "QPushButton:disabled{opacity:0.4;}"
    )
    t["btn_active_rec"]  = (_glow_base
        + "QPushButton{background:rgba(200,20,20,0.75);border-color:rgba(255,60,40,0.95);"
        "color:#ff4433;}")
    t["btn_active_pau"]  = (_glow_base
        + "QPushButton{background:rgba(180,90,0,0.72);border-color:rgba(255,165,0,0.95);"
        "color:#ffb830;}")
    t["btn_active_stop"] = (_glow_base
        + "QPushButton{background:rgba(80,80,80,0.72);border-color:rgba(160,160,160,0.90);"
        "color:#cccccc;}")
    t["btn_active_play"] = (_glow_base
        + "QPushButton{background:rgba(0,140,60,0.72);border-color:rgba(0,230,110,0.95);"
        "color:#44ff99;}")
    t["btn_active_exp"]  = t["btn_active_stop"]
    # CSS base estético vintage translúcido para reposo — opacidad 70%, texto gris negrita
    t["btn_idle"] = (
        "QPushButton{"
        "background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
        "stop:0 rgba(180,155,120,0.70),stop:1 rgba(100,80,60,0.75));"
        "border:1.5px solid rgba(210,185,150,0.85);"
        "border-radius:9px;"
        "color:#b0b0b0;"
        "font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;}"
        "QPushButton:hover:!disabled{"
        "background:rgba(255,255,255,0.80);"
        "border-color:rgba(255,255,255,0.95);color:#d0d0d0;}"
        "QPushButton:pressed:!disabled{"
        "background:rgba(150,120,90,0.88);}"
        "QPushButton:disabled{"
        "color:#707070;"
        "border-color:rgba(200,175,140,0.30);"
        "background:rgba(120,100,75,0.20);}"
    )
    return t

_patch_default_theme(DEFAULT_THEME)
THEME = DEFAULT_THEME


# ─────────────────────────────────────────────────────────────────────────────
#  VFD DORADO LUMÍNICO — rediseño del panel de contómetro de Lorito Aldhiro
#  (pedido explícito del usuario, mismo acabado que el VFD display de CRAC:
#  scanlines + efecto fosfórico, bordes redondeados, vidrio ahumado negro,
#  leyendas y contómetro en dorado lumínico). A diferencia de CRAC, Lorito
#  Aldhiro NO lleva imagen de fondo dinámica — lienzo crema vintage con
#  aspecto marrón vintage tipo nogal (§VFD_GOLD_PALETTE / §WOOD_CANVAS más abajo).
# ─────────────────────────────────────────────────────────────────────────────

# Dorado lumínico — un único tono base para dígitos, leyendas y la línea
# ondulante de la megacelda de señal, con variantes de alpha para el halo
# fosfórico y el estado "apagado" (fósforo residual, entre parpadeos).
VFD_GOLD          = "#ffcc55"
VFD_GOLD_BRIGHT   = "#ffe29a"
VFD_GOLD_DIM      = "rgba(255,204,85,70)"
VFD_GOLD_GLOW     = "rgba(255,204,85,90)"
VFD_GLASS_BG      = "#0b0906"     # vidrio ahumado negro (fondo de la megacelda)
VFD_GLASS_BG_TOP  = "#141008"     # variante más clara para el gradiente superior
VFD_SCANLINE      = "rgba(0,0,0,90)"

# Lienzo VINTAGE MARRÓN (§FONDO DEL LIENZO) — CORRECCIÓN pedida
# explícitamente por el usuario: pasa de un crema vintage claro a un
# marrón vintage oscuro tipo nogal/palisandro, con vetas realistas,
# emulando el gabinete de madera de un equipo de audio de alta gama de
# época — reemplaza la imagen de fondo dinámica de CRAC en Lorito
# Aldhiro.
WOOD_CANVAS_TOP    = "#4a3018"   # nogal claro, borde superior del gabinete
WOOD_CANVAS_MID    = "#2e1c0d"   # nogal medio, centro del panel
WOOD_CANVAS_BOTTOM = "#1c1108"   # nogal oscuro, vignette inferior
WOOD_GRAIN_LINE    = "rgba(15,8,4,95)"      # grano oscuro, profundo
WOOD_GRAIN_HILITE  = "rgba(214,158,96,40)"  # hebra clara — reflejo del barniz sobre la veta


def paint_brushed_aluminum(p, rect, radius=0):
    """
    Pinta un acabado de aluminio pulido cepillado — calco del SVG de
    referencia del usuario (identidad estética de Lorito Aldhiro: nunca
    el acabado cálido/femenino de CRAC, sino vintage con madera + este
    aluminio): gradiente metálico diagonal multi-parada + microrayado
    cepillado horizontal (líneas finas de alpha aleatorio con semilla
    fija — QPainter no tiene equivalente directo a `<feTurbulence>`,
    así que se aproxima con ruido de líneas en vez de ruido de píxel) +
    reflejo especular diagonal con blend "overlay" REAL (vía
    `QPainter.CompositionMode_Overlay`, igual que el
    `mix-blend-mode: overlay` del SVG) + viñeteado radial de
    profundidad + doble bisel interior (realce claro + sombra oscura).
    Reutilizado por `AluminumChassisPanel` y `VUMeterChassis` para que
    ambos compartan EXACTAMENTE el mismo acabado de material — pedido
    explícito del usuario ("los vumeters digitales también deberán
    contar con el mismo acabado de aluminio detallado en el código").
    """
    from PySide6.QtGui import (QLinearGradient, QRadialGradient, QColor, QBrush,
                                QPen, QPainterPath, QPainter as _QPainterCls)
    from PySide6.QtCore import Qt, QRectF
    import random as _rnd

    x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()

    clip = QPainterPath()
    if radius:
        clip.addRoundedRect(x, y, w, h, radius, radius)
    else:
        clip.addRect(x, y, w, h)
    p.save()
    p.setClipPath(clip)

    # Gradiente metálico diagonal — calco de `metal-grad` del SVG.
    g = QLinearGradient(x, y, x + w, y + h)
    g.setColorAt(0.00, QColor(0xd8, 0xdc, 0xe1))
    g.setColorAt(0.18, QColor(0x9f, 0xa6, 0xb0))
    g.setColorAt(0.35, QColor(0xee, 0xf2, 0xf5))
    g.setColorAt(0.52, QColor(0x7a, 0x81, 0x8a))
    g.setColorAt(0.70, QColor(0xd1, 0xd6, 0xdc))
    g.setColorAt(0.85, QColor(0x8c, 0x93, 0x9c))
    g.setColorAt(1.00, QColor(0xe2, 0xe6, 0xea))
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(g))
    p.drawRect(QRectF(x, y, w, h))

    # Microrayado cepillado horizontal — semilla fija para que no
    # "parpadee" entre repintados, mismo criterio que las vetas de
    # madera del lienzo.
    _rnd.seed(4477)
    yy = y
    while yy < y + h:
        a = _rnd.randint(0, 26)
        p.setPen(QPen(QColor(0, 0, 0, a), 1))
        p.drawLine(int(x), int(yy), int(x + w), int(yy))
        yy += 1

    # Reflejo especular diagonal — blend "overlay" real.
    sheen = QLinearGradient(x, y + h, x + w, y)
    sheen.setColorAt(0.00, QColor(255, 255, 255, 0))
    sheen.setColorAt(0.42, QColor(255, 255, 255, 13))
    sheen.setColorAt(0.50, QColor(255, 255, 255, 89))
    sheen.setColorAt(0.58, QColor(255, 255, 255, 13))
    sheen.setColorAt(1.00, QColor(255, 255, 255, 0))
    p.setCompositionMode(_QPainterCls.CompositionMode_Overlay)
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(sheen))
    p.drawRect(QRectF(x, y, w, h))
    p.setCompositionMode(_QPainterCls.CompositionMode_SourceOver)

    # Viñeteado radial de profundidad (bordes del chasis).
    vg = QRadialGradient(x + w / 2, y + h / 2, max(w, h) * 0.6)
    vg.setColorAt(0.70, QColor(0, 0, 0, 0))
    vg.setColorAt(1.00, QColor(0, 0, 0, 102))
    p.setBrush(QBrush(vg))
    p.drawRect(QRectF(x, y, w, h))

    p.restore()

    # Bisel interior — realce claro + sombra oscura, calco de los dos
    # `<rect>` insertados del SVG (stroke blanco 0.25 / negro 0.35).
    p.setPen(QPen(QColor(255, 255, 255, 64), 1.5))
    p.setBrush(Qt.NoBrush)
    p.drawRoundedRect(QRectF(x + 3, y + 3, w - 6, h - 6),
                       max(0, radius - 3), max(0, radius - 3))
    p.setPen(QPen(QColor(0, 0, 0, 89), 1.5))
    p.drawRoundedRect(QRectF(x + 4.5, y + 4.5, w - 9, h - 9),
                       max(0, radius - 4), max(0, radius - 4))


def paint_alu_screw(p, cx, cy, r=12):
    """
    Tornillo Allen de aluminio — calco del módulo `<g id="screw">` del
    SVG de referencia: cuerpo con gradiente diagonal metal claro→gris→
    casi negro, anillo interior de realce blanco muy tenue, cabeza
    Allen hexagonal oscura. Reutilizado por `AluminumChassisPanel`
    (4 esquinas, pedido explícito: "en los extremos del inicio del
    revestimiento").
    """
    from PySide6.QtGui import QLinearGradient, QColor, QBrush, QPen, QPolygonF
    from PySide6.QtCore import Qt, QPointF
    import math as _m

    g = QLinearGradient(cx - r, cy - r, cx + r, cy + r)
    g.setColorAt(0.00, QColor(0xe6, 0xea, 0xee))
    g.setColorAt(0.50, QColor(0x73, 0x79, 0x82))
    g.setColorAt(1.00, QColor(0x3a, 0x3d, 0x42))
    p.setPen(QPen(QColor(0x2c, 0x2f, 0x33), 0.8))
    p.setBrush(QBrush(g))
    p.drawEllipse(QPointF(cx, cy), r, r)

    p.setPen(QPen(QColor(255, 255, 255, 77), 0.5))
    p.setBrush(Qt.NoBrush)
    p.drawEllipse(QPointF(cx, cy), r * 0.79, r * 0.79)

    hexr = r * 0.375
    pts = []
    for i in range(6):
        a = _m.radians(60 * i - 90)
        pts.append(QPointF(cx + hexr * _m.cos(a), cy + hexr * _m.sin(a)))
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(0x1e, 0x20, 0x23))
    p.drawPolygon(QPolygonF(pts))


def paint_vfd_sheen(p, rect, radius=12):
    """
    Cobertor vítreo transparente — banda de reflejo diagonal sutil,
    simulando el vidrio real por delante del fósforo. CORRECCIÓN
    explícita del usuario: las tres megaceldas del panel fusionado
    (contómetro, Media Anim, onda bamboleante) deben quedar cubiertas
    por el MISMO cobertor vítreo, para que el conjunto se lea como una
    sola pantalla — no como tres piezas de vidrio pegadas. Por eso esta
    función vive separada de `paint_vfd_glass()`: se pinta UNA SOLA VEZ
    sobre el rectángulo exterior que agrupa las tres megaceldas (ver
    `_GlassSheenOverlay`, pintado por encima de las tres una vez que ya
    dibujaron su propio fondo/scanlines/halo). Estático (no respira):
    es un reflejo de superficie, no una emisión de fósforo.
    """
    from PySide6.QtGui import QLinearGradient, QColor, QBrush, QPainterPath
    from PySide6.QtCore import Qt

    x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()
    clip = QPainterPath()
    clip.addRoundedRect(x, y, w, h, radius, radius)

    sheen = QLinearGradient(x, y, x + w * 0.55, y + h)
    sheen.setColorAt(0.00, QColor(255, 255, 255, 26))
    sheen.setColorAt(0.30, QColor(255, 255, 255, 8))
    sheen.setColorAt(0.50, QColor(255, 255, 255, 0))
    sheen.setColorAt(1.00, QColor(255, 255, 255, 0))
    p.save()
    p.setClipPath(clip)
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(sheen))
    p.drawRect(x, y, w, h)
    p.restore()


def paint_vfd_glass(p, rect, radius=8, breath_phase=0.0, sheen=True):
    """
    Pinta el acabado "vidrio ahumado negro" del VFD de Lorito Aldhiro
    sobre `rect` (QRect): fondo ahumado con gradiente sutil, scanlines
    horizontales tenues con EFECTO DE RESPIRO fosfórico y un halo
    fosfórico superior — mismo acabado en todas las celdas VFD del
    panel fusionado (contómetro + Media Anim + megacelda de la onda
    bamboleante). Centralizado aquí para que el aspecto se mantenga
    idéntico entre las tres sin duplicar código.

    `breath_phase` (radianes, avanzado por un QTimer del panel dueño)
    modula la intensidad de las scanlines y del halo con una senoide
    lenta (pedido explícito del usuario: "scanlines fosfóricos con
    efecto de respiro") — en 0.0 (valor por defecto, llamadas que no
    animan) se comporta igual que antes del rediseño.

    `sheen` — CORRECCIÓN del usuario tras el primer rediseño: el
    cobertor vítreo transparente (reflejo diagonal) NO debe pintarse
    una vez POR CELDA (eso se veía como tres piezas de vidrio
    independientes en vez de una sola pantalla) — se dejó separado en
    `paint_vfd_sheen()`, pintado UNA SOLA VEZ sobre las tres megaceldas
    juntas por `_GlassSheenOverlay` (ver `CounterMegapanel`). Este
    parámetro por defecto sigue en True solo para que llamadas
    independientes de `paint_vfd_glass()` fuera del panel fusionado
    (si las hubiera) conserven el aspecto completo; las tres celdas del
    panel fusionado lo llaman con `sheen=False`.
    """
    import math as _m
    from PySide6.QtGui import QLinearGradient, QColor, QBrush, QPen
    from PySide6.QtCore import Qt

    x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()

    # Factor de "respiro" — oscila suavemente entre 0.6 y 1.0
    _breath = 0.8 + 0.2 * _m.sin(breath_phase)

    # Vidrio ahumado — gradiente vertical sutil (más claro arriba, "vitreo")
    g = QLinearGradient(0, y, 0, y + h)
    g.setColorAt(0.0, QColor(VFD_GLASS_BG_TOP))
    g.setColorAt(1.0, QColor(VFD_GLASS_BG))
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(g))
    p.drawRoundedRect(x, y, w, h, radius, radius)

    # Scanlines — líneas horizontales cada 3px, con alpha modulada por
    # el respiro fosfórico (efecto CRT/VFD "vivo", no estático)
    p.save()
    from PySide6.QtGui import QPainterPath
    clip = QPainterPath()
    clip.addRoundedRect(x, y, w, h, radius, radius)
    p.setClipPath(clip)
    _scan_col = QColor(VFD_SCANLINE)
    _scan_col.setAlpha(max(0, min(255, int(_scan_col.alpha() * _breath))))
    p.setPen(QPen(_scan_col, 1))
    yy = y
    while yy < y + h:
        p.drawLine(x, yy, x + w, yy)
        yy += 3
    p.restore()

    # Halo fosfórico superior (glow ambiental del tubo VFD) — también
    # respira junto con las scanlines
    g2 = QLinearGradient(0, y, 0, y + h * 0.45)
    g2.setColorAt(0.0, QColor(255, 220, 140, max(0, int(20 * _breath))))
    g2.setColorAt(1.0, QColor(255, 220, 140, 0))
    p.setBrush(QBrush(g2))
    p.drawRoundedRect(x, y, w, int(h * 0.45), radius, radius)

    if sheen:
        paint_vfd_sheen(p, rect, radius=radius)

    # Borde redondeado sutil (interior, del propio vidrio — el marco
    # BLANCO decorativo exterior lo pinta el panel fusionado que aloja
    # esta celda, ver `CounterMegapanel`)
    p.setPen(QPen(QColor(255, 214, 140, 40), 1))
    p.setBrush(Qt.NoBrush)
    p.drawRoundedRect(x, y, w - 1, h - 1, radius, radius)


def paint_wood_canvas(p, rect):
    """
    Pinta el fondo de lienzo VINTAGE MARRÓN de Lorito Aldhiro (§FONDO
    DEL LIENZO) — CORRECCIÓN explícita del usuario: el lienzo pasa de
    un crema vintage claro a un marrón vintage oscuro tipo nogal/
    palisandro, con vetas realistas (grano oscuro + hebras claras del
    barniz intercaladas + un puñado de nudos de madera) y un leve
    barniz lacado diagonal, para que se lea como el gabinete de madera
    de un equipo de audio de alta gama de época (receivers/tocadiscos
    con paneles de nogal), no como una lámina de color plano.
    Reemplazo estático de la imagen de fondo dinámica que usa CRAC.
    """
    from PySide6.QtGui import QLinearGradient, QRadialGradient, QColor, QBrush, QPen, QPointF
    from PySide6.QtCore import Qt
    import random as _rnd
    import math as _m

    x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()

    # Base — gradiente vertical nogal (más claro arriba, más oscuro
    # abajo — vignette de gabinete lacado, no un tono plano).
    g = QLinearGradient(0, y, 0, y + h)
    g.setColorAt(0.00, QColor(WOOD_CANVAS_TOP))
    g.setColorAt(0.50, QColor(WOOD_CANVAS_MID))
    g.setColorAt(1.00, QColor(WOOD_CANVAS_BOTTOM))
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(g))
    p.drawRect(x, y, w, h)

    # Vetas de madera — semilla fija para que el patrón no "parpadee"
    # entre repintados. Dos tipos de hebra intercalados: OSCURA (grano
    # profundo, la mayoría) y CLARA (reflejo del barniz sobre la veta,
    # más escasa) — cada una ondulada con dos frecuencias superpuestas
    # (no una sola onda mecánica) para que se lea como madera real.
    _rnd.seed(1986)
    yy = y + 6
    while yy < y + h:
        amp = _rnd.uniform(2, 7)
        step = 12
        is_light = _rnd.random() < 0.32
        col = QColor(WOOD_GRAIN_HILITE) if is_light else QColor(WOOD_GRAIN_LINE)
        p.setPen(QPen(col, 1))
        prev = None
        xx = x
        phase = _rnd.uniform(0, 6.28)
        while xx < x + w:
            oy = (yy + _m.sin(xx * 0.018 + phase) * amp
                     + _m.sin(xx * 0.004 + phase * 0.5) * amp * 0.6)
            if prev is not None:
                p.drawLine(int(prev[0]), int(prev[1]), int(xx), int(oy))
            prev = (xx, oy)
            xx += step
        yy += _rnd.uniform(9, 18)

    # Nudos de madera — un puñado de manchas radiales oscuras, tamaño y
    # posición fijos (semilla propia), sutiles: refuerzan el aspecto de
    # madera real sin volverse un elemento decorativo llamativo.
    _rnd.seed(2026)
    for _ in range(3):
        kx = x + _rnd.uniform(0.1, 0.9) * w
        ky = y + _rnd.uniform(0.15, 0.85) * h
        kr = _rnd.uniform(10, 22)
        rg = QRadialGradient(kx, ky, kr)
        rg.setColorAt(0.0, QColor(10, 5, 2, 130))
        rg.setColorAt(0.6, QColor(10, 5, 2, 55))
        rg.setColorAt(1.0, QColor(10, 5, 2, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(rg))
        p.drawEllipse(QPointF(kx, ky), kr, kr * 1.4)

    # Barniz lacado — reflejo diagonal muy sutil (mismo criterio que el
    # cobertor vítreo del VFD), para dar sensación de gabinete pulido
    # en vez de madera mate.
    sheen = QLinearGradient(x, y, x + w * 0.6, y + h)
    sheen.setColorAt(0.00, QColor(255, 220, 180, 16))
    sheen.setColorAt(0.35, QColor(255, 220, 180, 5))
    sheen.setColorAt(0.55, QColor(255, 220, 180, 0))
    sheen.setColorAt(1.00, QColor(255, 220, 180, 0))
    p.setPen(Qt.NoPen)
    p.setBrush(QBrush(sheen))
    p.drawRect(x, y, w, h)


class WoodCanvasBackground(QWidget):
    """
    Fondo estático del lienzo de Lorito Aldhiro (§FONDO DEL LIENZO,
    pedido explícito del usuario): a diferencia de CRAC, Lorito Aldhiro
    NO lleva imagen de fondo dinámica (ChatGPT Image ...png por
    k-means) — reemplazo íntegro por un lienzo pintado, marrón vintage
    tipo nogal con vetas realistas, vía `paint_wood_canvas()`.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        paint_wood_canvas(p, self.rect())
        p.end()


def apply_gold_vfd_accent(theme: dict) -> None:
    """
    Muta `theme` in-place (mismo patrón ya usado por
    `lorito_main_window.py` para `build_theme_from_image`) para que el
    acento/brillo general de la interfaz de Lorito Aldhiro sea dorado
    lumínico en vez del verde/blanco por defecto — pedido explícito del
    usuario de que el contómetro Y sus leyendas usen ese tono; se
    extiende aquí al resto de la interfaz (barra de menú, títulos,
    scrubs) para que el acabado sea consistente en todo el lienzo.
    """
    gold_bright = np.array([255, 226, 154])
    gold_accent = np.array([224, 168, 64])
    theme["bright"] = gold_bright
    theme["accent"] = gold_accent
