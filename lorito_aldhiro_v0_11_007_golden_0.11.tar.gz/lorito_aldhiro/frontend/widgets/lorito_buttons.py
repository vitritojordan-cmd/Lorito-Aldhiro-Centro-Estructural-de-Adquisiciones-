from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Botones estilizados reutilizables de la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, QRectF, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF



# ═════════════════════════════════════════════════════════════════════════════
#  DoubleClickButton  —  QPushButton con callback de doble clic
# ═════════════════════════════════════════════════════════════════════════════

class DoubleClickButton(QPushButton):
    """
    QPushButton que distingue clic simple de doble clic.

    FIX-STOP-DOUBLE-CLICK (v0.22.55):
      El botón ■ STOP utiliza esta subclase para implementar el doble clic
      especificado en C.R.A.C:
        · Un clic  → stop_all()  (detiene; scrub queda en posición actual)
        · Doble clic → _scrub_reset_to_start()  (stop + scrub retorna a 0)

    La detección se basa en mouseDoubleClickEvent de Qt, que se emite
    cuando el segundo clic ocurre dentro del tiempo de doble clic del SO.
    El clicked() estándar no se emite en el segundo clic cuando Qt lo
    reconoce como doble clic — por tanto NO hay doble disparo de stop_all().

    onDoubleClick: Callable opcional invocado en mouseDoubleClickEvent.
    """

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.onDoubleClick: Optional[Callable] = None

    def mouseDoubleClickEvent(self, event):
        # Ignorar si el botón está deshabilitado
        if not self.isEnabled():
            return
        if self.onDoubleClick:
            self.onDoubleClick()


# ═════════════════════════════════════════════════════════════════════════════
#  LoritoTransportButton — botones de control principal, SEGUNDO rediseño
#  (pedido explícito del usuario, nuevo SVG de referencia adjunto: chasis
#  de metal cepillado oscuro + bisel metálico multicapa + LED retroiluminado
#  con resplandor). CORRECCIÓN sobre el rediseño anterior: ya NO llevan
#  ninguna leyenda de texto (ni "REC" ni nada debajo del símbolo) y el
#  bisel completo ahora se pinta 100% desde código (antes venía de QSS
#  externo vía `setStyleSheet`, que queda como no-op inofensivo para no
#  romper los call-sites existentes de `lorito_mw_ui_build.py`, que siguen
#  llamando `setStyleSheet(...)` además de `setIconLit(...)` — solo esta
#  última sigue teniendo efecto visual real). Formato: rectángulo
#  horizontal, mismo tamaño/forma que los botones que reemplaza (nunca el
#  rectángulo vertical del SVG de referencia, que es solo la fuente de
#  estilo de material/iluminación, no de proporción). El botón EJECT del
#  SVG es, en Lorito Aldhiro, el equivalente exacto del botón EXPORTAR
#  (`ICON_EXPORT`, ya existente).
# ═════════════════════════════════════════════════════════════════════════════

class LoritoTransportButton(DoubleClickButton):
    ICON_REC    = "rec"
    ICON_PLAY   = "play"
    ICON_PAUSE  = "pause"
    ICON_STOP   = "stop"
    ICON_EXPORT = "export"

    # Color BASE del símbolo (silueta apagada) — calco de la paleta del
    # SVG de referencia: rec=rojo, play=verde, pausa/stop=gris mate
    # (apagados en el SVG), export/eject=ámbar (única variante "LIT DEMO"
    # del SVG, adoptada aquí como el color de encendido natural de
    # EXPORTAR/EJECT).
    _ICON_COLOR = {
        ICON_REC:    QColor(255, 42, 42),
        ICON_PLAY:   QColor(0, 255, 102),
        ICON_PAUSE:  QColor(180, 184, 190),
        ICON_STOP:   QColor(180, 184, 190),
        ICON_EXPORT: QColor(255, 170, 0),
    }
    # Color del resplandor del BORDE del bisel cuando el botón está
    # activo/pulsado (`.lit-border-*` del SVG) — no siempre coincide con
    # el color del símbolo (p. ej. pausa/stop encienden en ámbar, igual
    # que el borde "activo" genérico del SVG, aunque su símbolo en reposo
    # sea gris).
    _GLOW_COLOR = {
        ICON_REC:    QColor(255, 42, 42),
        ICON_PLAY:   QColor(0, 255, 102),
        ICON_PAUSE:  QColor(255, 170, 0),
        ICON_STOP:   QColor(255, 170, 0),
        ICON_EXPORT: QColor(255, 170, 0),
    }

    def __init__(self, icon: str, text: str, parent=None):
        # FIX-BOTONES-SIN-LEYENDA: el texto ya NO se pinta — se conserva
        # como tooltip (aparece solo al pasar el ratón, no es una leyenda
        # fija en pantalla) para no perder la pista de qué hace cada
        # botón, y la firma del constructor no cambia (todos los
        # call-sites existentes en `lorito_mw_ui_build.py` siguen
        # pasando `text` sin tocar nada).
        super().__init__("", parent)
        if text:
            self.setToolTip(text)
        self._icon = icon
        self._icon_lit = False      # encendido "sostenido" (estado activo real)
        self._icon_pressed = False  # encendido momentáneo (mientras se pulsa)

    def setIconLit(self, lit: bool) -> None:
        self._icon_lit = lit
        self.update()

    def mousePressEvent(self, event):
        self._icon_pressed = True
        self.update()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self._icon_pressed = False
        self.update()
        super().mouseReleaseEvent(event)

    def _draw_symbol(self, p: QPainter, cx: float, cy: float, s: float, lit_color: QColor):
        """Dibuja el símbolo (mismo trazado del SVG de referencia,
        reescalado a `s` px) centrado en (cx, cy) — ahora SIEMPRE
        centrado en el botón entero (antes pegado al borde izquierdo,
        para dejar sitio al texto que ya no existe)."""
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(lit_color))
        if self._icon == self.ICON_REC:
            p.drawEllipse(QPointF(cx, cy), s * 0.42, s * 0.42)
        elif self._icon == self.ICON_PLAY:
            tri = QPolygonF([QPointF(cx - s*0.32, cy - s*0.42),
                             QPointF(cx - s*0.32, cy + s*0.42),
                             QPointF(cx + s*0.40, cy)])
            p.drawPolygon(tri)
        elif self._icon == self.ICON_PAUSE:
            bw = s * 0.20; gap = s * 0.14; bh = s * 0.78
            p.drawRoundedRect(QRect(int(cx - gap - bw), int(cy - bh/2), int(bw), int(bh)), 1.5, 1.5)
            p.drawRoundedRect(QRect(int(cx + gap), int(cy - bh/2), int(bw), int(bh)), 1.5, 1.5)
        elif self._icon == self.ICON_STOP:
            sq = s * 0.70
            p.drawRoundedRect(QRect(int(cx - sq/2), int(cy - sq/2), int(sq), int(sq)), 2, 2)
        elif self._icon == self.ICON_EXPORT:
            tri = QPolygonF([QPointF(cx, cy - s*0.42),
                             QPointF(cx - s*0.34, cy + s*0.06),
                             QPointF(cx + s*0.34, cy + s*0.06)])
            p.drawPolygon(tri)
            p.drawRoundedRect(QRect(int(cx - s*0.34), int(cy + s*0.20), int(s*0.68), int(s*0.13)), 1, 1)

    def paintEvent(self, event):
        # El bisel YA NO viene de QSS — se pinta aquí por completo un
        # chasis de metal cepillado oscuro (calco de `chassis-grad`/
        # `btn-metal` del SVG de referencia), con un borde LED que se
        # enciende con resplandor cuando el botón está activo/pulsado
        # (`.lit-border-*` + `<feGaussianBlur>`, emulado con trazos
        # concéntricos de alpha decreciente — QPainter no tiene filtros
        # de desenfoque nativos). NUNCA se llama a `super().paintEvent()`.
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        radius = 6.0
        rect = QRectF(1, 1, w - 2, h - 2)
        pressed = self._icon_pressed

        # Cuerpo metálico — gradiente vertical (calco de `btn-metal` del
        # SVG, colapsado a solo 2 estados: reposo/pulsado, en vez de las
        # 6 paradas de color exactas del SVG, que están pensadas para un
        # botón alto — a esta altura (~36px) una versión más simple se
        # lee mejor sin bandas de color demasiado finas).
        grad = QLinearGradient(0, 0, 0, h)
        if pressed:
            grad.setColorAt(0.00, QColor(0x28, 0x2a, 0x2d))
            grad.setColorAt(0.15, QColor(0x45, 0x48, 0x4f))
            grad.setColorAt(0.85, QColor(0x68, 0x6d, 0x75))
            grad.setColorAt(1.00, QColor(0x1f, 0x20, 0x22))
        else:
            grad.setColorAt(0.00, QColor(0x4a, 0x4d, 0x52))
            grad.setColorAt(0.12, QColor(0x2b, 0x2d, 0x30))
            grad.setColorAt(0.50, QColor(0x1f, 0x20, 0x22))
            grad.setColorAt(0.88, QColor(0x14, 0x15, 0x17))
            grad.setColorAt(1.00, QColor(0x09, 0x0a, 0x0a))
        p.setPen(QPen(QColor(0x1a, 0x1b, 0x1d), 1.2))
        p.setBrush(QBrush(grad))
        p.drawRoundedRect(rect, radius, radius)

        # Sheen superior sutil (borde interior claro, calco del
        # `stroke="#ffffff" opacity="0.4"` del SVG).
        p.setPen(QPen(QColor(255, 255, 255, 40), 1))
        p.drawLine(QPointF(rect.x() + 5, rect.y() + 2),
                   QPointF(rect.x() + rect.width() - 5, rect.y() + 2))

        lit = self._icon_lit or self._icon_pressed
        base_col = self._ICON_COLOR.get(self._icon, QColor(200, 200, 200))
        glow_col = self._GLOW_COLOR.get(self._icon, base_col)

        cx, cy = w / 2.0, h / 2.0
        s = min(w, h) * 0.62

        if lit:
            # Borde LED con resplandor — 3 trazos concéntricos de alpha
            # decreciente (emula el `<feGaussianBlur>` del SVG).
            for _lw, _a in ((6.0, 16), (3.5, 38), (1.8, 95)):
                gcol = QColor(glow_col); gcol.setAlpha(_a)
                p.setPen(QPen(gcol, _lw))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), radius - 0.5, radius - 0.5)

            # Resplandor radial DETRÁS del símbolo (mismo criterio que el
            # rediseño anterior: la retroiluminación nace del símbolo,
            # nunca de todo el bisel).
            glow = QRadialGradient(cx, cy, s * 1.35)
            gl_col = QColor(glow_col); gl_col.setAlpha(150)
            glow.setColorAt(0.0, gl_col)
            glow.setColorAt(1.0, QColor(glow_col.red(), glow_col.green(), glow_col.blue(), 0))
            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(glow))
            p.drawEllipse(QPointF(cx, cy), s * 1.35, s * 1.35)
            lit_color = base_col.lighter(150)
        else:
            lit_color = QColor(base_col.red(), base_col.green(), base_col.blue(), 90)

        self._draw_symbol(p, cx, cy, s, lit_color)
        p.end()
