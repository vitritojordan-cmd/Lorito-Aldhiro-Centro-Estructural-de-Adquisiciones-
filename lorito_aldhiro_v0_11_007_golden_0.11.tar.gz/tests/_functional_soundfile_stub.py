"""
tests/_functional_soundfile_stub.py — stub funcional de `soundfile`
(lectura Y escritura), respaldado por el módulo `wave` de la librería
estándar. A diferencia del stub dummy de
`tests/test_stability_patch.py::_install_stub_modules` (que solo
permite IMPORTAR código que depende de `soundfile`, sin comportamiento
real), este stub escribe/lee bytes PCM reales — suficiente para
ejercitar el código real de `_build_export_array`/`DiskWriterV2` con
datos de verdad en este sandbox, sin `soundfile` instalado.

Superficie cubierta (la que usa `lorito_main_window.py`/
`lorito_capture_engine.py`): `SoundFile(path, mode)` como context
manager con `.frames`/`.samplerate`/`.channels`, `.read(n, dtype=
"float32", always_2d=True)`, `.write(block)`, `.flush()`, `.close()`,
y la función de módulo `read(path, dtype=..., always_2d=True)`.

GAP-062: lectura tolerante a WAVE_FORMAT_EXTENSIBLE. Los WAV que
produce `ffmpeg -c:a pcm_s24le` (usados para los fixtures de audio
REAL del usuario, p. ej. `tests/fixtures/sotalomafer1_scrub_5s.wav`)
usan ese tag (0xFFFE, fmt chunk de 40 bytes) en vez del PCM=1 clásico
— comportamiento normal de ffmpeg para 24 bits, no un archivo
corrupto. El módulo `wave` de la stdlib RECHAZA ese tag con
`wave.Error: unknown format`. `FunctionalSoundFile` intenta primero
`wave.open()` (camino existente, sin cambios para los WAV sintéticos
PCM=1 que usa el resto de la suite) y solo si eso falla con
`wave.Error` cae a `_ExtensibleRawReader` (parseo RIFF manual +
lectura secuencial de bytes crudos) — mismo subformato PCM real
(GUID `0x0001`), solo header distinto.
"""

import struct
import wave

import numpy as np


def parse_wav_header(path):
    """Parser RIFF/WAVE manual y mínimo — tolera fmt tag PCM (1) o
    WAVE_FORMAT_EXTENSIBLE (0xFFFE). Devuelve
    (fmt_dict, data_offset, data_size)."""
    with open(path, "rb") as f:
        riff, _riff_size, wave_id = struct.unpack("<4sI4s", f.read(12))
        if riff != b"RIFF" or wave_id != b"WAVE":
            raise ValueError(f"{path}: no es un WAV RIFF válido")
        fmt = None
        data_offset = None
        data_size = None
        while True:
            hdr = f.read(8)
            if len(hdr) < 8:
                break
            cid, csize = struct.unpack("<4sI", hdr)
            if cid == b"fmt ":
                fmt_bytes = f.read(csize)
                tag, ch, sr, _br, _ba, bps = struct.unpack("<HHIIHH", fmt_bytes[:16])
                fmt = {"tag": tag, "channels": ch, "samplerate": sr,
                       "bits_per_sample": bps}
            elif cid == b"data":
                data_offset = f.tell()
                data_size = csize
                f.seek(csize, 1)
            else:
                f.seek(csize, 1)
            if csize % 2 == 1:
                f.seek(1, 1)
        if fmt is None or data_offset is None:
            raise ValueError(f"{path}: WAV sin chunk fmt/data")
        return fmt, data_offset, data_size


class _ExtensibleRawReader:
    """Sustituto mínimo de `wave.Wave_read` (solo `.readframes(n)` y
    `.close()`) para WAV con header WAVE_FORMAT_EXTENSIBLE que `wave`
    rechaza — PCM24 únicamente (mismo subtype que el resto del
    proyecto). Mantiene posición de lectura propia (secuencial, igual
    semántica que `Wave_read.readframes`)."""

    def __init__(self, path):
        fmt, data_offset, data_size = parse_wav_header(path)
        if fmt["bits_per_sample"] != 24:
            raise ValueError(
                f"{path}: _ExtensibleRawReader solo soporta PCM24, "
                f"encontrado {fmt['bits_per_sample']} bits")
        self._channels = fmt["channels"]
        self._samplerate = fmt["samplerate"]
        self._bytes_per_frame = 3 * self._channels
        self._data_offset = data_offset
        self._n_frames = data_size // self._bytes_per_frame
        self._f = open(path, "rb")
        self._pos = 0

    def getnchannels(self):
        return self._channels

    def getframerate(self):
        return self._samplerate

    def getnframes(self):
        return self._n_frames

    def readframes(self, n):
        n = max(0, min(n, self._n_frames - self._pos))
        self._f.seek(self._data_offset + self._pos * self._bytes_per_frame)
        raw = self._f.read(n * self._bytes_per_frame)
        self._pos += n
        return raw

    def setpos(self, pos):
        self._pos = max(0, min(int(pos), self._n_frames))

    def close(self):
        self._f.close()


def _pcm24_bytes_to_float32(raw: bytes, n_channels: int) -> np.ndarray:
    n_samples = len(raw) // 3
    u8 = np.frombuffer(raw, dtype=np.uint8).reshape(n_samples, 3)
    buf32 = np.zeros((n_samples, 4), dtype=np.uint8)
    buf32[:, 0:3] = u8
    buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
    pcm = np.frombuffer(buf32.tobytes(), dtype="<i4").astype(np.float64)
    return (pcm / 8388608.0).astype(np.float32).reshape(-1, n_channels)


def _float32_to_pcm24_bytes(block: np.ndarray) -> bytes:
    clipped = np.clip(block, -1.0, 1.0)
    pcm32 = np.clip(np.round(clipped * 8388608.0), -8388608, 8388607).astype(np.int32)
    u8 = np.frombuffer(pcm32.tobytes(), dtype=np.uint8).reshape(-1, 4)
    return np.ascontiguousarray(u8[:, 0:3]).tobytes()


class FunctionalSoundFile:
    """Sustituto funcional de `soundfile.SoundFile` — solo PCM_24,
    que es el único subtype real que usa este proyecto para segmentos
    de captura."""

    def __init__(self, path, mode="r", samplerate=48000, channels=2,
                subtype="PCM_24", format="WAV"):
        self.name = path
        self._mode = mode
        if mode == "r":
            try:
                self._wf = wave.open(path, "rb")
            except wave.Error:
                # GAP-062: WAVE_FORMAT_EXTENSIBLE (p. ej. WAV reales
                # producidos por ffmpeg -c:a pcm_s24le) — `wave` no lo
                # soporta pero SÍ es PCM real (ver docstring del módulo).
                self._wf = _ExtensibleRawReader(path)
            self.channels = self._wf.getnchannels()
            self.samplerate = self._wf.getframerate()
            self.frames = self._wf.getnframes()
        else:
            self._wf = wave.open(path, "wb")
            self._wf.setnchannels(channels)
            self._wf.setsampwidth(3)
            self._wf.setframerate(samplerate)
            self.channels = channels
            self.samplerate = samplerate
            self.frames = 0

    def read(self, n, dtype="float32", always_2d=True):
        raw = self._wf.readframes(n)
        data = _pcm24_bytes_to_float32(raw, self.channels)
        return data

    def seek(self, frame):
        """GAP-062: `PlaybackEngine._prefetch()` posiciona la cabeza de
        lectura con `f.seek(read_start)` en cada ciclo (forward,
        reversa, tras seek, tras cambio de velocidad) — necesario para
        poder ejercitarlo de punta a punta con audio real, no solo con
        lectura secuencial de principio a fin como el resto de los
        consumidores existentes de este stub."""
        self._wf.setpos(int(frame))

    def write(self, block):
        raw = _float32_to_pcm24_bytes(block)
        self._wf.writeframesraw(raw)
        self.frames += block.shape[0]

    def flush(self):
        pass

    def close(self):
        self._wf.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def read(path, dtype="float32", always_2d=True):
    with FunctionalSoundFile(path, "r") as f:
        return f.read(f.frames, dtype=dtype, always_2d=always_2d), f.samplerate


def install_functional_soundfile_stub():
    """Instala este stub funcional en `sys.modules['soundfile']` —
    debe llamarse ANTES de `_install_stub_modules()`
    (`tests/test_stability_patch.py`), que no re-stubea un módulo que
    ya está en `sys.modules`."""
    import sys
    import types
    mod = types.ModuleType("soundfile")
    mod.SoundFile = FunctionalSoundFile
    mod.read = read
    sys.modules["soundfile"] = mod
