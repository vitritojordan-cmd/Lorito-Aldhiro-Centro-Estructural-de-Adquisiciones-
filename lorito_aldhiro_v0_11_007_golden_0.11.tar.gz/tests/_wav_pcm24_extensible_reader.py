"""
tests/_wav_pcm24_extensible_reader.py — GAP-062.

Parser RIFF/WAVE manual y mínimo para fixtures de audio REAL en PCM24.

Motivo de existir: los WAV producidos por `ffmpeg -c:a pcm_s24le`
escriben el header como WAVE_FORMAT_EXTENSIBLE (fmt tag=0xFFFE, chunk
`fmt ` de 40 bytes) en vez del tag PCM=1 clásico — un comportamiento
normal de ffmpeg para profundidades de bits no estándar (24 bits), no
un archivo corrupto. El módulo `wave` de la stdlib RECHAZA ese tag con
`wave.Error: unknown format`, y por tanto también
`tests/_functional_soundfile_stub.py::FunctionalSoundFile`, que se
apoya en `wave` internamente.

El subformato dentro de la extensión (primeros 2 bytes del GUID) es
`0x0001` = PCM en el archivo real usado aquí — es PCM24 genuino, solo
con el header "extensible". `parse_wav_header()` (el parser RIFF a
mano) y el conversor PCM24→float32 viven en
`_functional_soundfile_stub.py` (GAP-062 lo extendió con el mismo
parser para que `FunctionalSoundFile` también pueda leer estos
archivos) — este módulo los reutiliza en vez de duplicarlos.
"""

from _functional_soundfile_stub import _pcm24_bytes_to_float32, parse_wav_header


def _require_pcm24(path, fmt):
    if fmt["bits_per_sample"] != 24:
        raise ValueError(
            f"{path}: esperaba PCM24, encontrado {fmt['bits_per_sample']} bits")


class RealAudioPCM24Fixture:
    """Lector de solo-lectura, con seek por frame, de un fixture WAV
    PCM24 real (potencialmente extensible) — misma superficie mínima
    (`channels`, `samplerate`, `frames`, `read_frames(n, start)`) que
    necesitan los tests de este módulo, sin pasar por `wave`."""

    def __init__(self, path):
        self.path = path
        fmt, data_offset, data_size = parse_wav_header(path)
        _require_pcm24(path, fmt)
        self.channels = fmt["channels"]
        self.samplerate = fmt["samplerate"]
        self._bytes_per_frame = 3 * self.channels
        self._data_offset = data_offset
        self.frames = data_size // self._bytes_per_frame

    def read_frames(self, n_frames, start=0):
        """Lee `n_frames` desde el frame absoluto `start`, devuelve
        float32 (n_frames, channels)."""
        byte_start = self._data_offset + start * self._bytes_per_frame
        n_bytes = n_frames * self._bytes_per_frame
        with open(self.path, "rb") as f:
            f.seek(byte_start)
            raw = f.read(n_bytes)
        return _pcm24_bytes_to_float32(raw, self.channels)
