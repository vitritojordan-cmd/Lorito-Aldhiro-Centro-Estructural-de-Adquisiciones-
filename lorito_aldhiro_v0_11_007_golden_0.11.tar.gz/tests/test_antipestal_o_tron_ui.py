"""
test_antipestal_o_tron_ui.py -- GAP-041, integración de UI de
"Antipestal de Lola Grillo (PREVI)" y "Versión O Tron (FNESP)": menú
OPTAPE, leyendas compartidas "PREVI DSP"/"FNESP DSP", paneles de
ajustes.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402


class TestAntipestalToggle(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_striker_activates_and_sets_previ_legend(self):
        self.app._on_antipestal_menu("STRIKER")
        self.assertEqual(self.app._nr_coordinator._antipestal.mode, "STRIKER")
        self.assertTrue(self.app.clock._previ_dsp_active)

    def test_selecting_same_mode_twice_toggles_off(self):
        self.app._on_antipestal_menu("KARI")
        self.app._on_antipestal_menu("KARI")
        self.assertIsNone(self.app._nr_coordinator._antipestal)
        self.assertFalse(self.app.clock._previ_dsp_active)

    def test_switching_branch_directly_without_bypass(self):
        self.app._on_antipestal_menu("STRIKER")
        self.app._on_antipestal_menu("KARI")
        self.assertEqual(self.app._nr_coordinator._antipestal.mode, "KARI")

    def test_previ_legend_stays_active_if_cristhi_cosh_still_on(self):
        self.app._on_cristhi_cosh_toggle()
        self.app._on_antipestal_menu("STRIKER")
        self.app._on_antipestal_menu("STRIKER")
        self.assertTrue(self.app.clock._previ_dsp_active,
                        "Cristhi Cosh sigue activo, la leyenda no debe apagarse")

    def test_panel_updates_params_live(self):
        self.app._on_antipestal_menu("STRIKER")
        dsp = self.app._nr_coordinator._antipestal
        dsp.set_params(raspado=0.9)
        self.assertAlmostEqual(dsp.params["raspado"], 0.9)


class TestOTronToggle(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_barril_activates_and_sets_fnesp_legend(self):
        self.app._on_o_tron_menu("BARRIL")
        self.assertEqual(self.app._nr_coordinator._version_o_tron.mode, "BARRIL")
        self.assertTrue(self.app.clock._fnesp_dsp_active)

    def test_selecting_same_mode_twice_toggles_off(self):
        self.app._on_o_tron_menu("SIFON")
        self.app._on_o_tron_menu("SIFON")
        self.assertIsNone(self.app._nr_coordinator._version_o_tron)
        self.assertFalse(self.app.clock._fnesp_dsp_active)

    def test_switching_profile_directly(self):
        self.app._on_o_tron_menu("AA_MO")
        self.app._on_o_tron_menu("BARRIL")
        self.assertEqual(self.app._nr_coordinator._version_o_tron.mode, "BARRIL")


class TestSharedLegendAggregation(unittest.TestCase):
    def test_previ_dsp_active_true_with_only_cristhi_cosh(self):
        app = mw.LoritoAldhiroStudio()
        app._on_cristhi_cosh_toggle()
        self.assertTrue(app._nr_coordinator.previ_dsp_active)

    def test_previ_dsp_active_true_with_only_antipestal(self):
        app = mw.LoritoAldhiroStudio()
        app._on_antipestal_menu("KARI")
        self.assertTrue(app._nr_coordinator.previ_dsp_active)

    def test_previ_dsp_active_false_with_neither(self):
        app = mw.LoritoAldhiroStudio()
        self.assertFalse(app._nr_coordinator.previ_dsp_active)

    def test_fnesp_dsp_active_reflects_o_tron(self):
        app = mw.LoritoAldhiroStudio()
        self.assertFalse(app._nr_coordinator.fnesp_dsp_active)
        app._on_o_tron_menu("SIFON")
        self.assertTrue(app._nr_coordinator.fnesp_dsp_active)


if __name__ == "__main__":
    unittest.main()
