"""
test_antipestal_otron_ui.py -- GAP-041, integración de UI de
"Antipestal de Lola Grillo (PREVI)" y "Versión O Tron (FNESP)": menú
OPTAPE, leyendas compartidas "PREVI DSP"/"FNESP DSP", y paneles de
deslizadores. Usa `LoritoAldhiroStudio` instanciada REAL bajo los
stubs de PySide6 (GAP-036/037).
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.test_stability_patch import _install_stub_modules
_install_stub_modules()

import lorito_aldhiro.frontend.lorito_main_window as mw  # noqa: E402


class TestAntipestalMenu(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_striker_activates_and_toggles_off(self):
        self.app._on_antipestal_menu("STRIKER")
        self.assertEqual(self.app._nr_coordinator._antipestal.mode, "STRIKER")
        self.app._on_antipestal_menu("STRIKER")
        self.assertIsNone(self.app._nr_coordinator._antipestal)

    def test_switching_branches_without_bypass(self):
        self.app._on_antipestal_menu("STRIKER")
        self.app._on_antipestal_menu("KARI")
        self.assertEqual(self.app._nr_coordinator._antipestal.mode, "KARI")

    def test_previ_legend_reflects_aggregate_with_cristhi_cosh(self):
        self.app._on_cristhi_cosh_toggle()
        self.app._on_antipestal_menu("KARI")
        self.assertTrue(self.app.clock._previ_dsp_active)

        self.app._on_cristhi_cosh_toggle()
        self.assertTrue(self.app.clock._previ_dsp_active,
                        "Antipestal sigue activo -- la leyenda debe seguir encendida")

        self.app._on_antipestal_menu("KARI")
        self.assertFalse(self.app.clock._previ_dsp_active)

    def test_panel_updates_live_params(self):
        self.app._on_antipestal_menu("STRIKER")
        dsp = self.app._nr_coordinator._antipestal
        dsp.set_params(raspado=0.9)
        self.assertAlmostEqual(dsp.params["raspado"], 0.9)


class TestVersionOTronMenu(unittest.TestCase):
    def setUp(self):
        self.app = mw.LoritoAldhiroStudio()

    def test_barril_activates_and_toggles_off(self):
        self.app._on_o_tron_menu("BARRIL")
        self.assertEqual(self.app._nr_coordinator._version_o_tron.mode, "BARRIL")
        self.app._on_o_tron_menu("BARRIL")
        self.assertIsNone(self.app._nr_coordinator._version_o_tron)

    def test_fnesp_legend_activates(self):
        self.app._on_o_tron_menu("SIFON")
        self.assertTrue(self.app.clock._fnesp_dsp_active)
        self.app._on_o_tron_menu("SIFON")
        self.assertFalse(self.app.clock._fnesp_dsp_active)

    def test_fnesp_alternates_with_real_dolby_c(self):
        self.app.clock.set_cell_lit("DOLBY_C", True)
        self.app._on_o_tron_menu("AA_MO")
        initial = self.app.clock._legend_alt_on
        self.app._blink()
        self.app._blink()
        self.assertNotEqual(self.app.clock._legend_alt_on, initial)


if __name__ == "__main__":
    unittest.main()
