"""
Códigos de razón de la clasificación archivística (ARCHIVAL_CONTRACT.md,
CAPTURE_FAILURE_MATRIX.md filas 6, 17, 18 y 20), cada uno ejercitado de
forma aislada sobre `classify_session()`.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lorito_aldhiro.backend.archival.lorito_archival_state import (  # noqa: E402
    classify_session, ArchivalState,
)
from lorito_aldhiro.backend.capture.lorito_frame_ledger import (  # noqa: E402
    FrameLedger, LedgerReconciliation,
)

_CLEAN = {"frames_dropped": 0, "xrun_count": 0, "rba_overrun_total": 0,
          "ced_dropped_frames": 0, "recovery_count": 0, "starvation_events": 0,
          "wd_phase": "OK"}


def _codes(res):
    return {getattr(r, "code", None) for r in res.reasons}


class ReasonCodes(unittest.TestCase):

    def test_clean_status_is_safe(self):
        self.assertEqual(classify_session(dict(_CLEAN)).state, ArchivalState.ARCHIVAL_SAFE)

    def test_input_underflow_invalidates(self):
        res = classify_session(dict(_CLEAN, input_underflow_count=2))
        self.assertIn("INPUT_UNDERFLOW", _codes(res))
        self.assertEqual(res.state, ArchivalState.INVALID)

    def test_stress_test_mode_invalidates(self):
        res = classify_session(dict(_CLEAN, stress_test_active=True))
        self.assertIn("STRESS_TEST_MODE", _codes(res))
        self.assertEqual(res.state, ArchivalState.INVALID)

    def test_missing_checksums_when_required(self):
        res = classify_session(dict(_CLEAN), segment_paths=["/no/existe.wav"],
                               check_files_exist=False, require_checksums=True,
                               ledger=FrameLedger())
        self.assertIn("CHECKSUM_UNAVAILABLE", _codes(res))
        self.assertNotEqual(res.state, ArchivalState.ARCHIVAL_SAFE)

    def test_ledger_unavailable_when_required(self):
        res = classify_session(dict(_CLEAN), require_checksums=True)
        self.assertIn("LEDGER_UNAVAILABLE", _codes(res))
        self.assertNotEqual(res.state, ArchivalState.ARCHIVAL_SAFE)

    def test_unreconciled_ledger_invalidates(self):
        rec = LedgerReconciliation(ok=False, deltas={"ring": 512},
                                   causes=["512 frames sin causa"], totals={})
        res = classify_session(dict(_CLEAN), ledger=FrameLedger(), reconciliation=rec)
        self.assertIn("LEDGER_NOT_RECONCILED", _codes(res))
        self.assertEqual(res.state, ArchivalState.INVALID)
        self.assertFalse(res.ledger_reconciled)


if __name__ == "__main__":
    unittest.main()
