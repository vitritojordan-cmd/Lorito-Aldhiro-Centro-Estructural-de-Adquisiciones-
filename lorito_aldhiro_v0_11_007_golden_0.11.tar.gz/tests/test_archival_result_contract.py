"""
test_archival_result_contract.py — GAP-052, FASE 2 ("Archival State")
de la Orden Maestra de Saneamiento, Integración y Consolidación de
Lorito Aldhiro.

Cubre los campos NUEVOS y aditivos de `ArchivalClassification` (§9):
`frames_expected`/`frames_written`/`frames_lost`, `segments_expected`/
`segments_valid`/`segments_invalid`, `checksum_verified`, el alias
`status`, y `ArchivalReason` (verifica que sigue comportándose como un
string normal para código existente, además de llevar `.code`).

Ejecutar:  python3 -m unittest tests.test_archival_result_contract -v
"""

import os
import tempfile
import unittest
import wave

from lorito_aldhiro.backend.archival import ArchivalState, classify_session
from lorito_aldhiro.backend.archival.lorito_archival_state import ArchivalReason
from lorito_aldhiro.backend.archival.lorito_segment_checksum import (
    compute_segment_checksum,
)


def _write_wav(path, rate, channels, sampwidth, frames_data: bytes):
    with wave.open(path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sampwidth)
        wf.setframerate(rate)
        wf.writeframesraw(frames_data)


def _status(**overrides):
    base = {
        "frames_dropped": 0, "xrun_count": 0, "recovery_count": 0,
        "rba_overrun_total": 0, "ced_dropped_frames": 0,
        "starvation_events": 0, "wd_phase": "OK",
        "frames_received": 0, "frames_written": 0,
    }
    base.update(overrides)
    return base


class TestArchivalReasonBehavesAsString(unittest.TestCase):
    def test_is_a_str_subclass(self):
        r = ArchivalReason("frames_dropped=5", code="FRAMES_DROPPED")
        self.assertIsInstance(r, str)
        self.assertEqual(r, "frames_dropped=5")

    def test_substring_containment_works_like_before(self):
        # Mismo patrón que `tests/test_archival_state.py`:
        # assertIn("texto", result.reasons[0]) — debe seguir funcionando.
        r = ArchivalReason("xrun_count=3", code="XRUN")
        self.assertIn("xrun_count=3", r)

    def test_code_attribute_present(self):
        r = ArchivalReason("algo pasó", code="SOME_CODE")
        self.assertEqual(r.code, "SOME_CODE")

    def test_default_code_is_empty_string(self):
        r = ArchivalReason("sin código")
        self.assertEqual(r.code, "")


class TestQuantitativeFieldsOnCleanSession(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="lorito_archival_contract_")

    def tearDown(self):
        for f in os.listdir(self.tmpdir):
            os.remove(os.path.join(self.tmpdir, f))
        os.rmdir(self.tmpdir)

    def test_frames_and_segments_counted_correctly_when_safe(self):
        p1 = os.path.join(self.tmpdir, "seg0.wav")
        p2 = os.path.join(self.tmpdir, "seg1.wav")
        _write_wav(p1, 48000, 2, 2, bytes(range(256)) * 10)
        _write_wav(p2, 48000, 2, 2, bytes(range(256)) * 10)

        result = classify_session(
            _status(frames_received=9600, frames_written=9600),
            segment_paths=[p1, p2])

        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertEqual(result.status, ArchivalState.ARCHIVAL_SAFE)  # alias
        self.assertEqual(result.frames_expected, 9600)
        self.assertEqual(result.frames_written, 9600)
        self.assertEqual(result.frames_lost, 0)
        self.assertEqual(result.segments_expected, 2)
        self.assertEqual(result.segments_valid, 2)
        self.assertEqual(result.segments_invalid, 0)
        # Sin `segment_checksums`: honesto en "no verificado", nunca
        # verdadero vacuo — pero el estado sigue siendo SAFE (ver
        # docstring de classify_session sobre esta decisión).
        self.assertFalse(result.checksum_verified)

    def test_checksum_verified_true_when_checksums_match(self):
        p = os.path.join(self.tmpdir, "seg0.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 10)
        checksum = compute_segment_checksum(p)
        checksum["path"] = p

        result = classify_session(_status(), segment_paths=[p],
                                   segment_checksums=[checksum])
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertTrue(result.checksum_verified)
        self.assertEqual(result.segments_invalid, 0)

    def test_missing_segment_counted_as_invalid_not_valid(self):
        existing = os.path.join(self.tmpdir, "seg0.wav")
        missing = os.path.join(self.tmpdir, "seg1.wav")
        _write_wav(existing, 48000, 2, 2, bytes(range(256)) * 10)

        result = classify_session(_status(), segment_paths=[existing, missing])
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertEqual(result.segments_expected, 2)
        self.assertEqual(result.segments_invalid, 1)
        self.assertEqual(result.segments_valid, 1)

    def test_checksum_mismatch_counts_as_invalid_segment(self):
        p = os.path.join(self.tmpdir, "seg0.wav")
        _write_wav(p, 48000, 2, 2, bytes(range(256)) * 10)
        checksum = compute_segment_checksum(p)
        checksum["path"] = p
        with open(p, "r+b") as f:
            f.seek(60)
            byte = f.read(1)
            f.seek(60)
            f.write(bytes([byte[0] ^ 0xFF]))

        result = classify_session(_status(), segment_paths=[p],
                                   segment_checksums=[checksum])
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertFalse(result.checksum_verified)
        self.assertEqual(result.segments_invalid, 1)
        self.assertEqual(result.segments_valid, 0)

    def test_frames_lost_mirrors_frames_dropped(self):
        result = classify_session(_status(frames_dropped=42, frames_received=1000))
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertEqual(result.frames_lost, 42)
        self.assertEqual(result.frames_expected, 1000)

    def test_no_segments_reports_zero_not_error(self):
        result = classify_session(_status())
        self.assertEqual(result.segments_expected, 0)
        self.assertEqual(result.segments_valid, 0)
        self.assertEqual(result.segments_invalid, 0)


if __name__ == "__main__":
    unittest.main()
