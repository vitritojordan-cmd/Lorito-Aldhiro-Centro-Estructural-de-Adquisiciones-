"""
test_archival_state.py — Fase 7 (máquina de estados de integridad
post-sesión) de la Orden Maestra de Saneamiento Pre-Auditoría Aldhira
Phonographic.

`classify_session` acepta un dict como sustituto de
`CaptureEngineStatus` — no requiere sounddevice/soundfile ni ningún
stub, es lógica pura.
"""

import os
import tempfile
import unittest

from lorito_aldhiro.backend.archival import ArchivalState, classify_session


def _status(**overrides):
    base = {
        "frames_dropped": 0, "xrun_count": 0, "recovery_count": 0,
        "rba_overrun_total": 0, "ced_dropped_frames": 0,
        "starvation_events": 0, "wd_phase": "OK",
    }
    base.update(overrides)
    return base


class TestArchivalSafe(unittest.TestCase):
    def test_clean_session_is_archival_safe(self):
        result = classify_session(_status())
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertEqual(result.reasons, [])
        self.assertTrue(result.is_safe)
        self.assertTrue(result.is_usable)


class TestDegraded(unittest.TestCase):
    def test_xruns_alone_is_degraded_not_invalid(self):
        result = classify_session(_status(xrun_count=3))
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertFalse(result.is_safe)
        self.assertTrue(result.is_usable)
        self.assertIn("xrun_count=3", result.reasons[0])

    def test_rba_overrun_is_degraded(self):
        result = classify_session(_status(rba_overrun_total=12))
        self.assertEqual(result.state, ArchivalState.DEGRADED)

    def test_ced_dropped_frames_is_degraded(self):
        result = classify_session(_status(ced_dropped_frames=500))
        self.assertEqual(result.state, ArchivalState.DEGRADED)

    def test_successful_recovery_is_degraded_not_invalid(self):
        # recovery_count>0 pero wd_phase == "OK" al finalizar → se
        # recuperó con éxito, la sesión es completa pero merece aviso.
        result = classify_session(_status(recovery_count=2, wd_phase="OK"))
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertIn("recuperado con éxito", result.reasons[0])

    def test_starvation_events_is_degraded(self):
        result = classify_session(_status(starvation_events=1))
        self.assertEqual(result.state, ArchivalState.DEGRADED)

    def test_multiple_degraded_reasons_all_reported(self):
        result = classify_session(_status(xrun_count=2, starvation_events=1))
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertEqual(len(result.reasons), 2)

    def test_dsp_nonfinite_total_alone_is_degraded_not_invalid(self):
        # GAP-062, §16/FASE 6 — política confirmada por el usuario:
        # cualquier saneamiento NaN/Inf degrada, sin umbral de tolerancia.
        result = classify_session(_status(), dsp_nonfinite_total=1)
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertFalse(result.is_safe)
        self.assertTrue(result.is_usable)
        self.assertIn("dsp_nonfinite_total=1", result.reasons[0])
        self.assertEqual(result.dsp_nonfinite_total, 1)

    def test_dsp_nonfinite_total_zero_stays_archival_safe(self):
        # Default (0, ni siquiera pasado) no debe cambiar el comportamiento
        # de antes de GAP-062 — retrocompatibilidad explícita.
        result = classify_session(_status())
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)
        self.assertEqual(result.dsp_nonfinite_total, 0)

    def test_dsp_nonfinite_combines_with_other_degraded_reasons(self):
        result = classify_session(_status(xrun_count=1), dsp_nonfinite_total=42)
        self.assertEqual(result.state, ArchivalState.DEGRADED)
        self.assertEqual(len(result.reasons), 2)
        self.assertEqual(result.dsp_nonfinite_total, 42)


class TestInvalid(unittest.TestCase):
    def test_frames_dropped_is_invalid(self):
        result = classify_session(_status(frames_dropped=1024))
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertFalse(result.is_usable)
        self.assertIn("frames_dropped=1024", result.reasons[0])

    def test_unrecovered_stream_is_invalid(self):
        result = classify_session(_status(recovery_count=12, wd_phase="RED"))
        self.assertEqual(result.state, ArchivalState.INVALID)
        self.assertIn("recovery agotado", result.reasons[0])

    def test_invalid_takes_priority_over_degraded_conditions(self):
        # frames_dropped (INVALID) + xrun_count (DEGRADED) al mismo
        # tiempo → INVALID gana, no se reporta como DEGRADED.
        result = classify_session(_status(frames_dropped=10, xrun_count=5))
        self.assertEqual(result.state, ArchivalState.INVALID)

    def test_missing_segment_file_is_invalid(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            existing = os.path.join(tmpdir, "seg0.wav")
            missing = os.path.join(tmpdir, "seg1.wav")
            with open(existing, "wb") as f:
                f.write(b"x" * 100)
            result = classify_session(_status(), segment_paths=[existing, missing])
            self.assertEqual(result.state, ArchivalState.INVALID)
            self.assertIn("faltante", result.reasons[0])

    def test_empty_segment_file_is_invalid(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            empty = os.path.join(tmpdir, "seg0.wav")
            open(empty, "wb").close()
            result = classify_session(_status(), segment_paths=[empty])
            self.assertEqual(result.state, ArchivalState.INVALID)

    def test_check_files_exist_false_skips_filesystem_check(self):
        # Sin acceso al filesystem de los segmentos (p. ej. clasificar
        # solo a partir de telemetría) — no debe fallar ni intentar
        # tocar disco.
        result = classify_session(_status(), segment_paths=["/no/existe.wav"],
                                  check_files_exist=False)
        self.assertEqual(result.state, ArchivalState.ARCHIVAL_SAFE)


if __name__ == "__main__":
    unittest.main()
