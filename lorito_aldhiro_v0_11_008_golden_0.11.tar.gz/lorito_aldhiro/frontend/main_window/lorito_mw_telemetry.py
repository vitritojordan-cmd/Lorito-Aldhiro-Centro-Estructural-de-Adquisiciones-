"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Telemetría en vivo: estado del motor, progreso de exportación, VU, forma de onda, archival.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb, _status
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_v21 import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, SignalPulseCell,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




class TelemetryMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _on_backend_status(self, msg: str):
        _elog = getattr(self, "_event_log", None)
        if _elog is not None and not msg.startswith("__"):
            _elog.emit("ui.status", "INFO", "STATUS_MSG", data={"text": msg})
        if msg == "__EXPORT_DONE__":
            self._norm_blink_timer.stop()
            self.status_label.setText("__NORM_BLINK_OFF__")
            self._ui_state = ""  # forzar re-aplicación
            self._set_ui_state("standby")
            self._sync_buttons()
            # ── Cierre diferido post-export (CierreAbruptoCRAC "No") ──────────
            # Si el export fue lanzado desde closeEvent (guardar y cerrar),
            # disparamos el cierre ahora que el guardado terminó.
            if getattr(self, "_pending_close_after_export", False):
                self._pending_close_after_export = False
                QTimer.singleShot(80, self.close)   # breve pausa para que la UI se actualice
            return
        if msg == "__NORM_BLINK_ON__":
            self.status_label.setText("__NORM_BLINK_ON__")
            if not self._norm_blink_timer.isActive():
                self._norm_blink_timer.start()
            return
        # CAROLA DELICADA: arrancar timer de parpadeo al recibir la advertencia
        # y detenerlo tan pronto el nivel cambie a cualquier otro mensaje.
        if msg.startswith("__DRIFT_FRAMES_WARN__"):
            self.status_label.setText(msg)
            if not self._drift_frames_blink_timer.isActive():
                self._drift_frames_blink_timer.start()
            return
        # CAROLA ESTÁ APROBANDO: arrancar/detener timer de parpadeo celeste/verde
        if msg == "__EXPORT_VALIDATING_START__":
            self.status_label.setText("__EXPORT_VALIDATING_START__")
            return
        if msg == "__EXPORT_VALIDATING_STOP__":
            self.status_label.setText("__EXPORT_VALIDATING_STOP__")
            return
        # Cualquier otro mensaje distinto detiene el parpadeo de CAROLA DELICADA
        if self._drift_frames_blink_timer.isActive():
            self._drift_frames_blink_timer.stop()
        self.status_label.setText(msg)
    def _on_export_progress(self, codec: str, norm_val: str, pct: int):
        """
        Slot conectado a _bridge.export_progress (GUI thread).
        Gestiona el ciclo de vida del CracSaveDialog:
          · pct == 0   → crea y muestra el diálogo (si no existe)
          · 0 < pct < 100 → actualiza la barra de progreso
          · pct == 100 → avanza la barra al 100 % y el diálogo se cierra solo
          · pct == -1  → cierre forzado (error o finally), sin importar el valor
        """
        if pct == -1:
            # Cierre forzado: error durante el export
            if self._crac_save_dlg is not None:
                self._crac_save_dlg.done(0)
                self._crac_save_dlg = None
            # Limpiar overlay "Export" del contómetro (GAP-010) — el export
            # terminó (con error), ya no debe seguir mostrándose.
            if hasattr(self, "clock"):
                self.clock.setOverlay("EXPORT", False)
            return

        if self._crac_save_dlg is None:
            # Primera emisión: crear y mostrar el diálogo
            self._crac_save_dlg = CracSaveDialog(codec, norm_val, self)
            self._crac_save_dlg.finished.connect(
                lambda: setattr(self, "_crac_save_dlg", None)
            )
            self._crac_save_dlg.show()

        self._crac_save_dlg.set_progress(pct)
        if pct >= 100 and hasattr(self, "clock"):
            # Limpiar overlay "Export" del contómetro (GAP-010) — export
            # completado con éxito.
            self.clock.setOverlay("EXPORT", False)
    def _on_vu_ready(self, rms_l: float, rms_r: float):
        """Recibe nivel de VU desde audio thread (vía señal queued).
        Siempre ejecutado en el main/GUI thread — safe para Wayland SHM.
        """
        if hasattr(self, "vu"):
            self.vu.setValues(rms_l, rms_r)
            self.vu.update()   # update() AQUÍ = main thread = seguro
    def _on_tape_update(self):
        """Pulso de animación para TapeLogPanel — main thread únicamente."""
        for attr in ("tape_log_a", "tape_log_b"):
            tl = getattr(self, attr, None)
            if tl is not None:
                tl.update()
    def _tick_vu_redraw(self):
        """Llamado desde _tick() (GUI timer, 15 Hz) para repaints pendientes.
        Centraliza todos los update() de widgets visuales en el GUI timer,
        eliminando el patrón de update() disperso en métodos llamados
        desde threads de audio.
        """
        # Waveform pendiente
        if hasattr(self, "waveform") and self.waveform._pending_update:
            self.waveform._pending_update = False
            self.waveform.update()
        # FIX-VUMETERS-FROZEN: repintar VU meters a 15 Hz como respaldo al
        # update() de _tick_cassette (24 Hz). Cubre el caso en que los datos
        # se actualizaron en _tick() pero _tick_cassette aun no corrio.
        # Seguro: _tick_vu_redraw siempre corre en el GUI thread (QTimer).
        if hasattr(self, "vu_rec"):
            self.vu_rec.update()
        if hasattr(self, "vu_play"):
            self.vu_play.update()
        # StatusDisplay (si tiene dirty interno)
        if hasattr(self, "status_label"):
            pass  # StatusDisplay ya tiene update() en setText -- OK en GUI timer
    def _on_waveform_ready(self, waveform_widget, mn_arr, mx_arr, peak_clip: bool):
        """
        FIX-WAVEFORM-THREAD-CRASH — Slot Qt, siempre en GUI thread.
        Aplica los datos calculados por _WaveformUpdateWorker y repinta.
        Nunca se llama desde el worker thread — llega via señal Qt queued.
        """
        try:
            waveform_widget._wave_mn   = mn_arr
            waveform_widget._wave_mx   = mx_arr
            waveform_widget._wave_data = None
            waveform_widget._peak_clip = peak_clip
            waveform_widget._freq_hue  = None
            waveform_widget._dirty     = True
            waveform_widget.update()   # seguro: estamos en el GUI thread
        except Exception as e:
            _log.debug("_on_waveform_ready: %s", e)
    def _on_recovery_msg(self, msg: str):
        self.status_label.setText(msg)
    def _on_stream_died(self):
        """GUI responde al stream muerto: actualiza indicadores sin cerrarse."""
        self.ind.setState("standby")
        self.status_label.setText("__STREAM_SLEEP__")
        self._stream_sleep_blink_timer.start()
    def _update_internal_status(self):
        """Actualiza buf_label con telemetría compacta v0.08 (1 Hz)."""
        # Telemetría RAM
        ram_mb = _sample_ram_mb()
        _status.ram_mb_approx = ram_mb
        if ram_mb > RAM_THRESHOLD_CRITICAL_MB:
            if _status.ram_state != "CRITICAL":
                _status.ram_state = "CRITICAL"
                _log.error("RAM CRITICAL: %.0f MB — liberando caches", ram_mb)
                self._emergency_free_memory()
        elif ram_mb > RAM_THRESHOLD_HIGH_MB:
            if _status.ram_state == "OK":
                _status.ram_state = "HIGH"
                _log.warning("RAM HIGH: %.0f MB", ram_mb)
        else:
            _status.ram_state = "OK"

        if self._engine.recording and not self._engine.paused:
            xr   = _status.xrun_count
            qs   = getattr(_status, 'ced_frame_count', 0)
            q_pct= int(getattr(_status, 'ced_pressure_pct', 0.0))
            bp   = _status.backpressure_state[0]   # S/H/C/E
            drift_ms = _status.drift_ms
            jit  = _status.callback_jitter_ms
            mbps = _status.disk_mbps
            ar   = "SAFE" if not self._archival_safe else "ARCH"
            # Formato compacto v0.08:
            # RT OK | XR:0 | Q:12% | RAM:210MB | DRIFT:0.2ms
            parts = [
                f"{'RT' if _status.stream_alive else 'XX'} {ar[:2]}",
                f"XR:{xr}",
                f"Q:{q_pct}%",
                f"RAM:{ram_mb:.0f}MB",
                f"DRIFT:{drift_ms:.1f}ms",
            ]
            if mbps > 0:
                parts.append(f"{mbps:.1f}MB/s")
            if jit > 10:
                parts.append(f"JIT:{jit:.0f}ms")
            self.buf_label.setText(" | ".join(parts))

            # ── Detección de tendencia del RBA (anti-skip buffer) ─────────────
            # Solo monitorear si el motor tiene RBA accesible.
            # Umbral de tendencia: Δwm > +0.05 (llenando) / < -0.05 (vaciando).
            # Histéresis: 3 ticks consecutivos en la misma dirección antes de
            # cambiar el estado visible (evita parpadeo por fluctuaciones breves).
            _rba_wm_raw = getattr(_status, 'rba_watermark_pct', -1.0)
            if _rba_wm_raw >= 0:
                _rba_wm = _rba_wm_raw / 100.0   # normalizar a 0.0–1.0
                if self._rba_prev_wm >= 0:
                    _delta = _rba_wm - self._rba_prev_wm
                    _TREND_THRESH = 0.05           # 5% de cambio por tick
                    _HYST_TICKS   = 3              # ticks consecutivos requeridos
                    if _delta > _TREND_THRESH:
                        _new_dir = "llena"
                    elif _delta < -_TREND_THRESH:
                        _new_dir = "vacia"
                    else:
                        _new_dir = "none"
                    if _new_dir == self._rba_vasito:
                        self._rba_tick_count += 1
                    else:
                        self._rba_tick_count = 1 if _new_dir != "none" else 0
                        self._rba_vasito = _new_dir
                    # Emitir leyenda solo cuando se alcanza el umbral de histéresis
                    if self._rba_tick_count == _HYST_TICKS:
                        if self._rba_vasito == "llena":
                            self.status_label.setText("__VASITO_LLENA__")
                        elif self._rba_vasito == "vacia":
                            self.status_label.setText("__VASITO_VACIA__")
                self._rba_prev_wm = _rba_wm
        else:
            # Fuera de grabación: resetear seguimiento del RBA
            self._rba_prev_wm    = -1.0
            self._rba_vasito     = "none"
            self._rba_tick_count = 0

        # ── Leyenda de reposo total ───────────────────────────────────────────
        # "CAROLALDHIRA ACTIVA!" en blanco puro SOLO cuando no hay NINGUNA
        # actividad: sin grabación, sin reproducción, sin morpher, sin vaciado.
        # Durante reproducción el log lo gestiona _on_seek_ready / _on_speed_changed
        # / _on_morpher_changed directamente — este tick NO debe pisarlos.
        is_idle = (
            not self._engine.recording
            and not self._playing
            and not self._morpher_active
            and self._ui_state not in ("rec", "pause", "stop", "play", "export")
            and self.status_label._level in ("idle", "activa",
                                             "ok", "speed_purple",
                                             "carolamotion", "carolamotion_rev")
        )
        if is_idle:
            self.status_label.setText("__CAROLALDHIRA_ACTIVA__")
    def _emergency_free_memory(self):
        """Libera toda memoria no crítica cuando RAM supera umbral CRITICAL."""
        _log.error("Modo protección RAM activado — liberando caches")
        with self._speed_cache_lock:
            self._speed_cache = None
            self._speed_cache_ratio = None
        gc.collect()   # CONSERVADO: camino de emergencia RAM — único gc.collect() legítimo
        _log.info("Caches liberadas. RAM antes=%.0f MB", _status.ram_mb_approx)
    def _archival_tick(self):
        """
        Tick cada 5 s: comprueba drift temporal y guarda snapshots periódicos.
        v0.08: core del sistema de auditoría archivística.
        """
        if not self._engine.recording or self._engine.paused:
            return
        now = time.monotonic()

        # ── Drift temporal ────────────────────────────────────────────────
        if self._drift_t0 > 0:
            elapsed_wall   = now - self._drift_t0
            expected_f     = elapsed_wall * self._cache_rate
            actual_f       = float(_status.frames_received)
            drift_ms       = (actual_f - expected_f) / max(self._cache_rate, 1) * 1000.0
            _status.drift_ms = drift_ms
            _status.expected_frames = int(expected_f)

            if abs(drift_ms) > DRIFT_WARN_MS:
                _status.drift_warn_count += 1
                _log.warning("Drift temporal: %.1f ms (expected=%.0f actual=%.0f)",
                             drift_ms, expected_f, actual_f)
                if abs(drift_ms) > DRIFT_WARN_MS * 3:
                    _bridge.status_msg.emit(
                        f"LORITO VIO UNA DERIVA, TE AVISA!!! {drift_ms:+.0f}ms — pérdidas: {_status.drift_warn_count}")

        # ── Snapshot periódico ────────────────────────────────────────────
        if (self._snapshot_t == 0 or
                now - self._snapshot_t >= SNAPSHOT_INTERVAL_SECS):
            dur = self._rec_elapsed + (now - self._rec_start_t)
            if self._disk_tmp_path and _status.frames_written > 0:
                # OPT-03: worker persistente en lugar de Thread() efímero
                _snapshot_worker.submit(
                    self._disk_tmp_path, self._cache_rate,
                    _status.frames_written, self._session_codec, dur
                )
            self._snapshot_t = now

        # ── CrashGuard: actualizar manifest con estado actual ─────────────
        # Se ejecuta siempre que haya grabación activa. El ticker del daemon
        # escribe a disco cada CRASH_HEARTBEAT_SECS; aquí actualizamos el dict
        # en RAM para que el próximo tick tenga datos frescos.
        if self._disk_tmp_path and _status.frames_written > 0:
            dur_now = self._rec_elapsed + (now - self._rec_start_t)
            try:
                seg_paths = list(self._engine._disk_writer.get_segment_paths())
            except Exception:
                seg_paths = []
            _crash_guard.update({
                "samplerate":     self._cache_rate,
                "tmp_file":       self._disk_tmp_path,
                "segment_paths":  seg_paths,
                "frames_written": _status.frames_written,
                "duration_secs":  round(dur_now, 3),
                "codec_hint":     self.codec_box.currentText(),
                "opt1":           self.opt1_box.currentText(),
                "opt2":           self.opt2_box.currentText(),
                "norm":           self.norm_box.currentText(),
                "xruns":          _status.xrun_count,
                "drift_ms":       round(_status.drift_ms, 3),
                # v0.20 — normalización avanzada
                "normalization_mode":           _status.normalization_mode,
                "normalization_gain_db":        round(_status.normalization_gain_db, 4),
                "normalization_peak_db":        round(_status.normalization_peak_db, 4),
                "normalization_lufs":           round(_status.normalization_lufs, 4)
                                                if _status.normalization_lufs != float("-inf")
                                                else None,
                "normalization_noise_floor_db": round(_status.normalization_noise_floor_db, 4)
                                                if _status.normalization_noise_floor_db != float("-inf")
                                                else None,
                "normalization_true_peak_db":   round(_status.normalization_true_peak_db, 4),
                # CRAC 0.20 — campos extendidos
                "normalization_pre_gain_db":       round(_status.normalization_pre_gain_db, 4),
                "normalization_post_gain_db":      round(_status.normalization_post_gain_db, 4),
                "normalization_mid_rms":           (round(_status.normalization_mid_rms, 3)
                                                    if _status.normalization_mid_rms != float("-inf")
                                                    else None),
                "normalization_side_rms":          (round(_status.normalization_side_rms, 3)
                                                    if _status.normalization_side_rms != float("-inf")
                                                    else None),
                "normalization_stereo_balance":    round(_status.normalization_stereo_balance, 4),
                "normalization_crest_factor_db":   (round(_status.normalization_crest_factor_db, 2)
                                                    if _status.normalization_crest_factor_db != float("inf")
                                                    else None),
                "normalization_dynamic_range":     round(_status.normalization_dynamic_range, 2),
                "normalization_histogram_density": round(_status.normalization_histogram_density, 6),
                "normalization_silence_ratio":     round(_status.normalization_silence_ratio, 4),
                "normalization_auto_mode":         _status.normalization_auto_mode or None,
                # ── Cuentavueltas (persistencia ante crash) ──────────────────
                # Se guarda el estado completo del TapeLogPanel activo para que
                # _do_crash_recovery() pueda restaurarlo y el log de especificación
                # no muestre 000 al exportar un archivo recuperado.
                **self._get_counter_manifest_fields(),
            })
    def _get_counter_manifest_fields(self) -> dict:
        """
        Retorna un dict con el estado actual del cuentavueltas del TapeLogPanel
        activo, listo para ser mezclado en el crash-manifest.

        Usa claves con prefijo "counter_" para no colisionar con otros campos
        del manifest.  Si no se puede obtener el panel, retorna un dict vacío
        (el manifest quedará sin datos de cuentavueltas en lugar de fallar).
        """
        try:
            _lbl = self.cassette_dur_box.currentText()
            _panel_map = {
                "C-60":  self.tape_c60,
                "C-90":  self.tape_c90,
                "OTROS": self.tape_otros,
            }
            _panel = _panel_map.get(_lbl)
            if _panel is None:
                return {}
            return {
                "counter_tape_label":    _panel._tape_label,
                "counter_surplus_a":     _panel._counter_surplus_a,
                "counter_surplus_b":     _panel._counter_surplus_b,
                "counter_wrap_a_count":  _panel._counter_wrap_a_count,
                "counter_wrap_b_count":  _panel._counter_wrap_b_count,
                "counter_wrap_count":    _panel._counter_wrap_count,
                "counter_final_value":   _panel._counter_final_value,
                "counter_phase":         _panel._phase,
                "counter_flip_done":     _panel._flip_done,
            }
        except Exception as _e:
            _log.warning("_get_counter_manifest_fields: no se pudo leer estado — %s", _e)
            return {}
    def _toggle_archival_safe(self, enabled: bool):
        """
        Activa/desactiva Modo Archival Safe.
        Reduce FPS GUI, aumenta margen buffers, endurece watchdog.
        """
        self._archival_safe         = enabled
        _status.archival_safe_mode  = enabled
        if enabled:
            self._timer_vu.setInterval(1000 // ARCHIVAL_SAFE_FPS)   # ~10 FPS
            _log.info("Modo Archival Safe ACTIVADO: FPS=%d watchdog=%.1fs",
                      ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG)
        else:
            self._timer_vu.setInterval(SILENCE_ANALYSIS_INTERVAL_MS)   # 15 Hz — CRAC_UNIVERSAL_THRESHOLD_PROFILE
            _log.info("Modo Archival Safe DESACTIVADO")
