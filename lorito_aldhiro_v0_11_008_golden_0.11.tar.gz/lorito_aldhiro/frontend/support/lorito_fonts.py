from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Carga y registro de las fuentes tipográficas de la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_fonts.py — motor de registro de fuentes de letra embebidas.

Objetivo (pedido explícito del usuario, mismo criterio ya aplicado en
CRAC): Lorito Aldhiro NO debe depender de que el sistema operativo
anfitrión tenga instaladas fuentes concretas. El código heredado de la
modularización (`aecct2_v22_55.py` original) referenciaba "Helvetica
Neue"/"Futura"/"Courier New" por nombre — fuentes de macOS que, en
cualquier otro sistema (la mayoría de instalaciones Linux, por ejemplo),
Qt sustituye en silencio por lo que el tema del escritorio tenga a mano,
así que el aspecto de la app YA dependía del sistema anfitrión, de forma
invisible. Este motor reemplaza esa dependencia por fuentes reales,
embebidas en el propio tarball, registradas vía
`QFontDatabase.addApplicationFont()` — nunca resueltas por nombre desde
el catálogo del sistema.

Cuatro familias, cada una con su rol fijo (asignado por el usuario):

    Patopian 1986   → dígitos del panel de contómetro principal
    LLPixel         → cuentavueltas analógico (rodillos mecánicos) del
                       panel de duración de cinta
    Exo 2           → texto general de la interfaz
    Creato Display  → leyendas de los paneles de log y de duración de cinta
    Helvetica       → Media Anim (rediseño VFD dorado, pedido explícito
                       del usuario) — familia real verificada en la
                       tabla `name` (nameID 1) de los 4 archivos
                       entregados: "Helvetica"/"Helvetica Bold"/
                       "Helvetica Oblique"/"Helvetica Bold Oblique".
    Utendo          → leyendas de las CELDAS COMPARTIDAS del panel de
                       contómetro principal (columnas laterales L1-L4/
                       R1-R4 y filas de leyenda superior/inferior —
                       `DigitalClock._paint_side_column`/
                       `_paint_legend_row`), pedido explícito del
                       usuario. Familia real verificada por nameID 1 de
                       los 2 archivos entregados: "Utendo"/"Utendo
                       Bold". NO sustituye a Creato Display en el resto
                       de paneles (log/duración de cinta) ni en los
                       overlays transitorios del contómetro — solo las
                       leyendas fijas de esas celdas compartidas.

Uso:
    from lorito_aldhiro.frontend.support.lorito_fonts import (
        register_embedded_fonts, font_contometro, font_cuentavueltas,
        font_ui, font_leyendas, font_celdas_compartidas,
    )

    # Una vez, tras crear QApplication y antes de construir cualquier
    # widget (ver lorito_bootstrap.py):
    register_embedded_fonts()

    # En cualquier paintEvent/stylesheet:
    p.setFont(font_contometro(size=36, bold=True))
"""

import glob
import os

from lorito_aldhiro.backend.core.lorito_app_logging import _log


_ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "fonts")

# Nombre de familia REAL tal como queda embebido en cada archivo (tabla
# `name`, nameID 1 — verificado directamente sobre los archivos de fuente
# entregados, no asumido por el nombre del archivo/carpeta).
FONT_FAMILY_CONTOMETRO    = "Patopian 1986"
FONT_FAMILY_CUENTAVUELTAS = "LLPixel"
FONT_FAMILY_UI            = "Exo 2"
FONT_FAMILY_LEYENDAS      = "Creato Display"
FONT_FAMILY_MEDIA_ANIM    = "Helvetica"
FONT_FAMILY_CELDAS_COMPARTIDAS = "Utendo"

_FAMILY_DIRS = {
    FONT_FAMILY_CONTOMETRO:    "patopian_1986",
    FONT_FAMILY_CUENTAVUELTAS: "llpixel",
    FONT_FAMILY_UI:            "exo2",
    FONT_FAMILY_LEYENDAS:      "creato_display",
    FONT_FAMILY_MEDIA_ANIM:    "helvetica",
    FONT_FAMILY_CELDAS_COMPARTIDAS: "utendo",
}

_FONT_EXTENSIONS = (".ttf", ".otf")

# Se completa en register_embedded_fonts() — familias que efectivamente
# quedaron registradas con éxito. Cualquier `font_*()` que pida una
# familia ausente de este set cae al fallback de emergencia (§ver abajo)
# en vez de nombrar una fuente del sistema operativo por adivinanza.
_REGISTERED_FAMILIES: set[str] = set()
_REGISTRATION_DONE = False


def register_embedded_fonts() -> dict:
    """
    Registra TODOS los archivos de fuente embebidos en `assets/fonts/`
    vía `QFontDatabase.addApplicationFont()`. Idempotente — llamadas
    repetidas no vuelven a registrar (evita duplicados en
    QFontDatabase si algo la invoca más de una vez).

    Debe llamarse DESPUÉS de crear la `QApplication` (requisito de Qt
    para `QFontDatabase`) y ANTES de construir cualquier widget que
    vaya a usar estas fuentes.

    Devuelve un dict {familia_esperada: bool_registrada_ok} para que el
    llamador pueda decidir si continúa o registra un aviso — nunca
    lanza excepción por una fuente faltante (mismo criterio de
    degradación con gracia que el resto del proyecto ante dependencias
    opcionales, p. ej. `FFMPEG_CAPS`).
    """
    global _REGISTRATION_DONE
    from PySide6.QtGui import QFontDatabase
    result = {fam: False for fam in _FAMILY_DIRS}

    if _REGISTRATION_DONE:
        return {fam: fam in _REGISTERED_FAMILIES for fam in _FAMILY_DIRS}

    for family, subdir in _FAMILY_DIRS.items():
        dirpath = os.path.join(_ASSETS_DIR, subdir)
        if not os.path.isdir(dirpath):
            _log.error("lorito_fonts: directorio de fuente faltante: %s", dirpath)
            continue

        loaded_any = False
        for path in sorted(glob.glob(os.path.join(dirpath, "*"))):
            if not path.lower().endswith(_FONT_EXTENSIONS):
                continue
            font_id = QFontDatabase.addApplicationFont(path)
            if font_id == -1:
                _log.error("lorito_fonts: fallo al registrar '%s' "
                          "(QFontDatabase.addApplicationFont devolvió -1)", path)
                continue
            families = QFontDatabase.applicationFontFamilies(font_id)
            if family in families:
                loaded_any = True
            else:
                _log.warning(
                    "lorito_fonts: '%s' se registró pero su familia real "
                    "(%s) no coincide con la esperada ('%s') — revisar archivo",
                    path, list(families), family)

        if loaded_any:
            _REGISTERED_FAMILIES.add(family)
            result[family] = True
        else:
            _log.error("lorito_fonts: NINGÚN archivo válido encontrado para "
                      "la familia '%s' en %s — se usará fallback de emergencia, "
                      "NUNCA una fuente del sistema operativo nombrada a mano",
                      family, dirpath)

    _REGISTRATION_DONE = True
    return result


def _resolve_family(preferred: str) -> str:
    """
    Devuelve `preferred` si su registro fue exitoso. Si no (archivo
    faltante/corrupto), NUNCA cae a un nombre de fuente del sistema
    operativo (Helvetica Neue/Futura/Arial/etc. — eso es exactamente la
    dependencia que este motor existe para eliminar). En su lugar
    devuelve cadena vacía, que Qt interpreta como "usar la fuente por
    defecto de la aplicación" (`QFont()` sin argumentos) — el único
    fallback que Qt garantiza sin nombrar nada específico del SO.
    """
    if not _REGISTRATION_DONE:
        register_embedded_fonts()
    if preferred in _REGISTERED_FAMILIES:
        return preferred
    return ""


def _make_font(preferred_family: str, size: int, bold: bool = False,
               letter_spacing: float | None = None) -> QFont:
    from PySide6.QtGui import QFont
    family = _resolve_family(preferred_family)
    fnt = QFont(family) if family else QFont()
    if size:
        fnt.setPixelSize(size)
    fnt.setBold(bold)
    if letter_spacing is not None:
        fnt.setLetterSpacing(QFont.AbsoluteSpacing, letter_spacing)
    return fnt


# ── Factories por rol (§ver docstring del módulo) ─────────────────────────

def font_contometro(size: int = 36, bold: bool = True,
                    letter_spacing: float | None = 2) -> QFont:
    """Dígitos del panel de contómetro principal — Patopian 1986."""
    return _make_font(FONT_FAMILY_CONTOMETRO, size, bold, letter_spacing)


def font_cuentavueltas(size: int = 18, bold: bool = True,
                       letter_spacing: float | None = 0) -> QFont:
    """Rodillos del cuentavueltas mecánico (panel de duración de cinta)
    — LLPixel."""
    return _make_font(FONT_FAMILY_CUENTAVUELTAS, size, bold, letter_spacing)


def font_ui(size: int = 9, bold: bool = False,
           letter_spacing: float | None = None) -> QFont:
    """Texto general de la interfaz — Exo 2."""
    return _make_font(FONT_FAMILY_UI, size, bold, letter_spacing)


def font_leyendas(size: int = 9, bold: bool = False,
                  letter_spacing: float | None = 1) -> QFont:
    """Leyendas de los paneles de log y de duración de cinta — Creato
    Display."""
    return _make_font(FONT_FAMILY_LEYENDAS, size, bold, letter_spacing)


def font_media_anim(size: int = 7, bold: bool = True,
                    letter_spacing: float | None = 1) -> QFont:
    """Etiquetas/rótulos del Media Anim (rediseño VFD dorado) —
    Helvetica."""
    return _make_font(FONT_FAMILY_MEDIA_ANIM, size, bold, letter_spacing)


def font_celdas_compartidas(size: int = 9, bold: bool = True,
                            letter_spacing: float | None = None) -> QFont:
    """Leyendas de las celdas compartidas del contómetro principal
    (columnas laterales L1-L4/R1-R4 y filas de leyenda superior/
    inferior) — Utendo, pedido explícito del usuario."""
    return _make_font(FONT_FAMILY_CELDAS_COMPARTIDAS, size, bold, letter_spacing)


def ui_family_css() -> str:
    """
    Nombre de familia para usar en hojas de estilo Qt (`font-family:`).
    Devuelve SIEMPRE `FONT_FAMILY_UI` tal cual — a diferencia de
    `_resolve_family()`, una hoja de estilo no puede recibir cadena
    vacía de forma útil (Qt simplemente ignora la regla), así que aquí
    se nombra la familia esperada; si el registro falló, Qt hará su
    propia sustitución interna de todos modos, pero eso solo puede
    ocurrir si `register_embedded_fonts()` ya reportó el fallo por log
    — no es un comportamiento silencioso nuevo introducido por esta
    función.
    """
    return f"'{FONT_FAMILY_UI}'"
