from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Panel de estado general de la sesión en la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import math as _math
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.frontend.support.lorito_theme import THEME
from lorito_aldhiro.frontend.support.lorito_fonts import font_leyendas


# ─────────────────────────────────────────────────────────────────────────────
#  STATUS DISPLAY  — indicador de log con fondo estilo waveform
# ─────────────────────────────────────────────────────────────────────────────

class StatusDisplay(QWidget):
    """
    Rectángulo estilo WaveformDisplay que muestra el mensaje de estado.
    · Verde  → operación normal / progreso
    · Naranja → advertencia / posible daño de señal
    · Rojo   → error
    · Gris   → reposo (LISTO, idle)
    Reemplaza status_label + buf_label con una API compatible (setText / text).
    """

    # Palabras clave para clasificar el nivel del mensaje
    _ERROR_KEYS   = ("ERROR", "FALLÓ", "FALLO", "FAIL", "CRITICO",
                     "CRÍTICO", "CORRUPTO", "CORRUPT", "DISK ERROR",
                     "NO SE PUDO", "INCOMPLETO")
    _WARN_KEYS    = ("⚠", "WARN", "INTERRUMPIDO", "RECUPERANDO", "XRUN",
                     "CLIP", "DRIFT", "OVERFLOW", "STALL", "STARVATION",
                     "PRESSURE", "BACKPRESSURE", "JITTER", "VALIDANDO",
                     "SOSPECHOSO", "RT:", "AVISO", "LORITO VIO UNA DERIVA",
                     "LORITO EN PERDIDA FUERTE", "SEÑAL BASURA")
    _OK_KEYS      = ("LORITO", "GRABANDO", "LISTO",
                     "GUARDADO", "EXPORT", "EXPORTANDO",
                     "REPRODUCIENDO", "CODIFICANDO", "CHECKSUM", "RESAMPLEANDO",
                     "VELOCIDAD", "LEYENDO", "DETENIDO", "DETENIENDO",
                     "PAUSADO", "RECUPERADO", "COMPLETO", "OK", "STREAM")

    def __init__(self, parent=None):
        super().__init__(parent)
        self._msg      = "LISTO"
        self._aux      = ""
        self._level    = "idle"   # "ok" | "warn" | "error" | "idle"
        self._norm_blink_state = False   # estado parpadeo normalización
        self._norm_visible     = False   # True cuando hay normalización activa
        self._cafe_blink_state = True    # estado parpadeo VA POR UN CAFE (pausa)
        self._flush_blink_state = True   # estado parpadeo vaciado azul
        # ── Animación de cassette ────────────────────────────────────────────
        # _cassette_mode: None | "rec" | "drift" | "play"
        #                 | "speed" | "morph_fwd" | "morph_rev"
        self._cassette_mode    = None
        self._cassette_angle   = 0.0    # grados acumulados (0..360)
        self._cassette_blink   = False  # estado de parpadeo en modo drift
        self._cassette_reverse = False  # True cuando morphing va en reversa
        # ── Drift Crónico v0.20 — parpadeo amarillo/rojo alternado ───────────
        self._cronica_drift_ms    = 0.0   # drift acumulado en ms (para mostrar)
        self._cronica_blink_phase = False # False=amarillo intenso, True=rojo intenso
        # ── CAROLA DELICADA — parpadeo verde brillante ↔ color original error ─
        self._drift_frames_pct    = 0.0   # % drift frames (para mostrar)
        self._drift_frames_phase  = False # False=verde brillante, True=color original
        # ── CAROLACAPTURE SE DURMIÓ — parpadeo rosa intenso ↔ rojo intenso ────
        self._sleep_blink_phase   = False # False=rosa intenso, True=rojo intenso
        # ── CAROLA ESTÁ APROBANDO — parpadeo celeste ↔ verde claro ─────────────
        self._validating_blink_phase = False # False=celeste brillante, True=verde claro
        # ── CAROLA SIRVIÓ TU PLATO — parpadeo rosa intenso ↔ turquesa intenso ──
        self._sirvio_blink_phase  = False    # False=rosa intenso, True=turquesa intenso
        # ── CAROLA ARROJO EL PLATO — parpadeo gris ↔ rojo intenso ──────────────
        self._arrojo_blink_phase  = False    # False=gris, True=rojo intenso
        # ── TRANSDIGITALIZADOR IDIOTA — parpadeo naranja ↔ rosa intenso ─────────
        self._transdig_blink_phase = False   # False=naranja intenso, True=rosa intenso
        # ── ERROR CAROLA — parpadeo rojo intenso ↔ magenta intenso ──────────────
        self._error_carola_blink_phase = False  # False=rojo intenso, True=magenta intenso
        # ── CAROLA VELOZ PERFECTA — parpadeo crema pastel ↔ verde intenso ───────
        self._veloz_ok_blink_phase = False   # False=crema pastel, True=verde intenso
        # ── CAROLA LLEVA EL VASITO — parpadeo verde intenso ↔ morado ────────────
        self._vasito_llena_blink_phase = False  # False=verde intenso, True=morado
        # ── CAROLA SE LE ACABA EL VASITO — parpadeo rojo intenso ↔ morado ───────
        self._vasito_vacia_blink_phase = False  # False=rojo intenso, True=morado
        # ── Timer de parpadeo export_validating (350 ms) ─────────────────────
        # FIX-VALIDATING-TIMER (v0.22.09): el timer se creaba en LoritoAldhiroStudio
        # pero setText() lo buscaba en self (StatusDisplay) → AttributeError.
        # Se mueve aquí para que esté disponible desde la construcción del widget.
        self._export_validating_blink_timer = QTimer(self)
        self._export_validating_blink_timer.setInterval(350)
        self._export_validating_blink_timer.timeout.connect(
            lambda: self.setText("__EXPORT_VALIDATING_TICK__")
        )
        # ── Timer parpadeo CAROLA SIRVIÓ TU PLATO (450 ms) ───────────────────
        self._sirvio_blink_timer = QTimer(self)
        self._sirvio_blink_timer.setInterval(450)
        self._sirvio_blink_timer.timeout.connect(
            lambda: self.setText("__CAROLA_SIRVIO_TICK__")
        )
        # ── Timer parpadeo CAROLA ARROJO EL PLATO (500 ms) ───────────────────
        self._arrojo_blink_timer = QTimer(self)
        self._arrojo_blink_timer.setInterval(500)
        self._arrojo_blink_timer.timeout.connect(
            lambda: self.setText("__CAROLA_ARROJO_TICK__")
        )
        # ── Timer parpadeo TRANSDIGITALIZADOR IDIOTA (400 ms) ────────────────
        self._transdig_blink_timer = QTimer(self)
        self._transdig_blink_timer.setInterval(400)
        self._transdig_blink_timer.timeout.connect(
            lambda: self.setText("__TRANSDIGITALIZADOR_TICK__")
        )
        # ── Timer parpadeo ERROR CAROLA (300 ms) ─────────────────────────────
        self._error_carola_blink_timer = QTimer(self)
        self._error_carola_blink_timer.setInterval(300)
        self._error_carola_blink_timer.timeout.connect(
            lambda: self.setText("__ERROR_CAROLA_TICK__")
        )
        # ── Timer parpadeo CAROLA VELOZ PERFECTA (600 ms) — crema ↔ verde ────
        self._veloz_ok_blink_timer = QTimer(self)
        self._veloz_ok_blink_timer.setInterval(600)
        self._veloz_ok_blink_timer.timeout.connect(
            lambda: self.setText("__CAROLA_VELOZ_OK_TICK__")
        )
        # ── Timer parpadeo CAROLA LLEVA EL VASITO (500 ms) — verde ↔ morado ──
        self._vasito_llena_blink_timer = QTimer(self)
        self._vasito_llena_blink_timer.setInterval(500)
        self._vasito_llena_blink_timer.timeout.connect(
            lambda: self.setText("__VASITO_LLENA_TICK__")
        )
        # ── Timer parpadeo CAROLA SE LE ACABA EL VASITO (400 ms) — rojo ↔ morado
        self._vasito_vacia_blink_timer = QTimer(self)
        self._vasito_vacia_blink_timer.setInterval(400)
        self._vasito_vacia_blink_timer.timeout.connect(
            lambda: self.setText("__VASITO_VACIA_TICK__")
        )
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)

    # ── API compatible con QLabel ─────────────────────────────────────────────
    def _stop_custom_blink_timers(self):
        """Detiene todos los timers de parpadeo personalizados (evita parpadeo fantasma)."""
        for attr in ("_sirvio_blink_timer", "_arrojo_blink_timer",
                     "_transdig_blink_timer", "_error_carola_blink_timer",
                     "_veloz_ok_blink_timer", "_vasito_llena_blink_timer",
                     "_vasito_vacia_blink_timer"):
            t = getattr(self, attr, None)
            if t is not None:
                t.stop()

    def setText(self, msg: str):
        # Detener timers de parpadeo personalizados al recibir cualquier mensaje
        # nuevo que no sea un tick propio (evita parpadeo residual entre estados).
        _is_tick = msg in ("__CAROLA_SIRVIO_TICK__", "__CAROLA_ARROJO_TICK__",
                           "__TRANSDIGITALIZADOR_TICK__", "__ERROR_CAROLA_TICK__",
                           "__CAROLA_VELOZ_OK_TICK__",
                           "__VASITO_LLENA_TICK__", "__VASITO_VACIA_TICK__")
        if not _is_tick:
            self._stop_custom_blink_timers()
        if msg == "__CAROLALDHIRA_ACTIVA__":
            self._msg   = "LORITO EN ESCENA!!"
            self._level = "activa"
            self.update()
            return
        if msg.startswith("__CAROLAMOTION_SCANNING_REV__"):
            # Mensaje especial reversa: "CAROLAMOTION SCANNING MORPHING" + factor, en cyan
            factor = msg[len("__CAROLAMOTION_SCANNING_REV__"):]
            self._msg   = f"CAROLAMOTION SCANNING MORPHING  {factor}"
            self._level = "carolamotion_rev"
        elif msg.startswith("__CAROLAMOTION_SCANNING__"):
            # Mensaje especial adelante: "CAROLAMOTION SCANNING MORPHING" + factor, en amarillo
            factor = msg[len("__CAROLAMOTION_SCANNING__"):]
            self._msg   = f"CAROLAMOTION SCANNING MORPHING  {factor}"
            self._level = "carolamotion"
        elif msg.startswith("__CAROLAMOTION_SPEED__"):
            # Mensaje especial velocidad: púrpura intenso
            text = msg[len("__CAROLAMOTION_SPEED__"):]
            self._msg   = text
            self._level = "speed_purple"
        elif msg.startswith("__EXPORT_PREPARING__"):
            # Mensaje pre-export (lectura/resampleo): rosa intenso (deep pink)
            # Reemplaza el verde genérico anterior — indica que Carola & Aldhira
            # están leyendo el audio y preparando el pipeline de exportación.
            text = msg[len("__EXPORT_PREPARING__"):]
            self._msg   = text
            self._level = "export_preparing"
        elif msg.startswith("__CAROLAMOTION_EXPORT__"):
            # Mensaje especial exportando: celeste
            text = msg[len("__CAROLAMOTION_EXPORT__"):]
            self._msg   = text
            self._level = "export_cyan"
        elif msg.startswith("__EXPORT_WAV__"):
            # CAROLALDHIRA EXPORTANDO WAV — blanco
            text = msg[len("__EXPORT_WAV__"):]
            self._msg   = text
            self._level = "export_wav"
        elif msg.startswith("__EXPORT_FLAC__"):
            # CAROLALDHIRA EXPORTANDO FLAC — turquesa
            text = msg[len("__EXPORT_FLAC__"):]
            self._msg   = text
            self._level = "export_flac"
        elif msg.startswith("__EXPORT_OGG__"):
            # CAROLALDHIRA EXPORTANDO OGG VORBIS — marrón claro
            text = msg[len("__EXPORT_OGG__"):]
            self._msg   = text
            self._level = "export_ogg"
        elif msg.startswith("__EXPORT_WV__"):
            # CAROLALDHIRA EXPORTANDO WAVEPACK — gris brillante
            text = msg[len("__EXPORT_WV__"):]
            self._msg   = text
            self._level = "export_wv"
        elif msg == "__STREAM_SLEEP__":
            # CAROLACAPTURE SE DURMIÓ: parpadeo rosa intenso ↔ rojo intenso
            self._msg   = "QUE LORO TAN VAGO 🦥"
            self._level = "stream_sleep"
            self._sleep_blink_phase = False   # arranca en rosa intenso
        elif msg == "__STREAM_SLEEP_TICK__":
            self._sleep_blink_phase = not self._sleep_blink_phase
            self.update()
            return
        elif msg.startswith("__EXPORT_VALIDATING__"):
            # CAROLA ESTÁ APROBANDO: parpadeo celeste brillante ↔ verde claro
            text = msg[len("__EXPORT_VALIDATING__"):]
            self._msg   = text
            self._level = "export_validating"
            self._validating_blink_phase = False   # arranca en celeste
        elif msg == "__EXPORT_VALIDATING_TICK__":
            self._validating_blink_phase = not self._validating_blink_phase
            self.update()
            return
        elif msg == "__EXPORT_VALIDATING_START__":
            # FIX-VALIDATING-TIMER (v0.22.09): getattr defensivo por si el timer
            # aún no fue creado en algún path de instanciación parcial.
            _t = getattr(self, "_export_validating_blink_timer", None)
            if _t is not None:
                _t.start()
            self.update()
            return
        elif msg == "__EXPORT_VALIDATING_STOP__":
            _t = getattr(self, "_export_validating_blink_timer", None)
            if _t is not None:
                _t.stop()
            self.update()
            return
        elif msg.startswith("__EXPORT_CHECKSUM__"):
            # CAROLALDHIRA CHECKSUM: blanco
            text = msg[len("__EXPORT_CHECKSUM__"):]
            self._msg   = text
            self._level = "export_wav"       # reutiliza el nivel blanco existente
        elif msg.startswith("__EXPORT_SAVED__"):
            # CAROLA SURONDÚN: verde intenso
            text = msg[len("__EXPORT_SAVED__"):]
            self._msg   = text
            self._level = "export_saved"
        elif msg.startswith("__EXPORT_DESTROYED__"):
            # CAROLALDHIRA DESTRUIDA: rojo brillante
            text = msg[len("__EXPORT_DESTROYED__"):]
            self._msg   = text
            self._level = "export_destroyed"
        elif msg == "__NORM_BLINK_ON__":
            self._norm_visible = True
            self.update()
            return
        elif msg == "__NORM_BLINK_OFF__":
            self._norm_visible = False
            self.update()
            return
        elif msg == "__NORM_BLINK_TICK__":
            self._norm_blink_state = not self._norm_blink_state
            self.update()
            return
        elif msg == "__BUSYCHAN_PAUSE__":
            # Pausa física (btn_pause / tecla P): muestra "BUSYCHAN" en gris parpadeante.
            # NO se emite desde la auto-pausa por silencio (que usa __CAROLA_WAITING__).
            self._msg   = "BUSYCHAN"
            self._level = "busychan"
            self._cafe_blink_state = True
            self.update()
            return
        elif msg == "__BUSYCHAN_TICK__":
            # Tick del timer de pausa física — alterna visibilidad del texto BUSYCHAN.
            self._cafe_blink_state = not self._cafe_blink_state
            self.update()
            return
        elif msg == "__PAUSE_CAFE__":
            self._msg   = "LORITO VA POR UN CAFE"
            self._level = "pausa_cafe"
            self._cafe_blink_state = True
            self.update()
            return
        elif msg == "__PAUSE_CAFE_TICK__":
            self._cafe_blink_state = not self._cafe_blink_state
            self.update()
            return
        elif msg == "__CAROLA_WAITING__":
            # Auto-pausa por silencio: rosado intenso parpadeante.
            self._msg   = "AQUI ME DETENGO PARA ESPERARTE 🦜"
            self._level = "carola_waiting"
            self._cafe_blink_state = True
            self.update()
            return
        elif msg == "__FLUSH_BLINK_TICK__":
            self._flush_blink_state = not self._flush_blink_state
            self.update()
            return
        elif msg.startswith("__CAROLA_CRONICA__"):
            # Drift crónico v0.20: extraer valor de drift del mensaje,
            # establecer nivel especial con parpadeo amarillo/rojo alternado.
            # El símbolo ⚠ se preserva en el render (paintEvent lo añade siempre).
            try:
                drift_val = float(msg[len("__CAROLA_CRONICA__"):])
            except (ValueError, IndexError):
                drift_val = 0.0
            self._cronica_drift_ms = drift_val
            self._cronica_blink_phase = False   # reset al amarillo al activar
            self._msg   = f"⚠ LORITO EN PERDIDA FUERTE ({drift_val:+.0f}ms) SEÑAL BASURA"
            self._level = "carola_cronica"
        elif msg.startswith("__DRIFT_FRAMES_WARN__"):
            # CAROLA DELICADA: parpadeo verde brillante ↔ color original rojo-error.
            # El % de pérdida se extrae del sufijo numérico del mensaje.
            try:
                pct_val = float(msg[len("__DRIFT_FRAMES_WARN__"):])
            except (ValueError, IndexError):
                pct_val = 0.0
            self._drift_frames_pct   = pct_val
            self._drift_frames_phase = False   # reset a verde brillante al activar
            self._msg   = f"⚠ LORITO EN PERDIDA LEVE ({pct_val:.1f}% factor de pérdida) CUIDADITO!"
            self._level = "drift_frames_warn"
        elif msg == "__DRIFT_FRAMES_TICK__":
            # Tick de parpadeo: alterna fase verde brillante ↔ color error original
            self._drift_frames_phase = not self._drift_frames_phase
            self.update()
            return
        # ── CAROLA SIRVIÓ TU PLATO ────────────────────────────────────────────
        elif msg.startswith("__CAROLA_SIRVIO__"):
            dur_hms = msg[len("__CAROLA_SIRVIO__"):]
            self._msg   = f"LORITO SE POSÓ EN LA JAULA{(' ' + dur_hms) if dur_hms else ''}"
            self._level = "carola_sirvio"
            self._sirvio_blink_phase = False
            self._sirvio_blink_timer.start()
        elif msg == "__CAROLA_SIRVIO_TICK__":
            self._sirvio_blink_phase = not self._sirvio_blink_phase
            self.update()
            return
        # ── CAROLA ARROJO EL PLATO A LA BASURA ───────────────────────────────
        elif msg.startswith("__CAROLA_ARROJO__"):
            motivo = msg[len("__CAROLA_ARROJO__"):]
            self._msg   = f"LORITO SE VOLÓ DE LA JAULA {motivo}"
            self._level = "carola_arrojo"
            self._arrojo_blink_phase = False
            self._arrojo_blink_timer.start()
        elif msg == "__CAROLA_ARROJO_TICK__":
            self._arrojo_blink_phase = not self._arrojo_blink_phase
            self.update()
            return
        # ── TRANSDIGITALIZADOR IDIOTA ─────────────────────────────────────────
        elif msg == "__TRANSDIGITALIZADOR_IDIOTA__":
            self._msg   = "PERDISTE ALGO BUENO, EN FIN..."
            self._level = "transdigitalizador"
            self._transdig_blink_phase = False
            self._transdig_blink_timer.start()
        elif msg == "__TRANSDIGITALIZADOR_TICK__":
            self._transdig_blink_phase = not self._transdig_blink_phase
            self.update()
            return
        # ── ERROR CAROLA (OYE NO!! / ERROR ffmpeg / SI TODO ESTABA BIEN) ─────
        elif msg.startswith("__ERROR_CAROLA__"):
            text = msg[len("__ERROR_CAROLA__"):]
            self._msg   = text
            self._level = "error_carola"
            self._error_carola_blink_phase = False
            self._error_carola_blink_timer.start()
        elif msg == "__ERROR_CAROLA_TICK__":
            self._error_carola_blink_phase = not self._error_carola_blink_phase
            self.update()
            return
        # ── CAROLA VELOZ PERFECTA (RT OK) — crema pastel ↔ verde intenso ─────
        elif msg.startswith("__CAROLA_VELOZ_OK__"):
            text = msg[len("__CAROLA_VELOZ_OK__"):]
            self._msg   = text
            self._level = "carola_veloz_ok"
            self._veloz_ok_blink_phase = False
            self._veloz_ok_blink_timer.start()
        elif msg == "__CAROLA_VELOZ_OK_TICK__":
            self._veloz_ok_blink_phase = not self._veloz_ok_blink_phase
            self.update()
            return
        # ── CAROLA VELOZ INUTIL (RT con avisos) — color warn original ─────────
        elif msg.startswith("__CAROLA_VELOZ_WARN__"):
            text = msg[len("__CAROLA_VELOZ_WARN__"):]
            self._msg   = text
            self._level = "warn"   # mantiene color original de advertencia
        # ── CAROLA LLEVA EL VASITO (RBA llenando) — verde ↔ morado ───────────
        elif msg == "__VASITO_LLENA__":
            self._msg   = "LORITO CARGANDO LA JARRA"
            self._level = "vasito_llena"
            self._vasito_llena_blink_phase = False
            self._vasito_llena_blink_timer.start()
        elif msg == "__VASITO_LLENA_TICK__":
            self._vasito_llena_blink_phase = not self._vasito_llena_blink_phase
            self.update()
            return
        # ── CAROLA SE LE ACABA EL VASITO (RBA vaciando) — rojo ↔ morado ──────
        elif msg == "__VASITO_VACIA__":
            self._msg   = "LORITO VA AVENTANDO LA JARRA"
            self._level = "vasito_vacia"
            self._vasito_vacia_blink_phase = False
            self._vasito_vacia_blink_timer.start()
        elif msg == "__VASITO_VACIA_TICK__":
            self._vasito_vacia_blink_phase = not self._vasito_vacia_blink_phase
            self.update()
            return
        else:
            self._msg   = msg
            # CAROLALDHIRA CAPTURANDO → nivel especial rojo encendido
            if "LORITO VA GRABANDO" in msg.upper():
                self._level = "rec_capturing"
            # CAROLALDHIRA VACIANTE → nivel azul intenso parpadeante
            elif "VACIANTE" in msg.upper() or "VACIANDO" in msg.upper():
                self._level = "flush_blue"
            else:
                self._level = self._classify(msg)
        self.update()

    def setAux(self, txt: str):
        """Actualiza telemetría auxiliar. Llamado desde GUI timer (_tick) —
        siempre en el main thread. update() seguro para Wayland SHM."""
        if len(self._msg) > 45:
            self._aux = ""
        else:
            self._aux = txt
        self.update()   # main thread via _bridge.status_msg signal (queued)

    def text(self) -> str:
        return self._msg

    def tickCassette(self, angle: float, mode, blink_state: bool,
                     reverse: bool = False):
        """
        Llamado desde el timer de animación en LoritoAldhiroStudio (~24 fps).
        mode: None | "rec" | "drift" | "play" | "speed" | "morph_fwd" | "morph_rev"
        reverse: True cuando el morphing está en modo reversa (invierte giro)
        """
        changed = (self._cassette_angle   != angle or
                   self._cassette_mode    != mode  or
                   self._cassette_blink   != blink_state or
                   self._cassette_reverse != reverse)
        self._cassette_angle   = angle
        self._cassette_mode    = mode
        # v0.20: cuando blink_state flipa en modo drift → alternar fase amarillo/rojo
        if mode == "drift" and blink_state != self._cassette_blink:
            self._cronica_blink_phase = not self._cronica_blink_phase
        self._cassette_blink   = blink_state
        self._cassette_reverse = reverse
        if changed:
            self.update()

    # ── Clasificación de nivel ────────────────────────────────────────────────
    @staticmethod
    def _classify(msg: str) -> str:
        upper = msg.upper()
        for k in StatusDisplay._ERROR_KEYS:
            if k in upper:
                return "error"
        for k in StatusDisplay._WARN_KEYS:
            if k in upper:
                return "warn"
        for k in StatusDisplay._OK_KEYS:
            if k in upper:
                return "ok"
        return "idle"

    # ── Render ────────────────────────────────────────────────────────────────
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        br = THEME["bright"]

        # Metaloric Panel (0.11.008): ventana HUD del SVG de la usuaria; los
        # tintes y colores de mensaje (ok/aviso/error) se conservan.
        from lorito_aldhiro.frontend.widgets.lorito_svg_panels import paint_metaloric_window
        paint_metaloric_window(p, w, h)

        # Tinte de nivel (muy suave, sobre el fondo)
        level_tint = {
            "error":           QColor(220,  40,  40, 22),
            "warn":            QColor(220, 130,  30, 18),
            "ok":              QColor( 40, 180,  80, 14),
            "idle":            QColor(  0,   0,   0,  0),
            "activa":          QColor(  0,   0,   0,  0),
            "rec_capturing":   QColor(220,  20,  20, 22),
            "carolamotion":    QColor(200, 200,   0, 18),
            "carolamotion_rev":QColor(  0, 180, 255, 18),
            "speed_purple":    QColor(140,   0, 255, 18),
            "export_cyan":     QColor(  0, 200, 220, 18),
            "export_wav":      QColor(255, 255, 255, 10),
            "export_flac":     QColor(  0, 210, 200, 18),
            "export_ogg":      QColor(180, 130,  80, 18),
            "export_wv":       QColor(200, 200, 200, 14),
            "export_preparing":QColor(255,  20, 147, 22),   # deep pink tint (pre-export)
            "busychan":        QColor(200, 200, 200, 18) if self._cafe_blink_state else QColor(0, 0, 0, 0),
            "pausa_cafe":      QColor(255, 220,   0, 18),
            "flush_blue":      QColor(  0,  80, 255, 22),
            # v0.20 — Drift Crónico: tinte alternante amarillo/rojo (se actualiza abajo)
            "carola_cronica":  QColor(255, 200,   0, 20) if not self._cronica_blink_phase
                               else QColor(220,  20,  20, 25),
            # CAROLA DELICADA: tinte verde brillante ↔ tinte rojo-error
            "drift_frames_warn": QColor(  0, 255,  80, 22) if not self._drift_frames_phase
                                 else QColor(255, 255, 255, 18),
            # CAROLA ESPERANDO (auto-pausa silencio): rosado intenso parpadeante
            "carola_waiting":  QColor(255,  20, 147, 30) if self._cafe_blink_state
                               else QColor(  0,   0,   0,  0),
            # CAROLACAPTURE SE DURMIÓ: rosa intenso ↔ rojo intenso (parpadeo)
            "stream_sleep":    QColor(255,  20, 147, 28) if not self._sleep_blink_phase
                               else QColor(200,  10,  10, 28),
            # CAROLA ESTÁ APROBANDO: celeste ↔ verde claro (parpadeo)
            "export_validating": QColor(  0, 200, 230, 20) if not self._validating_blink_phase
                                 else QColor( 80, 230,  80, 20),
            # CAROLA SURONDÚN: verde intenso
            "export_saved":    QColor( 30, 200,  60, 20),
            # CAROLALDHIRA DESTRUIDA: rojo brillante
            "export_destroyed": QColor(255,  20,  20, 28),
            # CAROLA SIRVIÓ TU PLATO: rosa intenso ↔ turquesa intenso (parpadeo)
            "carola_sirvio":   QColor(255,  20, 147, 28) if not self._sirvio_blink_phase
                               else QColor(  0, 210, 210, 28),
            # CAROLA ARROJO EL PLATO: gris ↔ rojo intenso (parpadeo)
            "carola_arrojo":   QColor(160, 160, 160, 18) if not self._arrojo_blink_phase
                               else QColor(220,  20,  20, 28),
            # TRANSDIGITALIZADOR IDIOTA: naranja intenso ↔ rosa intenso (parpadeo)
            "transdigitalizador": QColor(255, 100,   0, 28) if not self._transdig_blink_phase
                                  else QColor(255,  20, 147, 28),
            # ERROR CAROLA: rojo intenso ↔ magenta intenso (parpadeo)
            "error_carola":    QColor(255,  20,  20, 28) if not self._error_carola_blink_phase
                               else QColor(255,   0, 180, 28),
            # CAROLA VELOZ PERFECTA: crema pastel ↔ verde intenso (parpadeo)
            "carola_veloz_ok": QColor(255, 245, 210, 22) if not self._veloz_ok_blink_phase
                               else QColor( 20, 200,  60, 22),
            # CAROLA LLEVA EL VASITO: verde intenso ↔ morado (parpadeo)
            "vasito_llena":    QColor( 20, 200,  60, 22) if not self._vasito_llena_blink_phase
                               else QColor(140,   0, 200, 22),
            # CAROLA SE LE ACABA EL VASITO: rojo intenso ↔ morado (parpadeo)
            "vasito_vacia":    QColor(220,  20,  20, 28) if not self._vasito_vacia_blink_phase
                               else QColor(140,   0, 200, 28),
        }.get(self._level, QColor(0,0,0,0))
        if level_tint.alpha() > 0:
            p.setBrush(level_tint)
            p.drawRoundedRect(0, 0, w, h, 6, 6)

        # Color del texto según nivel
        txt_color = {
            "error":           QColor(255,  70,  60, 230),
            "warn":            QColor(255, 160,  50, 220),
            "ok":              QColor( 80, 210, 100, 200),
            "idle":            QColor(int(br[0]), int(br[1]), int(br[2]), 90),
            "activa":          QColor(255, 255, 255, 220),   # blanco puro — reposo completo
            "rec_capturing":   QColor(255,  25,  25, 245),   # rojo encendido — grabando
            "carolamotion":    QColor(255, 230,   0, 240),   # amarillo intenso
            "carolamotion_rev":QColor(  0, 220, 255, 240),   # cyan intenso (reversa)
            "speed_purple":    QColor(180,   0, 255, 240),   # púrpura intenso (velocidad)
            "export_cyan":     QColor(  0, 210, 235, 240),   # celeste (exportando)
            "export_wav":      QColor(255, 255, 255, 240),   # blanco (WAV)
            "export_flac":     QColor(  0, 210, 200, 240),   # turquesa (FLAC)
            "export_ogg":      QColor(188, 143,  94, 240),   # marrón claro (OGG)
            "export_wv":       QColor(210, 215, 220, 240),   # gris brillante (WV)
            "export_preparing":QColor(255,  20, 147, 255),   # deep pink intenso (pre-export CAROLA & ALDHIRA)
            "busychan":        QColor(200, 200, 200, 245) if self._cafe_blink_state else QColor(200, 200, 200, 0),   # gris parpadeante — pausa física
            "pausa_cafe":      QColor(255, 230,   0, 245),   # amarillo brillante (pausa)
            "flush_blue":      QColor( 20, 100, 255, 245),   # azul intenso parpadeante (vaciado)
            # v0.20 — Drift Crónico: amarillo o rojo intenso según fase de parpadeo
            "carola_cronica":  QColor(255, 230,   0, 255) if not self._cronica_blink_phase
                               else QColor(255,  30,  30, 255),
            # CAROLA DELICADA: verde brillante (#00FF50) ↔ rojo-error original
            "drift_frames_warn": QColor(  0, 255,  80, 255) if not self._drift_frames_phase
                                 else QColor(255, 255, 255, 245),
            # CAROLA ESPERANDO: rosado intenso parpadeante ↔ transparente
            "carola_waiting":  QColor(255,  20, 147, 255) if self._cafe_blink_state
                               else QColor(255,  20, 147,  0),
            # CAROLACAPTURE SE DURMIÓ: rosa intenso (#FF1493) ↔ rojo intenso (#FF0020)
            "stream_sleep":    QColor(255,  20, 147, 255) if not self._sleep_blink_phase
                               else QColor(255,   0,  32, 255),
            # CAROLA ESTÁ APROBANDO: celeste brillante (#00D4FF) ↔ verde claro (#80FF80)
            "export_validating": QColor(  0, 212, 255, 255) if not self._validating_blink_phase
                                 else QColor(128, 255, 128, 255),
            # CAROLA SURONDÚN: verde intenso (#00CC44)
            "export_saved":    QColor(  0, 204,  68, 255),
            # CAROLALDHIRA DESTRUIDA: rojo brillante (#FF2020)
            "export_destroyed": QColor(255,  32,  32, 255),
            # CAROLA SIRVIÓ TU PLATO: rosa intenso (#FF1493) ↔ turquesa intenso (#00D4D4)
            "carola_sirvio":   QColor(255,  20, 147, 255) if not self._sirvio_blink_phase
                               else QColor(  0, 212, 212, 255),
            # CAROLA ARROJO EL PLATO: gris (#A0A0A0) ↔ rojo intenso (#FF1414)
            "carola_arrojo":   QColor(160, 160, 160, 220) if not self._arrojo_blink_phase
                               else QColor(255,  20,  20, 255),
            # TRANSDIGITALIZADOR IDIOTA: naranja intenso (#FF6400) ↔ rosa intenso (#FF1493)
            "transdigitalizador": QColor(255, 100,   0, 255) if not self._transdig_blink_phase
                                  else QColor(255,  20, 147, 255),
            # ERROR CAROLA: rojo intenso (#FF1414) ↔ magenta intenso (#FF00B4)
            "error_carola":    QColor(255,  20,  20, 255) if not self._error_carola_blink_phase
                               else QColor(255,   0, 180, 255),
            # CAROLA VELOZ PERFECTA: crema pastel (#FFF5D2) ↔ verde intenso (#14C83C)
            "carola_veloz_ok": QColor(255, 245, 210, 255) if not self._veloz_ok_blink_phase
                               else QColor( 20, 200,  60, 255),
            # CAROLA LLEVA EL VASITO: verde intenso (#14C83C) ↔ morado (#8C00C8)
            "vasito_llena":    QColor( 20, 200,  60, 255) if not self._vasito_llena_blink_phase
                               else QColor(140,   0, 200, 255),
            # CAROLA SE LE ACABA EL VASITO: rojo intenso (#FF1414) ↔ morado (#8C00C8)
            "vasito_vacia":    QColor(220,  20,  20, 255) if not self._vasito_vacia_blink_phase
                               else QColor(140,   0, 200, 255),
        }.get(self._level, QColor(int(br[0]), int(br[1]), int(br[2]), 90))

        # ── Animación de cassette (hubs giratorios) ───────────────────────────
        # Presente en modos: rec (rojo), drift (color warn + parpadeo), play (color ok),
        #                    speed (púrpura), morph_fwd (amarillo), morph_rev (cyan)
        cass_color = None
        cass_reverse = getattr(self, "_cassette_reverse", False)
        if self._cassette_mode == "rec":
            cass_color = QColor(255, 25, 25, 245)           # rojo encendido
        elif self._cassette_mode == "drift":
            if self._cassette_blink:
                cass_color = QColor(255, 160, 50, 230)      # naranja-warn (idéntico al texto drift)
            # blink off → no dibuja (efecto parpadeo)
        elif self._cassette_mode == "play":
            cass_color = QColor(80, 210, 100, 210)          # verde ok (idéntico al texto play)
        elif self._cassette_mode == "speed":
            cass_color = QColor(180, 0, 255, 240)           # púrpura intenso — idéntico a speed_purple
        elif self._cassette_mode == "morph_fwd":
            cass_color = QColor(255, 230, 0, 240)           # amarillo intenso — idéntico a carolamotion
        elif self._cassette_mode == "morph_rev":
            cass_color = QColor(0, 220, 255, 240)           # cyan intenso — idéntico a carolamotion_rev

        # Métricas de los hubs: dos bobinas de cassette con radios (spokes)
        CASS_R   = 7      # radio exterior del aro (px)
        CASS_GAP = 5      # separación entre los dos hubs
        CASS_PAD = 6      # margen izquierdo antes del primer hub
        cass_total_w = CASS_PAD + CASS_R*2 + CASS_GAP + CASS_R*2 + 4

        def _draw_hub(painter, cx, cy, angle_deg, color):
            """Dibuja un hub de cassette realista: aro exterior + 3 radios + cubo central."""
            N_SPOKES  = 3          # tres radios — aspecto cassette clásico
            outer_r   = float(CASS_R)
            spoke_r   = outer_r * 0.52   # los radios llegan al 52% del radio exterior
            hub_r     = outer_r * 0.26   # cubo central: 26% del radio exterior
            spoke_w   = 1.1              # grosor del rayo (px)

            cr, cg, cb = color.red(), color.green(), color.blue()

            # Aro exterior
            painter.setPen(QPen(color, 1.0))
            painter.setBrush(QColor(cr, cg, cb, 28))
            painter.drawEllipse(QPointF(cx, cy), outer_r, outer_r)

            # Aro interior tenue (surco entre radios y aro)
            pen_inner = QPen(QColor(cr, cg, cb, 55), 0.5)
            painter.setPen(pen_inner)
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(QPointF(cx, cy), spoke_r + 1.0, spoke_r + 1.0)

            # Radios (spokes) — se rotan con angle_deg
            pen_spoke = QPen(QColor(cr, cg, cb, 210), spoke_w)
            pen_spoke.setCapStyle(Qt.RoundCap)
            painter.setPen(pen_spoke)
            for i in range(N_SPOKES):
                a = _math.radians(angle_deg + i * 360.0 / N_SPOKES)
                x1 = cx + hub_r  * _math.cos(a)
                y1 = cy + hub_r  * _math.sin(a)
                x2 = cx + spoke_r * _math.cos(a)
                y2 = cy + spoke_r * _math.sin(a)
                painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))

            # Cubo central sólido
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(cr, cg, cb, 200))
            painter.drawEllipse(QPointF(cx, cy), hub_r, hub_r)

            # Punto de eje
            painter.setBrush(QColor(cr, cg, cb, 255))
            painter.drawEllipse(QPointF(cx, cy), 1.1, 1.1)

        # Hubs visibles en todos los modos EXCEPTO grabación (rec/drift)
        _show_hubs = (cass_color is not None and
                      self._cassette_mode not in ("rec", "drift"))

        if _show_hubs:
            cy_hub = h // 2
            cx1 = CASS_PAD + CASS_R
            cx2 = cx1 + CASS_R + CASS_GAP + CASS_R
            # Dirección de giro: normal -> hub1 horario, hub2 antihorario
            # En reversa (morph_rev): ambos invierten su sentido
            sign = -1.0 if cass_reverse else 1.0
            _draw_hub(p, cx1, cy_hub,  sign * self._cassette_angle, cass_color)
            _draw_hub(p, cx2, cy_hub, -sign * self._cassette_angle, cass_color)
            # Linea de cinta tangente inferior entre los dos hubs
            _cr = cass_color.red(); _cg = cass_color.green(); _cb = cass_color.blue()
            pen_tape = QPen(QColor(_cr, _cg, _cb, 140), 1.0)
            pen_tape.setCapStyle(Qt.RoundCap)
            p.setPen(pen_tape)
            p.drawLine(QPointF(cx1, cy_hub + CASS_R), QPointF(cx2, cy_hub + CASS_R))
            text_left = cass_total_w
        else:
            text_left = 8

        # ── Layout horizontal: cassette+mensaje izquierda │ telemetría derecha ──
        # La telemetría ocupa una columna derecha fija (~45% del ancho) para no
        # interferir con la animación de cassette ni con el mensaje principal.
        has_aux = bool(self._aux and not self._norm_visible)

        # Cuando hay telemetría la columna derecha ocupa ~45% del ancho total.
        # La columna izquierda (cassette + mensaje) ocupa el resto.
        TEL_W = (w * 45 // 100) if has_aux else 0   # ancho columna telemetría
        TEL_PAD = 6                                   # margen interno derecho
        # Separador vertical suave entre las dos columnas
        if has_aux:
            sep_x = w - TEL_W - 1
            p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 22), 1))
            p.drawLine(sep_x, 4, sep_x, h - 4)

        # Texto principal — columna izquierda, una sola fila, ancho total disponible
        fnt = font_leyendas(size=1)
        fnt.setPixelSize(9)
        fnt.setLetterSpacing(QFont.AbsoluteSpacing, 1)
        p.setFont(fnt)
        p.setPen(txt_color)
        msg_w = w - text_left - TEL_W - 10
        msg_rect = QRect(text_left, 0, msg_w, h)
        _skip_text = (
            (self._level == "busychan"   and not self._cafe_blink_state) or
            (self._level == "pausa_cafe" and not self._cafe_blink_state) or
            (self._level == "flush_blue" and not self._flush_blink_state)
            # carola_cronica: texto SIEMPRE visible — el parpadeo es de color, no de visibilidad
        )
        if not _skip_text:
            # ── Renderizado con emojis del mismo tamaño que el texto ─────────
            # Qt6 renderiza emojis con la fuente de color del sistema, que puede
            # ser mayor que el pixelSize de la fuente de texto, haciendo que los
            # emojis desborden el rect. Solución: dibujar con un QRect acotado
            # estrictamente a la altura del pixelSize + margen, y forzar
            # TextSingleLine para que Qt no expanda el área de dibujo.
            _txt_h  = 11   # altura real del área de texto (pixelSize 9 + margen 2)
            _txt_y  = (h - _txt_h) // 2
            _emoji_rect = QRect(text_left, _txt_y, msg_w, _txt_h)
            p.drawText(_emoji_rect,
                       Qt.AlignLeft | Qt.AlignVCenter | Qt.TextSingleLine,
                       self._msg)

        # Telemetría — columna derecha, fuente monoespaciada pequeña, alineada a la derecha
        if has_aux:
            aux_color = QColor(180, 210, 255, 200)   # azul-blanco suave
            fnt_aux = QFont("Courier New", 1)
            fnt_aux.setPixelSize(7)
            fnt_aux.setBold(False)
            fnt_aux.setLetterSpacing(QFont.AbsoluteSpacing, 0.3)
            p.setFont(fnt_aux)
            p.setPen(aux_color)
            aux_rect = QRect(w - TEL_W + TEL_PAD, 0, TEL_W - TEL_PAD - 6, h)
            p.drawText(aux_rect, Qt.AlignLeft | Qt.AlignVCenter, self._aux)

        # h_top queda igual a h en el nuevo layout (una sola fila)
        h_top = h

        # Borde idéntico al de WaveformDisplay
        p.setPen(QPen(QColor(int(br[0]), int(br[1]), int(br[2]), 28), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(0, 0, w - 1, h - 1, 6, 6)

        # Leyenda de normalizacion parpadeante (rosa intensa) — fila superior
        if self._norm_visible and self._norm_blink_state:
            fnt_n = font_leyendas(size=1)
            fnt_n.setPixelSize(8)
            fnt_n.setLetterSpacing(QFont.AbsoluteSpacing, 2)
            fnt_n.setBold(True)
            p.setFont(fnt_n)
            p.setPen(QColor(255, 20, 147, 255))
            norm_rect = QRect(w - 260, 0, 256, h_top)
            p.drawText(norm_rect, Qt.AlignRight | Qt.AlignVCenter,
                       "SONIDO ESTEREOFONICO NORMALIZADO")

        p.end()
