# TEST_REPORT_0.11.007

**743/743 pruebas, 0 fallos**, en plano (unos 149 s) y con
`-W error::ResourceWarning` (unos 138 s, 0 avisos). Hay 2 skips:

- árbol fuente de CRAC ausente (preexistente);
- permisos de directorio ignorados por root.

**Release de las cinco Órdenes Golden de ingeniería sobre 0.11.001**:
Captura, Exportación, DSP PREVI/NR, Instrumentación/ITL y Scrubs/Velocista/
Seek. Ver `gaps/GAP-076.md` … `gaps/GAP-081.md` y
`ORDENES_GOLDEN_0_11_ESTADO.md`.

## Entorno

- CPython 3.13.16 (Linux x86_64, con GIL).
- numpy 2.5.4, scipy 1.18.1, numba 0.68.0, soundfile 0.14.0 y
  ffmpeg 6.1.1 (`requirements.lock.txt`).
- PySide6 y sounddevice sustituidos por stubs funcionales, por diseño de
  la batería.

## Baterías Golden nuevas

| Archivo | Casos | Orden |
|---|---|---|
| `tests/test_capture_golden.py` | 27 | Captura T-01…T-10 |
| `tests/test_archival_reason_codes_golden.py` | 6 | Captura CAP-012 |
| `tests/test_export_golden.py` | 33 | Exportación EX-T01…T15 |
| `tests/test_dsp_golden.py` | 18 | DSP PREVI/NR |
| `tests/test_ui_itl_golden.py` | 30 | Instrumentación/ITL |
| `tests/test_transport_golden.py` | 18 | Scrubs SMV-T01…T10 |
| `tests/test_resample_continuity*.py` | 16 | Scrubs SMV-07/T01/T07/13 (reescritas) |

## Verificaciones adicionales

- `lorito_bootstrap.py` cargado con stubs: OK.
- Versión computada: `Lorito Aldhiro Alpha 0.11.007`.
- Bancos deterministas: `tools/bench_nr_fidelity.py` y
  `tools/bench_transport_discontinuity.py`.

## No ejecutable en este entorno

Soak de 50 h y de 8 h, loopback de hardware, comparación con CRAC 0.36,
escucha ciega, referencias Dolby/dbx, WCET con PortAudio real y build
free-threaded. **Ninguna orden se declara GOLDEN.**
