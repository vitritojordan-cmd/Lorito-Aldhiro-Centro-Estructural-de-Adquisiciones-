# TEST_REPORT_0.11.008

**756/756 pruebas, 0 fallos**, en plano (unos 154 s) y con
`-W error::ResourceWarning` (unos 146 s, 0 avisos). Hay 3 skips:

- árbol fuente de CRAC ausente (preexistente);
- permisos de directorio ignorados por root;
- `RealRender`: requiere PySide6/QtSvg reales. Ejecutado aparte en un
  entorno con PySide6 6.12: **OK**.

**Release de las pieles SVG del lienzo** (madera, Metaloric Panel, LCD
Display, Panascrub, vúmetros) y retiro de la madera pintada con Qt, que
fallaba en cada repintado. Ver `gaps/GAP-082.md`.

## Pruebas nuevas o adaptadas en esta versión

| Prueba | Qué verifica |
|---|---|
| `tests/test_svg_skins.py` (12) | XML válido a varios tamaños, sin `<filter>` (QtSvg = SVG Tiny), gradientes resueltos, leyendas de Lorito, escala dBFS, geometría del vúmetro, retiro de `paint_wood_canvas` y del import de QPointF desde QtGui, render real con QtSvg |
| `tests/test_transport_golden.py::ConfirmationWhileRingFull` | regresión: los comandos aplicados con el ring lleno llegan a CONFIRMED |
| `tests/test_capture_engine_end_to_end.py` | camino sin pérdida a 2× tiempo real (antes 10×, que bajo carga saturaba el ring; la pérdida se declaraba correctamente) |

## Capturas (ventana real, PySide6 6.12, offscreen)

`saneamiento_0_11_008/capturas/`:

| Archivo | Contenido |
|---|---|
| `00_comparativa_antes_despues.png` | comparativa antes / después |
| `01_antes.png` | 0.11.007; requirió parchear en memoria el import de QPointF para poder capturarla |
| `02_despues_reposo.png` | 0.11.008 en reposo |
| `03_despues_actividad.png` | estado visual simulado: grabación, niveles, onda, scrubs, Dolby B, C-90 |
| `04`–`07` | detalle a 2×: vúmetros, LCD Display, Panascrub, Metaloric Panel |
| `08_lienzo_madera_svg.png` | lienzo de madera SVG completo |

Reproducibles con `tools/capturas/`.

## Verificaciones adicionales

- `lorito_bootstrap.py` cargado con stubs: OK.
- Versión computada: `Lorito Aldhiro Alpha 0.11.008`.
