"""
tests/_functional_sounddevice_output_stub.py — GAP-062.

Stub funcional de `sounddevice.OutputStream` — hermano del ya
existente `_functional_sounddevice_stub.py` (que solo cubre
`InputStream`, para `CaptureEngineV2`). Este cubre la mitad de
REPRODUCCIÓN: un hilo de fondo llama al callback real repetidamente,
igual que haría PortAudio de verdad (sin poder replicar su timing
exacto de sistema operativo, pero sí la mecánica real: callback pide
un bloque → el motor real lo rellena desde su pipeline de prefetch/
resampleo → el hilo de fondo lo captura).

Permite ejercitar `PlaybackEngine` (`lorito_playback_engine.py`) de
punta a punta con SUS PROPIOS hilos reales (`_prefetch`, `_bridge`, el
"driver" simulado de este stub) en este sandbox sin hardware de audio
— hasta GAP-062, `PlaybackEngine` (el motor de reproducción real, no
el Transport Core nuevo sin cablear) no tenía NINGÚN test que lo
instanciara y lo corriera de verdad; solo sus funciones de resampleo
puras se probaban en aislamiento.
"""

import threading
import time

import numpy as np


class _FakeOutputCallbackFlags:
    """Sustituto de `sounddevice.CallbackFlags` para el callback de
    salida — falsy por defecto (sin underflow real del stub; los
    underruns de `PlaybackEngine` se manifiestan en SU PROPIO
    `cb_state['underrun']`, no en este flag)."""
    def __init__(self):
        self.output_underflow = False

    def __bool__(self):
        return False


class CallbackStop(Exception):
    """Sustituto de `sounddevice.CallbackStop` — la excepción real que
    `PlaybackEngine._audio_cb` lanza para señalar fin de stream (EOF,
    generación obsoleta, mute). El hilo de fondo de este stub la
    captura exactamente como haría PortAudio: deja de llamar al
    callback y marca el stream inactivo."""
    pass


class FunctionalOutputStream:
    """Sustituto funcional de `sounddevice.OutputStream` — un hilo de
    fondo llama al callback real (`PlaybackEngine._audio_cb`)
    repetidamente con un buffer `outdata` real, y acumula lo que el
    motor escribió para que el test pueda inspeccionarlo (detectar
    NaN/Inf, silencio inesperado, etc.)."""

    def __init__(self, samplerate, channels, dtype, blocksize, callback,
                latency="low", callback_interval=0.0, capture_output=True,
                max_callbacks=None):
        self.samplerate = samplerate
        self.channels = channels
        self.blocksize = blocksize
        self.callback = callback
        self.callback_interval = callback_interval
        self.capture_output = capture_output
        self.max_callbacks = max_callbacks
        self.active = False
        self.callbacks_delivered = 0
        self.captured = []  # lista de arrays outdata (copias) si capture_output
        self._stop_flag = threading.Event()
        self._thread = None

    def _run(self):
        while not self._stop_flag.is_set():
            if self.max_callbacks is not None and self.callbacks_delivered >= self.max_callbacks:
                break
            outdata = np.zeros((self.blocksize, self.channels), dtype=np.float32)
            try:
                self.callback(outdata, self.blocksize, None, _FakeOutputCallbackFlags())
            except CallbackStop:
                break
            except Exception:
                break
            if self.capture_output:
                self.captured.append(outdata.copy())
            self.callbacks_delivered += 1
            if self.callback_interval > 0:
                time.sleep(self.callback_interval)
        self.active = False

    # ── API real de sounddevice.OutputStream usada por PlaybackEngine ──
    def __enter__(self):
        self.active = True
        self._stop_flag.clear()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="fake-portaudio-output")
        self._thread.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
        return False

    def stop(self):
        self._stop_flag.set()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
        self.active = False

    def close(self):
        pass


def install_functional_sounddevice_output_stub(existing_module=None, **stream_kwargs):
    """Instala (o extiende) el stub en `sys.modules['sounddevice']` con
    `OutputStream` y `CallbackStop` — complementa
    `install_functional_sounddevice_stub()` (que instala `InputStream`),
    para poder tener ambos a la vez si algún test necesitara los dos.
    `stream_kwargs` se reenvían a cada `OutputStream` creado (p. ej.
    `callback_interval=0.002` para simular un ritmo más real)."""
    import sys
    import types

    mod = existing_module if existing_module is not None else sys.modules.get("sounddevice")
    if mod is None or not isinstance(mod, types.ModuleType):
        mod = types.ModuleType("sounddevice")

    def _output_stream_factory(*args, **kwargs):
        merged = dict(stream_kwargs)
        merged.update(kwargs)
        return FunctionalOutputStream(*args, **merged)

    mod.OutputStream = _output_stream_factory
    mod.CallbackStop = CallbackStop
    if not hasattr(mod, "query_devices"):
        mod.query_devices = lambda *a, **k: []
    sys.modules["sounddevice"] = mod
    return mod
