"""
tests/_functional_sounddevice_stub.py — GAP-037, stub funcional de
`sounddevice.InputStream` — simula un stream de audio real: un hilo
de fondo genera bloques y llama al callback repetidamente, igual que
haría PortAudio de verdad (sin poder replicar su timing exacto a nivel
de sistema operativo, pero sí la mecánica real: callback→RBA→drain→
CED→disco, con datos y concurrencia reales, no simulados a mano).

Permite probar `CaptureEngineV2` de punta a punta en este sandbox sin
hardware de audio: iniciar captura, dejar correr N bloques, detener,
y verificar el resultado en disco — algo que hasta esta sesión se
consideraba bloqueado por "requiere hardware real".
"""

import threading
import time

import numpy as np


class _FakeCallbackFlags:
    """Sustituto de `sounddevice.CallbackFlags` — falsy por defecto
    (sin xruns), con `.input_overflow` para simular uno cuando se pide."""
    def __init__(self, input_overflow=False):
        self.input_overflow = input_overflow
        self._truthy = input_overflow

    def __bool__(self):
        return self._truthy


class FunctionalInputStream:
    """Sustituto funcional de `sounddevice.InputStream` — un hilo de
    fondo genera bloques de audio sintético y llama al callback real
    del motor de captura, tal como haría el driver de audio."""

    def __init__(self, samplerate, channels, dtype, blocksize, callback,
                latency="high", block_interval=0.0, n_blocks_before_death=None,
                seed=0):
        self.samplerate = samplerate
        self.channels = channels
        self.blocksize = blocksize
        self.callback = callback
        self.block_interval = block_interval
        self.n_blocks_before_death = n_blocks_before_death
        self._rng = np.random.default_rng(seed)
        self._stop_flag = threading.Event()
        self._thread = None
        self._blocks_delivered = 0
        self.died = False

    def start(self):
        self._stop_flag.clear()
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="fake-portaudio")
        self._thread.start()

    def _run(self):
        while not self._stop_flag.is_set():
            if (self.n_blocks_before_death is not None
                    and self._blocks_delivered >= self.n_blocks_before_death):
                self.died = True
                break
            indata = self._rng.uniform(
                -0.3, 0.3, size=(self.blocksize, self.channels)).astype(np.float32)
            status = _FakeCallbackFlags()
            try:
                self.callback(indata, self.blocksize, None, status)
            except Exception:
                break
            self._blocks_delivered += 1
            if self.block_interval > 0:
                time.sleep(self.block_interval)

    def stop(self):
        self._stop_flag.set()
        if self._thread is not None:
            self._thread.join(timeout=5.0)

    def close(self):
        pass


def install_functional_sounddevice_stub(**stream_kwargs):
    """Instala el stub en `sys.modules['sounddevice']`. `stream_kwargs`
    se reenvían a cada `InputStream` creado (p. ej.
    `n_blocks_before_death=50` para simular muerte del stream)."""
    import sys
    import types

    mod = types.ModuleType("sounddevice")

    def _input_stream_factory(*args, **kwargs):
        merged = dict(stream_kwargs)
        merged.update(kwargs)
        return FunctionalInputStream(*args, **merged)

    mod.InputStream = _input_stream_factory
    mod.query_devices = lambda *a, **k: []
    sys.modules["sounddevice"] = mod
    return mod
