from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Panel de indicadores tipo VU/contómetro — celdas de leyenda, VU-meter, reloj digital.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QFontMetrics, QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath, QTransform)
from PySide6.QtCore    import QPoint, QPointF, QRectF

import math as _math
import os as _os

from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, VFD_GOLD, VFD_GOLD_BRIGHT, VFD_GOLD_DIM, VFD_GOLD_GLOW,
)
from lorito_aldhiro.frontend.support.lorito_fonts import font_ui, font_contometro, font_leyendas, font_celdas_compartidas, lcd_ascii
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget

# Tinta del LCD Display (SVG de la usuaria): #121008.
_LCD_INK_RGB = (0x12, 0x10, 0x08)


class LuminousIndicator(QWidget):
    """
    LED indicador parpadeante del lateral del panel de contómetro —
    SEGUNDO rediseño (pedido explícito del usuario, SVG de referencia
    adjunto: lente de cristal tipo joya, bisel de aluminio pulido con
    encastre rebajado, resplandor incandescente y facetas internas).
    Ya NO lleva la etiqueta de texto que tenía debajo (IDLE/REC/BUSY/
    ACT) — el SVG de referencia es una joya de cristal pura, sin
    leyenda, y a este tamaño el texto de 5px apenas se leía; se
    prioriza fidelidad al material de referencia. Tamaño aumentado
    ligeramente (`SIZE` 22→28, pedido explícito) — se reposiciona desde
    `lorito_mw_ui_build.py` para quedar centrado verticalmente en el
    lateral izquierdo del panel fusionado del contómetro
    (`CounterMegapanel`).
    """
    SIZE = 28
    TOTAL_H = SIZE   # ya no hay fila de texto separada — círculo puro

    def __init__(self, parent=None):
        super().__init__(parent)
        self._state    = "standby"
        self._blink_on = True
        self.setFixedSize(self.SIZE, self.TOTAL_H)
        # ── Wayland-safe attributes ───────────────────────────────────────────
        # WA_OpaquePaintEvent=False: composición alpha correcta en Wayland SHM.
        # WA_TranslucentBackground=True: esquinas del círculo transparentes.
        # WA_NoSystemBackground=True: sin relleno de fondo del parent widget.
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)

    def setState(self, s):  self._state = s;    self.update()
    def setBlink(self, b):  self._blink_on = b; self.update()

    def paintEvent(self, _):
        """LED circular del SVG del LCD Display (zócalo rebajado, halo,
        lente y punto especular). Color por estado; en reposo (standby)
        la lente cian queda apagada; REC parpadea."""
        from lorito_aldhiro.frontend.widgets.lorito_svg_panels import paint_svg_led
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w = self.width()
        st = THEME["states"].get(self._state, THEME["states"]["standby"])
        if self._state == "standby":
            color, lit = QColor("#00ffcc"), False
        else:
            color = QColor(st["ind"])
            lit = (self._state != "rec") or self._blink_on
        paint_svg_led(p, w / 2.0, w / 2.0, w / 2.0 - 1.5, color, lit)
        p.end()



def _parse_css_color(color: str) -> QColor:
    """Parsea 'rgba(r,g,b,a)' (a en 0..1 o 0..255) o '#rrggbb'/nombre
    Qt — mismo formato de color que usa el registro de overlays de
    CRAC (`mega_panel_text_registry.py`), para poder reutilizar sus
    cadenas literalmente sin reformatearlas a mano."""
    color = color.strip()
    if color.startswith("rgba"):
        nums = color[color.find("(") + 1: color.find(")")].split(",")
        r, g, b = (int(float(x)) for x in nums[:3])
        a_raw = float(nums[3])
        a = int(a_raw * 255) if a_raw <= 1.0 else int(a_raw)
        return QColor(r, g, b, a)
    return QColor(color)


class DigitalClock(QWidget):
    """
    Panel de contómetro principal de Lorito Aldhiro — megacelda del
    contador central, con una fila de 8 celdas arriba y otra de 8 abajo
    (0.11.010: + PREVI/TAU y COSANI/EXPORT) (paridad con CRAC, pedido explícito del usuario — ver
    GAP-010), más 4 celdas verticales invisibles en cada extremo de la
    megacelda (§GAP-015) — sumadas a la celda de esquina de las filas
    superior/inferior que ya tocan ese mismo borde, dan 6 celdas por
    extremo en total. SIN Vitreous Subeventos/logos SVG: solo leyendas
    de texto (mismo patrón "celda invisible" del VFD Display de CRAC).

        ┌──────────────────────────────────────────────┐
        │ DOLBY B DOLBY C DOLBY S DBX ANRS S ANRS PREVI TAU │  ← fila superior
        ├──┬────────────────────────────────────────┬──┤
        │L1│                                        │R1│
        │L2│              00:00:00                  │R2│  ← megacelda
        │L3│                                        │R3│
        │L4│                                        │R4│
        ├──┴────────────────────────────────────────┴──┤
        │ DNL DNR ALC ALSA JACK C-60 COSANI EXPORT       │  ← fila inferior
        └──────────────────────────────────────────────┘

    Es la megacelda IZQUIERDA del panel fusionado (`CounterMegapanel`,
    ver más abajo) — el Media Anim ya NO comparte este widget (antes
    vivía como hijo suyo, en el extremo derecho, empujando las celdas
    R1-R4): ahora vive en su propia megacelda cuadrada hermana.

    La celda final de la fila inferior conmuta su leyenda entre
    "C-60"/"C-90"/"OTROS" según `cassette_dur_box` (ver
    `set_tape_label_cell()`, llamado desde
    `_on_cassette_dur_changed()` en `lorito_main_window.py`).

    Las 8 celdas verticales (L1-L4/R1-R4) quedan como slots vacíos,
    listos para recibir contenido — sin asignación de leyenda todavía
    (pendiente de instrucción explícita, ver GAP-015 §pendiente).
    """

    LEGEND_ROW_H = 13
    # Cuadrícula angular del LCD (0.11.009): separación entre celdas,
    # margen interior de leyendas y del contómetro.
    GRID_GAP = 2
    LEGEND_PAD = 2
    COUNTER_PAD_X = 10
    COUNTER_PAD_Y = 6
    # 0.11.008: 15 → 30 px — con 15 px las leyendas (LADO A, STEREO, MONO,
    # NORMAL, DITHER, FOCUS) se recortaban en el borde.
    SIDE_COL_W = 30   # ancho de cada columna vertical izquierda/derecha
    # 0.11.010: tamaño mínimo legible de un overlay; los mensajes largos de
    # CRAC que no caben a este tamaño se recortan con "...".
    OVERLAY_MIN_PX = 14
    # 0.11.010: carretes de cassette (imagen de la usuaria) en una celda
    # invisible del ángulo superior derecho de la megacelda del contómetro.
    # El carrete grande y su pareja más pequeña se deforman para verse
    # inclinados en horizontal (aplastados en vertical y girados). El
    # contómetro y los overlays se dibujan por debajo de esa celda.
    REEL_CELL_H_FRAC = 0.38   # alto de la celda respecto de la megacelda
    REEL_SQUASH = 0.48        # aplastamiento vertical (perspectiva)
    REEL_TILT_DEG = -14.0     # inclinación
    REEL_SMALL = 0.68         # tamaño de la pareja respecto del grande
    REEL_GAP = 4
    _REEL_PATH = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                               "support", "assets", "images", "carrete_cassette.png")

    # 0.11.010: dos celdas nuevas arriba (PREVI, TAU) y dos abajo (COSANI,
    # EXPORT). Se encienden mientras haya armado un overlay de su familia
    # funcional (ver `lorito_overlay_registry.FAMILY_OF_CATEGORY`) o por
    # `set_cell_lit()`.
    TOP_CELLS    = [("DOLBY B", "DOLBY_B"), ("DOLBY C", "DOLBY_C"),
                    ("DOLBY S", "DOLBY_S"), ("DBX", "DBX"),
                    ("ANRS", "ANRS"), ("S ANRS", "S_ANRS"),
                    ("PREVI", "PREVI"), ("TAU", "TAU")]
    BOTTOM_CELLS = [("DNL", "DNL"), ("DNR", "DNR"), ("ALC", "ALC"),
                    ("ALSA", "ALSA"), ("JACK", "JACK"), ("C-60", "TAPE_LABEL"),
                    ("COSANI", "COSANI"), ("EXPORT", "EXPORT")]
    FAMILY_CELLS = ("PREVI", "TAU", "COSANI", "EXPORT")
    # Columna izquierda (L1-L4, de arriba a abajo, pedido explícito del
    # usuario): LADO A/B (conmuta según el lado de cinta), STEREO, MONO,
    # MON 1/2/3 (1=monitor estéreo normal, 2=monitor mono izquierdo,
    # 3=monitor mono derecho).
    LEFT_CELLS  = ["L1", "L2", "L3", "L4"]
    # Columna derecha (R1-R4): MPX, NORMAL (alterna con CrO2/FeCr/Metal),
    # DITHER (parpadea al seleccionar un maquillador dither — en Lorito
    # Aldhiro vive en la entrada de menú "DSP"), FOCUS.
    RIGHT_CELLS = ["R1", "R2", "R3", "R4"]

    # ── Dorado lumínico (§VFD_GOLD_PALETTE) — TODAS las leyendas del
    # contómetro (arriba/abajo/laterales) comparten el mismo tono dorado
    # lumínico, pedido explícito del usuario; ya no hay color por-token
    # distinto por sistema (Dolby/DBX/ANRS/etc. — eso vivía en
    # `_CELL_LIT_COLOR` antes de este rediseño VFD). Se conserva un único
    # QColor "encendido" vs. un "apagado" (fósforo residual, tenue).
    # LCD Display (SVG de la usuaria, 0.11.008): tinta negra sobre LCD
    # ámbar. El nombre `_GOLD` se conserva por compatibilidad.
    _CELL_LIT_COLOR_GOLD = QColor(0x12, 0x10, 0x08, 235)
    # FIX-CELL-APAGADO (pedido explícito del usuario): el estado "sin
    # sistema activo" de una celda de leyenda debe leerse como fósforo
    # genuinamente APAGADO (un residuo casi imperceptible, como un
    # segmento VFD real que nunca se encendió), no como una versión
    # "dimmer" a media intensidad del mismo dorado encendido. Antes
    # alpha=46 seguía siendo bien legible; se reduce a un residuo
    # fantasma (alpha=14) para que la diferencia encendido/apagado sea
    # clara de un vistazo, igual que un VFD real.
    # Segmento LCD apagado: residuo tenue de tinta, como un LCD real.
    _CELL_DIM_COLOR = QColor(0x12, 0x10, 0x08, 30)

    # Categorías de overlay en orden de prioridad — calcado del árbol real
    # de CRAC ("LilyGain > PeaKxtrem > scrub_msg > FnTape Aldh > ITL Flip
    # (FnSide A/B) > SeekYng > VaccUm TP > Expn Signal > SIPActiV > Pause
    # (manual) > Export > H-Dubb/N-Dubb > OvFlow > Side A/B > Auto Pause
    # > ... > NR transitorio > Dolby X > HX Pro"), filtrado a las
    # categorías que Lorito Aldhiro realmente tiene (§GAP-010). La
    # primera con una entrada activa en `_overlay_stack` es la que se
    # muestra; "FNC_NO_DISP" siempre gana (prioridad absoluta en CRAC).
    # 0.11.010: categorías de los overlays migrados del VFD de CRAC
    # (`showCracOverlay`): SYSTEM, TAU, COSANI, PREVI y SYSTEM_IDLE (Ready/
    # reposo, la más baja, como en CRAC). EXPORT es compartida.
    _CATEGORY_PRIORITY = (
        "FNC_NO_DISP", "SYSTEM", "SCRUBS", "FN_TAPE_ALDH", "ITL",
        "SIPA", "PAUSE_PHYSICAL", "EXPORT", "OVFLOW_TP", "SIDE_MSG",
        "TAU", "COSANI", "PREVI",
        "NR", "EQBIAS", "HX_PRO", "MONITOR", "CAPTURE_MONITOR",
        "SYSTEM_IDLE",
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self._text  = "00:00:00"; self._state = "standby"
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

        # ── Celdas de leyenda (arriba/abajo) — invisibles (sin fondo),
        # solo texto, se iluminan cuando el sistema correspondiente está
        # activo (§GAP-010, paridad con CRAC TOP_ROW_LEGEND_COLORS/
        # BACKEND_LEGEND_COLORS, sin logos SVG). ──────────────────────────
        self._cell_lit: dict[str, bool] = {
            token: False for _, token in (self.TOP_CELLS + self.BOTTOM_CELLS)
        }
        self._tape_label_text = "C-60"

        # ── Celdas verticales de extremo — leyendas fijas pedidas
        # explícitamente por el usuario (columna izquierda: LADO A/B,
        # STEREO, MONO, MON 1/2/3 — columna derecha: MPX, NORMAL/CrO2/
        # FeCr/Metal, DITHER, FOCUS). Arrancan apagadas (fósforo dorado
        # tenue) salvo el estado por defecto razonable de cada una.
        self._side_cell_text: dict[str, str] = {
            "L1": "LADO A", "L2": "STEREO", "L3": "MONO", "L4": "MON 1",
            "R1": "MPX", "R2": "NORMAL", "R3": "DITHER", "R4": "FOCUS",
        }
        self._side_cell_lit: dict[str, bool] = {
            token: False for token in (self.LEFT_CELLS + self.RIGHT_CELLS)
        }
        # Estado por defecto: LADO A encendido, STEREO encendido (modo
        # normal), MON 1 encendido (monitor estéreo normal).
        self._side_cell_lit["L1"] = True
        self._side_cell_lit["L2"] = True
        self._side_cell_lit["L4"] = True
        self._monitor_mode = 1          # 1=estéreo normal, 2=mono izq, 3=mono der
        self._dither_active = False     # True mientras hay un maquillador dither seleccionado
        self._dither_blink_on = True

        # ── Leyendas de DSP de CRAC adaptados (GAP-039/040, pedido
        # explícito del usuario) — "PREVI DSP" reemplaza la leyenda
        # "DOLBY B" mientras algún DSP de PREVI está activo (Cristhi
        # Cosh, etc. — comparten esta única celda, no hay uno por DSP).
        # "FNESP DSP" hace lo mismo en la celda "DOLBY C", pero SI
        # Dolby C real está también activo, ambas leyendas alternan
        # cada ~1s (avanzado por `tick_legend_alternation()`, mismo
        # tick central de 480ms que el resto de parpadeos del panel).
        self._previ_dsp_active = False
        self._fnesp_dsp_active = False
        self._legend_alt_on = True
        self._legend_alt_tick_count = 0

        # ── Leyenda "MUSC EQ" (GAP-043, Muscle Eq Samir) — reemplaza
        # "DOLBY S" en su celda; si Dolby S real también está activo,
        # ambas alternan cada ~1s (orden §19-20, mismo mecanismo ya
        # construido para PREVI DSP/FNESP DSP con Dolby B/C).
        self._muscle_eq_active = False
        self._muscle_eq_alt_on = True
        self._muscle_eq_alt_tick_count = 0

        # ── Overlay general (§GAP-010, generaliza el overlay ITL de
        # GAP-007/008 a múltiples categorías con prioridad) ──────────────
        self._overlay_stack: dict[str, tuple[str, QColor]] = {}
        self._overlay_blink_on = True

        # FIX-OVERLAY-BLINK-AUTOSUFICIENTE (pedido explícito del
        # usuario — auditoría de overlays): antes `_overlay_blink_on`
        # SOLO avanzaba cuando `tickITLOverlayBlink()` era llamado desde
        # afuera, y eso únicamente ocurría durante la auto-pausa por
        # silencio o el desbordamiento de cuentavueltas — es decir,
        # cualquier overlay ajeno a esos dos casos (SCRUBS, SIDE_MSG,
        # FN_TAPE_ALDH, HX_PRO, etc.) dependía de un tick que nunca
        # llegaba mientras esos dos subsistemas estuvieran inactivos.
        # Un widget bien diseñado no depende de que un módulo externo
        # no relacionado recuerde llamarlo: DigitalClock ahora es
        # autosuficiente y trae su propio QTimer de parpadeo a 480ms
        # (mismo intervalo que el resto del panel), activo siempre que
        # haya al menos un overlay armado. Las llamadas externas a
        # `tickITLOverlayBlink()` desde auto-pausa/overflow se retiraron
        # (ver `lorito_mw_silence_autopause.py`) para no duplicar el
        # parpadeo cuando ambos coincidan.
        self._overlay_blink_timer = QTimer(self)
        self._overlay_blink_timer.setInterval(480)
        self._overlay_blink_timer.timeout.connect(self.tickITLOverlayBlink)
        self._overlay_blink_timer.start()

        # Fase de "respiro" fosfórico de las scanlines (§paint_vfd_glass)
        # — avanzada por el panel fusionado dueño (`CounterMegapanel`),
        # NO por un timer propio: las tres megaceldas del panel deben
        # respirar EN FASE, como una sola pieza de vidrio.
        self._breath_phase = 0.0

    def set_breath_phase(self, phase: float) -> None:
        self._breath_phase = phase
        self.update()

    def setText(self, t):  self._text  = t; self.update()
    def setState(self, s): self._state = s; self.update()

    # ── Celdas de leyenda ──────────────────────────────────────────────
    def set_cell_lit(self, token: str, lit: bool) -> None:
        """Enciende/apaga una celda de leyenda por su token (§TOP_CELLS/
        BOTTOM_CELLS). Token desconocido: no-op silencioso (nunca rompe
        el arranque por un nombre mal escrito)."""
        if token in self._cell_lit:
            self._cell_lit[token] = lit
            self.update()

    def set_host_cell(self, backend: str) -> None:
        """ALSA/JACK son mutuamente excluyentes — enciende una, apaga la
        otra (paridad con BACKEND_LEGEND_COLORS de CRAC)."""
        self.set_cell_lit("ALSA", backend == "ALSA")
        self.set_cell_lit("JACK", backend == "JACK")

    def set_tape_label_cell(self, text: str) -> None:
        """Conmuta la leyenda de la celda final de la fila inferior
        entre C-60/C-90/OTROS (pedido explícito del usuario)."""
        self._tape_label_text = text
        self.update()

    def set_side_cell(self, token: str, text: str = "", lit: bool = False) -> None:
        """Asigna texto/estado a una celda vertical de extremo
        (L1-L4/R1-R4, §GAP-015). Token desconocido: no-op silencioso."""
        if token in self._side_cell_text:
            self._side_cell_text[token] = text
            self._side_cell_lit[token] = lit
            self.update()

    # ── Leyendas fijas de columna — helpers de conveniencia ────────────
    def set_tape_side(self, side: str) -> None:
        """L1: conmuta LADO A / LADO B según el lado de cinta activo."""
        side = "B" if str(side).upper().startswith("B") else "A"
        self.set_side_cell("L1", f"LADO {side}", True)

    def set_channel_mode(self, stereo: bool) -> None:
        """L2/L3: STEREO/MONO — exclusión mutua, mismo patrón que
        ALSA/JACK (`set_host_cell`)."""
        self.set_side_cell("L2", "STEREO", stereo)
        self.set_side_cell("L3", "MONO", not stereo)

    def set_monitor_mode(self, mode: int) -> None:
        """L4: MON 1 (monitor estéreo normal) / MON 2 (monitor mono
        izquierdo) / MON 3 (monitor mono derecho)."""
        mode = mode if mode in (1, 2, 3) else 1
        self._monitor_mode = mode
        self.set_side_cell("L4", f"MON {mode}", True)

    def set_tape_type(self, tipo: str) -> None:
        """R2: NORMAL (alterna con CrO2/FeCr/Metal)."""
        self.set_side_cell("R2", tipo.upper(), True)

    def set_mpx_lit(self, lit: bool) -> None:
        """R1: MPX (filtro de piloto estéreo 19kHz)."""
        self.set_side_cell("R1", "MPX", lit)

    def set_focus_lit(self, lit: bool) -> None:
        """R4: FOCUS."""
        self.set_side_cell("R4", "FOCUS", lit)

    def set_dither_active(self, active: bool) -> None:
        """R3: DITHER — parpadea mientras un maquillador dither está
        seleccionado (en Lorito Aldhiro vive en la entrada de menú
        "DSP", a diferencia de CRAC donde vive en Pañalissu). El
        parpadeo real avanza vía `tick_dither_blink()`, llamado desde
        el mismo tick de 480ms que el resto de parpadeos del panel."""
        self._dither_active = active
        if not active:
            self._dither_blink_on = True
        self.set_side_cell("R3", "DITHER", active and self._dither_blink_on)

    def tick_dither_blink(self) -> None:
        if self._dither_active:
            self._dither_blink_on = not self._dither_blink_on
            self.set_side_cell("R3", "DITHER", self._dither_blink_on)

    # ── Leyendas "PREVI DSP"/"FNESP DSP" (GAP-039/040) ──────────────────
    def set_previ_dsp_active(self, active: bool) -> None:
        """Mientras `active`, la celda "DOLBY B" muestra "PREVI DSP" en
        su lugar — compartida por todos los DSP de PREVI (no hay una
        celda por DSP; si más de uno estuviera activo, esta leyenda
        sigue reflejando "hay al menos uno armado")."""
        self._previ_dsp_active = active

    def set_fnesp_dsp_active(self, active: bool) -> None:
        """Mientras `active`, la celda "DOLBY C" muestra "FNESP DSP" —
        si Dolby C real también está activo (`_cell_lit["DOLBY_C"]`),
        ambas leyendas alternan cada ~1s vía `tick_legend_alternation()`."""
        self._fnesp_dsp_active = active
        if not active:
            self._legend_alt_on = True
            self._legend_alt_tick_count = 0

    def tick_legend_alternation(self) -> None:
        """Avanza la alternancia PREVI DSP/FNESP DSP con Dolby B/C —
        llamado desde el mismo tick de 480ms que `tick_dither_blink()`;
        alterna cada 2 llamadas (~960ms, aproxima el "cada segundo"
        pedido por el usuario sin crear un QTimer nuevo)."""
        if not self._fnesp_dsp_active or not self._cell_lit.get("DOLBY_C", False):
            return
        self._legend_alt_tick_count += 1
        if self._legend_alt_tick_count % 2 == 0:
            self._legend_alt_on = not self._legend_alt_on

    # ── Leyenda "MUSC EQ" (GAP-043) ──────────────────────────────────
    def set_muscle_eq_active(self, active: bool) -> None:
        """Mientras `active`, la celda "DOLBY S" muestra "MUSC EQ" —
        si Dolby S real también está activo, ambas alternan cada ~1s
        (orden §19-20)."""
        self._muscle_eq_active = active
        if not active:
            self._muscle_eq_alt_on = True
            self._muscle_eq_alt_tick_count = 0

    def tick_muscle_eq_alternation(self) -> None:
        """Avanza el parpadeo/alternancia de "MUSC EQ" — mismo tick
        central de 480ms que el resto de parpadeos. Dos comportamientos
        distintos (orden §19 vs §20):
        - Muscle Eq Samir activo SOLO (Dolby S real apagado): la
          leyenda "MUSC EQ" PARPADEA (aparece/desaparece) durante la
          actividad del procesador (§19).
        - Muscle Eq Samir Y Dolby S real activos a la vez: la celda
          ALTERNA entre "DOLBY S" y "MUSC EQ" en vez de parpadear
          cada una por separado (§20)."""
        if not self._muscle_eq_active:
            return
        self._muscle_eq_alt_tick_count += 1
        if self._muscle_eq_alt_tick_count % 2 == 0:
            self._muscle_eq_alt_on = not self._muscle_eq_alt_on

    # ── Overlay general (múltiples categorías, con prioridad) ─────────
    def setOverlay(self, category: str, active: bool,
                   text: str = "", color: str = "") -> None:
        """
        Activa/desactiva un overlay en una categoría dada. Varias
        categorías pueden estar "armadas" a la vez (p. ej. SIPA activo
        mientras se arma una EXPORT) — solo se muestra la de mayor
        prioridad (`_CATEGORY_PRIORITY`). Pasar `active=False` retira
        SOLO esa categoría; si había otra por debajo en prioridad, pasa
        a mostrarse automáticamente.
        """
        if active:
            self._overlay_stack[category] = (text, _parse_css_color(color) if color else QColor(255, 255, 255, 220))
        else:
            self._overlay_stack.pop(category, None)
            if not self._overlay_stack:
                # Sin overlays armados: reiniciar la fase de parpadeo a
                # "visible" para que el PRÓXIMO overlay que se active
                # empiece siempre mostrándose, en vez de heredar una
                # fase "apagada" residual del último parpadeo.
                self._overlay_blink_on = True
        self.update()

    def setOverlayFromRegistry(self, category: str, active: bool, token: str | None = None) -> None:
        """Conveniencia: resuelve texto/color desde
        `lorito_overlay_registry.message_for(token)` en vez de pasarlos
        a mano — usado por los disparadores de NR/HX Pro/monitor."""
        if active and token:
            from lorito_aldhiro.backend.export.lorito_overlay_registry import message_for
            text, color = message_for(token)
            self.setOverlay(category, True, text, color)
        else:
            self.setOverlay(category, False)

    def showCracOverlay(self, token: str, active: bool = True, **fields) -> None:
        """Muestra (o retira) un overlay migrado del VFD de CRAC por su token
        (`lorito_crac_vfd_overlays`). Se arma en la categoría de su familia
        funcional, con lo que se enciende la celda PREVI/TAU/COSANI/EXPORT
        correspondiente. Si CRAC le daba una duración, se retira solo al
        cumplirse (y el reloj se reinicia si se vuelve a disparar)."""
        from lorito_aldhiro.backend.export.lorito_overlay_registry import (
            crac_overlay, crac_overlay_text, OVERLAY_MESSAGES)
        e = crac_overlay(token)
        if e is None:
            if active:
                self.setOverlayFromRegistry("FNC_NO_DISP", True, "FNC_NO_DISP")
            return
        cat = e["lcd_category"]
        timers = self.__dict__.setdefault("_crac_overlay_timers", {})
        if not active:
            self.setOverlay(cat, False)
            t = timers.get(cat)
            if t is not None:
                t.stop()
            return
        self.setOverlay(cat, True, crac_overlay_text(token, **fields),
                        OVERLAY_MESSAGES["FNC_NO_DISP"][1])
        if e["duration_ms"]:
            t = timers.get(cat)
            if t is None:
                t = QTimer(self)
                t.setSingleShot(True)
                t.timeout.connect(lambda c=cat: self.setOverlay(c, False))
                timers[cat] = t
            t.start(int(e["duration_ms"]))

    def _family_cells_lit(self) -> set:
        """Celdas de familia (PREVI/TAU/COSANI/EXPORT) encendidas porque hay
        armado al menos un overlay de esa familia funcional."""
        from lorito_aldhiro.backend.export.lorito_overlay_registry import family_of_category
        return {family_of_category(cat) for cat in self._overlay_stack} & set(self.FAMILY_CELLS)

    def _active_overlay(self) -> tuple[str, QColor] | None:
        for cat in self._CATEGORY_PRIORITY:
            if cat in self._overlay_stack:
                return self._overlay_stack[cat]
        return None

    # ── Compatibilidad retroactiva: la API de GAP-007/008 sigue viva,
    # ahora como delegado de la categoría "ITL" del overlay general. ────
    def setITLOverlay(self, active: bool, text: str = "",
                      color: str = "rgba(80,220,255,200)") -> None:
        self.setOverlay("ITL", active, text, color)

    def tickITLOverlayBlink(self) -> None:
        """Alterna la visibilidad del overlay activo (cualquier
        categoría) — llamado desde el mismo tick de 480ms que ya
        sincroniza pausa/PC/paneles de cinta."""
        if self._overlay_stack:
            self._overlay_blink_on = not self._overlay_blink_on
            self.update()

    # ── Cuadrícula angular (0.11.009) ────────────────────────────────────
    @staticmethod
    def _grid_cell(p: QPainter, rect: QRect) -> None:
        """Marco recto (sin redondeo) de una celda del LCD, tinta tenue."""
        p.save()
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(QPen(QColor(*_LCD_INK_RGB, 72), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRect(rect.adjusted(0, 0, -1, -1))
        p.restore()

    def _grid_rects(self, w: int, h: int):
        """Rectángulos de la cuadrícula: filas superior/inferior, columnas
        laterales y megacelda del contómetro (con GRID_GAP entre celdas)."""
        g = self.GRID_GAP
        row_h = self.LEGEND_ROW_H
        scw = self.SIDE_COL_W
        mc_y = row_h + g
        mc_h = h - 2 * (row_h + g)
        def row(y, cells):
            n = len(cells)
            cw = (w + g) / n
            return [QRect(int(i * cw), y, int((i + 1) * cw) - int(i * cw) - g, row_h)
                    for i in range(n)]
        def col(x, tokens):
            n = len(tokens)
            ch = (mc_h + g) / n
            return [QRect(x, mc_y + int(i * ch), scw, int((i + 1) * ch) - int(i * ch) - g)
                    for i in range(n)]
        return {
            "top": row(0, self.TOP_CELLS),
            "bottom": row(h - row_h, self.BOTTOM_CELLS),
            "left": col(0, self.LEFT_CELLS),
            "right": col(w - scw, self.RIGHT_CELLS),
            "counter": QRect(scw + g, mc_y, w - 2 * (scw + g), mc_h),
        }

    def paintEvent(self, _):
        """LCD Display — cuadrícula angular (0.11.009): cada celda con marco
        recto; leyendas pequeñas CENTRADAS en su celda (0.11.010);
        contómetro (y overlays) en el ángulo INFERIOR IZQUIERDO de la
        megacelda, con margen para no tocar los bordes. Tinta negra del LCD
        sobre el ámbar que pinta `CounterMegapanel`."""
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        ink = QColor(*_LCD_INK_RGB)
        g = self._grid_rects(w, h)
        for key in ("top", "bottom", "left", "right"):
            for r in g[key]:
                self._grid_cell(p, r)
        mc = g["counter"]
        self._grid_cell(p, mc)

        self._paint_side_column(p, self.LEFT_CELLS, g["left"])
        self._paint_side_column(p, self.RIGHT_CELLS, g["right"])
        self._paint_legend_row(p, self.TOP_CELLS, g["top"])
        self._paint_legend_row(p, self.BOTTOM_CELLS, g["bottom"])

        # Carretes en su celda invisible (ángulo superior derecho).
        reel_cell, reels = self._reel_rects(mc)
        for r in reels:
            self._paint_reel(p, r)

        # Área útil del contómetro: megacelda menos el margen y por debajo de
        # la celda de los carretes, para que nunca se toquen.
        area = mc.adjusted(self.COUNTER_PAD_X, self.COUNTER_PAD_Y,
                           -self.COUNTER_PAD_X, -self.COUNTER_PAD_Y)
        area.setTop(reel_cell.bottom() + 1 + self.REEL_GAP)
        overlay = self._active_overlay()
        if overlay is not None and self._overlay_blink_on:
            ov_text, _ov_color = overlay
            ov_text = lcd_ascii(ov_text)
            # Overlays: misma familia que los dígitos (FIX-OVERLAY-FONT) y
            # mismo ángulo inferior izquierdo; tamaño ajustado para caber en
            # la megacelda (antes crecía hasta desbordarla).
            fnt_ov = self._fit_font(font_contometro, ov_text, area, start_px=46,
                                    spacing=1, min_px=self.OVERLAY_MIN_PX)
            # Mensajes largos de CRAC (diálogos, barra MENSAJE): si ni al
            # tamaño mínimo caben, se recortan con "..." dentro de la celda
            # (ASCII: alarm clock no tiene el carácter "…" de elidedText).
            ov_text = self._elide_ascii(fnt_ov, ov_text, area.width())
            p.setPen(ink)       # tinta del LCD (el color del registro es del VFD)
            self._draw_bottom_left(p, fnt_ov, ov_text, area)
        elif overlay is None:
            text = lcd_ascii(self._text)
            fnt = self._fit_font(font_contometro, text, area, start_px=56,
                                 spacing=2)
            p.setPen(QColor(ink.red(), ink.green(), ink.blue(),
                            250 if self._state in ("rec", "play") else 225))
            self._draw_bottom_left(p, fnt, text, area)
        # (overlay activo en la fase apagada del parpadeo: megacelda vacía)
        p.end()

    @staticmethod
    def _draw_bottom_left(p: QPainter, fnt: QFont, text: str, area: QRect) -> None:
        """Ancla el texto por sus TINTAS reales (no por la caja de línea de
        la fuente, cuyo descenso lo dejaría centrado): el borde inferior de
        los glifos toca el margen inferior y el izquierdo el margen
        izquierdo del área."""
        p.setFont(fnt)
        br = QFontMetrics(fnt).tightBoundingRect(text)
        p.drawText(QPoint(area.left() - br.left(), area.bottom() - br.bottom()), text)

    # ── Carretes de cassette (0.11.010) ─────────────────────────────────
    def _reel_transform(self):
        """Transformación de un carrete centrado en el origen: aplastado en
        vertical y girado (forma inclinada horizontal)."""
        t = QTransform()
        t.rotate(self.REEL_TILT_DEG)
        t.scale(1.0, self.REEL_SQUASH)
        return t

    def _reel_extent(self) -> tuple[float, float]:
        """Ancho y alto de la caja del carrete deformado, por unidad de lado."""
        r = self._reel_transform().mapRect(QRectF(-0.5, -0.5, 1.0, 1.0))
        return r.width(), r.height()

    def _reel_rects(self, mc: QRect):
        """Celda invisible de los carretes (ángulo superior derecho de la
        megacelda, dentro del margen) y la caja de cada carrete: el grande a
        la derecha y su pareja, más pequeña, a la izquierda, centrados en la
        misma línea."""
        ex, ey = self._reel_extent()
        cell_h = max(8, int(mc.height() * self.REEL_CELL_H_FRAC))
        big = cell_h / ey                      # lado del carrete grande
        small = big * self.REEL_SMALL
        bw, bh = big * ex, big * ey
        sw, sh = small * ex, small * ey
        cell_w = int(bw + self.REEL_GAP + sw) + 1
        top = mc.top() + self.REEL_GAP
        right = mc.right() - self.COUNTER_PAD_X
        cell = QRect(right - cell_w + 1, top, cell_w, cell_h)
        cy = cell.top() + cell_h / 2.0
        big_r = QRectF(cell.right() + 1 - bw, cy - bh / 2.0, bw, bh)
        small_r = QRectF(big_r.left() - self.REEL_GAP - sw, cy - sh / 2.0, sw, sh)
        return cell, [big_r, small_r]

    def _reel_pixmap(self, ink: QColor) -> QPixmap | None:
        pm = getattr(self, "_reel_pm_cache", None)
        if pm is None:
            src = QPixmap(self._REEL_PATH)
            if src.isNull():
                self._reel_pm_cache = False
                return None
            tinted = QPixmap(src.size())
            tinted.fill(Qt.transparent)
            q = QPainter(tinted)
            q.drawPixmap(0, 0, src)
            q.setCompositionMode(QPainter.CompositionMode_SourceIn)
            q.fillRect(tinted.rect(), ink)
            q.end()
            self._reel_pm_cache = pm = tinted
        return pm or None

    def _paint_reel(self, p: QPainter, box: QRectF) -> None:
        """Dibuja un carrete deformado que llena `box` (tinta del LCD)."""
        pm = self._reel_pixmap(QColor(*_LCD_INK_RGB, 225))
        if pm is None:
            return
        ex, _ey = self._reel_extent()
        side = box.width() / ex
        p.save()
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.translate(box.center())
        p.setTransform(self._reel_transform(), True)
        p.drawPixmap(QRectF(-side / 2, -side / 2, side, side), pm, QRectF(pm.rect()))
        p.restore()

    @staticmethod
    def _elide_ascii(fnt: QFont, text: str, width: int) -> str:
        fm = QFontMetrics(fnt)
        if fm.horizontalAdvance(text) <= width:
            return text
        while text and fm.horizontalAdvance(text.rstrip() + "...") > width:
            text = text[:-1]
        return text.rstrip() + "..."

    @staticmethod
    def _fit_font(factory, text: str, area: QRect, start_px: int, spacing: float,
                  min_px: int = 8):
        px = start_px
        while True:
            f = factory(size=0, bold=True)
            f.setPixelSize(px)
            f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
            fm = QFontMetrics(f)
            br = fm.tightBoundingRect(text)
            if (max(fm.horizontalAdvance(text), br.width()) <= area.width()
                    and br.height() <= area.height()) or px <= min_px:
                return f
            px -= 1

    def _paint_side_column(self, p: QPainter, tokens, rects) -> None:
        """Columna de 4 celdas verticales (§GAP-015) en la cuadrícula
        angular: leyenda pequeña CENTRADA en su celda (0.11.010; una palabra
        por línea), con un solo tamaño por columna — el mayor que permite
        que todas quepan. Fuente Utendo (celdas compartidas)."""
        pad = self.LEGEND_PAD
        texts = [self._side_cell_text.get(t, "") for t in tokens]
        col_w = rects[0].width() - 2 * pad
        cell_h = min(r.height() for r in rects) - 2 * pad
        px = 8
        while True:
            fnt = font_celdas_compartidas(size=0, bold=True)
            fnt.setPixelSize(px)
            fm = QFontMetrics(fnt)
            fits = all(
                max(fm.horizontalAdvance(wd) for wd in (t.split() or [""])) <= col_w
                and fm.height() * len(t.split() or [""]) <= cell_h
                for t in texts)
            if fits or px <= 5:
                break
            px -= 1
        p.save()
        p.setFont(fnt)
        for token, text, r in zip(tokens, texts, rects):
            lit = self._side_cell_lit.get(token, False)
            p.setPen(self._CELL_LIT_COLOR_GOLD if lit else self._CELL_DIM_COLOR)
            words = text.split() or [""]
            p.drawText(r, Qt.AlignCenter, "\n".join(words))
        p.restore()

    def _paint_legend_row(self, p: QPainter, cells, rects) -> None:
        """Fila de leyenda superior/inferior — Utendo (pedido explícito
        del usuario, misma familia que `_paint_side_column`: son las
        celdas compartidas del contómetro principal)."""
        # 0.11.010: leyenda CENTRADA en su celda (horizontal y vertical),
        # con un solo tamaño por fila: el mayor que permite que todas
        # quepan (incluidas las alternativas PREVI DSP/FNESP DSP/MUSC EQ).
        pad = self.LEGEND_PAD
        fam_lit = self._family_cells_lit()
        cell_w = min(r.width() for r in rects) - 2 * pad
        candidates = [label for label, _ in cells] + [
            "PREVI DSP", "FNESP DSP", "MUSC EQ", "OTROS", self._tape_label_text]
        px = max(6, rects[0].height() - 5)
        while True:
            fnt = font_celdas_compartidas(size=0, bold=True)
            fnt.setPixelSize(px)
            fm = QFontMetrics(fnt)
            if max(fm.horizontalAdvance(t) for t in candidates) <= cell_w or px <= 5:
                break
            px -= 1
        p.setFont(fnt)
        for i, (label, token) in enumerate(cells):
            if token == "TAPE_LABEL":
                text = self._tape_label_text
            elif token == "DOLBY_B" and self._previ_dsp_active:
                text = "PREVI DSP"
            elif token == "DOLBY_C" and self._fnesp_dsp_active:
                if self._cell_lit.get("DOLBY_C", False):
                    text = "FNESP DSP" if self._legend_alt_on else "DOLBY C"
                else:
                    text = "FNESP DSP"
            elif token == "DOLBY_S" and self._muscle_eq_active:
                if self._cell_lit.get("DOLBY_S", False):
                    text = "MUSC EQ" if self._muscle_eq_alt_on else "DOLBY S"
                else:
                    text = "MUSC EQ" if self._muscle_eq_alt_on else ""
            else:
                text = label
            lit = self._cell_lit.get(token, False) or token in fam_lit
            if token == "DOLBY_B" and self._previ_dsp_active:
                lit = True
            if token == "DOLBY_C" and self._fnesp_dsp_active:
                lit = True
            if token == "DOLBY_S" and self._muscle_eq_active:
                lit = True
            color = self._CELL_LIT_COLOR_GOLD if lit else self._CELL_DIM_COLOR
            p.setPen(color)
            p.drawText(rects[i], Qt.AlignCenter, text)


class SignalPulseCell(QWidget):
    """
    Megacelda INFERIOR del panel fusionado del contómetro
    (`CounterMegapanel`) — traza la onda bamboleante. Antes vivía como
    widget HERMANO independiente, con la MISMA altura que la megacelda
    del contómetro (bug reportado por el usuario: panel separado,
    empujando el lienzo de forma anormal); ahora es una megacelda más
    de `CounterMegapanel`, con 1/4 de la altura del bloque superior
    (contómetro + Media Anim) — ver `CounterMegapanel._layout_children()`.
    Mismo acabado VFD (vidrio ahumado negro + scanlines + halo
    fosfórico, vía `paint_vfd_glass`), respirando EN FASE con las otras
    dos megaceldas del panel.

    CONEXIÓN REAL AL MOTOR DE CAPTURA (corregido en esta sesión tras
    instrucción explícita del usuario: "la línea de reacción a la señal
    entrante deberá funcionar de modo real... conectada al motor de
    captura y no como algo estético"). Diseño anterior (GAP-018): un
    QTimer interno hacía avanzar una fase sintética que dibujaba dos
    senoides sumadas, moduladas por el NIVEL RMS — con un "piso de
    movimiento sutil incluso en silencio" que hacía que la línea
    ondulara SIEMPRE, tuviera o no señal real. Eso era, efectivamente,
    una animación decorativa con un volumen real como parámetro, no un
    trazo real de la señal.

    Ahora: `set_samples(mono)` recibe el bloque de muestras CRUDAS real
    del pipeline de captura (`CaptureEngine._monitor_block`, el mismo
    buffer ya usado para los VU meters — ver `lorito_main_window.py::
    _tick()`), y `paintEvent` dibuja esas muestras TAL CUAL (un
    osciloscopio real, no una síntesis). Sin QTimer propio: el trazo
    SOLO se mueve cuando llega un bloque nuevo — silencio real ahora sí
    se ve como una línea plana, no como una ondulación fingida.
    `set_level(l, r)` se conserva como *fallback* únicamente para
    reproducción (el reproductor, `StreamingPlayer`, no expone todavía
    un buffer de muestras crudas — solo VU suavizado, ver GAP de
    referencia) — en ese caso se dibuja una envolvente simple
    proporcional al nivel real, SIN oscilación sintética añadida.
    """

    # FIX-MEGACELDA-INFERIOR (pedido explícito del usuario): la
    # megacelda inferior de la onda bamboleante ya NO lleva ninguna
    # leyenda de texto — antes mostraba "SEÑAL" en la esquina, retirada
    # por completo (la celda queda como osciloscopio puro).

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self._samples: "np.ndarray | None" = None   # bloque crudo real más reciente
        self._level_l = 0.0
        self._level_r = 0.0
        self._breath_phase = 0.0   # avanzada por CounterMegapanel, ver DigitalClock

    def set_breath_phase(self, phase: float) -> None:
        self._breath_phase = phase
        self.update()

    def set_samples(self, mono) -> None:
        """Alimenta el trazo con muestras CRUDAS reales (mono, ya
        mezclado L/R si hace falta) del pipeline de captura — llamado
        desde `lorito_main_window.py::_tick()` con
        `CaptureEngine._monitor_block`. Reemplaza cualquier nivel
        previo de `set_level()` como fuente del trazo mientras haya
        muestras nuevas."""
        self._samples = mono
        self.update()

    def set_level(self, l: float, r: float) -> None:
        """Fallback SOLO para reproducción (sin buffer de muestras
        crudas expuesto todavía por `StreamingPlayer` — ver GAP de
        referencia). Limpia `_samples` para que `paintEvent` sepa que
        debe dibujar la envolvente por nivel, no un trazo de muestras."""
        self._samples = None
        self._level_l = max(0.0, min(1.0, l))
        self._level_r = max(0.0, min(1.0, r))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        # LCD Display: fondo ámbar común (CounterMegapanel); trazo en tinta.

        mid_y = h * 0.58
        amp_max = h * 0.34
        pts = []

        if self._samples is not None and len(self._samples) > 1:
            # ── Trazo REAL de osciloscopio — muestras crudas del motor
            # de captura, remuestreadas por selección de índice (sin
            # interpolar/inventar valores) a un punto por columna de
            # pantalla, tal como se vería en un osciloscopio real.
            samples = self._samples
            n_src = len(samples)
            n_pts = max(2, int(w))
            peak = 0.0
            for i in range(n_pts):
                idx = min(n_src - 1, int(i * n_src / n_pts))
                v = float(samples[idx])
                peak = max(peak, abs(v))
                x = i
                y = mid_y - v * amp_max
                pts.append(QPointF(x, y))
            level = min(1.0, peak)
        else:
            # ── Fallback SOLO reproducción: envolvente por nivel, sin
            # oscilación sintética (silencio real = línea plana).
            level = max(self._level_l, self._level_r)
            n_pts = max(24, w // 6)
            for i in range(n_pts + 1):
                fx = i / n_pts
                x = fx * w
                # Envolvente simple (medio punto por encima/debajo del
                # centro proporcional al nivel) — no es forma de onda
                # real, es un indicador de nivel honesto (no finge más
                # detalle del que hay disponible).
                y = mid_y - amp_max * level * (1.0 if i % 2 == 0 else -1.0) * 0.5
                pts.append(QPointF(x, y))

        if not pts:
            p.end()
            return

        # Halo (trazo ancho semitransparente) + línea nítida encima —
        # mismo efecto fosfórico que los dígitos del contómetro.
        path = QPainterPath()
        path.moveTo(pts[0])
        for pt in pts[1:]:
            path.lineTo(pt)

        p.setPen(QPen(QColor(*_LCD_INK_RGB, 45), 4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawPath(path)
        p.setPen(QPen(QColor(*_LCD_INK_RGB, 235 if level > 0.05 else 170), 1.6,
                     Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawPath(path)

        p.end()


class _MediaAnimGlassCell(QWidget):
    """
    Megacelda cuadrada de vidrio VFD (§CounterMegapanel) que aloja el
    Media Anim — mismo acabado `paint_vfd_glass` que las otras dos
    megaceldas del panel fusionado, para que las tres se vean como una
    sola pieza. El Media Anim se centra dentro de ella con un margen
    fijo pequeño, SIEMPRE cuadrado (mismo lado que la celda que lo
    aloja) — corrige el bug reportado de un tamaño aproximado que
    hacía que el icono se viera desbordado o recortado.
    """

    PAD = 8   # margen entre el vidrio de la celda y el Media Anim
    ANIM_SCALE = 0.80

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.anim = MediaAnimWidget(self)
        self._breath_phase = 0.0

    def set_breath_phase(self, phase: float) -> None:
        self._breath_phase = phase
        self.update()

    def resizeEvent(self, event):
        # 0.11.009: el Media Anim ocupa el 80 % del lado útil para no
        # desbordar su celda (su dibujo sobresale de la caja nominal).
        side = max(10, int((min(self.width(), self.height()) - 2 * self.PAD) * self.ANIM_SCALE))
        x = (self.width() - side) // 2
        y = (self.height() - side) // 2
        self.anim.setGeometry(x, y, side, side)
        super().resizeEvent(event)

    def paintEvent(self, _):
        # LCD Display: el fondo ámbar es común (CounterMegapanel).
        pass


class _GlassSheenOverlay(QWidget):
    """
    Cobertor vítreo ÚNICO del panel fusionado (§CounterMegapanel) —
    corrección explícita del usuario tras el primer rediseño: "las 3
    megaceldas deben ser cubiertas por el mismo cobertor vítreo... de
    manera tal que todo el conjunto parezca una sola pantalla". Antes
    cada megacelda (`DigitalClock`, `_MediaAnimGlassCell`,
    `SignalPulseCell`) pintaba su propio reflejo diagonal por separado
    — visualmente eran tres piezas de vidrio independientes en vez de
    una sola. Este widget se superpone POR ENCIMA de las tres (se crea
    último, así que nace ya en la cima del orden Z de `CounterMegapanel`)
    y pinta un único `paint_vfd_sheen()` recortado al contorno exterior
    completo del panel — el reflejo cruza los separadores blancos
    igual que cruzaría el vidrio de una sola pantalla física.

    Transparente a eventos de ratón: es puramente decorativo, nunca
    debe interceptar clics/arrastres destinados a los widgets que
    cubre.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self._radius = 12

    def set_radius(self, radius: int) -> None:
        self._radius = radius

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        from lorito_aldhiro.frontend.support import lorito_svg_skins as skins
        skins.paint_svg(p, skins.svg_lcd_glass(self.width(), self.height()),
                        0, 0, self.width(), self.height(), self)
        p.end()


class CounterMegapanel(QWidget):
    """
    LCD DISPLAY (0.11.008, SVG de la usuaria — análogo al VFD Display de
    CRAC): el panel pinta el encastre oscuro y la pantalla ámbar con
    textura de matriz (`svg_lcd_screen`); las megaceldas dibujan en tinta
    negra #121008 sobre ella y `_GlassSheenOverlay` aplica la cubierta de
    vidrio del SVG (`svg_lcd_glass`). Lo que sigue describe la estructura
    de megaceldas, que no cambia; el marco y los separadores BLANCOS y el
    vidrio VFD dorado mencionados abajo fueron sustituidos por el LCD.

    Panel fusionado del contómetro principal de Lorito Aldhiro —
    rediseño pedido explícito del usuario, UNA SOLA PIEZA física (mismo
    criterio de fusión que usa el VFD Display de CRAC): un widget padre
    con bordes redondeados y un marco BLANCO decorativo exterior, que
    aloja tres megaceldas:

      · IZQUIERDA (rectangular) — `DigitalClock`: contómetro central +
        las filas/columnas de leyenda ya existentes (sin cambios en su
        estructura interna, solo en su ancho: ya no comparte espacio
        con el Media Anim).
      · DERECHA (cuadrada perfecta) — `_MediaAnimGlassCell`, que aloja
        el `MediaAnimWidget`, ahora en su propia megacelda dedicada, sin
        desbordar ni verse recortada.
      · INFERIOR — `SignalPulseCell` (onda bamboleante, sin leyenda),
        con 1/4 de la altura de las megaceldas superiores.

    Separadores BLANCOS entre las tres (vertical entre izquierda/
    derecha, horizontal entre el bloque superior y el inferior) —
    pedido explícito del usuario, mismo criterio que el marco. Las tres
    megaceldas respiran EN FASE (mismo `breath_phase`, avanzado por un
    único QTimer de este panel) para que el efecto fosfórico se vea
    como el de una sola pieza de vidrio, no tres independientes.

    Geometría — fórmula cerrada (nunca iterativa, mismo criterio ya
    establecido en este proyecto para evitar recalcular por tanteo):
    dado el alto total `h` del panel,
        TOP_H = (h - SEP - 2*BORDER) / 1.25
        BOTTOM_H = TOP_H / 4
    de modo que  2*BORDER + TOP_H + SEP + BOTTOM_H == h  exactamente.
    El lado del cuadrado derecho es TOP_H (la altura completa de la
    megacelda izquierda); con un margen de seguridad para nunca
    quitarle a la izquierda más del 45% del ancho disponible (nunca
    debería activarse con las proporciones reales del panel, pero
    evita una megacelda izquierda ilegible si el panel se usara alguna
    vez con un ancho anormalmente angosto).
    """

    BORDER = 7            # encastre + bisel del LCD (SVG) antes del área ámbar
    SEP    = 3             # separadores internos (tinta tenue del LCD)
    BREATH_INTERVAL_MS = 60
    BREATH_STEP = 0.05

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

        self.digital_clock = DigitalClock(self)
        self.media_anim_glass = _MediaAnimGlassCell(self)
        self.signal_pulse = SignalPulseCell(self)
        # Creado AL FINAL a propósito: en Qt, el último hijo creado nace
        # en la cima del orden Z entre hermanos — así el cobertor vítreo
        # único queda por encima de las tres megaceldas sin necesitar
        # raise_() explícito (se llama de todas formas en
        # `_layout_children()`, por robustez ante reordenamientos).
        self._sheen = _GlassSheenOverlay(self)

        self._breath_phase = 0.0
        self._breath_timer = QTimer(self)
        self._breath_timer.setInterval(self.BREATH_INTERVAL_MS)
        self._breath_timer.timeout.connect(self._tick_breath)
        self._breath_timer.start()

    @property
    def media_anim(self) -> MediaAnimWidget:
        return self.media_anim_glass.anim

    def _tick_breath(self) -> None:
        self._breath_phase += self.BREATH_STEP
        self.digital_clock.set_breath_phase(self._breath_phase)
        self.signal_pulse.set_breath_phase(self._breath_phase)
        self.media_anim_glass.set_breath_phase(self._breath_phase)

    def resizeEvent(self, event):
        self._layout_children()
        super().resizeEvent(event)

    def _layout_children(self) -> None:
        w, h = self.width(), self.height()
        B, S = self.BORDER, self.SEP

        # 0.11.009: la celda de la onda pasa de 1/4 a 1/2 del alto del
        # bloque superior (TOP_H = disponible / 1.5).
        top_h = max(60, int((h - S - 2 * B) / 1.5))
        bottom_h = max(10, h - 2 * B - S - top_h)

        square_side = min(top_h, max(60, int(w * 0.45)))
        left_w = max(10, w - 2 * B - S - square_side)

        self.digital_clock.setGeometry(B, B, left_w, top_h)
        self.media_anim_glass.setGeometry(B + left_w + S, B, square_side, top_h)
        self.signal_pulse.setGeometry(B, B + top_h + S, w - 2 * B, bottom_h)

        # Cobertor vítreo único — cubre TODO el rectángulo interior que
        # agrupa las tres megaceldas (mismo contorno redondeado que el
        # marco blanco exterior, ligeramente adentro de él), por encima
        # de las tres, como una sola pantalla física.
        self._sheen.setGeometry(0, 0, w, h)
        self._sheen.set_radius(10)
        self._sheen.raise_()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        B, S = self.BORDER, self.SEP

        # LCD Display (SVG de la usuaria, 0.11.008): encastre oscuro +
        # pantalla ámbar con textura de matriz; los separadores entre
        # megaceldas son líneas de tinta tenue (como la línea divisoria
        # de la barra de estado del SVG).
        from lorito_aldhiro.frontend.support import lorito_svg_skins as skins
        if not skins.paint_svg(p, skins.svg_lcd_screen(w, h), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#d4b242"))
        # Cuadrícula angular: marco recto de la celda del Media Anim y de la
        # celda de la onda (las celdas del contómetro las dibuja DigitalClock).
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(QPen(QColor(*_LCD_INK_RGB, 72), 1))
        p.setBrush(Qt.NoBrush)
        for wd in (self.media_anim_glass, self.signal_pulse):
            p.drawRect(wd.geometry().adjusted(0, 0, -1, -1))
        p.end()





class VUBar(QWidget):
    """Vista de nivel (NO instrumento metrológico). Orden Golden UI/ITL
    (INST-01): el valor llega ya medido por `CaptureMeter` (RMS 300 ms por
    canal en ventana de frames, escala −60…0 dBFS → 0…1). La balística
    visual (caída y peak-hold) se rige por TIEMPO monotónico (`now`), no
    por número de ticks: un temporizador con jitter no cambia la duración
    efectiva del hold. Sin `now` (llamadas heredadas) se conserva la
    balística por tick. `setQuality("STALE")` atenúa la barra: un dato
    viejo nunca se presenta como actual."""
    # Caída de nivel: 0.012/tick a 24 fps ≈ 0.288/s
    DECAY_STEP  = 0.012
    DECAY_PER_S = DECAY_STEP * 24.0
    # Peak-hold: 72 ticks a 24 fps = 3 s
    PEAK_HOLD   = 72
    PEAK_HOLD_S = 3.0
    # Caída del peak: 0.003/tick ≈ 0.072/s
    PEAK_DECAY  = 0.003
    PEAK_DECAY_PER_S = PEAK_DECAY * 24.0

    def __init__(self, parent=None):
        super().__init__(parent)
        self._val_l = 0.0; self._val_r = 0.0
        self._pk_l  = 0.0; self._pk_r  = 0.0
        self._ph_l  = 0;   self._ph_r  = 0
        self._pk_alpha_l = 0; self._pk_alpha_r = 0
        # Balística por tiempo: instante del último pico y del último paso
        self._pk_t_l = None; self._pk_t_r = None
        self._last_t = None
        self._quality = "VALID"
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)

    def setQuality(self, quality: str):
        self._quality = quality or "VALID"

    def _step(self, now):
        if now is None:
            return None
        dt = 0.0 if self._last_t is None else max(0.0, min(now - self._last_t, 1.0))
        self._last_t = now
        return dt

    def _peak_time(self, val, pk, pk_t, pka, now, dt):
        """Peak-hold por tiempo: mantiene PEAK_HOLD_S y luego cae."""
        if val >= pk:
            return val, now, 255
        if pk_t is not None and now - pk_t > self.PEAK_HOLD_S:
            pk = max(val, pk - self.PEAK_DECAY_PER_S * dt)
            pka = max(0, int(255 * pk))
        return pk, pk_t, pka

    def setValues(self, l: float, r: float, now: float | None = None):
        """Actualiza estado interno. NO llama update() (Wayland-safe: el
        repintado lo dispara el temporizador de GUI)."""
        dt = self._step(now)
        if dt is not None:
            l = max(0., min(1., l)); r = max(0., min(1., r))
            self._val_l, self._val_r = l, r
            self._pk_l, self._pk_t_l, self._pk_alpha_l = self._peak_time(
                l, self._pk_l, self._pk_t_l, self._pk_alpha_l, now, dt)
            self._pk_r, self._pk_t_r, self._pk_alpha_r = self._peak_time(
                r, self._pk_r, self._pk_t_r, self._pk_alpha_r, now, dt)
            return

        def upd(val, pk, ph, pka):
            val = max(0., min(1., val))
            if val >= pk:
                pk = val; ph = self.PEAK_HOLD; pka = 255
            else:
                ph -= 1
                if ph <= 0:
                    pk = max(pk - self.PEAK_DECAY, val)
                    pka = max(0, int(255 * pk))
            return val, pk, ph, pka
        self._val_l, self._pk_l, self._ph_l, self._pk_alpha_l = upd(
            l, self._pk_l, self._ph_l, self._pk_alpha_l)
        self._val_r, self._pk_r, self._ph_r, self._pk_alpha_r = upd(
            r, self._pk_r, self._ph_r, self._pk_alpha_r)

    def decay(self, now: float | None = None):
        dt = self._step(now)
        if dt is not None:
            self._val_l = max(0., self._val_l - self.DECAY_PER_S * dt)
            self._val_r = max(0., self._val_r - self.DECAY_PER_S * dt)
            self._pk_l, self._pk_t_l, self._pk_alpha_l = self._peak_time(
                self._val_l, self._pk_l, self._pk_t_l, self._pk_alpha_l, now, dt)
            self._pk_r, self._pk_t_r, self._pk_alpha_r = self._peak_time(
                self._val_r, self._pk_r, self._pk_t_r, self._pk_alpha_r, now, dt)
            self.update()
            return

        def dec(val, pk, ph, pka):
            val = max(0., val - self.DECAY_STEP)
            ph -= 1
            if ph <= 0:
                pk  = max(0., pk - self.PEAK_DECAY)
                pka = max(0, int(255 * pk))
            return val, pk, ph, pka
        self._val_l, self._pk_l, self._ph_l, self._pk_alpha_l = dec(
            self._val_l, self._pk_l, self._ph_l, self._pk_alpha_l)
        self._val_r, self._pk_r, self._ph_r, self._pk_alpha_r = dec(
            self._val_r, self._pk_r, self._ph_r, self._pk_alpha_r)
        self.update()

    def _draw_bar(self, p, x, y, bw, bh, val, pk, pk_alpha):
        # Fondo redondeado igual al resto de paneles
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(6, 6, 6, 230))
        p.drawRoundedRect(x, y, bw, bh, 5, 5)

        # Relleno de nivel con clip path redondeado
        fh = int(bh * val)
        if fh > 0:
            g = QLinearGradient(0, y + bh, 0, y)
            g.setColorAt(0.00, QColor(THEME["vu_green"]).darker(150))
            g.setColorAt(0.50, QColor(THEME["vu_green"]))
            g.setColorAt(0.72, QColor(THEME["vu_yellow"]))
            g.setColorAt(0.84, QColor(THEME["vu_red"]).lighter(130))
            g.setColorAt(1.00, QColor(THEME["vu_red"]))
            # Clip redondeado para que el relleno respete las esquinas
            path = QPainterPath()
            path.addRoundedRect(x, y, bw, bh, 5, 5)
            p.save()
            p.setClipPath(path)
            p.fillRect(x, y + bh - fh, bw, fh, QBrush(g))
            p.restore()

        # Líneas de escala semitransparentes
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(QPen(QColor(0, 0, 0, 55), 1))
        for i in range(1, 10):
            ly = y + int(bh * i / 10)
            p.drawLine(x + 2, ly, x + bw - 2, ly)

        # Borde exterior redondeado (igual al estilo de otros paneles)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(QPen(QColor(255, 255, 255, 18), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(x, y, bw - 1, bh - 1, 5, 5)

        # Marca peak-hold cinematográfica
        if pk > 0.02 and pk_alpha > 0:
            py = y + int(bh * (1.0 - pk))
            # Determinar color de la marca según zona
            if pk > 0.84:
                pk_rgb = QColor(THEME["vu_red"]).lighter(130)
            elif pk > 0.72:
                pk_rgb = QColor(THEME["vu_yellow"])
            else:
                pk_rgb = QColor(THEME["vu_green"])
            pk_rgb.setAlpha(pk_alpha)
            # Línea principal
            p.setPen(QPen(pk_rgb, 2, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(x + 2, py, x + bw - 3, py)
            # Pequeño halo difuso encima/abajo
            halo = QColor(pk_rgb); halo.setAlpha(pk_alpha // 4)
            p.setPen(QPen(halo, 1))
            p.drawLine(x + 2, py - 1, x + bw - 3, py - 1)
            p.drawLine(x + 2, py + 1, x + bw - 3, py + 1)

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height(); gap = 6; bw = (w - gap) // 2
        # FIX-VU-BLACK-RECT (v0.22.02): CompositionMode_Clear sobre un widget con
        # WA_TranslucentBackground produce un rectángulo negro opaco cuando el padre
        # no tiene composición real (LoritoAldhiroStudio es un QWidget sólido).
        # Se elimina el paso Clear; _draw_bar ya pinta su propio fondo redondeado
        # oscuro semitransparente que cubre el área correctamente sin cuadrado negro.
        self._draw_bar(p, 0,       0, bw, h, self._val_l, self._pk_l, self._pk_alpha_l)
        self._draw_bar(p, bw + gap, 0, bw, h, self._val_r, self._pk_r, self._pk_alpha_r)
        # Glow analógico en bordes: intensidad proporcional al RMS
        _rms = max(self._val_l, self._val_r)
        if _rms > 0.05:
            _ga = int(min(52, _rms * 90))
            if _rms > 0.72:
                _gc = QColor(int(THEME["vu_red"][1:3],16),
                             int(THEME["vu_red"][3:5],16),
                             int(THEME["vu_red"][5:7],16), _ga)
            elif _rms > 0.42:
                _gc = QColor(int(THEME["vu_yellow"][1:3],16),
                             int(THEME["vu_yellow"][3:5],16),
                             int(THEME["vu_yellow"][5:7],16), _ga)
            else:
                _gc = QColor(int(THEME["vu_green"][1:3],16),
                             int(THEME["vu_green"][3:5],16),
                             int(THEME["vu_green"][5:7],16), _ga)
            p.setBrush(Qt.NoBrush)
            for _off in (2, 1):
                _alpha = _ga * (2 - _off) // 2
                _gc.setAlpha(_alpha)
                p.setPen(QPen(_gc, 1))
                p.drawRoundedRect(-_off, -_off, w + _off*2 - 1, h + _off*2 - 1, 5 + _off, 5 + _off)
        if getattr(self, "_quality", "VALID") != "VALID":
            # Dato viejo/no disponible: velo visible (nunca pasa por "silencio").
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 140))
            p.drawRoundedRect(0, 0, w, h, 5, 5)
        p.end()
