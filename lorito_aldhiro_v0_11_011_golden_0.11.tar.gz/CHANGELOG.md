# CHANGELOG — Lorito Aldhiro

Registro de cambios introducidos en este tarball. Cada entrada representa
una **revisión de código** y eleva en 1 el tercer dígito de la versión
que cuenta las entradas `## [NNN]` de este archivo para calcular
`APP_VERSION` de forma automática, sin tocar código
(`lorito_aldhiro/backend/core/lorito_version.py`).

Cuando una entrada requiere una explicación técnica extensa (qué se tocó,
por qué, riesgos, pasos siguientes), se enlaza a un **gap de referencia**
en `/gaps/GAP-NNN.md`. No todas las entradas necesitan un gap.

El formato de cada entrada es:

```
## [NNN] — AAAA-MM-DD — Título breve
Gap de referencia: gaps/GAP-NNN.md   (si aplica)

Descripción de lo que cambió.
```

---

## [088] — 2026-10-13 — LCD Display para Lorito: overlays de sus funciones, tamaños de letra fijos, carretes vectoriales que giran, corazón y retiro de los hubs
Gap de referencia: [gaps/GAP-085.md](gaps/GAP-085.md)

- El registro de overlays del LCD es de Lorito
  (`backend/export/lorito_lcd_overlays.py`): 44 overlays, solo de
  funciones que Lorito tiene (cinta, scrubs, ITL, SIPA, desborde, NR, HX
  Pro, MPX, monitor, sus DSP PREVI, exportación y Fnc No Disp). Se retiran
  los de funciones que solo existen en CRAC. API con nombres de Lorito:
  `showLcdOverlay`, `lcd_overlay`, tokens `LCD_*`.
- Tamaños de letra fijos en el LCD: el contómetro, 56 px, es la referencia
  y los overlays usan ese mismo tamaño. Un overlay más ancho que su área se
  desplaza como marquesina en vez de achicarse. Leyendas: 8 px en las filas,
  7 px en la columna izquierda y 6 px en la derecha.
- Carretes vectoriales con antialiasing (sin escalonado en las tomas): la
  forma del carrete de la usuaria se traza como ruta vectorial.
- Corazón negro a la altura de los carretes, centrado bajo la celda DOLBY S.
- Los carretes orquestan el movimiento: la cinemática de los hubs del panel
  de duración de cinta (grabación, ω = v/R por bobina, OTROS/SOBRANTE,
  volteo, tambaleo por desborde) y del panel de log (reproducción,
  Velocista, Morpher, Seek) se migra a
  `backend/playback/lorito_reel_kinematics.py`. Se retiran los hubs de
  ambos paneles.

## [087] — 2026-10-13 — LCD Display: leyendas centradas, celdas PREVI/TAU/COSANI/EXPORT, overlays del VFD de CRAC, carretes de cassette y fuente alarm clock
Gap de referencia: [gaps/GAP-084.md](gaps/GAP-084.md)

- Todas las leyendas de las celdas del LCD quedan centradas en su celda,
  en horizontal y en vertical.
- Dos celdas nuevas arriba (PREVI, TAU) y dos abajo (COSANI, EXPORT). Se
  encienden mientras haya armado un overlay de su familia funcional.
- Los 213 mensajes overlay del VFD display de CRAC 0.37.512 se migran al
  LCD (`backend/export/lorito_crac_vfd_overlays.py`), cada uno registrado
  en su familia. Solo overlays mostrables en el VFD. `DigitalClock.showCracOverlay(token)` los muestra con la
  duración que tenían en CRAC.
- SIPA, desborde de cuentavueltas, ITL y función no disponible: se
  revisaron en todas las superficies de CRAC y quedan registrados sus
  overlays del VFD (SIPActiV, SIPApatrM/SIPAchiVH/SIPAnLm, OvFlow TP,
  FnSide A, FnTape Aldh/Ar, Reversing <, Fnc No Disp). Por corrección de
  la usuaria se excluyen los mensajes internos o de CAROLAVENTOS ("TU
  CINTA ES MUY LARGA... UPS!!", "ITL — FIN DE CINTA", "AUTO-PAUSA —
  SILENCIO", "FUNCION NO DISPONIBLE") y "FnSide B" (al final del Lado B
  va "FnTape Aldh"). Los que Lorito ya disparaba tienen el mismo texto
  que en CRAC.
- Conectados a funciones que Lorito ya tiene: "Tape C-60/C-90/Othr Tape"
  al cambiar de cinta; "( ChristCOSH )", "LolGanchFin" y "LuchEnloqD -
  {letra} )" al armar esos DSP PREVI (antes "PREVI DSP — ...").
- Carretes de cassette (imagen de la usuaria) en una celda invisible del
  ángulo superior derecho de la megacelda del contómetro: el carrete y su
  pareja más pequeña, deformados para verse inclinados en horizontal. El
  contómetro y los overlays se dibujan por debajo, sin tocarlos.
- El contómetro y sus overlays usan la fuente alarm clock (la del VFD de
  CRAC) en lugar de Patopian 1986, cuya "V" (y X, B, D) tenía segmentos
  incompletos: por eso la "V" de VerLcha se veía cortada.
- `lcd_ascii()` adapta al LCD lo que alarm clock no trae: acentos, Ñ, µ,
  rayas, "…", emojis y saltos de línea. Un overlay largo baja hasta 14 px
  y, si aun así no cabe, se recorta con "..." dentro de su celda.

## [086] — 2026-10-13 — LCD Display en cuadrícula angular: contómetro abajo-izquierda, leyendas arriba-derecha, onda más alta, Media Anim contenido
Gap de referencia: [gaps/GAP-083.md](gaps/GAP-083.md)

- Las celdas del LCD forman una cuadrícula de marcos rectos.
- Cada leyenda va pequeña en el ángulo superior derecho de su celda.
- El contómetro y los overlays van en el ángulo inferior izquierdo de su
  megacelda, con margen y ajustados a ella (antes el overlay del
  Velocista la desbordaba).
- La celda de la onda bamboleante pasa de 1/4 a 1/2 del alto del bloque
  superior.
- El Media Anim se reduce al 80 % de su celda.
- Pruebas nuevas en `tests/test_lcd_grid.py`. Capturas en
  `saneamiento_0_11_009/capturas/`.

## [085] — 2026-10-12 — Pieles SVG del lienzo: madera, Metaloric Panel, LCD Display, Panascrub y vúmetros (retira la madera pintada con Qt)
Gap de referencia: [gaps/GAP-082.md](gaps/GAP-082.md)

- Se retira el fondo de madera pintado con código Qt (`paint_wood_canvas`).
  Fallaba en cada repintado: importaba `QPointF` desde `QtGui` y dejaba el
  QPainter abierto. El lienzo se sustituye por completo por el SVG de
  madera de la usuaria.
- Los SVG del Metaloric Panel (visor de señal + estado + duración de
  cinta), del LCD Display (contómetro ámbar + LED + botones), del Panascrub
  (3 Scrubs) y de los vúmetros (REC VU / PLAY VU, escala dBFS) se adaptan
  al tamaño real de cada widget y a las leyendas de Lorito.
- Se retiran los acabados pintados a mano que las pieles reemplazan.
- Los scrubs usan el mismo margen para pintar y para el ratón (antes
  había un desfase de 2 px).
- Las columnas laterales del LCD ya no recortan sus leyendas.
- Corregido un defecto del Transport Core: los comandos aplicados con el
  ring lleno no llegaban a CONFIRMED. Tiene prueba de regresión.
- Capturas en `saneamiento_0_11_008/capturas/`.

## [084] — 2026-10-12 — Cierre de las cinco Órdenes Golden 0.11.001: verificación, documentación y release 0.11.007
Gap de referencia: [gaps/GAP-081.md](gaps/GAP-081.md)

Verificación final de las cinco refundaciones (entradas 079–083) con la
batería completa, en plano y con `-W error::ResourceWarning`. Se añaden el
estado consolidado por hallazgo (`ORDENES_GOLDEN_0_11_ESTADO.md`), las
referencias de investigación técnica (`REFERENCIAS_INVESTIGACION_TECNICA.md`),
el lockfile de dependencias (`requirements.lock.txt`) y el paquete
`saneamiento_0_11_007/` (manifiesto SHA-256, informe de pruebas, salida de la
corrida). El tarball sale limpio, sin `__pycache__` ni `.pyc` (EX-14).
**Ninguna orden se declara GOLDEN**: quedan las puertas de hardware (soak,
loopback, CRAC 0.36, escucha ciega, referencias Dolby/dbx, firmas).

## [083] — 2026-10-12 — Orden Golden Scrubs Morpher / Velocista / Seek: Transport Core como autoridad única de PlaybackEngine
Gap de referencia: [gaps/GAP-080.md](gaps/GAP-080.md)

`PlaybackEngine` reescrito:

- `TransportMachine` y `SpeedPlanner` como autoridad única;
- transacciones de transporte ordenadas y confirmadas;
- ring SPSC preasignado de bloques etiquetados por generación;
- callback que solo copia;
- lector de velocidad variable con cursor absoluto (SMV-13);
- política de transición por operación (DIP en seek, continua en
  velocidad, fundido en EOF y STOP).

Se retiran el resampleo por chunks, el crossfade en plena transición, los
eventos ad hoc, los debounces y el estado forense global. La GUI emite
comandos semánticos. Se añaden 18 pruebas Golden, el banco de
discontinuidades y cinco documentos.

## [082] — 2026-10-12 — Orden Golden de Instrumentación / ITL / Telemetría
Gap de referencia: [gaps/GAP-079.md](gaps/GAP-079.md)

Nueva rama `backend/telemetry/` con:

- medidor dBFS por ventana de frames y peak-hold por tiempo;
- envolventes por canal con vista absoluta y normalizada;
- `TapeModel`/`TimelineAuthority`;
- bitácora forense JSONL con prioridad P0 no descartable.

ITL con reloj desde frames, volteo y stop exactamente una vez, y SIPA por
timestamps. Se corrigieron tres defectos reales:

- el interbloqueo del autostop;
- el peak-hold dependiente de los ticks;
- OTROS heredaba los automatismos de C-90.

## [081] — 2026-10-12 — Orden Golden DSP PREVI / NR: contrato único, reconfiguración transaccional y banco de fidelidad
Gap de referencia: [gaps/GAP-078.md](gaps/GAP-078.md)

- Contrato DSP único con errores tipificados.
- Adaptador de bloque fijo: 15 configuraciones dependían del tamaño de
  bloque y ahora todas son invariantes.
- Guarda de finitud con DEGRADED y telemetría por etapa.
- `reconfigure()` transaccional sobre todas las etapas.
- `NR_FIDELITY_BENCH.md`: todos los perfiles NR quedan clasificados como
  APROXIMACIÓN.

## [080] — 2026-10-12 — Orden Golden de Exportación: ExportService como única ruta, finalización durable y verificada
Gap de referencia: [gaps/GAP-077.md](gaps/GAP-077.md)

- La GUI exporta solo por `ExportRequest` → `ExportService` →
  `ExportSession` → `AtomicFinalizer`. Etapas: fsync del parcial,
  validación independiente, contabilidad de frames, SHA-256, rename, fsync
  de directorio, sidecar atómico y relectura posterior.
- Se eliminan `_build_export_array`, `lorito_exporters.py` y
  `USE_STREAMING_EXPORT`.
- Corregido un bloqueo real del decodificador de validación de ffmpeg (stdin
  heredado).

## [079] — 2026-10-12 — Orden Golden de Captura: ring SPSC sin pérdida silenciosa, FrameLedger, FSM y cierre en fases
Gap de referencia: [gaps/GAP-076.md](gaps/GAP-076.md)

- `SPSCCaptureRing` sin locks, sin sobrescritura ni truncamiento.
- Fail-stop por defecto.
- `FrameLedger` reconciliado.
- `CaptureSessionFSM` con generación.
- `request_stop()`/`finalize()` con barrera flush+fsync y resultados de
  cierre explícitos.
- Clasificación archivística basada en evidencia.
- Ruta DERIVED separada del RAW.

## [078] — 2026-09-18 — FASE 12 (§24): Release Candidate — cierre formal de la Orden Maestra de Ingeniería (12/12 fases) y salto de versión a 0.11
Gap de referencia: [gaps/GAP-075.md](gaps/GAP-075.md)

Cierra la "Orden Maestra de Ingeniería: Saneamiento, integración y
consolidación de Lorito Aldhiro" (12 fases, iniciada en sesiones
previas). Verificación final: suite completa 598/598, 0 fallidos (1
skip preexistente sin relación), dos corridas limpias consecutivas
(plana + `-W error::ResourceWarning`, ~162s cada una), más
`lorito_bootstrap.py` reverificado explícitamente una vez más — la
misma disciplina de ejecución real (§29) que cerró cada fase
anterior, repetida aquí como último paso antes del salto de versión.
Con las 12 fases cerradas (1=contratos/errores, 2=archival state,
3=streaming export, 4=transport core [deferido con decisión de
riesgo, GAP-068], 5=morpher/velocista [ídem], 6=Muscle EQ, 7=God
Object [deferido, GAP-071], 8=separación backend/frontend, 9=
integración capture→playback [GAP-072], 10=fault injection completo
+ 1 defecto real corregido [GAP-073], 11=soak sintético parcial
[GAP-074, declarado explícitamente NO literal frente a §23], 12=este
mismo cierre), se cumple la condición que el usuario fijó de
antemano para elevar la versión: `APP_MINOR` pasa de 10 a 11 y
`_MINOR_REVISION_BASE` de 50 a 77 en
`lorito_aldhiro/backend/core/lorito_version.py` (mismo patrón de
salto ya usado en 0.05→0.06/0.06→0.07/0.07→0.08/0.08→0.09/0.09→0.10),
con lo que esta misma entrada computa como versión **0.11.001**. Se
empaqueta `saneamiento_0_11_001/` (RELEASE_MANIFEST.txt con SHA-256 de
cada archivo fuente, TEST_REPORT_0.11.001.md, _test_run_full.txt) y el
tarball correspondiente en `dist/`, siguiendo el mismo formato de
entrega ya usado en los releases 0.10.015/016/017. La próxima
auditoría profunda que el usuario ya anunció ("descontaminación de la
tubería de audio y DSP de hilos GUI y otras optimizaciones") queda
explícitamente fuera de alcance de esta entrada y reservada para una
sesión futura sobre esta base 0.11.

## [077] — 2026-09-18 — FASE 11: soak test SINTÉTICO (§23, Suite F) — "DSP directo" + "ciclos repetidos" como sustituto parcial de las 50h de reloj real
Gap de referencia: [gaps/GAP-074.md](gaps/GAP-074.md)

Implementa el sustituto sintético que `ESTADO_MAESTRO_CONSOLIDACION.md`
ya contemplaba para FASE 11 (50h de reloj real, imposible de sostener
en una sesión de chat): nuevo `tests/test_soak_synthetic.py` (4
tests). Eje "DSP directo": 6000 chunks (~8.5 min equivalentes) con
una cadena NR real y activa (DNL+ALC, elegida por ser de las más
livianas medidas) verificando cero NaN/Inf y RSS que se estabiliza
(no crece sostenido) a lo largo del volumen, más una corrida más
corta con una etapa cara (Muscle EQ+Dolby B). Benchmark real de cada
etapa DSP documentado en el GAP (de ~0.4ms/chunk en ALC a ~45ms/chunk
en Dolby S — combinadas, algunas cadenas corren más lento que tiempo
real en este sandbox). Eje "ciclos repetidos": 40 ciclos reales de
`DiskWriterV2` (extiende GAP-064 con verificación explícita de
hilos/RSS, no solo conteo) y 40 ciclos reales de arranque/cierre de
`PlaybackEngine` (nunca ejercitado así antes). Hallazgo real durante
la escritura: `flush(timeout=5.0)` en 100 ciclos costaba 251s por el
tope interno de `CE_DISK_FLUSH_SETTLE_MAX_S=2.0s` (GAP-064, no un
bug) — reducido a `timeout=0.15` y 40 ciclos sin perder señal. Suite
completa: 598/598, 0 fallidos (1 skip preexistente sin relación), con
y sin `-W error::ResourceWarning`. `lorito_bootstrap.py` reverificado.
Deja FASE 12 (Release Candidate) como el único trabajo restante de
las 12 fases.

## [076] — 2026-09-18 — FASE 10 QUEDA COMPLETA (§20): 4 escenarios de fault injection sobre PlaybackEngine + fix real de busy-spin en _audio_cb()
Gap de referencia: [gaps/GAP-073.md](gaps/GAP-073.md)

Cierra los 4 escenarios que quedaban pendientes de FASE 10: disco
lento, seek tardío, scrub rápido y desconexión de dispositivo de
salida, todos sobre `PlaybackEngine` real (nuevo
`tests/test_fault_injection_playback.py`, 6 tests). El escenario de
disco lento sostenido reveló un defecto REAL en `_audio_cb()`: tras
un refill fallido, si el chunk previo estaba agotado (no `None`) el
código no entraba al relleno de silencio y quedaba girando
(busy-spin) dentro del callback de audio en tiempo real durante todo
el tiempo que tardara el disco lento — el propio comentario ("nunca
stall") prometía justo lo que ese camino no cumplía. Corregido
comprobando ambos estados de "sin datos" tras el refill fallido
(`chunk is None` O `pos >= len(chunk)`), verificado con un script de
reproducción mínimo (antes: 72 callbacks reales y cero silencio
genuino en 0.6s bajo disco a 50ms/lectura, con underruns internos
>2700; después: 278 callbacks reales y silencio correcto cuando
corresponde). Además, la escritura de estos tests encontró dos falsos
negativos reales del propio arnés (mutar `sys.modules["soundfile"/
"sounddevice"]` en vez de `pe.sf`/`pe.sd` directamente, invisible en
aislamiento pero real bajo `unittest discover` por el mismo problema
de reimportación ya documentado desde GAP-036/037/041) — corregidos
mutando directamente el objeto que `PlaybackEngine` usa. Verificado
sin regresión contra `test_playback_engine_integration.py` (GAP-062)
y `test_capture_to_playback_integration.py` (GAP-072). Suite completa:
594/594, 0 fallidos (1 skip preexistente sin relación), 3 corridas
limpias (dos en plano, una con `-W error::ResourceWarning`).
`lorito_bootstrap.py` reverificado.

## [075] — 2026-09-18 — FASE 9 (§19): test de integración real "Capture → Playback del mismo audio"
Gap de referencia: [gaps/GAP-072.md](gaps/GAP-072.md)

Cierra el par de integración que §19 pedía explícitamente y que
ningún test cubría todavía: que el audio que la mitad "Capture" del
pipeline escribe a disco (segmento WAV PCM24 real, mismo escritor que
`DiskWriterV2`) sobrevive intacto al ser leído y reproducido por un
`PlaybackEngine` real. Nuevo
`tests/test_capture_to_playback_integration.py` (3 tests): (1) a
`speed_ratio=1.0` — confirmado en `_prefetch()` como passthrough real
(el resampleador se salta con `abs(ratio-1.0) <= 0.0005`) — el audio
entregado al driver simulado (`FunctionalOutputStream.captured`)
coincide muestra a muestra (dominio PCM24 ya cuantizado,
`atol=1e-6`) con lo originalmente escrito; (2) a `ratio=1.5`
(resampleador cúbico real activo), correlación >0.95 contra una
referencia independiente (`numpy.interp`, no el código bajo prueba);
(3) detector explícito de canal L/R invertido (tonos de 440Hz/660Hz
distinguibles por canal). Arnés reutilizado de
`test_playback_engine_integration.py` (GAP-062/063): `PlaybackEngine`
real con hilos reales, stubs funcionales de `soundfile`/`sounddevice`
reasignados directamente sobre el módulo ya importado. Suite
completa: 588/588, 0 fallidos (1 skip preexistente sin relación), con
y sin `-W error::ResourceWarning`, ambas corridas limpias.
`lorito_bootstrap.py` reverificado.

## [074] — 2026-09-18 — FASE 7: extracción de lógica pura de nombrado/formato de _do_export() (alcance acotado, ExportController completo diferido por decisión de riesgo)
Gap de referencia: [gaps/GAP-071.md](gaps/GAP-071.md)

Decisión: envolver `_do_export()` (`ExportMixin.export()`,
`lorito_mw_export.py`) en un `ExportController` completo (etiquetado
"riesgo medio") requeriría reestructurar la orquestación real de
exportación (hilo, emisiones de `_bridge`, mutación del global
`_status`, manejo de 4 categorías de excepción) sin forma de
verificarlo con la GUI real (PySide6 bloqueado en este sandbox) más
allá de los tests existentes — mismo criterio de riesgo que FASE 4/5
(GAP-068), diferido a una sesión con esa verificación disponible.
En su lugar: nuevo `backend/export/lorito_export_naming.py`
(`export_codec_extension()`/`export_speed_filename_tag()`/
`export_speed_display_suffix()`/`export_clip_tag()`) extrae
MECÁNICAMENTE la lógica pura de nombrado/formato de `_do_export()`,
sin tocar su orquestación real. 15 tests nuevos
(`tests/test_export_naming.py`), incluido un hallazgo real de
precisión de punto flotante en el umbral de velocidad (`abs(0.995-1.0)
> 0.005` es `True` pero `abs(1.005-1.0) > 0.005` es `False` —
representación binaria, no error de lógica; mismo tipo de hallazgo ya
documentado en GAP-062 para `speed_zone_coded_name`). Verificado
contra la suite REAL de exportación end-to-end existente
(`test_export_end_to_end_with_spec_file.py`, sin modificar ningún
assert) para confirmar cero cambio de comportamiento observable,
incluida la exportación real con velocidad ×1.5 que confirma el tag
`"_x1p50"` en el nombre de archivo real. Suite completa: 585/585, 0
fallidos, con y sin `-W error::ResourceWarning` (una corrida con esa
flag mostró el fallo transitorio de `ColaElasticaDisco`/`DiskWriterV2`
ya documentado desde GAP-052/064, sin relación con este GAP,
desaparecido en la repetición inmediata). `lorito_bootstrap.py`
reverificado.

## [073] — 2026-09-18 — FASE 7: retiro de código muerto + extracción de helpers puros de _on_speed_changed/_on_morpher_changed
Gap de referencia: [gaps/GAP-070.md](gaps/GAP-070.md)

Retirados `_resample_full_cubic()`/`_resample_block_cubic()`
(`lorito_mw_playback.py`, 1068→1027 líneas) — código muerto encontrado
y documentado en GAP-062, retirado aquí tras REPETIR la auditoría
exhaustiva desde cero (cero llamadores reales, cero cobertura de
test, cero llamador dinámico); el resampleo real de producción sigue
sin cambios en `PlaybackEngine`. Nuevo módulo
`backend/playback/lorito_playback_scrub_sync.py`
(`clamp_position_fraction()`/`speed_status_text()`) — extracción
MECÁNICA de dos fragmentos puros duplicados (4 y 3 sitios
respectivamente) dentro de `_on_speed_changed()`/
`_on_morpher_changed()`, reemplazados por llamadas a las funciones
compartidas sin tocar ninguna línea de la orquestación real de
`self._player`/Qt/hilos de esos dos métodos. 15 tests nuevos
(`tests/test_playback_scrub_sync.py`) cubren ambas variantes de guarda
de `clamp_position_fraction` (con/sin `total_secs`) y el formato exacto
de `speed_status_text` contra `_carol_speed_label`. Suite completa:
570/570, 0 fallidos, con y sin `-W error::ResourceWarning`.
`lorito_bootstrap.py` reverificado.

## [072] — 2026-09-18 — FASE 6 QUEDA COMPLETA: auditoría de cardinalidad de canales (§16) — resultado positivo real, sin defectos
Gap de referencia: [gaps/GAP-069.md](gaps/GAP-069.md)

Cierre del último pendiente de FASE 6 (Muscle EQ hardening):
"cardinalidad de canales sigue sin auditar" (GAP-062). 18 tests nuevos
(`tests/test_nr_coordinator_channel_cardinality.py`) ejercitan
`NRCoordinator(channels=1)` con chunks mono reales `ndim==1` a través
de cada uno de los 8 perfiles NR, HX Pro, ALC, MPX, EQ/BIAS (4 tipos
de cinta), Muscle Eq Samir, Cristhi Cosh, Antipestal, Versión O Tron,
los 20 sub-perfiles de Lucha Enloquecida (uno por uno, sin muestreo) y
la cadena COMPLETA con todo activo a la vez (incluida una guarda de
regresión en estéreo, chunks consecutivos sostenidos y
`reconfigure()` en caliente de estéreo a mono). Resultado: **positivo
real, sin defectos** — los 18 tests pasaron en la primera ejecución,
confirmando con ejecución real (no solo lectura de código) que la
cadena DSP ya maneja `channels` arbitrario correctamente desde su
diseño original (`mono = x.ndim == 1` consistente en cada perfil;
`FocusProfile` se autodesactiva y hace passthrough con `channels<2`
por diseño). Producción sigue usando siempre `CE_CHANNELS = 2` — este
GAP no introduce ninguna ruta de captura mono, audita que la cadena
SERÍA segura si alguna vez se usara. Con esto, FASE 6 queda completa
(sus 2 pendientes, política NaN/Inf y cardinalidad de canales, ambos
cerrados). Suite completa: 555/555, 0 fallidos, con y sin
`-W error::ResourceWarning`. `lorito_bootstrap.py` reverificado.

## [071] — 2026-09-18 — FASE 4/5: cierre formal (decisión documentada, sin swap riesgoso)
Gap de referencia: [gaps/GAP-068.md](gaps/GAP-068.md)

Cierre formal de FASE 4 (Transport Core) y FASE 5 (Morpher +
Velocista), sin cambios de código: se documenta y se deja registrada
la decisión de NO cablear `TransportMachine`/`SpeedPlanner`/
`GenerationGuard` (`backend/transport/`, 23 tests en aislamiento,
reconfirmado con `grep` que siguen sin ningún llamador de producción)
en lugar de la lógica interna actual de `PlaybackEngine` durante esta
Orden. Motivo doble: §29 de la Orden exige verificación con audio real
antes de integrar código de tiempo real a producción (este sandbox no
puede confirmar ausencia de pops/glitches audibles), y la propia
instrucción activa del usuario ya difiere ese trabajo explícitamente a
la auditoría siguiente (post-0.11, cuyo objetivo principal es
"la descontaminación de la tubería de audio y DSP de hilos GUI"), para
la cual `TransportMachine` (máquina de estados pura, sin
acoplamiento a hilos GUI) es la candidata natural. Se deja
documentado, sin ambigüedad, qué infraestructura queda lista para esa
sesión futura (fixture de audio real, stubs funcionales con hilos
reales, precedente de flag de migración `USE_CONTINUOUS_RESAMPLE`).
El motor ACTUAL de producción (`PlaybackEngine`) sigue con su defecto
real de deriva de fase corregido y verificado con audio real (GAP-062)
y su primera cobertura de integración de hilos reales (GAP-063,
incluida una carrera real corregida) — ambos ya cerrados, no
reabiertos por este GAP. Suite completa: 537/537, 0 fallidos, con y
sin `-W error::ResourceWarning`. `lorito_bootstrap.py` reverificado.

## [070] — 2026-09-18 — Puente ExportSessionReport↔normalization_stats + flag USE_STREAMING_EXPORT (FASE 3 QUEDA COMPLETA: 3/3 huecos cerrados)
Gap de referencia: [gaps/GAP-067.md](gaps/GAP-067.md)

Cierre del hueco (c) de FASE 3 ("no existe puente entre
`ExportSessionReport` y los ~15-19 campos `_status.normalization_*`
que consume la UI/spec file"), último de los 3 huecos identificados en
GAP-054 — con esto FASE 3 (Streaming Export) queda con sus 3 huecos
reales cerrados. `lorito_normalization_stats_bridge.py` (nuevo):
`export_resolved_mode_with_stats()`/`export_mid_side_with_stats()`
devuelven `(ExportSessionReport, stats: dict)` con la MISMA forma de
dict que el camino legado (`_apply_normalization_advanced`), calculada
a partir de las funciones `measure_*`/`compute_*` ya existentes en
`lorito_normalization_streaming.py` (sin reimplementar nada);
`apply_normalization_stats_to_status()` empaqueta el bloque de
asignación ya existente en `lorito_mw_export.py` como función
reutilizable; `USE_STREAMING_EXPORT = False` es el flag de migración
con rollback (mismo patrón que `USE_CONTINUOUS_RESAMPLE`), en `False`
por defecto porque este camino aún no se ha ejercitado contra
`lorito_mw_export.py` real (bloqueado por PySide6, no por diseño).

13 tests nuevos (`tests/test_normalization_stats_bridge.py`),
incluida verificación bit-a-bit contra el camino legado y contra
`export_resolved_mode()` puro. La ejecución de la suite COMPLETA (no
solo el archivo nuevo en aislamiento) expuso 1 falso positivo del
scanner de regresión `_status.` (GAP-056/057, ya documentado como
propenso a falsos positivos por operar sobre texto crudo, no AST) —
5 apariciones literales de `_status.normalization_*` en prosa de
docstring, corregidas sin tocar código real. Suite completa: 537/537,
0 fallos (1 skip preexistente), con y sin `-W error::ResourceWarning`.
`lorito_bootstrap.py` reverificado.

Alcance NO cubierto (documentado, no implementado): cableado real a
`lorito_mw_export.py` (bloqueado por PySide6); puentes equivalentes
para `export_tape_preset()`/`export_two_pass()` (árboles de decisión
independientes, mismo patrón mecánico de extensión).

## [069] — 2026-09-18 — Encoders streaming FLAC/OGG/WavPack (vía ffmpeg) + 4 defectos reales corregidos en la infraestructura común de encoders
Gap de referencia: [gaps/GAP-066.md](gaps/GAP-066.md)

Cierre del hueco (b) de FASE 3 ("faltan encoders streaming de
FLAC/OGG/WV"), parte del cierre completo de todos los frentes
pendientes de la Orden Maestra pedido explícitamente por el usuario
antes de elevar la versión a 0.11. `soundfile` no es instalable en
este sandbox, así que estos encoders nuevos (`FlacEncoder`,
`OggEncoder`, `WvEncoder`, `lorito_ffmpeg_stream_encoder.py`)
generalizan el patrón de pipe directo a un subproceso `ffmpeg` que
`WVExporter` (camino legado) ya usa en producción, al contrato
`Encoder` streaming (§23) y a PCM `f32le` crudo (sin conversión de
tipo de muestra en Python).

Escribirlos con EJECUCIÓN REAL (no solo diseño) contra el ffmpeg
instalado del sandbox sacó a la luz 4 defectos reales, 3 en el módulo
nuevo y **1 en `AtomicFinalizer` (código compartido por TODOS los
encoders, incluido `WavEncoder`)**:
1. `Popen.communicate()` tras cerrar `stdin` a mano → `ValueError`
   (el mismo patrón, sin probar, existe en `WVExporter._run_wv_pipe`
   del camino legado).
2. El decodificador de `ffmpeg` redondea streams Vorbis MUY cortos
   (<~1.1s) al alza — el contenedor es exacto (verificado con
   `ffprobe`), el defecto es solo del decode de vuelta. Corregido:
   `validate()` usa `ffprobe` (`duration_ts`/`time_base`) como método
   exacto primario, sin decodificar nada.
3. El encoder nativo `vorbis` de ffmpeg no admite audio mono (sin
   impacto práctico — este proyecto captura siempre en estéreo).
4. **El real**: `AtomicFinalizer.run()` limpiaba el `.partial` ANTES
   de llamar a `encoder.finalize()` en la ruta de fallo — para un
   encoder SÍNCRONO (`WavEncoder`) no importaba, pero para un encoder
   ASÍNCRONO respaldado por un subproceso, el archivo de salida podía
   no existir aún en ese momento y terminar de crearse DESPUÉS,
   dejando un `.partial` huérfano real (violación de §37/§38),
   reproducido con un `FlacEncoder` real fallando a mitad de stream.
   Corregido: `finalize()` ahora corre siempre ANTES de la limpieza,
   en ambas rutas (éxito y fallo) — comportamiento de `WavEncoder` sin
   cambios (sus 9 tests preexistentes siguen pasando igual).

También: `ffmpeg` necesita `-f <formato>` de salida EXPLÍCITO porque
`AtomicFinalizer` escribe primero a `final_path + ".partial"`, una
extensión que rompe la inferencia de muxer por extensión (invisible
probando un encoder aislado; solo aparece con `ExportSession` real de
punta a punta) — corregido con `_ffmpeg_container_format` declarado
por cada subclase.

17 tests nuevos (`tests/test_ffmpeg_stream_encoders.py`), contra
ffmpeg real (con `skipUnless` por codec disponible): round-trip
aislado por codec (estéreo/mono/~391 bloques), fallback de encoder,
modos de fallo, y `ExportSession` real de punta a punta por codec.
524/524 tests de la suite completa, con y sin
`-W error::ResourceWarning` (1 fallo intermitente YA documentado
desde GAP-052/GAP-064 en una corrida, limpio en la repetición
inmediata — no una regresión). `lorito_bootstrap.py` reverificado.

## [068] — 2026-09-17 — Resampleo streaming por velocidad, con conteo de frames exacto (sin deriva acumulada)
Gap de referencia: [gaps/GAP-065.md](gaps/GAP-065.md)

Cierre del hueco (a) de FASE 3 ("el resampleo por velocidad no tiene
equivalente streaming"), primer paso del cierre completo de todos los
frentes pendientes de la Orden Maestra pedido explícitamente por el
usuario antes de elevar la versión a 0.11.
`StreamingSpeedResampleTransform`/`expected_resampled_frames`
(`lorito_export_resample_transform.py`, nuevo) aplican
`resample_stateful_continuous()` (GAP-037/GAP-062) bloque a bloque
para `ExportSession`, con una técnica de "objetivo acumulado" (estilo
Bresenham) que GARANTIZA conteo de frames de salida EXACTO — sin
deriva sistemática acumulada, que de otro modo crece linealmente con
el número de bloques (medido con números reales: 2M frames, ~3906
bloques, deriva real y no-cero con el enfoque naíf). `ExportSession`
gana un parámetro `expected_output_frames` opcional (por defecto
`None` — cero cambio de comportamiento para los 9 tests preexistentes
de `test_export_streaming.py`) para que `AtomicFinalizer` (§28) valide
contra el conteo de SALIDA correcto cuando hay resampleo.

14 tests nuevos (`tests/test_export_resample_transform.py`),
incluyendo una sesión larga real (200 000 frames, ratio "feo") que
expondría `FrameAccountingError` si la técnica no funcionara, y un
ancla de regresión que mide la deriva real del enfoque naíf que este
GAP evita. 507/507 tests de la suite completa (493 previos + 14
nuevos). `lorito_bootstrap.py` reverificado.

## [067] — 2026-09-17 — `DiskWriterV2.flush()` ya no espera 30s sin motivo + investigación real de la flakiness de `ColaElasticaDisco` documentada desde GAP-052
Gap de referencia: [gaps/GAP-064.md](gaps/GAP-064.md)

Segunda continuación autónoma ("Continuar.") tras 0.10.016.
`DiskWriterV2.flush()` esperaba el `timeout` completo (30s por
defecto) en CADA llamada mientras el hilo de escritura seguía activo,
porque internamente esperaba sobre un `Event` que solo se marca
cuando el hilo TERMINA — confirmado con medición real (35.9s para un
test que solo captura 0.3s de audio). Corregido acotando esa espera a
un margen breve (`CE_DISK_FLUSH_SETTLE_MAX_S = 2.0s`, nueva
constante), sin tocar el hot path del hilo de escritura. Resultado:
35.9s → 7.9s para el test afectado; suite completa ~134s → ~96s. Test
de regresión permanente añadido, aislado (sin pasar por
`CaptureEngineV2` completo).

De paso, se investigó a fondo la flakiness intermitente de
`DiskWriterV2`/`ColaElasticaDisco` documentada desde GAP-052 y vuelta
a topar en GAP-063: se descartó con evidencia real (40 corridas,
conteo de hilos activos) la hipótesis de fuga de hilos, y se
reprodujo y explicó el mecanismo real (saturación de la cola elástica
bajo ruido de scheduling del sandbox, interactuando con un stub de
entrada deliberadamente más rápido que tiempo real) — comportamiento
de descarte POR DISEÑO, no un defecto de producción alcanzable con
hardware real. No se "corrige" (no aplica); se documenta con más
precisión.

493/493 tests (492 previos + 1 nuevo), con y sin
`-W error::ResourceWarning`. `lorito_bootstrap.py` reverificado
explícitamente.

## [066] — 2026-09-17 — Primera cobertura de integración con hilos reales de `PlaybackEngine` + carrera real corregida en `stop()`/`_play_loop`
Gap de referencia: [gaps/GAP-063.md](gaps/GAP-063.md)

Continuación autónoma ("Continuar.") tras 0.10.015. `PlaybackEngine`
(el motor de reproducción/scrub REAL en producción, el archivo con
más historial de bugs del proyecto) no tenía ningún test que lo
corriera con sus propios hilos — solo sus funciones de resampleo
puras se probaban en aislamiento. Se construyó infraestructura nueva
(stub funcional de `sounddevice.OutputStream`, tolerancia a
WAVE_FORMAT_EXTENSIBLE + `.seek()` en el stub de `soundfile`) y una
suite de 6 tests que instancia el motor real contra el fixture de
audio real del usuario. Al correrla se encontró y corrigió una carrera
real (no teórica) entre `PlaybackEngine.stop()` (hilo llamador) y el
bucle monitor de `_play_loop` (hilo propio del motor): `stop()` podía
poner `self._stream = None` justo cuando `_play_loop` leía
`self._stream.active`, produciendo un `AttributeError` no fatal pero
real en el 100% de las llamadas a `stop()` observadas. Corregido con
una copia local del stream, inmune a la reasignación desde otro hilo.
También se encontró y corrigió un problema de orden de import entre
archivos de test (mismo patrón ya conocido de GAP-036/037/041) que
hacía fallar la suite nueva solo al correr la batería COMPLETA, nunca
en aislamiento.

492/492 tests (486 previos + 6 nuevos), con y sin
`-W error::ResourceWarning`. `lorito_bootstrap.py` reverificado
explícitamente.

## [065] — 2026-09-17 — Audio real del usuario confirma y corrige deriva de fase en el resampler de scrub (FASE 4/5) + política FASE 6 (NaN/Inf, cuestionario) implementada + segundo corte de FASE 7
Gap de referencia: [gaps/GAP-062.md](gaps/GAP-062.md)

El usuario adjuntó `Sotalomafer1.mp3` (un cassette transdigitalizado
en CRAC 0.10) con tres pedidos: usarlo para las comparativas de sonido
de los Scrubs, continuar FASE 7, y lanzar un cuestionario para decidir
la política NaN/Inf de FASE 6.

**FASE 4/5**: repitiendo la metodología exacta de GAP-037 (referencia
Catmull-Rom real, sin clamps de borde) pero con 20s reales del clip
del usuario, se confirma cuantitativamente la deriva de fase de
`_resample_stateful()` en cada frontera de chunk de prefetch (error
real hasta ~70000× mayor que la corrección, en forward/reverse/
post-seek). `resample_stateful_continuous()` (ya construida en
GAP-037, sin conectar) queda cableada a producción en
`lorito_playback_engine.py` tras una flag `USE_CONTINUOUS_RESAMPLE`
(§26): nuevo slot `phase_history` en `_SpeedState`, reseteado en
lockstep con `phase_cursor` en los 2 puntos de reset, y los 4 sitios
reales de llamada del prefetch loop condicionados a la flag. Nuevo
`tests/test_resample_continuity_real_audio.py` (5 tests) con un
fixture real embebido de 5s (`tests/fixtures/sotalomafer1_scrub_5s.wav`).

**FASE 6**: cuestionario al usuario (4 preguntas) — se confirma el
statu quo de recuperación silenciosa (sin excepción en ningún sitio,
`DSPIntegrityError` sigue sin conectar) pero el conteo de saneamientos
(`NRCoordinator.nonfinite_counts`) ahora SÍ degrada la clasificación
archival: cualquier saneamiento >0 impide `ARCHIVAL_SAFE`, sin umbral,
en todas las etapas por igual. Implementado en
`backend/archival/lorito_archival_state.py` (nuevo parámetro opcional
`dsp_nonfinite_total`, retrocompatible) y
`CaptureEngineV2.classify_session()` (suma real de
`nr_coordinator.nonfinite_counts`). 6 tests nuevos, incluida
verificación con `NRCoordinator.process_chunk()` real sobre un bloque
con NaN/Inf reales.

**FASE 7**: auditado `lorito_mw_playback.py` (1099 líneas) — extraída
`_speed_zone_coded_name` (activa en producción, sin cobertura previa)
a `backend/playback/lorito_speed_zone_labels.py` (1099→1068 líneas),
12 tests de frontera exacta. Hallazgo real: `_resample_full_cubic`/
`_resample_block_cubic` en el mismo archivo son código MUERTO (cero
llamadores, cero tests) — documentado, no retirado.

Práctica de GAP-054 reconfirmada tres veces: `lorito_bootstrap.py`
reverificado explícitamente tras cada una de las tres partes.

Verificación: **486/486 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (463 preexistentes + 5 resampler audio
real + 6 FASE 6 + 12 speed zone labels). `/ESTADO_MAESTRO_
CONSOLIDACION.md` actualizado. Versión NO elevada a 0.11.

---

## [064] — 2026-09-17 — FASE 2 (§8): `classify_session()` conectado al cierre real de sesión — cierra el pendiente de GAP-052
Gap de referencia: [gaps/GAP-061.md](gaps/GAP-061.md)

GAP-052 construyó `CaptureEngineV2.classify_session()` pero lo dejó
sin conectar al flujo real de cierre de sesión, citando una decisión
de presentación no tomada. Cerrado con la opción más conservadora ya
anticipada entonces: una llamada agregada en `_stop_worker()`
(`lorito_mw_recording.py`), justo después de `disk_writer.stop()` (los
segmentos ya cerrados y checksumeados), que guarda el resultado en
`self._last_archival_classification` — sin construir ninguna señal Qt
nueva ni cambiar la UI. Envuelto en `try/except` (mismo criterio
defensivo que el resto del método): un fallo al clasificar no impide
que el resto del cierre de sesión siga su curso. Con esto, §8 de la
Orden ("el sistema de archivo debe convertirse en parte OBLIGATORIA
del cierre de sesión") queda satisfecho de verdad — antes, el
subsistema solo era alcanzable desde tests.

Nuevo `tests/test_stop_all_classifies_session.py` (2 tests) dispara
`stop_all()` real con segmentos y checksums reales, confirmando que
una sesión sana termina `ARCHIVAL_SAFE` y una corrupta termina
`INVALID`. Hallazgo real de infraestructura de test: una carrera
genuina entre `Thread.start()` (retorna en el hilo padre) y el
registro del hilo hijo en `threading.enumerate()` (ocurre dentro del
hilo hijo) causó un fallo intermitente — corregido con sondeo breve en
vez de una comprobación inmediata única, mismo patrón ya usado en
`test_fault_injection_dsp_exception.py`.

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **463/463 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (461 preexistentes + 2 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado — FASE 2 ahora completa
del todo. Versión NO elevada a 0.11.

---

## [063] — 2026-09-17 — Cobertura end-to-end real de exportación (resampleo, normalización, FLAC, OGG) nunca antes ejercitada + fix de una limitación real del stub de señales
Gap de referencia: [gaps/GAP-060.md](gaps/GAP-060.md)

En vez de continuar mecánicamente la extracción de FASE 7
(rendimientos decrecientes tras GAP-056), se aplicó el patrón de mayor
valor de esta sesión: buscar ramas de `_do_export()` nunca ejercitadas
con ejecución de punta a punta real. Encontradas 3: resampleo por
velocidad (§3c — la función en sí ya tenía test en aislamiento, pero
su conexión real dentro del flujo de exportación, no), normalización
avanzada (§3b, ~57 líneas con 18 asignaciones a `_status.
normalization_*`, siempre saltada porque el test usaba "Sin
normalizar" por defecto), y los codecs FLAC/OGG (vía `ffmpeg` real,
disponible en este sandbox — confirmado antes de escribir los tests).
`tests/test_export_end_to_end_with_spec_file.py` extendido de 1 a 4
tests. Ningún defecto nuevo en la lógica de negocio — las 4 ramas
funcionan correctamente.

**Hallazgo real de infraestructura de test** (no de producción): el
test de FLAC reveló que `_SignalStub.emit()` (`tests/test_stability_
patch.py`, usado por `_install_stub_modules()` en gran parte de la
batería) no replicaba un comportamiento genuino y válido de Qt — una
señal puede conectarse a un slot que acepta MENOS parámetros de los
que la señal emite (Qt descarta los sobrantes; patrón real usado en
`codec_box.currentTextChanged.connect(self._update_codec_ui)`). El
stub pasaba siempre todos los argumentos, produciendo un `TypeError`
ante un patrón que en producción funciona sin problema — un falso
positivo de la infraestructura de test. Corregido: `emit()` ahora
introspecciona la firma del callback y trunca los argumentos a su
aridad real. Verificado que el cambio (en infraestructura compartida)
no rompe ningún test existente.

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **461/461 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (457 preexistentes + 4 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [062] — 2026-09-17 — FASE 10 continuación: NaN/Inf real en la cadena DSP — verifica el comportamiento existente sin reabrir la decisión de política pendiente de FASE 6
Gap de referencia: [gaps/GAP-059.md](gaps/GAP-059.md)

Nuevo `tests/test_fault_injection_nonfinite_dsp.py` (9 tests) — inyecta
NaN/Inf reales en `NRCoordinator`/`sanitize_finite` (clases de
producción, no reimplementadas). Deliberadamente NO toca la decisión
de política pendiente de GAP-051 (`DSPIntegrityError` sin conectar):
verifica el comportamiento EXISTENTE (sanear + contar + resetear la
etapa), no lo cambia. Cubre: `sanitize_finite()` en aislamiento (NaN→0,
Inf→clip con signo correcto, camino sano sin copia, determinismo);
NaN/Inf en la entrada de la cadena (nunca llega a ninguna etapa,
conteo acumulativo correcto); y el caso más importante — una etapa
cuyo cómputo interno produce NaN/Inf de verdad (simula un filtro IIR/
EMA real vuelto inestable, no un passthrough del NaN de entrada):
salida final siempre finita, conteo atribuido a la etapa correcta, la
etapa se resetea para no envenenar su recursión permanentemente,
incluso en el caso extremo de fallar en 10 llamadas seguidas sin que
el pipeline se caiga.

Ningún defecto encontrado — tercera vez en esta sesión de trabajo que
Fault Injection confirma con ejecución real que una protección
documentada existe de verdad (ver también GAP-058).

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **457/457 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (448 preexistentes + 9 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [061] — 2026-09-17 — FASE 10 (Fault Injection, §22) — ENOSPC/EIO en exportación y excepción DSP en el drain loop, ambos verificados con ejecución real
Gap de referencia: [gaps/GAP-058.md](gaps/GAP-058.md)

Barrido de seguimiento previo: los otros 8 singletons globales
conocidos del proyecto (`_clip_log`, `_xrun_forensics`, `_psi_
monitor`, `_stress_test`, `_integrity_monitor`, `_frn_writer_worker`,
`_snapshot_worker`, `_crash_guard`) auditados con la misma técnica que
encontró el bug de `_status` (GAP-056/057) — cero problemas
encontrados, confirma que estaba aislado a lo ya corregido.

**ENOSPC/EIO en exportación** (`tests/test_fault_injection_export.py`,
4 tests): un `WavEncoder` real cuyo `write()` falla de verdad tras N
llamadas (no un mock genérico) inyecta fallos de disco a mitad de
codificación y durante el rename atómico sobre `AtomicFinalizer`/
`ExportSession` reales. Confirma: abort limpio sin `.final` ni
`.partial` huérfano, excepciones tipificadas correctas
(`ExportError`/`ExportFinalizeError` según la etapa), resultado
determinista en corridas repetidas. Ningún defecto nuevo — confirma
que la arquitectura de errores de FASE 1 (GAP-051) funciona bajo
fallos reales de disco.

**Excepción DSP en el drain loop** (`tests/test_fault_injection_dsp_
exception.py`, 3 tests): el código documenta en un comentario que
cualquier excepción de una etapa DSP se registra y esa iteración cae a
los bloques sin procesar, sin perder la sesión — no se asumió que el
comentario fuera correcto. Se llamó a la función REAL de producción
(`_drain_loop_fn`) en un hilo real, con `RingBufferAbsorcion`/
`ColaElasticaDisco` reales, con una etapa DSP que falla deliberadamente
(desde la 1ª llamada, desde la 3ª, o siempre). Confirmado con ejecución
real en los 3 casos: el drain loop no se cae, ningún frame se pierde.
Ningún defecto encontrado — resultado positivo real, no asumido.

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **448/448 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (441 preexistentes + 7 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [060] — 2026-09-17 — Seguimiento de GAP-056: verificación con ejecución real de los 3 archivos restantes — dos métodos corrían en QTimers reales cada 1 y 5 segundos, sin condición, toda sesión de uso
Gap de referencia: [gaps/GAP-057.md](gaps/GAP-057.md)

Cierra el pendiente explícito de GAP-056: verificado con `LoritoAldhiroStudio()`
real bajo stubs que los 6 métodos directamente invocables de los 3
archivos no verificados en la sesión anterior (`start_record`,
`toggle_pause`, `_on_rec_engine_ready` en `lorito_mw_recording.py`;
`_update_internal_status`, `_archival_tick` en `lorito_mw_telemetry.py`;
`_activate_silence_autopause`, `_deactivate_silence_autopause` en
`lorito_mw_silence_autopause.py`) corren limpios tras el fix.

**Hallazgo adicional real**: `_update_internal_status`/`_archival_tick`
están conectados a `QTimer` reales arrancados INCONDICIONALMENTE en
`__init__` de `LoritoAldhiroStudio` (1 Hz y cada 5 s respectivamente) —
antes del fix de GAP-056, el `NameError` no era un fallo puntual al
exportar: era recurrente, cada 1 y cada 5 segundos, durante TODA
sesión real de uso de la aplicación, desde el momento en que la
ventana principal terminaba de construirse. `start_record()` también
resetea `_status.frames_received`/etc. como parte de sus primeras
operaciones — iniciar una grabación real también habría fallado ahí.

Nuevo `tests/test_status_fix_real_execution.py` (6 tests) formaliza la
verificación de forma permanente. Confirmado que detecta el bug si se
reintroduce. Nota de honestidad documentada en el propio GAP: uno de
los 6 tests no detectó la reversión en su primera prueba porque el
estado del `app` recién construido toma una rama que no llega a tocar
`_status` en esa invocación puntual — la garantía completa sigue
siendo el test estático de GAP-056, estos son verificación real
adicional, no sustituto de cobertura de ramas exhaustiva.

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **441/441 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (435 preexistentes + 6 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [059] — 2026-09-17 — FIX CRÍTICO: `_status` sin importar en 4 archivos (112 usos) — toda exportación real terminaba en error pese a producir un archivo válido — + primer corte real de FASE 7
Gap de referencia: [gaps/GAP-056.md](gaps/GAP-056.md)

**Fix crítico** (encontrado verificando FASE 7 con el mayor rigor
posible, disparando `export()` completo en vez de solo las funciones
extraídas en aislamiento): el global `_status` (`BackendStatus`,
`backend/audio/lorito_audio_backend.py`) se usaba en 112 sitios de 4
archivos (`lorito_mw_export.py`, `lorito_mw_recording.py`, `lorito_mw_
telemetry.py`, `lorito_mw_silence_autopause.py`) sin haberse importado
NUNCA — `NameError` garantizado. Los 4 archivos ya importaban otras
cosas del mismo módulo; solo faltaba `_status` en esa línea. Mismo
patrón que GAP-053/054/055 (una migración que no propagó una
referencia a todos los sitios), pero más grave en la práctica: no
impedía arrancar la app, así que pasó desapercibido — significa que
toda exportación real terminaba mostrando un error al usuario aunque
el archivo de audio ya se hubiera escrito correctamente, y el archivo
"Aldhira de Especificación de CRAC" nunca llegó a generarse. Corregido
(una línea por archivo). Nuevo test de regresión permanente
(`test_status_global_is_imported_everywhere_it_is_used`) — confirmado
que detecta el bug exacto si se reintroduce en cualquiera de los 4
archivos.

**FASE 7 (§13, primer corte real)**: nuevo `backend/export/lorito_
export_session_spec.py` — extracción mecánica (no un rediseño) de la
lógica pura de `_do_export()` sin ninguna dependencia de Qt: el
chequeo de integridad end-to-end y la construcción completa del texto
del "Aldhira de Especificación de CRAC" (incluidos los 3 casos del
cuentavueltas C-60/C-90). `lorito_mw_export.py` bajó de 725 a 637
líneas. 21 tests de regresión de texto EXACTO, carácter a carácter,
contra el código original — más un test end-to-end real que dispara
`export()` completo bajo stubs (fue precisamente ESTE test el que
encontró el bug de `_status` de arriba). La orquestación de hilos/Qt
sigue en el mixin — un `ExportController` completo queda para una
sesión futura.

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **435/435 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (412 preexistentes + 23 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [058] — 2026-09-17 — Auditoría de FASE 4 (Transport Core) + avance real de FASE 9 (Suite B, §19) — integración cruzada Export↔Archival
Gap de referencia: [gaps/GAP-055.md](gaps/GAP-055.md)

**FASE 4 (Transport Core)**: auditado, no cableado — mismo perfil de
riesgo que FASE 3 (GAP-054). `TransportMachine`/`SpeedPlanner`/
`GenerationGuard` confirmados sin ningún uso de producción.
`PlaybackEngine` gestiona posición/velocidad con lógica propia y
ajustes RT históricos (anti-pop, FIX-SNAP-FROZEN-HEAD) verificados
únicamente por ausencia de pops audibles en uso real — la GUI llama
directamente a sus métodos sin ninguna mediación. Caracterizado con
precisión, no cableado a medias.

**FASE 9 (Integration tests, §19 Suite B)**: avance real. Nuevo
`tests/test_integration_capture_segment_export_archive.py` (5 tests)
— construye segmentos WAV reales con checksums reales y los ejercita a
través de `ExportSession` (FASE 1) Y `classify_session()` (FASE 2)
JUNTOS, en el mismo escenario, cerrando un hueco real: cada subsistema
tenía cobertura sólida por separado, pero ninguno se había probado en
conjunto sobre la misma sesión. Hallazgo real: un bit-flip en un
segmento ya cerrado que no cambia el tamaño del archivo **pasa sin
abortar por `ExportSession`** (no verifica checksum por diseño, nunca
fue su responsabilidad) pero **sí lo detecta `classify_session()`**
(INVALID, `checksum_verified=False`) — confirma con ejecución real la
división de responsabilidades entre exportación (§4) e integridad
patrimonial (§9), documentado para que ningún trabajo futuro de FASE 3
asuma una garantía de integridad de contenido que la ruta de
exportación nunca prometió.

Práctica de GAP-054 reconfirmada: `lorito_bootstrap.py` reverificado
explícitamente antes de cerrar.

Verificación: **412/412 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (407 preexistentes + 5 nuevos).
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [057] — 2026-09-17 — Auditoría profunda de FASE 3 (Streaming Export) + fix real de FASE 8 (backend/frontend) — misma familia de bug que GAP-053
Gap de referencia: [gaps/GAP-054.md](gaps/GAP-054.md)

**FASE 3 (Streaming Export, P0.1)**: auditoría profunda que encuentra
el alcance real del swap pendiente — 3 huecos concretos, ninguno
cableado todavía: (1) el resampleo por velocidad no tiene equivalente
streaming, (2) solo existe encoder streaming para WAV (no FLAC/OGG/WV),
(3) no existe puente entre `ExportSessionReport` y los ~15 campos
`_status.normalization_*` que consumen la UI y el archivo de
especificación de sesión. El módulo de normalización streaming en sí
(1239 líneas, 20 modos, presets, AUTO, TWO_PASS, reutilizando la
matemática exacta de los módulos legados) está completo — su propio
docstring decía estar bloqueado por falta de PySide6 ejecutable, una
afirmación desactualizada desde GAP-036. No se cableó esta sesión: el
puente de estadísticas por sí solo merece su propia verificación
dedicada, no una pieza apurada.

**FASE 8 (backend/frontend, §14)**: auditoría completa de todo
`backend/` en busca de imports hacia `frontend/`. Encontrado y
corregido: `backend/playback/lorito_tape_physics.py` importaba
`_ITL_AVAILABLE` de `frontend/integration/lorito_itl_bridge.py` a
nivel de módulo — la MISMA familia de bug que GAP-053 (una migración,
GAP-008, internalizó el motor ITL pero este archivo nunca se
actualizó del todo). Peor aún: la bandera importada no tenía relación
real con lo que el código protegido usaba — confundía el motor ITL
INTERNO (`lorito_itl_integration.py`) con un plugin EXTERNO y distinto
(`aecct2_itl_integration`, opcional, nunca incluido en el tarball),
produciendo un falso negativo latente. Corregido quitando el import y
el gate; el `try/except` que ya envolvía el import real es la única
comprobación necesaria. Comportamiento observable confirmado idéntico
con ejecución real en subproceso limpio (sin PySide6/frontend en
absoluto). Queda 1 excepción documentada y deliberadamente sin tocar:
`backend/core/lorito_stability_patch.py` importa frontend de forma
diferida y seguro por diseño (herramienta de introspección) — moverlo
tocaría de nuevo `lorito_bootstrap.py`, justo el archivo recién
arreglado por un bug crítico.

**Práctica nueva y permanente** (instrucción explícita del usuario,
por los antecedentes de CRAC): toda sesión reverifica explícitamente
`lorito_bootstrap.py` antes de cerrar, no solo confía en que la suite
completa pase.

Verificación: **407/407 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (406 preexistentes + 1 nuevo,
`test_tape_physics_backend_independence.py`, que corre en subproceso
limpio y confirma que `PySide6`/`lorito_aldhiro.frontend` nunca entran
a `sys.modules`). `lorito_bootstrap.py` reverificado explícitamente.
`/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado. Versión NO elevada a
0.11.

---

## [056] — 2026-09-16 — FIX CRÍTICO: `lorito_bootstrap.py` no arrancaba — 7 imports con rutas planas anteriores a la arborización
Gap de referencia: [gaps/GAP-053.md](gaps/GAP-053.md)

Reportado por el usuario con traceback real de su propia máquina:
`ModuleNotFoundError: No module named 'lorito_aldhiro.backend.lorito_
app_logging'` — la aplicación no podía arrancar en absoluto. Causa:
`lorito_bootstrap.py` vive en la raíz del tarball, fuera del árbol
`lorito_aldhiro/`, y quedó fuera del alcance de la arborización en
subpaquetes (GAP-032) — sus 7 imports de `lorito_aldhiro.*` seguían
apuntando a las rutas planas de antes de esa migración. Auditoría
exhaustiva de TODO el proyecto (no solo el archivo reportado) confirmó
que el problema estaba 100% aislado a este único archivo. Los 7
imports corregidos a su ubicación real actual (`backend.core.*`,
`backend.capture.*`, `backend.audio.*`, `frontend.integration.*`,
`frontend.support.*`), verificado con ejecución real bajo stubs — el
import completo ahora corre sin excepción.

Se cerró el hueco de cobertura, no solo el síntoma: existe desde
GAP-012 un test dedicado exactamente a esta clase de bug
(`test_module_decomposition_regression.py`), pero excluía
deliberadamente `lorito_bootstrap.py` (para no arrancar una
`QApplication` real) usando `pkgutil.walk_packages()` sobre el árbol
`lorito_aldhiro/` — un recorrido que, por construcción, nunca alcanza
un archivo fuera de ese árbol. Nuevo test ejecuta el código a nivel de
módulo de `lorito_bootstrap.py` vía `runpy.run_path(...,
run_name="__not_main__")` (nunca entra al bloque `__main__` que
arrancaría la GUI real) — confirmado que detecta el bug exacto
reportado (revertido el fix, el test falla reproduciendo el mismo
traceback; restaurado, vuelve a pasar).

Este bug es anterior a las FASES 1 y 2 de la Orden de Saneamiento,
Integración y Consolidación (GAP-051/052) y también estaba presente en
los tarballs 0.10.004 y 0.10.005 entregados durante esa Orden —
ninguna de esas sesiones tocó `lorito_bootstrap.py`.

Verificación: **406/406 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (405 preexistentes + 1 nuevo).

---

## [055] — 2026-09-16 — FASE 2 ("Archival State") de la Orden Maestra de Saneamiento, Integración y Consolidación — contrato §9 completo + motor conectado
Gap de referencia: [gaps/GAP-052.md](gaps/GAP-052.md)

`ArchivalClassification` (`backend/archival/`) extendido de forma
ADITIVA con los campos cuantitativos del contrato §9: `frames_
expected`/`frames_written`/`frames_lost`, `segments_expected`/
`segments_valid`/`segments_invalid`, `checksum_verified`, y la
propiedad `status` (alias de `state`). Nueva clase `ArchivalReason`
(subclase de `str` — mismo patrón que `LoritoError` en GAP-051):
`result.reasons` sigue siendo una lista de strings normales para
código existente, pero cada motivo ahora lleva además un `.code`
estructurado (`FRAMES_DROPPED`, `SEGMENT_MISSING_OR_EMPTY`,
`CHECKSUM_MISMATCH`, etc.). Nuevo método `CaptureEngineV2.classify_
session()`: reúne la telemetría, los segmentos y los checksums REALES
del motor (nunca placeholder) y delega en `backend.archival.classify_
session()` — antes, el subsistema existía y funcionaba (Orden
anterior, GAP-032/035) pero nunca se llamaba desde código de
producción, confirmado por búsqueda exhaustiva antes de tocar nada.

Decisión de política registrada, no tomada unilateralmente: el texto
literal de §9 exige `checksum_verified == True` para `ARCHIVAL_SAFE`,
pero `segment_checksums` sigue siendo un parámetro opcional (como ya
lo era) — aplicar esa exigencia de forma estricta reclasificaría sin
aviso sesiones que hoy son seguras sin haber tenido checksums que
verificar. `checksum_verified` se implementó como campo honesto e
informativo, sin atarlo a `state`; la decisión de endurecerlo queda
pendiente de confirmación explícita del usuario (mismo criterio que
`DSPIntegrityError` en GAP-051).

**Hallazgo real de esta sesión**: al intentar verificar `classify_
session()` de punta a punta con el arnés de captura simulada de
GAP-037, se confirmó (con `faulthandler`) una fragilidad de timing real
y preexistente en `DiskWriterV2`/`ColaElasticaDisco` — el hilo de
escritura a veces no sale a tiempo de esperar más datos tras `stop()`,
reproducible incluso con el test YA EXISTENTE de GAP-037 corrido en
aislamiento, sin relación con el código de esta fase. No se persiguió
dentro de FASE 2 (tocaría código de captura en tiempo real sin poder
verificarlo con hardware real); documentada como candidata real para
Fault Injection o Fase 4. Mitigación: el test de integración de esta
sesión verifica el cableado real (segmentos/checksums reales en disco)
instanciando `CaptureEngineV2()` directamente, sin disparar el ciclo
de hilos — mismo patrón ya establecido en GAP-036/041.

Pendiente explícito, no resuelto: conectar la llamada automática a
`classify_session()` dentro de `_stop_worker()` (GUI) — depende de una
decisión de presentación al usuario (aviso, señal Qt nueva, o solo
almacenamiento silencioso) no tomada unilateralmente aquí.

Verificación: **405/405 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (391 preexistentes + 14 nuevos: 10 en
`test_archival_result_contract.py`, 4 en `test_capture_engine_
archival_integration.py`) — cifra típica de esta sesión (5 de 6
corridas completas); 1 corrida mostró un fallo intermitente de la
misma familia de fragilidad de `DiskWriterV2` ya documentada arriba,
no reproducido con detalle pese a intentarlo, ver GAP-052 para la nota
completa. `/ESTADO_MAESTRO_CONSOLIDACION.md` actualizado (FASES 1-2 de
12 completas). Versión NO elevada a 0.11.

---

## [054] — 2026-09-16 — FASE 1 ("Contratos + errores") de la Orden Maestra de Saneamiento, Integración y Consolidación — taxonomía formal de excepciones + fix real de P0.4
Gap de referencia: [gaps/GAP-051.md](gaps/GAP-051.md)

Subpaquete nuevo `backend/errors/`: `LoritoError` (raíz, hereda de
`RuntimeError` para preservar sitios `except RuntimeError` ya
existentes) + 7 categorías de política de recuperación (§15 de la
Orden vigente: `RecoverableError`, `DegradedError`, `FatalError`,
`IntegrityError`, `CorruptionError`, `LoritoEnvironmentError` —
renombrada para no sombrear el builtin de Python —, `UserAbortError`);
`ExportError` con los 6 campos estructurados exigidos por §11
(`segment_id`/`frame_start`/`frame_count`/`path`/`cause`/`recoverable`)
y 6 subclases (`FormatMismatchError`/`ExportAbortError`/
`SegmentReadError` retroadaptadas desde `RuntimeError` sueltos
preexistentes, sin cambiar nombre ni mensaje; `SegmentIntegrityError`/
`FrameAccountingError`/`ChecksumMismatchError`/`ExportFinalizeError`
nuevas); `DSPIntegrityError` (§16) creada por contrato pero
deliberadamente sin conectar a `NRCoordinator` esta sesión — cambiar
su política de saneo silencioso de NaN/Inf a lanzar-y-abortar es una
decisión de política pendiente de confirmación explícita del usuario,
no un defecto a corregir unilateralmente. `InvalidTransitionError`
(transport) y `MuscleEqError` (DSP) también retroadaptadas.
`AtomicFinalizer`/`ExportSessionReport` extendidos de forma ADITIVA
con el contrato `ExportResult` (§4): `exception` estructurada junto al
`error` string ya existente, `status`, `checksum_status`,
`segments_read`/`segments_failed`, `output_path`, `duration_seconds`,
y los alias `frames_expected`/`frames_read`/`frames_written`.

**Defecto real encontrado y corregido en código de PRODUCCIÓN** (no
solo infraestructura nueva): `_build_export_array()`
(`lorito_mw_export.py`, el método que la GUI usa hoy) ante un segmento
truncado no lanzaba ningún error — el bucle salía en silencio y el
segmento siguiente se escribía desplazado en el tiempo sobre la
posición ya alcanzada, sin ningún aviso. Peor que el "relleno de
silencio" que el propio comentario del código describía, porque ese
camino de relleno nunca llegaba a ejecutarse en este escenario exacto.
Corregido: ahora lanza `SegmentReadError` tipificado nombrando el
segmento y la posición exactos, aborta la exportación completa (P0.4)
— verificado con el mismo arnés de PySide6-stub de GAP-036/041
(`LoritoAldhiroStudio()` real, segmentos WAV corrompidos reales).

Higiene menor de paso: `backend/transport/__init__.py` y
`backend/export/__init__.py` estaban vacíos desde su creación
(violación de la convención de árbol de módulos vigente desde
GAP-032) — el primero poblado con reexportes completos, el segundo
solo con docstring (motivo documentado: dos de sus submódulos
requieren `soundfile` a nivel de módulo, reexportarlos habría roto
imports de submódulos hermanos que hoy funcionan sin esa dependencia
stubeada). Un test obsoleto (`test_overflow_tick_wires_ovflow_tp`)
corregido — fallaba contra un refactor intencional de una sesión
anterior que nunca actualizó su aserción; confirmado que no es una
regresión de esta sesión.

Verificación: **391/391 tests, 0 fallidos**, con y sin
`-W error::ResourceWarning` (365 preexistentes + 1 corregido de forma
no funcional + 26 nuevos). Nuevo documento de estado,
`/ESTADO_MAESTRO_CONSOLIDACION.md`, consolida el mapa de las 12 fases
de esta tercera Orden Maestra (1 completa, 11 pendientes — multi-sesión
por diseño, igual que las dos anteriores). Versión NO elevada a 0.11
(instrucción explícita del usuario: solo al terminar todo el proceso).

---

## [053] — 2026-09-15 — Placa única de aluminio pulido fusiona Scrubs, Visor de Señal, panel de logs y panel de duración de cinta — VU meters con el mismo acabado detallado
Gap de referencia: [gaps/GAP-050.md](gaps/GAP-050.md)

A partir de un tercer SVG de referencia (chasis de aluminio pulido con
microrayado cepillado, reflejo especular diagonal, viñeteado y
tornillos Allen de esquina), nueva función compartida
`paint_brushed_aluminum()` (`lorito_theme.py`): gradiente metálico
diagonal de 7 paradas, microrayado horizontal emulado con líneas de
alpha aleatorio (semilla fija), reflejo especular con blend "overlay"
real (`QPainter.CompositionMode_Overlay`), viñeteado radial y doble
bisel interior — más `paint_alu_screw()` para los tornillos Allen.
Nueva clase `AluminumChassisPanel`: una única placa de aluminio pulido
que fusiona en una sola pieza física los 4 paneles que el usuario pidió
unir (Scrubs — Control de Escaneo/Torcedura/Velocista —, Visor de
Señal Interactivo, panel de logs `StatusDisplay`, panel de duración de
cinta), colocada detrás de todos ellos (creada antes que
`scrub_title`, geometría final fijada después de conocer la altura del
panel de duración de cinta); cada widget conserva su propio fondo
oscuro, que ahora se lee como una ventana empotrada en la placa. Ancho
fijado EXACTAMENTE a la zona central (`CTR_X`→`CTR_XR`), que coincide
por diseño con los bordes interiores de las dos corazas de VU
(`VUMeterChassis`) — unión sin espacio, pedido explícito del usuario.
4 tornillos Allen en las esquinas de la placa ("extremos del inicio
del revestimiento"). `VUMeterChassis` actualizado para usar la MISMA
`paint_brushed_aluminum()` en vez de su gradiente plano anterior — los
VU meters digitales quedan con idéntico acabado detallado, pedido
explícito del usuario. 100/100 módulos compilan; sin verificación
visual con PySide6 real.

## [052] — 2026-09-15 — Botones de transporte sin leyenda (chasis metálico propio), placas de título troqueladas en aluminio, coraza de VU meters, LED tipo joya
Gap de referencia: [gaps/GAP-049.md](gaps/GAP-049.md)

A partir de dos SVG de referencia (botones de audio vintage con chasis
de metal cepillado + LED retroiluminado; lente de cristal tipo joya con
bisel de aluminio), tres piezas rediseñadas por completo en código
(nunca incrustando los SVG como asset). `LoritoTransportButton`
(`lorito_buttons.py`) reescrito: bisel de metal cepillado propio
(`paintEvent()` ya no delega en QSS/`super()`), sin ninguna leyenda de
texto (se conserva como tooltip), formato rectángulo horizontal sin
cambios de tamaño, resplandor de borde LED emulado con trazos
concéntricos de alpha decreciente al activarse/pulsar — EJECT del SVG
mapeado al botón EXPORTAR ya existente. Nueva clase
`AluminumTitlePlaque` (`lorito_indicators.py`): placa de aluminio
pulido MATE (mismo material que los botones, sin su brillo 3D) con
texto TROQUELADO (realce claro + sombra oscura, sin relleno de color
plano) — reemplaza los 5 títulos de texto negro plano que habían
perdido contraste tras el fondo de madera marrón (GAP-048): título
principal, los 3 nombres de Scrubs, y "Visor de Señal Interactivo".
Nueva clase `VUMeterChassis`: coraza de aluminio pulido con ventana
rebajada oscura para la escala/barras de cada VU meter; encabezados
"REC VU"/"PLAY VU" y etiquetas L/R pasados a `AluminumTitlePlaque`
(la escala de dB con color funcional rojo/ámbar/verde se dejó sin
tocar a propósito). `LuminousIndicator` (LED lateral del contómetro)
rediseñado por completo emulando la lente de cristal tipo joya del
segundo SVG (bisel de aluminio con encastre, resplandor incandescente,
facetas internas, reflejo especular) — tamaño aumentado (`SIZE`
22→28), etiqueta de texto retirada (el SVG de referencia no la lleva),
posición sin cambios (ya centraba verticalmente sobre el panel
fusionado, derivado dinámicamente de `LuminousIndicator.SIZE`).
100/100 módulos compilan; sin verificación visual con PySide6 real.

## [051] — 2026-09-15 — Fondo del lienzo: de crema vintage a marrón vintage tipo nogal con vetas realistas — salto de versión a 0.10
Gap de referencia: [gaps/GAP-048.md](gaps/GAP-048.md)

Rediseño explícito del usuario: el fondo estático del lienzo
(`WoodCanvasBackground`/`paint_wood_canvas()`, `lorito_theme.py`) pasa
de un tono crema claro a un marrón vintage oscuro tipo nogal/
palisandro, para emular el gabinete de madera de un equipo de audio de
alta gama de época. Paleta nueva (`WOOD_CANVAS_TOP/MID/BOTTOM`,
`WOOD_GRAIN_LINE`, `WOOD_GRAIN_HILITE`). Vetas rehechas con dos hebras
intercaladas (oscura mayoritaria + clara escasa, reflejo del barniz),
cada una ondulada con dos frecuencias superpuestas en vez de una sola
onda mecánica; se añadieron 3 nudos de madera (manchas radiales
oscuras, semilla fija) y un barniz lacado diagonal sutil (mismo
criterio que el cobertor vítreo del VFD) para dar sensación de
gabinete pulido. Semillas de aleatoriedad fijas en ambos casos, igual
que antes, para que el patrón no cambie entre repintados. Versión
elevada a 0.10 a pedido explícito del usuario al cierre de este
cambio — `APP_MINOR` 9→10, `_MINOR_REVISION_BASE` actualizado a 50
(última cuenta de entradas bajo MENOR=09), mismo patrón ya usado en
los tres saltos de versión anteriores del proyecto.

## [050] — 2026-09-15 — Panel de contómetro principal fusionado en una sola pieza (marco blanco, 3 megaceldas, cobertor vítreo único) + corrección de overlays/leyendas/VU meters
Gap de referencia: [gaps/GAP-047.md](gaps/GAP-047.md)

Rediseño estructural del panel de contómetro principal a partir de una
auditoría visual completa del usuario (PNG de referencia adjunto).
Nueva clase `CounterMegapanel` (`lorito_indicators.py`) fusiona en un
solo widget físico lo que antes eran 4 widgets sueltos con geometría
manual (`DigitalClock`, `MediaAnimWidget` como hijo suyo, y
`SignalPulseCell` como hermano de igual altura): marco blanco
decorativo redondeado, separadores blancos internos, y tres
megaceldas — izquierda (contómetro, sin cambios en su estructura
interna de leyendas), derecha (cuadrado perfecto dedicado al Media
Anim, ya no recortado ni desbordado) e inferior (onda bamboleante a
1/4 de la altura superior, sin leyenda "SEÑAL"). Geometría por fórmula
cerrada, nunca iterativa. Las tres megaceldas comparten un único
cobertor vítreo (`_GlassSheenOverlay`, corrección de una segunda
vuelta tras la primera entrega) en vez de uno independiente por celda,
para que el conjunto se lea como una sola pantalla física — mismo
criterio de fusión que el VFD Display de CRAC. Corregidos además:
overlay del contómetro usando una fuente distinta a los dígitos
(ahora `font_contometro`, mismo bug que CRAC ya había resuelto);
overlays de Scrubs/Side A/Side B/FnTape Aldh invisibles por depender
de un tick de parpadeo externo que solo corría durante auto-pausa/
overflow (`DigitalClock` ahora trae su propio `QTimer` autosuficiente);
celdas de leyenda "apagadas" que se veían como un simple dimmer en vez
de fósforo genuinamente apagado; Media Anim forzado a dorado en todos
sus estados; encabezados "REC VU"/"PLAY VU" sobrepuestos con la barra
de menú (offset de Y sin sumar `MENU_BAR_H`); título y rótulos de
Scrubs con color negro hardcodeado (antes mezcla dinámica accent+
bright del tema). Altura del lienzo (`H`) reducida de 710 a 630,
verificada aritméticamente contra la nueva cascada. 100/100 módulos
compilan; sin verificación visual con PySide6 real (sandbox sin
PySide6 ni acceso a red, confirmado al intentar instalarlo).

## [049] — 2026-09-15 — Modularización de lorito_main_window.py en mixins por responsabilidad + arborización de los 31 módulos en base plana
Gap de referencia: [gaps/GAP-046.md](gaps/GAP-046.md)

`lorito_main_window.py` (6.376 líneas, 86 métodos en una sola clase)
modularizado mediante `tools/modularizar_main_window.py`: cada grupo
de métodos por responsabilidad pasó a una clase mixin en su propio
archivo (extracción exacta por rango de línea vía `ast`, ningún
cuerpo de método modificado), quedando un núcleo de 706 líneas
(`__init__`/`closeEvent`/`keyPressEvent`) heredando de 8 mixins +
QWidget. Los 24 módulos planos de `backend/` y 7 de `frontend/`
arborizados en 9 subpaquetes nuevos (`core/`, `audio/`, `capture/`,
`playback/`, `export/`, `dialogs/`, `support/`, `integration/`,
`spectral/`) mediante `tools/arborizar_modulos_planos.py`, que mueve
cada archivo y reescribe automáticamente las referencias de import en
todo el árbol. Tres defectos reales encontrados y corregidos en el
camino: un atributo de clase (`W = 1040; H = 710`) que el primer
extractor de métodos perdía en silencio; un patrón de import
(`from paquete import módulo as X`) que el reescritor de referencias
no cubría; y **dos** rutas calculadas por `__file__` (assets de
fuentes y la raíz del proyecto para `lorito_version.py`) que se
rompieron al mover sus archivos consumidores un nivel más profundo —
esta última hacía que el cálculo de versión cayera en silencio al
valor de respaldo en vez de contar las entradas reales del CHANGELOG.
archivos nuevos de `main_window/` llevan su banner decorativo desde
el propio script generador; los 31 módulos reubicados conservaron el
suyo intacto — cobertura final: 100/100 módulos `.py` del proyecto
con banner. Batería completa: 365/365 tests, 0 fallidos. `backend/`
queda con 0 archivos en base plana; `frontend/` con 1
(`lorito_main_window.py`, exento a propósito).

## [048] — 2026-09-13 — Descarolización de leyendas visibles (panel de duración de cinta, panel de estado/bitácora, diálogos de exportación/error)
Gap de referencia: [gaps/GAP-045.md](gaps/GAP-045.md)

Reemplazada la terminología basada en CRAC/"Carola" que aparece como
leyenda visible en pantalla, según el mapeo explícito dado por el
usuario: 8 leyendas del panel de duración de cinta (`lorito_tape_log_
panel.py`) y 17 del panel de estado/bitácora (`lorito_status_
display.py`/`lorito_main_window.py`), más una regla general (CAROLA/
CAROLALDHIRA → LORITO) aplicada a diálogos de exportación/error
(`lorito_dialogs.py`) y dos etiquetas de animación (`lorito_media_
anim.py`). Actualizadas también 3 comparaciones lógicas que
dependían del texto viejo para clasificar color/nivel, evitando que
el cambio de texto rompiera la clasificación visual. Exentas, según
lo pedido: leyendas de Scrubs Morpher/Velocista y prefijos internos
invisibles de enrutamiento entre paneles. Batería completa: 365/365
tests, 0 fallidos. Dos puntos quedaron marcados para confirmar con el
usuario: una leyenda "CAROLA TE ESTA ESPERANDO" sin decoración no se
localizó como texto independiente, y "CAROLALINO"/"CAROLATIZANDO" se
resolvieron con criterio propio al no estar en la lista explícita.

## [047] — 2026-09-12 — Banner de registro con cobertura total (92 módulos) y silueta de lorito como huevo de pascua
Gap de referencia: [gaps/GAP-044.md](gaps/GAP-044.md)

Extendida la cobertura del banner "LORITO ALDHIRO DE REGISTROS
ALTERNATIVOS C.E.A" (GAP-043) a los 92 módulos `.py` de
`lorito_aldhiro/` (excluidos los 12 `__init__.py`), y agregada una
silueta ASCII de lorito como huevo de pascua dentro del marco, ambos
pedidos explícitos del usuario. Dos defectos reales de la propia
herramienta encontrados y corregidos en el camino: un `^` en los
patrones de detección que no ancla donde se esperaba con
`re.match(string, pos)` (causaba docstrings duplicados), y backslashes
sin escapar en la silueta dentro de un docstring no crudo (`SyntaxWarning`).
Ambos se manifestaron como corrupción real de archivos en un primer
intento — detectada con `ast.parse()`/`compile()` sobre el árbol
completo, revertida con una regex exacta, y reparados los casos límite
(comilla de apertura perdida en 60 archivos, comilla huérfana en 32)
antes de la ejecución final correcta. Verificado 0 problemas de
sintaxis/warnings en los 92 módulos, e idempotencia (92/92 "saltado"
en una segunda corrida). Batería completa: 365/365 tests, 0 fallidos
— sin cambios de versión adicionales sobre 0.09.001.

## [046] — 2026-09-12 — MUSCLE EQ SAMIR (VITRITO): diseño nuevo para Lorito Aldhiro, banners de registro C.E.A, paneles sin redimensionado, versión elevada a 0.09
Gap de referencia: [gaps/GAP-043.md](gaps/GAP-043.md)

Ecualizador en caliente diseñado desde cero para Lorito Aldhiro (a
diferencia de los 4 DSP anteriores, adaptados de CRAC), a partir de
una Orden de Ingeniería de 36 secciones aportada por el usuario. 6
tipos de filtro DF2T (RBJ Cookbook), hasta 8 bandas, transición suave
de coeficientes por rampa lineal (~10ms, sin clicks verificado), 44
presets en 5 categorías (Tonal/Musical/Histórico/Técnico/Cinta) —
RIAA/NAB/CCIR usan frecuencias de esquina reales investigadas (50Hz/
500.5Hz/2122Hz para RIAA; 50Hz/3180Hz para NAB, confirmando por qué
ambas curvas no son intercambiables pese a compartir un corner). Bypass
real (nunca "ganancia=0dB"), "HECHO" no resetea nada, "RESTABLECER"
vuelve a FLAT sin discontinuidad. Primero en la cadena de
NRCoordinator (antes que los DSP de PREVI). Indicador "MUSC EQ" en la
celda "DOLBY S" con dos comportamientos distintos (parpadeo solo vs.
alternancia con Dolby S real), reutilizando el tick central ya
existente. Script `tools/insertar_banner_registro.py` (idempotente)
inserta el banner "LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A" con
el concepto de cada DSP en 27 módulos (7 DSP + 20 perfiles de Lucha
Enloquecida). Paneles de Cristhi Cosh/Antipestal/Muscle Eq ahora sin
redimensionado, igual que el resto de Lorito. 25 tests nuevos. Batería
completa: 365/365 tests, 0 fallidos. Versión elevada a 0.09.000.

## [045] — 2026-09-12 — Lucha Enloquecida (PREVI): 20 sub-perfiles adaptados desde CRAC, backend + UI completos
Gap de referencia: [gaps/GAP-042.md](gaps/GAP-042.md)

Última pieza de la línea de trabajo de DSP de CRAC. 20 sub-perfiles
"LUCHALOCA LOFI A" a "T" portados desde CRAC — confirmado que ninguno
depende de nada más allá de `biquad.py`/el contrato mínimo, lo que
simplificó el porte pese al tamaño total (~5.460 líneas). Retirado
`get_metrics()` (PreviAnalyzer) del contrato y de las 20 subclases; no
portada la infraestructura de UI/telemetría propia de CRAC (TMI,
Vitreous, VFD, iconos SVG). Equivalencia numérica exacta verificada
contra el código original de CRAC para los 20 perfiles completos
(diff=0.0). Integrado a `NRCoordinator` (`set_lucha_enloquecida()`) y
a la leyenda compartida "PREVI DSP". UI: submenú dedicado dentro de
OPTAPE con los 20 sub-perfiles. 13 tests nuevos. Batería completa:
340/340 tests, 0 fallidos. Con esto, los 4 DSP de CRAC pedidos quedan
completos (Cristhi Cosh, Antipestal Lola Grillo, Versión O Tron, Lucha
Enloquecida) — Autoalineación omitida por decisión del usuario.

## [044] — 2026-09-12 — Antipestal de Lola Grillo (PREVI) y Versión O Tron (FNESP): backend + UI completos, investigación web, versión elevada a 0.08
Gap de referencia: [gaps/GAP-041.md](gaps/GAP-041.md)

A pedido del usuario, en una sola sesión: **Antipestal de Lola Grillo**
("Gancha Striker"/"Gancha Kari") portado desde CRAC — corrección real
encontrada por investigación web: el pre/post-eco (print-through) de
CRAC usaba 8-14ms, la física real del fenómeno (verificada con el
cálculo geométrico exacto para cinta abierta y adaptada a cassette)
da 2.2-2.9 SEGUNDOS — 1.5-2 órdenes de magnitud de diferencia,
corregido. Wow/flutter confirmado dentro de rangos reales documentados
(sin cambios). **Versión O Tron** (AA-MO/BARRIL/SIFÓN) portado —
BARRIL (5kHz) y SIFÓN (300-3800Hz) confirmados contra especificaciones
reales de radiodifusión AM y SSB/onda corta documentadas; AA-MO
corregido en su atribución (el electreto real es de banda ancha, la
limitación viene del conjunto grabador completo, no del micrófono).
Convertido de función offline (CRAC) a perfil streaming con estado
persistente (biquads con zi/zf, mismo patrón que LUFS en GAP-029).
Ambos integrados a `NRCoordinator`, con las leyendas compartidas
"PREVI DSP"/"FNESP DSP" (preparadas en GAP-040) usadas por primera vez
con DSP reales. Menú OPTAPE, paneles de deslizadores, overlays de 4s.
24 tests nuevos, incluida equivalencia bit-exacta contra el código
original de CRAC para los componentes compartidos. Defecto de
aislamiento entre archivos de test encontrado y corregido en el
camino (mismo patrón de GAP-036/037, no afecta producción). Batería
completa: 315/315 tests, 0 fallidos. **Versión elevada a 0.08**
(pedido explícito del usuario). Pendiente: Lucha Enloquecida (sesión
dedicada, sin empezar).

## [043] — 2026-09-12 — Florecedor de Cristhi Cosh (PREVI): UI completa (menú OPTAPE, leyenda "PREVI DSP", panel de deslizadores, overlay)
Gap de referencia: [gaps/GAP-040.md](gaps/GAP-040.md)

Cerrada la parte de interfaz que quedó pendiente en GAP-039. Entrada
en el menú OPTAPE ("FLORECEDOR CRISTHI COSH (PREVI)" + "— Ajustes…").
`DigitalClock` extendido con `set_previ_dsp_active()`/
`set_fnesp_dsp_active()`/`tick_legend_alternation()` — la celda
"DOLBY B" muestra "PREVI DSP" mientras el DSP está armado; la celda
"DOLBY C" está preparada para mostrar "FNESP DSP" (alternando cada
~1s con "DOLBY C" si el NR real también está activo) para cuando se
adapte el primer DSP de Funciones Especiales. La alternancia reutiliza
el tick de 480ms ya existente para el parpadeo de DITHER — sin QTimer
nuevo. Panel de ajustes con 4 deslizadores tradicionales (sin
perillas), actualizando el DSP en vivo. Overlay simple de encendido,
4s, sin ninguna métrica de PreviAnalyzer/TMI. 9 tests nuevos, todos
contra la ventana completa instanciada real bajo los stubs de PySide6.
Batería completa: 291/291 tests, 0 fallidos. Florecedor de Cristhi
Cosh queda COMPLETO (backend + UI). Pendientes según el orden
confirmado: Antipestal de Lola Grillo, Versión O Tron.

## [042] — 2026-09-12 — Florecedor de Cristhi Cosh (PREVI): backend adaptado desde CRAC y conectado a la cadena real
Gap de referencia: [gaps/GAP-039.md](gaps/GAP-039.md)

Primer DSP de CRAC adaptado al catálogo de Lorito. Cadena de 5 bandas
(Azucena/Nicole/Daniela/Pocha-SIRF/Rommy) portada con matemática
idéntica al original — verificado ejecutando el código fuente de CRAC
directamente y comparando contra la versión portada: diferencia máxima
0.0 en 30 bloques con artefactos simulados. Recortado (no portado, por
tener ya equivalente en Lorito o no haber sido pedido): la guarda
propia de CRAC contra NaN/Inf (`PREVIDSPBlockGuard`) — reemplazada por
`DSP_NONFINITE_OUTPUT`/`sanitize_finite` ya existente (el propio
comentario del controlador de CRAC confirma el mismo defecto que
motivó esa guarda en Lorito, GAP-025); modos de captura/inhibición
mutua entre DSP de PREVI; PreviAnalyzer/TMI; calentamiento JIT.
Integrado a `NRCoordinator` (`set_cristhi_cosh()`, primero en la
cadena, antes de EQ/BIAS/MPX) con el mismo patrón de saneamiento por
etapa de la Fase 10. 15 tests nuevos. Batería completa: 282/282 tests,
0 fallidos. Pendiente: menú OPTAPE, leyenda "PREVI DSP", panel de
deslizadores, overlay de encendido — la interfaz de usuario, no el
backend.

## [041] — 2026-09-12 — Mecanismo de protección ante crasheos por condición de carrera al cerrar el sistema, replicado desde CRAC
Gap de referencia: [gaps/GAP-038.md](gaps/GAP-038.md)

A pedido del usuario (tarball CRAC subido, orden de trabajo: omitir
Autoalineación —ya cubierta por `FocusProfile`—, Lucha Enloquecida a
sesión dedicada, abordar antes los fallos fatales de Python). Auditado
qué protecciones de cierre ya tenía Lorito (heredadas de CRAC:
`CarolaBienvenidaDialog`/`CarolaNooDialog`/`CierreAbruptoDialog` — ya
presentes). Defecto real encontrado en el propio Lorito (no en CRAC):
un comentario falso afirmaba que `CaptureEngineV2.stop()` ya detenía
`DiskWriterV2` internamente — no era así. Las ramas GUARDAR y
DESCARTAR de `closeEvent` nunca detenían el hilo de escritura a disco,
la misma familia de condición de carrera "cerrar con motores
corriendo" que CRAC saneó con `wait_for_pending_stream_close()`. Nuevo
`CaptureEngineV2.wait_for_background_threads()` (equivalente adaptado
a la arquitectura real de Lorito, sin hilo de lectura bloqueante
propio) llamado desde `stop()` y como última línea de defensa
incondicional en `closeEvent`. Corregidas ambas ramas para detener
`DiskWriterV2` de verdad. Confirmado que el crash "corrupted
double-linked list" de PREVI-DSP-no-desarmado no aplica todavía (Lorito
no tiene DSP de PREVI; su único DSP en tiempo real corre en el hilo de
drenaje, no enganchado al callback RT como en CRAC) — se replicará el
patrón de desarme cuando se agreguen esos DSP. 7 tests nuevos,
incluida reproducción real del defecto con `LoritoAldhiroStudio`
instanciada de verdad. Batería completa: 268/268 tests, 0 fallidos.

## [040] — 2026-09-12 — Cierre de los frentes "bloqueados por hardware real" mediante stubs funcionales: pipeline de captura end-to-end, ring buffer SPSC bajo carga real, y corrección medida de la deriva de `_resample_stateful`
Gap de referencia: [gaps/GAP-037.md](gaps/GAP-037.md)

Nuevo stub funcional de `sounddevice.InputStream` (hilo real llamando
al callback de audio real) — permite correr `CaptureEngineV2` de
punta a punta: audio simulado → callback → RBA → drain → CED →
DiskWriterV2 → WAV en disco, cero frames perdidos, watchdog escalando
YELLOW→ORANGE→RED→recovery con temporización real. `LockFreeSPSCRingBuffer`
verificado bajo la misma carga como reemplazo directo. **Hallazgo
central**: medida por primera vez la deriva de fase de
`_resample_stateful` (GAP-026 solo la había especulado) — con los
tamaños de bloque reales de `PlaybackEngine`, el error se acumula
progresivamente en cada frontera de chunk. Nueva corrección
`resample_stateful_continuous` (`backend/dsp/`, historial de 2
muestras entre llamadas) verificada con precisión de `float32` contra
una referencia Catmull-Rom calculada a mano. Dos defectos de test
(no de producción) encontrados y corregidos en el camino: reinstalar
`sys.modules` no rebindea referencias ya importadas (mismo patrón que
GAP-036); drenar un ring buffer SPSC después de que el productor ya
terminó no es un escenario válido. `backend/dsp/__init__.py` poblado
(estaba vacío). Ninguna de las correcciones integrada a producción
real todavía — construidas y verificadas en aislamiento, mismo
criterio que toda esta cadena de sesiones. 7 tests nuevos. Batería
completa: 261/261 tests, 0 fallidos.

## [039] — 2026-09-12 — Exploración del hallazgo de stubs de PySide6: `_build_export_array()` real ejecutado y verificado bit-exacto contra el camino streaming
Gap de referencia: [gaps/GAP-036.md](gaps/GAP-036.md)

Puesto a prueba el hallazgo de GAP-034 (stubs de PySide6 preexistentes
razonablemente completos). Confirmado: `LoritoAldhiroStudio()` se
instancia COMPLETA bajo esos stubs. Construido un stub FUNCIONAL de
`soundfile` (lectura+escritura reales vía `wave`, a diferencia del
dummy existente que solo permite importar) — con él,
`_build_export_array()` (el método RAM-unbounded original que motivó
toda la Fase 1) se ejecutó DE VERDAD contra segmentos sintéticos
reales, y su resultado es idéntico bit a bit al de `SegmentProvider`
streaming sobre los mismos segmentos. Esto NO integra Fase 1 a la GUI
todavía (ese swap real sigue sin hacerse — `export()` completo es
mucho más grande que `_build_export_array` en aislamiento) pero
reduce sustancialmente el riesgo de esa integración futura y deja una
técnica de verificación concreta y repetible. 3 tests nuevos. Batería
completa: 254/254 tests, 0 fallidos. Ningún código de
`lorito_main_window.py` modificado — sesión puramente exploratoria.

## [038] — 2026-09-12 — Conexión real de integridad de segmento (Fase 7, continuación de GAP-032)
Gap de referencia: [gaps/GAP-035.md](gaps/GAP-035.md)

`integrity_crc32_errors` (GAP-032: estructuralmente condenado a valer
siempre 0, `_IntegrityMonitor` nunca conectado) resuelto de otra
forma, no reutilizando `_IntegrityMonitor` tal cual: hashear el buffer
float32 antes de la conversión interna de `soundfile` a PCM arriesgaba
falsos positivos permanentes (no se puede verificar en este sandbox si
ese redondeo es bit-exacto — GAP-026 ya encontró un bug de ese tipo en
la propia implementación streaming del proyecto). Nuevo módulo
`backend/archival/lorito_segment_checksum.py`: SHA-256/CRC32
calculados RELEYENDO el segmento ya cerrado desde disco, conectado a
`DiskWriterV2._close_segment` (nuevo método `get_segment_checksums()`)
y a `classify_session()` (Fase 7, GAP-032) vía un parámetro opcional
`segment_checksums` que detecta corrupción real (bit rot, truncamiento)
y marca la sesión `INVALID` nombrando el segmento exacto. 11 tests
nuevos, incluida detección real de un byte invertido después del
cierre del segmento, y 2 tests end-to-end con `DiskWriterV2` real.
Batería completa: 251/251 tests, 0 fallidos. `_IntegrityMonitor` queda
como código muerto documentado, no como pendiente.

## [037] — 2026-09-12 — Fases 2, 9, 12, 14, 15 y 16: cierre de todo lo identificado como abordable sin hardware real
Gap de referencia: [gaps/GAP-034.md](gaps/GAP-034.md)

**Fase 2**: `SegmentReadError` — un segmento truncado (header miente
sobre su tamaño real, síntoma de un crash a mitad de escritura) se
entregaba en silencio; ahora se detecta y nombra el segmento exacto.
**Fase 9**: casos nombrados por la orden ("seek durante prefetch",
"scrub con underrun") verificados en `GenerationGuard` — máquina de
estados pura, sin hardware. **Fase 12**: cobertura medida por primera
vez con el módulo estándar `trace` (sin dependencias externas) — error
propio de medición corregido en el camino (un `--count` mal
interpretado daba un falso 100%); resultado real: 42.3% agregado, ver
`/COBERTURA.md`. Hallazgo colateral: ya existe un mecanismo de stubs
de PySide6 razonablemente completo desde antes de esta cadena de
sesiones. **Fase 14**: `DiskWriterV2` real ejercitado con fallos
forzados (ENOSPC, transitorio, agotar reintentos, disco casi lleno,
fallo al abrir segmento) vía un stub funcional de `sf.SoundFile`
respaldado por `wave`. **Fase 15**: README actualizado (congelado en
0.01.002); `lorito_version.py` reducido de 1062 a 122 líneas (946
líneas de changelog CRAC pre-bifurcación, inertes, movidas a
`/HISTORICO_VERSION_CRAC.md`). **Fase 16**: `/EXPORT_CONTRACT.md` y
`/RT_CONTRACT.md` escritos por primera vez, documentando solo lo ya
construido y verificado. 15 tests nuevos. Batería completa: 240/240
tests, 0 fallidos. Único pendiente genuinamente bloqueado por hardware
de las fases antes "sin identificar": Fase 13 (pruebas de larga
duración).

## [036] — 2026-09-11 — Documento maestro consolidado del estado de la Orden de Saneamiento (GAP-024 a GAP-033)
Gap de referencia: (ninguno — documentación pura, sin cambios de código)

Nuevo `ESTADO_MAESTRO_SANEAMIENTO.md` en la raíz del tarball —
consolida en un solo documento el estado de las 33 GAPs acumuladas
desde el inicio de la Orden Maestra de Saneamiento: tabla de fases con
su estado real (no aspiracional), lista de los 6 defectos reales
encontrados y corregidos en la cadena de sesiones, la convención de
árbol de módulos vigente, y los pendientes categorizados por qué los
bloquea (PySide6, hardware real, o trabajo mayor sin bloqueo técnico).
Corrección honesta incluida: las Fases 2/9/12/13/14/16/17 de la orden
original no tienen su contenido preservado en ningún GAP anterior —
se documenta como "sin identificar, requiere consultar al usuario" en
vez de inventar su alcance. Sin cambios de código — batería sin tocar:
225/225.

## [035] — 2026-09-11 — Fase 8: soporte RF64 real en el encoder WAV streaming
Gap de referencia: [gaps/GAP-033.md](gaps/GAP-033.md)

`WavEncoder` ya no lanza `NotImplementedError` cuando el tamaño
estimado supera el límite RIFF de 32 bits (~3.9 GB) — escribe un
header RF64 (EBU Tech 3306) desde el principio, aprovechando que
`ExportSession` siempre conoce `total_frames_hint` de antemano (vía
`SegmentProvider`, sumando headers de segmentos antes de escribir
nada), por lo que la decisión RIFF/RF64 se toma correctamente desde el
primer byte, sin necesidad de mutar un header ya escrito. Nuevo chunk
`ds64` (riffSize/dataSize/sampleCount de 64 bits), sentinelas
`0xFFFFFFFF` en `'RF64'`/`'data'` nunca tocados en finalize. Parser
dedicado `_validate_rf64()` (el `wave` estándar de Python no entiende
RF64). 9 tests nuevos, incluida verificación de estructura de bytes a
mano y round-trip completo vía `ExportSession` sin escribir gigabytes
reales a disco (se explota el hint deliberadamente). Test preexistente
que esperaba el `NotImplementedError` viejo, actualizado. Batería
completa: 225/225 tests, 0 fallidos. Con esto, todas las fases de la
Orden Maestra marcadas "no requiere hardware" (3-8) han sido abordadas
al menos una vez desde GAP-024.

## [034] — 2026-09-11 — Convención de árbol de módulos + Fase 6 (recovery, sin defectos) + Fase 7 (máquina de estados archival, construida desde cero) + hallazgo real: `_IntegrityMonitor` nunca conectado
Gap de referencia: [gaps/GAP-032.md](gaps/GAP-032.md)

Adoptada la convención de árbol de subpaquetes conectados por
`__init__.py` (pedida por el usuario, guardada para sesiones futuras):
`lorito_ring_buffer_spsc.py` movido a `backend/rt/`; `backend/export_
streaming/__init__.py` (vacío desde su creación) poblado para conectar
sus 7 módulos. **Fase 6**: `_auto_recover()` auditado con
`CaptureEngineV2` real + mocks deterministas de tiempo — sin defectos,
7 tests nuevos, incluida verificación real de no-destructividad (datos
en RBA/CED sobreviven intactos al recovery). **Fase 7**: la máquina de
estados `ARCHIVAL_SAFE`/`DEGRADED`/`INVALID` no existía en ninguna
forma — construida desde cero en nuevo subpaquete `backend/archival/`.
Hallazgo real en el camino: `integrity_crc32_errors` nunca se
incrementa porque `_IntegrityMonitor` (CRC32/SHA256 por segmento,
completamente implementado) nunca se conecta al `DiskWriterV2` real —
un campo estructuralmente condenado a valer siempre 0, no solo
"olvidado". La clasificación nueva se apoya solo en contadores
realmente conectados (`frames_dropped`, `xrun_count`,
`rba_overrun_total`, `ced_dropped_frames`, `recovery_count`,
`starvation_events`, segmentos en disco). 13 tests nuevos, lógica pura
sin stubs. Batería completa: 216/216 tests, 0 fallidos. Pendiente:
conectar `_IntegrityMonitor` de verdad (trabajo mayor) y Fase 8 (RF64).

## [033] — 2026-09-11 — Fases 3/4/5: ring buffer RT sin locks (SPSC), auditoría de política de overflow, defecto real de conteo corregido en la Cola Elástica de Disco
Gap de referencia: [gaps/GAP-031.md](gaps/GAP-031.md)

**Fase 3**: nuevo módulo `lorito_ring_buffer_spsc.py`
(`LockFreeSPSCRingBuffer`) — ring buffer Single-Producer-Single-
Consumer sin locks para reemplazar eventualmente a
`RingBufferAbsorcion` (que usa `threading.Condition` en cada `write()`
desde `_audio_callback`). Protocolo tipo seqlock por secuencia de
slot: el productor es wait-free (nunca espera, nunca coordina con el
lector); el consumidor detecta y cuenta los overruns. Verificado con
hilos REALES de Python en concurrencia genuina (10 tests, incluidos 4
de estrés con hasta 5000 bloques y 3 slots sin ningún sleep — el
escenario más agresivo posible), no requiere hardware de audio.
**Fase 4**: auditada la política de backpressure del drain loop y el
overflow de `RingBufferAbsorcion` — diseño coherente, conteo ya
correcto, sin defectos encontrados; el ring buffer SPSC de la Fase 3
es la propuesta de esta sesión para ese frente. **Fase 5**: defecto
real encontrado en `ColaElasticaDisco` — `dropped_frames` nunca se
incrementaba pese a que la clase promete "NUNCA descarta
silenciosamente" (el propio drain loop leía ese campo esperando que
reflejara la realidad). Corregido con una línea. 6 tests nuevos,
usando stubs transitorios de sounddevice/soundfile para poder importar
el módulo real en este sandbox. Batería completa: 196/196 tests, 0
fallidos. Reemplazar RingBufferAbsorcion por el nuevo diseño en
CaptureEngineV2 sigue pendiente de una sesión con hardware de audio.

## [032] — 2026-09-11 — TWO_PASS (v21): última pieza del catálogo de 20 modos de normalización streaming — frente cerrado por completo
Gap de referencia: [gaps/GAP-030.md](gaps/GAP-030.md)

Cierre absoluto del frente de normalización streaming abierto en
GAP-027. `resolve_two_pass_mode` replica el árbol de decisión propio
de `_two_pass_analysis` (v21) — percentiles p05/p95 de bloques de
100ms sin subsample, distinto al de AUTO. Reutiliza el orquestador
`export_resolved_mode` ya construido en GAP-029, sin duplicar lógica.
4 tests nuevos, los 4 en verde a la primera ejecución. Batería
completa: 180/180 tests, 0 fallidos. **Los 20 modos de
`NormalizationMode`/`NormalizationModeV21` tienen ahora una réplica
streaming verificada** — frente cerrado.

## [031] — 2026-09-11 — Cierre del frente de normalización streaming (18 modos restantes + AUTO + presets de cinta) — salto de versión a 0.07
Gap de referencia: [gaps/GAP-029.md](gaps/GAP-029.md)

Implementados y verificados los 18 modos de normalización streaming
que quedaban pendientes tras GAP-028 (PRESERVATIVE, NOISE_AWARE,
CREST_GUARD, MID_SIDE, TRUE_PEAK/x4, LUFS_23/16/14, INTELLIGENT_PEAK,
ADAPTIVE_BLOCK), el meta-modo AUTO (árbol de decisión completo) y los
presets de cinta (v21) — cierre prácticamente completo del catálogo de
20 modos de `NormalizationMode`/`NormalizationModeV21` (queda pendiente
solo la función de decisión propia de TWO_PASS, ver GAP-029). LUFS usa
`scipy.signal.lfilter` con estado encadenado (verificado bit-exacto
frente a una sola llamada). Único modo no bit-exacto por diseño:
INTELLIGENT_PEAK (percentil aproximado por histograma, error acotado y
medido <0.05 dB). Tres defectos reales encontrados y corregidos: (1)
`_norm_adaptive_block` (legado) crasheaba con `ValueError` en CUALQUIER
audio estéreo real al llegar a una zona de crossfade — bug de
broadcasting nunca antes ejercitado; (2) el mismo bug en la versión
streaming; (3) desalineación real de buffer en `measure_block_rms_
streaming` que corrompía las ventanas de análisis posteriores a la
segunda (afectaba a NOISE_AWARE y a los presets de cinta). 19 tests
nuevos (`tests/test_normalization_streaming_full.py`), todos
comparados contra las funciones legadas reales. Batería completa:
176/176 tests, 0 fallidos. Versión elevada explícitamente a 0.07
(`APP_MINOR` 6→7, `_MINOR_REVISION_BASE`→30) por pedido del usuario.

## [030] — 2026-09-11 — Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic: Fase 1, prueba de concepto real de normalización streaming en dos pasadas (PEAK_SIMPLE, RMS_*)
Gap de referencia: [gaps/GAP-028.md](gaps/GAP-028.md)

Implementado el diseño de dos pasadas de GAP-027 para los 2 modos más
simples de Categoría A. Nuevo parámetro `block_transform` en
`ExportSession` (retrocompatible, `None` por defecto). Nuevo módulo
`backend/export_streaming/lorito_normalization_streaming.py`:
`measure_peak_streaming`/`measure_rms_streaming` (pase 1, memoria
O(block_frames)) + `compute_peak_simple_gain`/`compute_rms_gain`
(misma fórmula exacta que `lorito_normalization.py`, importada, nunca
reimplementada) + `export_with_scalar_gain` (pase 2, segunda lectura
real desde disco). Verificado bit a bit contra
`_apply_normalization_advanced` sobre el array completo materializado,
y medido con un caso real de 12M frames: **~804 KB de RSS** frente a
los ~96 MB que exigiría el camino legado — el patrón resuelve
realmente el defecto de RAM. 5 tests nuevos
(`tests/test_normalization_streaming.py`). Batería completa: 157/157,
0 fallidos. Sigue pendiente: los otros 18 modos, y la integración real
a `main_window.export()` (bloqueada por PySide6 no ejecutable aquí).

## [029] — 2026-09-11 — Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic: clasificación de streamabilidad de los 20 modos de normalización (auditoría pura)
Gap de referencia: [gaps/GAP-027.md](gaps/GAP-027.md)

Auditoría documental (sin cambios de código) de los 17 modos de
normalización v0.20 + 3 de v0.21, punto 1 de la recomendación de
GAP-026. Hallazgo: NINGÚN modo requiere acceso aleatorio a la señal
completa — 14 son ganancia escalar global (pase 1 medir chunked → pase
2 aplicar), 1 (`ADAPTIVE_BLOCK`) es una curva por bloque pero sigue
siendo streameable en dos pasadas con un array O(n_bloques), y 3
(`AUTO`, presets de cinta, `TWO_PASS`) son meta-modos que se resuelven
en las categorías anteriores tras el análisis. El soft limiter
(v21) es causal/stateful, streaming-friendly por construcción. Diseño
arquitectónico propuesto para una sesión futura (refactor
medir/aplicar por modo) documentado en el GAP. Batería sin cambios:
152/152.

## [028] — 2026-09-11 — Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic: Fase 1 auditada — defecto real de round-trip PCM corregido en el encoder streaming
Gap de referencia: [gaps/GAP-026.md](gaps/GAP-026.md)

Auditoría de fidelidad del camino de exportación streaming ya
construido (`SegmentProvider`/`WavEncoder`/`AtomicFinalizer`/
`ExportSession`), previa a considerar su integración a `main_window.
export()` (todavía bloqueada por falta de PySide6/sounddevice
ejecutables en este sandbox — sin cambios respecto a `GAP-002`/
`GAP-003`). Defecto real encontrado: `WavEncoder._float32_to_pcm_bytes`
usaba escala asimétrica + truncación frente al decodificador,
produciendo hasta ±1 LSB de error en el 100% de las muestras de un
re-exportado SIN NINGÚN DSP aplicado — el "sin tocar nada" no era
bit-exacto. Corregido con escala simétrica + redondeo + clip al rango
entero válido, para PCM_16/24/32. Verificado bit-exacto para PCM_16 y
PCM_24; PCM_32 tiene un límite arquitectónico real (no un bug) por la
mantisa de 24 bits de `float32`, contrato de `Block.data` — medido y
documentado explícitamente, no una regresión. 6 tests nuevos
(`tests/test_export_pcm_roundtrip.py`). Batería completa: 152/152
tests, 0 fallidos. No se tocó `lorito_main_window.py` ni ningún código
de UI/Qt — Fase 1 sigue sin wirearse a la GUI real.

## [027] — 2026-09-11 — Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic: Fase 10 (DSP_NONFINITE_OUTPUT, finite-in/finite-out)
Gap de referencia: [gaps/GAP-025.md](gaps/GAP-025.md)

Implementada la Fase 10 de la Orden Maestra (saneamiento DSP). Defecto
real confirmado: `np.clip` al final de cada etapa de `NRCoordinator`
(EQ/BIAS, MPX, perfiles NR, HX Pro, ALC) no sanea NaN, y el estado IIR
recursivo de varias etapas (biquads de MPX, shelves de EQ/BIAS) queda
envenenado de forma permanente ante un único NaN. Nuevo módulo
`backend/dsp/lorito_dsp_finite_guard.py` (`sanitize_finite`, camino
sano sin copia). Aplicado en `NRCoordinator.process_chunk` en dos
niveles: finite-in (bloque de entrada crudo) y por etapa (sanea +
resetea el estado de la etapa que produjo el NaN/Inf, reutilizando su
`reset()` ya existente). Contadores por etapa en
`NRCoordinator.nonfinite_counts`. 12 tests nuevos
(`tests/test_dsp_finite_guard.py`), incluida la demostración del
defecto real sin el guard. Batería completa: 146/146 tests, 0
fallidos. No se tocó ring buffer, threading, ni estructura RT alguna.

## [026] — 2026-09-11 — Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic: primera pasada real (Fase 0/11/15 + auditoría)
Gap de referencia: [gaps/GAP-024.md](gaps/GAP-024.md)

- El usuario entregó una Orden Maestra de Ingeniería de 30 secciones
  para sanear Lorito Aldhiro antes de la primera campaña de pruebas de
  Aldhira Phonographic (equivalente al esquema de auditoría de CRAC).
  Esta entrada cubre la primera pasada real — NO la orden completa
  (ver veredicto explícito abajo y el detalle fase por fase en
  `saneamiento_0_06_006/ENGINEERING_STATUS_0.06.006.md`).
- **Fase 0 (baseline)**: batería completa corrida contra 0.06.005 tal
  como llegó — 134 tests, **4 fallos** (`BASELINE_0.06.005`). Entorno
  real registrado (Python 3.12.3/NumPy 2.4.4/SciPy 1.17.1, sin
  PySide6, sin PortAudio). `RELEASE_MANIFEST.txt` con SHA-256 de los
  108 módulos generado por primera vez.
- **Fase 11 (4 tests obsoletos)**: los 4 fallos del baseline eran
  exactamente los 4 tests que cita la orden — confirma que está bien
  fundamentada contra el código real. Corregidos actualizando la
  EXPECTATIVA al comportamiento actualmente contratado (familias de
  fuente: 4→6; overlay EXPORT: "Export"→"Expn Signal"; celdas
  laterales: vacías→valores por defecto reales de GAP-018). Batería
  final: **134/134, 0 failed.**
- **Fase 15 (higiene, parcial)**: 2 fugas de recursos reales
  encontradas al correr la batería con `-W error::ResourceWarning`
  (`open()` sin `with` en `lorito_version.py`, `os.scandir()` sin
  `with` en `lorito_rt_priorities.py`) — corregidas y reverificadas.
- **Auditoría sin modificar código** (Fases 1/3/4/5/6/7/8/9/10):
  confirmado que la exportación principal materializa el array
  completo en RAM (P0 real, ya existe infraestructura streaming sin
  wireear en `backend/export_streaming/`); confirmado
  `threading.Condition` en el ring buffer RT; no se localizó un módulo
  CED dedicado; ARCHIVAL_SAFE/RF64/recovery no auditados a fondo;
  saneamiento DSP finite mapeado como candidata de bajo riesgo para la
  próxima sesión.
- **Veredicto explícito**: 0.06.006 (esta entrega) **NO supera los
  Gates 3 y 4** de la orden y **NO debe entregarse a Aldhira
  Phonographic todavía** — el resto de la orden (rediseño del ring
  buffer RT, migración del export a streaming, máquina ARCHIVAL_SAFE,
  RF64, pruebas de larga duración e inyección de fallos) requiere
  sesiones dedicadas, varias de ellas con capacidad de probar audio
  real que este sandbox no tiene.

---

## [025] — 2026-09-10 — Fuente Utendo en celdas compartidas del contómetro + megacelda de señal conectada de verdad al motor de captura
Gap de referencia: [gaps/GAP-023.md](gaps/GAP-023.md)

- Registrada la fuente Utendo (familia real verificada por nameID 1:
  "Utendo"/"Utendo Bold") como quinta familia embebida
  (`font_celdas_compartidas()` en `lorito_fonts.py`), aplicada
  únicamente a las leyendas de las celdas COMPARTIDAS del contómetro
  principal (columnas laterales L1-L4/R1-R4 y filas de leyenda
  superior/inferior de `DigitalClock`) — pedido explícito del usuario.
  Los overlays transitorios y la leyenda de la megacelda de señal
  siguen en Creato Display, sin cambios.
- `SignalPulseCell` (megacelda de señal, GAP-018) corregida: el diseño
  anterior tenía un QTimer propio que dibujaba una síntesis de senoides
  con un "piso de movimiento" que ondulaba incluso en silencio total —
  una animación decorativa parametrizada por volumen, no un trazo real,
  tal como señaló el usuario. Ahora `set_samples()` recibe el bloque de
  MUESTRAS CRUDAS real de `CaptureEngine._monitor_block` (el mismo
  buffer que ya escribe el callback RT real de audio) durante grabación
  activa, y las dibuja directamente como un osciloscopio real — sin
  QTimer propio, sin síntesis: el trazo solo se mueve cuando llega
  señal real, y silencio real ahora sí se ve como una línea plana.
  `set_level()` se conserva solo como fallback de reproducción (sin
  buffer de muestras crudas expuesto todavía por `StreamingPlayer`),
  también sin oscilación sintética.
- Verificado numéricamente (fuera de Qt): selección de muestras en 4
  casos límite (bloque normal, bloque más chico que el ancho, silencio
  total, una sola muestra) y downmix mono sobre el shape real de
  `_monitor_block` — todos correctos. `python3 -m py_compile` de todo
  el árbol — limpio.

---

## [024] — 2026-09-10 — Corrección: overlay real de la zona Velocista "Aguilar" es "Aguilr"
Gap de referencia: [gaps/GAP-022.md](gaps/GAP-022.md) (addendum)

- El usuario corrigió el overlay de la zona Aguilar (0.70…0.89 del
  Scrub Velocista): el texto real es "Aguilr", no "Aguilar" como decía
  el diccionario `SPEED_ZONE_DISPLAY_NAMES` citado en la revisión
  anterior. Corregido en `lorito_overlay_registry.py` y
  `_speed_zone_coded_name()` de `lorito_main_window.py`.
- Confirmado que `backend/lorito_normalization.py` (sufijo de nombre de
  archivo en exportación) usa el nombre completo "Aguilar" para un
  propósito distinto — no entra en conflicto, sin cambios ahí.
- `python3 -m py_compile` de todo el árbol — limpio.

---

## [023] — 2026-09-10 — Overlays reales del contómetro para Seek/Morpher/Velocista y Expn Signal (corrección de [022])
Gap de referencia: [gaps/GAP-022.md](gaps/GAP-022.md)

- El usuario corrigió el hallazgo de la revisión anterior: CRAC SÍ
  muestra overlays reales en el contómetro principal para los 3 Scrubs.
  Auditoría confirma: Seek → "SeekYng" (`crac_scrub_seek.py`), Morpher →
  "ScCue"/"ScRew" según dirección (`mega_panel_controller.py` —
  encontrados en la revisión anterior pero sin usar por error), y
  Velocista → nombre codificado de zona de velocidad según el ratio
  exacto (`_carol_speed_label()` + `SPEED_ZONE_DISPLAY_NAMES`):
  CaLibrt/Aguilar/CromTn/SupRpdr/VerLcha/JayaquTe/UltrJayaqute.
- Corregido el overlay de exportación de "Export" a "Expn Signal"
  (`setOverlayExpnSignal()` real de CRAC, mayor prioridad).
- Ciclo de vida implementado tal como pidió el usuario: Seek/Morpher
  terminan exactamente al soltar el control; Velocista se mantiene 4s
  más tras soltar con un QTimer persistente (`stop()+start()`), que se
  reinicia si se vuelve a tocar el control dentro de ese margen —
  mismo mecanismo que el "Fnc No Disp" real de CRAC.
- Hallazgo colateral corregido de paso: el "Fnc No Disp" real de CRAC
  dura 4000ms con reinicio de cronómetro (no 1500ms con
  `QTimer.singleShot` suelto, como tenía Lorito Aldhiro).
- `_speed_zone_coded_name()` verificado numéricamente (24 valores,
  todos los bordes de zona) contra la tabla real de CRAC — coincide
  exactamente. `python3 -m py_compile` de todo el árbol — limpio.

---

## [022] — 2026-09-10 — Overlays reales de Velocista/Morpher/Export + color dorado uniforme en todas las leyendas
Gap de referencia: [gaps/GAP-021.md](gaps/GAP-021.md)

- Continuación de la auditoría del árbol de overlays de CRAC (mismo
  tarball de la revisión anterior): búsqueda de `setOverlayScrubMsg(`
  en todo `src/crac/` confirma que CRAC NO muestra "Speed"/"Morpher"
  como overlay del contómetro — eso era una aproximación de una sesión
  muy anterior de Lorito Aldhiro. El mecanismo real
  (`_update_scrub_drag_factor_legend()`, patch115) es una leyenda de
  factor de arrastre con formato `f"x{ratio:.2f}"` (Velocista) /
  `f"x{ratio:.2f}R"` si reversa (Morpher), en una celda VFD dedicada
  que Lorito Aldhiro no tiene libre (sus 8 celdas laterales ya están
  asignadas por instrucción explícita del usuario).
- Adaptación documentada: se reutiliza el overlay transitorio existente
  (categoría SCRUBS) pero con el texto/formato real de CRAC, actualizado
  en vivo en cada tick de arrastre — `_on_speed_changed()` y
  `_on_morpher_changed()` en `lorito_main_window.py`.
- Confirmado que el overlay "Export" ya coincidía exactamente con el
  texto real de CRAC (`_painting_mixin.py` línea 1917) — sin cambios
  de texto.
- `lorito_overlay_registry.py` reescrito: TODAS las entradas del
  registro (NR, ALC, HX Pro, Monitor, EQ/BIAS, MPX, Focus, Export,
  Pause, SIPActiV, OvFlow TP, Side A/B, etc.) recoloreadas al mismo
  dorado lumínico uniforme (`rgba(255,204,85,225)`), por instrucción
  explícita del usuario — antes cada categoría tenía un color propio
  calcado de CRAC. Entradas muertas `SCRUB_SPEED`/`SCRUB_MORPHER`
  eliminadas del registro (reemplazadas por el texto dinámico).
- Verificado con `python3 -m py_compile` de todo el árbol — sin
  referencias colgantes a los tokens eliminados.

---

## [021] — 2026-09-10 — Auditoría del árbol de overlays de CRAC: vocabulario real de MONITOR y MPX FI
Gap de referencia: [gaps/GAP-020.md](gaps/GAP-020.md)

- El usuario resubió el tarball de CRAC, esta vez con el árbol fuente
  completo (`src/crac/...`), para auditar el árbol de overlays y
  cerrar el límite documentado en la revisión anterior (los mensajes
  de MONITOR se habían inventado por no tener el literal real
  disponible).
- Auditoría contra `src/crac/studio/_ui_events_mixin.py` (§1.22,
  auditoría CRAC 0.37→0.38) y `_overlays_mixin.py`/`_painting_mixin.py`
  del VFD: el botón físico MONITOR de CRAC cicla 4 pasos —
  OFF→ST→L→R→OFF — con overlay real "Monitoring ST"/"Monitoring Ls"/
  "Monitoring Rs"/"Monitoring OFF", verde esmeralda `QColor(0,230,154)`,
  4 segundos. Corregido en `lorito_overlay_registry.py` y
  `lorito_main_window.py` (antes: texto inventado y 1500ms).
- Auditoría del filtro MPX real de CRAC (`_state_mixin.py::
  update_mpx_active()`): overlay real "MPX FI" (no "MPX"), verde señal
  `QColor(0,230,118)`, 4 segundos — corregido en ambos archivos.
- Confirmado por búsqueda exhaustiva que FOCUS y EQ/BIAS (emulador de
  ecualización/bias por tipo de cinta) NO tienen precedente en CRAC —
  se mantienen como diseño propio de la revisión anterior, sin cambios.
- Verificado con `python3 -m py_compile` de todo el árbol — cambios
  puramente de vocabulario/color/timer, sin tocar lógica de la cadena
  DSP.
- Salto de versión explícito a 0.06 pedido por el usuario.

---

## [020] — 2026-09-10 — DSP MPX/EQ-BIAS/FOCUS (Numba/NumPy), motor de monitorización en tiempo real, menús MONITOR y EQ/BIAS
Gap de referencia: [gaps/GAP-019.md](gaps/GAP-019.md)

- Reversión de la fusión de paneles (log/duración de cinta/forma de
  onda) del rediseño VFD anterior — vuelven a su distribución
  independiente previa.
- Morpher y Speed scrub bars adaptados al mismo esquema visual del SVG
  de referencia ya aplicado al Control de Escaneo (quedó pendiente en
  la revisión anterior), conservando su lógica bipolar/de suavizado
  intacta.
- Nuevo DSP MPX (`lorito_dsp_mpx.py`): filtro notch de piloto FM
  estéreo (19kHz, +38kHz si el sample rate lo permite), biquads RBJ
  acelerados con Numba (degrada con gracia a NumPy puro si Numba no
  está instalado) — verificado numéricamente (-155dB en 19kHz, 1kHz
  intacto). Vive en el menú OPTAPE, junto a HX PRO/ALC.
- Nuevo DSP EQ/BIAS (`lorito_dsp_eq_bias.py`): emulador de las curvas
  reales IEC 60094 de los 4 tipos de cinta (NORMAL 120µS, CrO2/FeCr/
  Metal 70µS) + headroom de bias creciente por tipo — verificado
  numéricamente. Menú propio "EQ/BIAS", overlay de la fórmula 4s al
  seleccionar.
- Nuevo DSP FOCUS (`lorito_dsp_focus.py`): corrección de azimuth/fase
  L-R en tiempo real vía correlación cruzada + desplazamiento
  fraccionario causal — verificado numéricamente (correlación L/R
  0.38→0.9997 tras corregir un error de signo detectado por el propio
  test). Vive en el menú OPTAPE, overlay "Focus" 4s al activar.
- `NRCoordinator` extendido con MPX/FOCUS (independientes) y EQ/BIAS
  (selección única) en la cadena real de procesamiento del drain loop
  de captura — verificado end-to-end con los 3 DSP activos a la vez.
- Nuevo motor de monitorización de señal en tiempo real
  (`lorito_monitor_engine.py`): ring buffer + `sd.OutputStream` propio
  + downmix Numba (Stereo/Mono L/Mono R/Desactivado), conectado al
  callback de entrada de `CaptureEngine` (que ya copiaba a
  `_monitor_block` sin ningún consumidor real). Menú "MONITOR" nuevo,
  con la leyenda MON 1/2/3 del contómetro avanzando cíclicamente.
  Downmix y ring buffer verificados numéricamente; el `OutputStream`
  en sí no pudo probarse contra hardware real (sandbox sin dispositivo
  de audio ni `sounddevice` instalado).
- Investigación web previa al diseño de los 3 DSP (filtro MPX real,
  curvas IEC 60094, principio de auto-azimuth de decks de gama alta),
  con fuentes documentadas en el gap de referencia.
- Límite explícito documentado: los mensajes overlay de MONITOR no son
  un calco verificado del texto literal de CRAC (esa función no venía
  en los tarballs adjuntos a ninguna sesión) — inferidos del mismo
  estilo terso ya confirmado para el resto del registro.

---

## [019] — 2026-09-09 — Rediseño VFD dorado lumínico (contómetro, megacelda de señal, botones retroiluminados, scrubs, lienzo crema/madera, Megapanel fusionado)
Gap de referencia: [gaps/GAP-018.md](gaps/GAP-018.md)

- Rediseño visual completo pedido por el usuario, estilo VFD dorado
  lumínico calcado del acabado de CRAC (vidrio ahumado + scanlines +
  fósforo). Contómetro principal repintado sobre `paint_vfd_glass()`
  (nueva en `lorito_theme.py`), dígitos y TODAS las leyendas (arriba/
  abajo/columnas laterales L1-L4/R1-R4, con los textos exactos pedidos:
  LADO A/B, STEREO, MONO, MON 1/2/3, MPX, NORMAL, DITHER, FOCUS) en un
  único tono dorado lumínico.
- Nueva megacelda `SignalPulseCell` debajo del grupo de celdas del
  contómetro, misma altura que este (fórmula cerrada nueva,
  `TIMER_H == MEGA_PULSE_H`), con una línea ondulante dorada que
  reacciona al nivel de señal real (mismo dato que alimenta los VU
  meters).
- Lienzo ampliado 960×570 → 1040×710 (calculado antes de tocar ningún
  panel, como pidió el usuario) para que los cambios no desborden.
  Fondo dinámico por imagen (CRAC) reemplazado por un lienzo estático
  crema vintage/madera pulida (`WoodCanvasBackground`), sin imagen de
  fondo dinámica en Lorito Aldhiro.
- Los 5 botones de transporte migrados a `LoritoTransportButton`
  (nueva en `lorito_buttons.py`): conservan su bisel/QSS ya
  sincronizado, con el símbolo (círculo/triángulo/barras/cuadrado/
  eject, calcado del SVG entregado por el usuario) retroiluminado
  desde el propio símbolo al pulsar o en estado activo.
- `ScrubBarPlay` ("Control de Escaneo") rediseñado sobre el SVG de
  fader horizontal entregado (placa, marcas de graduación, ranura, cap
  metálico rectangular), longitud/arrastre reacondicionados al ancho
  real del widget. Morpher/Speed scrub bars sin tocar (ver límite
  explícito en el gap).
- Media Anim ahora cuadrado (lado = promedio entre su ancho de diseño
  y el nuevo alto del contómetro) y con tipografía Helvetica propia
  registrada (`lorito_fonts.py`, verificada por nameID real de los 4
  `.ttf` entregados).
- Menú "DSP" nuevo con submenú "DITHER" (en Lorito Aldhiro vive aquí,
  no en Pañalissu como en CRAC) — cablea la celda R3 y su parpadeo real.
- Log + duración de cinta + forma de onda agrupados visualmente en un
  Megapanel vitrificado (`VitrifiedMegapanel`) — reconstrucción propia,
  el módulo real de fusión de CRAC no venía en los tarballs de esta
  sesión (ver límite explícito en el gap).
- Verificado con `python3 -m py_compile` de todo el árbol tras cada
  edición y con verificación numérica (fuera de Qt) de que la nueva
  cascada de layout vertical cabe dentro del lienzo ampliado sin
  overlap. Sin verificación visual con PySide6 real (no disponible en
  este sandbox).

---

## [018] — 2026-09-08 — LORITO EXPORTADOR: réplica completa (3 secciones de normalización, panel de información)
Gap de referencia: [gaps/GAP-017.md](gaps/GAP-017.md)

- Sesión dedicada (indicada al cierre de GAP-016) para acercar LORITO
  EXPORTADOR a la réplica real del panel MANUAL de CRAC. Hallazgo clave:
  los enums ya reales de Lorito Aldhiro (`NormalizationMode`/
  `NormalizationModeV21`) correspondían EXACTO, valor por valor, a la
  separación en 3 secciones de CRAC (básica/avanzada/preset de cinta) —
  no hubo que inventar ninguna clasificación nueva.
- `LoritoExportadorDialog` reescrito con la estructura de dos columnas
  real: NORMALIZACIÓN básica + NORMALIZACIÓN AVANZADA + PERFIL DE
  CINTA/PRESET como 3 combos separados con **exclusión mutua real**
  (idéntico mecanismo a CRAC — verificado con ejecución real, no
  inspección de fuente), más el panel INFORMACIÓN DEL PERFIL. Al
  confirmar, la normalización activa (prioridad avanzada > cinta >
  básica, igual que `get_params()` de CRAC) se escribe de vuelta al
  `norm_box` real. Sub-diálogo de opciones avanzadas por códec y
  cabecera con imagen quedan sin portar — sin equivalente en Lorito
  Aldhiro hoy, documentado en GAP-017 §4.
- Hallazgo colateral real: `QFrame` faltaba en los imports de
  `lorito_dialogs.py` — encontrado por los tests de esta sesión al
  ejecutar el diálogo de verdad, no por revisión manual.
- Infraestructura de tests mejorada: los stubs compartidos de PySide6
  ganaron `QComboBox`/`QLineEdit`/`QLabel` con estado real (antes
  resolvían al mismo stub genérico permisivo que cualquier otra clase)
  y una metaclase que resuelve cualquier constante de clase no listada
  a un comodín — esto, de paso, **resolvió la barrera que bloqueaba la
  construcción completa de `LoritoAldhiroStudio()` desde GAP-013**:
  confirmado que ahora construye de punta a punta sin excepción, primera
  vez en el historial de este proyecto (no confirma apariencia visual,
  solo ausencia de errores de construcción).
- 12 tests nuevos (`tests/test_export_panel_replica.py`) + 1 test de
  regresión que fija el hito de construcción completa. 134/134 en la
  batería completa del proyecto.

---

## [017] — 2026-09-08 — Imagen espectral post-export + LORITO EXPORTADOR (versión escalada)
Gap de referencia: [gaps/GAP-016.md](gaps/GAP-016.md)

- Generador de imagen espectral post-exportación portado completo desde
  CRAC (`crac_export_spectral_engine.py`/`crac_export_spectral_render.py`)
  sin recortes de matemática — `lorito_export_spectral_engine.py`
  (backend puro FFT/percentiles/color) + `lorito_export_spectral_render.py`
  (frontend Qt). Marca de plataforma "Carola Records Aldhira Capture"
  (rosa) → **"Lorito Aldhiro" en amarillo**, pedido explícito. Conectado
  al final de `export()`, genera `{base}_spectral.png`, envuelto en su
  propio `try/except` para no tumbar una exportación ya exitosa.
- **LORITO EXPORTADOR** (`LoritoExportadorDialog`, `lorito_dialogs.py`):
  nuevo diálogo que se abre al pulsar "SALIDA", con el mismo mecanismo
  de dos pasos que CRAC (elegir parámetros → INICIAR dispara el export
  real / ABORTAR cancela). Reutiliza (reparenta, no duplica) los combos
  ya reales de `LoritoAldhiroStudio`; agrega selector de directorio de
  salida (capacidad nueva — antes fijo a `ARCHIVE_DIR`).
  **Por indicación explícita del usuario, la réplica visual completa
  del panel de 1168 líneas de CRAC (cabecera con imagen, secciones de
  normalización separadas, sub-diálogo de opciones avanzadas por códec,
  panel de información) queda diferida a una sesión propia** — detalle
  completo en GAP-016 §3/§6.
- Menú CODEC (agregado en GAP-015) retirado de la barra — la elección
  de códec vive ahora solo en LORITO EXPORTADOR. Confirmado que HOST/
  MUESTRA siguen actualizando de verdad; BITDEPH mejorado para intentar
  un match real contra `opt1_box` antes de degradar a "Fnc No Disp".
- Verificación real: 14/14 tests nuevos (`tests/test_export_spectral.py`)
  — motor espectral verificado con audio sintético real (forma/dtype,
  franjas negras de cabecera/pie, alfa opaco, estéreo→mono, silencio,
  layout personalizado); wiring del nuevo flujo de exportación y del
  menú confirmado contra el código fuente real. 121/121 en la batería
  completa del proyecto.

---

## [016] — 2026-09-08 — Reestructuración de la UI principal: contómetro estirado, nuevo orden, celdas verticales
Gap de referencia: [gaps/GAP-015.md](gaps/GAP-015.md)

- Reordenados los widgets del lienzo principal (menú → título →
  contómetro → botones → escaneo → torcedura → velocista → visor de
  señal → logs → cinta) y retirados de la vista los combos legados que
  quedaban debajo del contómetro (Frecuencia/Codec/Profundidad/
  NORMALIZACION/Duración de Cassette) — ocultos, no eliminados: siguen
  siendo los mismos objetos que el resto del código lee, sin romper
  funcionalidad. Agregado CODEC como entrada nueva de menú
  (WAV/FLAC/OGG/WV); Profundidad(export)/NORMALIZACION quedan sin
  entrada de menú equivalente todavía, documentado como pendiente.
- Renombres: título → "LORITO ALDHIRO {versión}"; botón de exportación
  → "SALIDA"; Scrub Seek → "CONTROL DE ESCANEO"; Scrub Morpher →
  "CONTROL DE TORCEDURA"; Scrub Velocista → "CONTROL VELOCISTA"; panel
  de forma de onda → "VISOR DE SEÑAL INTERACTIVO".
- Contómetro estirado verticalmente (TIMER_H ≈139px, antes 62px) para
  ocupar el espacio liberado, calculado de abajo hacia arriba (suma de
  las alturas fijas de los 7 bloques que siguen + un PAD=7 constante
  entre cada uno, el resto se le asigna íntegro al contómetro) — no un
  número mágico fijado a mano. La celda del media anim se estira junto
  con él (ya usaba `TIMER_H` como alto).
- Agregadas 4 celdas verticales invisibles en cada extremo de la
  megacelda del contómetro (`DigitalClock.LEFT_CELLS`/`RIGHT_CELLS`),
  sumadas a la celda de esquina que las filas superior/inferior ya
  tenían en ese borde — 6 celdas por extremo en total, mismo patrón de
  celda invisible ya usado. Quedan como slots vacíos
  (`set_side_cell()`), sin contenido asignado — pendiente de
  instrucción explícita sobre qué deben mostrar.
- Verificación real: 7/7 tests nuevos (`tests/test_ui_layout_geometry.py`)
  confirman matemáticamente que la cascada no tiene superposiciones,
  cabe dentro del lienzo, y que el contómetro (no los demás bloques) es
  quien absorbe cualquier espacio extra si el lienzo creciera — las
  constantes se verificaron contra el código fuente real, no
  supuestas. 5 tests nuevos para las celdas verticales en
  `test_overlay_system.py`. Confirmado que `lorito_main_window.py`
  sigue importando limpio tras la reestructuración
  (`test_module_decomposition_regression`). 107/107 en la batería
  completa del proyecto. **Sin verificación visual con PySide6 real**
  — ver GAP-015 §8.

---

## [015] — 2026-09-08 — Extensión de tolerancia de Lado B (+3 min al tope máximo)
Gap de referencia: [gaps/GAP-014.md](gaps/GAP-014.md)

- Replicado en Lorito Aldhiro el fix ya aplicado en CRAC
  (`CHANGELOG.md` de CRAC `[0.37.348]`: "extensión de tolerancia Lado B
  (5→8 min), sumados ÚNICAMENTE al tope máximo"). Ventana de tolerancia
  de Lado B: C-60 `[58,63]min→[58,66]min`, C-90 `[87,92]min→[87,95]min`
  — el mínimo no se mueve, solo el máximo (+3 min), ventana 5→8 min en
  ambos modos.
- Tocados los tres puntos donde vive el valor, para que el motor real
  (fuente de verdad desde GAP-013) y el camino de fallback/documental
  coincidan: `lorito_crac_motor_v4.py` (`_PRESET_C60`/`_PRESET_C90`.
  `tol_max_b_s`), `lorito_tape_log_panel.py` (`_STOP_INTERVALS`, ventana
  5→8 min), `lorito_main_window.py` (`total_secs` del constructor de
  cada `TapeLogPanel`, 3780→3960s / 5520→5700s). Verificado con
  aritmética exacta por qué había que subir la ventana Y el total_secs
  juntos (no solo uno) para que el efecto neto fuera únicamente en el
  tope máximo, sin desplazar el mínimo — detalle completo en GAP-014 §3.
- De paso, corregida una intermitencia real (ajena a este fix) en 2
  tests de integración del drain loop (`test_nr_systems.py`): un
  `time.sleep(0.3)` fijo reemplazado por espera activa sobre
  `ced.frame_count`, confirmado estable en 5 corridas consecutivas.
- 9/9 en `tests/test_crac_motor_v4.py` (2 tests nuevos). 96/96 en la
  batería completa del proyecto.

---

## [014] — 2026-09-08 — Motor CRAC v4 integrado — la aplicación completa arranca por primera vez
Gap de referencia: [gaps/GAP-013.md](gaps/GAP-013.md)

- Integrado el módulo entregado por el usuario, que resolvía el bloqueo
  crítico encontrado en GAP-012: `aecct2_crac_motor_v4` (importado sin
  fallback desde `lorito_tape_log_panel.py` y, se descubrió en esta
  sesión, también desde `lorito_main_window.py` directamente). Copiado
  como `lorito_aldhiro/frontend/widgets/lorito_crac_motor_v4.py`,
  renombrado AECCT2→Lorito Aldhiro. El archivo ya traía un alias
  `CRACMotorV3 = CRACMotorV4` ("drop-in replacement para v3") — no hizo
  falta tocar ninguno de los 9 call-sites de `_crac_motor` que GAP-012
  había marcado como pendientes de auditoría.
- Confirmado con test que los presets C-60/C-90 de este motor coinciden
  exacto con los valores "CRAC-MOTOR-v2" que GAP-009 ya había
  encontrado hardcodeados en el resto del código — este motor es la
  fuente de verdad real de esos números.
- **La aplicación completa arranca por primera vez**: el test de
  regresión de GAP-012 vuelve a pasar con cero bloqueos conocidos;
  `lorito_main_window.py` importa limpio y expone `LoritoAldhiroStudio`;
  los 3 tests de `test_overlay_system.py` que quedaban saltados desde
  GAP-010/011 por este mismo bloqueo ahora corren de verdad. Un intento
  de construcción real de `LoritoAldhiroStudio()` con stubs avanza
  mucho más lejos que antes, deteniéndose solo en una limitación de los
  propios stubs de prueba, no en código de Lorito Aldhiro.
- 7 tests nuevos (`tests/test_crac_motor_v4.py`): alias, presets, ciclo
  completo pausa forzada→escape→volteo a Lado B, excedente, reset.
  94/94 en la batería completa del proyecto — **cero tests saltados por
  primera vez** en el historial de este proyecto.

---

## [013] — 2026-09-08 — DBX I/II/224, conexión real al motor de audio, test de regresión de módulos
Gap de referencia: [gaps/GAP-012.md](gaps/GAP-012.md)

- DBX ahora tiene los tres tipos reales I/II/224 (igual que CRAC), cada
  uno con su propia física de pre/de-énfasis y tiempos de ataque/
  release verificada contra `crac_dbx_nr.py`. Submenú "DBX ▸" en el
  menú NR; `NRCoordinator.select()` acepta parámetros de construcción
  genéricos para el perfil (`dbx_type=...`).
- Conectados los motores NR al audio real — pero NO en el callback RT
  (`_audio_callback`, que tiene reglas absolutas de cero-allocation
  documentadas en su propio código): se conectó en `_drain_loop_fn`
  (`lorito_capture_engine.py`, CAPA 1, un hilo dedicado que ya tolera
  logging/allocaciones), el punto correcto de la arquitectura para DSP
  con numpy. `CaptureEngineV2.nr_coordinator` asignado desde
  `LoritoAldhiroStudio.__init__` — la misma instancia que ya manejan
  los menús NR/OPTAPE. Verificado con las clases REALES de captura
  (RBA/CED reales, no dobles): un bloque de 800Hz con Dolby B
  seleccionado sale atenuado ~-10dB al llegar a la cola de disco, tal
  como exige la física real del sistema.
- Test de regresión nuevo, pedido explícito ("no existe en Lorito
  Aldhiro"): `tests/test_module_decomposition_regression.py` recorre
  TODO el árbol de módulos (la descomposición del monolito original) e
  importa cada uno, detectando la clase de bug que ya apareció varias
  veces sin que hubiera un test automático para ella. **Encontró un
  bloqueo real, todavía sin resolver**: `lorito_tape_log_panel.py`
  importa `aecct2_crac_motor_v4` sin `try/except` — un módulo externo
  no incluido en ningún tarball. Hoy, `lorito_main_window.py` (y por lo
  tanto la aplicación completa) no puede importarse. Documentado con
  precisión en el propio test (`KNOWN_BLOCKING_IMPORTS`, falla si algún
  día se resuelve sin actualizar el diccionario) y en GAP-012 §4/§6 —
  no resuelto en esta sesión, requiere su propia auditoría de los 9
  call-sites de `_crac_motor`.
- 84/84 en la batería completa del proyecto (7 tests nuevos de DBX I/
  II/224, 2 de integración real drain-loop↔NR, 4 del test de
  regresión de módulos).

---

## [012] — 2026-09-08 — Motores DSP reales de reducción de ruido (8 sistemas) + HX Pro + ALC
Gap de referencia: [gaps/GAP-011.md](gaps/GAP-011.md)

- Construidos los 8 motores DSP reales pedidos: Dolby B/C/S, DBX, ANRS,
  S-ANRS, DNL, DNR — más Dolby HX Pro y ALC (este último con efecto de
  respiro analógico real, sin precedente en CRAC, por pedido explícito).
  Paquete nuevo `lorito_aldhiro/backend/nr/` (`lorito_nr_dsp_core.py`
  con las primitivas compartidas — biquad shelving, compander RMS,
  paso-bajo deslizante, gate de dos bandas —, `lorito_nr_profiles.py`
  con los 8 perfiles, `lorito_nr_hxpro.py`, `lorito_nr_alc.py`,
  `lorito_nr_coordinator.py`). Física verificada contra los 9 motores
  reales auditados en CRAC (`crac.nr.*`, ~7800 líneas) — mismos Fc/
  ganancias/topología de bandas, sin portar el andamiaje de motores de
  calibración/medición/auto-detección que ni el propio CRAC invoca.
- Tres bugs reales encontrados y corregidos durante la verificación con
  tests: la ley de ganancia del compander portada inicialmente de CRAC
  EXPANDÍA el rango dinámico en vez de comprimirlo (fórmula sin
  normalizar contra el nivel de referencia — corregida a la fórmula
  feed-forward correcta); el divisor de bandas de DNR usaba un shelving
  con ganancia negativa en vez de un paso-bajo real; los coeficientes de
  ataque/release de ALC estaban calibrados para muestra pero la
  envolvente avanza por bloque (~44x más lento que lo pedido).
- Cableado real (no solo UI): `NRCoordinator` (selección estructural
  única entre los 8 sistemas + HX Pro/ALC independientes) instanciado
  en `LoritoAldhiroStudio`, conectado a los menús NR/OPTAPE de GAP-010
  (además de encender celda/overlay). **No conectado todavía al
  callback de audio en tiempo real** — seleccionar un sistema lo deja
  instanciado y listo, pero el audio capturado aún no pasa por él;
  pendiente de sesión dedicada (mismo criterio de máxima cautela sobre
  el hilo RT ya establecido desde GAP-002).
- Verificación real: 18/18 tests nuevos (`tests/test_nr_systems.py`,
  DSP puro con audio sintético vía numpy, sin PySide6) — física de cada
  primitiva, los 8 perfiles en sus 3 modos, HX Pro, el respiro de ALC
  (ataque rápido/release lento, recuperación progresiva de ganancia),
  y el coordinador. 73/73 en la batería completa del proyecto.

---

## [011] — 2026-09-08 — Overlays calcados de CRAC + contómetro de 3 filas + barra de menú
Gap de referencia: [gaps/GAP-010.md](gaps/GAP-010.md)

- Corregido el vocabulario de overlays del contómetro para que sea un
  calco EXACTO del texto real de CRAC (`_painting_mixin.py`/
  `_overlays_mixin.py`, el sistema VFD terso vigente), no las frases
  descriptivas en español de un primer intento: "OvFlow TP", "Side A",
  "Side B", "FnSide A", "FnTape Aldh", "Fnc No Disp", "SIPActiV",
  "Pause", "Export". Nuevo registro
  `lorito_aldhiro/backend/lorito_overlay_registry.py`.
- `DigitalClock` (`lorito_indicators.py`) reescrito con un sistema de
  overlay generalizado por categorías con prioridad (calcada del árbol
  real de CRAC, filtrada a lo que Lorito Aldhiro tiene), compatible
  hacia atrás con `setITLOverlay()` de GAP-007/008. De paso, corregido
  un bug real heredado: `font_leyendas` se usaba sin haberse importado
  nunca — habría lanzado `NameError` al dibujar el overlay con PySide6
  real.
- Contómetro rediseñado a 3 filas: fila superior (DOLBY B|DOLBY C|DOLBY
  S|DBX|ANRS|S ANRS), megacelda del contador (sin cambios de
  comportamiento), fila inferior (DNL|DNR|ALC|ALSA|JACK|C-60 — esta
  última conmutable entre C-60/C-90/OTROS). Celdas invisibles (solo
  texto, sin Vitreous Subeventos ni logos SVG), se iluminan cuando el
  sistema correspondiente está activo.
- Barra de menú nueva (`_build_menu_bar()`, mismo patrón QToolButton+
  QMenu que CRAC): CINTA, HOST, MUESTRA, BITDEPH, NR, OPTAPE, ACERCA.
  Lienzo ampliado de 520 a 570px de alto — la cascada de coordenadas Y
  ya relativa de `lorito_main_window.py` absorbió el cambio sin tocar
  cada constante a mano. CINTA real (reutiliza `cassette_dur_box`);
  HOST/MUESTRA/BITDEPH degradan con gracia a "Fnc No Disp" donde no hay
  backend real verificado (documentado honestamente, no fingido); NR/
  OPTAPE encienden celda+overlay sin motor DSP real todavía (ver
  pendiente); ACERCA siempre cae a "Fnc No Disp", tal como se pidió.
- **Motor DSP real de los 8 sistemas NR + HX Pro + ALC — NO incluido en
  esta sesión** (detalle y motivo en GAP-010 §5): la UI está
  completamente cableada, el backend de audio real queda para una
  sesión dedicada, mismo criterio de catálogo incremental que
  VitriCarola/Portal Lucha Carola JVC en CRAC.
- Verificación real: 11/11 tests nuevos (`tests/test_overlay_system.py`)
  — calco exacto de texto verificado carácter por carácter, prioridad
  de categorías, celdas de leyenda, y wiring confirmado contra el código
  fuente real de `lorito_main_window.py` (stubs de PySide6 ampliados
  para cubrir cualquier clase de QtWidgets). Hallazgo colateral (ajeno
  a este encargo): `lorito_tape_log_panel.py` depende de un módulo
  externo (`aecct2_crac_motor_v4`) no incluido en ningún tarball —
  documentado en GAP-010 §6, no investigado más a fondo.

---

## [010] — 2026-09-08 — Auditoría completa del stability patch + integración como módulo vivo
Gap de referencia: [gaps/GAP-009.md](gaps/GAP-009.md)

- Auditado `aecct2_stability_patch.py` (2698 líneas, ~25 parches
  A-1..K-3) parche por parche contra el código real de Lorito Aldhiro —
  no un port mecánico de las heurísticas originales, que habrían fallado
  en al menos dos casos (ver más abajo). Integrado como
  `lorito_stability_patch.py`, un módulo vivo que se ejecuta en cada
  arranque desde `lorito_bootstrap.py` (reemplaza un bloque
  `try/except ImportError` que ya intentaba este import, sin poder
  resolverlo — mismo patrón exacto que se encontró con el motor ITL en
  GAP-008). A diferencia de CRAC (donde este mismo parche fue retirado y
  archivado desde v0.34), en Lorito Aldhiro sigue siendo funcional: la
  clase que el parche parchea (`TapeLogPanel`) sigue siendo la real
  aquí, nunca fue reemplazada.
- Resultado de la auditoría: 11 de 25 parches ya integrados nativamente
  (verificado con cita de archivo:línea, no supuesto); 2 (K-1, K-2)
  SUPERADOS por una especificación más nueva que la que el parche
  original asume — aplicarlos literalmente habría sido un RETROCESO
  (Lorito Aldhiro ya tiene `total_secs=3780/5520` y
  `_FLIP_INTERVALS["C-90"]=(43,48)min`, más recientes que lo que K-1/K-2
  consideran "corregido"); 1 (H-2) es una divergencia deliberada
  (`PE_SPEED_DEBOUNCE=0.030` en vez de `0.005`, por un fix posterior y
  distinto, `FIX-DOUBLE-FLUSH`) que tampoco se revirtió; 2 (D-4, E-3)
  aplicados directamente al código fuente esta sesión; 9 diferidos con
  razón documentada (destaca: `_integrity_monitor` no está cableado a
  ningún call-site del proyecto — optimizarlo con H-1/B-4 sería
  prematuro).
- D-4: `fsync` del archivo `.sha256` en
  `lorito_export_integrity.py::_write_checksum_file()`. E-3: `fsync`
  del manifest (antes del rename atómico) y del heartbeat en
  `lorito_snapshot.py::CrashGuard._write_manifest()` — ambos cierran un
  escenario real de pérdida de datos ante corte de energía.
- Verificación real (no solo revisión de código): se instalaron stubs
  mínimos de `soundfile`/`sounddevice`/`PySide6` para poder importar y
  ejercitar `lorito_main_window.py`/`lorito_capture_engine.py`/
  `lorito_tape_log_panel.py`/`lorito_playback_engine.py`/
  `lorito_export_integrity.py`/`lorito_snapshot.py` REALES en este
  sandbox. 6/6 tests nuevos (`tests/test_stability_patch.py`) confirman
  D-4/E-3 detectados contra el código fuente real, K-1/K-2 nunca
  reportados como aplicados (guarda de regresión), y H-2 no revertido.

---

## [009] — 2026-09-08 — Motor ITL real integrado (fix FIX-FORCED-PAUSE-ESCAPE) + hallazgo sobre stability patch
Gap de referencia: [gaps/GAP-008.md](gaps/GAP-008.md)

- Integrado `lorito_itl_integration.py` (antes `aecct2_itl_integration.py`,
  906 líneas, motor "CLCC-ITL Monolith v2.0.0") — `lorito_main_window.py`
  ya tenía cableada la API completa (`integrate_itl_into_studio`,
  `ITLBridge.on_flip_side_b/on_start_recording/_gui_tick`) esperando
  este módulo, que nunca estuvo incluido en ningún tarball anterior.
  `lorito_itl_bridge.py` ahora importa el módulo interno real en vez de
  intentar un import externo que siempre fallaba — `_ITL_AVAILABLE` es
  `True` por primera vez.
- Auditado en paridad con el ITL de CRAC (`crac_v0_37_400`) y
  encontrada la misma falla histórica ("nunca se podía voltear a Lado
  B") que en GAP-007, pero esta vez SÍ presente: tres puntos de
  conmutación de pausa forzada comparaban `silence_timer >= 1.0`
  (segundo completo de silencio continuo requerido). Corregido con
  `_FORCED_PAUSE_ESCAPE_SECS = _MASTER_DT` (un tick, ≈67ms) — traducción
  exacta del `FIX-FORCED-PAUSE-ESCAPE` de CRAC a la semántica propia de
  este motor (detalle de por qué no es un `0.0` literal en GAP-008 §2.2).
  4/4 tests reales (`tests/test_itl_integration.py`) reproducen el bug
  con el umbral original y confirman el fix con el módulo real.
- Renombrado AECCT2→Lorito Aldhiro en el módulo integrado
  (`AECCT2Studio`→`LoritoAldhiroStudio`, cabecera, import muerto de
  `aecct2_config.suppress_gui_log` eliminado — sin equivalente en Lorito
  Aldhiro). Logger interno (`aecct2.itl_integration`) dejado tal cual,
  mismo patrón que el resto de loggers ya existentes en el proyecto
  (fuera del alcance del renombre de marca, ya documentado en GAP-002).
- **`aecct2_stability_patch.py` (2698 líneas) NO integrado.** Hallazgo
  crítico: es el mismo parche que CRAC archivó como "[FALLA 0.34 —
  MÓDULO RETIRADO]" — opera sobre rutas de módulo (`aecct2.aecct2_*`,
  paquete plano) que no coinciden con la estructura real de Lorito
  Aldhiro (`lorito_aldhiro.backend/frontend.lorito_*`, paquete anidado).
  Integrarlo a ciegas arriesga reintroducir lógica ya superada por el
  historial de fixes `FIX-v0.22.xx` ya documentado en el código actual
  (mismo patrón que se descubrió con el fix ITL de GAP-007). Pendiente
  de decisión del usuario — detalle completo en GAP-008 §3/§4.

---

## [008] — 2026-09-08 — Auditoría ITL CRAC vs Lorito Aldhiro + overlays ITL del contómetro
Gap de referencia: [gaps/GAP-007.md](gaps/GAP-007.md)

- Auditado `crac_v0_37_400_csa_speed_action_servosistemas.tar.gz` (última
  CRAC 0.37) comparando su motor ITL contra Lorito Aldhiro. Hallazgo
  estructural: no son comparables directamente — el "ITL" de Lorito
  Aldhiro era, hasta esta sesión, un stub de 16 líneas
  (`lorito_itl_bridge.py`) que intentaba importar un módulo externo
  ausente; la lógica real de volteo de lado vive inline en
  `lorito_main_window.py`/`lorito_tape_log_panel.py`, heredada de CRAC
  0.22.x previo al fork (GAP-001).
- Localizado en el CHANGELOG de CRAC (2026-05-24) el bug histórico
  "nunca se podía voltear a Lado B" (cluster `FIX-FORCED-PAUSE-ESCAPE`/
  `FIX-FLIP-B-GUARD`: `SILENCE_GUARD_ESCAPE_SECS` exigía 1s completo de
  silencio continuo antes de poder desarmar una pausa forzada, bloqueando
  el volteo indefinidamente). Auditado el código real de Lorito Aldhiro
  línea por línea: el fix **ya estaba presente**, heredado directamente
  del fork (`lorito_constants.py:203`, comentario citando literalmente
  "FIX-FORCED-PAUSE-ESCAPE v0.22.44"). No se modificó nada ahí — habría
  sido reescribir código ya correcto.
- Overlays ITL nuevos en el contómetro (`DigitalClock.setITLOverlay()`/
  `.tickITLOverlayBlink()` en `lorito_indicators.py`), equivalentes a los
  del Vitreous Panel de CRAC pero limitados a las dos funciones que
  Lorito Aldhiro realmente tiene (espera de volteo a Lado B, fin de
  cinta) — sin overlay de auto-reversa, que Lorito Aldhiro no
  implementa. Disparadores conectados en `lorito_main_window.py`
  (`_make_flip_cb`, `_make_stop_cb`, `_deactivate_silence_autopause`),
  parpadeo enganchado al tick de 480ms ya existente y activo durante la
  auto-pausa.

---

## [007] — 2026-09-08 — Motor de fuentes embebidas (independiente del SO) + integración + salto de versión 0.03.001
Gap de referencia: [gaps/GAP-006.md](gaps/GAP-006.md)

- Motor nuevo `lorito_aldhiro/frontend/lorito_fonts.py`: registra fuentes
  embebidas vía `QFontDatabase.addApplicationFont()`, nunca resueltas por
  nombre del sistema operativo (mismo criterio ya aplicado en CRAC).
  Cuatro familias embebidas en `lorito_aldhiro/frontend/assets/fonts/`:
  Patopian 1986 (dígitos del contómetro principal), LLPixel (cuentavueltas
  mecánico del panel de duración de cinta), Exo 2 (texto general de la
  interfaz), Creato Display (leyendas de log y duración de cinta).
- Integrado en los widgets reales: `lorito_indicators.py::DigitalClock`,
  `lorito_status_display.py`, `lorito_tape_log_panel.py`,
  `lorito_media_anim.py`, `lorito_waveform.py`, y las 40 declaraciones
  CSS `font-family` de `lorito_dialogs.py`/`lorito_main_window.py`/
  `lorito_theme.py` (antes Futura/Helvetica Neue). `lorito_bootstrap.py`
  registra las fuentes tras crear `QApplication` y antes de construir la
  ventana principal, y fija Exo 2 como fuente por defecto de la app.
- Verificación real con `fontTools` (sin PySide6, no disponible en este
  sandbox): 4/4 tests confirman que cada archivo embebido declara
  exactamente la familia esperada. La integración visual con Qt real
  queda pendiente de un entorno con PySide6 (detalle en GAP-006 §3/§6).
- Salto de versión a 0.03.001 por indicación explícita del usuario:
  `APP_MINOR` 1→3 a mano; `_MINOR_REVISION_BASE=6` en
  `lorito_version.py` para que la REVISIÓN reinicie en 001 bajo este
  MENOR sin reescribir el historial de CHANGELOG.

---

## [006] — 2026-09-08 — Orden Maestra de Refundación: transporte interactivo (FASE 1 — contratos)
Gap de referencia: [gaps/GAP-005.md](gaps/GAP-005.md)

- Tras el renombre SIPA→AIPLO, se pasó al transporte interactivo
  (Morpher/Velocista, Fases 2-5 de §40 de la orden de 44 secciones).
  Mismo criterio de máxima cautela que en exportación (GAP-003):
  `lorito_playback_engine.py` y `lorito_scrub_bars.py` (Morpher/
  Velocista) **sin tocar** — se construyó un paquete nuevo y aislado,
  `lorito_aldhiro/backend/transport/` (`lorito_transport_state.py`,
  `lorito_transport_commands.py`, `lorito_transport_machine.py`,
  `lorito_speed_planner.py`), cubriendo §1-§14 de la orden (FASE 1).
- `TransportState` reemplaza la ambigüedad real confirmada en GAP-002
  (una sola `src_pos`) por `requested_frame`/`source_frame`/
  `head_frame`/`rendered_frame` (§3). `TransportMachine` centraliza las
  11 transiciones de §4 (comando inválido para el modo actual →
  `InvalidTransitionError`, nunca aplicado en silencio) e incrementa
  `transport_generation` en cada cambio estructural real, sin bumpear
  por cada `SET_TARGET_SPEED` intermedio (§5/§12). `TransportCommand` es
  la única superficie que un widget UI puede tocar — no expone ningún
  método capaz de mutar el estado interno directamente (§6).
  `SpeedPlanner` es la autoridad única de velocidad compartida entre
  Morpher y Velocista (§13), con `desired`/`applied`/`rendered` ratio
  distintos (§11) y curva de transición sin saltos (§7).
- Verificación real: 21/21 tests nuevos (`tests/test_transport_core.py`)
  — incluye la matriz de Seek de §32 (confirmando específicamente §10:
  Seek durante reversa mantiene `direction=REVERSE`, no fuerza
  N→N+1→...), cambio de dirección como transición de primera clase
  (§9), combinaciones reverse+speed/morph/seek (§32), coalescing de
  velocidad sin generación nueva por evento (§12), `GenerationGuard`
  descartando bloques de una generación vieja (§5), y continuidad del
  `SpeedPlanner` entre dos tramos consecutivos de UI distintas (§13).
- Pendiente explícito (detalle en GAP-005 §4/§5): sin integración con
  `PlaybackEngine` real ni con `lorito_scrub_bars.py` — bloqueado por
  falta de `sounddevice`/`soundfile`/PySide6 reales en este sandbox para
  verificar con ejecución, no solo revisión de código; crossfade/anti-pop
  (§8) y la lectura reversa real (§9) quedan para una sesión futura.

---

## [005] — 2026-09-08 — Renombre SIPA → AIPLO del subsistema de auditoría forense
Gap de referencia: [gaps/GAP-004.md](gaps/GAP-004.md)

- El usuario aclaró que "SIPA" son las iniciales reservadas al Sistema
  Inteligente de Pausa Automática real (pausa por silencio durante la
  grabación, Silence Controller) — el subsistema de auditoría forense
  (`lorito_forensics.py`) venía usando el mismo acrónimo por error.
  Renombrado a "Auditor Integrado de Parámetros Lorito Ordenales"
  (AIPLO), mismo renombre ya aplicado en CRAC 0.24.
- Cambio mecánico sin alteración de comportamiento: identificadores
  (`_SIPA_FRN_ACTIVE`→`_AIPLO_FRN_ACTIVE`, etc.), las seis cadenas de
  evento emitidas (`SIPA_TICK`→`AIPLO_TICK`, etc.), el flag de CLI
  `--sipa-analyze`→`--aiplo-analyze` en `lorito_bootstrap.py`, y el
  README. Verificado con `py_compile` sobre el árbol completo.

---

## [004] — 2026-09-08 — Orden Maestra de Refundación: motor de exportación streaming (FASE 1 + FASE 6 + FASE 7/8 parcial)
Gap de referencia: [gaps/GAP-003.md](gaps/GAP-003.md)

- Por pedido explícito del usuario, se avanzó primero la exportación
  streaming (de las dos líneas de trabajo de la orden de 44 secciones).
  `lorito_exporters.py` sigue **congelado, sin tocar** — se construyó un
  subsistema nuevo y aislado: `lorito_aldhiro/backend/export_streaming/`
  (`lorito_export_blocks.py`, `lorito_segment_provider.py`,
  `lorito_encoder_base.py`, `lorito_wav_encoder.py`,
  `lorito_atomic_finalizer.py`, `lorito_export_session.py`).
- `SegmentProvider` valida formato de todos los segmentos contra sus
  headers antes de leer una sola muestra (§21, aborta con
  `FormatMismatchError` ante discrepancia) e itera bloques acotados
  secuencialmente por segmento, liberando cada uno antes del siguiente
  (§16) — sin `soundfile` (usa `wave` de la librería estándar, suficiente
  para los segmentos PCM enteros que ya escribe `DiskWriterV2`).
  `WavEncoder` es un escritor WAV/PCM streaming nativo real (RF64 sin
  implementar todavía, documentado explícitamente en vez de truncar
  silenciosamente). `AtomicFinalizer` implementa
  `.partial → validate → checksum → atomic rename` (§24) con frame
  accounting estricto (§28) y limpieza de `.partial` huérfano (§38).
- Verificación real (no revisión de código): 9/9 tests nuevos
  (`tests/test_export_streaming.py`) — formato, bloques, reconstrucción
  fiel de PCM_24, frame accounting exacto, aborto sin archivo final ante
  fallo de encoder, recuperación de `.partial` huérfano. Prueba de
  escalado de memoria en subprocesos reales independientes
  (`tests/test_export_memory_scaling.py`, §30/§36): sesión 20x más larga
  → RSS pico 1.03x (36532 KB → 37608 KB) — confirma memoria O(bloque),
  no O(duración de la captura).
- Pendiente explícito, sin ambigüedad (detalle completo en GAP-003 §4/§6):
  FLAC/OGG/WV no migrados al contrato `Encoder` nuevo (requieren
  `soundfile`/`ffmpeg` reales para verificar, no disponibles en este
  sandbox); RF64 sin implementar; etapa DSP/Resampler y normalización de
  dos pasadas de §20/§22 sin diseñar todavía; sin integración con
  `lorito_main_window.py` (bloqueado por falta de PySide6 real, mismo
  criterio de máxima cautela que Fase 9 de Transport Core en CRAC 0.37).

---

## [003] — 2026-09-08 — Orden Maestra de Refundación (Scrubs Morpher/Velocista + Exportación): FASE 0 — congelación forense y auditoría
Gap de referencia: [gaps/GAP-002.md](gaps/GAP-002.md)

- El usuario entregó una Orden Maestra de Ingeniería de 44 secciones para
  la refundación arquitectónica total de Scrubs Morpher, Scrubs Velocista
  y el motor de Exportación, ejecutada en 10 fases propias (§40) por
  diseño multi-sesión.
- Esta revisión cierra únicamente **FASE 0**: congelación del baseline de
  `0.01.002` (sin tocar ningún archivo de `lorito_aldhiro/`) y auditoría
  real contra el código — confirmado con grep/lectura directa, no
  supuesto — de qué partes de la orden ya tienen precedente en el código
  actual (generación de sesión en `PlaybackEngine._gen`, separación
  live/commit ratio, crossfade equal-power en flush, SIPA ya
  observacional) y cuáles no existen en absoluto (máquina de estados de
  transporte, generación por bloque, `SpeedPlanner` compartido,
  exportación streaming — confirmado que los 4 codecs actuales y
  `_build_export_array()` en `lorito_main_window.py` siguen el patrón
  "captura completa en RAM" que la orden declara deprecado).
- Sin cambios de comportamiento en esta revisión. Fases 1-10 quedan
  planificadas y documentadas en `gaps/GAP-002.md`, pendientes de
  ejecución en sesiones futuras.

---

## [002] — 2026-08-31 — Bifurcación formal: prefijo `lorito_`, CHANGELOG, módulo de versión y gaps de referencia
Gap de referencia: [gaps/GAP-001.md](gaps/GAP-001.md)

- **Bifurcación oficial**: a partir de esta revisión, la rama `CRAC 0.22.57`
  (Carola Records Aldhira Capture / AECCT2, aún en construcción) se bifurca
  formalmente en **Lorito Aldhiro 0.01.002**. Es una bifurcación creada para
  resolver los problemas de recontraemergencia que atraviesa el fuero
  Finguered, y deberá usarse mientras CRAC y AECCT2 continúan su propio
  desarrollo por separado. Ver el detalle en `gaps/GAP-001.md`.
- **Prefijo `lorito_` en todos los módulos elaborados**: los 32 módulos
  producidos en la modularización mecánica (más `lorito_bootstrap.py` en la
  raíz) se renombraron con el prefijo `lorito_` (p. ej. `version.py` →
  `lorito_version.py`, `capture_engine.py` → `lorito_capture_engine.py`).
  Se actualizaron todas las rutas de import (`lorito_aldhiro.backend...`,
  `lorito_aldhiro.frontend...`) en consecuencia. Los `__init__.py` de
  paquete no se renombraron (Python los requiere con ese nombre exacto
  para reconocer el paquete).
- **Nombre de la app reemplazado por "Lorito Aldhiro"**: el título de
  ventana, el rótulo superior de la interfaz y el texto de especificación
  exportado (antes `"Carola Records Aldhira Capture"` /
  `"CAROLA RECORDS · ALDHIRA CAPTURE"` / `"Carola Records CRAC v..."`)
  ahora usan la constante `APP_BRAND = "Lorito Aldhiro"` definida en el
  módulo de versión. **Alcance de este cambio**: se tocó únicamente el
  nombre/título de la aplicación. El vocabulario interno de mensajes de
  estado en tiempo de ejecución (p. ej. `"CAROLALDHIRA CAPTURANDO"`,
  `"CAROLALDHIRA ACTIVA!"`, usado en comparaciones de cadenas dentro de
  `lorito_status_display.py` y `lorito_main_window.py`) **no se modificó**
  en esta revisión, para no arriesgar romper la lógica de coincidencia de
  texto sin una instrucción explícita. Queda documentado como candidato a
  una revisión futura si se desea unificarlo también.
- **Módulo dedicado de registro de versión**: `lorito_version.py` pasa a
  ser la única fuente de verdad de nombre/versión. Se agregó
  `APP_BRAND`, `APP_STAGE`, `APP_MAJOR`, `APP_MINOR`, y las funciones
  `get_revision()`, `get_version_string()`, `get_full_label()`. El
  antiguo `APP_VERSION = "0.22.55"` (hardcodeado) fue reemplazado por
  `APP_VERSION = get_version_string()`, calculado leyendo este mismo
  CHANGELOG. `_version_label()` se actualizó al nuevo esquema
  `"{MARCA} {ETAPA} {MAYOR.MENOR.REVISIÓN}"`, conservando su firma
  original para no romper a quienes ya la llamaban.
- **Sistema de "gaps de referencia"** (`/gaps/`) establecido a partir de
  esta revisión: documentos numerados (`GAP-NNN.md`) donde se registra,
  con más detalle del que cabe en una entrada de CHANGELOG, el
  tratamiento técnico de una revisión — qué se va a tocar, por qué, y
  qué pasos siguen. Ver `gaps/GAP-001.md` para el primero.
- Verificación: recompilado (`py_compile`) y re-ejecutado
  `lorito_bootstrap.py` de punta a punta con los mismos stubs de
  PySide6/audio de la revisión anterior — construcción completa de la
  ventana principal sin errores tras el renombrado masivo de imports.

---

## [001] — 2026-08-31 — Modularización mecánica del monolito `aecct2_v22_55.py`

- Punto de partida: monolito único `aecct2_v22_55.py` (versión interna
  `CRAC 0.22.55`, 22.714 líneas, 381 sentencias de nivel superior).
- Se dividió mecánicamente en 33 módulos + módulo raíz de arranque,
  separados en dos ramas:
  - `lorito_aldhiro/backend/` — sin dependencias de Qt (motor de captura,
    reproducción, normalización, exportadores, forense/SIPA, snapshots,
    prioridades de tiempo real, física de la cinta, etc.).
  - `lorito_aldhiro/frontend/` — todo lo que usa `PySide6` (ventana
    principal, diálogos, widgets, tema visual, bridge de señales).
- Toda referencia de marca `AECCT2` se reemplazó por `Lorito Aldhiro`,
  excepto el texto `"AECCT2"` dibujado por la animación de la PC en el
  panel del contómetro (`frontend/widgets/media_anim.py`, preservado a
  propósito).
- Clase principal renombrada: `AECCT2Studio` → `LoritoAldhiroStudio`.
- Se detectó y resolvió una dependencia circular real entre el análisis en
  dos pasadas y el limitador conservador (fusionados en un único módulo,
  `normalization_v21.py`).
- Se detectaron y corrigieron 7 patrones `from __main__ import X` que el
  monolito usaba (válidos solo cuando todo el código vivía en un único
  script) y que habrían fallado silenciosamente en la versión modular;
  también se corrigió la mutación de `THEME` (de reasignación global a
  mutación in-place) para que el cambio de tema en caliente siga siendo
  visible en todos los módulos.
- Verificación: `py_compile` limpio en los 34 archivos y ejecución real
  de `bootstrap.py` de punta a punta con stubs de
  PySide6/sounddevice/soundfile/aecct2_crac_motor_v4, construyendo la
  ventana principal completa sin `NameError`/`ImportError`.
