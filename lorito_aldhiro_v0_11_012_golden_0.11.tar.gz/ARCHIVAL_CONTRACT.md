# ARCHIVAL_CONTRACT.md — Clasificación archivística de sesiones

Código: `backend/archival/lorito_archival_state.py` (`classify_session`),
`backend/archival/lorito_segment_checksum.py`. Lo invoca
`CaptureEngineV2.finalize()` (y `classify_session()` para sesiones ya
cerradas). Órdenes: Captura CAP-012, Exportación EX-12, DSP DSP-01.

## Estados

| Estado | Significado |
|---|---|
| `ARCHIVAL_SAFE` | Cada frame recibido del driver está en disco, verificado por releída, con ledger reconciliado y cierre completo. |
| `DEGRADED` | Material íntegro en disco, pero con eventos que afectan a la continuidad temporal o a la calidad del entorno (p. ej. `DEVICE_GAP` por recovery, `STARVATION`, `RECOVERY_SUCCEEDED`). |
| `INVALID` | Pérdida, corrupción, evidencia insuficiente o sesión fallida. |

## Requisitos de `ARCHIVAL_SAFE` (todos obligatorios)

1. La sesión no terminó en `FAILED` (`SESSION_FAILED`).
2. `FrameLedger.reconcile().ok` es verdadero y no hay discontinuidades de
   pérdida (`LEDGER_NOT_RECONCILED`, `LEDGER_LOSS`).
3. Los frames releídos del archivo coinciden con los `committed` del
   ledger (`LEDGER_FILE_MISMATCH`).
4. Hay un checksum SHA-256/CRC32 por segmento, calculado **releyendo el
   archivo cerrado** y reverificado al clasificar (`CHECKSUM_UNAVAILABLE`,
   `CHECKSUM_MISMATCH`, `FILE_VERIFY_FAILED`). `finalize()` invoca la
   clasificación con `require_checksums=True`; la API sigue aceptando
   clasificar solo con telemetría (sin esa exigencia) para herramientas e
   informes, pero ese resultado no es el que produce la captura.
5. El cierre fue completo (`FINALIZATION_INCOMPLETE`).
6. El driver no reportó `INPUT_OVERFLOW` ni `INPUT_UNDERFLOW`.
7. No es una sesión de prueba de estrés (`STRESS_TEST_MODE`).
8. No faltan segmentos ni hay segmentos vacíos (`SEGMENT_MISSING_OR_EMPTY`),
   y no hay frames perdidos (`FRAMES_DROPPED`).
9. Con `require_checksums=True`, sin ledger no hay `ARCHIVAL_SAFE` (`LEDGER_UNAVAILABLE`).
10. Ningún motivo de degradación: `XRUN`, `RBA_OVERRUN`, `CED_DROPPED_FRAMES`
    (contadores heredados; con el ring Golden toda pérdida real llega además
    como `LEDGER_LOSS` → INVALID), `RECOVERY_SUCCEEDED`, `DEVICE_GAP`,
    `STARVATION` y `DSP_NONFINITE_SANITIZED`. Cualquiera de ellos deja la
    sesión en `DEGRADED`.

Los requisitos 1–9 llevan a `INVALID` si fallan.

## Lo que NO eleva una sesión

- Que la exportación termine bien (`ExportSessionReport.ok`) no hace
  `ARCHIVAL_SAFE` a un archivo (EX-12). La exportación tiene su propia
  clase: `ARCHIVAL_SAFE` (copia bit-exacta verificada de una sesión
  `ARCHIVAL_SAFE`), `DERIVED` (cualquier transformación) o `NOT_ELIGIBLE`.
- El saneamiento numérico de una etapa DSP (`sanitize_finite`) nunca se
  oculta: queda como evento de integridad, pone la cadena en `DEGRADED` e
  deja la sesión en `DEGRADED` (requisito 10).
  El RAW no pasa por el DSP y queda intacto.

## Evidencia persistida

La `ArchivalClassification` incluye `reasons` (con código, gravedad y
detalle), `ledger_reconciled`, `ledger_deltas`, `discontinuities` y
`notes`. La GUI la muestra y la exportación la copia al manifiesto
(`.manifest.json`) y al texto de especificación.
