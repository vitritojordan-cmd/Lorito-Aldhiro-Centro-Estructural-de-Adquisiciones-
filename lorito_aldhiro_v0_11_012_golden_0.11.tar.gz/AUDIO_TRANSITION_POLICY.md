# AUDIO_TRANSITION_POLICY.md — Política de transición por operación

Código: `backend/transport/lorito_transition_policy.py`. Se aplica en el
hilo de render y **nunca en el callback**. Las rampas se precalculan al
construir la política.

| Operación | Política | Duración | Qué se preserva | Cuándo se degrada |
|---|---|---|---|---|
| Speed-live (Velocista, arrastre) | CONTINUOUS | — (slew ≤ 8 ratio/s) | cursor absoluto, estado del interpolador, contenido | nunca |
| Speed-commit (soltar) | CONTINUOUS | — (slew) | ídem | nunca |
| Morpher ida/vuelta y retorno elástico | CONTINUOUS | — | ídem; la reversa cruza ratio 0 sin corte | nunca |
| Seek (no contiguo) | **DIP** | 128 frames de salida + 128 de entrada (≈ 5,3 ms a 48 kHz), medio coseno | contenido exacto a ambos lados, **sin mezclar audio no adyacente** | destino con menos de 128 frames antes de EOF |
| Seek (opción artística) | XFADE_LINEAR | 256 frames | amplitud en señales correlacionadas o idénticas | ventana truncada por EOF |
| Seek (opción artística) | XFADE_EQUAL_POWER | 256 frames | potencia **solo** en señales no correlacionadas | ídem |
| Seek (corte explícito) | CUT | 0 | nada: discontinuidad permitida y medida | — |
| EOF | FADE_OUT_END | 64 frames sobre los últimos válidos | — | bloque final más corto que el fundido |
| Stop | FADE_OUT_END | 256 frames de la continuación, tras el audio encolado | — | audio insuficiente |
| Underrun | silencio explícito | lo que falte | contadores (`underrun_events`, `underrun_frames`, generación) | siempre declarado |

## Por qué así

- **Equal-power no es universal** (SMV-03). `cos²+sin²=1` conserva la
  potencia solo si las señales no están correlacionadas. Con contenido
  idéntico o en fase suma +3 dB en el centro; en contrafase cancela. Por eso
  no es la política por defecto.
- **DIP en lugar de crossfade para el seek** (SMV-09, orden §Fase 4). Un
  seek no contiguo mezclaría audio no adyacente. El DIP baja la continuación
  a cero y sube el destino desde cero. Usa medio coseno porque tiene
  derivada continua en los extremos y la métrica no ve quiebre de pendiente.
- **Sin transición en los cambios de velocidad**. Con cursor absoluto y
  rampa de ratio no hay discontinuidad que tapar, y un crossfade solo
  borraría transitorios.
- **Nada truncado se presenta como completo** (SMV-04). Si la ventana no
  cabe, la transición se aplica con la longitud disponible y el registro
  (`TransitionRecord`) lleva `degraded=True` y `reason`.
  `ledger.degraded_transitions` las cuenta.

## Registro

Cada transición genera un `TransitionRecord(operation, kind,
frames_planned, frames_applied, degraded, reason, transport_generation)`.
Se publica en `transport_snapshot()["transitions"]` y, si hay bitácora, como
evento `TRANSITION_<op>` (WARNING si está degradada).

## Sin garantías absolutas

Ninguna política se anuncia como "cero pops". La evidencia es la medición
(POP_DISCONTINUITY_TEST_REPORT.md), y la certificación requiere loopback de
hardware y escucha ciega.
