# CAPTURE_ARCHITECTURE_GOLDEN.md — Motor de Captura Golden (Lorito Aldhiro 0.11)

Orden: *Refactorización Golden del Motor de Captura* (CAP-001…CAP-012),
Lorito Aldhiro 0.11.001. Código: `backend/capture/lorito_capture_engine.py`,
`backend/rt/lorito_capture_ring.py`, `backend/capture/lorito_frame_ledger.py`,
`backend/capture/lorito_capture_session.py`, `backend/archival/`.
Pruebas: `tests/test_capture_golden.py` (T-01…T-10, 27 casos) y la batería
heredada adaptada.

## 1. Camino archivístico (RAW)

```
PortAudio ─► _audio_callback ─► SPSCCaptureRing ─► drain ─► CED ─► DiskWriterV2 ─► segmentos WAV
  (RT)        sin locks/IO/log    sin overwrite      no-RT    finita   dueño único     + SHA-256/CRC32
              copia y publica     sin truncamiento   bloquea  (frames) del archivo     releídos de disco
                                  rechazo explícito  por back-
                                                     pressure
```

| Hilo | Responsabilidad | Prohibido |
|---|---|---|
| Callback PortAudio | copiar el bloque al slot del ring y publicarlo; anotar flags de status | locks, `Condition`, espera por el consumidor, I/O, logging, asignación grande |
| Drain (no-RT) | vaciar el ring a la CED en orden de secuencia; alimentar medidor/envolvente y la ruta DERIVED | descartar frames del RAW |
| DiskWriterV2 | único dueño del archivo; escritura, flush, fsync, rotación de segmentos, checksum por releída | declarar éxito sin barrera de persistencia |
| Supervisor/watchdog | vigilancia; recovery solo si la FSM lo permite (generación vigente) | competir con `finalize()` |

## 2. Ring SPSC (CAP-001, CAP-002, CAP-005)

`SPSCCaptureRing` (protocolo de Lamport, un productor y un consumidor):

- Slots preasignados (`CE_RBA_SLOTS = 512`, hasta `CE_RBA_FRAMES_MAX = 4096`
  frames por bloque). El callback **copia antes de publicar** (NumPy puede
  liberar el GIL durante copias grandes) y publica incrementando el índice
  de escritura.
- **Nunca sobrescribe** el slot más antiguo ni trunca bloques. `publish()`
  devuelve un código explícito: `WRITE_OK`, `RING_FULL`, `BLOCK_OVERSIZE`,
  `BLOCK_SHAPE`, `WRITE_DISABLED`. Toda pérdida se cuenta
  (`rejected_*_frames`) y se registra en el `FrameLedger`.
- Etiquetado por generación: los bloques de una generación anterior
  (`reset_for_generation`) se cuentan como `stale_generation_*` y no
  llegan al archivo.
- **Limitación declarada** (`LOCK_FREE_VERIFIED`): la ausencia de locks
  se apoya en el GIL de CPython. En builds *free-threaded* (PEP 703) no hay
  garantías documentadas de orden de memoria para un ring en Python puro
  (ver REFERENCIAS_INVESTIGACION_TECNICA.md §1.3). El motor lo detecta y
  lo declara; no lo presenta como verificado.

## 3. Política de saturación (CAP-002, CAP-010)

| Política | Comportamiento ante la primera pérdida |
|---|---|
| `OVERFLOW_POLICY_FAIL_STOP` (por defecto) | sesión → `FAILED`, ring deshabilitado, stream cerrado, archivo parcial preservado, clasificación `INVALID` |
| `OVERFLOW_POLICY_CONTINUE_INVALID` | la pérdida se declara, la captura continúa y la sesión queda `INVALID` de forma irreversible |

La CED aplica backpressure al drain (bloquea, no descarta). `put_nowait`
solo se usa en rutas que cuentan cada frame descartado.

## 4. Máquina de estados de sesión (CAP-011)

`CaptureSessionFSM`: `IDLE → ARMING → CAPTURING ↔ PAUSED → DRAINING →
FINALIZING → CLASSIFIED`, más `FAILED` desde cualquier estado activo.
Cada transición se valida (`IllegalTransition`) y lleva un token de
generación. El recovery automático solo procede si
`recovery_allowed(gen)`: un recovery de una generación vieja o posterior
a `request_stop()` se rechaza. El intervalo de recovery se registra como
`DEVICE_GAP` en el ledger (degrada, no invalida).

## 5. Cierre en fases (CAP-003, CAP-008, CAP-009)

1. `request_stop()` deja de aceptar bloques, cierra el stream, confirma la
   quiescencia del callback (`CE_STOP_QUIESCE_TIMEOUT_S`) y vacía el ring
   hacia la CED.
2. `finalize()` (serializado por `_finalize_lock`, idempotente: llamadas
   concurrentes reciben el **mismo** resultado):
   - `flush_barrier(seq)` → flush + `os.fsync` por ruta + fsync del
     directorio (`FlushBarrierResult`);
   - cierre del writer → `WriterCloseResult` (hilo vivo = no cerrado);
   - verificación de segmentos y reconciliación del ledger;
   - `FinalizationResult(complete=…)`: **cualquier** timeout, hilo vivo o
     barrera no confirmada produce `complete=False` y la razón
     `FINALIZATION_INCOMPLETE`, que bloquea `ARCHIVAL_SAFE`.

`SoundFile.flush()` solo entrega datos al sistema de archivos; la
durabilidad exige `os.fsync` del descriptor y del directorio padre
(REFERENCIAS §1.4).

## 6. Disco (CAP-004)

`DiskWriterV2` distingue errno fatales (`ENOSPC`, `EDQUOT`, `EROFS`,
`EIO`…) de reintentables; detecta escrituras parciales; comprueba
espacio libre antes de escribir. Un error fatal lleva a fail-stop global
con razón persistente (`failure_reason`), nunca a un writer detenido en
silencio con la captura activa.

## 7. FrameLedger (CAP-012)

Contadores monotónicos por etapa: callback recibidos → ring aceptados →
drain → writer escritos → verificados en disco. `reconcile()` produce
`LedgerReconciliation(ok, deltas, causes, totals)`; cada delta distinto
de cero debe estar explicado por una discontinuidad registrada
(`RING_OVERFLOW`, `INPUT_OVERFLOW`, `DEVICE_GAP`, `PAUSE`…). La
clasificación archivística usa esta evidencia (ver ARCHIVAL_CONTRACT.md).

## 8. RAW vs DERIVED

El archivo de captura es siempre RAW (bit-exacto a lo que entregó el
driver). El DSP en vivo (NR, PREVI, efectos) escribe un hermano
`_DERIVED.wav` con su JSON de procedencia (cadena, parámetros, hash de
configuración, latencia). La ruta DERIVED **no comparte backpressure** con
la RAW: puede perder bloques, pero los cuenta (`DERIVED_INCOMPLETE`).

## 9. Telemetría fuera del camino crítico (CAP-005)

Medidor (`CaptureMeter`), envolvente (`LiveEnvelopeRing`) y bitácora
forense (`ForensicEventLog`) se alimentan desde el drain y no desde el
callback. La GUI lee snapshots inmutables (`telemetry_snapshot()`); los
segundos de audio provienen de frames aceptados
(`audio_seconds_accepted()`), no de ticks.

## 10. Lo que este entorno no puede demostrar

Soak de 50 h, captura loopback con interfaz real, comparación con CRAC
0.36, inyección de fallos de hardware (desconexión USB real) y medición
de deadline misses de un PortAudio real. Ver
ORDENES_GOLDEN_0_11_ESTADO.md §Puertas pendientes.
