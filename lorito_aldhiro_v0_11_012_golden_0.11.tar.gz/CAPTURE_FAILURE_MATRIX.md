# CAPTURE_FAILURE_MATRIX.md — Matriz de fallos de captura (Orden Golden CAP)

Cada fila: fallo → detección → reacción del motor → evidencia en el
ledger/clasificación → prueba que lo ejercita.

| # | Fallo | Detección | Reacción | Ledger / razón | Clasificación | Prueba |
|---|---|---|---|---|---|---|
| 1 | Ring lleno (consumidor lento) | `publish()` → `RING_FULL` | FAIL_STOP: ring deshabilitado, stream cerrado; CONTINUE_INVALID: sigue y marca | `RING_OVERFLOW` (frames exactos) | INVALID | `test_capture_golden` T-03 (y T-02 acelerado) |
| 2 | Bloque mayor que el slot | `BLOCK_OVERSIZE` | rechazo completo, nunca truncado | `BLOCK_OVERSIZE` | INVALID | T-01 |
| 3 | Forma/canales del bloque inválidos | `BLOCK_SHAPE` | rechazo | `BLOCK_SHAPE` | INVALID | T-02 |
| 4 | Bloque recibido tras fail-stop | `WRITE_DISABLED` | rechazo contado | `REJECTED_AFTER_FAILSTOP` | INVALID | T-02 |
| 5 | `paInputOverflow` del driver | flag de status del callback | captura sigue; hueco temporal declarado | `INPUT_OVERFLOW` | INVALID | T-09 |
| 6 | `paInputUnderflow` | flag de status | ceros insertados por PortAudio declarados | `INPUT_UNDERFLOW` | INVALID | `test_archival_reason_codes_golden` |
| 7 | ENOSPC / EDQUOT / EROFS / EIO | errno fatal en escritura | fail-stop global, razón persistente | `WRITER_FAILURE` / `SESSION_FAILED` | INVALID | T-05 (ENOSPC, EIO, desconexión, permiso, close) |
| 8 | Error transitorio de escritura | errno reintentable | reintento acotado; al agotarse, fail-stop | `WRITER_FAILURE` si se agota | INVALID si se agota | `test_fault_injection` |
| 9 | Escritura parcial | bytes escritos < esperados | fail-stop | `WRITER_FAILURE` | INVALID | T-05 (familia de fallos de almacenamiento) |
| 10 | Join del writer vence | hilo vivo tras timeout | `WriterCloseResult(closed=False)` | `FINALIZATION_INCOMPLETE` | no ARCHIVAL_SAFE | T-06 (timeout de drain nunca es éxito) |
| 11 | Barrera flush/fsync no confirmada | `FlushBarrierResult(ok=False)` | cierre incompleto declarado | `FINALIZATION_INCOMPLETE` | no ARCHIVAL_SAFE | T-05 (fallo de flush / fsync) |
| 12 | `finalize()` concurrente | `_finalize_lock` | segunda llamada espera y recibe el mismo resultado | — | sin cambio | T-07 |
| 13 | Recovery tras stop / generación vieja | `recovery_allowed(gen)` | recovery rechazado | — | — | `test_capture_recovery` |
| 14 | Recovery exitoso (stream reabierto) | FSM + supervisor | captura continúa | `DEVICE_GAP` (intervalo) | DEGRADED | `test_capture_recovery` |
| 15 | Recovery agotado | intentos ≥ máximo | sesión FAILED, terminal y declarada | `RECOVERY_EXHAUSTED` | INVALID | `test_fault_injection` |
| 16 | Segmento corrupto o truncado tras escribir | releída + SHA-256/CRC32 | verificación fallida | `FILE_VERIFY_FAILED` / `CHECKSUM_MISMATCH` | INVALID | T-10 (archivo alterado tras el cierre), `test_capture_engine_archival_integration` |
| 17 | Checksums no disponibles | segmento sin hash | — | `CHECKSUM_UNAVAILABLE` | no ARCHIVAL_SAFE | `test_archival_reason_codes_golden` |
| 18 | Ledger no reconcilia | deltas sin causa | — | `LEDGER_NOT_RECONCILED` / `LEDGER_LOSS` | INVALID | `test_archival_reason_codes_golden`, T-03 |
| 19 | Frames en archivo ≠ ledger | releída vs `committed` | — | `LEDGER_FILE_MISMATCH` | INVALID | T-10 |
| 20 | Modo de prueba de estrés activo | bandera del motor | — | `STRESS_TEST_MODE` | INVALID | `test_archival_reason_codes_golden` |
| 21 | DSP produce NaN/Inf (ruta DERIVED) | guarda de finitud por etapa | saneo + reset de etapa + evento | `DSP_NONFINITE_SANITIZED` | RAW intacto; sesión DEGRADED | T-09 (no finitos en RAW preservados), `test_dsp_golden` FiniteGuard |
| 22 | DERIVED no sigue el ritmo | cola DERIVED llena | bloque DERIVED descartado y contado | `DERIVED_INCOMPLETE` (info) | RAW sin cambio | T-08 (DSP lento y GUI congelada no tocan el RAW) |
| 23 | Inanición del planificador | watchdog | aviso; contadores separados por tipo | `STARVATION` | DEGRADED | T-09 (una inanición por callback tardío) |

Reglas transversales:

- Ningún fallo se traduce en éxito por timeout.
- Ningún frame del RAW se descarta sin entrada en el ledger.
- `ARCHIVAL_SAFE` exige un ledger reconciliado, checksums releídos de disco
  y un cierre completo.
