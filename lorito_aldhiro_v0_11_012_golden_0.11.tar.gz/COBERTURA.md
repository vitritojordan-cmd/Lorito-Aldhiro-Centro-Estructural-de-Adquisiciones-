# COBERTURA.md — Fase 12 de la Orden Maestra de Saneamiento
Pre-Auditoría Aldhira Phonographic

## Metodología

`coverage`/`pytest-cov` no están instalables en este sandbox (red
deshabilitada). Se midió con el módulo **`trace`** de la librería
estándar de Python, que no requiere ninguna dependencia externa:

```bash
python3 -m trace --count --missing --summary --coverdir=/tmp/covdir \
    --module unittest discover -s tests -p "test_*.py"
```

Nota de corrección honesta: el primer intento de esta medición usó
solo `--count` y confundió el conteo de ejecuciones con un booleano
"se ejecutó/no se ejecutó", contando líneas de definición (`def`/
`class`, que siempre se ejecutan una vez al importar el módulo,
independientemente de si la función se llama después) como "cubiertas"
sin verificar el cuerpo real. Eso dio un falso 100% en todos los
módulos. `--missing` (marca líneas ejecutables nunca ejecutadas con
`>>>>>>`) + `--summary` (reporte de porcentaje por archivo, generado
por la propia herramienta, sin parseo manual) corrigieron la medición.

## Resultado agregado

**42.3%** de cobertura de línea sobre 17 878 líneas ejecutables en
`lorito_aldhiro/` (backend + frontend), corriendo la batería completa
(240 tests).

## Módulos mejor cubiertos (≥90%, todos con trabajo dedicado de tests
en esta cadena de sesiones)

| Módulo | % |
|---|---|
| `backend.transport.lorito_transport_machine` | 96% |
| `backend.archival.lorito_archival_state` | 98% |
| `backend.export_streaming.lorito_export_session` | 92% |
| `backend.nr.lorito_nr_dsp_core` | 91% |
| `backend.transport.lorito_speed_planner` | 90% |
| `backend.dsp.lorito_dsp_finite_guard` | 100% |
| `backend.export_streaming.lorito_export_blocks` | 100% |
| `backend.transport.lorito_transport_state`/`lorito_transport_commands` | 100% |

## Módulos peor cubiertos (<20% — casi todos GUI/widgets, apenas
importados bajo stubs, nunca ejercitados en profundidad)

| Módulo | % | líneas |
|---|---|---|
| `backend.lorito_exporters` | 10% | 369 |
| `backend.lorito_playback_engine` | 13% | 668 |
| `frontend.widgets.lorito_media_anim` | 15% | 317 |
| `frontend.widgets.lorito_waveform` | 15% | 420 |
| `frontend.widgets.lorito_status_display` | 15% | 560 |
| `frontend.widgets.lorito_tape_log_panel` | 17% | 714 |
| `frontend.lorito_main_window` | 19% | 3422 |

## Lectura honesta de estos números

- La cobertura BAJA en `lorito_main_window.py`/widgets no es una
  sorpresa ni un defecto de esta sesión — refleja fielmente que ese
  código depende de PySide6 real para ejercitarse de verdad; los
  stubs existentes (`tests/test_stability_patch.py`) permiten
  IMPORTARLO (por eso no está en 0%) pero no simulan interacción de
  usuario real.
- Los módulos de `export_streaming/`, `dsp/`, `transport/`, `archival/`
  y `rt/` — el trabajo de las últimas ~15 sesiones — muestran
  cobertura alta de forma consistente, coherente con el volumen de
  tests dedicados que se escribieron para cada uno.
- `lorito_normalization.py` (67%) y `lorito_normalization_v21.py`
  (65%) tienen cobertura media-alta pero no total — los tests de
  GAP-027 a 030 ejercitan escenarios representativos de cada modo, no
  cada rama de cada función (p. ej. la ruta de fallback puro-Python de
  LUFS cuando `scipy` no está disponible nunca se ejercita, porque
  `scipy` SÍ está disponible en este sandbox).

## Hallazgo colateral de esta investigación (no una corrección, una
nota para sesiones futuras)

Al investigar por qué `frontend.lorito_main_window` lograba importarse
bajo trace, se confirmó que existe un mecanismo de stubs de PySide6
bastante completo desde antes de esta cadena de sesiones
(`tests/test_stability_patch.py::_install_stub_modules` — incluye un
Signal/slot REAL, no solo un dummy). Esto vale la pena tenerlo en
cuenta para cualquier trabajo futuro que se haya descartado
prematuramente por "requiere PySide6 real" — puede que una porción
de esa integración sí sea auditable a nivel estructural/lógico con
este mecanismo, aunque no a nivel de interacción visual real.
