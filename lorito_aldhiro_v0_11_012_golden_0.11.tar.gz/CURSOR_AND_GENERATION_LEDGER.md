# CURSOR_AND_GENERATION_LEDGER.md — Cursores, generaciones y reconciliación

## 1. Cursores canónicos (SMV-06, SMV-11)

| Cursor | Escritor | Significado |
|---|---|---|
| `requested_frame` | GUI (`seek_to`) | último destino pedido; **no** es una posición audible |
| `read_head_frame` | render | posición del lector de velocidad variable tras el último bloque |
| `queued_head_frame` | render | frame de fuente al final del último bloque publicado |
| `audible_frame` | callback | frame de fuente que se entrega al dispositivo, interpolado dentro del slot |
| `ui_frame` | — | igual a `audible_frame`; la UI muestra lo audible (`src_pos`) |

La GUI ya no escribe `src_pos` ni simula haber llegado al destino. Mientras
el usuario arrastra la barra de posición, la barra muestra su propio valor
(destino solicitado, explícito). Al soltar, vuelve a seguir `src_pos`.

En un bloque DIP de seek, el cursor audible salta al destino al comenzar el
bloque de transición: `src_start = destino − 128·ratio`, de modo que la
interpolación lineal dentro del slot da el frame de destino justo donde
empieza la parte nueva.

## 2. Generaciones

| Generación | Cambia en | Viaja en |
|---|---|---|
| sesión (`session_generation`) | cada `start()` | estado `_Session`; el callback de una sesión vieja no puede leer el ring nuevo (objetos distintos) |
| transporte (`transport_generation`) | PLAY, SEEK, entrada en SPEED_LIVE, COMMIT, STOP | cada slot del ring (`tgen`) |
| epoch de ratio (`ratio_epoch`) | cada LIVE/COMMIT aplicado | cada slot (`epoch`) |

Reglas:

- Un bloque se etiqueta con la generación vigente **al publicarse**. Antes
  de entrar al ring se comprueba que no sea inferior a `min_valid_gen`
  (`stale_dropped_before_ring`).
- El callback descarta un slot con `tgen < min_valid_gen`
  (`stale_discarded_in_callback`) y cuenta cualquier retroceso de
  generación entre slots consumidos (`mixed_generation_events`). Por
  construcción, al cortar en la cabeza de escritura, ambos quedan en 0.
- `stale_consumed` existe como invariante explícito: debe ser 0.

## 3. Libro de transporte por sesión (`TransportLedger`)

Hay un `TransportLedger` por sesión, sin estado global (SMV-08).

- Comandos: `commands_submitted`, `_applied`, `_confirmed`, `_superseded`,
  `_rejected`, `_out_of_order`, `live_coalesced` y
  `last_command_id_applied`.
- Bloques: `blocks_published`, `blocks_consumed`,
  `stale_dropped_before_ring`, `stale_discarded_in_callback`,
  `stale_consumed` y `mixed_generation_events`.
- Underruns: `underrun_events`, `underrun_frames` y
  `last_underrun_generation`.
- Transiciones: `transitions` (por `operación:tipo`) y
  `degraded_transitions`.

## 4. Reconciliación

Invariantes que verifican las pruebas:

```
commands_submitted == commands_applied + commands_superseded + commands_rejected
commands_out_of_order == 0
stale_consumed == 0 ; mixed_generation_events == 0 ; stale_dropped_before_ring == 0
blocks_consumed ≤ blocks_published
frames en silencio capturados ≥ underrun_frames − (frames de fundido de STOP/EOF)
```

## 5. Dónde leerlo

`PlaybackEngine.transport_snapshot()` devuelve, sin locks:

- los cursores, generaciones y epoch;
- el lead del ring;
- el ledger y las últimas 32 transacciones y transiciones;
- el timing del callback.

Al terminar la sesión, `last_session_snapshot` conserva el último estado.
