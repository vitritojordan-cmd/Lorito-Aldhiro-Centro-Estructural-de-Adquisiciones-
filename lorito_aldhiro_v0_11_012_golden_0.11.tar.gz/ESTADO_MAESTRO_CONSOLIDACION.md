# ESTADO_MAESTRO_CONSOLIDACION.md — Orden Maestra de Saneamiento,
Integración y Consolidación de Lorito Aldhiro

Documento consolidado de la TERCERA Orden Maestra del proyecto (las
dos anteriores están consolidadas en `/ESTADO_MAESTRO_SANEAMIENTO.md`,
que sigue vigente para su propio alcance). Se actualiza al cierre de
cada sesión que toque esta Orden — mismo criterio que el documento
hermano: estado real, no aspiracional.

## Veredicto vigente

**ORDEN MAESTRA CERRADA — las 12 fases quedan completas o formalmente
cerradas con decisión documentada, y la versión ya se elevó a
0.11.001 (GAP-075).** La instrucción activa del usuario (2026-09-17/18:
"cerrar por completo todos los frentes pendientes de las 12 fases,
diseñando stubs donde falte alguna dependencia, como condición
explícita para elevar la versión a 0.11") queda cumplida en su
totalidad con este cierre. La próxima auditoría que el propio usuario
ya anunció — descontaminar la tubería de audio/DSP de hilos GUI, más
otras optimizaciones — es explícitamente un frente NUEVO, fuera de
esta Orden, reservado para una sesión futura sobre la base 0.11.001.
Lo que sigue en esta sección documenta cómo se llegó a ese cierre.

Avance de la tanda de cierre: **FASE 3
(Streaming Export) QUEDA COMPLETA — los 3 huecos identificados en
GAP-054 están los 3 cerrados**: (a) resampleo streaming por velocidad,
con conteo de frames exacto sin deriva acumulada (GAP-065); (b)
encoders streaming FLAC/OGG/WavPack vía `ffmpeg`, que de paso
encontraron y corrigieron 4 defectos reales (incluido uno en
`AtomicFinalizer`, código COMPARTIDO por todos los encoders, ver
GAP-066); (c) puente `ExportSessionReport`↔`normalization_stats` +
flag `USE_STREAMING_EXPORT` (GAP-067) — **cerrado**. El cableado real a
producción (`lorito_mw_export.py`) sigue pendiente, bloqueado
únicamente por la ausencia de PySide6 ejecutable en este sandbox, no
por diseño faltante. Además, **FASE 4 (Transport Core) y FASE 5
(Morpher + Velocista) quedan con su cierre FORMAL** (GAP-068): decisión
explícita y documentada de NO cablear `TransportMachine`/
`SpeedPlanner`/`GenerationGuard` en lugar de la lógica interna actual
de `PlaybackEngine` durante esta Orden — diferido a la auditoría
siguiente (post-0.11) por partida doble: §29 exige verificación con
audio real antes de integrar código de tiempo real (este sandbox no
puede confirmarla) y la propia instrucción activa del usuario ya
nombra esa descontaminación de hilos GUI como el objetivo de la
próxima auditoría. El defecto real del motor ACTUAL ya estaba
corregido y verificado con audio real desde GAP-062/063 — este cierre
no reabre ni repite ese trabajo, solo formaliza la decisión de alcance.

**FASES 1, 2, 3, 4, 5, 6 y 7 de 12 completas (FASE 4/5 con cierre
FORMAL — decisión documentada de no cablear el Transport Core nuevo
en esta Orden, ver GAP-068 — no con un swap de motor; FASE 6 con su
decisión de política de GAP-062 MÁS la auditoría de cardinalidad de
canales de GAP-069, sin defectos; FASE 7 con su CUARTO corte real
GAP-071 — extracción de nombrado/formato de `_do_export()` — MÁS la
misma decisión de riesgo que FASE 4/5 para NO construir un
`ExportController` completo en esta Orden); FASE 8 (parcial); FASE 9
con su par "Capture → Playback del mismo audio" ya cerrado (GAP-072,
§19) además de la cobertura de integración con hilos reales de
`PlaybackEngine`; **FASE 10 QUEDA COMPLETA (GAP-073)** — los 4
escenarios de fault injection restantes (disco lento, seek tardío,
scrub rápido, desconexión de dispositivo de salida) sobre
`PlaybackEngine` real; **FASE 11 tiene su sustituto SINTÉTICO
implementado (GAP-074)** — "DSP directo" (volumen sostenido, horas
equivalentes, contra `NRCoordinator` real) + "ciclos repetidos" (40
ciclos reales de `DiskWriterV2` y de `PlaybackEngine`), declarado
explícitamente como sustituto PARCIAL de las 50h de reloj real de
§23, no como equivalencia literal.** **FASE 12 (Release Candidate)
QUEDA CERRADA (GAP-075)**: verificación final con ejecución real
(suite completa 598/598 tres veces, dos antes del salto de versión —
plana y con `-W error::ResourceWarning` — y una vez más después,
además de `lorito_bootstrap.py` reverificado dos veces), salto de
versión aplicado (`APP_MINOR` 10→11, `_MINOR_REVISION_BASE` 50→77,
`APP_VERSION` confirmado como `0.11.001`), y empaquetado de
`saneamiento_0_11_001/` + tarball en `dist/` siguiendo la misma
convención de los releases 0.10.015/016/017. **Con esto, las 12 fases
de la Orden quedan formalmente cerradas.**
Además, cuatro fixes críticos fuera de las 12 fases: GAP-056/057
(`_status` sin importar en 4 archivos, 112 usos), GAP-063 (carrera
real en `PlaybackEngine.stop()`/`_play_loop`, encontrada con el primer
test de integración con hilos reales de ese motor), GAP-064
(`DiskWriterV2.flush()` esperaba 30s sin motivo en cada llamada) y
**GAP-073 (busy-spin real en `_audio_cb()`: un underrun con el chunk
previo agotado —no `None`— giraba sin límite dentro del callback de
audio en tiempo real en vez de degradar a silencio, encontrado
recién al ejercitar disco lento sostenido de verdad)** — todos ya
verificados con ejecución real. GAP-064 además investigó a fondo (no
solo documentó) la flakiness de `DiskWriterV2`/`ColaElasticaDisco`
conocida desde GAP-052: descartó con evidencia real la hipótesis de
fuga de hilos y confirmó que es ruido de scheduling del sandbox sobre
un stub deliberadamente más rápido que tiempo real, no un defecto de
producción. **Versión elevada a 0.11.001 (GAP-075)** — cumplida la
condición fijada de antemano por el usuario: terminar TODO el
proceso de saneamiento de las 12 fases antes de elevarla. Suite
completa: 598/598 tests (1 skip preexistente no relacionado), 0
fallidos, con y sin `-W error::ResourceWarning` (~160s) — reverificada
una vez más después del salto de versión, sin regresión.

**Práctica permanente desde GAP-054 (instrucción explícita del
usuario, por los antecedentes de CRAC): toda sesión que toque este
proyecto debe reverificar `lorito_bootstrap.py` explícitamente antes
de cerrar** — no basta con que la suite completa pase (el test de
GAP-053 ya lo cubre automáticamente), se reconfirma a propósito. Ver
GAP-053 para el método (`runpy.run_path(..., run_name="__not_main__")`
bajo stubs).

## Mapa de fases (§27 de la Orden) — estado real

| Fase | Qué es | Estado | GAP |
|---|---|---|---|
| 1 | Contratos + errores | **Completa** — `backend/errors/` (taxonomía §11/§15/§16), 5 excepciones ad-hoc retroadaptadas, contrato `ExportResult` (§4) extendido de forma aditiva en `ExportSessionReport`/`AtomicFinalizer`, fix real de P0.4 en `_build_export_array()` | GAP-051 |
| 2 | Archival State | **Completa** — contrato §9 extendido de forma aditiva (`ArchivalReason`, campos cuantitativos: frames/segments/checksum_verified), `CaptureEngineV2.classify_session()` conecta el subsistema al motor real (segmentos+checksums reales, nunca placeholder), y ahora TAMBIÉN conectado a `stop_all()` (§8: parte obligatoria del cierre real de sesión, GAP-061) — resultado guardado en `self._last_archival_classification`, sin presentación en UI todavía (decisión de presentación no tomada, no bloquea la obligatoriedad del cálculo) | GAP-052, GAP-061 |
| 3 | Streaming Export | **COMPLETA — 3 de 3 huecos reales cerrados (GAP-065/066/067), no cableada a producción todavía**: (a) **cerrado** — resampleo streaming por velocidad (`StreamingSpeedResampleTransform`), conteo de frames exacto sin deriva acumulada, cableado en `ExportSession` vía `expected_output_frames`; (b) **cerrado** — `FlacEncoder`/`OggEncoder`/`WvEncoder` vía `ffmpeg` (mismo patrón de pipe que `WVExporter` ya usa en producción), que de paso corrigieron 4 defectos reales, uno de ellos en `AtomicFinalizer` (código compartido, afectaba a cualquier encoder asíncrono); (c) **cerrado** — `lorito_normalization_stats_bridge.py`: `export_resolved_mode_with_stats()`/`export_mid_side_with_stats()` devuelven `(ExportSessionReport, stats)` con la misma forma de dict que el camino legado, `apply_normalization_stats_to_status()` reutiliza el bloque de asignación ya existente en `lorito_mw_export.py`, flag `USE_STREAMING_EXPORT = False` (mismo patrón que `USE_CONTINUOUS_RESAMPLE`). El módulo de normalización streaming en sí (20 modos, presets, AUTO, TWO_PASS) está completo y listo — el bloqueador real del cableado a producción ya NO es PySide6 como módulo (esa afirmación en su docstring legado está desactualizada), sino la ausencia de PySide6 EJECUTABLE en este sandbox para poder verificar el cableado con `lorito_mw_export.py` real | GAP-054 (caracterización), GAP-065 (hueco a), GAP-066 (hueco b), GAP-067 (hueco c) |
| 4 | Transport Core | **CERRADA (cierre formal, GAP-068) — defecto real corregido y verificado con audio real (GAP-062), cobertura de integración de hilos reales (GAP-063)**: `_resample_stateful()` (el resampleador cúbico stateful que usa `PlaybackEngine`, NO el Transport Core nuevo) tenía una deriva de fase real en cada frontera de chunk de prefetch, medida por primera vez con tonos sintéticos en GAP-037 y confirmada cuantitativamente con 20s reales de `Sotalomafer1.mp3` del usuario (factor de error hasta ~70000× mayor que la corrección). `resample_stateful_continuous()` (ya construida en GAP-037, sin conectar) está cableada a producción tras la flag `USE_CONTINUOUS_RESAMPLE`, y GAP-063 la ejercitó por primera vez con el motor completo corriendo en hilos reales (no solo las funciones puras), encontrando y corrigiendo además una carrera real en `stop()`. `TransportMachine`/`SpeedPlanner`/`GenerationGuard` (el Transport Core nuevo en sí, 23 tests en aislamiento) SIGUEN sin ningún uso de producción — **decisión FORMAL de GAP-068: no cablearlo en esta Orden**, diferido explícitamente a la auditoría siguiente (post-0.11, descontaminación de audio/DSP de hilos GUI) por exigencia de §29 (verificación con audio real, no disponible aquí) y por instrucción propia del usuario | GAP-055 (caracterización), GAP-062 (fix + verificación con audio real), GAP-063 (integración de hilos reales + carrera corregida), GAP-068 (cierre formal) |
| 5 | Morpher + Velocista | **CERRADA (cierre formal, GAP-068)** — el defecto de deriva de fase de GAP-062 (Fase 4) es compartido por el pipeline de Morpher/Velocista (mismo `_resample_stateful()`/`_SpeedState` en `PlaybackEngine`) — beneficiado por la misma corrección, y por la nueva cobertura de integración de GAP-063 (`set_speed`/`set_speed_live` ejercitados con hilos reales). Mismo criterio de cierre formal que Fase 4: el `SpeedPlanner` compartido nuevo (verificado en aislamiento, `TestSharedPlannerBetweenMorpherAndVelocista`) queda para cablear en la auditoría siguiente | GAP-062 (beneficio compartido con Fase 4), GAP-063 (cobertura de integración), GAP-068 (cierre formal) |
| 6 | Muscle EQ hardening | **COMPLETA** — **Política NaN/Inf (§16) decidida por el usuario vía cuestionario (GAP-062) e implementada**: se mantiene la recuperación silenciosa existente (sin excepción en ningún sitio, `DSPIntegrityError` sigue sin conectar a ningún `raise` — decisión explícita, no un pendiente) PERO el conteo de saneamientos (`NRCoordinator.nonfinite_counts`) ahora SÍ degrada la clasificación archival: cualquier saneamiento >0 impide `ARCHIVAL_SAFE`, aplicado por igual a todas las etapas, sin umbral. **Cardinalidad de canales (§16) auditada (GAP-069) — resultado POSITIVO real, sin defectos**: 18 tests con `NRCoordinator(channels=1)` real y chunks mono `ndim==1` a través de cada perfil (8 NR, HX Pro, ALC, MPX, EQ/BIAS, Muscle Eq, PREVI completo incluidos los 20 sub-perfiles de Lucha Enloquecida) y la cadena completa activa a la vez — confirma con ejecución real que la cadena ya maneja `channels` arbitrario correctamente por diseño (`FocusProfile` se autodesactiva con `channels<2`); producción sigue usando siempre `CE_CHANNELS=2` | GAP-051 (`DSPIntegrityError` creada), GAP-062 (política decidida + implementada), GAP-069 (cardinalidad de canales, sin defectos) |
| 7 | Controllers / God Object | **CERRADA con decisión de riesgo documentada (GAP-071)** — cuarto corte real: `backend/export/lorito_export_naming.py` (`export_codec_extension`/`export_speed_filename_tag`/`export_speed_display_suffix`/`export_clip_tag`) extrae MECÁNICAMENTE la lógica pura de nombrado/formato de `_do_export()` (`lorito_mw_export.py`), verificado contra la suite real de exportación end-to-end existente sin cambiar ningún byte de comportamiento. Un `ExportController` COMPLETO alrededor de `_do_export()` (etiquetado "riesgo medio") se decidió NO construirlo en esta Orden — reestructuraría la orquestación real de exportación sin forma de verificarlo con la GUI real (PySide6 bloqueado), mismo criterio de riesgo que FASE 4/5 (GAP-068) — diferido, no un hueco sin decidir. Tercer corte (GAP-070): código muerto retirado — `_resample_full_cubic`/`_resample_block_cubic` (auditados DOS veces, cero llamadores reales/dinámicos/tests) fuera de `lorito_mw_playback.py` (1068→1027 líneas); `backend/playback/lorito_playback_scrub_sync.py` (`clamp_position_fraction`/`speed_status_text`) extrae 2 fragmentos puros duplicados (4 y 3 sitios) de `_on_speed_changed`/`_on_morpher_changed`, sin tocar su orquestación real de hilos/Qt/`_player`. Segundo corte (GAP-062): `backend/playback/lorito_speed_zone_labels.py` extrae de `lorito_mw_playback.py` (1099→1068 líneas) el nombre codificado de zona de velocidad del Scrub Velocista (12 tests). Corte anterior (GAP-056): `backend/export/lorito_export_session_spec.py` extrae de `lorito_mw_export.py` (725→637 líneas) el chequeo de integridad end-to-end y el texto del spec de sesión (21 tests). Cobertura end-to-end extendida (GAP-060). El RESTO de la orquestación de hilos/Qt/`_do_export()` (la inmensa mayoría de sus líneas) sigue en los mixins por decisión de riesgo, no por falta de trabajo | GAP-056, GAP-060, GAP-062, GAP-070, GAP-071 |
| 8 | Backend/frontend separation | **Auditoría completa realizada; 1 violación real corregida.** `backend/playback/lorito_tape_physics.py` importaba `_ITL_AVAILABLE` de `frontend/integration/lorito_itl_bridge.py` — corregido (era además un falso gate: dos motores ITL distintos, interno y plugin externo, confundidos). Queda 1 excepción DOCUMENTADA y deliberadamente sin tocar: `backend/core/lorito_stability_patch.py` importa clases de frontend de forma diferida y segura, solo para introspección — moverlo de sitio tocaría de nuevo `lorito_bootstrap.py` | GAP-054 |
| 9 | Integration tests | **Avance real, ahora con "Capture → Playback" cerrado (GAP-072)**: 5 tests ejercitan "Capture → Segment → Export", "Capture → Archive → Classification", "Corruption → Abort" y "Checksum mismatch → INVALID" (§19) sobre los MISMOS segmentos reales a través de `ExportSession` Y `classify_session()` juntos — hallazgo real: un bit-flip que no cambia tamaño pasa Export (no verifica checksum, nunca fue su trabajo) pero lo atrapa Archival, confirmando la división de responsabilidades entre §4 y §9. **"Seek → Scrub → Playback"/"Speed change → Playback" cubiertas (GAP-063)**: 6 tests instancian `PlaybackEngine` real con sus propios hilos (`_prefetch`/`_bridge`/driver de audio simulado) contra el fixture de audio real del usuario — forward, reversa, seek en vivo, cambio de velocidad discreto y en vivo, y stop limpio; encontraron y corrigieron una carrera real en `stop()`. **"Capture → Playback del mismo audio" (GAP-072)**: 3 tests nuevos construyen un segmento WAV PCM24 real y determinista (mismo escritor que `DiskWriterV2`) y lo reproducen con un `PlaybackEngine` real, comparando el CONTENIDO entregado al driver simulado contra lo escrito — muestra a muestra a `ratio=1.0` (post-cuantización PCM24), por correlación a `ratio=1.5` (resampleador real activo), y un detector explícito de canal L/R invertido — hueco que ni GAP-055 (Capture→Export/Archive) ni GAP-063 (Playback con fixture estático ajeno a Capture) cerraban | GAP-055, GAP-063, GAP-072 |
| 10 | Fault injection | **COMPLETA (GAP-073 cierra los 4 escenarios restantes, CON un defecto real encontrado y corregido)**: ENOSPC/EIO en exportación streaming (4 escenarios) y excepción DSP en el drain loop (3 escenarios) — GAP-058, sin defectos encontrados. NaN/Inf en la cadena DSP (9 escenarios, incluida una etapa que falla 10 veces seguidas) — GAP-059, verifica el comportamiento EXISTENTE (sanear+contar+resetear) sin reabrir la decisión de política pendiente de Fase 6, sin defectos encontrados. **Congestión real de CED/RBA investigada (GAP-064)**: reproducida con 40 corridas del ciclo completo en un proceso — la cola se satura y descarta frames POR DISEÑO bajo ruido de scheduling del sandbox combinado con un stub de entrada más rápido que tiempo real; fuga de hilos descartada con evidencia real. No es un defecto de producción alcanzable con hardware real. **Los 4 escenarios que faltaban (GAP-073), todos sobre `PlaybackEngine` real**: disco lento (latencia inyectada en `.read()`/`.seek()`), seek tardío bajo disco lento (dispara la rama de fallback de `_bridge()`), scrub rápido (60 cambios de velocidad en vivo en sucesión rápida) y desconexión de dispositivo de salida (excepción genérica desde el callback de audio, apagado limpio + `on_done`). El escenario de disco lento sostenido encontró un defecto REAL de busy-spin en `_audio_cb()`: tras un refill fallido con el chunk previo agotado (no `None`), el código no entraba al relleno de silencio y giraba sin límite dentro del callback de audio en tiempo real — corregido comprobando ambos estados de "sin datos", verificado con ejecución real (antes: 72 callbacks/0 silencio genuino en 0.6s bajo disco a 50ms; después: 278 callbacks/silencio correcto) y sin regresión en `test_playback_engine_integration.py`/`test_capture_to_playback_integration.py` | GAP-058, GAP-059, GAP-064, GAP-073 |
| 11 | 50h soak test | **Sustituto SINTÉTICO implementado y verificado (GAP-074) — NO satisface literalmente las 50h de reloj real de §23, declarado explícitamente.** `tests/test_soak_synthetic.py` (4 tests): "DSP directo" (6000 chunks ~8.5min equivalentes con cadena NR real DNL+ALC activa, verificando cero NaN/Inf y RSS que se estabiliza en vez de crecer sostenido, más una corrida corta con una etapa cara Muscle EQ+Dolby B) + "ciclos repetidos" (40 ciclos reales de `DiskWriterV2`, extiende GAP-064 con verificación explícita de hilos/RSS; 40 ciclos reales de arranque/cierre de `PlaybackEngine`, nunca ejercitado así antes). Benchmark real de cada etapa DSP documentado (de ~0.4ms/chunk en ALC a ~45ms/chunk en Dolby S — combinadas, algunas cadenas corren más lento que tiempo real en este sandbox, dato para la auditoría siguiente). Ver nota más abajo para las opciones consideradas y por qué se eligió la sintética | GAP-064 (precedente de ciclos), GAP-074 (soak sintético) |
| 12 | Release candidate | **CERRADA (GAP-075)** — verificación final con ejecución real (598/598, con y sin `-W error::ResourceWarning`, dos veces antes del salto de versión y una vez más después; `lorito_bootstrap.py` reverificado dos veces), salto de versión aplicado (`APP_MINOR` 10→11, `_MINOR_REVISION_BASE` 50→77 → `APP_VERSION="0.11.001"`), `saneamiento_0_11_001/` + tarball empaquetados en `dist/`. Con esto, las 12 fases quedan formalmente cerradas | GAP-075 |

## Nota sobre la Fase 11 (soak test de 50 horas) — limitación real, no evitada

La Orden (§23, Suite F) exige una captura continua de 50 horas de
reloj real sin reiniciar el proceso, verificando RAM/CPU estables y
`ARCHIVAL_SAFE` al finalizar. Esto es, literalmente, categóricamente
distinto de todo lo demás en esta Orden: no es una limitación de
stubs/hardware de audio (que SÍ se puede rodear con los stubs
funcionales ya usados en GAP-036/037/041) — es una limitación de
TIEMPO DE RELOJ que ninguna sesión de chat, por diseño, puede sostener.
Opciones reales consideradas para esta fase:

1. **Aceptar una simulación SINTÉTICA (muchos frames sintéticos
   procesados rápido, no muchas horas de reloj) como sustituto parcial
   — ya contemplado como posibilidad por `ESTADO_MAESTRO_SANEAMIENTO.
   md` para la Fase 13 de la Orden anterior, nunca ejecutado hasta
   ahora. IMPLEMENTADA en GAP-074** (ver fila de la tabla arriba) —
   dentro del criterio de la instrucción activa del usuario ("cerrar
   por completo todos los frentes pendientes... diseñando stubs donde
   falte alguna dependencia"): aquí lo que falta no es una dependencia
   sino tiempo de reloj, y el sustituto sintético es el stub
   equivalente para esa limitación específica, exactamente como esta
   misma nota ya lo había dejado abierto.
2. Ejecutar el soak test FUERA de una sesión de chat (script
   standalone que el usuario corre en su propia máquina con hardware
   real durante 50h reales), con Lorito Aldhiro solo preparando el
   script y el criterio de aceptación — sigue sin ejecutarse; es una
   decisión que le corresponde al usuario, no a esta sesión.

## Hallazgos reales de esta sesión (más allá de FASE 1 en sí)

1. **Defecto confirmado en `_build_export_array()`** (código de
   producción, no infraestructura nueva): un segmento truncado no
   producía ningún error — desplazaba en el tiempo el resto de la
   sesión exportada en silencio. Corregido (ver GAP-051).
2. **`backend/transport/__init__.py` y `backend/export/__init__.py`
   vacíos** desde su creación, violando la convención vigente desde
   GAP-032. Corregidos (el primero con reexportes completos, el
   segundo solo con docstring — motivo documentado en GAP-051).
3. **Un test obsoleto** (`test_overflow_tick_wires_ovflow_tp`) fallaba
   contra el código real desde un refactor de una sesión anterior que
   nunca actualizó su aserción. No es una regresión de esta sesión —
   confirmado que ya fallaba en el punto de partida (0.10.003).

## Hallazgos reales de FASE 2 (GAP-052)

1. **Fragilidad de timing real en `DiskWriterV2`/`ColaElasticaDisco`**:
   correr el ciclo completo `start()`/`stop()`/`flush_disk()` de
   `CaptureEngineV2` más de una vez por proceso (o incluso una sola
   vez, en algunas corridas) resultó intermitente en este sandbox —
   confirmado con `faulthandler` que el hilo de `_write_loop` a veces
   no sale a tiempo de `ColaElasticaDisco.get_batch()` tras `stop()`.
   Reproducido con el test YA EXISTENTE de GAP-037 corrido en
   aislamiento — no es un defecto introducido en esta fase. Candidata
   real para Suite E (Fault Injection) o Fase 4 (Transport Core); no
   resuelta aquí (tocaría código de captura en tiempo real sin poder
   verificarlo con hardware real). **Actualización GAP-064**:
   investigada a fondo — descartada la hipótesis de fuga de hilos con
   evidencia real (40 corridas, conteo de hilos estable), y reproducido
   el mecanismo real: saturación de `ColaElasticaDisco` (descarte de
   frames POR DISEÑO, `put_nowait()`) bajo ruido de scheduling del
   sandbox combinado con un stub de entrada deliberadamente más rápido
   que tiempo real — no un defecto de producción alcanzable con
   hardware real de audio. Ver `gaps/GAP-064.md` para el detalle
   completo. De paso, GAP-064 encontró y corrigió un defecto real
   independiente en el mismo subsistema: `DiskWriterV2.flush()`
   esperaba el timeout completo (30s) sin motivo en cada llamada con
   el hilo de escritura activo — corregido, con regresión permanente.
2. `classify_session()` (backend) existía y funcionaba desde la Orden
   anterior pero **nunca se llamaba desde código de producción** —
   confirmado por búsqueda exhaustiva antes de esta sesión.

## Hallazgos reales de GAP-054 (auditoría FASE 3 + fix FASE 8)

1. **`lorito_tape_physics.py` tenía la MISMA familia de bug que
   GAP-053**: un import backend→frontend que además resultó ser un
   falso gate — la bandera que importaba (`_ITL_AVAILABLE`, del motor
   ITL INTERNO) no tenía relación real con el plugin EXTERNO
   (`aecct2_itl_integration`) que el código protegido intentaba usar.
   Corregido; comportamiento observable confirmado idéntico con
   ejecución real.
2. El docstring de `lorito_normalization_streaming.py` (1239 líneas,
   ya completo para los 20 modos) afirmaba estar bloqueado por falta
   de PySide6 ejecutable — desactualizado desde que GAP-036 estableció
   la técnica de instanciación real bajo stubs. El bloqueador real de
   FASE 3 es la falta de un puente de estadísticas y de encoders
   streaming para 3 de los 4 codecs, no PySide6.

## Hallazgo crítico de GAP-056 — `_status` sin importar, 4 archivos, 112 usos

Verificando la extracción de FASE 7 con el mayor rigor posible
(disparando `export()` COMPLETO, no solo las funciones extraídas en
aislamiento) se encontró un `NameError: name '_status' is not defined`
real en la ruta de exportación de producción — y, al auditar el
patrón en todo el árbol, resultó estar presente en 4 archivos
completos (`lorito_mw_export.py`, `lorito_mw_recording.py`, `lorito_
mw_telemetry.py`, `lorito_mw_silence_autopause.py`, 112 usos en
total), todos con el mismo import de `lorito_audio_backend` YA
presente pero sin `_status` en la lista. Más grave que GAP-053 en un
sentido concreto: no impide arrancar la app, así que pasó
desapercibido — pero significa que, antes de este fix, **toda
exportación real terminaba mostrando un error al usuario aunque el
archivo de audio se hubiera escrito bien**, y el archivo "Aldhira de
Especificación de CRAC" nunca llegó a generarse. Corregido (una línea
por archivo) y cerrado con un test de regresión permanente. Ver
GAP-056 para el detalle completo, incluida la explicación de por qué
una versión generalizada de ese test (cualquier nombre libre, no solo
`_status`) se descartó por ruido de falsos positivos.

**Seguimiento (GAP-057)**: verificado con ejecución real que los otros
3 archivos también funcionan tras el fix, no solo el de exportación.
Hallazgo adicional real: `_update_internal_status`/`_archival_tick`
corren en `QTimer` reales (1 Hz y cada 5 s) arrancados
incondicionalmente desde que la ventana principal termina de
construirse — antes del fix, el `NameError` era recurrente durante
TODA sesión de uso real de la app, no un fallo puntual al exportar.
`start_record()` también resetea `_status` como parte de sus primeras
operaciones. Los 6 métodos directamente invocables de los 3 archivos
verificados limpios con `LoritoAldhiroStudio()` real bajo stubs.

## Hallazgos reales de GAP-062 (audio real + FASE 6 + FASE 7)

1. **Deriva de fase real confirmada con audio real, no solo
   sintético**: 20s de `Sotalomafer1.mp3` (cassette transdigitalizado
   en CRAC 0.10, adjuntado por el usuario) reproducen, con música/voz
   real, el mismo defecto que GAP-037 solo había medido con tonos
   sintéticos — error real hasta ~70000× mayor en el resampleador
   legado que en la corrección, en los 3 ratios forward probados más
   reversa y post-seek-reset. La corrección (`resample_stateful_
   continuous()`, ya construida en GAP-037) queda cableada a
   producción tras `USE_CONTINUOUS_RESAMPLE`.
2. **El WAV real producido por `ffmpeg -c:a pcm_s24le` usa
   WAVE_FORMAT_EXTENSIBLE**, que el módulo `wave` de la stdlib (y por
   tanto el stub funcional de soundfile del proyecto) rechaza —
   resuelto con un parser RIFF manual (`tests/_wav_pcm24_extensible_
   reader.py`) en vez de re-codificar el fixture o tocar el stub
   compartido.
3. **Código muerto real encontrado en `lorito_mw_playback.py`**:
   `_resample_full_cubic()`/`_resample_block_cubic()` — cero
   llamadores, cero tests, una tercera implementación redundante del
   mismo resampleo cúbico Catmull-Rom que ya vive, activo, en
   `PlaybackEngine`. Documentado, no retirado (decisión de retiro
   pendiente, no automática).

## Hallazgos reales de GAP-063 (integración de hilos reales de `PlaybackEngine`)

1. **Carrera real (no teórica) en `PlaybackEngine.stop()`/
   `_play_loop`**: `stop()` (hilo llamador) podía poner
   `self._stream = None` justo cuando el bucle monitor de `_play_loop`
   (su propio hilo) leía `self._stream.active` — `AttributeError`
   real, no fatal (capturado, el `finally:` de limpieza seguía
   corriendo bien) pero reproducible en el 100% de las llamadas a
   `stop()` observadas durante los primeros tests reales con hilos que
   corrió este motor. Encontrada ÚNICAMENTE porque este GAP construyó
   el primer test que ejecuta `PlaybackEngine` con concurrencia real
   — ni la lectura de código ni los tests puros de resampleo (GAP-037/
   062) podían haberla revelado. Corregida con una copia local del
   stream, inmune a la reasignación desde otro hilo.
2. **Segundo hallazgo, de infraestructura de test (no de producción)**:
   mismo patrón de fragilidad de orden de import entre archivos de
   test ya documentado en GAP-036/037/041 (`ce_mod.sd =
   sys.modules["sounddevice"]`) — reapareció para `PlaybackEngine`
   porque su suite nueva pasaba aislada pero fallaba al correr la
   batería COMPLETA. Resuelto con el mismo patrón ya establecido
   (reasignar `pe.sd`/`pe.sf` tras el import, sin importar el orden).

## Hallazgos reales de GAP-065/066/067 (cierre COMPLETO de FASE 3, huecos a/b/c)

1. **Deriva sistemática de conteo de frames en resampleo streaming
   por bloques** (GAP-065): `resample_stateful_continuous()` calcula
   `n_out` de forma independiente por bloque — con bloques de tamaño
   uniforme, el mismo error de redondeo se repite en cada bloque y
   crece LINEALMENTE con el número de bloques (medido con números
   reales: deriva no-cero con 2M frames/~3906 bloques). Resuelto con
   una técnica de "objetivo acumulado" (estilo Bresenham) que
   perturba el `ratio` LOCAL de cada bloque en una cantidad
   imperceptible en vez de tocar la función compartida — conteo
   EXACTO garantizado, verificado con ejecución real, no solo
   argumentado.
2. **4 defectos reales en la infraestructura de encoders streaming**
   (GAP-066), encontrados con ejecución real contra `ffmpeg`, no
   hipotéticos — el más importante: **`AtomicFinalizer` (código
   COMPARTIDO por TODOS los encoders, incluido `WavEncoder`) limpiaba
   el `.partial` ANTES de llamar a `encoder.finalize()`** en la ruta
   de fallo. Invisible con un encoder síncrono (`WavEncoder`, ya
   escribe directo a disco), pero con un encoder ASÍNCRONO respaldado
   por un subproceso (`ffmpeg`), el archivo de salida podía no
   existir aún en ese momento y terminar de crearse DESPUÉS de la
   "limpieza" — `.partial` huérfano real, violación de §37/§38.
   Corregido: reordenado para que `finalize()` corra siempre primero.
   Los otros 3: `Popen.communicate()` tras cerrar `stdin` a mano
   (`ValueError`, mismo patrón sin probar en el `WVExporter` legado);
   el decodificador de `ffmpeg` redondea streams Vorbis muy cortos
   (<~1.1s) al alza (el contenedor SÍ es exacto — corregido leyendo
   `duration_ts`/`time_base` vía `ffprobe` en vez de decodificar); el
   encoder nativo `vorbis` de ffmpeg no admite mono (sin impacto
   práctico, documentado).
3. **`ffmpeg` necesita `-f <formato>` de salida explícito** cuando el
   nombre de archivo no termina en una extensión reconocible —
   `AtomicFinalizer` SIEMPRE escribe primero a `final_path +
   ".partial"`, invisible probando un encoder aislado con una ruta ya
   con la extensión correcta, solo aparece con `ExportSession` real de
   punta a punta.
4. **Falso positivo nuevo del scanner `_status.` (GAP-056/057)**
   (GAP-067): el scanner de regresión que busca la subcadena literal
   `"_status."` sin import, para atrapar el `NameError` real de
   GAP-056 si reaparece, opera sobre TEXTO crudo, no AST — no
   distingue código de docstrings (limitación ya autodocumentada desde
   GAP-056/057). El docstring del nuevo puente de estadísticas
   mencionaba `_status.normalization_*` como prosa explicativa (nunca
   como código — ese módulo usa un parámetro local `status`,
   deliberadamente sin importar el singleton) y disparó 5 falsos
   positivos. Corregido reescribiendo el texto del docstring para
   evitar la subcadena exacta, sin tocar ningún comportamiento de
   código — confirma que el scanner sigue necesitando, como trabajo
   futuro ya identificado, un análisis real de ámbito con `ast` en vez
   de regex sobre texto.

## Documentos de referencia de esta Orden

- `gaps/GAP-051.md` — detalle completo de FASE 1, incluidas las 6
  decisiones de diseño registradas para que sesiones futuras no las
  reabran sin verlas.
- `gaps/GAP-052.md` — detalle completo de FASE 2, incluida la
  fragilidad de timing de `DiskWriterV2` y la decisión pendiente sobre
  `checksum_verified`.
- `gaps/GAP-053.md` — **fuera de las 12 fases**: fix crítico de un bug
  reportado por el usuario (`lorito_bootstrap.py` no arrancaba, 7
  imports con rutas planas anteriores a la arborización) más el cierre
  del hueco de cobertura que permitió que pasara desapercibido. Se
  menciona aquí porque una sesión que continúe esta Orden desde un
  tarball 0.10.004/0.10.005 debe saber que esos dos SÍ tenían este bug
  — usar 0.10.006 o posterior.
- `gaps/GAP-054.md` — auditoría profunda de FASE 3 (3 huecos reales
  identificados, no cableada todavía) + fix real de FASE 8
  (`lorito_tape_physics.py`, misma familia de bug que GAP-053).
- `gaps/GAP-055.md` — auditoría de FASE 4 (Transport Core, mismo
  riesgo que FASE 3) + avance real de FASE 9 (Suite B: 5 tests de
  integración cruzada Export↔Archival, incluido el hallazgo de la
  división de responsabilidades sobre bit rot).
- `gaps/GAP-056.md` — **fix crítico fuera de las 12 fases**: `_status`
  (global `BackendStatus`) sin importar en 4 archivos, 112 usos,
  `NameError` garantizado en la ruta real de exportación — descubierto
  verificando el primer corte real de FASE 7. Toda sesión que continúe
  desde un tarball anterior a 0.10.009 debe saber que lo tenía.
- `gaps/GAP-057.md` — seguimiento de GAP-056: verificación con
  ejecución real de los otros 3 archivos afectados. Hallazgo adicional:
  dos de los métodos corrían en QTimers reales cada 1 y 5 segundos
  durante toda sesión de uso de la app, no solo al exportar.
- `gaps/GAP-058.md` — FASE 10 (Fault Injection): ENOSPC/EIO en
  exportación y excepción DSP en el drain loop, ambos con ejecución
  real, sin defectos nuevos encontrados (resultado positivo real).
- `gaps/GAP-059.md` — FASE 10 continuación: NaN/Inf en la cadena DSP,
  verifica el comportamiento existente (sanear+contar+resetear) sin
  reabrir la decisión de política pendiente de Fase 6.
- `gaps/GAP-060.md` — cobertura end-to-end real de ramas de
  exportación nunca antes ejercitadas (resampleo, normalización, FLAC,
  OGG) + fix de una limitación real del stub de señales compartido
  (`Signal.emit()` no replicaba la aridad flexible de Qt).
- `gaps/GAP-061.md` — `classify_session()` conectado al cierre real de
  sesión (`stop_all()`) — cierra el pendiente de GAP-052, completando
  FASE 2 del todo. Resultado guardado, sin presentación en UI todavía.
- `gaps/GAP-062.md` — audio real del usuario (`Sotalomafer1.mp3`)
  confirma y corrige un defecto real de deriva de fase en el
  resampler de scrub (FASE 4/5, cableado a producción tras flag);
  cuestionario + implementación de la política FASE 6 (NaN/Inf
  degrada archival, sin abortar); segundo corte real de FASE 7
  (`lorito_speed_zone_labels.py`) + hallazgo de código muerto.
- `gaps/GAP-063.md` — primera cobertura de integración con hilos
  reales de `PlaybackEngine` (6 tests, fixture de audio real) +
  infraestructura nueva (stub funcional de `sounddevice.OutputStream`,
  tolerancia WAVE_FORMAT_EXTENSIBLE + `.seek()` en el stub de
  `soundfile`) + carrera real encontrada y corregida en `stop()`/
  `_play_loop` + fix de orden de import entre archivos de test (mismo
  patrón de GAP-036/037/041).
- `gaps/GAP-064.md` — `DiskWriterV2.flush()` esperaba 30s sin motivo
  (corregido, con regresión permanente) + investigación real de la
  flakiness de `ColaElasticaDisco`/`DiskWriterV2` documentada desde
  GAP-052 (fuga de hilos descartada con evidencia real; mecanismo real
  reproducido y explicado — ruido de sandbox sobre un stub más rápido
  que tiempo real, no un defecto de producción).
- `gaps/GAP-065.md` — FASE 3, hueco (a): resampleo streaming por
  velocidad con conteo de frames exacto (técnica de "objetivo
  acumulado", sin deriva sistemática) — `StreamingSpeedResampleTransform`
  cableada en `ExportSession` vía `expected_output_frames`.
- `gaps/GAP-066.md` — FASE 3, hueco (b): encoders streaming
  FLAC/OGG/WavPack vía `ffmpeg` + 4 defectos reales corregidos en la
  infraestructura común de encoders (el más importante, en
  `AtomicFinalizer`, código compartido por todos los encoders).
- `gaps/GAP-067.md` — FASE 3, hueco (c), ÚLTIMO de los 3 — FASE 3
  QUEDA COMPLETA: puente `ExportSessionReport`↔`normalization_stats`
  (`lorito_normalization_stats_bridge.py`) + flag
  `USE_STREAMING_EXPORT` (mismo patrón que `USE_CONTINUOUS_RESAMPLE`)
  + falso positivo nuevo del scanner `_status.` encontrado y corregido
  en docstrings.
- `gaps/GAP-068.md` — FASE 4/5, cierre FORMAL (decisión documentada,
  sin código nuevo): NO cablear `TransportMachine`/`SpeedPlanner`/
  `GenerationGuard` en esta Orden — diferido a la auditoría siguiente
  (post-0.11) por §29 (verificación con audio real no disponible aquí)
  y por instrucción propia del usuario (descontaminación de audio/DSP
  de hilos GUI como objetivo de esa próxima auditoría). Documenta
  también qué infraestructura queda lista para esa sesión futura.
- `gaps/GAP-069.md` — FASE 6 QUEDA COMPLETA: auditoría de cardinalidad
  de canales (§16), último pendiente de esa fase — 18 tests con
  `NRCoordinator(channels=1)` real contra cada perfil de la cadena DSP
  (incluidos los 20 sub-perfiles de Lucha Enloquecida uno por uno) y
  la cadena completa activa; resultado POSITIVO real, sin defectos
  encontrados (pasaron en la primera ejecución).
- `gaps/GAP-070.md` — FASE 7, tercer corte real: retiro de código
  muerto (`_resample_full_cubic`/`_resample_block_cubic`, auditados
  dos veces) + extracción mecánica de 2 helpers puros
  (`clamp_position_fraction`/`speed_status_text`,
  `lorito_playback_scrub_sync.py`) de `_on_speed_changed`/
  `_on_morpher_changed`, sin tocar su orquestación real de hilos/Qt.
- `gaps/GAP-071.md` — FASE 7, cuarto corte real Y decisión de riesgo:
  `backend/export/lorito_export_naming.py` extrae mecánicamente la
  lógica pura de nombrado/formato de `_do_export()`; decisión
  explícita de NO construir un `ExportController` completo en esta
  Orden (mismo criterio de riesgo que GAP-068/FASE 4/5) — con esto,
  FASE 7 queda cerrada. Incluye un hallazgo real de precisión de
  punto flotante en el umbral de velocidad del tag de nombre de
  archivo.
- `gaps/GAP-072.md` — FASE 9 (§19): cierra el par "Capture → Playback
  del mismo audio", el único par de integración explícitamente pedido
  que quedaba sin cobertura (ni GAP-055 —Capture→Export/Archive— ni
  GAP-063 —Playback con fixture estático ajeno a Capture— lo cerraban).
  3 tests nuevos (`test_capture_to_playback_integration.py`): contenido
  entregado a `PlaybackEngine` real comparado muestra a muestra (dominio
  PCM24) contra un segmento escrito con el mismo escritor que
  `DiskWriterV2`, a `ratio=1.0` (passthrough real confirmado leyendo
  `_prefetch()`) y por correlación a `ratio=1.5`, más un detector
  explícito de canal L/R invertido.
- `gaps/GAP-073.md` — FASE 10 QUEDA COMPLETA (§20): los 4 escenarios
  de fault injection restantes sobre `PlaybackEngine` real (disco
  lento, seek tardío bajo disco lento, scrub rápido, desconexión de
  dispositivo de salida, `test_fault_injection_playback.py`, 6
  tests). El escenario de disco lento encontró y corrigió un defecto
  REAL de busy-spin en `_audio_cb()`: un underrun con el chunk previo
  agotado (no `None`) giraba sin límite dentro del callback de audio
  en tiempo real en vez de degradar a silencio — corregido
  comprobando ambos estados de "sin datos" tras un refill fallido.
  También documenta y corrige dos falsos negativos reales del propio
  arnés de test (mutar `sys.modules[...]` en vez de `pe.sf`/`pe.sd`
  directamente — invisible en aislamiento, real bajo
  `unittest discover`, mismo problema de reimportación que
  GAP-036/037/041).
- `gaps/GAP-074.md` — FASE 11 (§23, Suite F): soak test SINTÉTICO
  como sustituto PARCIAL declarado de las 50h de reloj real —
  `tests/test_soak_synthetic.py` (4 tests): "DSP directo" (volumen
  sostenido contra `NRCoordinator` real, con benchmark real de cada
  etapa DSP documentado) + "ciclos repetidos" (40 ciclos reales de
  `DiskWriterV2` y de `PlaybackEngine`). Documenta también un hallazgo
  de arnés (no de producción): `flush(timeout=5.0)` en 100 ciclos
  costaba 251s por el tope interno `CE_DISK_FLUSH_SETTLE_MAX_S=2.0s`
  de GAP-064 — reducido a `timeout=0.15` y 40 ciclos.
- `gaps/GAP-075.md` — **FASE 12, ÚLTIMA fase — cierre formal de TODA
  la Orden Maestra**: verificación final con ejecución real, resumen
  final de las 12 fases (cuáles completas, cuáles cerradas con
  decisión de riesgo, cuál con sustituto sintético parcial — sin
  reescribir ninguna como "completa sin matices"), salto de versión
  0.10→0.11 (`APP_VERSION="0.11.001"`) y empaquetado de
  `saneamiento_0_11_001/` + tarball en `dist/`.
- `/ESTADO_MAESTRO_SANEAMIENTO.md` — las DOS Órdenes anteriores (sigue
  vigente, alcance distinto — no reemplazado por este documento).

## Cómo continuar en una sesión nueva

**ORDEN MAESTRA CERRADA (2026-09-18, GAP-075) — las 12 fases están
todas completas o formalmente cerradas con decisión documentada, y la
versión ya está en 0.11.001.** No queda ningún frente abierto de esta
Orden para retomar. Una sesión nueva que continúe sobre esta base
debe partir directamente de la **auditoría siguiente, ya anunciada
por el usuario**: descontaminación de la tubería de audio y DSP de
hilos GUI, más otras optimizaciones — un frente NUEVO, no una
continuación de las 12 fases ya cerradas. Insumos ya dejados listos
para esa auditoría futura, todos documentados en los GAPs
correspondientes:

- El benchmark real de costo por etapa DSP (GAP-074): de ~0.4ms/chunk
  (ALC) a ~45ms/chunk (Dolby S) sobre un chunk de 4096 frames — varias
  etapas caras combinadas pueden correr más lento que tiempo real en
  este sandbox.
- El Transport Core nuevo (`TransportMachine`/`SpeedPlanner`/
  `GenerationGuard`, FASE 4/5, GAP-068) ya construido y probado en
  aislamiento, sin cablear a producción por decisión explícita de
  riesgo — candidato natural para esa descontaminación de hilos.
- El fixture de audio real del usuario (`tests/fixtures/`) y la
  infraestructura de stubs funcionales de `sounddevice`/`soundfile`
  (GAP-036/037/041/062/063/072/073) — reutilizables sin modificación.
- El defecto de busy-spin corregido en `_audio_cb()` (GAP-073) y la
  regla de test (mutar `<modulo>.sd`/`<modulo>.sf` directamente, nunca
  `sys.modules[...]`, ver más abajo) — ambos relevantes para cualquier
  trabajo futuro sobre el callback de audio en tiempo real.
- Un `ExportController`/`PlaybackController` completo desacoplado de
  Qt (FASE 7, GAP-071) sigue diferido por el mismo criterio de riesgo
  — candidato también para esa sesión futura si su alcance incluye
  desacoplar la orquestación de hilos/Qt, no solo el DSP.

Si en cambio se quisiera **reabrir** alguna decisión ya cerrada de
esta Orden (no recomendado sin pedido explícito del usuario): Fase 6
(política NaN/Inf + cardinalidad de canales) ya tiene
AMBOS pendientes cerrados (GAP-062 la política, GAP-069 la
cardinalidad, sin defectos encontrados) — no reabrir sin que el
usuario lo pida explícitamente. El `checksum_verified` estricto de
Fase 2 (si se
quiere reabrir) sigue siendo una decisión de política pendiente. Fase
4/5: **cerrada formalmente (GAP-068) — no reabrir el cableado del
Transport Core nuevo en esta Orden**; ese trabajo es, por decisión
explícita ya registrada, el objeto de la auditoría siguiente
(post-0.11, descontaminación de audio/DSP de hilos GUI), no un
pendiente de esta. El defecto real del resampler de scrub ya está
corregido, verificado con audio real (GAP-062) y con integración de
hilos reales (GAP-063, incluida una carrera real encontrada y
corregida en `stop()`); el Transport Core nuevo
(`TransportMachine`/`SpeedPlanner`/`GenerationGuard`) sigue sin cablear
por esa decisión — cuando llegue esa auditoría siguiente, el fixture
de audio real ya embebido en `tests/fixtures/` y la infraestructura de
stubs de `OutputStream` ya construida en GAP-063 están listos para
reutilizarse sin modificación. **Fase 7 CERRADA**: el código muerto
(`_resample_full_cubic`/`_resample_block_cubic`) fue retirado
(GAP-070, auditado dos veces antes de borrar); helpers puros extraídos
de `_on_speed_changed`/`_on_morpher_changed`
(`clamp_position_fraction`/`speed_status_text`,
`lorito_playback_scrub_sync.py`, GAP-070) y de `_do_export()`
(`export_codec_extension`/`export_speed_filename_tag`/
`export_speed_display_suffix`/`export_clip_tag`,
`lorito_export_naming.py`, GAP-071) — el RESTO de esos métodos (la
inmensa mayoría de sus líneas: orquestación real de hilos/Qt/
`_player`/`_bridge`) sigue en los mixins **por decisión explícita de
riesgo** (GAP-071, mismo criterio que GAP-068/FASE 4/5), no por falta
de trabajo — un `ExportController`/`PlaybackController` completo
desacoplado de Qt queda diferido a una sesión con verificación real de
GUI disponible, no reabrir sin que el usuario lo pida explícitamente.
**Fase 9 tiene ahora cerrado su par "Capture→Playback del mismo
audio"** (GAP-072: `tests/test_capture_to_playback_integration.py`,
3 tests, contenido verificado no solo integridad mecánica) — no
reabrir sin que el usuario lo pida. **Fase 10 YA ESTÁ COMPLETA**
(GAP-073: los 4 escenarios que faltaban — disco lento, seek tardío
bajo disco lento, scrub rápido, desconexión de dispositivo de salida
— sobre `PlaybackEngine` real, `tests/test_fault_injection_playback.py`,
6 tests) — no reabrir sin que el usuario lo pida. GAP-073 corrigió
además un defecto REAL de busy-spin en `_audio_cb()`
(`lorito_playback_engine.py`, ~línea 1194): tras un refill fallido,
si el chunk previo estaba agotado (no `None`) el código no entraba
al relleno de silencio y giraba sin límite dentro del callback de
audio en tiempo real — corregido comprobando ambos estados de "sin
datos" (`chunk is None` O `pos >= len(chunk)`), verificado sin
regresión contra `test_playback_engine_integration.py`/
`test_capture_to_playback_integration.py`. **Fase 11 YA TIENE su
sustituto sintético (GAP-074)**: `tests/test_soak_synthetic.py` (4
tests) — "DSP directo" (volumen sostenido contra `NRCoordinator`
real, benchmark real de cada etapa DSP documentado en el GAP) +
"ciclos repetidos" (40 de `DiskWriterV2`, 40 de `PlaybackEngine`) —
declarado EXPLÍCITAMENTE como sustituto PARCIAL, no equivalencia
literal de las 50h de reloj real de §23 — no reabrir sin que el
usuario lo pida. **Fase 12 YA ESTÁ CERRADA (GAP-075)**: verificación
final + salto de versión a 0.11.001 + empaquetado — con esto, **las
12 fases de la Orden Maestra quedan formalmente cerradas por
completo**, no reabrir ninguna sin que el usuario lo pida
explícitamente. Al escribir un test nuevo que instancie un
módulo `backend/*` con stubs de
`sounddevice`/`soundfile`, reasignar `<modulo>.sd`/`<modulo>.sf =
sys.modules[...]` tras el import SIEMPRE — no asumir que el orden de
`unittest discover` coincide con el de correr el archivo aislado
(mismo patrón ya visto en GAP-036/037/041/063). Además, **dentro de
un método de test, mutar SIEMPRE `<modulo>.sd`/`<modulo>.sf`
directamente (nunca `sys.modules["sounddevice"/"soundfile"]`)**
cuando se necesite instalar un fallo/latencia sobre un módulo YA
importado — `sys.modules[...]` puede haber sido reemplazado por el
import de OTRO archivo posterior bajo `unittest discover`, dejando la
inyección sin efecto real (falso negativo confirmado en GAP-073,
solo visible bajo la suite completa, nunca en aislamiento). La
flakiness de `ColaElasticaDisco`/`DiskWriterV2` (GAP-052, investigada
a fondo en GAP-064) NO requiere más investigación — está explicada y
confirmada como ruido de sandbox sobre un stub más rápido que tiempo
real, no un defecto de producción. Recordatorio permanente:
reverificar `lorito_bootstrap.py` explícitamente antes de cerrar
cualquier sesión.
