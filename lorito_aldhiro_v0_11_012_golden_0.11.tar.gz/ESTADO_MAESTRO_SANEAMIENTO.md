# ESTADO_MAESTRO_SANEAMIENTO.md — Orden Maestra de Saneamiento
Pre-Auditoría Aldhira Phonographic (rama 0.06.005 → 0.09.004)

Documento consolidado tras GAP-024 a GAP-046 — pensado para no tener
que reconstruir el estado leyendo GAPs sueltos en una sesión nueva.
Se actualiza al cierre de cada sesión que toque esta Orden Maestra.

## Veredicto vigente

**0.09.004 sigue sin superar los Gates 3 (ARCHIVAL) y 4 (RELEASE)
completos** de la Orden Maestra original. No entregar a Aldhira
Phonographic todavía. Gates 1 (BUILD) y 2 (TEST) en PASS —
**365/365 tests, 0 fallidos**, con y sin `-W error::ResourceWarning`.

## Mapa de fases — estado real, no aspiracional

| Fase | Qué es | Estado | GAP |
|---|---|---|---|
| 0 | Auditoría inicial | Hecha | GAP-024 |
| 1 | Export streaming (RAM O(bloque)) | Infra construida y verificada bit-exacta; **NO integrada a `main_window.export()`** (bloqueado por PySide6 — ver nota de stubs más abajo) | GAP-025/026 |
| 2 | Política de errores de lectura | Defecto real corregido: un segmento truncado (header miente sobre su tamaño real) se entregaba en silencio como si fuera el final normal de la sesión — ahora `SegmentReadError` lo detecta y nombra el segmento exacto | GAP-034 |
| 3 | Ring buffer RT sin locks | `LockFreeSPSCRingBuffer` construido y verificado con concurrencia real de hilos Y con un pipeline de captura end-to-end simulado (GAP-037, stub funcional de `sounddevice`). **NO integrado a `CaptureEngineV2` en producción** — el swap final sigue pendiente de hardware real para el veredicto de timing definitivo | GAP-031/037 |
| 4 | Política de overflow | Auditada, sin defectos — diseño ya coherente | GAP-031 |
| 5 | Cola Elástica de Disco (CED) | Defecto real corregido: `dropped_frames` nunca se incrementaba | GAP-031 |
| 6 | Recovery no-destructivo | Auditado con `CaptureEngineV2` real + mocks de tiempo — sin defectos | GAP-032 |
| 7 | Máquina de estados archival | Construida desde cero (`backend/archival/`, GAP-032). **Checksums reales por segmento conectados** (GAP-035): `DiskWriterV2` calcula SHA-256/CRC32 releyendo el segmento de disco al cerrarlo; `classify_session()` detecta corrupción real (bit rot, truncamiento) si se le pasan. `_IntegrityMonitor` viejo queda como código muerto documentado (deliberadamente no reutilizado, ver GAP-035) | GAP-032/035 |
| 8 | RF64 | Implementado completo — `WavEncoder` ya no falla sobre ~3.9GB | GAP-033 |
| 9 | Playback/Scrub/Velocista | Casos nombrados por la orden ("scrub con underrun", "seek durante prefetch") verificados explícitamente en `GenerationGuard` — máquina de estados pura, sin hardware | GAP-034 |
| 10 | Sanitización DSP (`DSP_NONFINITE_OUTPUT`) | Implementada y verificada — guard finite-in/finite-out en `NRCoordinator` | GAP-025 |
| 11, 15 (higiene inicial) | Tests obsoletos + fugas de recursos | Hechas | GAP-024 |
| 12 | Cobertura de tests | Medida por primera vez con el módulo estándar `trace` (sin `coverage`/`pytest-cov`, no instalables) — **42.3% agregado**, ver `/COBERTURA.md` para el desglose | GAP-034 |
| 14 | Inyección de fallos | `DiskWriterV2` real ejercitado con fallos forzados (ENOSPC, fallo transitorio, agotar reintentos, disco casi lleno, fallo al abrir segmento) vía un stub funcional de `sf.SoundFile` respaldado por `wave` | GAP-034 |
| 15 | Higiene del release | README actualizado (estaba congelado en 0.01.002); `lorito_version.py` reducido de 1062 a 122 líneas (946 líneas de changelog CRAC pre-bifurcación, 100% inertes, movidas a `/HISTORICO_VERSION_CRAC.md`) | GAP-034 |
| 16 | Contratos técnicos obligatorios | Escritos por primera vez — `/EXPORT_CONTRACT.md` y `/RT_CONTRACT.md`, documentando solo lo YA construido y verificado (no aspiracional) | GAP-034 |
| Normalización (20 modos) | Los 20 modos de `NormalizationMode`/`V21` en streaming de dos pasadas | Completo y verificado bit-exacto (con 2 excepciones documentadas: `INTELLIGENT_PEAK` aproximado por histograma, `TRUE_PEAK` con discrepancia acotada en fronteras de segmento). **NO integrado a `main_window.export()`** | GAP-027/028/029/030 |
| 13 | Pruebas de larga duración | **Sin abordar** — es la única de las fases "sin identificar" que sí depende genuinamente de hardware real (o de aceptar una simulación sintética como sustituto parcial) | — |
| 17 | Auditoría interna final (6 categorías A-F) | Meta-fase — depende de que el resto esté completo | — |
| 28 | Checklist de entregables de cierre (13 puntos) | Depende de que el resto de fases estén completas primero | GAP-024 |

## Defectos reales encontrados y corregidos en esta cadena de sesiones
(no solo en código nuevo — varios en el código que la GUI usa hoy)

1. `WavEncoder._float32_to_pcm_bytes` (streaming) — escala asimétrica +
   truncación, 100% de las muestras con hasta ±1 LSB de error incluso
   sin ningún DSP aplicado. **Corregido** — GAP-026.
2. `NRCoordinator` — sin guard `DSP_NONFINITE_OUTPUT`, un solo NaN
   podía envenenar el estado IIR de una etapa para siempre.
   **Corregido** — GAP-025.
3. `_norm_adaptive_block` (legado) — **crasheaba con `ValueError`** en
   cualquier audio estéreo real al llegar a una zona de crossfade,
   nunca antes ejercitado. **Corregido** — GAP-029 (y el mismo bug en
   la versión streaming propia, también corregido).
4. `measure_block_rms_streaming` (streaming) — desalineación real de
   buffer que corrompía las ventanas de análisis desde la tercera en
   adelante. **Corregido** — GAP-029.
5. `ColaElasticaDisco.dropped_frames` — nunca se incrementaba pese a
   la promesa explícita de "nunca descarta silenciosamente".
   **Corregido** — GAP-031.
6. `integrity_crc32_errors`/`_IntegrityMonitor` — estructuralmente
   condenado a valer siempre 0. **Resuelto de otra forma** (GAP-035):
   en vez de conectar `_IntegrityMonitor` (arriesgaba falsos positivos
   por no poder verificar el redondeo interno de `soundfile`), se
   construyó `lorito_segment_checksum.py` — checksum real releyendo
   el segmento ya escrito desde disco, conectado a `DiskWriterV2` y a
   `classify_session()`.
7. `SegmentProvider.iter_blocks()` — un segmento truncado (header
   miente sobre su tamaño real) se entregaba en silencio, marcado
   incorrectamente como el final normal de la sesión. **Corregido** —
   GAP-034 (`SegmentReadError`).

## Convención de árbol de módulos (vigente desde GAP-032)

Código nuevo se organiza en subpaquetes conectados por `__init__.py`
— nunca ficheros sueltos en `backend/`. Ramas actuales:
- `backend/export_streaming/` — Fase 1 + normalización (GAP-002 a 030).
- `backend/rt/` — `LockFreeSPSCRingBuffer` (Fase 3, GAP-031).
- `backend/archival/` — máquina de estados de integridad (Fase 7, GAP-032).

## GAP-037 — cierre de los frentes de hardware con stubs funcionales

Extendida la técnica de stubs a `sounddevice.InputStream` (hilo real
llamando al callback real) — `CaptureEngineV2` corrido de punta a
punta, watchdog real escalando con temporización real. Hallazgo
central: medida por primera vez (antes solo especulada en GAP-026)
la deriva de fase real de `_resample_stateful` con los tamaños de
bloque que usa `PlaybackEngine` en producción — se acumula
progresivamente, no es un artefacto puntual. Corrección construida
y verificada (`resample_stateful_continuous`), no integrada a
producción todavía. Ver GAP-037.

## GAP-036 — el hallazgo de PySide6 ya se puso a prueba

Se instaló un stub FUNCIONAL de `soundfile` (lectura+escritura
reales) y se ejecutó `_build_export_array()` REAL contra segmentos
sintéticos, comparando contra `SegmentProvider` streaming —
**resultado idéntico bit a bit**. Esto reduce sustancialmente el
riesgo de la integración de Fase 1, aunque el swap real a
`main_window.export()` sigue sin hacerse (ese método es mucho más
grande que `_build_export_array` en aislamiento). Ver GAP-036.

## Hallazgo importante para reevaluar qué está "bloqueado por PySide6" (contexto original, GAP-034)

Investigando la Fase 12 (cobertura) se confirmó que existe, desde
ANTES de esta cadena de sesiones, un mecanismo de stubs de PySide6
razonablemente completo (`tests/test_stability_patch.py::
_install_stub_modules` — incluye un Signal/slot REAL, no solo un
dummy) que permite IMPORTAR y ejercitar estructuralmente
`lorito_main_window.py` y los widgets del frontend en este sandbox.
Esto NO significa que la integración de Fase 1/normalización a
`main_window.export()` deje de estar bloqueada — ese trabajo sigue sin
intentarse — pero sí que la afirmación repetida en sesiones anteriores
("bloqueado por PySide6 no ejecutable") merece revisarse caso por
caso: puede que una porción de esa integración sea auditable a nivel
lógico/estructural con este mecanismo, aunque no a nivel de
interacción visual real. No explorado a fondo todavía.

## Pendiente, categorizado por qué lo bloquea

**Bloqueado por PySide6 no ejecutable en este sandbox (con la
salvedad de arriba):**
- Integrar el export streaming + los 20 modos de normalización a
  `main_window.export()` (reemplazar `_build_export_array()` +
  `ExporterBase.export()`).

**Bloqueado por hardware de audio real:**
- Reemplazar `RingBufferAbsorcion` por `LockFreeSPSCRingBuffer` dentro
  de `CaptureEngineV2` — necesita verificar comportamiento empírico
  bajo carga real (jitter del scheduler, timing real de PortAudio) que
  ningún test de hilos sintéticos puede replicar del todo.
- Medir el impacto real de `_resample_stateful` (interpolación por
  bloque) en export completo.
- Fase 13 (pruebas de larga duración) — a menos que se acepte una
  simulación sintética (muchos frames, no muchas horas de reloj) como
  sustituto parcial.

**Meta-fases, dependen de que el resto esté completo:**
- Fase 17 (auditoría interna final, 6 categorías).
- Fase 28 (checklist de entregables de cierre).

## Documentos de referencia generados por esta Orden

- `/EXPORT_CONTRACT.md`, `/RT_CONTRACT.md` — contratos técnicos (Fase 16).
- `/COBERTURA.md` — reporte de cobertura (Fase 12).
- `/HISTORICO_VERSION_CRAC.md` — changelog heredado del monolito CRAC,
  extraído de `lorito_version.py` (Fase 15).

## Cómo continuar en una sesión nueva

Adjuntar el último tarball entregado y escribir "Lorito" — o pedir
directamente continuar con uno de los pendientes de arriba.


## GAP-038 — frente nuevo: DSP de CRAC (crac_v0_37_416) para Lorito Aldhiro

El usuario aportó un tarball de CRAC pidiendo adaptar 5 DSP
(Florecedor Cristhi Cosh, Antipestal Lola Grillo, Autoalineación,
Versión O Tron, Lucha Enloquecida) y replicar protecciones de cierre.
Decisiones del usuario: Autoalineación OMITIDA (ya cubierta por
`FocusProfile`, la esfera TMI de CRAC no es compatible con Lorito);
Lucha Enloquecida (20 sub-perfiles, ~5.460 líneas) a sesión DEDICADA
aparte; los DSP restantes van al menú OPTAPE; protecciones de cierre
abordadas PRIMERO (GAP-038, cerrado).

**Florecedor de Cristhi Cosh, Antipestal de Lola Grillo, y Versión O
Tron: COMPLETOS** (backend + UI, GAP-039/040/041) — 3 de 5 DSP de CRAC
adaptados de punta a punta. Autoalineación OMITIDA (ya cubierta por
`FocusProfile`). Investigación web realizada para ambos DSP nuevos:
corrección real encontrada en el print-through de Antipestal (CRAC
usaba ms, la física real de cassette da 2.6-3.3 SEGUNDOS — corregido);
los anchos de banda de O Tron (AM 5kHz, onda corta 300-3.8kHz)
resultaron ya bien fundamentados en la práctica real documentada.
Leyendas compartidas "PREVI DSP"/"FNESP DSP" ahora agregan TODOS los
DSP de su categoría (`previ_dsp_active`/`fnesp_dsp_active`).

**LÍNEA DE TRABAJO DE DSP DE CRAC: COMPLETA.** Lucha Enloquecida
(GAP-042) — 20 sub-perfiles A-T, equivalencia exacta verificada
contra CRAC (diff=0.0 en los 20), integrado a `NRCoordinator` y a la
leyenda compartida "PREVI DSP", submenú dedicado en OPTAPE. Con esto,
los 4 DSP pedidos (Cristhi Cosh, Antipestal Lola Grillo, Versión O
Tron, Lucha Enloquecida) están completos — backend + UI. Autoalineación
quedó omitida por decisión del usuario (`FocusProfile` ya cubre esa
función).

**Versión: 0.08.002.** Cada uno debe llegar "recortado" — sin TMI,
sin métricas de PreviAnalyzer, sin SVG — con leyenda "PREVI DSP"
(alternando con "DOLBY B") o "FNESP DSP" (alternando con "DOLBY C"),
panel de deslizadores simple, y el patrón de desarme-al-detener-captura
construido desde cero junto con el primer DSP que se agregue.


## GAP-043/044 — MUSCLE EQ SAMIR (VITRITO) + banner de registro C.E.A

Diseño NUEVO para Lorito Aldhiro (no adaptado de CRAC): ecualizador en
caliente in-line con 6 tipos de filtro DF2T, transición suave por
rampa de coeficientes, 44 presets en 5 categorías (RIAA/NAB/CCIR con
frecuencias de esquina reales investigadas), integrado primero en la
cadena de `NRCoordinator`, con indicador "MUSC EQ" en la celda "DOLBY
S" (parpadeo simple / alternancia según Dolby S real).

Script `tools/insertar_banner_registro.py` (idempotente) inserta el
banner "LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A" — con el
concepto de una línea de cada módulo y una silueta de lorito como
huevo de pascua — en los **92 módulos** `.py` de `lorito_aldhiro/`
(excluidos los `__init__.py`). Dos bugs reales de la propia
herramienta encontrados y corregidos en el camino (anclaje `^` con
`re.match(pos)`; backslashes sin escapar en un docstring no crudo).

Paneles de Cristhi Cosh/Antipestal/Muscle Eq ahora sin redimensionado
(`setFixedSize`), igual criterio que el resto de Lorito desde CRAC.

**Versión: 0.09.002**, elevada explícitamente a pedido del usuario.


## GAP-045 — Descarolización de leyendas visibles

Reemplazada la terminología CRAC/"Carola" visible en pantalla por
terminología de Lorito Aldhiro: 8 leyendas del panel de duración de
cinta, 17 del panel de estado/bitácora, y una regla general aplicada
a diálogos de exportación/error y 2 etiquetas de animación. Exentas
las leyendas de Scrubs Morpher/Velocista (terminología universal
Finguered) y los prefijos internos invisibles de enrutamiento entre
paneles. Dos puntos quedaron marcados para confirmar con el usuario
(ver GAP-045): una leyenda no localizada, y dos etiquetas resueltas
con criterio propio.

**Versión: 0.09.003.**


## GAP-046 — Modularización de main_window.py + arborización total

`lorito_main_window.py` (6.376 líneas, 86 métodos) modularizado en
mixins por responsabilidad (núcleo de 706 líneas + 8 archivos), y los
31 módulos restantes en base plana (24 de `backend/`, 7 de
`frontend/`) arborizados en 9 subpaquetes nuevos por responsabilidad
— ambos mediante scripts dedicados (`tools/modularizar_main_window.py`,
`tools/arborizar_modulos_planos.py`). Tres defectos reales de los
propios scripts encontrados y corregidos: pérdida silenciosa de un
atributo de clase, un patrón de import no cubierto, y dos rutas
calculadas por `__file__` rotas al mover sus archivos (una de ellas
hacía que el cálculo de versión cayera en silencio al valor de
respaldo). Cobertura de banners: 100/100 módulos. `backend/` queda
con 0 archivos en base plana; `frontend/` con 1 (el núcleo de
main_window, exento a propósito).

**Versión: 0.09.004.**
