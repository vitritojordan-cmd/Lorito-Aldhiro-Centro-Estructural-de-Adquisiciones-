# EXPORT_CONTRACT.md — contrato del motor de exportación streaming

Revisión de la Orden Golden de Exportación (EX-01…EX-14, pruebas
EX-T01…EX-T16), Lorito Aldhiro 0.11.001. Sustituye la versión de la Fase 16,
que declaraba el streaming "no integrado a la GUI". **Hoy es la única ruta.**

Código: `backend/export_streaming/` (`lorito_export_service.py`,
`lorito_export_session.py`, `lorito_atomic_finalizer.py`,
`lorito_segment_provider.py`, `lorito_wav_encoder.py`,
`lorito_ffmpeg_stream_encoder.py`, `lorito_normalization_streaming.py`).
GUI: `frontend/main_window/lorito_mw_export.py`.
Pruebas: `tests/test_export_golden.py` (33 casos) y la batería streaming
existente.

## 1. Flujo único (EX-01, EX-06)

```
GUI (worker, no bloquea) ─► ExportRequest (inmutable)
                           └► ExportService.run()
                                ├─ preflight: inventario de segmentos, formato, codec
                                ├─ NormalizationPlan (análisis acotado, 2 pasadas)
                                └─ ExportSession ─► AtomicFinalizer ─► archivo final
                                                                    ├─ .sha256 (sidecar)
                                                                    └─ .manifest.json
```

`_build_export_array`, `lorito_exporters.py` (`_EXPORTERS`),
`USE_STREAMING_EXPORT` y la normalización sobre un array global quedan
**eliminados**. Un escaneo estático basado en AST (EX-T15) falla si
reaparece cualquier referencia productiva.

## 2. Garantías

1. **Memoria O(block_frames + estado DSP)**, independiente de la duración
   (EX-02). Ningún componente materializa la sesión.
2. **Preflight determinista** (EX-03, EX-04, EX-07). Un segmento ausente,
   vacío, truncado o con rate/canales/ancho distinto aborta antes del primer
   bloque con un error tipificado (`FormatMismatchError`, `SegmentReadError`).
   No hay omisión silenciosa ni downmix implícito. Si el codec no está
   disponible, se aborta con `CodecUnavailableError`.
3. **Normalización por plan** (EX-05, EX-11). `plan_normalization()` resuelve
   las más de 20 etiquetas de la GUI a un plan de dos pasadas (medir y
   aplicar) con estadísticas acotadas. Una etiqueta desconocida es un error
   tipificado, nunca un "sin normalizar" silencioso.
4. **Finalización atómica y durable** (EX-08, EX-09). Etapas del
   `AtomicFinalizer` (el informe registra `stage`):
   `encode` → `.partial` → `fsync` del parcial → `validate` (lector
   independiente) → `accounting` (frames) → `checksum` (SHA-256 en streaming)
   → `rename` (`os.replace`) → `dir_fsync` → `sidecar` (escritura atómica)
   → `reread` (relectura post-publicación del archivo **final** y comparación
   de SHA-256) → `done`. `sha256_reread_ok`, `sidecar_ok` y `durability`
   salen de lo comprobado, no de lo supuesto. Un rename es atómico pero no
   durable sin el fsync del directorio (REFERENCIAS §1.4, `durable_rename`
   de PostgreSQL).
5. **ffmpeg seguro** (EX-10):
   - `stdout` va a DEVNULL y `stderr` se drena en un hilo hacia un deque
     acotado, sin deadlock con stderr voluminoso.
   - Ciclo de vida terminate → kill → wait, sin procesos huérfanos.
   - Un código de salida distinto de cero aborta. FLAC acepta `bit_depth`
     16/24 (`-sample_fmt`).
   - El decodificador de validación corre con `-nostdin` y stdin=DEVNULL;
     un temporizador lo mata si vence el plazo. Antes heredaba el stdin del
     padre y podía quedar bloqueado para siempre (hallado al correr la
     batería en segundo plano).
   - Los códecs sin pérdida comparan los frames decodificados con
     `ffprobe`.
6. **Cancelación** (EX-T11): se comprueba en cada bloque y en cada etapa. Una
   exportación cancelada nunca publica nada y limpia el `.partial`
   (`status=CANCELLED`).
7. **Clasificación separada de la archivística** (EX-12):
   - `ARCHIVAL_SAFE`: copia bit-exacta verificada de una sesión
     `ARCHIVAL_SAFE`.
   - `DERIVED`: cualquier transformación (normalización, velocidad, codec
     con pérdida).
   - `NOT_ELIGIBLE`: fuente no segura.
   La clase va al manifiesto y al texto de especificación.
8. **Progreso por frames** (EX-13), no por tamaño de archivo.
9. **Huérfanos** (EX-T14): `cleanup_orphans()` elimina `.partial` y sidecars
   sin su archivo final, sin tocar nunca un final válido anterior.
10. **Manifiesto** `.manifest.json`: solicitud, plan, codec, frames,
    SHA-256, clase y metadatos (serializados con `default=str`). Si falla
    el manifiesto se registra en `manifest_error`; no se "despublica" un
    final ya verificado.
11. **WAV**: PCM_16/24 bit-exacto sin DSP, `FLOAT` (format tag 3) y RF64
    automático por encima del límite RIFF. Un subtipo desconocido es un
    error. `parse_riff_header` valida la cabecera de forma independiente.

## 3. Lo que este entorno no demuestra

Exportaciones reales de 1 a 50 h con medición de RSS en hardware de
destino, matrices completas de codecs con decodificadores de referencia
externos a ffmpeg, y la escucha. EX-T01 se cubre con una sesión sintética
de muchos bloques y la medición de memoria acotada; EX-T16 (entorno limpio
y dependencias fijadas) se cubre con `requirements.lock.txt` y el manifiesto
de release.
