# HISTORICO_VERSION_CRAC.md — changelog heredado del monolito CRAC
pre-bifurcación (extraído de `lorito_version.py`, GAP-034/Fase 15)

Este archivo contenía ~946 líneas de comentarios de CHANGELOG del
monolito CRAC original (`aecct2_v22_55.py` y anteriores), embebidos
directamente en `lorito_aldhiro/backend/lorito_version.py` desde la
bifurcación. Python nunca ejecuta comentarios — este bloque era
100% inerte, y su información ya está duplicada (para todo lo
posterior a la bifurcación) por `/CHANGELOG.md` + `/gaps/GAP-NNN.md`,
el mecanismo real que `_count_changelog_revisions()` usa para
calcular la versión.

Se conserva aquí como referencia histórica del desarrollo de CRAC
antes de la bifurcación (Fase 15 — higiene del release, GAP-034),
en vez de borrarlo directamente.

---


══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.55 — FIX-SCRUB-SEEK-RESUME
 Fecha: 2026-05-26
 Tipo: FIX — scrub seek no reanudaba desde la posición correcta

 BUGS corregidos (cuatro comportamientos defectuosos del CAROLALDHIRA ESCANEADOR):

 BUG 1 — Stop → Play retornaba al inicio en lugar de reanudar
 ─────────────────────────────────────────────────────────────
 Al detener manualmente (un clic en STOP o Space), el scrub quedaba
 visualmente en la posición correcta, pero al dar Play nuevamente la
 reproducción arrancaba desde 0 en lugar de desde donde se detuvo.

 CAUSA: _on_play_done_signal() hacía scrub.setValue(0) y
 waveform.setPlayPos(0.0) incondicionalmente al recibir el signal de fin
 de reproducción. Cuando stop_all() detenía manualmente y el thread del
 player terminaba con lag, el signal tardío disparaba _on_play_done_signal
 que reseteaba el scrub a 0 y pisaba el _scrub_parked_offset guardado.

 FIX: _on_play_done_signal() evalúa src_pos del player al terminar:
   · Si src_pos >= 99.5% del total (fin natural de pista) → scrub a 0,
     _scrub_parked_offset = None. El próximo Play arranca desde el inicio.
   · Si src_pos < 99.5% (stop externo con lag) → preservar posición actual
     del scrub. _scrub_parked_offset sincronizado con scrub._value.

 BUG 2 — Drag del scrub estando detenido → Play retornaba al inicio
 ────────────────────────────────────────────────────────────────────
 Al arrastrar el scrub a cualquier punto con la reproducción detenida y
 luego dar Play, la reproducción arrancaba desde 0.

 CAUSA: misma que BUG 1 — el signal tardío de play_done pisaba
 _scrub_parked_offset incluso después de que el usuario había arrastrado
 el scrub a una nueva posición. Cubierto por el mismo FIX.

 BUG 3 — Tecla E/e no implementada (reset al inicio)
 ─────────────────────────────────────────────────────
 El documento de especificación C.R.A.C define la tecla E/e como
 equivalente al doble clic en STOP: detiene la reproducción y retorna
 el scrub al inicio (posición 0). La tecla no existía en el código.

 FIX: Se introduce _scrub_reset_to_start() que centraliza la lógica de
 reset-a-inicio. Registrado como QShortcut "E" y como Key_E en
 keyPressEvent (respaldo). Refactorizado _toggle_play_stop (doble Space)
 para llamar a este mismo método — comportamiento idéntico desde los tres
 puntos de entrada: E, doble Space, doble clic en ScrubBarPlay.

 BUG 4 — Doble clic en botón ■ STOP no tenía efecto (FIX-STOP-DOUBLE-CLICK)
 ──────────────────────────────────────────────────────────────────────────────
 C.R.A.C especifica que doble clic en el botón ■ STOP equivale a la tecla
 E/e: detiene la reproducción y retorna el scrub al inicio (posición 0).
 Sin embargo btn_stop era un QPushButton estándar que no distingue simple
 de doble clic — mouseDoubleClickEvent nunca se implementó.

 CAUSA: btn_stop = QPushButton estándar; clicked() dispara en cada clic
 individual (incluido el primero del doble), pero mouseDoubleClickEvent()
 no existía → el doble clic llamaba stop_all() dos veces sin reset al inicio.

 FIX: Se introduce DoubleClickButton (subclase de QPushButton) con el
 atributo onDoubleClick: Callable. btn_stop se instancia como
 DoubleClickButton; su onDoubleClick apunta a _scrub_reset_to_start().
 El clicked() del primer clic del par sigue disparando stop_all() normal;
 el mouseDoubleClickEvent del segundo clic invoca el reset al inicio.

 COMPORTAMIENTO FINAL ESPECIFICADO:
   · Un clic STOP / Space → scrub queda en posición actual.
     Siguiente Play reanuda exactamente desde ese punto.
   · Drag del scrub (detenido) → Play → arranca desde donde se arrastró.
   · Doble clic STOP / doble Space / tecla E → scrub retorna a 0.
     Siguiente Play arranca desde el inicio de la señal.
   · Fin natural de pista → scrub retorna a 0 automáticamente.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.54 — FIX-CLOSE-RECOVERY
 Fecha: 2026-05-25
 Tipo: FIX — al cerrar tras recovery no aparecia CierreAbruptoDialog

 BUG: Al abrir el programa con un archivo recuperado (crash real o cierre
 limpio con "No") y cerrar sin haber grabado nada nuevo, la interfaz no
 mostraba el dialogo CierreAbruptoDialog que pregunta si guardar o descartar.
 El programa cerraba en silencio, perdiendo el archivo recuperado.

 CAUSA RAIZ: La condicion de closeEvent para mostrar el dialogo era:
   _hay_grabacion = bool(
       self._disk_tmp_path
       and os.path.exists(self._disk_tmp_path)
       and _status.frames_written > 0   ← FALLO
   )
 _status.frames_written es un contador acumulado de la sesion de grabacion
 activa. En una sesion recuperada donde no se grabo nada nuevo, este contador
 es siempre 0 aunque el archivo tmp exista con horas de audio. La condicion
 fallaba y el cierre ocurria por el path "sin grabacion" sin consultar al usuario.

 FIX: Reemplazar la condicion por self._has_audio(), que verifica unicamente
 que el archivo tmp exista en disco y tenga contenido valido (>512 bytes).
 Este metodo ya era usado correctamente en _check_crash_recovery(),
 _check_informacion_patrimonial() y otros puntos del arranque. Ahora cierre
 y arranque usan el mismo criterio de "hay audio" — consistencia total.

 CASOS CUBIERTOS:
   · Sesion de crash real recuperada → cerrar → aparece CierreAbruptoDialog ✓
   · Sesion de guardado limpio ("No") recuperada → cerrar → idem ✓
   · Sesion grabada en esta ejecucion → comportamiento sin cambio ✓
   · Sin audio (arranque limpio) → comportamiento sin cambio ✓
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.53 — FIX-EGL-DETECT
 Fecha: 2026-05-25
 Tipo: FIX — error de arranque "Failed to load client buffer integration: shm"

 BUG: En sistemas con libwayland-egl presente (KDE Plasma Wayland, GNOME
 Wayland, Weston), Qt reportaba al arrancar:
   qt.qpa.wayland: Failed to load client buffer integration: "shm"
   qt.qpa.wayland: Available client buffer integrations: QList("wayland-egl")
   Warning: fallback to QtQuick software backend.

 CAUSA: v0.22.51 introdujo QT_WAYLAND_CLIENT_BUFFER_INTEGRATION=shm para
 garantizar compatibilidad con compositores wlroots sin EGL. Sin embargo,
 en sistemas que SI tienen wayland-egl, forzar "shm" hace que Qt falle
 al cargar el backend y caiga en software rendering (QtQuick software),
 degradando el rendimiento grafico.

 FIX: Eliminar la linea setdefault("QT_WAYLAND_CLIENT_BUFFER_INTEGRATION", "shm").
 Qt detecta automaticamente la integracion disponible: usa wayland-egl si
 esta presente, y cae a shm solo si EGL no esta disponible. Este es el
 comportamiento correcto y universal para todos los compositores Wayland.
 El fix de thread-safety del SIGSEGV (v0.22.51) NO depende de SHM —
 la seguridad viene de que ningun hilo no-GUI llama update()/repaint().
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.52 — FIX-VUMETERS-FROZEN
 Fecha: 2026-05-25
 Tipo: FIX — VU meters de grabación y reproducción congelados en ejecución

 BUG: Los VUBar (vu_rec / vu_play) se congelaban visualmente durante el
 funcionamiento normal. Solo se actualizaban al minimizar/maximizar la ventana
 (resize forzado por el sistema operativo).

 CAUSA RAÍZ: Doble omisión de update():
   1. VUBar.setValues() NO llama update() por diseño (thread-safety Wayland).
      El repaint se delegó a _tick_vu_redraw() y _tick_cassette().
   2. _tick_cassette() llama setValues()/decay() pero NUNCA llama update()
      sobre vu_rec ni vu_play después de setValues(). decay() sí incluye
      su propio update(), pero setValues() no — quedando los datos
      actualizados sin repintar el widget.
   3. _tick_vu_redraw() solo hacía update() del waveform; ignoraba
      completamente vu_rec y vu_play.

 FIX 1 — _tick_cassette(): añadir self.vu_rec.update() / self.vu_play.update()
   inmediatamente después de setValues() en ambas ramas (rec activo y play activo).
   Seguro: _tick_cassette() siempre corre en el GUI thread (QTimer main thread).

 FIX 2 — _tick_vu_redraw(): añadir update() de vu_rec y vu_play como
   respaldo adicional a 15 Hz, cubriendo el caso en que _tick_cassette
   no haya corrido (condición de carrera entre los dos timers).
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.51 — WAYLAND-NATIVE-FULL
 Fecha: 2026-05-24
 Tipo: FIX/OPT — soporte Wayland nativo completo; eliminación de dependencias
       XCB/XWayland; corrección de SIGSEGV en QWaylandShmBackingStore;
       thread-safety total en actualización visual.

 ── Cambios de entorno (antes de QApplication) ───────────────────────────────
 · QT_WAYLAND_RECONNECT eliminado (env var ficticia sin efecto en Qt6).
 · QT_QPA_WAYLAND_GL_CONFIG eliminado (env var ficticia).
 · QT_WAYLAND_CLIENT_BUFFER_INTEGRATION=shm añadido: fuerza SHM buffer
   compatible con wlroots, KWin y Mutter sin dependencia de EGL.
 · QT_WAYLAND_FORCE_DPI=96 añadido: inhibe escalado DPI doble.
 · HiDPI PassThrough movido fuera del bloque _is_wayland: aplica también en
   X11. Siempre se configura antes de QApplication.

 ── Thread-safety GUI (SIGSEGV QWaylandShmBackingStore) ─────────────────────
 · WaveformDisplay.updateFromBuffer(): eliminado self.update() inseguro.
   Reemplazado por self._pending_update = True. El repaint real lo emite
   _tick_vu_redraw() desde el GUI timer (main thread). Elimina el SIGSEGV
   cuando updateFromBuffer era llamado desde _tick() que a su vez ejecutaba
   update() justo cuando el compositor Wayland actualizaba el backing store.
 · WaveformDisplay._update_from_file(): eliminados todos los self.update()
   (incluyendo early-returns). Este método corre en el worker thread
   _WaveformUpdateWorker — cualquier update() desde allí es una race condition
   contra QWaylandShmBackingStore::finalizeBackBuffer.
 · WaveformDisplay.updateFromRaw(): fast-paths vacíos ahora usan
   _pending_update = True en lugar de self.update().
 · WaveformDisplay.clearWave(): self.update() conservado y documentado
   como seguro (siempre llamado desde el GUI thread).

 ── Optimización de render ───────────────────────────────────────────────────
 · Eliminado __import__('PySide6.QtGui', fromlist=['QPainterPath']) en
   VUBar._draw_bar() paintEvent hotpath. QPainterPath ya está importado a
   nivel de módulo — el __import__ en cada frame añadía ~5µs innecesarios.

 ── Compatibilidad de compositores ──────────────────────────────────────────
 · wlroots (sway, labwc, river): QT_WAYLAND_CLIENT_BUFFER_INTEGRATION=shm
   garantiza compatibilidad sin necesidad de libwayland-egl.
 · KDE Plasma Wayland: QT_WAYLAND_DISABLE_WINDOWDECORATION=1 previene
   doble borde entre decoraciones Qt y KWin.
 · GNOME Wayland: ídem con Mutter.
 · PipeWire/PulseAudio/JACK: sin cambios en el pipeline de audio; los fixes
   son exclusivamente de la capa gráfica Qt6.
══════════════════════════════════════════════════════════════════════════════


══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.50 — FIX-SCRUB-PLAY-FROM-POS
 Fecha: 2026-05-24
 Tipo: FIX (reproducción siempre arranca desde la posición del scrub)

 CONTROLES AFECTADOS:
   · CAROLALDHIRA ESCANEADOR (ScrubBarPlay): barra horizontal de posición
     de reproducción — escanea la señal de izquierda a derecha y viceversa.
   · Línea de posición del panel de forma de onda (WaveformWidget idle_scrub):
     línea vertical sincronizada que se mueve con el drag sobre la onda.
   Estos dos controles comparten onSeek=_scrub_seek_realtime y
   onRelease=_scrub_released, y por tanto el mismo _scrub_parked_offset.

 BUG 1 — Scrub → Play arranca desde 0 (no desde la posición del scrub)
 ────────────────────────────────────────────────────────────────────────
 FLUJO ROTO:
   1. Sin reproducción activa, usuario mueve ScrubBarPlay a posición X.
      → _scrub_released guarda _scrub_parked_offset = X * total_secs.
      → scrub._value = X.  waveform._play_pos = X (idle_scrub).
   2. Usuario pulsa Play (btn_play o Space).
      → play_audio(offset=None).
      → _playing=False y _scrub_parked_offset is not None
         → frac = X / total_secs → start_frame = X * total_frames.  ✓
      → _scrub_parked_offset = None  (consumido).
   3. _on_seek_ready() arranca el StreamingPlayer desde start_frame.
      → self._play_offset = frac * total_secs  ✓
      → self.waveform.setMode("playback")
      → _waveform_worker.submit() → recalcula la forma de onda.
      → NO se llama scrub.setValue(frac) ni waveform.setPlayPos(frac).
   4. _on_waveform_ready() redibuja el waveform: _dirty=True, update().
      → El waveform está en modo "playback" pero _play_pos sigue en X
        del idle_scrub. Visualmente parece bien, pero scrub._value no
        fue confirmado → en el primer tick de 24 Hz (~42 ms), el tick
        lee player.src_pos ≈ 0 (el player acaba de arrancar, src_pos
        aún no avanzó un chunk completo) → scrub.setValue(~0) →
        el scrub visual "salta" a 0 antes de avanzar desde X.

 CAUSA RAÍZ:
   En _on_seek_ready, src_pos del player comienza en 0.0 (frame absoluto
   = start_frame, pero src_pos es relativo al inicio del player y se
   actualiza en el primer callback de audio, ~5-20 ms después). El tick
   de 24 Hz lee src_pos antes del primer callback → calcula pos ≈ 0 →
   scrub va momentáneamente a 0, luego avanza desde X. Visualmente el
   scrub "parpadea" en 0 o arranca desde 0 durante un frame o dos.

 FIX-SCRUB-PLAY-FROM-POS A (BUG 1):
   En _on_seek_ready(), inmediatamente después de arrancar el player,
   llamar scrub.setValue(frac) y waveform.setPlayPos(frac) con la
   fracción de inicio calculada. Esto ancla visualmente el scrub y la
   línea del waveform en la posición correcta desde el primer frame,
   sin esperar al primer tick de 24 Hz.

 BUG 2 — Línea del waveform no sigue al CAROLALDHIRA ESCANEADOR en idle
 ────────────────────────────────────────────────────────────────────────
 FLUJO ROTO:
   1. Sin reproducción, usuario mueve ScrubBarPlay (ESCANEADOR) a X.
      → _scrub_seek_realtime: waveform.setPlayPos(X) y waveform.setMode
        ("idle_scrub") solo si waveform._mode == "idle".
      → Si waveform._mode ya es "idle_scrub" (usuario ya había arrastrado
        antes), la condición `if self.waveform._mode in ("idle",):` es
        False → waveform NO entra en idle_scrub ni actualiza _play_pos.
   2. La línea del waveform se queda en la última posición del drag
      anterior, desincronizada del ESCANEADOR.

 FIX-SCRUB-PLAY-FROM-POS B (BUG 2):
   En _scrub_seek_realtime, cambiar la condición de activación del modo
   idle_scrub de `if mode == "idle"` a `if mode in ("idle", "idle_scrub")`.
   Así el waveform actualiza _play_pos en CADA movimiento del ESCANEADOR,
   incluso si ya estaba en idle_scrub por un drag anterior.
   La llamada waveform.setPlayPos(pct) ya existe en _scrub_seek_realtime
   (primera línea del método), pero setPlayPos solo marca _pending_update
   si la diferencia > 0.001 — es correcto. El problema era que
   waveform._mode no pasaba a "idle_scrub" en el segundo drag, por lo
   que paintEvent no dibujaba la línea de posición.

 BUG 3 — Play con waveform-scrub (línea) arranca desde 0
 ────────────────────────────────────────────────────────
 FLUJO ROTO:
   1. Sin reproducción, usuario arrastra la línea del waveform a X.
      → mousePressEvent del waveform: waveform._mode = "idle_scrub",
        waveform._play_pos = X. onSeek(X) → _scrub_seek_realtime(X).
      → _scrub_seek_realtime: waveform.setPlayPos(X) ✓.
        self._scrub_parked_offset = X * total_secs ✓.
        self.scrub.setValue(X) ✓ — ESCANEADOR se sincroniza.
      → mouseReleaseEvent: onRelease(X) → _scrub_released(X).
      → _scrub_released: _scrub_parked_offset = X * total_secs ✓.
        scrub.setValue(X) ✓. waveform.setPlayPos(X) ✓.
   2. Usuario pulsa Play.
      → play_audio() → _scrub_parked_offset consumido → start_frame=X ✓.
      → _on_seek_ready: arranca player desde X.
      → BUG 1 aplica aquí también: scrub salta a ~0 en el primer tick.
   FIX: aplicar FIX A (_on_seek_ready con setValue/setPlayPos) cubre
   también este flujo. No se necesita fix adicional.

══════════════════════════════════════════════════════════════════════════════
                       FIX-OVERFLOW-BLINK-SYNC · FIX-HUB-FLIP-RESET
 Fecha: 2026-05-24
 Tipo: FIX (4 correcciones — etapa de duración de cinta C-60 y C-90)

 ── FIX 1 (FIX-DEACTIVATE-TOL-FLIP): Volteo Lado B al desactivar pausa
    dentro de ventana de tolerancia — aplica a C-60 y C-90 ────────────────

 ESCENARIO:
   1. Grabación entra en zona de tolerancia del Lado A [flip_min … flip_max]
      (C-60: [28 min, 33 min] / C-90: [43 min, 48 min]).
   2. Silencio ≥ 5 s → _activate_silence_autopause() → on_flip_side_b()
      → _flip_pending=True en el TapeLogPanel.
   3. Regresa señal → _deactivate_silence_autopause().
   4. BUG: el motor CRACMotorV3 no confirmó reset (query_counter_reset()=False)
      → ni _phase="B", ni reset del cuentavueltas. Volteo bloqueado.

 FIX: En _deactivate_silence_autopause(), si _flip_pending sigue True tras
 notify_autopause_deactivated() + sincronización, ejecutar volteo de emergencia:
 _flip_pending=False, _flip_done=True, _phase="B", reset contador + ángulos.
 El loop abarca tape_c60 y tape_c90 — C-90 cubierto por el mismo código.

 ── FIX 2 (FIX-DEACTIVATE-STOP-B): Detención de emergencia Lado B ────────

 ESCENARIO: Al fin del Lado B, el motor CRACMotorV3 marca _stop_triggered=True
 y debería llamar on_auto_stop(). Si la pausa automática se desactiva antes de
 que el motor procese su tick (misma desincronía que FIX 1 pero para Lado B),
 on_auto_stop() nunca se llama y la grabación no se detiene.

 FIX: Bloque adicional en _deactivate_silence_autopause() que, después del
 loop de volteo, verifica si algún panel activo (C-60 o C-90) tiene
 _stop_triggered=True y _phase="B". En ese caso llama on_auto_stop() vía
 QTimer.singleShot(0) para no interrumpir el flujo de reanudación del motor.

 ── FIX 3 (FIX-OVERFLOW-BLINK-SYNC): Parpadeo "TU CINTA ES MUY LARGA... UPS!!"
    sincronizado con "¡OYE, ¿DÓNDE TE HAS METIDO?!" ─────────────────────

 BUG: _wobble_blink_vis se alternaba en cada tick de update_state (~15 Hz →
 ~7.5 Hz): parpadeo excesivamente rápido, visualmente distinto al de la
 leyenda de autopause (480 ms → ~1.04 Hz).

 FIX:
   · Se elimina el toggle de _wobble_blink_vis de update_state.
   · Nuevo método tick_overflow_blink() en TapeLogPanel: alterna _wobble_blink_vis
     solo si _counter_overflow=True, llamado por timers de 480 ms.
   · Nuevo timer _overflow_blink_timer (QTimer, 480 ms) en LoritoAldhiroStudio:
     arranca cuando any(_counter_overflow) en el tick de animación,
     se detiene cuando ningún panel tiene overflow.
   · _on_carola_waiting_blink() también llama tick_overflow_blink() por si
     overflow y autopause coinciden (coexistencia sin duplicación).
   · _wobble_phase (sinusoide de tambaleo físico) sigue avanzando en update_state
     en cada tick — solo el parpadeo de color queda sincronizado.

 ── FIX 4 (FIX-HUB-FLIP-RESET): Hubs vuelven a posición de inicio al voltear
    al Lado B en C-60 y C-90 ──────────────────────────────────────────────

 BUG: Al voltear de Lado A → Lado B, _angle1 y _angle2 conservaban los valores
 acumulados del Lado A. El cassette volteado físicamente debe empezar con el
 hub izquierdo lleno (radio máx) y el derecho vacío (radio mín), igual que al
 inicio de Lado A. Los ángulos acumulados del Lado A no tienen relación con
 la posición angular inicial del Lado B (son caras opuestas del cassette).

 FIX: En todos los bloques de reset al voltear (update_state query_counter_reset,
 _deactivate query_counter_reset, _deactivate TOL-FLIP emergencia, fallback
 legado), añadir _angle1=0.0 y _angle2=0.0. La animación de los hubs arranca
 desde posición inicial en el Lado B, igual que al inicio de una grabación.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.47 — FIX-SCRUB-CRAC-PARK
 Fecha: 2026-05-24
 Tipo: FIX (lógica de scrub en estado parado — C.R.A.C)

 ── FIX 1: Mover el scrub estando parado inicia reproducción (incorrecto) ───
 BUG: Al arrastrar el CAROLALDHIRA ESCANEADOR (ScrubBarPlay) o el scrub de
 la forma de onda estando detenido (sin Play activo), la reproducción se
 iniciaba automáticamente al soltar el ratón. El C.R.A.C especifica que en
 estado parado el scrub debe comportarse como un marcador de posición de
 inicio: posiciona el punto, pero NO arranca reproducción. Al pulsar Play,
 la reproducción debe comenzar exactamente donde quedó el scrub.

 CAUSAS:
   · _scrub_seek_realtime(): cuando no hay player activo, disparaba
     _scrub_timer.start(120) → al timeout _scrub_commit() llamaba play_audio().
   · _scrub_released(): cuando no hay player activo, llamaba play_audio()
     directamente en el mouseUp.
   · _scrub_commit(): llamaba play_audio() como fallback.

 FIX:
   · _scrub_seek_realtime() — rama "sin player": ya no dispara _scrub_timer.
     Solo guarda _scrub_parked_offset y sincroniza scrub.setValue(pct).
   · _scrub_released() — rama "sin player": solo guarda _scrub_parked_offset
     + actualiza scrub.setValue y waveform.setPlayPos. NO llama play_audio().
   · _scrub_commit(): queda como guarda de seguridad vacía (solo limpia
     _scrub_pending). Ya no llama play_audio() en ningún caso.
   · play_audio() ya consumía _scrub_parked_offset al arrancar (v0.22.41);
     esa lógica no cambia — Play arranca desde el punto de parking.

 ── FIX 2: Waveform-scrub no funciona en estado parado (FIX-SCRUB-CRAC-PARK) ─
 BUG: El scrub de la forma de onda (drag sobre la línea de reproducción,
 v0.22.45) solo se activaba cuando el modo era "playback". En estado parado
 ("idle") el drag no hacía nada: ni movía el marcador ni guardaba posición.
 El C.R.A.C especifica que tanto el CAROLALDHIRA ESCANEADOR como el drag
 sobre la forma de onda deben comportarse igual en estado parado.

 FIX: Se introduce el modo interno "idle_scrub" en WaveformDisplay:
   · mousePressEvent: se activa también cuando _mode es "idle" o "idle_scrub"
     (no solo "playback"). Al iniciar el drag en estado parado, el modo pasa
     a "idle_scrub" para que paintEvent dibuje la línea de posición.
   · mouseMoveEvent: actualiza _play_pos y solicita repaint en "idle_scrub".
   · mouseReleaseEvent: deja el modo en "idle_scrub" (línea visible) y llama
     onRelease → _scrub_released → guarda _scrub_parked_offset.
   · paintEvent: en "idle_scrub" dibuja una línea punteada (Qt.DashLine) con
     color accent en alpha 130, visualmente distinta de la línea sólida de
     reproducción activa, indicando que es el marcador de inicio.
   · setMode(): transición "idle_scrub" → "idle"/"playback"/"rec" cuando el
     sistema cambia el estado externamente (Play pulsado → "playback",
     Stop → "idle"). La línea punteada desaparece al arrancar o detener.
   · _scrub_seek_realtime(): cuando no hay player activo, activa "idle_scrub"
     también cuando el drag viene del CAROLALDHIRA ESCANEADOR, para que ambos
     scrubs sean visualmente coherentes.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.46 — FIX-OVERFLOW-WRAP-PERSIST · FIX-FLIP-B-DEACTIVATE
 Fecha: 2026-05-24
 Tipo: FIX (2 correcciones — cuentavueltas overflow tras wrap y volteo Lado B)

 ── FIX 1: Leyenda/tambaleo/parpadeo se apagan cuando el cuentavueltas retorna
           a 000 tras superar 999 (FIX-OVERFLOW-WRAP-PERSIST) ─────────────────
 BUG: Cuando la cinta era más larga que la duración nominal del segmento
 (Lado A o Lado B) el cuentavueltas llegaba a 999 y luego hacía wrap a 000
 (FIX-COUNTER-WRAP-C6090, v0.22.44). Al hacer wrap, self._counter pasaba a
 valer 0 (o cualquier valor < 999). La condición de activación del overflow
 era `if self._counter >= 999`, que resultaba False → el else limpiaba
 _counter_overflow, _wobble_phase y _wobble_blink_vis. Resultado: la leyenda
 "TU CINTA ES MUY LARGA... UPS!!", los hubs tambaleantes y el parpadeo
 desaparecían justo cuando el contador retornaba a 000 y el nuevo conteo
 comenzaba, aunque la cinta seguía siendo más larga que el segmento.
 CAUSA: La condición basada en self._counter (valor visual tras módulo 1000)
 no refleja si la cinta sigue desbordada. El indicador correcto es
 _t_norm_raw > 1.0, que está calculado justo antes del bloque.
 FIX: Reemplazar `if self._counter >= 999` por `if _t_norm_raw > 1.0`.
 Ahora el overflow se mantiene activo durante todo el tiempo que el segmento
 esté desbordado (_t_norm_raw > 1.0), independientemente del valor visual
 del contador (que puede ser 000–999 con módulo). El wobble y parpadeo
 continúan sin interrupción en cada vuelta del cuentavueltas.

 ── FIX 2: Al desactivar la pausa automática, no voltea al Lado B cuando la
           pausa fue forzada por tope flip_max (FIX-FLIP-B-DEACTIVATE) ──────
 BUG: Cuando el audio activo llegaba a flip_max (RUTA 2 de CRAC-MOTOR-v2),
 update_state activaba _forced_pause_active=True y _flip_pending=True, y
 disparaba on_flip_side_b (pausa forzada). Al detectar silencio en la pausa
 forzada (FIX-FORCED-PAUSE-ESCAPE, v0.22.44), update_state limpiaba
 _forced_pause_active=False en el tick que detectaba el silencio.
 Sin embargo, en ese mismo tick autopause_active seguía siendo True (la pausa
 continuaba activa), por lo que la condición de confirmación de volteo en
 update_state (not autopause_active + not _forced_pause_active + _flip_pending)
 nunca se satisfacía: `not autopause_active` era False.
 Cuando finalmente llegaba señal, _deactivate_silence_autopause se ejecutaba,
 pero allí el bloque de volteo comprobaba `getattr(_tp, "_flip_pending", False)`.
 Si update_state había limpiado _forced_pause_active en un tick previo pero
 _flip_pending seguía True, el volteo debería ejecutarse en _deactivate.
 No obstante, en algunos ticks la secuencia era:
   update_state(active=False, autopause=True):
     → _forced_pause_active ya False, _flip_pending True
     → condición de volteo: not True → NO voltea
   _deactivate → bloque de volteo: _flip_pending True → ¿ejecuta?
 El problema secundario: _forced_pause_active no se limpiaba en _deactivate
 ANTES de la verificación de _flip_pending (se limpiaba dentro del if), por
 lo que si _forced_pause_active aún era True en el momento de _deactivate,
 cualquier lógica adicional que lo comprobara quedaba bloqueada.
 FIX: En _deactivate_silence_autopause, limpiar _tp._forced_pause_active=False
 INCONDICIONALMENTE antes de comprobar _flip_pending. Al reanudar el motor,
 la pausa forzada no tiene sentido: si la señal regresó, la reanudación es
 definitiva. El volteo a Lado B se ejecuta si _flip_pending=True sin ninguna
 restricción adicional de _forced_pause_active.
 El bucle se refactoriza para usar `continue` en lugar de anidado profundo,
 mejorando la legibilidad y eliminando la posibilidad de omitir la limpieza
 de _forced_pause_active por condición de no-flip.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.45 — FIX-WAVEFORM-SCRUB-DRAG
 Fecha: 2026-05-24
 Tipo: FIX (1 corrección — scrub por arrastre sobre la pantalla de onda)

 ── FIX 1: La línea de playback en la forma de onda no respondía al ratón ─
 BUG: La línea vertical que atraviesa la pantalla de forma de onda indicaba
 la posición de reproducción visualmente, pero arrastrar el ratón sobre ella
 no movía el scrub. El único scrubber funcional era el widget
 CAROLALDHIRA ESCANEADOR (ScrubBarPlay) ubicado bajo la forma de onda.
 El C.R.A.C especifica que la línea que atraviesa la pantalla de onda también
 debe ser arrastrable con el ratón para mover el punto de reproducción.
 CAUSA: WaveformDisplay no implementaba mousePressEvent, mouseMoveEvent ni
 mouseReleaseEvent, ni tenía callbacks onSeek / onRelease.
 FIX: Se añaden a WaveformDisplay:
   · onSeek / onRelease: Callable opcionales (igual que ScrubBarPlay).
   · _wf_drag: flag de arrastre activo.
   · _wf_pct(x): convierte coordenada X a fracción 0..1.
   · mousePressEvent: activa _wf_drag solo si _mode == "playback" y onSeek
     está registrado; llama onSeek(pct) inmediatamente.
   · mouseMoveEvent: llama onSeek(pct) mientras _wf_drag sea True.
   · mouseReleaseEvent: desactiva _wf_drag, llama onRelease(pct).
 En LoritoAldhiroStudio, tras instanciar self.waveform, se asignan:
   self.waveform.onSeek    = self._scrub_seek_realtime
   self.waveform.onRelease = self._scrub_released
 El comportamiento es idéntico al ScrubBarPlay: seek interno durante el drag
 y consolidación con play_audio() al soltar, con sincronía del hub y el
 visor de cassette. El cursor cambia a SizeHorCursor durante el drag para
 indicar la interactividad al usuario.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.44 — FIX-COUNTER-WRAP-C6090 · FIX-OVERFLOW-RESET-FLIP
                       FIX-FORCED-PAUSE-ESCAPE · FIX-FLIP-B-GUARD
 Fecha: 2026-05-24
 Tipo: FIX (4 correcciones — cuentavueltas C-60/C-90 y lógica volteo Lado B)

 ── FIX 1: Cuentavueltas C-60/C-90 no retorna a 000 al llegar a 999 (FIX-COUNTER-WRAP-C6090) ─
 BUG: En modos C-60 y C-90, cuando el contador llegaba a 999 se clavaba allí.
 La leyenda "TU CINTA ES MUY LARGA... UPS!!" y el tambaleo se activaban, pero
 el visor nunca retornaba a 000 ni reiniciaba el conteo como especifica el C.R.A.C.
 CAUSA: `self._counter = min(999, int(_t_norm * 999))` clampea el valor a 999
 en cuanto _t_norm ≥ 1.0. El módulo 1000 nunca se aplicaba en este path
 (solo existía en el path OTROS). El surplus se registraba correctamente pero
 el visor quedaba estancado en 999.
 FIX: Cuando _t_norm_raw > 1.0 (desbordamiento real), calcular
 `self._counter = int(_t_norm_raw * 999) % 1000` para que el visor haga
 la vuelta 999→000 y siga contando. El flag _counter_overflow sigue activo
 mientras la cinta esté "larga" (_t_norm_raw > 1.0), manteniendo la leyenda
 y el tambaleo. Solo cuando el contador está en el rango normal (< 999) se
 limpia _counter_overflow. El incremento de surplus se calcula como antes.

 ── FIX 2: _counter_overflow no se limpia al voltear al Lado B (FIX-OVERFLOW-RESET-FLIP) ─
 BUG: Si el cuentavueltas desbordaba en el Lado A (cinta larga → 999+),
 al voltear al Lado B el flag _counter_overflow permanecía True. El visor
 seguía mostrando "TU CINTA ES MUY LARGA... UPS!!" y el tambaleo continuaba
 aunque el contador ya se había reseteado a 000 para el Lado B.
 FIX: En el bloque `if new_phase == "B":` de update_state(), añadir:
   self._counter_overflow  = False
   self._wobble_phase      = 0.0
   self._wobble_blink_vis  = True
 Así el inicio del Lado B comienza siempre con visor limpio.

 ── FIX 3: Pausa forzada por tope no conmuta a pausa-por-silencio (FIX-FORCED-PAUSE-ESCAPE) ─
 BUG: Cuando elapsed_secs >= flip_max con señal activa, el sistema forzaba
 auto-pausa (_flip_pending=True). El spec exige que al detectar silencio de
 "medio microsegundo" (prácticamente un tick), la pausa forzada conmute a
 pausa ordinaria por silencio, de modo que cuando regrese señal se desactive
 automáticamente y se voltee al Lado B.
 CAUSA: SILENCE_GUARD_ESCAPE_SECS = 1.0 s — el sistema esperaba 1 segundo
 de silencio antes de hacer la conmutación. Cualquier silencio < 1s no
 activaba _flip_pending_unlocked y la pausa forzada nunca se convertía en
 pausa ordinaria; la señal de regreso no podía voltear al Lado B.
 FIX: Bajar SILENCE_GUARD_ESCAPE_SECS a 0.0 s, de modo que el PRIMER tick
 silencioso (≥ 67ms) detectado mientras la pausa forzada está activa sea
 suficiente para armar _flip_pending_unlocked=True y convertir la pausa
 en pausa ordinaria. Cualquier tick de audio posterior activa el release
 (SILENCE_RELEASE_MIN_TICKS = 3 ticks ≈ 200ms) y voltea a Lado B.

 ── FIX 4: Volteo al Lado B no ocurre en _deactivate_silence_autopause (FIX-FLIP-B-GUARD) ─
 BUG: Cuando la auto-pausa se desactivaba por señal entrante, el volteo al
 Lado B en _deactivate_silence_autopause() actualizaba _tp._phase, _flip_done
 y llamaba al ITL, pero NO reseteaba _counter_overflow ni _wobble. Además,
 la lógica de volteo doble (update_state + _deactivate) podía causar que
 _counter_base no se actualizase correctamente.
 FIX: En el bloque de volteo de _deactivate_silence_autopause(), añadir
 el reset explícito de overflow igual que en update_state():
   _tp._counter_overflow = False
   _tp._wobble_phase     = 0.0
   _tp._wobble_blink_vis = True
 Y resetear _counter_surplus_a en ese punto para no contaminar el log de B.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.43 — FIX-SCRUB-DOUBLE-RESET · FIX-SCRUB-RECOVERY-INIT
 Fecha: 2026-05-24
 Tipo: FIX (2 correcciones — scrub doble-acción y estado inicial en recovery)

 ── FIX 1: Doble clic / doble Space retorna scrub al inicio (FIX-SCRUB-DOUBLE-RESET) ─
 BUG: El C.R.A.C especifica que dos clics de ratón sobre cualquier zona de la
 señal grabada, o dos pulsaciones de Space, deben retornar el scrub de
 reproducción al inicio (posición 0) de forma automática.
 Este comportamiento no estaba implementado:
   · ScrubBarPlay no tenía mouseDoubleClickEvent.
   · _toggle_play_stop() y keyPressEvent no distinguían doble pulsación.
 FIX:
   · ScrubBarPlay.mouseDoubleClickEvent(): resetea posición a 0.0, emite
     onRelease(0.0) para que _scrub_released arranque reproducción desde 0
     (o posicione el scrub en 0 si no había player activo).
   · _toggle_play_stop(): implementa detección de doble Space con timer de
     300 ms (_double_space_timer). Primera pulsación → comportamiento normal
     (play/stop). Segunda pulsación dentro de 300 ms → retorno al inicio:
     stop_all() + resetear scrub a 0 + _scrub_parked_offset = None.
   · Doble clic en ScrubBarPlay durante reproducción activa arranca desde 0.
   · Doble clic estando detenido posiciona el scrub en 0 listo para el Play.

 ── FIX 2: Scrub no inicializado tras recovery (FIX-SCRUB-RECOVERY-INIT) ──────
 BUG: Tras recuperar sesión de crash o cierre limpio, el scrub de reproducción
 podía quedar en un estado inconsistente: _scrub_parked_offset con un valor
 basura de sesión anterior, la línea de onda en modo incorrecto, o el thumb
 del scrub no reseteado a 0. Si el usuario pulsaba Play inmediatamente tras
 la recovery, play_audio() podía consumir un _scrub_parked_offset espurio.
 FIX: En _do_crash_recovery(), tras restaurar la GUI y antes de _sync_buttons():
   · _scrub_parked_offset = None (elimina cualquier offset de sesión anterior)
   · scrub.setValue(0.0) (thumb en inicio)
   · waveform.setPlayPos(0.0) (cursor en inicio)
   · waveform.setMode("idle") (asegurar modo ocioso — ya hacía setMode en otros
     paths pero no en el path de recovery directa)
 Los mismos 4 resets se aplican tanto en crash real como en cierre limpio
 (ambos pasan por _do_crash_recovery).
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.42 — FIX-SCRUB-STOPPED-PLAY · FIX-SCRUB-WAVEFORM-MARKER
 Fecha: 2026-05-24
 Tipo: FIX (2 correcciones — scrub en pausa)

 ── FIX 1: Mover scrub detenido no iniciaba reproducción (FIX-SCRUB-STOPPED-PLAY) ─
 BUG: En v0.22.41 se corrigió el reset al inicio, pero se dejó demasiado
 conservador: mover el scrub estando detenido ya no arrancaba la reproducción.
 El comportamiento esperado del C.R.A.C es que al arrastrar y soltar el scrub
 la reproducción arranque exactamente en el punto marcado.
 CAUSA: _scrub_released() y _scrub_commit() en v0.22.41 solo guardaban
 _scrub_parked_offset sin llamar a play_audio() cuando no había player activo.
 FIX:
   · _scrub_released(): cuando no hay player activo, llama play_audio(pct*secs)
     directamente con el offset exacto del punto soltado. Limpia
     _scrub_parked_offset antes de llamar para evitar doble-consumo.
   · _scrub_commit(): ídem — arranca play_audio(pct*secs) desde el punto
     donde el debounce disparó (comportamiento original restaurado).
   · El bug del "reinicio al inicio" ya está resuelto por stop_all() que
     preserva la posición del scrub en vez de resetearlo a 0 (v0.22.41).

 ── FIX 2: Línea de marca en vista de onda no se movía al arrastrar (FIX-SCRUB-WAVEFORM-MARKER) ─
 BUG: Al arrastrar el scrub de reproducción estando detenido, la línea de
 marca vertical en la vista de onda (WaveformDisplay) no se movía. La posición
 de la onda sí se actualizaba internamente (_play_pos) pero la línea no
 aparecía porque WaveformDisplay solo la dibuja cuando _mode == "playback".
 Estando detenido, el modo era "idle" → línea invisible → sin feedback visual.
 FIX: En _scrub_seek_realtime(), llamar self.waveform.setMode("playback")
 antes de setPlayPos() para que la línea de marca sea visible durante el drag,
 incluso cuando no hay reproducción activa. La vista de onda permanece en
 modo "playback" hasta que play_audio() la confirma o stop_all() la pone
 en "idle".
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.41 — FIX-SCRUB-PLAY-POS · FIX-MORPH-SPEED-SYNC · FIX-HUB-GHOST
 Fecha: 2026-05-24
 Tipo: FIX (4 correcciones — scrub, sincronía C.R.A.C, pops, hubs fantasma)

 ── FIX 1: Play inicia desde inicio en vez de la posición del scrub (FIX-SCRUB-PLAY-POS) ──
 BUG: Si el scrub de reproducción se movía estando detenido y luego se pulsaba
 Play, la reproducción comenzaba desde el inicio (frame 0) en lugar del punto
 marcado por el scrub.
 CAUSA: _scrub_released() y _scrub_commit() llamaban a play_audio() incluso
 cuando no había reproducción activa, arrancando el audio inmediatamente desde
 la posición del scrub. Luego, al pararse (manual o por fin de pista), stop_all()
 o _on_play_done_signal() hacían scrub.setValue(0) → el scrub volvía al inicio.
 Si el usuario pulsaba Play tras eso, play_audio(offset=None) leía scrub._value=0
 y arrancaba desde el inicio.
 FIX:
   · _scrub_released(): si no hay reproducción activa, NO llama play_audio().
     Solo actualiza _scrub_parked_offset con la posición marcada.
   · _scrub_commit(): ídem — sin auto-play si no se estaba reproduciendo.
   · play_audio(offset=None): si offset es None y no se estaba reproduciendo,
     usa _scrub_parked_offset como punto de inicio en lugar de scrub._value
     (que puede haber sido reseteado a 0 por stop_all). Limpia _scrub_parked_offset
     tras consumirlo para que el próximo Play sin scrub parta del inicio.
   · stop_all() y _on_play_done_signal(): preservan el valor del scrub en lugar
     de resetearlo a 0 cuando la parada no fue por fin de pista completa.
     Al terminar naturalmente la pista sí se resetea a 0.

 ── FIX 2: Scrub reproducción no sigue a morpher/velocidad (FIX-MORPH-SPEED-SYNC) ──
 BUG: Al mover los scrubs de morpher o velocidad de reproducción, el scrub de
 posición (barra de reproducción) y el cursor de la vista de onda no avanzaban
 en sincronía. El C.R.A.C exige que todos los scrubs sigan al ritmo de la cinta.
 CAUSA: La actualización del scrub de posición (scrub.setValue) y de la vista de
 onda (waveform.setPlayPos) solo ocurría en _tick_cassette() cuando _playing=True,
 pero este tick no corregía el avance adicional causado por ratio≠1.0 del morpher
 o del velocista: usaba src_pos/rate que ya refleja el avance real, así que en
 teoría sí debería estar correcto… pero los scrubs de morpher y velocidad tenían
 su propio valor de posición (pos en MorpherScrubBar, ratio en SpeedScrubBar) que
 NO se reflejaba visualmente en la barra de reproducción durante el drag.
 FIX:
   · En _on_speed_changed(): cuando _playing=True y dragging=True, actualizar
     scrub.setValue y waveform.setPlayPos con la posición actual del player.
   · En _on_morpher_changed(): ídem para drag y retorno elástico.
   · Esto garantiza que cualquier movimiento de morpher/velocidad provoque
     actualización visual inmediata del scrub de posición y la onda.

 ── FIX 3: Pops severos con scrubs morpher/velocidad (FIX-SCRUB-POP-GUARD) ─────
 BUG: Al jugar continuamente con los scrubs de morpher y velocidad aparecían
 pops audibles severos, especialmente al cruzar la zona neutral del velocista
 estando sin reproducción activa.
 CAUSA: _on_speed_changed() llamaba a self._player.set_speed() y
 set_speed_live() incluso cuando self._playing=False. Acceder al _player sin
 reproducción activa puede disparar flushes sobre un stream no inicializado,
 produciendo artefactos de audio al arrancar la siguiente reproducción.
 FIX: Guardar defensivamente con try/except ya existía en partes del código;
 se añaden guards explícitos en los paths de set_speed/set_speed_live para
 no ejecutar operaciones de audio cuando not self._playing.

 ── FIX 4: Hub de cassette queda pintado al llegar al neutro (FIX-HUB-GHOST) ────
 BUG: Al jugar con los scrubs de morpher y velocidad, a veces el hub del
 cassette en la pantalla de logs quedaba pintado con el color activo del scrub
 (amarillo morpher, púrpura velocista) incluso después de que el scrub volvía
 a su valor neutro. En el log aparecían fenómenos de "falsos activos".
 CAUSA: _morpher_active y _speed_scrub_active se seteaban a True cuando el
 scrub salía del neutro, pero podían no resetearse si el retorno al neutro
 llegaba por un path que no invocaba _sync_buttons() ni limpiaba el flag.
 En _on_speed_changed(), la condición `is_moving = abs(ratio-1.0)>=0.005`
 comparaba con 0.005 pero at_center usaba 0.002; había una banda muerta entre
 0.002 y 0.005 donde at_center=True pero is_moving=True, dejando
 _speed_scrub_active=True con el scrub en neutro visual → hub pintado.
 FIX:
   · Unificar el umbral de neutro: usar la misma constante NEUTRAL_THRESH=0.003
     para is_moving y at_center en _on_speed_changed().
   · En _on_morpher_changed(), al llegar al path de consolidación final
     (pos≈0, no drag, no elastic), forzar _morpher_active=False y llamar
     _sync_buttons() incondicionalmente (no solo si _morpher_active era True).
   · En _tick_cassette(), añadir guard: si mode es "speed" o "morph_*" pero
     el scrub correspondiente no está activo según sus flags, forzar mode=None.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.40 — FIX-FLUSH-ANIM · FIX-SPEC-LABELS · FIX-RECOVERY-DIALOG
 Fecha: 2026-05-24
 Tipo: FIX (3 correcciones)

 ── FIX 1: Animación flushing congelada (FIX-FLUSH-ANIM) ─────────────────────
 BUG: La animación de PC arrojando bits al disco duro (estado "flushing" de
 MediaAnimWidget) se quedaba congelada al activarse el vaciado de búfer.
 CAUSA: random.seed(int(self._angle * 7)) usaba _angle como semilla. _angle
 solo avanza cuando _tick_cassette() pasa delta > 0, pero durante el vaciado
 la grabación ya se detuvo → mode=None → delta=0 → _angle constante → mismas
 posiciones de partículas en cada repaint → animación visualmente congelada.
 FIX:
   · Nuevo atributo _flush_tick (int) que se incrementa en cada llamada a
     tick() independientemente de delta.
   · setState("flushing") resetea _flush_tick a 0.
   · paintEvent usa random.seed(self._flush_tick & 0xFFFF) → partículas
     siempre se mueven aunque delta=0.
   · _screen_on ahora parpadea a ~4 Hz basado en _flush_tick (antes usaba
     _angle que también estaba congelado).

 ── FIX 2: Leyendas del log de especificación (FIX-SPEC-LABELS) ──────────────
 Sustituciones de texto en la sección CUENTAVUELTAS del log de exportación:
   "VUELTACAROLAS SOBRANTES"       → "C.R.A.C Tape Counter"
   "VUELTACAROLAS DADAS"           → "C.R.A.C Tape Counter - Reinicios"
   "VUELTACAROLA QUIETA"           → "C.R.A.C Tape Counter - Posición Quedada"
   "CAROLA SE DETUVO EN EL PUNTO"  → "C.R.A.C - Tape Counter - Punto de Truncamiento"
   "CAROLA REGISTRO DE SEÑAL SIMPLE" → "C.R.A.C - Tape Counter - Punto de Truncamiento"
 Solo afecta el contenido del archivo .txt de especificación; sin cambios
 en la lógica de cálculo ni en las variables internas.

 ── FIX 3: Diálogo de guardar ausente tras crash real (FIX-RECOVERY-DIALOG) ──
 BUG: Tras recuperar una sesión crasheada (CAROLA TRANQUILIZADA → RECUPERAR),
 no aparecía el cuadro de diálogo CracInformacionPatrimonialDialog pidiendo
 guardar la sesión recuperada.
 CAUSA: En _check_crash_recovery(), el path de cierre limpio (is_clean_preserve)
 llamaba a CracInformacionPatrimonialDialog.exec() después de _do_crash_recovery(),
 pero el path de crash real (RECUPERAR) solo llamaba _do_crash_recovery() y
 terminaba sin mostrar el diálogo.
 FIX: Añadir if self._has_audio(): CracInformacionPatrimonialDialog(self).exec()
 después de _do_crash_recovery() también en el path de crash real.
══════════════════════════════════════════════════════════════════════════════



══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.39 — FIX-COUNTER-CRASH-PERSIST
 Fecha: 2026-05-24
 Tipo: FIX — persistencia del cuentavueltas en crash-recovery

 ── Problema ─────────────────────────────────────────────────────────────────
 Al recuperar un archivo desde el búfer tras un crash o cierre abrupto y
 exportarlo, la sección CUENTAVUELTAS del log de especificación mostraba
 000 en todos los parámetros (surplus_a, surplus_b, final_value, fase, etc.).

 ── Causa raíz ───────────────────────────────────────────────────────────────
 El crash-manifest (escrito periódicamente por CrashGuard._write_manifest)
 contenía datos de audio, normalización y duración, pero NUNCA incluía el
 estado del cuentavueltas (TapeLogPanel._counter_surplus_a/b,
 _counter_final_value, _phase, _flip_done, etc.).
 Al arrancar tras el crash, los TapeLogPanel se inicializan con todos sus
 contadores en 0; _do_crash_recovery() no los restauraba, y por lo tanto
 get_spec_log_data() retornaba ceros al exportar.

 ── Solución ─────────────────────────────────────────────────────────────────
 1. LoritoAldhiroStudio._get_counter_manifest_fields()  [método nuevo]
      Lee el estado actual del TapeLogPanel activo y retorna un dict con
      claves prefijadas "counter_*" para mezclar en el crash-manifest.

 2. LoritoAldhiroStudio._archival_tick()  [modificado]
      Incorpora **self._get_counter_manifest_fields() en el dict pasado a
      _crash_guard.update() en cada tick (cada 5 s durante la grabación).
      El manifest en disco siempre tiene el estado fresco del cuentavueltas.

 3. TapeLogPanel.restore_counter_state(data)  [método nuevo]
      Recibe el dict del manifest y reescribe los atributos internos del
      cuentavueltas (_counter_surplus_a/b, _counter_wrap_*,
      _counter_final_value, _phase, _flip_done).

 4. LoritoAldhiroStudio._do_crash_recovery()  [modificado]
      Tras restaurar la GUI y antes de _sync_buttons(), llama a
      _restore_panel.restore_counter_state(manifest) usando el panel
      identificado por "counter_tape_label" del manifest (o el activo si
      el campo no existe en manifests anteriores).
      También sincroniza cassette_dur_box con la etiqueta recuperada.

 ── Compatibilidad ───────────────────────────────────────────────────────────
 Manifests generados por versiones anteriores (sin campos counter_*):
   · _get_counter_manifest_fields() no existía → esos manifests no tienen
     los campos → restore_counter_state() usa fallback a 0/False/"A".
   · Comportamiento idéntico al anterior: ceros en el log.
   · No hay regresión, solo mejora para sesiones grabadas con v0.22.39+.
══════════════════════════════════════════════════════════════════════════════



══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.38 — OPT-GLOBAL-FORENSIC-RECONSTRUCTION
 Fecha: 2026-05-23
 Tipo: OPTIMIZACIÓN ESTRUCTURAL GLOBAL — reconstrucción forense completa

 ── Eliminación de scipy en el GUI thread ────────────────────────────────────
 OPT-SCIPY-ELIM: _crac_classify_profile() reemplaza scipy.signal.welch()
 por numpy rfft + ventana Hann con caché de instancia (_prof_hann, _prof_freqs).
 · Elimina import dinámico de scipy en el hot path 15 Hz del GUI thread.
 · Elimina la creación de 2 arrays temporales (freqs, psd) por tick.
 · Caché de ventana Hann evita recalcular np.hanning(n) cuando el blocksize
   no cambia (caso dominante en sesiones estables).
 · Overhead ~4× menor que welch para bloques < 2048 muestras.

 ── Eliminación de allocaciones en el detector de silencio ───────────────────
 OPT-FFT-CACHE: _check_silence_autopause() cachea rfftfreq + sc_mask por
 tamaño de segmento (_sil_fft_cached_n / _sil_fft_sc_mask). Elimina la
 recreación de dos arrays numpy en cada tick del spectral gate (15 Hz).

 OPT-PROFILE-DEBOUNCE: clasificación espectral CRAC-PROFILE ejecuta cada
 5 ticks (~333 ms) en lugar de cada tick (67 ms). La EMA integra
 suavemente — convergencia indistinguible para el usuario. Reduce FFT
 CPU en ~80% manteniendo precisión de clasificación A/B.

 OPT-PAUSE-DEQUE: _sil_pause_times migrado de list a deque(maxlen=N).
 · Elimina la list comprehension `[t for t in ... if t > cutoff]` del
   hot path _activate_silence_autopause() (llamada cada detección 15 Hz).
 · Operación O(k) en frente del deque vs O(n) list comprehension.
 · Cero allocaciones en el camino dominante (ninguna pausa en ventana).

 OPT-RMS-FLOAT32: cálculo de RMS de silencio usa dot product sobre float32
 nativo en lugar de astype(np.float64) + mean(x²). Elimina array duplicado.

 OPT-VU-DOT: VU de grabación usa dot product (_col @ _col * inv_n) en lugar
 de mean(d[:,c]**2). Elimina array temporal de cuadrados por tick.

 ── Resets de caché en start_record ─────────────────────────────────────────
 Todos los cachés introducidos se resetean en start_record() para garantizar
 coherencia si el samplerate cambia entre sesiones.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.37 — CUENTAVUELTAS-TRUNCADO-C60-C90-SPEC-LOG
 Fecha: 2026-05-23
 Tipo: FEATURE — detección de grabación truncada en Lado A y Lado B (C-60 / C-90)

 ── Descripción ──────────────────────────────────────────────────────────────
 En modos C-60 y C-90, cuando el operario detiene la grabación antes de que
 el cuentavueltas complete un ciclo completo (0→999→0), se distinguen dos casos:

 CASO 1 — Lado A truncado (cuentavueltas detenido entre 000 y 999, sin retorno):
   · _flip_done == False al exportar.
   · En la sección CUENTAVUELTAS del log de especificación se anota:
       CAROLA REGISTRO DE SEÑAL SIMPLE: (XXX)
     donde XXX es el valor del cuentavueltas al detenerse (final_value).
   · NO se anota nada para el Lado B.

 CASO 2 — Lado A completo (retornó a 000) + Lado B truncado:
   · _flip_done == True y _phase == "B" al exportar, con surplus_b == 0
     (el Lado B no llegó a 999).
   · Se aplica la fórmula de VUELTACAROLAS SOBRANTES del Lado A normalmente.
   · Para el Lado B se anota:
       CAROLA SE DETUVO EN EL PUNTO (XXX) EN EL LADO B
     donde XXX es el valor del cuentavueltas del Lado B al detenerse.

 CASO 3 — Lado A completo + Lado B completo (ambos retornaron a 000):
   · Comportamiento sin cambio: se anotan ambos VUELTACAROLAS SOBRANTES.

 Cambios aplicados:
   · get_spec_log_data() ahora incluye "phase" y "flip_done".
   · Sección CUENTAVUELTAS de _do_export() reestructurada con los 3 casos.
   · Modos OTROS: sin cambio.
══════════════════════════════════════════════════════════════════════════════

══════════════════════════════════════════════════════════════════════════════
 CHANGELOG v0.22.36 — CUENTAVUELTAS-WRAP-C60-C90-OTROS-SPEC-LOG
 Fecha: 2026-05-23
 Tipo: FEATURE — comportamiento wrap del cuentavueltas + log "Aldhira de Especificación de CRAC"

 ── C-60 / C-90 ──────────────────────────────────────────────────────────────
 · Cuando el cuentavueltas llega a 999, retorna a 000 y sigue contando.
 · Las vueltas dadas después de pasar 999 se acumulan en:
     _counter_surplus_a (Lado A) y _counter_surplus_b (Lado B)
 · Al finalizar Lado A (pausa automática de volteo), se captura
   _counter_surplus_a. Al reactivar en Lado B, el cuentavueltas retorna
   a 000 y acumula _counter_surplus_b hasta que se detiene la grabación.
 · En el log "Aldhira de Especificación de CRAC" se anota:
     VUELTACAROLAS SOBRANTES: XXX (LADO A)
     VUELTACAROLAS SOBRANTES: XXX (LADO B)
 · La animación de hubs y parpadeo de overflow NO se modifica.

 ── OTROS ────────────────────────────────────────────────────────────────────
 · _counter_wrap_count ya existía y cuenta los ciclos 0→999→0.
 · Al exportar se anota en el log de especificación:
     VUELTACAROLAS DADAS: X   (cuántas veces el contador retornó a cero)
     VUELTACAROLA QUIETA: XXX (valor del contador al detenerse la grabación)

 ── Log "Aldhira de Especificación de CRAC" ──────────────────────────────────
 · Nuevo archivo <base>_aldhira_spec_crac.txt generado junto al audio exportado.
 · Contiene todas las especificaciones técnicas de la sesión + datos cuentavueltas.

 Variables nuevas : _counter_surplus_a, _counter_surplus_b,
                    _counter_wrap_post_a (bandera de reset en Lado B),
                    _counter_post_a_base (base para calcular surplus B)
 Métodos nuevos   : get_spec_log_data() en TapeLogPanel
 Métodos modificados: update_state() (captura surplus A al voltear, reset en B),
                      _do_export() (escribe archivo de especificación)
══════════════════════════════════════════════════════════════════════════════


── CRAC Capture Engine v1.0 — instalado en v0.22.00 ─────────────────────────
Reemplaza: AudioCaptureEngine v0.21.x, DiskWriter v0.20.15,
           _RobustRingBuffer (como motor de captura), PreRollBuffer
Nuevas clases del motor: CaptureEngineV2, DiskWriterV2, RingBufferAbsorcion,
                         ColaElasticaDisco, PreRollBufferV2, CaptureClock,
                         _AtomicSlot, PreallocPool, CaptureEngineStatus
Arquitectura: Pipeline 4 capas desacopladas con Ring Buffer de Absorción
              antiskip (tipo CD portátil), recovery no-destructivo,
              clock monotónico hardened, backpressure predictivo por watermark,
              DiskWriter con escritura por batches y cola elástica.
Dependencias: sounddevice, soundfile, numpy (sin cambios respecto a v0.21.x)
Referencia:   crac_capture_engine_v1.py — Carola Records Aldhira Capture
─────────────────────────────────────────────────────────────────────────────
