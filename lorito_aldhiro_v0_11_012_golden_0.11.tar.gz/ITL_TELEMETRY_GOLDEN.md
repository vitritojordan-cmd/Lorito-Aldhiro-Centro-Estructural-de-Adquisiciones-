# ITL_TELEMETRY_GOLDEN.md — Instrumentación, visor de onda, ITL y bitácora

Orden: LA-GOLDEN-UI-ITL-TELEM-001 (INST-01/02, WAVE-01/02, ITL-01/02/03,
TAPE-01, LOG-01/02, THREAD-01), Lorito Aldhiro 0.11.001.
Código: `backend/telemetry/` (sin Qt), `frontend/widgets/lorito_indicators.py`,
`frontend/widgets/lorito_waveform.py`, `frontend/integration/lorito_itl_integration.py`,
`frontend/main_window/lorito_mw_ui_build.py`.
Pruebas: `tests/test_ui_itl_golden.py` (30 casos).

## Principio

La UI **observa** snapshots inmutables. Nunca es autoridad sobre frames,
duración efectiva ni integridad.

## 1. Medidor (INST-01, INST-02)

- `CaptureMeter` (hilo de drenaje):
  - peak de muestra y RMS por canal en una ventana de **frames** (300 ms),
    independiente del tamaño de bloque;
  - dBFS con suelo de −120;
  - overs por canal (≥ 0,999).
- Cada `MeterReading` declara `unit=dBFS`, `peak_kind=SAMPLE_PEAK`,
  `window_ms` y `source=CAPTURE_RAW`. El true peak **no** se presenta como
  medido.
- `CaptureTelemetrySnapshot` lleva `measured_at` monotónico y una calidad:
  - `VALID`;
  - `STALE` si tiene más de 0,5 s (`quality_at`);
  - `UNAVAILABLE`.
  El cero ya no significa a la vez silencio y sensor sin dato.
- `PeakHold` funciona **por tiempo**: el valor mostrado es función cerrada
  de (pico retenido, instante, ahora). Es idéntico con 1 tick o con 1000.
  Las pruebas encontraron y corrigieron un decaimiento acumulativo que
  dependía del número de ticks.
- `VUBar` aplica balística por tiempo (`setValues(l, r, now)`,
  `decay(now)`) y muestra un velo STALE.

## 2. Visor de onda (WAVE-01, WAVE-02)

- Envolventes min/max **por canal**:
  - en vivo, `LiveEnvelopeRing` (memoria fija, productor en el drenaje);
  - desde archivo, `compute_file_envelope`, que lee por bloques.
- Vista `ABSOLUTE` (escala 1, sin auto-normalización) separada de la vista
  `NORMALIZED`, con un selector en el widget.
- `reduce_columns` conserva los extremos y no diezma por muestreo: los
  transitorios sobreviven.
- El widget solo pinta los datos compactos (`updateFromEnvelope`).

## 3. ITL (ITL-01, ITL-02, ITL-03)

- **Reloj de cinta desde frames.** `tick(dt, audio_seconds)` avanza
  exactamente los segundos de audio aceptados por el motor de captura
  (`audio_seconds_accepted()`). Es inmune a ticks perdidos, al jitter y a
  una GUI congelada, y es nulo durante las pausas. El primer tick ancla la
  referencia, porque puede llegar todavía el contador de la sesión previa.
- **Exactamente una vez.**
  - Volteo y autostop: `flip_done`/`stop_issued`, con contadores de
    duplicados.
  - El volteo manual es idempotente.
  - Los callbacks se difieren y se disparan **fuera del lock**. Esto corrige
    un interbloqueo P0 real: el autostop llamaba a
    `stop_all → stop_recording`, que volvía a pedir el mismo
    `threading.Lock`.
- **SIPA por timestamps.** El cronómetro de silencio avanza por tiempo
  monotónico real entre lecturas (paso acotado a 1 s). Una lectura con más
  de 0,5 s de antigüedad es STALE: congela el cronómetro y se cuenta.
- **Perfil de cinta (TAPE-01).** `configure_profile()` fija umbrales y
  cuentavueltas. **OTROS no tiene automatismos**: el reloj avanza, pero no
  hay pausa, volteo, stop ni aviso de desborde. Antes, OTROS heredaba en
  silencio los umbrales de C-90.

## 4. Duración de cinta (TAPE-01)

`TapeModel.describe()` separa **NOMINAL** (etiqueta C-60/C-90),
**AUDIO** (frames) y **ESTIMADO ± tolerancia** (3 %). `TimelineAuthority`
distingue el tiempo de audio (frames) del tiempo de pared (incluye pausas) y
lleva el registro de eventos (START, FLIP_CONFIRMED).

## 5. Bitácora forense (LOG-01, LOG-02)

- `ForensicEventLog` (JSONL, esquema `lorito.event/1`). Cada evento lleva
  `ts_utc`, `t_monotonic_ns`, `session_id`, `stage`, `severity`,
  `sequence`, `frame`, `prev_state`, `new_state`, `cause` y `data`.
- `emit()` nunca hace I/O:
  - la cola informativa está acotada y cuenta lo que descarta, que se
    reporta como `LOG_DROPPED`;
  - la cola de prioridad (ERROR, CRITICAL, P0) **no descarta** y hace
    fsync de cada evento P0.
- Errores de disco: visibles en `write_errors`/`last_error`. Los P0 se
  retienen en memoria (`pending_priority`) y el cierre no se cuelga.
- Hay un singleton de proceso (`get_process_event_log()`) en
  `ARCHIVE_DIR/lorito_forensic_events.jsonl`, o en `LORITO_EVENT_LOG_PATH`.
  Lo usan el motor de captura (transiciones de estado y pérdidas P0) y el
  reproductor (transiciones de transporte). Los mensajes de estado de la
  GUI también se registran: el `StatusDisplay` pasa a ser una **vista**.

## 6. Afinidad de hilos (THREAD-01)

Los widgets solo se tocan en el hilo de GUI, mediante señales encoladas. El
backend publica snapshots (medidor, envolvente, transporte) y la GUI los
lee.

## 7. Fuera del alcance de este entorno

Calibración del medidor contra un instrumento de referencia, validación
visual por operadores y pruebas de usabilidad con hardware de cinta real.
