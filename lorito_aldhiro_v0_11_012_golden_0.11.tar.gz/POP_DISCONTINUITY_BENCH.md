# POP_DISCONTINUITY_BENCH — Lorito Aldhiro (Orden Golden SMV, Fases 0/7)

Generado por `tools/bench_transport_discontinuity.py`. Motor productivo con hilos reales; driver PortAudio SIMULADO (callbacks cada 2 ms, sin hardware). Salida digital del motor, no loopback acústico.

| Señal | Gesto | Seek | Discont. amplitud / pendiente | Pico 1.ª dif. | Underruns | Obsoletos consumidos | Gen. mezcladas | Fuera de orden | Trans. degradadas | Callback p99 / máx (ms) | SHA-256 salida (16) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| seno_997Hz_-6dBFS | speed_x1_x0.8_x1 | DIP | 0 / 0 | 0.0654 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.069 / 0.069 | 8ad9abf1437ea24c |
| seno_997Hz_-6dBFS | velocista_drag_release | DIP | 0 / 0 | 0.1252 (cota 0.1308) | 0 | 0 | 0 | 0 | 0 | 0.047 / 0.066 | 259d24cf130705ee |
| seno_997Hz_-6dBFS | morpher_ida_vuelta_elastico | DIP | 0 / 0 | 0.1539 (cota 0.1635) | 0 | 0 | 0 | 0 | 0 | 0.055 / 0.059 | 06935da6f484e13d |
| seno_997Hz_-6dBFS | seek_repetido_20-50ms | DIP | 0 / 0 | 0.0654 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.051 / 0.094 | efe6fc7fe716fc22 |
| seno_997Hz_-6dBFS | seek_repetido_20-50ms | CUT | 10 / 22 | 0.7656 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.048 / 0.075 | 1fa591e68ec3d082 |
| seno_997Hz_-6dBFS | ratios_0.999_1_1.001 | DIP | 0 / 0 | 0.0654 (cota 0.0655) | 0 | 0 | 0 | 0 | 0 | 0.092 / 0.092 | c8cc1dfd038cf9a6 |
| seno_997Hz_-6dBFS | reversa_y_seek_en_reversa | DIP | 0 / 0 | 0.0654 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.060 / 0.060 | 1daed519595f4905 |
| multiseno_220_997_3100 | speed_x1_x0.8_x1 | DIP | 0 / 0 | 0.0655 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.047 / 0.047 | 9d607be567ba25e2 |
| multiseno_220_997_3100 | velocista_drag_release | DIP | 0 / 0 | 0.1229 (cota 0.1318) | 0 | 0 | 0 | 0 | 0 | 0.051 / 0.061 | 0108689c0be21af9 |
| multiseno_220_997_3100 | morpher_ida_vuelta_elastico | DIP | 0 / 0 | 0.1485 (cota 0.1648) | 0 | 0 | 0 | 0 | 0 | 0.043 / 0.056 | 9bd128c97c90e227 |
| multiseno_220_997_3100 | seek_repetido_20-50ms | DIP | 0 / 0 | 0.0656 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.047 / 0.078 | 7be8121f9465760a |
| multiseno_220_997_3100 | seek_repetido_20-50ms | CUT | 10 / 19 | 0.6483 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.081 / 0.083 | 395613a0f61e6774 |
| multiseno_220_997_3100 | ratios_0.999_1_1.001 | DIP | 0 / 0 | 0.0656 (cota 0.0660) | 0 | 0 | 0 | 0 | 0 | 0.049 / 0.049 | 7c9ea211affa4d4b |
| multiseno_220_997_3100 | reversa_y_seek_en_reversa | DIP | 0 / 0 | 0.0656 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.129 / 0.129 | 1e3450e6029dee62 |
| impulsos_cada_100ms | speed_x1_x0.8_x1 | DIP | impulsos detectados: 6 | — | 0 | 0 | 0 | 0 | 0 | 0.057 / 0.057 | 505dfd90d4f11f0c |
| impulsos_cada_100ms | velocista_drag_release | DIP | impulsos detectados: 13 | — | 0 | 0 | 0 | 0 | 0 | 0.052 / 0.393 | 706a7b0e065013ca |
| impulsos_cada_100ms | morpher_ida_vuelta_elastico | DIP | impulsos detectados: 8 | — | 0 | 0 | 0 | 0 | 0 | 0.042 / 0.048 | e8bebcc9c460a372 |
| impulsos_cada_100ms | seek_repetido_20-50ms | DIP | impulsos detectados: 23 | — | 0 | 0 | 0 | 0 | 0 | 0.156 / 0.513 | b05c552ff46d1e30 |
| impulsos_cada_100ms | seek_repetido_20-50ms | CUT | impulsos detectados: 23 | — | 0 | 0 | 0 | 0 | 0 | 0.064 / 0.188 | 3fccba595d838f5f |
| impulsos_cada_100ms | ratios_0.999_1_1.001 | DIP | impulsos detectados: 7 | — | 0 | 0 | 0 | 0 | 0 | 0.112 / 0.112 | 7b9f87440c842eca |
| impulsos_cada_100ms | reversa_y_seek_en_reversa | DIP | impulsos detectados: 6 | — | 0 | 0 | 0 | 0 | 0 | 0.067 / 0.067 | dada66d91cfaa441 |

Nota: la fila CUT es un CONTROL: demuestra que la métrica detecta un corte seco; la política productiva de seek es DIP. Los hashes varían entre corridas porque el instante exacto de cada gesto depende del planificador del SO.
