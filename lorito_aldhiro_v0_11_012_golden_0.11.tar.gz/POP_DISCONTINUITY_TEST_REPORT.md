# POP_DISCONTINUITY_TEST_REPORT.md — Informe de discontinuidades (Orden Golden SMV)

Lorito Aldhiro 0.11.007 (refundación del Transport Core). Este informe
separa con precisión **lo medido** en este entorno (salida digital del motor
productivo, con hilos reales, sobre un driver PortAudio simulado) de **lo
que exige hardware** y queda pendiente.

## 1. Señales patrón (corpus determinista)

| Señal | Uso | Cota física de la métrica |
|---|---|---|
| Seno 997 Hz a −6 dBFS | SMV-T01, T04, T05, T07, T08, política de seek, STOP | 1.ª diferencia ≤ a·2πf·r/fs; 2.ª ≤ a·(2πf·r/fs)² |
| Multiseno 220 + 997 + 3100 Hz | banco | suma de cotas por componente |
| Impulsos 0,9 cada 100 ms | SMV-T02 (duplicación o pérdida de transitorios) | conteo de grupos > 0,3 |
| Seno con fixture de audio real (Sotalomafer1, 5 s) | contrato del lector | referencia Catmull-Rom muestra a muestra |

Métrica (`backend/transport/lorito_discontinuity_metrics.py`):

- **discontinuidad de amplitud**: muestra con |Δx| > 1,15 × cota;
- **discontinuidad de pendiente**: |Δ²x| > 4 × cota;
- los tramos de silencio exacto (underrun o fin declarados) se cuentan
  aparte.

La métrica se valida a sí misma: la política CUT (corte seco) **sí**
dispara discontinuidades (control positivo).

## 2. Resultados automatizados (SMV-T01…T10)

`tests/test_transport_golden.py`: 18 casos, todos OK. Se corrió 5 veces
aislada y dentro de la suite completa.

| Prueba | Criterio | Resultado |
|---|---|---|
| SMV-T01 | ×1 → ×0,8 → ×1 con seno: 0 discontinuidades de amplitud y de pendiente | OK |
| SMV-T02 | impulsos durante speed-live y commit hasta EOF: exactamente 20 de 20 | OK |
| SMV-T03 | 25 seeks cada 20–50 ms con disco lento (15 ms por lectura): 0 obsoletos, 0 generaciones mezcladas, 0 fuera de orden; el frame audible converge al último destino | OK |
| SMV-T04 | Morpher 1 → 2,5 → −2 → retorno elástico → commit: 0 discontinuidades | OK |
| SMV-T05 | Velocista 0,5…2 con arrastre y suelta rápida ×3: 0 underruns (sin gaps por flush), 0 discontinuidades | OK |
| SMV-T06 | seek a 40 frames del EOF: transición SEEK **degradada** declarada con causa; la sesión termina en EOF | OK |
| SMV-T07 | live con 0,999 / 1,000 / 1,001: 0 discontinuidades; cursor exacto (prueba de lector) | OK |
| SMV-T08 | seek durante reversa: la posición audible parte del destino y decrece; 0 discontinuidades | OK |
| SMV-T09 | análisis AST del callback: sin logs, locks, I/O, asignaciones, crossfades ni `try/with`; percentiles de timing reportados | OK |
| SMV-T10 | disco lento (50 ms por lectura): underruns contados con frames y generación; silencio capturado ≥ frames de underrun declarados; 0 generaciones mezcladas | OK |
| Política de seek | DIP 0 discontinuidades; CUT > 0 (control); XFADE_LINEAR acotado | OK |
| STOP | fundido FADE_OUT_END, última muestra 0, 0 discontinuidades | OK |
| Orden determinista | seeks supersedidos, LIVE combinados, IDs monotónicos | OK |
| SMV-08 | el motor no usa `_frn_state`/`_frn_emit` | OK |

Contrato del lector (`tests/test_resample_continuity*.py`, 16 casos):

- ×1 bit-exacto, con señal sintética y con audio real;
- error ≤ 1e-5 frente a la referencia en **cada** muestra, con ratios 0,5 a
  2, rampas y reversa a través de 0;
- cursor = Σ ratios exacto;
- lecturas de disco acotadas por la caché.

## 3. Banco reproducible

`tools/bench_transport_discontinuity.py` cubre 3 señales × 6 gestos (más el
control CUT). Recorre los gestos de la orden: speed ×1→×0,8→×1, arrastre y
suelta del Velocista, Morpher ida/vuelta con retorno elástico, seeks
repetidos, ratios ≈ 1, y reversa con seek en reversa. Salida de la última
ejecución:

| Señal | Gesto | Seek | Discont. amplitud / pendiente | Pico 1.ª dif. | Underruns | Obsoletos consumidos | Gen. mezcladas | Fuera de orden | Trans. degradadas | Callback p99 / máx (ms) | SHA-256 salida (16) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| seno_997Hz_-6dBFS | speed_x1_x0.8_x1 | DIP | 0 / 0 | 0.0654 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.069 / 0.069 | 8ad9abf1437ea24c |
| seno_997Hz_-6dBFS | velocista_drag_release | DIP | 0 / 0 | 0.1252 (cota 0.1308) | 0 | 0 | 0 | 0 | 0 | 0.047 / 0.066 | 259d24cf130705ee |
| seno_997Hz_-6dBFS | morpher_ida_vuelta_elastico | DIP | 0 / 0 | 0.1539 (cota 0.1635) | 0 | 0 | 0 | 0 | 0 | 0.055 / 0.059 | 06935da6f484e13d |
| seno_997Hz_-6dBFS | seek_repetido_20-50ms | DIP | 0 / 0 | 0.0654 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.051 / 0.094 | efe6fc7fe716fc22 |
| seno_997Hz_-6dBFS | seek_repetido_20-50ms | CUT | 10 / 22 | 0.7656 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.048 / 0.075 | 1fa591e68ec3d082 |
| seno_997Hz_-6dBFS | ratios_0.999_1_1.001 | DIP | 0 / 0 | 0.0654 (cota 0.0655) | 0 | 0 | 0 | 0 | 0 | 0.092 / 0.092 | c8cc1dfd038cf9a6 |
| seno_997Hz_-6dBFS | reversa_y_seek_en_reversa | DIP | 0 / 0 | 0.0654 (cota 0.0654) | 0 | 0 | 0 | 0 | 0 | 0.060 / 0.060 | 1daed519595f4905 |
| multiseno_220_997_3100 | speed_x1_x0.8_x1 | DIP | 0 / 0 | 0.0655 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.047 / 0.047 | 9d607be567ba25e2 |
| multiseno_220_997_3100 | velocista_drag_release | DIP | 0 / 0 | 0.1229 (cota 0.1318) | 0 | 0 | 0 | 0 | 0 | 0.051 / 0.061 | 0108689c0be21af9 |
| multiseno_220_997_3100 | morpher_ida_vuelta_elastico | DIP | 0 / 0 | 0.1485 (cota 0.1648) | 0 | 0 | 0 | 0 | 0 | 0.043 / 0.056 | 9bd128c97c90e227 |
| multiseno_220_997_3100 | seek_repetido_20-50ms | DIP | 0 / 0 | 0.0656 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.047 / 0.078 | 7be8121f9465760a |
| multiseno_220_997_3100 | seek_repetido_20-50ms | CUT | 10 / 19 | 0.6483 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.081 / 0.083 | 395613a0f61e6774 |
| multiseno_220_997_3100 | ratios_0.999_1_1.001 | DIP | 0 / 0 | 0.0656 (cota 0.0660) | 0 | 0 | 0 | 0 | 0 | 0.049 / 0.049 | 7c9ea211affa4d4b |
| multiseno_220_997_3100 | reversa_y_seek_en_reversa | DIP | 0 / 0 | 0.0656 (cota 0.0659) | 0 | 0 | 0 | 0 | 0 | 0.129 / 0.129 | 1e3450e6029dee62 |
| impulsos_cada_100ms | speed_x1_x0.8_x1 | DIP | impulsos detectados: 6 | — | 0 | 0 | 0 | 0 | 0 | 0.057 / 0.057 | 505dfd90d4f11f0c |
| impulsos_cada_100ms | velocista_drag_release | DIP | impulsos detectados: 13 | — | 0 | 0 | 0 | 0 | 0 | 0.052 / 0.393 | 706a7b0e065013ca |
| impulsos_cada_100ms | morpher_ida_vuelta_elastico | DIP | impulsos detectados: 8 | — | 0 | 0 | 0 | 0 | 0 | 0.042 / 0.048 | e8bebcc9c460a372 |
| impulsos_cada_100ms | seek_repetido_20-50ms | DIP | impulsos detectados: 23 | — | 0 | 0 | 0 | 0 | 0 | 0.156 / 0.513 | b05c552ff46d1e30 |
| impulsos_cada_100ms | seek_repetido_20-50ms | CUT | impulsos detectados: 23 | — | 0 | 0 | 0 | 0 | 0 | 0.064 / 0.188 | 3fccba595d838f5f |
| impulsos_cada_100ms | ratios_0.999_1_1.001 | DIP | impulsos detectados: 7 | — | 0 | 0 | 0 | 0 | 0 | 0.112 / 0.112 | 7b9f87440c842eca |
| impulsos_cada_100ms | reversa_y_seek_en_reversa | DIP | impulsos detectados: 6 | — | 0 | 0 | 0 | 0 | 0 | 0.067 / 0.067 | dada66d91cfaa441 |

Nota: la fila CUT es un CONTROL: demuestra que la métrica detecta un corte seco; la política productiva de seek es DIP. Los hashes varían entre corridas porque el instante exacto de cada gesto depende del planificador del SO.

Lectura:

- Todos los gestos con la política productiva tienen **0 discontinuidades
  de amplitud y de pendiente**.
- 0 obsoletos consumidos, 0 generaciones mezcladas, 0 comandos fuera de
  orden y 0 underruns.
- El pico de la 1.ª diferencia queda bajo la cota física de la señal a la
  velocidad máxima usada.
- El control CUT muestra que un corte seco produce saltos de hasta unas 12
  veces la cota.
- El timing del callback es el del stub (p99 < 0,2 ms), **no** el de un
  PortAudio real.

## 4. Pendiente: requiere hardware o personas (no ejecutable aquí)

| ID | Prueba | Estado |
|---|---|---|
| SMV-T11 | loopback de 30 min con interfaz real, corpus música/voz y gestos automatizados | **PENDIENTE**: sin interfaz de audio en este entorno |
| SMV-T12 | comparación con CRAC 0.36 (mismas fuentes, rate, canales y gestos) | **PENDIENTE**: CRAC 0.36 y su entorno no están disponibles |
| SMV-T13 | soak de 8 h con cambios repetidos de control | **PENDIENTE**: el banco sintético cubre minutos, no horas |
| SMV-T14 | entorno limpio y regresión completa con hashes archivados | parcial: suite completa reproducible, `requirements.lock.txt` y manifiesto SHA-256; falta la ejecución en máquina limpia de referencia |
| — | escucha ciega con dos evaluadores, artefactos anotados | **PENDIENTE**: requiere personas |
| — | deadline misses p50…p99.9 con PortAudio real, CPU al 90 % y GUI congelada | **PENDIENTE**: el instrumento está implementado (`callback_timing`); falta medirlo en hardware |

## 5. Clasificación

Según §8 de la orden, **no se declara GOLDEN**: faltan G0 (comparación con
CRAC 0.36), G6 (loopback de hardware y comparación de calidad) y G7 (firma
de QA). Las puertas G1–G5 tienen evidencia automatizada en este entorno. No
se afirma "cero pops": se afirma que, con la métrica y el corpus
declarados, la salida digital no presenta discontinuidades.
