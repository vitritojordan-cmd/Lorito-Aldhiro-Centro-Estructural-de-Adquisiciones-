# REFERENCIAS_INVESTIGACION_TECNICA.md — investigación externa para las Órdenes Golden 0.11.001

Informe de investigación técnica en internet realizado para la refundación de los
cinco motores (Captura, DSP PREVI/NR, Exportación, Instrumentación/ITL,
Scrubs/Velocista/Seek). Se conserva tal como se produjo, con sus marcas de
confianza:

- **[NO VERIFICADO]**: no se pudo contrastar con la fuente primaria desde este entorno.
- **[DE MEMORIA]**: dato de conocimiento previo, sin lectura de fuente en esta sesión.
- **[PROPUESTA]**: sugerencia de diseño, no un hecho de una fuente.

El proxy del entorno bloqueó la lectura directa de varios dominios primarios
(portaudio.com, docs.python.org, itu.int, ebu.ch…); sí se leyó el código y la
documentación fuente en `raw.githubusercontent.com` (PortAudio,
python-sounddevice, python-soundfile, CPython, NumPy, pyloudnorm, libebur128).
Las decisiones de implementación que se apoyan en este informe se citan en
los documentos de contrato de cada motor.

---

## Informe técnico de investigación para el refactor de Lorito Aldhiro

**Cómo se hizo la investigación.** Desde este entorno el proxy bloqueó WebFetch hacia casi todos los dominios primarios (portaudio.com, docs.python.org, readthedocs, lwn.net, learn.microsoft.com, itu.int, ebu.ch, wikipedia, worldradiohistory). Sí se pudieron leer:
- `raw.githubusercontent.com`: código y documentación fuente de PortAudio, python-sounddevice, python-soundfile, CPython, NumPy, pyloudnorm y libebur128.
- Fragmentos devueltos por WebSearch.

Lo que no pude comprobar en una fuente primaria aparece marcado como **[NO VERIFICADO]** o **[DE MEMORIA]**. Las sugerencias de diseño que son mías, y no vienen de una fuente, van marcadas como **[PROPUESTA]**.

---

## 1. Captura y tiempo real

### 1.1 Restricciones del callback de PortAudio (portaudio.h)

Fuente: https://raw.githubusercontent.com/PortAudio/portaudio/master/include/portaudio.h

**Qué no se debe hacer en el callback** (cita literal): "Do not allocate memory, access the file system, call library functions or call other functions from the stream callback that may block or take an unpredictable amount of time to complete."

**Qué API se puede usar dentro del callback:** solo `Pa_GetStreamCpuLoad()`. Cualquier otra llamada a la API de PortAudio está prohibida ahí.

**Significado de los flags (`PaStreamCallbackFlags`):**
- **`paInputUnderflow`**
  - Si el stream se abrió con `paFramesPerBufferUnspecified`: la entrada es todo silencio porque no había datos reales.
  - En los demás casos: se insertaron ceros en el buffer de entrada para compensar el underflow.
- **`paInputOverflow`**
  - Se descartaron datos anteriores a la primera muestra del buffer, "possibly because the stream callback is using too much CPU time".
  - **Consecuencia para la app:** en la grabación hay un hueco temporal que no se ve en los datos. Hay que contarlo y marcarlo en metadatos.
- **`paOutputUnderflow`**: se insertó un hueco (o datos) en la salida.
- **`paOutputOverflow`**: se descartarán datos de salida porque no hay sitio.
- **`paPrimingOutput`**: la salida se usa para cebar el stream y la entrada puede ser cero.

**Marca de tiempo:** `PaStreamCallbackTimeInfo.inputBufferAdcTime` es "the time when the first sample of the input buffer was captured at the ADC input". Conviene usarla, y no el reloj del sistema, para la marca temporal de cada bloque.

Lectura recomendada (secundaria): Ross Bencina, "Real-time audio programming 101". Se pudo localizar el artículo, pero no leerlo; la discusión está en https://lwn.net/Articles/452630/. Su regla: no reservar ni liberar memoria y no bloquear un mutex en el hilo de audio.

### 1.2 Detalles de python-sounddevice

Fuente: https://raw.githubusercontent.com/spatialaudio/python-sounddevice/master/src/sounddevice.py

**Firma del callback:** `callback(indata, outdata, frames, time, status)`.
- `time` es una estructura CFFI con `inputBufferAdcTime` y `outputBufferDacTime`.
- `status` es un objeto `CallbackFlags`.

**Atributos de `CallbackFlags`:** `input_underflow`, `input_overflow`, `output_underflow`, `output_overflow`, `priming_output`.
- `__bool__` devuelve True si hay algún flag activo.
- `__ior__` permite acumular: `errores |= status`. sounddevice lo hace internamente (`self.status |= status`) en `_CallbackContext`.
- `__str__` lista los flags activos.

**Reglas del callback:**
- Debe llenar siempre todo `outdata`, pase lo que pase.
- Si lanza cualquier excepción, el callback no se vuelve a llamar.
- `CallbackStop`: el stream sigue hasta que suenan todos los buffers ya generados.
- `CallbackAbort`: el stream termina lo antes posible.

**Modo bloqueante:** `InputStream.read()` devuelve `(data, overflowed)`. `overflowed` es True si PortAudio descartó entrada entre la llamada anterior y esta.

**`blocksize`:** la documentación recomienda `blocksize=0` (lo elige el host, y puede variar) salvo que el algoritmo necesite un número fijo de frames. Un valor fijo puede añadir una capa de buffering en algunos host APIs. Ver https://python-sounddevice.readthedocs.io/en/0.5.1/api/streams.html.

**GIL:** la documentación oficial de sounddevice no dice nada del GIL **[NO VERIFICADO en docs]**. Pero el callback es código Python, así que necesita el GIL.
- Cualquier hilo que retenga el GIL durante más de un bloque provoca under/overflow.
- El intérprete reparte el GIL por "timeslices" (`sys.setswitchinterval`). Según la documentación, el valor real "can be higher, especially if long-running internal functions" se están ejecutando. Fuente: https://raw.githubusercontent.com/python/cpython/main/Doc/library/sys.rst. El valor por defecto es 5 ms **[DE MEMORIA]**.
- **Consecuencia:** el `blocksize` (o la latencia) tiene que ser bastante mayor que el peor tiempo de retención del GIL de los otros hilos, por ejemplo durante FFT, render de waveform o JSON grandes.

**Patrones de los ejemplos oficiales:**
- **`rec_unlimited.py`** (https://raw.githubusercontent.com/spatialaudio/python-sounddevice/master/examples/rec_unlimited.py)
  - Usa una `queue.Queue()` sin límite.
  - El callback hace `q.put(indata.copy())`. La copia es obligatoria porque PortAudio reutiliza el buffer.
  - El hilo principal escribe con `SoundFile(mode='x')`, que falla si el archivo ya existe, en un bucle `file.write(q.get())`.
- **`play_long_file.py`** (https://raw.githubusercontent.com/spatialaudio/python-sounddevice/master/examples/play_long_file.py)
  - Prellena la cola con `buffersize` bloques.
  - En el callback usa `q.get_nowait()`. Si recibe `queue.Empty`, lanza `CallbackAbort`.
  - Si el último bloque es corto, rellena con ceros y lanza `CallbackStop`.
  - El productor usa `q.put(data, timeout=…)`, así que la cola está acotada y la memoria también.
  - Usa `finished_callback=event.set` con un `threading.Event`.

**[PROPUESTA] Patrón para captura:**
1. En el callback:
   - acumular `status` en un contador por flag (enteros simples);
   - copiar `indata` a un bloque de un pool preasignado;
   - hacer `put_nowait` del índice en una cola acotada.
2. Si la cola está llena (`queue.Full`): no bloquear. Incrementar `dropped_blocks` y registrar el instante con `time.inputBufferAdcTime`.
3. Fuera del callback: nada de logging, I/O ni asignaciones grandes.

### 1.3 SPSC "lock-free" en CPython y Python free-threaded

**Con GIL:**
- Una asignación simple (`self.w = n`) se ejecuta como un único bytecode de almacenamiento, así que otro hilo nunca ve un valor a medias. Esto es una propiedad de la implementación, no una garantía del lenguaje **[DE MEMORIA]**.
- **Cuidado con NumPy:** "NumPy releases the GIL for many low-level operations" (https://raw.githubusercontent.com/numpy/numpy/main/doc/source/reference/thread_safety.rst). Una copia por slice de un array grande puede ejecutarse sin GIL, y el lector puede ver datos a medio copiar.
- **Regla:** primero copiar los datos y después publicar el índice (`write_idx += n`). El lector lee el índice y solo entonces lee los datos.
- La misma documentación de NumPy advierte que leer y escribir a la vez el mismo array da resultados inconsistentes, y que redimensionar un array que otro hilo está leyendo puede tumbar el intérprete.

**Free-threaded (3.13t / 3.14t)** (https://raw.githubusercontent.com/python/cpython/main/Doc/howto/free-threading-python.rst, https://raw.githubusercontent.com/python/cpython/main/Doc/library/sys.rst):
- **Detectar el build:** `sysconfig.get_config_var("Py_GIL_DISABLED") == 1`.
- **Detectar si el GIL está activo en ejecución:** `sys._is_gil_enabled()` (3.13+).
- **Reactivación del GIL:** `PYTHON_GIL` o `-X gil` lo reactivan. Importar una extensión C no preparada también lo reactiva y emite un aviso. Esto puede pasar con PySide6, cffi o soundfile según la versión **[NO VERIFICADO por paquete]**.
- **Tipos built-in:** `dict`, `list` y `set` usan locks internos "that behave similarly to the GIL". Aun así se recomienda usar primitivas explícitas.
- **Iteradores:** no es seguro compartir un iterador entre hilos.
- **Coste en un solo hilo:** sobrecoste de ~1 % (macOS aarch64) a ~8 % (x86-64 Linux).
- **NumPy:** soporte experimental desde 2.1 con CPython 3.13.

**Conclusión:** no hay garantías documentadas de ordenación de memoria para un ring buffer "lock-free" escrito en Python puro en el build free-threaded.

**[PROPUESTA]** Usar `queue.Queue(maxsize=N)` o `queue.SimpleQueue` para pasar índices de bloques preasignados. El lock interno es corto, y el callback ya paga el coste de ser Python. Si se quiere un ring real, hacerlo en C/Cython con atómicos acquire/release.

### 1.4 Durabilidad y errores de disco

**`os.fsync(fd)`** (https://raw.githubusercontent.com/python/cpython/main/Doc/library/os.rst):
- En Unix llama a `fsync`. En Windows llama a `_commit` del CRT, que se apoya en `FlushFileBuffers` **[DE MEMORIA]**.
- Hay que hacer antes `f.flush()` para vaciar el buffer de Python.
- `SoundFile.flush()` solo pasa los datos al sistema de archivos ("Write unwritten data to the file system"), no a disco. Después hay que hacer `os.fsync` sobre el fd. Fuente: https://raw.githubusercontent.com/bastibe/python-soundfile/master/soundfile.py.

**`os.replace`:**
- "If successful, the renaming will be an atomic operation (this is a POSIX requirement)."
- Puede fallar entre sistemas de archivos distintos, así que el temporal debe estar en el mismo directorio que el destino.

**El rename es atómico pero no durable.** Hay que hacer `fsync` del directorio padre.
- Hilo de PostgreSQL de 2015 (ext4): https://www.postgresql.org/message-id/56589A65.4060201%402ndquadrant.com
- `durable_rename()` de PostgreSQL hace: fsync del archivo, rename, fsync del destino y fsync del directorio. Commit: https://forger.sitiv.fr/open-dsi/postgres/commit/606e0f98

**Secuencia [PROPUESTA] en POSIX:**
1. Escribir `x.tmp`.
2. `flush` y `os.fsync(fd)`, luego `close`.
3. `os.replace(tmp, final)`.
4. `dfd = os.open(dir, os.O_RDONLY)`, `os.fsync(dfd)`, `os.close(dfd)`.

En Windows no se puede abrir un directorio con `os.open`: saltar el paso 4.

**Atomicidad en Windows:** `os.replace` usa `MoveFileEx(MOVEFILE_REPLACE_EXISTING)`. Microsoft no documenta que sea atómico, y hay informes de que puede caer en una copia (https://pypi.python.org/pypi/pyosreplace, https://bugs.python.org/issue8828).

**`FlushFileBuffers`:**
- Escribe todos los buffers del archivo al dispositivo.
- Es ineficiente si se llama tras cada escritura. Microsoft sugiere `FILE_FLAG_NO_BUFFERING | FILE_FLAG_WRITE_THROUGH` si hacen falta muchas escrituras durables.
- Requiere un handle con acceso de escritura.
- Fuente: https://msdn.microsoft.com/en-us/library/aa364439.aspx (solo leído por fragmentos).

**fsyncgate (2018):**
- En Linux, un error de writeback hace que las páginas se marquen limpias y se descarten.
- El primer `fsync` devuelve EIO y borra el error, así que un segundo `fsync` puede devolver éxito sin que los datos estén en disco.
- Fuentes: https://lwn.net/Articles/752063/, https://www.postgresql.org/message-id/CAMsr%2BYHh%2B5Oq4xziwwoEfhoTZgr07vdGG%2Bhu%3D1adXx59aTeaoQ%40mail.gmail.com
- Desde Linux 4.13 (errseq_t), el error se notifica a todos los descriptores abiertos (https://man7.org/linux/man-pages/man2/fsync.2.html).
- PostgreSQL pasó a hacer PANIC ante un fallo de fsync en archivos de datos (`data_sync_retry`; fuente secundaria: https://thebuild.com/blog/all-your-gucs-in-a-row-datasyncretry/).

**[PROPUESTA] Política para la app:**
- **EIO en `write` o `fsync`:** el archivo deja de ser fiable. No reintentar el fsync dando el resultado por bueno. Cerrar el archivo, marcar la toma como "posiblemente corrupta" y abrir un segmento nuevo en otro archivo si la captura debe continuar.
- **ENOSPC:** detener la escritura de forma ordenada. Los datos ya sincronizados son válidos. Avisar en la UI, conservar en RAM lo que quepa y ofrecer un destino alternativo.
- **Cadencia de fsync:** hacerlo periódicamente (por ejemplo cada N segundos) y no por bloque. Cuesta caro, como advierte la documentación de Microsoft.

---

## 2. DSP y reducción de ruido

### 2.1 Sistemas analógicos: parámetros

**Advertencia general:** no fue posible acceder a los papers JAES, a los manuales de servicio ni a worldradiohistory. Los datos siguientes vienen de fuentes secundarias y patentes. Una emulación "compatible" de estos sistemas no es fiel sin las curvas oficiales de Dolby.

**Dolby B**
- **Reducción máxima:** ~10 dB en alta frecuencia. La mayoría de fuentes dicen "por encima de ~4 kHz", no 5 kHz.
- **Ganancia según nivel:** una señal de bajo nivel recibe +10 dB. A Dolby Level (+3 VU) no se modifica. Entre ambos la ganancia varía de forma continua. El nivel de control se mide sobre el contenido por encima de ~1 kHz. Fuentes: https://www.soundonsound.com/techniques/tape-noise-reduction, https://en.wikipedia.org/wiki/Dolby_noise-reduction_system.
- **Dolby Level de consumo:** 200 nWb/m (ANSI), equivalente a ~218 nWb/m DIN. El original era 185 nWb/m. Fuentes: Wikipedia y https://stereo2go.com/forums/goto/post?id=51519.
- **Arquitectura:** un estante paso-alto deslizante ("sliding band") en la cadena lateral.
  - La patente US 4,922,535 describe el elemento deslizante como "a variable low pass shelf characteristic that 'slides' downward as the DC control voltage increases".
  - El lazo de control incluye filtros paso-bajo de ~800 Hz, ~1,6 kHz y ~400 Hz más el suavizado que fija ataque y relajación.
  - Fuente: https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4922535
- **Datos que no encontré:** el umbral exacto en dB y las constantes de tiempo **[NO VERIFICADO]**. La patente US 4,068,139 indica que el NE545 no cumple con precisión el estándar Dolby B.
- **Topología [DE MEMORIA]:** Dolby B/C son de doble camino. El codificador suma la salida de la cadena lateral a la señal. El decodificador pone la misma cadena lateral en realimentación negativa, de modo que es el complemento exacto si los niveles están calibrados. **Implicación:** un decodificador digital necesita calibrar el nivel (tono a Dolby Level) para seguir bien.

**Dolby C**
- Hasta 20 dB de reducción, con el mismo principio que B pero con curvas distintas.
- Dos etapas escalonadas. Las fuentes más citadas describen una etapa baja fija y una alta deslizante.
- Actúa desde ~100 Hz. Unos 15 dB a 400 Hz y unos 20 dB entre 2 y 10 kHz.
- **Spectral skewing:** atenuación en grabación por encima de ~10 kHz antes del compander, y la inversa en reproducción.
- **Anti-saturación:** estante de alta frecuencia desde ~2 kHz que solo actúa a nivel alto.
- Más sensible a errores de alineación que B.
- Fuentes: https://stason.org/TULARC/entertainment/audio/pro/4-3-What-is-the-difference-between-Dolby-A-B-C-S-and-S.html, https://www.manualsdir.com/manuals/75729/denon-drm-555.html?page=15, patente https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4473852.

**Dolby S**
- Derivado de SR. Hasta 24 dB (SR ~25 dB). Compatible con reproducción en B.
- Combina bandas fijas y deslizantes ("Action Substitution"). El umbral está 25 dB por debajo del Dolby Level.
- En alta frecuencia usa dos etapas de 12 dB con umbrales escalonados.
- Fuentes: https://www.muzines.co.uk/articles/dolby-s-explained/2897, https://www.rapmag.com/a/93/feb93/radio-systems-rs2-noise-reduction-phase-correction-review.
- La cifra de ~10 dB en graves **[NO VERIFICADO]**.

**Dolby (Ray Dolby, JAES, octubre de 1967)**
- "An Audio Noise Reduction System" (Dolby A): cuatro bandas, compresores de bajo nivel, ~10 dB.
- Registro AES: https://aes2.org/publications/elibrary-page/?id=1083. El volumen 15 **[NO VERIFICADO]**.

**dbx Tipo I y Tipo II**
- Compansión lineal en dB 2:1 en grabación y 1:2 en reproducción, en todo el espectro, con pre-énfasis de alta frecuencia.
- **Tipo I:**
  - Pensado para medios con S/N ≥ 60 dB y respuesta ≥ 30 Hz–15 kHz a −3 dB.
  - Es sensible a errores de respuesta, fase y dropouts.
- **Tipo II:**
  - Para medios ruidosos y de banda limitada (casete, vinilo).
  - Más pre-énfasis en el detector y detección RMS.
  - La cadena de control recorta graves y agudos (solo el control, no el audio) para tolerar errores de respuesta.
- Los dos no son intercambiables.
- Fuentes: https://en.wikipedia.org/wiki/Dbx_(noise_reduction), http://audiotools.com/noise.html, https://www.soundonsound.com/techniques/tape-noise-reduction.
- Las constantes de tiempo y las curvas de énfasis exactas **[NO VERIFICADO]**.

**Telefunken High Com**
- Compander de banda ancha "2:1:2" con puntos de quiebre a alto y bajo nivel para reducir el bombeo.
- Reducción de 10 a 15 dB en graves y hasta ~20 dB(A) en agudos (las fuentes discrepan). High Com II es de banda deslizante.
- Fuentes: https://en.wikipedia.org/wiki/High_Com, patente https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4376916.

**JVC ANRS / Super ANRS**
- JVC afirmaba que ANRS era compatible con Dolby B en reproducción y que no infringía patentes de Dolby.
- Super ANRS añade extensión de headroom en alta frecuencia. Las fuentes discrepan sobre su compatibilidad.
- Fuente: https://cool.culturalheritage.org/byform/mailing-lists/arsclist/2002/06/msg00066.html.

**Philips DNL (Dynamic Noise Limiter)**
- Solo reproducción y no complementario (finales de los 60).
- Fuente: https://en.wikipedia.org/wiki/Dynamic_Noise_Limiter.
- La frecuencia de ~4,5 kHz **[NO VERIFICADO]**.

**DNR (National LM1894, hoy de TI)**
- No complementario y solo reproducción. Combina enmascaramiento psicoacústico y ancho de banda adaptativo.
- "10 dB effective tape noise reduction (CCIR/ARM)".
- Fuentes: https://www.ti.com/product/LM1894, nota AN-386.
- El rango de ancho de banda (~1–34 kHz) **[NO VERIFICADO]**.

**Dolby HX Pro**
- **No es reducción de ruido:** modula el bias durante la grabación según el contenido de alta frecuencia, para reducir el autoborrado.
- No requiere decodificación. Lo originó Bang & Olufsen (Jensen) y lo licenció Dolby.
- **Implicación para la UI:** no debe aparecer como modo de reproducción ni como "decodificador".
- Fuentes: https://www.sweetwater.com/insync/hx-pro/, https://www.manualslib.com/manual/4373903/Sony-Tc-Rx606es.html.

### 2.2 Biquads (RBJ Audio EQ Cookbook)

Fuente: https://www.w3.org/TR/audio-eq-cookbook (W3C Note, 8 de junio de 2021).

Los diseños se obtienen de prototipos analógicos por transformada bilineal, con compensación de warping en frecuencia y en ancho de banda.

**Variables comunes [DE MEMORIA, contrastado con el índice del documento]:**
- `w0 = 2π·f0/Fs`
- `α = sin(w0)/(2Q)`
- `A = 10^(dBgain/40)`, solo para peaking y shelving

**Peaking:**
- b0 = 1 + α·A, b1 = −2·cos w0, b2 = 1 − α·A
- a0 = 1 + α/A, a1 = −2·cos w0, a2 = 1 − α/A

**High-shelf:**
- b0 = A[(A+1) + (A−1)cos w0 + 2√A·α]
- b1 = −2A[(A−1) + (A+1)cos w0]
- b2 = A[(A+1) + (A−1)cos w0 − 2√A·α]
- a0 = (A+1) − (A−1)cos w0 + 2√A·α
- a1 = 2[(A−1) − (A+1)cos w0]
- a2 = (A+1) − (A−1)cos w0 − 2√A·α

Normalizar todos los coeficientes por a0.

**Direct Form II transpuesta (DF2T):**
- y = b0·x + s1
- s1 = b1·x − a1·y + s2
- s2 = b2·x − a2·y

DF2T es la forma preferida en coma flotante por su menor sensibilidad al redondeo. DF1 se recomienda en coma fija y cuando los coeficientes se modulan en línea. Fuentes: https://www.musicdsp.org/en/latest/Filters/275-direct-form-ii-biquad.html, https://www.dsprelated.com/glossary/biquad, https://docs.rs/crate/biquad/latest. **En la app:** para EQ estática en float64, usar DF2T, que es lo que hace `scipy.signal.sosfilt` **[DE MEMORIA]**. Si se modula, usar DF1 o SVF/TPT.

**Estabilidad:** con a0 = 1, los polos están dentro del círculo unidad si y solo si |a2| < 1 y |a1| < 1 + a2 (triángulo de estabilidad) **[DE MEMORIA; criterio general de polos en https://ccrma.stanford.edu/~jos/fp/Stability_Revisited.html]**. Comprobarlo cada vez que se recalculan coeficientes, y rechazar o limitar Q y ganancia.

**Frecuencia de muestreo:** los coeficientes dependen de Fs (w0 y prewarping). Hay que recalcularlos al cambiar Fs, y limitar f0 a menos de ~0,45·Fs. BS.1770 lo dice explícitamente para el K-weighting: otras Fs requieren otros coeficientes.

**Suavizado de parámetros (anti-zipper):**
- Interpolar linealmente los coeficientes de un biquad puede volverlo inestable.
- **Solución recomendada:** suavizar los parámetros de control (f0, Q, ganancia en dB) con un filtro de un polo y recalcular los coeficientes cada 16 a 32 muestras, o por bloque. Para modulación rápida, usar SVF/TPT.
- Fuentes: https://www.kvraudio.com/forum/viewtopic.php?p=7463248; Kalinichenko, DAFx 2006, "Smooth and Safe Parameter Interpolation of Biquadratic Filters", https://dafx.de/paper-archive/details/cHbRQjkBpxQWUgk-ihIVjQ.
- **Suavizador de un polo:** p ← p + (1 − e^(−1/(τ·Fs_ctrl)))·(target − p).

**Denormales:**
- Aparecen en colas de decaimiento de IIR y pueden costar hasta ~100 veces más (https://docs.cycling74.com/reference/gen_dsp_isdenorm/).
- Remedios: FTZ/DAZ (solo SSE), umbral `if |s| < 1e-30: s = 0`, o inyectar un DC diminuto (1e-20 a 1e-10, distinto en cada etapa; en un HPF con cero exacto en DC, aplicarlo a una toma de la línea de retardo). Fuente: https://lists.linuxaudio.org/archives/linux-audio-dev/2003-August/004579.html.
- NumPy no activa FTZ **[DE MEMORIA]**. En bucles Python o Numba con estado, limpiar el estado al final de cada bloque.

---

## 3. Exportación

### 3.1 RF64 / BW64

Fuentes: https://en.wikipedia.org/wiki/RF64; EBU Tech 3306 v1.1 (https://knowledgehub.ebu.ch/files/live/sites/tech/files/shared/tech/tech3306v1_1.pdf, no pude abrirla); ITU-R BS.2088 (BW64).

**Cabecera:**
- 'RIFF' pasa a ser 'RF64'.
- El tamaño de 32 bits se pone a 0xFFFFFFFF.
- Justo después de 'WAVE' va el chunk `ds64`, antes de `fmt `.

**Layout de `ds64` [DE MEMORIA, verificar con Tech 3306 Anexo]:**
- riffSize: uint64
- dataSize: uint64
- sampleCount: uint64
- tableLength: uint32
- table[]: {chunkId[4], chunkSize: uint64}
- chunkSize = 28 + 12·tableLength
- El campo de tamaño del chunk `data` también vale 0xFFFFFFFF.

**Patrón de streaming:** reservar al principio un chunk `JUNK` de 28 bytes de payload. Si al cerrar el archivo pasa de 4 GiB, convertir JUNK en `ds64` y RIFF en RF64.

**BW64 (BS.2088):** es casi idéntico, con id 'BW64' y los chunks `axml`/`chna`. EBU Tech 3306 v2 (2018) remite a BS.2088.

**libsndfile:**
- El formato 'RF64' está en la tabla de soundfile (subtipo por defecto PCM_16).
- No encontré en soundfile la opción de auto-downgrade `SFC_RF64_AUTO_DOWNGRADE` de libsndfile **[NO VERIFICADO]**.
- **[PROPUESTA]** Si la duración estimada (Fs·canales·bytes·segundos) puede superar ~4 GiB, abrir directamente en 'RF64'.

### 3.2 WAVE_FORMAT_EXTENSIBLE

Fuentes: https://learn.microsoft.com/en-us/windows/win32/api/mmreg/ns-mmreg-waveformatextensible; "Multiple channel audio data and WAVE files", https://learn.microsoft.com/pt-br/previous-versions/windows/hardware/design/dn653308(v=vs.85).

- `cbSize ≥ 22`.
- `wBitsPerSample` es el contenedor (múltiplo de 8). `wValidBitsPerSample` es menor o igual (ejemplo: 20 bits en un contenedor de 24).
- `dwChannelMask`: el bit 0 es FL, el bit 1 es FR, etc.
- `SubFormat`: `KSDATAFORMAT_SUBTYPE_PCM` o `KSDATAFORMAT_SUBTYPE_IEEE_FLOAT`.
- La recomendación de Microsoft de usarlo para más de 16 bits o más de 2 canales **[DE MEMORIA del documento dn653308]**.
- libsndfile lo gestiona con `WAVEX` o con `WAV` y `PCM_24`.

### 3.3 Escritura por bloques con soundfile

Fuente: https://raw.githubusercontent.com/bastibe/python-soundfile/master/soundfile.py

- Cada `SoundFile.write()` escribe en la posición actual, avanza y "enlarges the file if necessary". Por eso se puede escribir en bucle.
- `soundfile.blocks(file, blocksize, overlap, fill_value, out)` sirve para la lectura en streaming. `out=` permite reutilizar un buffer.
- `compression_level` va de 0,0 a 1,0 (FLAC/Ogg).
- `flush()` pasa los datos al sistema de archivos, no a disco.

### 3.4 ffmpeg por pipe

**Comando [PROPUESTA]:**
```
ffmpeg -hide_banner -loglevel error -f f32le -ar 48000 -ac 2 -i pipe:0 -c:a flac -compression_level 8 out.tmp.flac
```
- Para Vorbis: `-c:a libvorbis -q:a 6`.
- Para WavPack: `-c:a wavpack`.

`pipe:0` es la URL de stdin (https://python-ffmpeg.readthedocs.io/en/latest/examples/feeding-data-to-stdin/). Los nombres de encoder y opciones **[NO VERIFICADO en la doc de ffmpeg]**: confirmar con `ffmpeg -encoders`.

**Deadlock** (https://raw.githubusercontent.com/python/cpython/main/Doc/library/subprocess.rst):
- "Use communicate() rather than .stdin.write, .stdout.read or .stderr.read to avoid deadlocks due to any of the other OS pipe buffers filling up."
- `wait()` "will deadlock when using stdout=PIPE or stderr=PIPE" si el hijo llena el pipe.
- `communicate()` acumula todo en memoria ("do not use this method if the data size is large"), así que no sirve para hacer streaming de horas de audio.

**[PROPUESTA] Patrón:**
1. `stdout=DEVNULL`, porque la salida va a archivo.
2. `stderr` redirigido a un archivo temporal, o drenado por un hilo lector a un `deque(maxlen=200)`.
3. El hilo principal escribe bloques en `proc.stdin.write(...)`. Si recibe `BrokenPipeError`, ffmpeg ha muerto: leer el stderr guardado.
4. `proc.stdin.close()` para señalar EOF.
5. `proc.wait(timeout=T)`. Si lanza `TimeoutExpired`: `proc.kill()` y luego `proc.wait()`.
6. Comprobar `returncode == 0`.

La documentación dice que con `communicate(timeout)` el hijo no se mata al expirar el tiempo: hay que matarlo y volver a llamar a `communicate()`, nunca a `wait()`.

### 3.5 Publicación atómica y SHA-256

- Escribir `nombre.part` en el mismo directorio, luego fsync, `os.replace` y fsync del directorio (ver §1.4).
- Calcular el hash en streaming: `h = hashlib.sha256()` y `h.update(bloque)` por cada bloque escrito, o releyendo el archivo en trozos de 1 MiB tras el fsync. Releer verifica lo que realmente está en disco.
- Guardar el hash en un sidecar que se publica también con `os.replace`.

### 3.6 Loudness: EBU R128 / ITU-R BS.1770

**K-weighting a 48 kHz** (BS.1770, tablas 1 y 2: https://itu.int/dms_pubrec/itu-r/rec/bs/R-REC-BS.1770-1-200709-S!!PDF-F.pdf):
- **Etapa 1 (shelf):** b = [1.53512485958697, −2.69169618940638, 1.19839281085285], a = [1, −1.69065929318241, 0.73248077421585].
- **Etapa 2 (RLB):** b = [1, −2, 1], a = [1, −1.99004745483398, 0.99007225036621].

**Otras Fs:**
- libebur128 recalcula con BLT: shelf con f0 = 1681.97 Hz, G ≈ +4 dB, Q ≈ 0.7072; HPF con f0 ≈ 38.14 Hz, Q ≈ 0.5003; K = tan(π·f0/Fs). Fuente: https://raw.githubusercontent.com/jiixyj/libebur128/master/ebur128/ebur128.c.
- pyloudnorm usa shelf de 4 dB, Q = 1/√2 y 1500 Hz, y HPF de 38 Hz con Q = 0,5. Fuente: https://raw.githubusercontent.com/csteinmetz1/pyloudnorm/master/pyloudnorm/meter.py.
- **Recomendación:** preferir los parámetros de libebur128, que reproducen la respuesta de 48 kHz con más exactitud.

**Gating:**
- Bloques de 400 ms con 75 % de solape (salto de 100 ms).
- Loudness de bloque: l = −0,691 + 10·log10(Σ G_i·z_i). Pesos: G = 1 para L/R/C, 1,41 para los surround, 0 para LFE.
- Puerta absoluta: −70 LUFS.
- Puerta relativa: (loudness de los bloques que pasan la puerta absoluta) − 10 LU.
- Integrado = −0,691 + 10·log10 de la media de las energías (z) de los bloques que pasan ambas puertas.

**Objetivos R128:**
- −23 LUFS, ±0,5 LU (±1 LU en directo, revisión de 2023).
- True peak máximo −1 dBTP.
- Momentary = 400 ms y short-term = 3 s según EBU Tech 3341 **[DE MEMORIA]**.
- Fuente: https://tech.ebu.ch/docs/r/r128-2014.pdf.

**Normalización en dos pasadas [PROPUESTA]:**
1. Primera pasada en streaming: acumular energías por bloque de 100 ms (sub-bloques) para construir los bloques de 400 ms, y medir el true peak.
2. Ganancia: g_dB = objetivo − integrado, limitada a (techo_TP − TP_medido).
3. Segunda pasada: aplicar la ganancia al exportar.

**True peak (Anexo 2):**
- Sobremuestreo ×4 a 48 kHz.
- **[DE MEMORIA]** FIR de 48 coeficientes en 4 fases de 12, con atenuación opcional de 12,04 dB para coma fija.
- libebur128 usa un FIR de 49 taps (sinc con ventana de Hann): ×4 por debajo de 96 kHz, ×2 hasta 192 kHz, nada desde 192 kHz.
- Debe mantener estado entre bloques: las últimas 11 o 12 muestras por canal.

### 3.7 Remuestreo en streaming

**Limitación de SciPy:** `scipy.signal.resample_poly` asume ceros fuera de la señal (`padtype`) y no guarda estado. Procesar por bloques produce transitorios en cada frontera. Fuente: https://docs.scipy.org/doc/scipy-1.5.4/reference/generated/scipy.signal.resample_poly.html.

**Diseño polifásico con estado [PROPUESTA]:**
1. Reducir la razón L/M con gcd.
2. Diseñar un prototipo de K·L taps para la tasa L·Fs.
3. Mantener un historial de K−1 muestras de entrada y una fase entera φ ∈ [0, L).
4. Cada muestra de salida usa la fase φ. Luego φ += M; mientras φ ≥ L: φ −= L y se avanza una muestra de entrada.

**Contabilidad exacta de frames:** total_out = ⌊(N_in·L + φ0)/M⌋, con φ0 la fase inicial. Llevar contadores enteros de 64 bits, nunca floats acumulados. Al final: vaciar el historial con ceros y recortar según el retardo de grupo (K·L−1)/2 a la tasa alta.

**Alternativas:** MatX ofrece un `resample_poly_stream` equivalente al de una sola pasada (https://nvidia.github.io/MatX/api/signalimage/streaming/resample_poly_stream.html). python-soxr (`ResampleStream`) y python-samplerate tienen API con estado **[DE MEMORIA, verificar]**.

---

## 4. Medición, UI e ITL

**VU (ANSI C16.5, IEC 60268-17, BS 6840)**
- Llega al 99 % en 300 ms ±30 ms ante un escalón a 0 VU, con un sobreimpulso del 1 al 1,5 % (norma ASA de 1954).
- 0 VU = +4 dBu (1,228 V en 600 Ω) en estudio.
- Fuentes: https://en.wikipedia.org/wiki/VU_meter, https://jontalle.web.engr.illinois.edu/Public/Allen-pdf/LobdellAllen07.pdf.
- **[PROPUESTA]** Emulación: rectificación de onda completa más un sistema de 2.º orden con ζ ≈ 0,8. Aproximación con un polo: τ ≈ 0,3/ln(100) ≈ 65 ms.

**PPM (IEC 60268-10)**
- **Tipo I (DIN):**
  - Integración de 5 ms, definida como la duración de una ráfaga de 5 kHz que marca 2 dB por debajo de la referencia.
  - Retorno de 20 dB en 1,7 s (algunas tablas dicen 1,5 s), ≈ 11,8 dB/s.
- **Tipo II (BBC IIa / EBU IIb):**
  - Integración de 10 ms.
  - Retorno de 24 dB en 2,8 s ≈ 8,6 dB/s.
- Fuentes: https://en.wikipedia.org/wiki/Peak_programme_meter, https://dhd.audio/?p=16330. Las discrepancias (5 frente a 10 ms, 1,5 frente a 1,7 s) se deben verificar contra la norma.

**Medidor de pico digital (IEC TR 60268-18:1995)**
- Especifica tiempo de retardo y tiempo de retorno, pero no obtuve los valores **[NO VERIFICADO]**.
- Fuente: https://webstore.iec.ch/publication/1217.

**Pico de muestra frente a true peak**
- El pico de muestra subestima los picos entre muestras. Usar el detector ×4 de §3.6 para la medida "dBTP".

**[PROPUESTA] Peak-hold basado en tiempo**
- Mantener el valor pico durante 1–2 s.
- Después decaer a la velocidad elegida: `nivel = max(nuevo, hold − rate·Δt)`, con Δt medido con un reloj monotónico, no con el intervalo nominal del timer.

**Waveform overview**
- **audiowaveform/BBC:** pares (min, max) por canal, con `samples_per_pixel` fijado al generar. No se puede ampliar más allá del nivel generado. Fuente: https://github.com/face08/audiowaveform/blob/master/doc/DataFormat.md.
- **Audacity:** resúmenes (min, max, rms) cada 256 y cada 65 536 muestras. Al dibujar elige el de 65 536 si spp ≥ 65 536, el de 256 si spp ≥ 256, y si no las muestras crudas. Fuente: https://doxy.audacityteam.org/_get_wave_display_8cpp_source.html.
- **[PROPUESTA]**
  - Generar la pirámide de forma incremental durante la captura. Los niveles gruesos se obtienen exactamente como el mínimo de los mínimos y el máximo de los máximos.
  - Dibujar una línea vertical de min a max por columna.

**Qt 6**
- Un QObject "vive" en el hilo donde se creó. Sus eventos los despacha el bucle de eventos de ese hilo. `moveToThread` no funciona con objetos que tienen padre. Fuente: https://doc.qt.io/qt-6.9/threads-qobject.html.
- AutoConnection decide en el momento del emit: directa si el receptor está en el mismo hilo, encolada si no **[secundario]**.
- No tocar widgets fuera del hilo GUI. Los hilos de audio y E/S se comunican por señales encoladas o colas sondeadas por un QTimer.
- **QTimer:**
  - El tipo por defecto es CoarseTimer, que puede adelantarse hasta un 5 % del intervalo.
  - PreciseTimer apunta a 1 ms y nunca se adelanta.
  - Si se pierden varios timeouts, emite uno solo.
  - QChronoTimer (6.8+) tiene resolución de ns.
  - Fuente: https://doc.qt.io/qt-6/qtimer.html.
- **QElapsedTimer:** desde Qt 6.6 se apoya en `std::chrono::steady_clock` (MonotonicClock). Equivale en Python a `time.monotonic_ns()`. Fuente: https://doc.qt.io/qt-6/qelapsedtimer.html.

**Logging con cola acotada**
- `QueueHandler.enqueue` usa `put_nowait`. Con `queue.Queue(maxsize)` llena, lanza `queue.Full`, que `emit` desvía a `handleError`. Eso imprime un traceback a stderr si `logging.raiseExceptions` está activo: es costoso y ruidoso.
- `prepare()` formatea y copia el record, y elimina `args` y `exc_info`.
- `QueueListener` bloquea en `get`, admite `respect_handler_level` y funciona como gestor de contexto.
- `stop()` encola un centinela. Su docstring advierte que pueden quedar records sin procesar.
- Fuente: https://raw.githubusercontent.com/python/cpython/main/Lib/logging/handlers.py.
- **[PROPUESTA]** Subclase de `QueueHandler` cuyo `enqueue` haga `put_nowait` y, ante `queue.Full`, incremente `dropped` sin propagar. El listener emite periódicamente "N registros descartados". No hacer logging desde el callback de audio: usar contadores.

**Casete**
- C60 = 30 min por cara, C90 = 45, C120 = 60. Velocidad de 4,76 cm/s (1⅞ ips).
- Fuentes: https://en.wikipedia.org/wiki/Cassette_tape, https://www.jas-audio.or.jp/journal-pdf/2012/05/201205_017-028.pdf.
- La tolerancia de velocidad de IEC 60094-1/-7 **[NO VERIFICADO]**: las normas son de pago.
- **[PROPUESTA]** Prever una duración real de más o menos un 2–3 % y no cortar la captura por la duración nominal. Los C60 reales suelen durar unos 31–32 min por cara **[DE MEMORIA]**.

---

## 5. Scrub, varispeed y seek

**Crossfades**
- Fink, Holters y Zölzer (DAFx-16): las señales no correlacionadas se funden con potencia constante (−3 dB en el centro: g_a = cos(πt/2), g_b = sin(πt/2)). Las correlacionadas, de forma lineal (−6 dB: 1−t, t).
- Son reglas prácticas. El paper deriva curvas a partir de la correlación medida r: más ganancia en el centro cuando r < 0, y r = −1 requiere ganancia infinita.
- Fuente: https://www.hsu-hh.de/ant/wp-content/uploads/sites/699/2017/10/Fink-Holters-Zölzer-2016-Signal-matched-power-complementary-cross-fading-and-dry-wet-mixing.pdf.
- Q-SYS: lineal = −6 dB ("constant gain"), que deja un hueco de 3 dB con señales no correlacionadas.
- **[PROPUESTA]**
  - Para un seek dentro del mismo material (bucle o salto corto, señales muy correlacionadas): lineal, de 5 a 20 ms.
  - Para un salto a otro punto del programa (no correlacionado): potencia constante.
  - Opcional: estimar r sobre la ventana y elegir la curva según r.

**Paso por cero y declick**
- **[PROPUESTA]** Ajustar el punto de corte al paso por cero más cercano (dentro de ±N muestras) con la misma pendiente. Aun así, aplicar un micro-fade de ≥ 2 ms, porque en señales estéreo o con DC el cruce no coincide entre canales.

**Interpolación para varispeed**
- **Hermite de 4 puntos y 3.er orden (Catmull-Rom)** (Niemitalo, "Polynomial Interpolators for High-Quality Resampling of Oversampled Audio", yehar.com/blog/wp-content/uploads/2009/08/deip.pdf, citado en https://www.dsprelated.com/showcode/3.php). Con t ∈ [0, 1) entre y0 e y1:
  - c0 = y0
  - c1 = ½(y1 − y−1)
  - c2 = y−1 − 2,5·y0 + 2·y1 − ½·y2
  - c3 = ½(y2 − y−1) + 1,5(y0 − y1)
  - out = ((c3·t + c2)·t + c1)·t + c0
- Rockbox lo adoptó como una mejora grande frente a la interpolación lineal y con poco coste. Fuente: https://git.lenord.me/devs/foxbox/src/commit/1f76edabf9dca3b1cb25de77f6572a12370e35c4/lib/rbcodec/dsp/resample.c.
- **Sinc con ventana (J. O. Smith):** evalúa la señal en cualquier instante fraccionario con un único paso-bajo y admite una razón que varía suavemente en el tiempo. Fuente: https://ccrma.stanford.edu/~jos/resample/.
  - **[DE MEMORIA]** Si velocidad > 1, escalar el kernel (fc = 1/velocidad) para evitar aliasing.
- **Posición de lectura:** índice entero (int64) más fracción en float64, o en coma fija de 32.32. Avanzar `pos += speed` por muestra de salida. Suavizar `speed` con un filtro de un polo de ~10 a 30 ms para evitar escalones de pitch.

**DAWs**
- **Ardour:** Shuttle Speed Control en modo "sprung" (scrub solo mientras se pulsa) y modo "wheel" (velocidad fija hasta Stop). VariSpeed fija la velocidad en semitonos (×2^(1/12) ≈ 105,9 %), cents o porcentaje. Fuente: https://manual.ardour.org/ardours-interface/the-transport-bar/.
- **Mixxx:**
  - Usa `EngineBufferScaleLinear` (interpolación lineal) para el scratch, porque los time-stretchers no sirven con tempo que cambia rápido.
  - En 2025 añadió un remuestreador sinc con tres calidades.
  - Documenta jitter por la latencia MIDI y deriva ("sticker drift").
  - Fuentes: https://mixxx.org/news/2025-08-04-gsoc-2025-report-armaan-chowfin/, https://github.com/mixxxdj/mixxx/wiki/gsoc-2023-ideas.

**Rubber Band**
- `OptionProcessRealTime` para tiempo real (solo `process()`).
- Motor R3 (`OptionEngineFiner`): más calidad y mucho más CPU. R2 sigue siendo el predeterminado.
- Las opciones desconocidas se ignoran en silencio: comprobar con `getEngineVersion()`.
- Licencia GPL v2 o posterior, o licencia comercial obligatoria para distribuir con otros términos.
- Fuentes: https://breakfastquay.com/rubberband/code-doc/classRubberBand_1_1RubberBandStretcher.html, https://breakfastquay.com/news/20220707.html.
- **Implicación:** úsese solo si cambiar el tempo sin cambiar el pitch es un requisito. Para el scrub tipo cinta, el varispeed por remuestreo es lo correcto.

**Contadores de generación (descartar buffers obsoletos)**
- ffplay: cada flush de la cola de paquetes incrementa `serial`. Cada paquete o frame lleva el serial vigente. Los que no coinciden se descartan en cuanto se empuja el flush.
- Fuentes: https://ffmpeg.org/pipermail/ffmpeg-cvslog/2012-October/056050.html, https://lists.ffmpeg.org/pipermail/ffmpeg-devel/2013-January/137683.html, https://ffmpeg.org/pipermail/ffmpeg-devel/2018-August/233691.html.
- **[PROPUESTA]**
  - `epoch` entero que se incrementa en cada seek o cambio de dirección.
  - El lector de disco etiqueta cada bloque con (epoch, posición).
  - El callback descarta los bloques con `epoch != current`, aplica un fade-out de 2 a 5 ms al último bloque válido y un fade-in al primero de la nueva epoch.

**Detección automática de pops para tests [PROPUESTA, apoyada en la literatura]**
- La literatura trata los clicks como outliers del residuo de un modelo AR. Godsill y Rayner usan tramas de 2048 muestras, orden 10 a 40 y umbral 4 a 8 veces la desviación del residuo (https://sigproc.eng.cam.ac.uk/Main/SJGSpringer). Essentia ofrece `ClickDetector` (https://essentia.upf.edu/reference/std_ClickDetector.html).
- **Test simple para discontinuidades de transporte:**
  - d2[n] = x[n] − 2x[n−1] + x[n−2]. Marcar un pop si |d2| > k·MAD(d2) local, con k ≈ 8–10.
  - Alternativa: |Δx| > 2π·f_max·A_pico/Fs + margen (cota de pendiente de una señal limitada a f_max).
- Usar señales de prueba de seno puro (por ejemplo 1 kHz a −6 dBFS): cualquier salto de seek sin crossfade dispara el detector.
- Contabilizar los pops por cada 1000 seeks en CI.

---

**Huecos que conviene cerrar con documentos de pago o PDFs no accesibles desde aquí:**
- Constantes de tiempo y umbrales exactos de Dolby B/C/S (manuales de servicio y hojas de datos NE545/NE645 y LM1112).
- Curvas de dbx Tipo II.
- Valores de IEC 60268-18 y de la tolerancia de velocidad de IEC 60094.
- Tabla de coeficientes del Anexo 2 de BS.1770-5.
- Layout exacto de `ds64` en Tech 3306 / BS.2088.
- Disponibilidad de `SFC_RF64_AUTO_DOWNGRADE` en python-soundfile.