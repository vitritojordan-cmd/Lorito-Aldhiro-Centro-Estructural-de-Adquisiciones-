# RT_CONTRACT.md — contrato del tiempo real (captura y reproducción)

Revisión de las Órdenes Golden 0.11.001 (Captura CAP-001/005, Scrubs SMV-02/
SMV-10, Instrumentación LOG-02). **Sustituye** la versión de la Fase 16 de
la Orden de Saneamiento, que describía un `RingBufferAbsorcion` con
`threading.Condition` y modo *overwrite-oldest*, dos comportamientos que
quedan retirados (ver §Historia).

Fundamento: la cabecera de PortAudio prohíbe en el callback "allocate
memory, access the file system, call library functions or call other
functions … that may block or take an unpredictable amount of time"
(REFERENCIAS_INVESTIGACION_TECNICA.md §1.1).

## 1. Callbacks RT del proyecto

| Callback | Archivo | Qué hace | Qué NO hace |
|---|---|---|---|
| Captura `_audio_callback` | `backend/capture/lorito_capture_engine.py` | copia el bloque al slot del `SPSCCaptureRing` y lo publica; anota flags de status (overflow/underflow) en contadores | locks, `Condition`, espera por consumidor, I/O, logging, forenses, DSP, medición de nivel |
| Reproducción `_audio_cb` | `backend/playback/lorito_playback_engine.py` | copia frames de bloques ya renderizados del ring SPSC; descarta generaciones por debajo del mínimo válido; rellena silencio declarado en underrun; actualiza cursor audible y contadores | lecturas de disco, resampleo, crossfades, logging, `_frn_emit`, locks, `try/except`, asignaciones grandes (verificado por análisis AST en `tests/test_transport_golden.py` SMV-T09) |
| Monitor `_MonoRingBuffer` | `backend/playback/lorito_monitor_engine.py` | SPSC sin locks; cuenta frames descartados | bloquear |

## 2. Rings SPSC

- Un productor y un consumidor; cada índice tiene un único escritor.
- Slots preasignados. El productor completa el slot y **después** publica el
  índice. Copiar antes de publicar es obligatorio porque NumPy puede liberar
  el GIL en copias grandes.
- Nunca se sobrescribe ni se trunca: si no hay hueco, el resultado es
  explícito (`RING_FULL` en captura y fail-stop; underrun contado en
  reproducción).
- **Límite declarado**: la ausencia de locks se apoya en el GIL de CPython.
  En el build *free-threaded* no hay garantía documentada de orden de memoria
  para un ring en Python puro. `LOCK_FREE_VERIFIED` lo indica en ejecución y
  no se presenta como verificado.

## 3. Medición

- Captura: duración por callback contabilizada fuera del camino crítico
  (contadores de inanición separados por tipo, sin doble conteo — CAP-006/007).
- Reproducción: duración de cada callback en un array preasignado de 4096
  muestras. Los percentiles p50/p95/p99/p99.9/máx y los *deadline misses*
  frente a `PE_BLOCKSIZE / fs` se calculan **fuera** del callback
  (`transport_snapshot()["callback_timing"]`).
- Ningún log se emite dentro de un callback. La bitácora forense
  (`ForensicEventLog`) usa cola acotada; los eventos P0 no se descartan.

## 4. Lo que no se puede afirmar sin hardware

En este entorno el driver es un stub funcional, así que el timing medido
corresponde a ese stub. Los deadline misses reales con una interfaz física,
la prioridad RT del sistema operativo y la convivencia con PipeWire/JACK
quedan en las puertas pendientes (ORDENES_GOLDEN_0_11_ESTADO.md).

## Historia

- Fase 16 (Saneamiento): `RingBufferAbsorcion.write()` con
  `threading.Condition` y overwrite-oldest. **Retirado** (CAP-001/002).
- GAP-031: `LockFreeSPSCRingBuffer` verificado en aislamiento. Lo sustituye
  `SPSCCaptureRing`, integrado en producción.
- GAP-037: `resample_stateful_continuous`. El reproductor ya no lo usa
  (cursor absoluto en `VariableRateReader`); queda para la exportación.
- GAP-034: `GenerationGuard` aislado. Integrado ahora como etiquetado de
  generación en ambos rings.
