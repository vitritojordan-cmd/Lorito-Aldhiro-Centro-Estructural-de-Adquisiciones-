# SCRUBS_TRANSPORT_ARCHITECTURE_GOLDEN.md — Scrubs Morpher / Velocista / Seek

Orden: *Refundación de Scrubs Morpher, Velocista y Seek* (SMV-01…SMV-14),
Lorito Aldhiro 0.11.001. Mandato: una autoridad única de transporte, una
línea temporal coherente y pruebas acústicas objetivas, no más parches de
crossfade.

## 1. Qué se retiró

Del motor anterior (`PlaybackEngine` v1.0) se retiraron:

- el protocolo ad hoc de eventos (`_seek_evt`, `_speed_change_evt`,
  `_flush_req_evt`/`_flush_ready_evt`), el `snap_pos`/`head_pos`, el
  hot-swap de deques y el `_SpeedState` compartido;
- los debounces heurísticos (`PE_SPEED_DEBOUNCE`, `PE_LIVE_DEBOUNCE`);
- `_make_xfade_blk` (crossfade dinámico con eventos forenses en plena
  transición) y el "fade-in de 16 frames" presentado como anti-pop;
- `_resample_stateful` (resampleo por chunks con deriva y la "zona neutra"
  que congelaba el cursor) y el estado forense global
  `_frn_state['phase_prev_cursor']`;
- en la GUI, las escrituras directas a `_ss.snap_pos`/`last_head_snap`, el
  `_speed_change_evt.clear()` y el "matar el stream y crear otro motor"
  (`_muted`/`_stop_evt`) en cada reposicionamiento.

## 2. Hilos y colas

```
 GUI (Qt)                         hilo pe-render (no-RT)                      callback RT (PortAudio)
 ─────────                        ───────────────────────                     ───────────────────────
 Velocista  ─┐                    drena comandos EN ORDEN                     copia frames del slot r
 Morpher    ─┼─ TransportTransaction ─► TransportMachine (estado/generación)   descarta tgen < min_valid
 Seek bar   ─┤   (deque, sin lock)     SpeedPlanner (slew de ratio)           silencio declarado si r == w
 Stop       ─┘                         VariableRateReader (cursor absoluto)   cursor audible, contadores
                                       TransitionPolicy (rampas precalc.)     timing en array preasignado
                                       publica bloque etiquetado ──► ring SPSC (16 × 512 frames) ──►
 transport_snapshot() ◄── cursores, ledger, transacciones, timing (copias, sin lock)
```

- **Comandos**: `collections.deque` (append y popleft atómicos bajo el
  GIL). Cada comando es una `TransportTransaction` con `command_id`
  monotónico.
- **Ring audible**: 16 slots preasignados de 512 frames con metadatos por
  slot:
  - generación de sesión y de transporte (`tgen`) y `epoch` de ratio;
  - frames de fuente inicial y final y ratio final;
  - flags (`END`, `TRANSITION`, `DEGRADED`) y RMS por canal para el VU.
- **Lead**: el render mantiene `PE_TARGET_LEAD = 6` bloques por delante,
  unos 64 ms a 48 kHz. Esa es la latencia máxima de un comando.

## 3. Autoridad única (SMV-01, SMV-12)

`TransportMachine` (estado, dirección y generaciones) y `SpeedPlanner`
(ratio deseado → aplicado → renderizado) viven **dentro** del hilo de render
y son la única fuente de verdad. La GUI emite comandos semánticos
(`seek_to`, `set_speed_live`, `set_speed_live_noflush`, `set_speed`,
`request_stop`) y lee el cursor audible (`src_pos`).

## 4. Semántica de corte

Un comando surte efecto en la **cabeza de escritura** del ring. El audio ya
encolado (como mucho el lead) se reproduce íntegro: era válido para la
generación vigente al publicarse. Nunca se vacía la cola por debajo del
callback, así que no puede aparecer un bloque viejo **después** de uno
nuevo. Los contadores `mixed_generation_events` y
`stale_dropped_before_ring` lo vigilan (las pruebas exigen 0).

## 5. Lector de velocidad variable (SMV-07, SMV-10, SMV-13)

`VariableRateReader`:

- usa un cursor absoluto en float64 e interpolación Catmull-Rom con vecinos
  reales del archivo (caché de 65 536 frames);
- aplica una rampa de ratio por muestra dentro de cada bloque;
- la reversa es continua a través de ratio 0;
- con ×1 y cursor entero, la copia es bit-exacta;
- no tiene "zona neutra": con 0,999, 1,000 y 1,001 el cursor avanza
  exactamente la suma de los ratios.

## 6. Transiciones (SMV-02, SMV-03, SMV-04, SMV-09)

Ver AUDIO_TRANSITION_POLICY.md. Las rampas se calculan una vez y se aplican
en el render. Velocidad, Morpher y reversa son **continuos** (sin
transición). Seek usa DIP sin mezclar audio no adyacente. EOF y STOP
terminan con fundido. Cualquier transición truncada se declara DEGRADADA.

## 7. Evidencia

- `tests/test_transport_golden.py`: SMV-T01…T10, más la política de seek
  medida, el STOP con fundido, el orden determinista y la ausencia de
  estado forense global.
- `tests/test_resample_continuity*.py`: contrato del lector con señal
  sintética y con audio real.
- Pruebas heredadas adaptadas: integración, inyección de fallos y
  Captura→Reproducción.
- Banco: `tools/bench_transport_discontinuity.py` → POP_DISCONTINUITY_BENCH.md.

Informe: POP_DISCONTINUITY_TEST_REPORT.md.
