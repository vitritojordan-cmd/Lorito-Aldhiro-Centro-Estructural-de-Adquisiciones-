# TRANSPORT_COMMAND_CONTRACT.md — Contrato de comandos de transporte

Código: `backend/playback/lorito_playback_engine.py` (API),
`backend/transport/lorito_transport_ledger.py` (transacciones),
`backend/transport/lorito_transport_machine.py` (estados).

## 1. Transacción

Cada llamada de la UI crea una `TransportTransaction`:

| Campo | Significado |
|---|---|
| `command_id` | entero monotónico global |
| `kind` | `SEEK`, `LIVE`, `COMMIT`, `STOP` |
| `value` | frame destino (SEEK) o ratio con signo (LIVE/COMMIT) |
| `source` | origen semántico (`SEEK`, `LIVE`, `ELASTIC`, `COMMIT`, `UI`) |
| `session_generation` | sesión de reproducción |
| `transport_generation` | se asigna al aplicar |
| `status` | `PENDING` → `APPLIED` → `CONFIRMED`, o bien `SUPERSEDED`/`REJECTED` |
| `t_submit`, `t_apply`, `t_confirm` | instantes monotónicos |

**Confirmación**: un comando pasa a `CONFIRMED` cuando el primer bloque
renderizado tras aplicarlo queda publicado en el ring audible. Cuando el
callback alcanza ese bloque, `audible_generation` y `audible_frame` lo
reflejan.

## 2. Comandos

| API | Kind | Semántica | Generación | Transición |
|---|---|---|---|---|
| `seek_to(frame)` | SEEK | reposiciona el cursor al destino (acotado a `[0, total−1]`); conserva ratio y dirección | nueva (máquina: SEEKING → SEEK_DONE en el mismo bloque) | DIP (por defecto) |
| `set_speed_live(r)` | LIVE | arrastre de Velocista o Morpher; `r` con signo (negativo = reversa) | nueva solo al **entrar** en SPEED_LIVE | CONTINUA (slew) |
| `set_speed_live_noflush(r)` | LIVE (`source=ELASTIC`) | retorno elástico del Morpher; mismo efecto que LIVE | ídem | CONTINUA |
| `set_speed(r)` | COMMIT | soltar el Velocista o convergencia final del Morpher; fija el ratio confirmado | nueva (SPEED_COMMIT) | CONTINUA (slew) |
| `request_stop()` | STOP | detención no bloqueante (GUI) | nueva (STOPPING) | FADE_OUT_END tras el audio encolado |
| `stop()` | STOP | igual, pero espera el cierre (`PE_STOP_TIMEOUT` = 1,5 s; después corte duro declarado) | ídem | ídem |
| `start(...)` | — | sesión nueva; `stop()` previo | sesión +1 | — |

Ratio: se acota a `±PE_MAX_RATIO` (4,0); un valor no finito se convierte en
1,0. La velocidad de cambio está limitada por `PE_SLEW_PER_S` (8 unidades
de ratio por segundo).

## 3. Orden, coalescing y supersesión (SMV-05, SMV-14)

- Los comandos se aplican **en orden de llegada**; `commands_out_of_order`
  debe ser 0.
- Varios LIVE en un mismo drenaje se combinan explícitamente: solo cuenta el
  último deseado y se suma `live_coalesced`.
- Un SEEK todavía no renderizado queda `SUPERSEDED` si llega otro SEEK o un
  STOP. Es determinista: no hay ventanas de tiempo.
- Una transición inválida para el estado actual se registra como `REJECTED`
  con su causa y nunca se aplica en silencio.

## 4. EOF y reversa

- Adelante: al pasar el último frame, el bloque final se cierra con
  FADE_OUT_END, se publica el marcador `END` y el callback termina el
  stream; se llama a `on_done`.
- Reversa: lo mismo al llegar al frame 0.
- La dirección es el signo del ratio aplicado y cambia de forma continua a
  través de 0, sin generación nueva ni corte.

## 5. Garantías verificadas

`stale_consumed = 0`, `mixed_generation_events = 0`,
`commands_out_of_order = 0`, `stale_dropped_before_ring = 0`, y
`submitted = applied + superseded + rejected`. Ver
`tests/test_transport_golden.py`.
