"""Paquete Lorito Aldhiro Studio — modularizacion mecanica del monolito original."""
