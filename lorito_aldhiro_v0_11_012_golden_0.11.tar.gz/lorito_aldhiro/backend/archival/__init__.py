"""
lorito_aldhiro.backend.archival — clasificación de integridad
post-sesión de una captura (Fase 7 de la Orden Maestra de Saneamiento
Pre-Auditoría Aldhira Phonographic).

Rama del árbol de módulos de Lorito Aldhiro (ver GAP-032). Subsistema
CONSTRUIDO DESDE CERO esta sesión (GAP-033) — no existía ninguna
máquina de estados ARCHIVAL_SAFE/DEGRADED/INVALID en el código
anterior; solo existían constantes de rendimiento de GUI con nombre
parecido (`ARCHIVAL_SAFE_FPS`/`ARCHIVAL_SAFE_WATCHDOG`,
`lorito_constants.py`), sin relación con integridad de sesión.

Módulos:
  · lorito_archival_state — `ArchivalState` (enum), `classify_session()`.
  · lorito_segment_checksum — `compute_segment_checksum()`/
    `verify_segment_checksum()` (GAP-035): checksums SHA-256/CRC32
    reales por segmento, calculados releyendo el archivo ya cerrado
    desde disco — la conexión real que le da sentido a la detección de
    corrupción que `_IntegrityMonitor` (GAP-032) nunca tuvo.
"""

from lorito_aldhiro.backend.archival.lorito_archival_state import (
    ArchivalState, ArchivalClassification, classify_session,
)
from lorito_aldhiro.backend.archival.lorito_segment_checksum import (
    compute_segment_checksum, verify_segment_checksum,
)

__all__ = [
    "ArchivalState", "ArchivalClassification", "classify_session",
    "compute_segment_checksum", "verify_segment_checksum",
]
