from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Selección y abstracción del backend de audio real (PortAudio/sounddevice).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import shutil
import subprocess
import threading
from enum import Enum, auto

from lorito_aldhiro.backend.core.lorito_app_logging import _log



# ══════════════════════════════════════════════════════════════════════════════
#  NORMALIZACIÓN AVANZADA v0.20 — 7 modos integrados al monolito CRAC
#  Todos los algoritmos se ejecutan FUERA del callback RT, en el pipeline de
#  exportación (hilo background). Cero impacto en captura en tiempo real.
#  Diseño streaming-friendly: sin cargar el archivo completo en RAM cuando
#  se requiere análisis previo (RMS, LUFS, Noise-aware, True Peak).
# ══════════════════════════════════════════════════════════════════════════════

class NormalizationMode(Enum):
    """
    Modos de normalización disponibles en CRAC v0.20.
    Valor = etiqueta de texto del QComboBox (norm_box) para compatibilidad directa
    con la serialización de snapshots/crash-manifest existente (campo "norm").
    """
    NONE             = "Sin normalizar"
    PEAK_SIMPLE      = "Norm -0.2 dBFS"          # modo heredado — peak simple
    RMS_20           = "RMS -20 dBFS"
    RMS_18           = "RMS -18 dBFS"
    RMS_14           = "RMS -14 dBFS"
    LUFS_23          = "LUFS -23 (broadcast)"
    LUFS_16          = "LUFS -16 (streaming)"
    LUFS_14          = "LUFS -14 (podcast)"
    INTELLIGENT_PEAK = "Peak inteligente"
    TRUE_PEAK        = "True Peak (x2)"
    TRUE_PEAK_X4     = "True Peak (x4)"
    PRESERVATIVE     = "Preservativa"
    NOISE_AWARE      = "Noise-aware"
    ADAPTIVE_BLOCK   = "Adaptativa por bloques"
    # ── CRAC 0.20 — nuevos modos de cierre ───────────────────────────────────
    MID_SIDE         = "Mid/Side"              # análisis y norm M/S estéreo
    CREST_GUARD      = "Crest Guard"           # preservación de microdinámica
    AUTO             = "Auto (inteligente)"    # selección automática de modo

    @classmethod
    def from_label(cls, label: str) -> "NormalizationMode":
        """Parsear desde etiqueta de combo. Fallback a NONE."""
        for m in cls:
            if m.value == label:
                return m
        return cls.NONE

# Lista ordenada para poblar el QComboBox (norm_box).
# El orden importa: las opciones heredadas van primero para compatibilidad.
NORM_ITEMS = [m.value for m in NormalizationMode]

# ── Detección de capacidades de ffmpeg en tiempo de arranque ─────────────────
def _probe_ffmpeg() -> dict:
    """
    Detecta si ffmpeg está disponible y qué encoders tiene compilados.
    Se llama una vez al iniciar. Resultado cacheado en FFMPEG_CAPS.
    """
    caps = {
        "available":    False,
        "libvorbis":    False,   # OGG Vorbis de alta calidad (VBR real)
        "vorbis":       False,   # encoder vorbis nativo ffmpeg (ABR, menor calidad)
        "libwavpack":   False,   # WavPack via libwavpack
        "wavpack":      False,   # wavpack nativo ffmpeg
        "flac":         False,   # FLAC
        "path":         "",
        "version":      "",
    }
    ffmpeg_path = shutil.which("ffmpeg")
    if not ffmpeg_path:
        return caps
    caps["available"] = True
    caps["path"]      = ffmpeg_path
    try:
        # Obtener versión
        rv = subprocess.run([ffmpeg_path, "-version"],
                            capture_output=True, timeout=5)
        vout = rv.stdout.decode(errors="replace")
        for line in vout.splitlines():
            if line.startswith("ffmpeg version"):
                caps["version"] = line.split()[2] if len(line.split()) > 2 else ""
                break

        # Obtener encoders: parsear línea a línea para evitar falsos positivos
        r = subprocess.run([ffmpeg_path, "-encoders"],
                           capture_output=True, timeout=5)
        for raw_line in (r.stdout + r.stderr).splitlines():
            line = raw_line.decode(errors="replace").strip()
            # Formato: " A.... libvorbis  Vorbis..."
            # El nombre del encoder está en la segunda columna (índice 1 tras split)
            parts = line.split()
            if len(parts) < 2:
                continue
            enc_name = parts[1]
            if enc_name == "libvorbis":
                caps["libvorbis"] = True
            elif enc_name == "vorbis":
                caps["vorbis"] = True
            elif enc_name == "libwavpack":
                caps["libwavpack"] = True
            elif enc_name == "wavpack":
                caps["wavpack"] = True
            elif enc_name == "flac":
                caps["flac"] = True
    except Exception:
        pass
    _log.info("ffmpeg: %s  libvorbis=%s vorbis=%s libwavpack=%s wavpack=%s flac=%s",
              caps.get("version","?"),
              caps["libvorbis"], caps["vorbis"],
              caps["libwavpack"], caps["wavpack"], caps["flac"])
    return caps

FFMPEG_CAPS = _probe_ffmpeg()

# ─────────────────────────────────────────────────────────────────────────────
#  SISTEMA DE ESTADO INTERNO (backend monitor)
# ─────────────────────────────────────────────────────────────────────────────

class BackendStatus:
    """Estado compartido entre todos los threads. Acceso atómico por tipo."""
    __slots__ = (
        "stream_alive", "disk_alive", "xrun_count",
        "queue_size", "callback_tick", "last_block_t",
        "estimated_latency_ms", "dsp_load", "recovery_count",
        # ── Contadores de integridad ──
        "frames_received",    # total frames que llegaron al callback
        "frames_written",     # total frames confirmados escritos a disco
        "frames_dropped",     # frames descartados por overflow de cola
        "frames_exported",    # total frames confirmados en el archivo exportado final
        "disk_write_secs",    # tiempo total de escritura en disco
        "backpressure_state", # "SAFE" / "HIGH" / "CRITICAL" / "EXTREME"
        "disk_bytes_written", # bytes reales en el archivo temporal
        # ── Telemetría RAM (v0.07) ──
        "ram_mb_approx",      # uso RAM proceso en MB (aproximado)
        "ram_state",          # "OK" / "HIGH" / "CRITICAL"
        # ── Telemetría v0.08 ──
        "callback_jitter_ms",    # jitter máximo entre callbacks (ms)
        "disk_write_ms_last",    # tiempo último write a disco (ms)
        "disk_write_ms_max",     # tiempo máximo de write en sesión (ms)
        "disk_mbps",             # velocidad escritura MB/s (ventana corta)
        "drift_ms",              # drift temporal actual (ms)
        "drift_warn_count",      # cuántas veces superó umbral de drift
        "expected_frames",       # frames que deberían haberse recibido
        "clip_count_l",          # clips detectados canal L
        "clip_count_r",          # clips detectados canal R
        "archival_safe_mode",    # bool: modo archival activo
        "last_callback_t",       # monotonic del último callback (para jitter)
        # ── Telemetría avanzada v0.09 ──
        "callback_latency_sum",  # suma de latencias callback (para avg)
        "callback_latency_count",# contador para avg
        "callback_latency_avg_ms",# latencia promedio callback (ms)
        "starvation_events",     # contador de starvation detectados
        "rb_l1_occupancy_pct",   # ocupación RB_L1 (%)
        "rb_l2_occupancy_pct",   # ocupación RB_L2 (%)
        "segment_count",         # número de segmentos escritos
        "current_segment_frames",# frames en segmento actual
        "integrity_crc32_errors",# bloques con CRC32 inconsistente
        "psi_cpu_pct",           # presión PSI CPU (%)
        "psi_io_pct",            # presión PSI IO (%)
        "psi_mem_pct",           # presión PSI memoria (%)
        # ── Stress test mode (v0.19) ──
        "stress_test_active",    # bool: modo stress test activo
        # ── XRLOG rate-limiting (v0.19) ──
        "_xrlog_last_msg",       # último mensaje XRLOG emitido (para dedup)
        "_xrlog_last_t",         # timestamp del último XRLOG emitido
        "_xrlog_repeat_count",   # cuántas veces se repitió el último mensaje
        # ── XD Patch: protección extrema xrun/drift ──
        "rb_l1_overrun_count",   # overruns acumulados en RB_L1
        "rb_l2_expanded_count",  # veces que RB_L2 fue expandido
        "wd_phase",              # fase watchdog: "OK"/"YELLOW"/"ORANGE"/"RED"
        "drift_ewma_ms",         # drift suavizado por EWMA (ms)
        "drift_chronic",         # bool: drift crónico detectado
        "drift_frames_pct",      # % discrepancia frames_recv vs frames_written
        "jitter_ewma_ms",        # jitter suavizado EWMA (ms)
        "jitter_p95_ms",         # percentil 95 del jitter (ms)
        "jitter_p99_ms",         # percentil 99 del jitter (ms)
        "disk_slow_count",       # writes lentos consecutivos
        "disk_io_protected",     # bool: modo protección I/O lento activo
        "recovery_last_t",       # monotonic del último recovery completado
        # ── Normalización avanzada v0.20 ─────────────────────────────────────
        "normalization_mode",          # str: etiqueta del modo activo
        "normalization_gain_db",       # float: ganancia aplicada en dB
        "normalization_peak_db",       # float: peak original en dBFS antes de normalizar
        "normalization_lufs",          # float: loudness medido en LUFS (-∞ si N/A)
        "normalization_noise_floor_db",# float: noise floor estimado en dBFS
        "normalization_true_peak_db",  # float: true peak detectado en dBFS
        "normalization_stats",         # dict: estadísticas detalladas del análisis
        # ── CRAC 0.20 — bloque normalización avanzada ─────────────────────────
        "normalization_pre_gain_db",        # float: ganancia etapa 1 (pre-norm doble)
        "normalization_post_gain_db",       # float: ganancia etapa 3 (post-norm doble)
        "normalization_mid_rms",            # float: RMS del canal Mid en dBFS
        "normalization_side_rms",           # float: RMS del canal Side en dBFS
        "normalization_stereo_balance",     # float: stereo_balance_index 0..1
        "normalization_crest_factor_db",    # float: crest factor pre-norm
        "normalization_dynamic_range",      # float: rango dinámico estimado (dB)
        "normalization_histogram_density",  # float: fracción de muestras en zona clipping
        "normalization_silence_ratio",      # float: fracción de bloques silenciosos
        "normalization_auto_mode",          # str: modo elegido por AUTO ("" si no fue AUTO)
        # ── v0.21 — campos inyectados por _patch_backend_status ──────────────
        "auto_normalization_decision",      # str: decisión compacta del modo AUTO
        "auto_normalization_reason",        # str: razón detallada de la decisión
        "normalization_rms_final_db",       # float: RMS post-normalización
        "normalization_percentile_5",       # float: percentil 5 RMS (bloques)
        "normalization_percentile_95",      # float: percentil 95 RMS (bloques)
        "normalization_true_peak_final_db", # float: true peak post-normalización
        "normalization_report_path",        # str: ruta al reporte JSON guardado
        "_lock",
    )

    def __init__(self):
        self._lock                = threading.Lock()
        self.stream_alive         = False
        self.disk_alive           = False
        self.xrun_count           = 0
        self.queue_size           = 0
        self.callback_tick        = 0
        self.last_block_t         = 0.0
        self.estimated_latency_ms = 0.0
        self.dsp_load             = 0.0
        self.recovery_count       = 0
        self.frames_received      = 0
        self.frames_written       = 0
        self.frames_dropped       = 0
        self.frames_exported      = 0
        self.disk_write_secs      = 0.0
        self.backpressure_state   = "SAFE"
        self.disk_bytes_written   = 0
        self.ram_mb_approx        = 0.0
        self.ram_state            = "OK"
        # v0.08
        self.callback_jitter_ms   = 0.0
        self.disk_write_ms_last   = 0.0
        self.disk_write_ms_max    = 0.0
        self.disk_mbps            = 0.0
        self.drift_ms             = 0.0
        self.drift_warn_count     = 0
        self.expected_frames      = 0
        self.clip_count_l         = 0
        self.clip_count_r         = 0
        self.archival_safe_mode   = False
        self.last_callback_t      = 0.0
        # v0.09
        self.callback_latency_sum   = 0.0
        self.callback_latency_count = 0
        self.callback_latency_avg_ms= 0.0
        self.starvation_events      = 0
        self.rb_l1_occupancy_pct    = 0.0
        self.rb_l2_occupancy_pct    = 0.0
        self.segment_count          = 0
        self.current_segment_frames = 0
        self.integrity_crc32_errors = 0
        self.psi_cpu_pct            = 0.0
        self.psi_io_pct             = 0.0
        self.psi_mem_pct            = 0.0
        # v0.19
        self.stress_test_active     = False
        self._xrlog_last_msg        = ""
        self._xrlog_last_t          = 0.0
        self._xrlog_repeat_count    = 0
        # XD Patch — protección extrema xrun/drift
        self.rb_l1_overrun_count    = 0
        self.rb_l2_expanded_count   = 0
        self.wd_phase               = "OK"
        self.drift_ewma_ms          = 0.0
        self.drift_chronic          = False
        self.drift_frames_pct       = 0.0
        self.jitter_ewma_ms         = 0.0
        self.jitter_p95_ms          = 0.0
        self.jitter_p99_ms          = 0.0
        self.disk_slow_count        = 0
        self.disk_io_protected      = False
        self.recovery_last_t        = 0.0
        # v0.20 — normalización avanzada
        self.normalization_mode           = "Sin normalizar"
        self.normalization_gain_db        = 0.0
        self.normalization_peak_db        = 0.0
        self.normalization_lufs           = float("-inf")
        self.normalization_noise_floor_db = float("-inf")
        self.normalization_true_peak_db   = 0.0
        self.normalization_stats          : dict = {}
        # v0.20 — bloque normalización avanzada (cierre CRAC 0.20)
        self.normalization_pre_gain_db        = 0.0
        self.normalization_post_gain_db       = 0.0
        self.normalization_mid_rms            = float("-inf")
        self.normalization_side_rms           = float("-inf")
        self.normalization_stereo_balance     = 0.0
        self.normalization_crest_factor_db    = float("inf")
        self.normalization_dynamic_range      = 0.0
        self.normalization_histogram_density  = 0.0
        self.normalization_silence_ratio      = 0.0
        self.normalization_auto_mode          = ""
        # v0.21 — nuevos campos (también declarados en __slots__)
        self.auto_normalization_decision      = ""
        self.auto_normalization_reason        = ""
        self.normalization_rms_final_db       = float("-inf")
        self.normalization_percentile_5       = float("-inf")
        self.normalization_percentile_95      = float("-inf")
        self.normalization_true_peak_final_db = float("-inf")
        self.normalization_report_path        = ""

    def inc_xrun(self):
        with self._lock: self.xrun_count += 1

    def snapshot(self) -> dict:
        with self._lock:
            return {k: getattr(self, k) for k in self.__slots__ if k != "_lock"}


def _sample_ram_mb() -> float:
    """
    Lee uso RSS del proceso en MB. Sin dependencias externas.
    OPT-08: usa /proc/self/statm (una línea de enteros, ~100x más compacto
    que /proc/PID/status con su parse línea-a-línea). RSS = campo [1] × PAGE_SIZE.
    """
    try:
        with open("/proc/self/statm") as f:
            fields = f.read().split()
        # statm: size rss shared text lib data dirty — en páginas
        rss_pages = int(fields[1])
        return rss_pages * 4096 / (1024.0 * 1024.0)   # 4KB páginas → MB
    except Exception:
        pass
    # Fallback al método original si statm falla (non-Linux)
    try:
        with open(f"/proc/{os.getpid()}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return float(line.split()[1]) / 1024.0
    except Exception:
        pass
    return 0.0


_status = BackendStatus()


# ─────────────────────────────────────────────────────────────────────────────
#  DETECCIÓN DE BACKEND DE AUDIO (Linux: PipeWire / ALSA / JACK)
# ─────────────────────────────────────────────────────────────────────────────

def _detect_audio_backend() -> str:
    """Intenta detectar el backend de audio activo en Linux."""
    if sys.platform != "linux":
        return "default"
    try:
        r = subprocess.run(["pactl", "info"], capture_output=True, timeout=2)
        if b"PipeWire" in r.stdout:
            return "pipewire"
    except Exception:
        pass
    try:
        r = subprocess.run(["jack_control", "status"], capture_output=True, timeout=2)
        if r.returncode == 0:
            return "jack"
    except Exception:
        pass
    return "alsa"

AUDIO_BACKEND = _detect_audio_backend()
