from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Utilidades de conversión y manipulación de audio compartidas.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import threading
import time
import numpy as np
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_constants import CLIP_THRESHOLD



# ─────────────────────────────────────────────────────────────────────────────


def _detect_clips(block: np.ndarray, threshold: float = CLIP_THRESHOLD) -> tuple:
    """
    Detecta clips en un bloque de audio.
    Devuelve (clips_l, clips_r).
    """
    clips_l = int(np.sum(np.abs(block[:, 0]) >= threshold)) if block.shape[1] > 0 else 0
    clips_r = int(np.sum(np.abs(block[:, 1]) >= threshold)) if block.shape[1] > 1 else clips_l
    return clips_l, clips_r


# ── Clipping detector persistente ────────────────────────────────────────────

class ClipLog:
    """
    Registra eventos de clipping con timestamps y canal afectado.
    Thread-safe. Guardado en metadata de sesión al exportar.
    """
    def __init__(self):
        self._lock    = threading.Lock()
        self._events  : List[dict] = []   # [{"t": float, "ch": str, "n": int}, ...]
        self.total_l  = 0
        self.total_r  = 0

    def record(self, clips_l: int, clips_r: int):
        if clips_l == 0 and clips_r == 0:
            return
        t = time.monotonic()
        with self._lock:
            if clips_l > 0:
                self.total_l += clips_l
                self._events.append({"t": round(t, 3), "ch": "L", "n": clips_l})
            if clips_r > 0:
                self.total_r += clips_r
                self._events.append({"t": round(t, 3), "ch": "R", "n": clips_r})

    def reset(self):
        with self._lock:
            self._events.clear()
            self.total_l = 0
            self.total_r = 0

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "total_l":   self.total_l,
                "total_r":   self.total_r,
                "events":    list(self._events[-200:]),   # últimos 200 eventos
            }

_clip_log = ClipLog()
