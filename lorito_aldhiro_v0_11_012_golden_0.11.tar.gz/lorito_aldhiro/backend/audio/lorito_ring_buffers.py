from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ring buffer de absorción (RBA) entre el callback de audio y el hilo de escritura a disco.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import threading
import time
import queue
import gc
import hashlib
from datetime import datetime
import random
import numpy as np
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import _status
from lorito_aldhiro.backend.core.lorito_constants import XRLOG_FILENAME, XRLOG_MAX_BYTES
from lorito_aldhiro.backend.core.lorito_timing import _monotonic_raw_ns



# ─────────────────────────────────────────────────────────────────────────────
#  v0.09 — RING BUFFER MULTINIVEL PREALOCADO
# ─────────────────────────────────────────────────────────────────────────────

class _RobustRingBuffer:
    """
    Ring buffer circular con slots prealocados. Tolerante a carga brutal.

    Mejoras vs _PreallocRingBuffer v0.20.14:
      · Límite de sobreescritura controlado: en modo allow_overwrite se registra
        CADA overrun individual en el contador sin acumular deuda silenciosa.
      · resize() puede usarse desde cualquier thread concurrentemente gracias al
        Condition ya existente — sin cambios de API.
      · read_batch() retorna lista de copias independientes del buffer interno
        (idéntico a versión anterior — seguridad de memoria garantizada).
      · occupancy_pct es property thread-safe: acceso atómico entero CPython.
      · clear() no resetea _overflow_count — el contador es acumulativo por sesión.
      · Invariantes: _write_idx y _read_idx siempre mod _n, _count en [0, _n].
    """

    def __init__(self, n_slots: int, frames: int, channels: int,
                 name: str = "RB", allow_overwrite: bool = False):
        self._name     = name
        self._n        = n_slots
        self._allow_ow = allow_overwrite
        # Array 3D prealocado: [slots, frames_max, channels]
        self._buf    = np.zeros((n_slots, frames, channels), dtype=np.float32)
        self._sizes  = np.zeros(n_slots, dtype=np.int32)
        self._write_idx    = 0
        self._read_idx     = 0
        self._count        = 0
        self._lock         = threading.Lock()
        self._not_empty    = threading.Condition(self._lock)
        self._overflow_count = 0    # acumulativo de sesión — nunca se borra
        self._max_frames   = frames

    # ── Escritura (path RT — mínimo locking) ─────────────────────────────────

    def write(self, block: np.ndarray) -> bool:
        """
        Escribe bloque en el próximo slot disponible.
        Retorna True si OK. False si buffer lleno y allow_overwrite=False.
        En allow_overwrite=True siempre retorna True (puede descartar más antiguo).
        Seguro desde el callback RT: lock mínimo, sin allocations.
        """
        n_frames = block.shape[0]
        if n_frames > self._max_frames:
            block    = block[:self._max_frames]
            n_frames = self._max_frames

        with self._not_empty:
            if self._count >= self._n:
                self._overflow_count += 1
                if self._allow_ow:
                    # Sacrifica el bloque más antiguo (overrun controlado)
                    self._read_idx = (self._read_idx + 1) % self._n
                    self._count   -= 1
                    # Nota: el overrun se loguea desde el drain/watchdog,
                    # no aquí, para mantener el callback RT sin I/O de log.
                else:
                    return False  # RB_L2 lleno — drain toma acción

            dst = self._buf[self._write_idx]
            dst[:n_frames] = block
            self._sizes[self._write_idx] = n_frames
            self._write_idx = (self._write_idx + 1) % self._n
            self._count    += 1
            self._not_empty.notify()
        return True

    # ── Lectura ───────────────────────────────────────────────────────────────

    def read(self, timeout: float = 0.05) -> Optional[np.ndarray]:
        """Lee el siguiente bloque. Bloquea hasta timeout si vacío."""
        with self._not_empty:
            if self._count == 0:
                self._not_empty.wait(timeout=timeout)
            if self._count == 0:
                return None
            idx    = self._read_idx
            n      = self._sizes[idx]
            result = self._buf[idx, :n].copy()
            self._read_idx = (self._read_idx + 1) % self._n
            self._count   -= 1
        return result

    def read_batch(self, max_items: int = 64) -> list:
        """Lee hasta max_items bloques sin bloquear. Retorna lista de copias."""
        out = []
        with self._not_empty:
            while self._count > 0 and len(out) < max_items:
                idx = self._read_idx
                n   = self._sizes[idx]
                out.append(self._buf[idx, :n].copy())
                self._read_idx = (self._read_idx + 1) % self._n
                self._count   -= 1
        return out

    # ── Expansión defensiva ───────────────────────────────────────────────────

    def resize(self, new_n_slots: int):
        """
        Expansión de capacidad. Solo permite aumentar, nunca reducir.
        Prealocación inmediata de slots adicionales. Thread-safe.
        """
        with self._not_empty:
            if new_n_slots <= self._n:
                return
            extra     = new_n_slots - self._n
            ch        = self._buf.shape[2]
            extra_buf = np.zeros((extra, self._max_frames, ch), dtype=np.float32)
            extra_sz  = np.zeros(extra, dtype=np.int32)
            self._buf   = np.concatenate([self._buf,   extra_buf], axis=0)
            self._sizes = np.concatenate([self._sizes, extra_sz],  axis=0)
            self._n     = new_n_slots
            # No notificamos: resize no añade datos, solo espacio.

    # ── Propiedades ───────────────────────────────────────────────────────────

    @property
    def occupancy_pct(self) -> float:
        """% de ocupación. Lectura atómica (entero CPython). Sin lock explícito."""
        n = self._n
        return (self._count / n * 100.0) if n > 0 else 0.0

    @property
    def overflow_count(self) -> int:
        return self._overflow_count

    def clear(self):
        """Limpia todos los slots pendientes. NO resetea overflow_count."""
        with self._not_empty:
            self._write_idx = 0
            self._read_idx  = 0
            self._count     = 0




class _XRunForensics:
    """
    Sistema de diagnóstico profundo de XRuns, starvation y write stalls.

    Diseño:
      · El callback RT solo pone un evento en una cola lock-free.
      · Un thread separado (de baja prioridad) lee la cola y escribe el log.
      · NUNCA bloquea el callback RT.
      · Archivo: ~/AUX/fonogramas/capture_session.xrlog
      · Límite de tamaño: XRLOG_MAX_BYTES (rotación automática).
    """

    def __init__(self):
        self._queue    : queue.Queue = queue.Queue(maxsize=512)
        self._path     = os.path.join(ARCHIVE_DIR, XRLOG_FILENAME)
        self._thread   : Optional[threading.Thread] = None
        self._stop_evt = threading.Event()
        self._active   = False
        # Prealocación de campos PSI para no allocar en el writer thread
        self._psi_cache : dict = {"cpu": 0.0, "io": 0.0, "mem": 0.0,
                                  "last_t": 0.0}

    def start(self):
        if self._active:
            return
        self._stop_evt.clear()
        self._active = True
        self._thread = threading.Thread(
            target=self._writer_loop, daemon=True,
            name="aecct2-xrforensics"
        )
        self._thread.start()
        _log.info("XRunForensics iniciado: %s", self._path)

    def stop(self):
        self._active = False
        self._stop_evt.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)
        self._thread = None

    def record_xrun(self, kind: str, cb_latency_ms: float,
                    write_latency_ms: float, queue_size: int):
        """
        Registra un evento forense. Llamado desde drain/watchdog (NO desde callback RT).
        Recoge datos del sistema sin bloquear el path de audio.

        v0.19: Rate-limiting y dedup para evitar spam durante storms de PSI.
        · Mensajes idénticos (mismo kind) se consolidan: se registra uno y se
          añade un contador de repeticiones. Máximo 1 evento por kind cada 2 s.
        · Durante storms (>20 eventos del mismo kind en < 10 s) se emite una
          línea STORM_SUMMARY en lugar de cientos de líneas individuales.
        """
        if not self._active:
            return

        now = time.monotonic()
        msg_key = kind  # clave de dedup

        # Rate-limit: mismo kind no puede emitirse más de 1 vez cada 2 s
        _XRLOG_MIN_INTERVAL = 2.0
        last_t = _status._xrlog_last_t if _status._xrlog_last_msg == msg_key else 0.0
        if now - last_t < _XRLOG_MIN_INTERVAL:
            _status._xrlog_repeat_count += 1
            return  # consolidado — no encolar

        # Flush repeat count si el mismo kind tenía repeticiones pendientes
        repeat = _status._xrlog_repeat_count
        if repeat > 0 and _status._xrlog_last_msg == msg_key:
            try:
                self._queue.put_nowait({
                    "kind": f"{msg_key}_REPEAT",
                    "t_ns": _monotonic_raw_ns(),
                    "cb_lat_ms": 0.0, "wr_lat_ms": 0.0,
                    "q_size": 0,
                    "_repeat_count": repeat,
                })
            except queue.Full:
                pass

        _status._xrlog_last_msg     = msg_key
        _status._xrlog_last_t       = now
        _status._xrlog_repeat_count = 0

        event = {
            "kind":          kind,
            "t_ns":          _monotonic_raw_ns(),
            "cb_lat_ms":     round(cb_latency_ms, 3),
            "wr_lat_ms":     round(write_latency_ms, 3),
            "q_size":        queue_size,
        }
        # Añadir datos del sistema (no RT, puede ser lento)
        try:
            event["core"]      = self._read_cpu_core()
            event["gov"]       = self._read_governor()
            event["ram_free_mb"] = self._read_free_ram_mb()
            event["psi"]       = self._read_psi_snapshot()
        except Exception:
            pass
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            pass  # descartar si la cola forense está llena

    def _writer_loop(self):
        """Thread de baja prioridad que escribe el xrlog desde la cola."""
        try:
            with open(self._path, "a", buffering=4096,
                      encoding="utf-8") as f:
                f.write(f"\n# === Sesión iniciada {datetime.now().isoformat()} ===\n")
                while not self._stop_evt.is_set() or not self._queue.empty():
                    try:
                        ev = self._queue.get(timeout=0.5)
                    except queue.Empty:
                        continue
                    try:
                        # Línea de resumen para eventos repetidos consolidados
                        if ev["kind"].endswith("_REPEAT"):
                            line = (
                                f"{ev['t_ns']} {ev['kind']}"
                                f" count={ev.get('_repeat_count', 0)}"
                                "\n"
                            )
                        else:
                            line = (
                                f"{ev['t_ns']} {ev['kind']}"
                                f" cb={ev['cb_lat_ms']:.2f}ms"
                                f" wr={ev['wr_lat_ms']:.2f}ms"
                                f" q={ev['q_size']}"
                                f" core={ev.get('core','?')}"
                                f" gov={ev.get('gov','?')}"
                                f" ram_free={ev.get('ram_free_mb','?')}MB"
                                f" psi_cpu={ev.get('psi',{}).get('cpu',0.0):.1f}%"
                                f" psi_io={ev.get('psi',{}).get('io',0.0):.1f}%"
                                f" psi_mem={ev.get('psi',{}).get('mem',0.0):.1f}%"
                                "\n"
                            )
                        f.write(line)
                        # Chequear tamaño; truncar si excede límite
                        if f.tell() > XRLOG_MAX_BYTES:
                            f.seek(0)
                            f.truncate()
                            f.write(f"# Log rotado {datetime.now().isoformat()}\n")
                    except Exception as e:
                        _log.debug("XRunForensics writer: %s", e)
        except Exception as e:
            _log.warning("XRunForensics thread error: %s", e)

    def _read_cpu_core(self) -> str:
        try:
            with open("/proc/self/stat") as f:
                parts = f.read().split()
                return parts[38] if len(parts) > 38 else "?"
        except Exception:
            return "?"

    def _read_governor(self) -> str:
        try:
            for entry in os.scandir("/sys/devices/system/cpu"):
                gov = os.path.join(entry.path, "cpufreq", "scaling_governor")
                if os.path.exists(gov):
                    with open(gov) as f:
                        return f.read().strip()
        except Exception:
            pass
        return "?"

    def _read_free_ram_mb(self) -> float:
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemAvailable:"):
                        return float(line.split()[1]) / 1024.0
        except Exception:
            pass
        return 0.0

    def _read_psi_snapshot(self) -> dict:
        psi = {"cpu": 0.0, "io": 0.0, "mem": 0.0}
        try:
            for key, path in (("cpu",  "/proc/pressure/cpu"),
                              ("io",   "/proc/pressure/io"),
                              ("mem",  "/proc/pressure/memory")):
                if os.path.exists(path):
                    with open(path) as f:
                        for line in f:
                            if line.startswith("some"):
                                parts = line.split()
                                for p in parts:
                                    if p.startswith("avg10="):
                                        psi[key] = float(p.split("=")[1])
                                        break
                                break
        except Exception:
            pass
        return psi


_xrun_forensics = _XRunForensics()


# ─────────────────────────────────────────────────────────────────────────────
#  v0.09 — PSI MONITOR (Linux Pressure Stall Information)
# ─────────────────────────────────────────────────────────────────────────────

class _PSIMonitor:
    """
    Monitorea /proc/pressure/{cpu,io,memory} en un thread de baja prioridad.
    Actualiza _status.psi_* fields periódicamente.
    Sin spam de logs: throttle mínimo PSI_LOG_MIN_INTERVAL segundos.
    """

    def __init__(self):
        self._thread   : Optional[threading.Thread] = None
        self._stop_evt = threading.Event()
        self._last_warn_t = 0.0
        self._available = all(
            os.path.exists(f"/proc/pressure/{x}")
            for x in ("cpu", "io", "memory")
        )

    def start(self):
        if not self._available:
            _log.info("PSI Monitor: /proc/pressure no disponible")
            return
        self._stop_evt.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True,
            name="aecct2-psimon"
        )
        self._thread.start()

    def stop(self):
        self._stop_evt.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _loop(self):
        while not self._stop_evt.wait(timeout=5.0):
            psi = {"cpu": 0.0, "io": 0.0, "mem": 0.0,
                   "cpu60": 0.0, "io60": 0.0, "mem60": 0.0}
            try:
                for key, path in (("cpu",  "/proc/pressure/cpu"),
                                  ("io",   "/proc/pressure/io"),
                                  ("mem",  "/proc/pressure/memory")):
                    with open(path) as f:
                        for line in f:
                            if line.startswith("some"):
                                for part in line.split():
                                    if part.startswith("avg10="):
                                        psi[key] = float(part.split("=")[1])
                                    # FIX-PSI-AVG60 (v0.21.06): leer avg60 también.
                                    # avg10 solo mide los últimos 10s y refleja picos
                                    # transitorios (e.g., compilación JIT, fork de
                                    # subprocess). avg60 confirma presión sostenida.
                                    elif part.startswith("avg60="):
                                        psi[key + "60"] = float(part.split("=")[1])
                                break
            except Exception:
                pass

            _status.psi_cpu_pct = psi["cpu"]
            _status.psi_io_pct  = psi["io"]
            _status.psi_mem_pct = psi["mem"]

            # Warning si presión crítica (con throttle).
            # FIX-PSI-AVG60 (v0.21.06): distinguir presión sostenida (avg60 alto)
            # de pico transitorio (solo avg10 alto). Con gov=schedutil el avg10 de
            # CPU siempre fluctúa → PSI_CRITICAL se disparaba cada 30s aunque solo
            # hubiera un spike breve de 5s. Ahora:
            #   avg10 > umbral Y avg60 > 10% → PSI_CRITICAL real
            #   avg10 > umbral Y avg60 ≤ 10% → PSI_TRANSIENT (solo warning, no xrlog crítico)
            max_psi    = max(psi["cpu"],   psi["io"],   psi["mem"])
            max_psi60  = max(psi["cpu60"], psi["io60"], psi["mem60"])
            now = time.monotonic()
            if (max_psi >= PSI_WARN_THRESHOLD
                    and now - self._last_warn_t >= PSI_LOG_MIN_INTERVAL):
                self._last_warn_t = now
                _is_sustained = max_psi60 >= PSI_WARN_THRESHOLD * 0.5
                if _is_sustained:
                    _log.warning(
                        "PSI presión SOSTENIDA: cpu=%.1f%%(60s=%.1f%%) "
                        "io=%.1f%%(60s=%.1f%%) mem=%.1f%%(60s=%.1f%%) "
                        "— considerar buffers mayores o reducir carga del sistema",
                        psi["cpu"], psi["cpu60"], psi["io"], psi["io60"],
                        psi["mem"], psi["mem60"]
                    )
                    _xrun_forensics.record_xrun(
                        "PSI_CRITICAL",
                        cb_latency_ms=_status.callback_jitter_ms,
                        write_latency_ms=_status.disk_write_ms_last,
                        queue_size=_status.queue_size
                    )
                else:
                    _log.info(
                        "PSI pico transitorio: cpu=%.1f%%(60s=%.1f%%) "
                        "io=%.1f%%(60s=%.1f%%) — no sostenido, ignorando",
                        psi["cpu"], psi["cpu60"], psi["io"], psi["io60"]
                    )

_psi_monitor = _PSIMonitor()


# ─────────────────────────────────────────────────────────────────────────────
#  v0.09 — INTEGRITY MONITOR (CRC32 + SHA256 por segmento)
# ─────────────────────────────────────────────────────────────────────────────
#  STRESS TEST MODE  (v0.19)
# ─────────────────────────────────────────────────────────────────────────────

class _StressTestMode:
    """
    Modo interno de pruebas extremas para validar estabilidad sin hardware externo.

    Capacidades:
    · Saturación artificial de disco (escritura de basura al directorio temporal)
    · Latencia simulada en disk_queue (sleep aleatorio en _write_loop)
    · XRuns simulados (incrementa xrun_count periódicamente)
    · Delays de queue (put con timeout artificial)
    · Presión de RAM (alloca y libera bloques grandes)
    · Playback seek spam (emite seek_ready repetidamente)

    SOLO para uso en desarrollo/testing. NUNCA activar en producción archivística.
    Controlado por _status.stress_test_active.
    """

    # Parámetros de stress configurables
    DISK_SATURATION_MB    = 50      # MB de basura para saturar disco
    DISK_SATURATION_FILES = 8       # número de archivos temporales
    QUEUE_DELAY_MAX_MS    = 80      # delay aleatorio máximo en queue (ms)
    XRUN_INJECT_INTERVAL  = 3.0     # segundos entre XRuns simulados
    RAM_PRESSURE_MB       = 128     # MB de presión de RAM
    SEEK_SPAM_INTERVAL    = 1.5     # segundos entre seeks simulados
    LATENCY_INJECT_MS     = 25      # latencia de callback simulada (ms)

    def __init__(self):
        self._active        = False
        self._stop_evt      = threading.Event()
        self._threads: list = []
        self._tmp_files: list = []
        self._ram_bufs: list  = []

    def start(self):
        """Activa el modo stress. Lanza hilos de perturbación."""
        if self._active:
            _log.warning("StressTestMode ya está activo")
            return
        self._active = True
        _status.stress_test_active = True
        self._stop_evt.clear()
        _log.warning("⚠ STRESS TEST MODE ACTIVADO — solo para testing interno")

        for target, name in [
            (self._disk_saturator,  "stress-disk"),
            (self._xrun_injector,   "stress-xrun"),
            (self._ram_pressurizer, "stress-ram"),
            (self._queue_delayer,   "stress-queue"),
        ]:
            t = threading.Thread(target=target, daemon=True, name=name)
            t.start()
            self._threads.append(t)

    def stop(self):
        """Detiene el modo stress y limpia recursos."""
        if not self._active:
            return
        self._active = False
        _status.stress_test_active = False
        self._stop_evt.set()
        for t in self._threads:
            t.join(timeout=3.0)
        self._threads.clear()
        self._ram_bufs.clear()
        # Eliminar archivos temporales de saturación
        for p in self._tmp_files:
            try:
                os.unlink(p)
            except Exception:
                pass
        self._tmp_files.clear()
        _log.info("StressTestMode desactivado — recursos liberados")

    # ── Hilos de perturbación ─────────────────────────────────────────────────

    def _disk_saturator(self):
        """Escribe archivos basura para saturar el ancho de banda de disco."""
        import random
        chunk = os.urandom(1024 * 1024)  # 1 MB
        while not self._stop_evt.is_set():
            for i in range(self.DISK_SATURATION_FILES):
                if self._stop_evt.is_set():
                    break
                path = os.path.join(ARCHIVE_DIR, f"_stress_sat_{i}.tmp")
                try:
                    with open(path, "wb") as f:
                        for _ in range(self.DISK_SATURATION_MB):
                            f.write(chunk)
                    self._tmp_files.append(path)
                except Exception as e:
                    _log.debug("stress-disk: %s", e)
            # Pausa breve, luego vuelve a saturar
            self._stop_evt.wait(timeout=2.0)
            # Limpiar entre rondas
            for p in list(self._tmp_files):
                try:
                    os.unlink(p)
                    self._tmp_files.remove(p)
                except Exception:
                    pass

    def _xrun_injector(self):
        """Simula XRuns periódicos incrementando xrun_count."""
        while not self._stop_evt.wait(timeout=self.XRUN_INJECT_INTERVAL):
            # Orden Golden (CAP-006): un XRun simulado cuenta UNA vez y
            # en UN solo contador (antes incrementaba también starvation).
            _status.xrun_count += 1
            _log.debug("stress-xrun: XRun simulado (total=%d)", _status.xrun_count)

    def _ram_pressurizer(self):
        """Alloca y libera bloques grandes para presionar el GC."""
        while not self._stop_evt.is_set():
            try:
                mb = random.randint(32, self.RAM_PRESSURE_MB)
                buf = bytearray(mb * 1024 * 1024)
                self._ram_bufs.append(buf)
                self._stop_evt.wait(timeout=0.5)
                if self._ram_bufs:
                    self._ram_bufs.pop()
                del buf
                gc.collect()   # CONSERVADO: _StressTestMode únicamente — libera bytearray de presión RAM
                self._stop_evt.wait(timeout=1.0)
            except MemoryError:
                _log.warning("stress-ram: MemoryError durante presión de RAM")
                self._stop_evt.wait(timeout=2.0)

    def _queue_delayer(self):
        """Introduce latencia artificial simulada en el timing de escritura."""
        while not self._stop_evt.wait(timeout=0.2):
            # Solo perturba si hay grabación activa
            if _status.stream_alive and not _status.stress_test_active:
                break
            delay = random.uniform(0, self.QUEUE_DELAY_MAX_MS / 1000.0)
            time.sleep(delay)

    @property
    def is_active(self) -> bool:
        return self._active


# Singleton global del modo stress
_stress_test = _StressTestMode()

# ─────────────────────────────────────────────────────────────────────────────

class _IntegrityMonitor:
    """
    Calcula CRC32 incremental por bloque y SHA-256 por segmento.
    Thread-safe. Sin allocations en path caliente.
    """

    def __init__(self):
        import zlib as _zlib
        self._zlib          = _zlib
        self._crc32_running = 0       # CRC32 acumulado del segmento actual
        self._sha256_ctx    = hashlib.sha256()
        self._lock          = threading.Lock()
        self._block_count   = 0
        self._segment_hashes: list = []  # [(seg_idx, sha256_hex, crc32_hex), ...]

    def reset_segment(self):
        """Reinicia contextos para nuevo segmento."""
        with self._lock:
            self._crc32_running = 0
            self._sha256_ctx    = hashlib.sha256()
            self._block_count   = 0

    def update(self, block_bytes: bytes) -> int:
        """
        Actualiza CRC32 y SHA256 con los bytes del bloque.
        Retorna CRC32 acumulado actual. Sin allocations internas.
        """
        with self._lock:
            self._crc32_running = self._zlib.crc32(
                block_bytes, self._crc32_running
            ) & 0xFFFFFFFF
            self._sha256_ctx.update(block_bytes)
            self._block_count += 1
            return self._crc32_running

    def finalize_segment(self, seg_idx: int) -> dict:
        """
        Finaliza segmento: extrae SHA-256 y CRC32 finales.
        Retorna dict con hashes. Reinicia contextos automáticamente.
        """
        with self._lock:
            sha256_hex = self._sha256_ctx.hexdigest()
            crc32_hex  = f"{self._crc32_running:08x}"
            blocks     = self._block_count
            record = {
                "seg":    seg_idx,
                "sha256": sha256_hex,
                "crc32":  crc32_hex,
                "blocks": blocks,
            }
            self._segment_hashes.append(record)
            # Reiniciar para siguiente segmento
            self._crc32_running = 0
            self._sha256_ctx    = hashlib.sha256()
            self._block_count   = 0
        _log.info("Integridad segmento %d: sha256=%s... crc32=%s blocks=%d",
                  seg_idx, sha256_hex[:16], crc32_hex, blocks)
        return record

    def get_all_hashes(self) -> list:
        with self._lock:
            return list(self._segment_hashes)

_integrity_monitor = _IntegrityMonitor()
