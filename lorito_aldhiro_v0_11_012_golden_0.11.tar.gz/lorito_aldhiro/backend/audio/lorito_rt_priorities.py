from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ajuste de prioridades de tiempo real del sistema operativo para los hilos de audio.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import ctypes
import ctypes.util
from dataclasses import dataclass, field
import grp as _grp
import pwd as _pwd
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.core.lorito_constants import RT_PRIORITY_DRAIN


# ── Singleton global de libc (evita find_library() repetitivo en paths calientes) ──
# Cargado una sola vez al importar el módulo. Reutilizado por _monotonic_raw_ns(),
# _set_rt_priority(), _set_sched_batch() y _mlockall_thread().
_LIBC: Optional[ctypes.CDLL] = None
if sys.platform == "linux":
    try:
        _LIBC = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
    except Exception:
        _LIBC = None

# ── Estructuras ctypes reutilizables (evita redefinición en cada llamada) ──
class _SchedParam(ctypes.Structure):
    _fields_ = [("sched_priority", ctypes.c_int)]

class _Timespec(ctypes.Structure):
    _fields_ = [("tv_sec", ctypes.c_long), ("tv_nsec", ctypes.c_long)]


# ─────────────────────────────────────────────────────────────────────────────
#  UTILIDADES v0.08
# ─────────────────────────────────────────────────────────────────────────────

def _set_rt_priority(priority: int = 60) -> bool:
    """
    Intenta aplicar prioridad SCHED_FIFO al thread actual.

    Orden de intentos:
      1. sched_setscheduler() directo (requiere RLIMIT_RTPRIO > 0,
         que el paquete realtime-privileges configura vía PAM para
         los grupos 'audio' y 'realtime').
      2. rtkit-daemon vía D-Bus (fallback si RLIMIT_RTPRIO = 0
         pero rtkit está activo y el usuario está en los grupos correctos).

    Silencioso si ninguno está disponible.
    """
    if sys.platform != "linux":
        return False

    # ── Intento 1: sched_setscheduler() directo ───────────────────────────────
    try:
        libc = _LIBC
        if libc is None:
            raise RuntimeError("libc no disponible")
        SCHED_FIFO = 1
        param = _SchedParam(sched_priority=max(1, min(99, priority)))
        ret = libc.sched_setscheduler(0, SCHED_FIFO, ctypes.byref(param))
        if ret == 0:
            _log.info("RT priority SCHED_FIFO %d aplicada al thread %s",
                      priority, threading.current_thread().name)
            return True
        else:
            errno_val = ctypes.get_errno()
            _log.debug(
                "sched_setscheduler falló (errno=%d) — "
                "probando rtkit como fallback", errno_val
            )
    except Exception as e:
        _log.debug("_set_rt_priority sched_setscheduler: %s", e)

    # ── Intento 2: rtkit-daemon vía D-Bus ─────────────────────────────────────
    # Solo si _RT_STATUS indica que rtkit está activo y el usuario tiene grupos RT.
    if _RT_STATUS is not None and _RT_STATUS.rtkit_active:
        if _RT_STATUS.in_audio or _RT_STATUS.in_realtime:
            ok = _apply_rt_via_rtkit(priority=priority)
            if ok:
                _log.info(
                    "RT priority %d aplicada vía rtkit al thread %s",
                    priority, threading.current_thread().name
                )
            return ok
        else:
            _log.debug(
                "rtkit disponible pero usuario sin grupos RT — "
                "sin prioridad RT para thread %s",
                threading.current_thread().name
            )
    return False


def _set_sched_batch() -> bool:
    """
    Aplica SCHED_BATCH al thread actual para reducir interferencia con threads RT.
    Ideal para el GUI thread y tareas de baja prioridad en kernel Zen.
    SCHED_BATCH = 3 en Linux.
    """
    if sys.platform != "linux":
        return False
    try:
        libc = _LIBC
        if libc is None:
            return False
        SCHED_BATCH = 3
        param = _SchedParam(sched_priority=0)   # SCHED_BATCH siempre prioridad 0
        ret = libc.sched_setscheduler(0, SCHED_BATCH, ctypes.byref(param))
        if ret == 0:
            _log.info("SCHED_BATCH aplicado al thread %s", threading.current_thread().name)
            return True
        else:
            _log.debug("SCHED_BATCH falló (errno=%d)", ctypes.get_errno())
    except Exception as e:
        _log.debug("_set_sched_batch: %s", e)
    return False


def _mlockall_thread() -> bool:
    """
    Llama a mlockall(MCL_CURRENT | MCL_FUTURE) en el proceso.
    Evita page faults en los threads de audio RT durante la sesión.
    Requiere CAP_IPC_LOCK o RLIMIT_MEMLOCK suficiente.
    Solo se llama una vez (efecto global al proceso).
    """
    if sys.platform != "linux":
        return False
    try:
        import resource
        # Elevar RLIMIT_MEMLOCK a 128 MB si está limitado
        soft, hard = resource.getrlimit(resource.RLIMIT_MEMLOCK)
        target = 128 * 1024 * 1024
        if soft != resource.RLIM_INFINITY and soft < target:
            try:
                new_soft = min(target, hard) if hard != resource.RLIM_INFINITY else target
                resource.setrlimit(resource.RLIMIT_MEMLOCK, (new_soft, hard))
                _log.info("RLIMIT_MEMLOCK elevado a %d MB", new_soft // (1024*1024))
            except Exception as re:
                _log.debug("No se pudo elevar RLIMIT_MEMLOCK: %s", re)

        libc     = _LIBC
        if libc is None:
            return False
        MCL_CURRENT = 1
        MCL_FUTURE  = 2
        ret = libc.mlockall(MCL_CURRENT | MCL_FUTURE)
        if ret == 0:
            _log.info("mlockall(MCL_CURRENT|MCL_FUTURE) OK — page faults RT eliminados")
            return True
        else:
            errno = ctypes.get_errno()
            _log.debug("mlockall falló (errno=%d) — sin bloqueo de páginas", errno)
    except Exception as e:
        _log.debug("_mlockall_thread: %s", e)
    return False


def _set_cpu_affinity(cpus: list) -> bool:
    """
    Aplica afinidad de CPU al thread actual usando sched_setaffinity(2).
    cpus: lista de índices de núcleo lógico (ej. [2, 3]).
    """
    if sys.platform != "linux" or not cpus:
        return False
    try:
        os.sched_setaffinity(0, set(cpus))
        _log.info("CPU affinity → núcleos %s para thread %s",
                  cpus, threading.current_thread().name)
        return True
    except Exception as e:
        _log.debug("CPU affinity falló: %s", e)
    return False


# Fallback inicializado antes de _detect_zen_affinity() para evitar NameError
ZEN_AFFINITY_AUDIO: list = []  # núcleos reservados para audio RT
ZEN_AFFINITY_GUI:   list = []  # núcleos para GUI/player

def _detect_zen_affinity() -> None:
    """
    Detecta núcleos físicos disponibles y sugiere una partición
    GUI / Audio para minimizar interrupciones en el path RT.

    Lógica:
      · Excluye E-cores (eficiencia) en CPUs híbridas leyendo
        /sys/devices/system/cpu/cpuN/cpufreq/cpuinfo_max_freq
      · Reserva el último tercio de núcleos P para audio RT
      · El resto va al GUI + player

    Rellena ZEN_AFFINITY_AUDIO y ZEN_AFFINITY_GUI.
    """
    global ZEN_AFFINITY_AUDIO, ZEN_AFFINITY_GUI
    try:
        n_cpu = os.cpu_count() or 1
        if n_cpu < 2:
            return  # mono-núcleo: sin partición

        # Leer frecuencias máximas para detectar E-cores (freq más baja)
        max_freqs = {}
        for i in range(n_cpu):
            freq_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/cpuinfo_max_freq"
            try:
                with open(freq_path) as f:
                    max_freqs[i] = int(f.read().strip())
            except Exception:
                max_freqs[i] = 0

        if max_freqs:
            global_max = max(max_freqs.values())
            # P-cores = núcleos con freq >= 90% del máximo global
            p_cores = [i for i, f in max_freqs.items() if f >= global_max * 0.90]
        else:
            p_cores = list(range(n_cpu))

        if not p_cores:
            p_cores = list(range(n_cpu))

        p_cores.sort()
        # Reservar el último tercio (mínimo 1) de P-cores para audio
        n_audio = max(1, len(p_cores) // 3)
        ZEN_AFFINITY_AUDIO = p_cores[-n_audio:]
        ZEN_AFFINITY_GUI   = p_cores[:-n_audio] if len(p_cores) > n_audio else p_cores[:]

        _log.info("Zen affinity: audio=%s gui=%s (de %d P-cores / %d totales)",
                  ZEN_AFFINITY_AUDIO, ZEN_AFFINITY_GUI, len(p_cores), n_cpu)
    except Exception as e:
        _log.debug("_detect_zen_affinity: %s", e)


# Ejecutar detección de afinidad al importar el módulo
_detect_zen_affinity()


def _check_scheduler_warnings() -> List[str]:
    """
    Detecta advertencias del scheduler en Linux.
    Ampliado para kernel Zen (Arch Linux): preemption, HZ, threadirqs,
    transparent huge pages, CPU governor, y detección de kernel Zen.
    Devuelve lista de mensajes de warning.
    """
    warns = []
    if sys.platform != "linux":
        return warns

    # ── Detectar kernel Zen ───────────────────────────────────────────────────
    try:
        uname = os.uname()
        kernel_ver = uname.release
        is_zen = "zen" in kernel_ver.lower()
        _log.info("Kernel detectado: %s  zen=%s", kernel_ver, is_zen)
        if not is_zen:
            warns.append(
                f"Kernel '{kernel_ver}' no parece ser Zen — "
                "instala linux-zen para mejor latencia de audio"
            )
    except Exception:
        pass

    # ── CONFIG_HZ: Zen usa 1000 Hz por defecto ────────────────────────────────
    try:
        # /proc/sys/kernel/hz no existe en todos los kernels;
        # alternativa: leer CONFIG desde /boot o /proc/config.gz
        hz = None
        for cfg_path in ("/proc/config.gz", f"/boot/config-{os.uname().release}"):
            try:
                if cfg_path.endswith(".gz"):
                    import gzip
                    with gzip.open(cfg_path, "rt", errors="replace") as f:
                        for line in f:
                            if line.startswith("CONFIG_HZ="):
                                hz = int(line.split("=")[1].strip())
                                break
                else:
                    with open(cfg_path) as f:
                        for line in f:
                            if line.startswith("CONFIG_HZ="):
                                hz = int(line.split("=")[1].strip())
                                break
                if hz is not None:
                    break
            except Exception:
                pass
        if hz is not None:
            if hz < 1000:
                warns.append(
                    f"CONFIG_HZ={hz} — kernel Zen debería compilarse con HZ=1000 "
                    "para audio RT óptimo"
                )
            else:
                _log.info("CONFIG_HZ=%d OK", hz)
        else:
            # Fallback: /proc/sys/kernel/hz (raro pero posible)
            try:
                with open("/proc/sys/kernel/hz", "r") as f:
                    hz = int(f.read().strip())
                    if hz < 250:
                        warns.append(f"Kernel HZ={hz} bajo (recomendado ≥1000 para Zen audio)")
            except Exception:
                pass
    except Exception:
        pass

    # ── Preemption dinámica (Zen 6.x) ────────────────────────────────────────
    try:
        preempt_path = "/sys/kernel/debug/sched/preempt"
        if os.path.exists(preempt_path):
            with open(preempt_path) as f:
                preempt_val = f.read().strip()
            _log.info("Preemption mode: %s", preempt_val)
            if "none" in preempt_val.lower():
                warns.append(
                    "Preemption en modo NONE — para audio RT se recomienda "
                    "'full' o 'voluntary': echo full > /sys/kernel/debug/sched/preempt"
                )
        else:
            # Kernels < 6.6: leer CONFIG_PREEMPT*
            try:
                uname_r = os.uname().release
                cfg_path = f"/boot/config-{uname_r}"
                if os.path.exists(cfg_path):
                    with open(cfg_path) as f:
                        cfg = f.read()
                    if "CONFIG_PREEMPT_NONE=y" in cfg:
                        warns.append("CONFIG_PREEMPT_NONE activo — sin preemption voluntaria")
                    elif "CONFIG_PREEMPT_VOLUNTARY=y" in cfg:
                        _log.info("CONFIG_PREEMPT_VOLUNTARY OK")
                    elif "CONFIG_PREEMPT=y" in cfg:
                        _log.info("CONFIG_PREEMPT (full) OK")
            except Exception:
                pass
    except Exception:
        pass

    # ── threadirqs ────────────────────────────────────────────────────────────
    try:
        # Si threadirqs está activo, los IRQ de audio corren en threads
        # que pueden recibir prioridad RT separada del loop de audio.
        irq_thread_found = False
        # P2-HIGIENE (Orden Maestra de Saneamiento 0.06.005→0.06.006,
        # Fase 15): iterar `os.scandir()` sin `with` y cortar temprano
        # con `break` deja el descriptor de directorio sin cerrar hasta
        # el siguiente ciclo del GC — detectado como `ResourceWarning`
        # real al correr la batería de tests completa.
        with os.scandir("/proc/irq") as _irq_entries:
            for entry in _irq_entries:
                smp_path = f"/proc/irq/{entry.name}/smp_affinity_list"
                if os.path.exists(smp_path):
                    irq_thread_found = True
                    break
        # Alternativa: mirar si algún kthread se llama irq/N
        try:
            r = subprocess.run(["ps", "-eo", "comm"], capture_output=True, timeout=2)
            if b"irq/" in r.stdout:
                _log.info("threadirqs detectado (kthreads irq/N presentes)")
            else:
                warns.append(
                    "threadirqs no detectado — añade 'threadirqs' a los parámetros "
                    "del kernel en /etc/default/grub para mejor RT"
                )
        except Exception:
            pass
    except Exception:
        pass

    # ── Transparent Huge Pages ────────────────────────────────────────────────
    try:
        thp_path = "/sys/kernel/mm/transparent_hugepage/enabled"
        if os.path.exists(thp_path):
            with open(thp_path) as f:
                thp = f.read().strip()
            if "[always]" in thp:
                warns.append(
                    "Transparent Huge Pages en modo 'always' — puede causar "
                    "latencia RT esporádica. Recomendado: "
                    "echo madvise > /sys/kernel/mm/transparent_hugepage/enabled"
                )
            else:
                _log.info("THP mode: %s OK", thp)
    except Exception:
        pass

    # ── CPU frequency governor ────────────────────────────────────────────────
    try:
        governors = set()
        cpu_base = "/sys/devices/system/cpu"
        for entry in os.scandir(cpu_base):
            gov_path = os.path.join(entry.path, "cpufreq", "scaling_governor")
            if os.path.exists(gov_path):
                with open(gov_path) as f:
                    governors.add(f.read().strip())
        if governors and governors != {"performance"}:
            bad = governors - {"performance"}
            warns.append(
                f"CPU governor(s) no-performance detectados: {bad} — "
                "para grabación RT usa: "
                "echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor"
            )
        elif governors == {"performance"}:
            _log.info("CPU governor: performance OK en todos los núcleos")
    except Exception:
        pass

    # ── rtkit-daemon ──────────────────────────────────────────────────────────
    try:
        r = subprocess.run(["systemctl", "is-active", "rtkit-daemon"],
                           capture_output=True, timeout=2)
        if r.returncode != 0:
            warns.append("rtkit-daemon no activo — RT priority no disponible sin root; "
                         "instala rtkit y habilítalo: systemctl enable --now rtkit-daemon")
        else:
            _log.info("rtkit-daemon activo OK")
    except Exception:
        pass

    # ── Integración con _RT_STATUS (realtime-privileges) ─────────────────────
    # Si el diagnóstico RT ya se ejecutó, añadir sus warnings al informe
    # del scheduler para tener un único punto de reporte.
    if _RT_STATUS is not None:
        for w in _RT_STATUS.warnings:
            if w not in warns:   # evitar duplicados con rtkit check anterior
                warns.append(w)

    return warns


# ─────────────────────────────────────────────────────────────────────────────
#  REALTIME PRIVILEGES — paquete realtime-privileges + grupo audio (Arch Linux)
# ─────────────────────────────────────────────────────────────────────────────
#
#  El paquete realtime-privileges (AUR/Arch) instala:
#    /etc/security/limits.d/99-realtime-privileges.conf
#    /usr/lib/sysusers.d/realtime-privileges.conf  (crea grupo 'realtime')
#
#  Junto con el grupo 'audio' (presente por defecto en Arch), esto permite
#  que procesos del usuario eleven su prioridad de scheduling sin root ni
#  CAP_SYS_NICE, usando los límites PAM de /etc/security/limits.conf.
#
#  Requisitos para el usuario:
#    sudo usermod -aG audio,realtime $USER   (o newgrp audio / newgrp realtime)
#    # Cerrar sesión y volver a entrar para que los GIDs suplementarios surtan efecto
#
# ─────────────────────────────────────────────────────────────────────────────

import grp as _grp
import pwd as _pwd
from dataclasses import dataclass, field


# ── Nombres de grupo configurables ───────────────────────────────────────────
RT_GROUP_AUDIO    = "audio"      # grupo estándar Linux para acceso al hardware de audio
RT_GROUP_REALTIME = "realtime"   # grupo instalado por realtime-privileges

# ── Archivo de límites instalado por realtime-privileges ─────────────────────
RT_LIMITS_FILES = [
    "/etc/security/limits.d/99-realtime-privileges.conf",
    "/etc/security/limits.d/99-audio.conf",      # alternativa común
    "/etc/security/limits.conf",                 # fallback global
]

# ── Límites mínimos esperados (según spec de realtime-privileges) ─────────────
RT_REQUIRED_RTPRIO  = 95     # prioridad RT mínima que debería poder aplicar el usuario
RT_REQUIRED_MEMLOCK = -1     # -1 = unlimited (valor especial en limits.conf)
RT_REQUIRED_NICE    = -15    # nice negativo mínimo esperado


@dataclass
class _RtPrivilegesStatus:
    """
    Resultado del diagnóstico completo de RT privileges.
    Todos los campos son de solo lectura tras el diagnóstico.
    """
    # Membresía de grupos
    in_audio    : bool = False
    in_realtime : bool = False

    # Límites PAM efectivos
    rtprio_limit   : Optional[int] = None   # None = no encontrado
    memlock_limit  : Optional[int] = None   # -1 = unlimited
    nice_limit     : Optional[int] = None

    # rtkit
    rtkit_active   : bool = False
    rtkit_elevated : bool = False   # True si se elevó con éxito vía rtkit

    # Límites del proceso actuales (rlimit)
    rlim_rtprio_soft : int = 0
    rlim_memlock_soft: int = 0

    # Resumen
    rt_fully_ready : bool = False   # True si todo está configurado correctamente
    warnings       : list = field(default_factory=list)
    notes          : list = field(default_factory=list)


def _rt_privileges_check() -> dict:
    """
    Verifica membresía del usuario actual en los grupos 'audio' y 'realtime'
    leyendo directamente /proc/self/status (GIDs suplementarios del proceso).
    No usa subprocess; no modifica nada.

    Devuelve dict con claves:
      in_audio    (bool)
      in_realtime (bool)
      uid         (int)
      username    (str)
      groups      (list[str])   — nombres de todos los grupos del proceso
    """
    result = {
        "in_audio":    False,
        "in_realtime": False,
        "uid":         os.getuid(),
        "username":    "",
        "groups":      [],
    }
    try:
        result["username"] = _pwd.getpwuid(result["uid"]).pw_name
    except Exception:
        pass

    # Leer GIDs suplementarios desde /proc/self/status (campo Groups:)
    # Esto refleja los GIDs activos en el proceso actual, no solo los del passwd.
    gids = set()
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("Groups:"):
                    parts = line.split()[1:]
                    gids = {int(g) for g in parts if g.isdigit()}
                    break
    except Exception:
        pass

    # Añadir GID efectivo y real por si acaso
    try:
        gids.add(os.getgid())
        gids.add(os.getegid())
    except Exception:
        pass

    # Resolver GIDs a nombres de grupo
    group_names = []
    for gid in gids:
        try:
            group_names.append(_grp.getgrgid(gid).gr_name)
        except Exception:
            group_names.append(str(gid))
    result["groups"] = sorted(group_names)

    result["in_audio"]    = RT_GROUP_AUDIO    in group_names
    result["in_realtime"] = RT_GROUP_REALTIME in group_names

    _log.info(
        "RT groups: usuario=%s  audio=%s  realtime=%s  grupos=%s",
        result["username"], result["in_audio"], result["in_realtime"],
        result["groups"]
    )
    return result


def _rt_limits_from_group() -> dict:
    """
    Lee /etc/security/limits.d/99-realtime-privileges.conf (y alternativas)
    y extrae los límites configurados para @audio y @realtime.

    Formato de limits.conf:
      @audio   -  rtprio   95
      @audio   -  memlock  unlimited
      @realtime -  rtprio  99
      @realtime -  nice    -15

    Devuelve dict:
      rtprio   (int | None)
      memlock  (int | None)    -1 = unlimited
      nice     (int | None)
      source   (str)           — archivo donde se encontró
      raw_lines (list[str])    — líneas relevantes encontradas
    """
    result = {
        "rtprio":    None,
        "memlock":   None,
        "nice":      None,
        "source":    "",
        "raw_lines": [],
    }

    target_groups = {f"@{RT_GROUP_AUDIO}", f"@{RT_GROUP_REALTIME}"}

    for limits_path in RT_LIMITS_FILES:
        if not os.path.exists(limits_path):
            continue
        try:
            with open(limits_path, "r", errors="replace") as f:
                lines = f.readlines()
        except Exception as e:
            _log.debug("No se pudo leer %s: %s", limits_path, e)
            continue

        found_any = False
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            domain, _type, item, value = parts[0], parts[1], parts[2], parts[3]
            if domain not in target_groups:
                continue
            found_any = True
            result["raw_lines"].append(line)

            def _parse_val(v):
                if v in ("unlimited", "-1"):
                    return -1
                try:
                    return int(v)
                except ValueError:
                    return None

            if item == "rtprio":
                v = _parse_val(value)
                if v is not None:
                    # Tomar el mayor rtprio encontrado entre los grupos
                    if result["rtprio"] is None or (v != -1 and v > result["rtprio"]):
                        result["rtprio"] = v
            elif item == "memlock":
                v = _parse_val(value)
                if v is not None:
                    result["memlock"] = v
            elif item == "nice":
                v = _parse_val(value)
                if v is not None:
                    if result["nice"] is None or v < result["nice"]:
                        result["nice"] = v

        if found_any:
            result["source"] = limits_path
            break  # usar el primer archivo que tenga entradas relevantes

    _log.info(
        "RT limits (%s): rtprio=%s memlock=%s nice=%s",
        result["source"] or "no encontrado",
        result["rtprio"], result["memlock"], result["nice"]
    )
    return result


def _apply_rt_via_rtkit(thread_id: Optional[int] = None,
                        priority: int = RT_PRIORITY_DRAIN) -> bool:
    """
    Solicita prioridad RT para el thread actual (o thread_id dado) a través
    de rtkit-daemon vía D-Bus (org.freedesktop.RealtimeKit1).

    El flujo es:
      1. Intentar con dbus-python (import dbus) — más limpio y sin subprocess.
      2. Fallback a dbus-send como subproceso — compatible sin dbus-python.

    rtkit eleva la prioridad dentro de los límites del grupo; el proceso no
    necesita CAP_SYS_NICE ni ejecutarse como root.

    Devuelve True si la elevación fue confirmada.
    """
    if sys.platform != "linux":
        return False

    tid = thread_id if thread_id is not None else threading.get_native_id()
    prio = max(1, min(99, priority))

    _log.debug("_apply_rt_via_rtkit: tid=%d prio=%d", tid, prio)

    # ── Intento 1: dbus-python ────────────────────────────────────────────────
    try:
        import dbus  # type: ignore
        bus   = dbus.SystemBus()
        rtkit = bus.get_object(
            "org.freedesktop.RealtimeKit1",
            "/org/freedesktop/RealtimeKit1"
        )
        iface = dbus.Interface(rtkit, "org.freedesktop.RealtimeKit1")
        # Firma D-Bus de MakeThreadRealtime es 'tu': (UInt64 thread_id, UInt32 priority).
        # El PID NO forma parte de la firma — el proceso ya está identificado
        # implícitamente por la conexión D-Bus. Pasar pid como tercer argumento
        # produce "Fewer items found in D-Bus signature" y el error se repite en loop.
        iface.MakeThreadRealtime(dbus.UInt64(tid), dbus.UInt32(prio))
        _log.info("rtkit dbus-python: thread %d elevado a RT prio %d", tid, prio)
        return True
    except ImportError:
        _log.debug("dbus-python no disponible — probando dbus-send")
    except Exception as e:
        _log.warning("rtkit dbus-python falló: %s", e)

    # ── Intento 2: dbus-send (subproceso) ─────────────────────────────────────
    try:
        cmd = [
            "dbus-send",
            "--system",
            "--print-reply",
            "--dest=org.freedesktop.RealtimeKit1",
            "/org/freedesktop/RealtimeKit1",
            "org.freedesktop.RealtimeKit1.MakeThreadRealtime",
            # Solo thread_id y priority — sin pid
            f"uint64:{tid}",
            f"uint32:{prio}",
        ]
        r = subprocess.run(cmd, capture_output=True, timeout=3)
        if r.returncode == 0:
            _log.info("rtkit dbus-send: thread %d elevado a RT prio %d", tid, prio)
            return True
        else:
            err = r.stderr.decode(errors="replace").strip()
            _log.warning("rtkit dbus-send falló (rc=%d): %s", r.returncode, err[:120])
    except FileNotFoundError:
        _log.debug("dbus-send no encontrado en PATH")
    except Exception as e:
        _log.warning("rtkit dbus-send excepción: %s", e)

    return False


def _rt_rlimits_current() -> dict:
    """
    Lee los rlimits actuales del proceso para RLIMIT_RTPRIO y RLIMIT_MEMLOCK.
    Devuelve dict con claves rtprio_soft, rtprio_hard, memlock_soft, memlock_hard.
    """
    result = {
        "rtprio_soft":  0,
        "rtprio_hard":  0,
        "memlock_soft": 0,
        "memlock_hard": 0,
    }
    try:
        import resource
        s, h = resource.getrlimit(resource.RLIMIT_RTPRIO)
        result["rtprio_soft"] = s
        result["rtprio_hard"] = h
        s, h = resource.getrlimit(resource.RLIMIT_MEMLOCK)
        result["memlock_soft"] = s
        result["memlock_hard"] = h
    except Exception as e:
        _log.debug("_rt_rlimits_current: %s", e)
    return result


def _diagnose_rt_privileges() -> _RtPrivilegesStatus:
    """
    Diagnóstico unificado de RT privileges para Lorito Aldhiro en Arch Linux con
    paquete realtime-privileges y grupo audio activos.

    Pasos:
      1. Verificar grupos del proceso (audio, realtime)
      2. Leer límites PAM de limits.d
      3. Leer rlimits actuales del proceso
      4. Comprobar rtkit-daemon
      5. Construir lista de warnings accionables
      6. Intentar elevar el thread actual si todo parece correcto

    Devuelve _RtPrivilegesStatus con el diagnóstico completo.
    """
    st = _RtPrivilegesStatus()

    # ── 1. Grupos ──────────────────────────────────────────────────────────────
    grp_info = _rt_privileges_check()
    st.in_audio    = grp_info["in_audio"]
    st.in_realtime = grp_info["in_realtime"]
    username       = grp_info["username"]

    if not st.in_audio:
        st.warnings.append(
            f"Usuario '{username}' NO está en el grupo '{RT_GROUP_AUDIO}'. "
            f"Ejecuta: sudo usermod -aG {RT_GROUP_AUDIO} {username}  "
            f"(y cierra/abre sesión)"
        )
    if not st.in_realtime:
        st.warnings.append(
            f"Usuario '{username}' NO está en el grupo '{RT_GROUP_REALTIME}'. "
            f"Instala realtime-privileges y ejecuta: "
            f"sudo usermod -aG {RT_GROUP_REALTIME} {username}  "
            f"(y cierra/abre sesión). "
            f"En Arch: sudo pacman -S realtime-privileges"
        )

    # ── 2. Límites PAM ─────────────────────────────────────────────────────────
    lim = _rt_limits_from_group()
    st.rtprio_limit  = lim["rtprio"]
    st.memlock_limit = lim["memlock"]
    st.nice_limit    = lim["nice"]

    if lim["source"]:
        st.notes.append(f"Límites RT leídos de: {lim['source']}")
    else:
        st.warnings.append(
            "No se encontró configuración PAM de RT en limits.d. "
            "El paquete realtime-privileges debería instalar "
            "/etc/security/limits.d/99-realtime-privileges.conf automáticamente. "
            "Reinstala: sudo pacman -S realtime-privileges"
        )

    if st.rtprio_limit is not None and st.rtprio_limit < RT_REQUIRED_RTPRIO:
        st.warnings.append(
            f"rtprio PAM = {st.rtprio_limit} (mínimo recomendado: {RT_REQUIRED_RTPRIO}). "
            f"Añade '@{RT_GROUP_AUDIO} - rtprio {RT_REQUIRED_RTPRIO}' "
            f"en /etc/security/limits.d/99-realtime-privileges.conf"
        )

    if st.memlock_limit is not None and st.memlock_limit != -1:
        st.warnings.append(
            f"memlock PAM = {st.memlock_limit} KB (se recomienda 'unlimited'). "
            f"Añade '@{RT_GROUP_AUDIO} - memlock unlimited' en limits.d"
        )

    # ── 3. rlimits del proceso ─────────────────────────────────────────────────
    rl = _rt_rlimits_current()
    st.rlim_rtprio_soft  = rl["rtprio_soft"]
    st.rlim_memlock_soft = rl["memlock_soft"]

    import resource as _resource
    INF = _resource.RLIM_INFINITY

    if rl["rtprio_soft"] == 0 and rl["rtprio_hard"] == 0:
        st.warnings.append(
            "RLIMIT_RTPRIO del proceso es 0/0 — el kernel rechazará SCHED_FIFO. "
            "Verifica que la sesión se inició después de añadir el usuario al grupo "
            "y que PAM cargó /etc/security/limits.d correctamente "
            "(requiere pam_limits.so en /etc/pam.d/system-login)"
        )
        st.notes.append(
            "Tip: verifica con 'ulimit -r' en una terminal nueva. "
            "Si sigue en 0, revisa /etc/pam.d/system-login y reinicia la sesión."
        )
    else:
        st.notes.append(
            f"RLIMIT_RTPRIO: soft={rl['rtprio_soft']} "
            f"hard={'unlimited' if rl['rtprio_hard'] == INF else rl['rtprio_hard']}"
        )

    memlock_str = ('unlimited' if rl['memlock_soft'] == INF
                   else f"{rl['memlock_soft'] // 1024} MB")
    st.notes.append(f"RLIMIT_MEMLOCK soft: {memlock_str}")

    # ── 4. rtkit-daemon ────────────────────────────────────────────────────────
    try:
        r = subprocess.run(["systemctl", "is-active", "rtkit-daemon"],
                           capture_output=True, timeout=2)
        st.rtkit_active = (r.returncode == 0)
    except Exception:
        st.rtkit_active = False

    if not st.rtkit_active:
        st.warnings.append(
            "rtkit-daemon no está activo. Habilítalo: "
            "sudo systemctl enable --now rtkit-daemon"
        )

    # ── 5. Elevación del thread principal vía rtkit ────────────────────────────
    # Solo si rtkit está activo y el usuario tiene los grupos correctos.
    if st.rtkit_active and (st.in_audio or st.in_realtime):
        st.rtkit_elevated = _apply_rt_via_rtkit(priority=RT_PRIORITY_DRAIN)
        if st.rtkit_elevated:
            st.notes.append(
                f"Thread principal elevado a RT prio {RT_PRIORITY_DRAIN} vía rtkit"
            )
        else:
            st.warnings.append(
                "rtkit-daemon activo pero la elevación falló. "
                "Posibles causas: usuario no en grupo 'realtime', "
                "rtprio PAM insuficiente, o dbus no disponible. "
                "Instala python-dbus para diagnóstico detallado: "
                "sudo pacman -S python-dbus"
            )
    elif not st.rtkit_active and rl["rtprio_soft"] > 0:
        # rtkit no disponible, pero el kernel sí permite SCHED_FIFO directo
        st.notes.append(
            "rtkit no activo — se usará sched_setscheduler() directo "
            f"(RLIMIT_RTPRIO soft={rl['rtprio_soft']} permite esto)"
        )

    # ── 6. Veredicto final ─────────────────────────────────────────────────────
    st.rt_fully_ready = (
        (st.in_audio or st.in_realtime)
        and (st.rtprio_limit is None or st.rtprio_limit >= RT_REQUIRED_RTPRIO)
        and rl["rtprio_soft"] > 0
        and not st.warnings   # sin warnings = configuración completa
    )

    # Log resumen
    _log.info(
        "RT privileges: audio=%s realtime=%s rtprio_lim=%s "
        "memlock_lim=%s rlim_rtprio=%d rtkit=%s elevado=%s ready=%s",
        st.in_audio, st.in_realtime, st.rtprio_limit,
        "unlimited" if st.memlock_limit == -1 else st.memlock_limit,
        st.rlim_rtprio_soft, st.rtkit_active, st.rtkit_elevated,
        st.rt_fully_ready
    )
    for w in st.warnings:
        _log.warning("RT config: %s", w)
    for n in st.notes:
        _log.info("RT note: %s", n)

    return st


# Resultado del diagnóstico RT (se ejecuta al importar el módulo,
# antes de crear la GUI, para que los threads lo lean sin carrera).
_RT_STATUS: Optional[_RtPrivilegesStatus] = None


def _init_rt_privileges() -> _RtPrivilegesStatus:
    """
    Punto de entrada único. Ejecuta el diagnóstico y almacena el resultado
    en _RT_STATUS. Llamado una sola vez desde __main__.
    """
    global _RT_STATUS
    _RT_STATUS = _diagnose_rt_privileges()
    return _RT_STATUS
