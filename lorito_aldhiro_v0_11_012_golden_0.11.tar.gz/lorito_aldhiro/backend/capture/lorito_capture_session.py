from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Máquina de estados única del ciclo de vida de una sesión de captura.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_capture_session.py — Orden Golden del Motor de Captura (CAP-011,
Fases 3 y 6).

    IDLE → ARMING → CAPTURING ↔ PAUSED → DRAINING → FINALIZING → CLASSIFIED
                         │          │          │            │
                         └──────────┴──────────┴────────────┴──→ FAILED

  · Una sola autoridad de ciclo de vida: start/stop/recovery/fail-stop
    pasan por `transition()`, serializado con un lock NO-RT (el callback
    de audio nunca lo toca: lee solo `accepting`, un bool publicado).
  · `generation` se incrementa en cada ARMING; recovery y workers
    llevan el token de generación con el que nacieron y se descartan
    si ya no coincide (`is_current()`).
  · Recovery solo puede ejecutarse en CAPTURING/PAUSED. Una solicitud
    de parada (DRAINING o posterior) lo invalida — nunca reabre un
    stream tras `request_stop()`.
  · FAILED es terminal para la sesión (solo admite → FINALIZING para
    preservar el archivo parcial y clasificarlo, y → IDLE para una
    sesión nueva). `failure_reason` persiste hasta el próximo ARMING.
"""

import threading
import time
from enum import Enum


class CaptureState(str, Enum):
    IDLE = "IDLE"
    ARMING = "ARMING"
    CAPTURING = "CAPTURING"
    PAUSED = "PAUSED"
    DRAINING = "DRAINING"
    FINALIZING = "FINALIZING"
    CLASSIFIED = "CLASSIFIED"
    FAILED = "FAILED"


_ALLOWED = {
    CaptureState.IDLE: {CaptureState.ARMING},
    CaptureState.ARMING: {CaptureState.CAPTURING, CaptureState.FAILED, CaptureState.IDLE},
    CaptureState.CAPTURING: {CaptureState.PAUSED, CaptureState.DRAINING, CaptureState.FAILED},
    CaptureState.PAUSED: {CaptureState.CAPTURING, CaptureState.DRAINING, CaptureState.FAILED},
    CaptureState.DRAINING: {CaptureState.FINALIZING, CaptureState.FAILED},
    CaptureState.FINALIZING: {CaptureState.CLASSIFIED, CaptureState.FAILED},
    CaptureState.CLASSIFIED: {CaptureState.IDLE, CaptureState.ARMING},
    CaptureState.FAILED: {CaptureState.DRAINING, CaptureState.FINALIZING,
                          CaptureState.CLASSIFIED, CaptureState.IDLE,
                          CaptureState.ARMING},
}

RECOVERY_ALLOWED = frozenset({CaptureState.CAPTURING, CaptureState.PAUSED})
STOP_REQUESTED = frozenset({CaptureState.DRAINING, CaptureState.FINALIZING,
                            CaptureState.CLASSIFIED})


class IllegalTransition(RuntimeError):
    pass


class CaptureSessionFSM:
    """FSM del ciclo de vida de captura (no-RT, thread-safe)."""

    def __init__(self, on_transition=None):
        self._lock = threading.RLock()
        self._state = CaptureState.IDLE
        self._generation = 0
        self._failure_reason = ""
        self._history: list = []
        self._stop_requested = False
        self._on_transition = on_transition
        # Publicado para el callback RT (lectura de un bool, sin lock).
        self.accepting = False

    # ── Lectura ────────────────────────────────────────────────────────────

    @property
    def state(self) -> CaptureState:
        return self._state

    @property
    def generation(self) -> int:
        return self._generation

    @property
    def failure_reason(self) -> str:
        return self._failure_reason

    @property
    def stop_requested(self) -> bool:
        return self._stop_requested

    @property
    def history(self) -> list:
        with self._lock:
            return list(self._history)

    def is_current(self, generation: int) -> bool:
        return generation == self._generation

    def recovery_allowed(self, generation: int | None = None) -> bool:
        with self._lock:
            if generation is not None and generation != self._generation:
                return False
            return self._state in RECOVERY_ALLOWED and not self._stop_requested

    # ── Transiciones ───────────────────────────────────────────────────────

    def transition(self, new_state: CaptureState, reason: str = "",
                   expected_generation: int | None = None) -> bool:
        """Aplica la transición si es legal. Devuelve True si cambió el
        estado, False si ya estaba en `new_state` (idempotente). Lanza
        `IllegalTransition` si no está permitida."""
        cb = None
        with self._lock:
            if expected_generation is not None and expected_generation != self._generation:
                raise IllegalTransition(
                    f"generación obsoleta {expected_generation} != {self._generation}")
            old = self._state
            if new_state == old:
                return False
            if new_state not in _ALLOWED[old]:
                raise IllegalTransition(f"{old.value} → {new_state.value} no permitido")
            if new_state == CaptureState.ARMING:
                self._generation += 1
                self._failure_reason = ""
                self._stop_requested = False
            if new_state in STOP_REQUESTED:
                self._stop_requested = True
            if new_state == CaptureState.FAILED:
                self._stop_requested = True
                if not self._failure_reason:
                    self._failure_reason = reason or "FAILED"
            self._state = new_state
            self.accepting = new_state == CaptureState.CAPTURING
            self._history.append((time.monotonic(), old.value, new_state.value,
                                  reason, self._generation))
            if len(self._history) > 1024:
                del self._history[:256]
            cb = self._on_transition
        if cb is not None:
            try:
                cb(old, new_state, reason)
            except Exception:
                pass
        return True

    def try_transition(self, new_state: CaptureState, reason: str = "") -> bool:
        try:
            return self.transition(new_state, reason)
        except IllegalTransition:
            return False

    def fail(self, reason: str) -> bool:
        """Transición a FAILED desde cualquier estado activo. Idempotente:
        conserva la PRIMERA razón de fallo."""
        with self._lock:
            if self._state in (CaptureState.FAILED,):
                return False
            if self._state == CaptureState.IDLE:
                self._failure_reason = reason
                return False
            if not self._failure_reason:
                self._failure_reason = reason
            try:
                return self.transition(CaptureState.FAILED, reason)
            except IllegalTransition:
                return False
