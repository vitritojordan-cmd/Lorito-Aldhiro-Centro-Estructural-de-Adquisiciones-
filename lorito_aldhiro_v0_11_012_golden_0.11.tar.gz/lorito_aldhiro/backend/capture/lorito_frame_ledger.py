from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: FrameLedger — contabilidad monotónica y reconciliable de cada frame de la sesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_frame_ledger.py — Orden Golden del Motor de Captura (CAP-006,
CAP-007, CAP-012, Fase 1) y Orden Golden de Instrumentación (ITL-01,
`TimelineAuthority`).

Definiciones formales (ver `ARCHIVAL_CONTRACT.md`):

  received   — frames entregados por PortAudio al callback mientras la
               sesión aceptaba audio (CAPTURING, no PAUSED).
  accepted   — frames publicados en el ring SPSC.
  rejected_* — frames que el callback NO pudo publicar (ring lleno,
               bloque sobredimensionado, forma inválida, fail-stop).
               Son PÉRDIDA DECLARADA: nunca se infiere cero pérdida de
               un contador que no se actualizó.
  drained    — frames que el drain sacó del ring.
  enqueued   — frames que el drain puso en la cola de disco (CED).
  written    — frames que el DiskWriter escribió con éxito.
  persisted  — frames cubiertos por un flush+fsync confirmado.
  verified   — frames releídos del archivo cerrado (cabecera + datos).
  lost_*     — frames que llegaron a una etapa y no pasaron a la
               siguiente por un fallo (writer caído, timeout de cierre).

Reconciliación (todas deben dar 0 al cierre para ARCHIVAL_SAFE):
  received  - (accepted + rejected)              → delta_callback
  accepted  - (drained + pending_ring)           → delta_ring
  drained   - (enqueued + lost_drain)            → delta_drain
  enqueued  - (written + lost_writer + pending_ced) → delta_writer
  written   - verified   (si hubo verificación)  → delta_verify

Concurrencia: cada contador tiene UN SOLO escritor (el callback, el
drain o el writer); lecturas desde otros hilos son instantáneas
aproximadas en vivo y exactas una vez que la etapa escritora está
quiescente (precondición de `reconcile()` final). Los eventos de
discontinuidad se registran desde hilos no-RT en una lista acotada.
"""

import threading
import time
from dataclasses import dataclass, field


MAX_DISCONTINUITY_EVENTS = 4096


@dataclass(frozen=True)
class DiscontinuityEvent:
    kind: str           # OVERFLOW / OVERSIZE / DEVICE_GAP / RECOVERY / WRITER_FAILURE / ...
    frame_index: int    # posición en la línea de tiempo de audio aceptado
    frames: int         # frames afectados (0 si desconocido → ver `unknown`)
    detail: str = ""
    unknown: bool = False
    t_monotonic: float = 0.0
    t_utc: float = 0.0


@dataclass
class LedgerReconciliation:
    ok: bool
    deltas: dict
    causes: list = field(default_factory=list)
    totals: dict = field(default_factory=dict)


class FrameLedger:
    """Libro contable de frames de UNA sesión (una generación)."""

    def __init__(self, session_id: str = "", generation: int = 0,
                 sample_rate: int = 48000, channels: int = 2):
        self.session_id = session_id
        self.generation = generation
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        # escritor: callback
        self.received = 0
        self.callbacks = 0
        self.received_while_paused = 0
        # escritor: drain
        self.drained = 0
        self.enqueued = 0
        self.lost_drain = 0
        self.derived_enqueued = 0
        self.derived_dropped = 0
        self.visual_dropped_blocks = 0
        # escritor: writer
        self.written = 0
        self.persisted = 0
        self.lost_writer = 0
        self.verified = 0
        self.verification_ran = False
        # escritor: control de sesión (no-RT)
        self.preroll_frames = 0
        self.finalization_incomplete = False
        self.finalization_reason = ""
        self.writer_failure_reason = ""
        self.unknown_counters: list = []
        self._events: list = []
        self._events_dropped = 0
        self._events_lock = threading.Lock()

    # ── Eventos de discontinuidad (no-RT) ─────────────────────────────────

    def record_discontinuity(self, kind: str, frame_index: int, frames: int,
                             detail: str = "", unknown: bool = False) -> None:
        ev = DiscontinuityEvent(kind=kind, frame_index=int(frame_index),
                                frames=int(frames), detail=detail, unknown=unknown,
                                t_monotonic=time.monotonic(), t_utc=time.time())
        with self._events_lock:
            if len(self._events) >= MAX_DISCONTINUITY_EVENTS:
                # Nunca desaparecen en silencio: se cuenta cuántos no
                # cupieron, y la clasificación lo trata como pérdida de
                # trazabilidad (bloquea ARCHIVAL_SAFE).
                self._events_dropped += 1
                return
            self._events.append(ev)

    @property
    def discontinuities(self) -> list:
        with self._events_lock:
            return list(self._events)

    @property
    def discontinuity_events_dropped(self) -> int:
        return self._events_dropped

    # ── Reconciliación ────────────────────────────────────────────────────

    def reconcile(self, ring_counters: dict,
                  pending_ced_frames: int = 0) -> LedgerReconciliation:
        """Cruza contadores del ledger con los del ring. Devuelve todos
        los deltas y una causa por cada delta distinto de cero o por
        cualquier pérdida/pendiente/incidencia declarada."""
        rc = ring_counters
        accepted = int(rc.get("accepted_frames", 0))
        consumed = int(rc.get("consumed_frames", 0))
        rejected = (int(rc.get("rejected_full_frames", 0))
                    + int(rc.get("rejected_oversize_frames", 0))
                    + int(rc.get("rejected_shape_frames", 0))
                    + int(rc.get("rejected_disabled_frames", 0)))
        stale = int(rc.get("stale_generation_frames", 0))
        pending_ring = accepted - consumed - stale
        deltas = {
            "callback": self.received - (accepted + rejected),
            "ring": consumed - self.drained,
            "drain": self.drained - (self.enqueued + self.lost_drain),
            "writer": (self.enqueued + self.preroll_frames)
                      - (self.written + self.lost_writer + pending_ced_frames),
        }
        if self.verification_ran:
            deltas["verify"] = self.written - self.verified
        causes = []
        for k, v in deltas.items():
            if v != 0:
                causes.append(f"delta_{k}={v}")
        if rejected:
            causes.append(f"perdida_declarada_callback={rejected}")
        if stale:
            causes.append(f"bloques_generacion_obsoleta={stale}")
        if self.lost_drain:
            causes.append(f"perdida_drain={self.lost_drain}")
        if self.lost_writer:
            causes.append(f"perdida_writer={self.lost_writer} ({self.writer_failure_reason})")
        if pending_ring or pending_ced_frames:
            causes.append(f"frames_pendientes_sin_persistir={pending_ring + pending_ced_frames}")
        if self.finalization_incomplete:
            causes.append(f"FINALIZATION_INCOMPLETE ({self.finalization_reason})")
        if self.unknown_counters:
            causes.append(f"contadores_desconocidos={self.unknown_counters}")
        if self._events_dropped:
            causes.append(f"eventos_discontinuidad_no_registrados={self._events_dropped}")
        ok = (all(v == 0 for v in deltas.values()) and not rejected and not stale
              and not self.lost_drain and not self.lost_writer
              and not pending_ring and not pending_ced_frames
              and not self.finalization_incomplete and not self.unknown_counters
              and not self._events_dropped)
        totals = self.snapshot()
        totals.update(accepted=accepted, consumed=consumed, rejected=rejected,
                      stale=stale, pending_ring=pending_ring,
                      pending_ced=pending_ced_frames)
        return LedgerReconciliation(ok=ok, deltas=deltas, causes=causes, totals=totals)

    # ── Línea de tiempo (TimelineAuthority) ───────────────────────────────

    def audio_seconds_committed(self) -> float:
        """Duración de audio CONFIRMADA por el writer — la autoridad de
        duración de la sesión (no el reloj de pared, no ticks de GUI)."""
        return self.written / max(self.sample_rate, 1)

    def audio_seconds_received(self) -> float:
        return self.received / max(self.sample_rate, 1)

    def snapshot(self) -> dict:
        return {
            "session_id": self.session_id,
            "generation": self.generation,
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "callbacks": self.callbacks,
            "received": self.received,
            "received_while_paused": self.received_while_paused,
            "drained": self.drained,
            "enqueued": self.enqueued,
            "lost_drain": self.lost_drain,
            "derived_enqueued": self.derived_enqueued,
            "derived_dropped": self.derived_dropped,
            "visual_dropped_blocks": self.visual_dropped_blocks,
            "written": self.written,
            "persisted": self.persisted,
            "lost_writer": self.lost_writer,
            "verified": self.verified,
            "verification_ran": self.verification_ran,
            "preroll_frames": self.preroll_frames,
            "finalization_incomplete": self.finalization_incomplete,
            "finalization_reason": self.finalization_reason,
            "writer_failure_reason": self.writer_failure_reason,
            "discontinuities": len(self._events),
            "discontinuity_events_dropped": self._events_dropped,
        }
