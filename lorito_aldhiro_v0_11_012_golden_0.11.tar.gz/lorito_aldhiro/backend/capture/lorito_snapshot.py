from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Instantánea del estado de la sesión para recuperación ante crash.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import threading
import queue
import json
from datetime import datetime
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import _status
from lorito_aldhiro.backend.core.lorito_constants import CRASH_HEARTBEAT_FILE, CRASH_HEARTBEAT_SECS, CRASH_MANIFEST_FILE, SNAPSHOT_SUBDIR



# ── Snapshot recovery ─────────────────────────────────────────────────────────

def _save_session_snapshot(path_tmp: str, rate: int, frames_written: int,
                           codec_hint: str, duration_secs: float) -> str:
    """
    Guarda un snapshot JSON de la sesión actual en ~/AUX/fonogramas/snapshots/.
    Devuelve la ruta del snapshot guardado.
    """
    snap_dir = os.path.join(ARCHIVE_DIR, SNAPSHOT_SUBDIR)
    os.makedirs(snap_dir, exist_ok=True)
    ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
    snap = {
        "version":        "0.09",
        "timestamp_iso":  datetime.now().isoformat(),
        "samplerate":     rate,
        "frames_written": frames_written,
        "duration_secs":  round(duration_secs, 3),
        "codec_hint":     codec_hint,
        "tmp_file":       path_tmp,
        "xruns":          _status.xrun_count,
        "drift_ms":       round(_status.drift_ms, 3),
        "clip_l":         _status.clip_count_l,
        "clip_r":         _status.clip_count_r,
        "ram_mb":         round(_status.ram_mb_approx, 1),
        "backpressure":   _status.backpressure_state,
        "recovery_count": _status.recovery_count,
    }
    snap_path = os.path.join(snap_dir, f"snap_{ts}.json")
    try:
        with open(snap_path, "w", encoding="utf-8") as f:
            json.dump(snap, f, indent=2)
        _log.info("Snapshot guardado: %s", snap_path)
    except Exception as e:
        _log.warning("No se pudo guardar snapshot: %s", e)
        snap_path = ""
    return snap_path


def _load_latest_snapshot() -> Optional[dict]:
    """
    Carga el snapshot más reciente si existe.
    Útil para recovery tras crash.
    """
    snap_dir = os.path.join(ARCHIVE_DIR, SNAPSHOT_SUBDIR)
    if not os.path.isdir(snap_dir):
        return None
    try:
        snaps = sorted([f for f in os.listdir(snap_dir) if f.endswith(".json")])
        if not snaps:
            return None
        with open(os.path.join(snap_dir, snaps[-1]), "r", encoding="utf-8") as f:
            data = json.load(f)
        _log.info("Snapshot cargado: %s", snaps[-1])
        return data
    except Exception as e:
        _log.warning("No se pudo cargar snapshot: %s", e)
        return None


# ══════════════════════════════════════════════════════════════════════════════
#  CRASH RECOVERY GUARD — v0.19 CrashGuard
#  ──────────────────────────────────────────────────────────────────────────────
#  Mecanismo:
#    · Al iniciar una grabación se escribe un HEARTBEAT en disco.
#    · El heartbeat se actualiza cada CRASH_HEARTBEAT_SECS con un manifest
#      JSON que contiene todo lo necesario para reexportar: ruta del archivo
#      temporal, todos los segmentos, rate, codec, opt1, opt2, norm, frames.
#    · Al cerrar limpiamente (closeEvent) se elimina el heartbeat.
#    · Si al arrancar el heartbeat existe → crash detectado.
#      La GUI ofrece reconstruir la sesión y reintentar la exportación.
# ══════════════════════════════════════════════════════════════════════════════

_HEARTBEAT_PATH = os.path.join(ARCHIVE_DIR, CRASH_HEARTBEAT_FILE)
_MANIFEST_PATH  = os.path.join(ARCHIVE_DIR, CRASH_MANIFEST_FILE)


class _SnapshotWorker:
    """
    OPT-03: Worker persistente para snapshots JSON asincrónicos.
    Reemplaza el patrón threading.Thread(target=_save_session_snapshot)
    que se lanzaba desde _archival_tick cada SNAPSHOT_INTERVAL_SECS.
    Hilo daemon creado una sola vez; recibe trabajos via submit().
    """
    def __init__(self):
        self._queue: queue.Queue = queue.Queue(maxsize=16)
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="crac-snapshot"
        )
        self._thread.start()

    def submit(self, path_tmp: str, rate: int, frames_written: int,
               codec_hint: str, duration_secs: float) -> None:
        """Encola un trabajo de snapshot. Non-blocking."""
        try:
            self._queue.put_nowait((path_tmp, rate, frames_written,
                                    codec_hint, duration_secs))
        except queue.Full:
            pass  # snapshot previo todavía en cola; saltar este ciclo

    def _loop(self) -> None:
        while True:
            args = self._queue.get()
            try:
                _save_session_snapshot(*args)
            except Exception as exc:
                _log.warning("_SnapshotWorker: error en snapshot: %s", exc)

_snapshot_worker = _SnapshotWorker()


class CrashGuard:
    """
    Protección contra crashes: mantiene un archivo de heartbeat en disco
    mientras hay una sesión activa. Si el proceso muere sin limpiar el
    archivo, la próxima ejecución lo detecta y ofrece recuperación.

    Thread-safe. El ticker corre en un daemon thread de baja prioridad
    para no interferir con los threads de audio RT.
    """

    def __init__(self):
        self._active   = False
        self._lock     = threading.Lock()
        self._stop_evt = threading.Event()
        self._thread   : Optional[threading.Thread] = None
        # Campos del manifest (actualizados por el GUI antes de cada tick)
        self._manifest : dict = {}

    def start(self, initial_manifest: dict):
        """
        Inicia la guardia. Escribe el heartbeat inicial y lanza el ticker.
        Debe llamarse desde el GUI thread al iniciar grabación.
        """
        with self._lock:
            if self._active:
                return
            self._active    = True
            self._manifest  = dict(initial_manifest)
            self._stop_evt.clear()

        self._write_manifest()
        self._thread = threading.Thread(
            target=self._ticker, daemon=True, name="aecct2-crashguard"
        )
        self._thread.start()
        _log.info("CrashGuard activado: %s", _HEARTBEAT_PATH)

    def update(self, manifest_update: dict):
        """
        Actualiza campos del manifest (llamado periódicamente desde _archival_tick).
        Thread-safe: se escribe en el próximo tick del daemon.
        """
        with self._lock:
            self._manifest.update(manifest_update)

    def stop(self):
        """
        Limpia el heartbeat y detiene el ticker.
        Debe llamarse desde closeEvent o al finalizar la sesión limpiamente.
        """
        with self._lock:
            if not self._active:
                return
            self._active = False
        self._stop_evt.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)
        self._thread = None
        self._clear_heartbeat()
        _log.info("CrashGuard desactivado — heartbeat limpiado")

    def _ticker(self):
        """Loop del daemon: actualiza el manifest cada CRASH_HEARTBEAT_SECS."""
        while not self._stop_evt.wait(timeout=CRASH_HEARTBEAT_SECS):
            with self._lock:
                if not self._active:
                    break
            self._write_manifest()

    def _write_manifest(self):
        """Escribe el manifest atómicamente (rename desde tmp)."""
        try:
            with self._lock:
                data = dict(self._manifest)
            data["heartbeat_iso"] = datetime.now().isoformat()
            data["pid"]           = os.getpid()

            tmp_path = _MANIFEST_PATH + ".tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
                # PATCH E-3 (auditado desde aecct2_stability_patch.py — ver
                # GAP-009): fsync antes del rename atómico. Sin esto, el
                # rename puede completarse en el filesystem mientras el
                # contenido del .tmp sigue solo en el buffer del SO — un
                # corte de energía justo después del rename deja un
                # manifest "atómico" pero con datos que nunca llegaron a
                # disco, exactamente el escenario que CrashGuard existe
                # para prevenir.
                f.flush()
                os.fsync(f.fileno())
            # Rename atómico en Linux (si falla a mitad, el anterior queda intacto)
            os.replace(tmp_path, _MANIFEST_PATH)

            # Heartbeat: archivo vacío para detección rápida sin parsear JSON
            with open(_HEARTBEAT_PATH, "w") as f:
                f.write(data["heartbeat_iso"] + "\n")
                f.flush()
                os.fsync(f.fileno())   # PATCH E-3
        except Exception as e:
            _log.warning("CrashGuard: no se pudo escribir manifest: %s", e)

    @staticmethod
    def _clear_heartbeat():
        """Elimina heartbeat y manifest al cerrar limpiamente."""
        for p in (_HEARTBEAT_PATH, _MANIFEST_PATH):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass

    @staticmethod
    def is_crash_pending() -> bool:
        """Retorna True si existe un heartbeat de sesión anterior sin limpiar."""
        return os.path.exists(_HEARTBEAT_PATH)

    @staticmethod
    def load_crash_manifest() -> Optional[dict]:
        """Carga el manifest de la sesión destruida. None si no existe o está corrupto."""
        if not os.path.exists(_MANIFEST_PATH):
            return None
        try:
            with open(_MANIFEST_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            _log.info("CrashGuard: manifest cargado — sesión del %s",
                      data.get("heartbeat_iso", "?"))
            return data
        except Exception as e:
            _log.warning("CrashGuard: no se pudo leer manifest: %s", e)
            return None

    @staticmethod
    def dismiss():
        """Descarta la sesión destruida sin intentar recuperarla."""
        CrashGuard._clear_heartbeat()
        _log.info("CrashGuard: sesión destruida descartada por el usuario")


# Singleton global del crash guard
_crash_guard = CrashGuard()


def _validate_crash_manifest(manifest: dict) -> tuple:
    """
    Valida que el manifest tenga los datos mínimos para intentar recuperación.

    Retorna (ok: bool, error_msg: str, recoverable_paths: list[str]).
    recoverable_paths son los archivos de audio encontrados en disco.
    """
    if not manifest:
        return False, "Manifest vacío", []

    tmp_path  = manifest.get("tmp_file", "")
    seg_paths = manifest.get("segment_paths", [])
    rate      = manifest.get("samplerate", 0)

    if not rate or rate < 1:
        return False, "Frecuencia de muestreo inválida en manifest", []

    # Buscar archivos recuperables
    candidates = []
    if tmp_path and os.path.exists(tmp_path) and os.path.getsize(tmp_path) > 512:
        candidates.append(tmp_path)
    for sp in seg_paths:
        if sp and os.path.exists(sp) and os.path.getsize(sp) > 512:
            if sp not in candidates:
                candidates.append(sp)

    if not candidates:
        return False, "No se encontraron archivos de audio recuperables en disco", []

    return True, "", candidates
