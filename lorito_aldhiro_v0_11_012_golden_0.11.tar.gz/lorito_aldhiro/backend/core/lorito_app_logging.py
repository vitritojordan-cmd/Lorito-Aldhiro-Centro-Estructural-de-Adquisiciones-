from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Configuración central de logging de la aplicación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import logging
from logging.handlers import RotatingFileHandler


# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES GLOBALES
# ─────────────────────────────────────────────────────────────────────────────

ARCHIVE_DIR = os.path.expanduser("~/AUX/fonogramas")
os.makedirs(ARCHIVE_DIR, exist_ok=True)

# ── Logger interno silencioso (rotativo, bajo overhead) ───────────────────────
_LOG_PATH = os.path.join(ARCHIVE_DIR, "aecct2_internal.log")
_log = logging.getLogger("aecct2")
_log.setLevel(logging.DEBUG)
_log.propagate = False
try:
    _fh = RotatingFileHandler(_LOG_PATH, maxBytes=2*1024*1024, backupCount=3)
    _fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    _log.addHandler(_fh)
except Exception:
    _log.addHandler(logging.NullHandler())
