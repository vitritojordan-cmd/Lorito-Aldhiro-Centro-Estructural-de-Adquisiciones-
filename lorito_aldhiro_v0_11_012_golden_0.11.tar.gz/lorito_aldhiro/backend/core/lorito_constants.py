from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Constantes compartidas de todo el backend (tamaños de buffer, umbrales, timeouts).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import logging
from collections import deque
import soundfile as sf


# ── Ring buffer: SOLO para VU/waveform en RAM (~90 s a 48kHz/1024) ────────────
# El audio COMPLETO siempre va a disco. Esta deque es para monitoreo visual.
MAX_RING_BLOCKS    = 4_500     # ~90 s de ventana visual a 48kHz/1024

# ── Cola de escritura a disco: NUNCA debe llenarse ────────────────────────────
# A 48kHz/1024/bloque → ~47 bloques/s. 32_000 bloques = ~11 min de cushion.
# Si se llena: se registra en log pero NO se descarta (bloqueo controlado).
DISK_QUEUE_MAXSIZE = 256_000  # v0.20.15 (legacy — mantenido para compatibilidad con telemetría GUI)

# ── Watchdog: bloques sin actividad antes de trigger ─────────────────────────

# ── DiskWriter: fsync periódico cada N bloques ───────────────────────────────
DISK_FSYNC_EVERY   = 400     # ~16 s a 48kHz/2048 — PATCH v0.20.13: 200→400 (reduce picos I/O que congelan drain)

# ── Playback streaming: parámetros de chunking ───────────────────────────────
# Lee disco en bloques de este tamaño; NUNCA carga el archivo completo.
PLAYBACK_CHUNK_FRAMES  = 4_096   # ~85ms @ 48kHz — tamaño de chunk de prefetch
# PATCH POPS/CRACS-A: 8→16 slots → ~1360ms de colchón (era 680ms).
# Con resampling y disco lento el prefetch puede vaciarse en <700ms.
# 16 slots garantizan que ningún slowdown breve de I/O provoque underrun.
PLAYBACK_RING_CHUNKS   = 4       # buffer de prefetch ≈341ms — latencia live ≤85ms con flush
PLAYBACK_SPEED_WINDOW  = 32_768  # ventana de resampleo por chunk (RAM constante)
# PATCH POPS/CRACS-B: 512→1024 → callback cada ~21ms @ 48kHz.
# Con blocksize=512 el callback se activa cada ~11ms; si el prefetch se
# retrasa un solo ciclo de disk read (≥5ms), el deque se vacía y hay
# underrun → pop.  1024 frames dan al prefetch el doble de margen.
PLAYBACK_BLOCKSIZE     = 512     # blocksize del OutputStream (~10ms @ 48kHz) — respuesta más ágil
# ── CAROLALDHIRA DRIFT CUIDADO! — Hardening nivel hardened ─────────────────
#   · PLAYBACK_RING_CHUNKS=8 (era 4): doble cushion contra subdesbordamiento RT
#   · Crossfade en flush speed-change: 128 frames de rampa lineal anti-clic
#   · Debounce mínimo 30ms entre set_speed() efectivos (anti-glitch de scrub)
#   · Underruns prolongados (>3 consecutivos) → warn en XRLOG
_UNDERRUN_HARDENED_LIMIT   = 5    # underruns RT consecutivos antes de warn XRLOG (era 3)
# PATCH POPS/CRACS-D: 128→256 frames de crossfade al flush por cambio de speed.
# 128 frames @ 48kHz = 2.7ms: demasiado corto para enmascarar el artefacto
# de fase al cambiar velocidad.  256 frames = 5.3ms — imperceptible al oído.
_SPEED_FLUSH_XFADE_FRAMES  = 256  # frames de crossfade al flush por cambio de speed
# v0.20.17: _SPEED_DEBOUNCE_SECS solo actúa en set_speed() (eventos discretos: press/release).
# El path live (set_speed_live) no hace flush → no necesita debounce.
# 0.005s = guardia mínima anti double-flush en eventos discretos consecutivos rápidos.
_SPEED_DEBOUNCE_SECS       = 0.005  # guardia mínima entre set_speed() discretos (v0.20.17: 0.012→0.005)
# v0.20.17: cursor de fase de resampleo. Se resetea a este valor solo tras flush/seek.
# Preservado entre chunks sucesivos → cero discontinuidades de fase entre chunks.
_PHASE_CURSOR_RESET        = 0.0    # valor inicial de _phase_cursor tras flush/seek

# ── Waveform progresivo: tamaño máximo del cache min/max ─────────────────────
WAVEFORM_CACHE_MAX_POINTS = 4_000  # puntos de envelope máximos en RAM

# ── Telemetría RAM: umbrales (MB) ────────────────────────────────────────────
RAM_THRESHOLD_HIGH_MB     = 300    # warning
RAM_THRESHOLD_CRITICAL_MB = 500    # activar modo protección

# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTES v0.08
# ══════════════════════════════════════════════════════════════════════════════

# ── Pre-roll circular ─────────────────────────────────────────────────────────
PREROLL_SECS          = 15        # segundos de pre-roll en RAM antes de REC
PREROLL_MAX_SECS      = 30        # máximo configurable
PREROLL_MIN_SECS      = 0         # 0 = desactivado

# ── Drift temporal: umbral de warning ────────────────────────────────────────
DRIFT_WARN_MS         = 100.0     # ms de drift antes de warning
DRIFT_CHECK_INTERVAL  = 10.0      # segundos entre chequeos de drift

# ── AUTO-PAUSA POR SILENCIO (CAROLA TE ESTA ESPERANDO) ───────────────────────
# ── CRAC_UNIVERSAL_THRESHOLD_PROFILE — detector multi-criterio adaptativo ────
# ── v0.20.8: UMBRAL ANCLADO AL AUDIO DE REFERENCIA (aecct2_20260520_202133.wav)
#
# ANALYSIS:
#   RMS Window:              800 ms
#   Analysis Rate:           15 Hz  (timer_vu = 67 ms/tick)
#   Sidechain Filters:       HPF 120 Hz / LPF 4.8 kHz
#   Spectral Flux:           enabled
#   Stationary Hiss Reject.: DISABLED  (señal de referencia ES el hiss que activa)
#   Midband Activity:        DISABLED  (ídem — cualquier señal audible libera pausa)
#   Transient Detector:      enabled
#
# REFERENCE AUDIO ANALYSIS (aecct2_20260520_202133.wav):
#   Duration:     10.475 s  |  48 kHz 24-bit stereo
#   Peak (max):  -74.49 dBFS  →  0.00018859 lin  ← CEILING DE ACTIVACIÓN
#   Peak (p99):  -74.89 dBFS  →  0.00018009 lin
#   RMS global:  -86.95 dBFS  →  0.00004490 lin  ← FLOOR DE ACTIVACIÓN
#   Spectral:    LF 80.3%  MID 4.9%  HF 14.8%
#   → Perfil de hum grave (LF dominante) con componente HF residual
#
# NUEVA LÓGICA DE UMBRAL (v0.20.8):
#   · El umbral de activación (pausa) se ancla DIRECTAMENTE al ceiling del audio
#     de referencia: cualquier señal ≤ ceiling_ref activa el contador de silencio.
#   · No hay calibración ni EMA de subida: el techo es fijo desde el inicio.
#   · El audio de referencia (hiss, zumbido, hum) ES el nivel de "silencio".
#   · Activación: 5 s continuos con señal ≤ ceiling_ref (ambos perfiles).
#   · Release: señal mínimamente audible (clip, zumbido, hiss por encima del
#     ceiling_ref + 0 dB) libera la pausa en el primer tick válido.
#   · Sensibilidad de activación Y desactivación: τ = 0.5 µs (1 tick a 15 Hz).
#
# AUTO-PAUSE ACTIVATION (v0.20.8):
#   Peak ≤ SILENCE_REF_CEILING_LIN  (= -74.49 dBFS)  durante 5 s continuos
#   RMS  ≤ SILENCE_REF_RMS_LIN      (= -86.95 dBFS)  durante 5 s continuos
#   Sin perfil diferenciado: AMBOS perfiles usan 5 s.
#
# AUTO-PAUSE RELEASE (v0.20.8 — fast-release ultra-sensible):
#   Cualquier señal audible por encima del ceiling:
#   Peak > SILENCE_REF_CEILING_LIN  OR  RMS > SILENCE_REF_RMS_LIN
#   → Libera la pausa en el PRIMER TICK donde se detecta señal (τ = 0.5 µs).
#   Sin hold de release: el mínimo clip, zumbido o hiss libera inmediatamente.
#
# HYSTERESIS (v0.20.8):
#   Activación: señal ≤ ceiling_ref  (0 dB de margen — techo exacto)
#   Release:    señal > ceiling_ref  (0 dB — mismo techo, sentido contrario)
#   Histéresis efectiva: 0 dB (detector binario: silencio/señal sobre el techo)
#
# FAILSAFE:
#   Pause Cooldown:          5 s
#   Maximum Pause Frequency: 3 pauses / minute
#   Ignore Pause During:     XRUN recovery / buffer stress /
#                            export blocking / callback overload
#
# REALTIME SAFETY:
#   Auto-pause thread priority:  LOW
#   Capture thread priority:     MAXIMUM
#   DSP overload policy:         degrade gracefully
#   Buffer policy:               expand before drop
#   Callback policy:             never block

# ── Ventana y tasa de análisis ───────────────────────────────────────────────
SILENCE_WINDOW_MS            = 800     # ms de ventana de análisis RMS (CRAC: 800 ms)
SILENCE_ANALYSIS_RATE_HZ     = 15      # Hz: tasa de análisis (timer_vu = 67 ms)
SILENCE_ANALYSIS_INTERVAL_MS = 67      # ms: intervalo del timer_vu (1000 / 15 ≈ 67 ms)

# ── Calibración adaptativa del noise floor ────────────────────────────────────
# v0.20.8: la calibración sigue activa para determinar _sil_ceiling_ref en
# runtime, pero los umbrales fijos de fallback están anclados al audio de
# referencia. Si la calibración produce un ceiling más bajo que el de la
# referencia, se usa el de la referencia (el más conservador — más señal
# entra en la zona de "silencio").
SILENCE_CALIB_SECS           =  4.0    # s: duración de calibración inicial
SILENCE_NOISE_TRACK_TAU      = 30.0    # s: constante de tiempo EMA (slow adaptive tracking)
SILENCE_EMA_UP_TAU_US        =  0.5    # µs: τ de subida del EMA — respuesta instantánea.
                                       # α_up = 1 - exp(-67ms / 0.5µs) ≈ 1.0 en 1 tick.
                                       # TANTO activación COMO release reaccionan en ≤ 1 tick.

# ── v0.20.8: Umbral de referencia anclado al audio de referencia ─────────────
# Derivados del análisis de aecct2_20260520_202133.wav (48 kHz, 24 bit, estéreo):
#   Peak máximo observado:  -77.02 dBFS  →  0.00014091 lin  (medición precisa mono-mix)
#   RMS global del audio:   -88.74 dBFS  →  0.00003656 lin
#   p99 block RMS (67ms):   -84.58 dBFS  →  0.00005900 lin
#
# UMBRAL DE ACTIVACIÓN (PAUSA) — v0.20.9:
#   El umbral debe estar SOBRE el pico del audio de referencia con margen generoso,
#   para que el ruido de referencia quede DENTRO de la zona de silencio.
#   Margen: peak_ref × 6  (+15.6 dB sobre el peak) = -61.46 dBFS.
#   El audio de referencia (-77.02 dBFS peak) queda 15.6 dB por debajo del umbral
#   → siempre detectado como silencio.
#   Cualquier señal audible (clip, zumbido, hiss de programa) que supere -61.46 dBFS
#   libera la pausa en el primer tick.
#
# UMBRAL DE RELEASE — idéntico al de activación (histéresis 0 dB, detector binario).
# Sensibilidad τ = 0.5 µs para activación Y release (1 tick a 15 Hz).
SILENCE_REF_PEAK_DBFS        = -77.02  # dBFS peak: peak real del audio de referencia
SILENCE_REF_RMS_DBFS_RAW     = -88.74  # dBFS RMS:  RMS real del audio de referencia
SILENCE_REF_CEILING_DBFS     = -61.46  # dBFS: umbral de activación = ref_peak + 15.6 dB (×6 lin)
SILENCE_REF_RMS_DBFS         = -73.18  # dBFS: umbral RMS activación = ref_rms  + 15.6 dB (×6 lin)
SILENCE_REF_CEILING_LIN      = 8.454e-04   # lineal: 10^(-61.46/20) ≈ 0.000845  (ref_peak × 6)
SILENCE_REF_RMS_LIN          = 2.193e-04   # lineal: 10^(-73.18/20) ≈ 0.000219  (ref_rms  × 6)

# ── Offsets de activación respecto al reference adaptativo ───────────────────
# v0.20.9: offsets en 0 dB — el umbral ES SILENCE_REF_CEILING_LIN directamente.
SILENCE_ACT_RMS_OFFSET_DB    =  0.0    # dB: sin offset adicional sobre el umbral fijo
SILENCE_ACT_PEAK_OFFSET_DB   =  0.0    # dB: sin offset adicional sobre el umbral fijo

# ── Offsets de release respecto al reference adaptativo ──────────────────────
# v0.20.9: histéresis 0 dB — release al mismo nivel que la activación.
SILENCE_REL_RMS_OFFSET_DB    =  0.0    # dB: release al mismo nivel que activación
SILENCE_REL_PEAK_OFFSET_DB   =  0.0    # dB: release al mismo nivel que activación

# ── Umbrales fijos de fallback (usados pre-calibración y como base) ──────────
# v0.20.9: anclados al umbral de activación (= ref_peak × 6).
# El audio de referencia (-77.02 dBFS) queda 15.6 dB por debajo → siempre silencio.
SILENCE_RMS_THRESH_DB        = -73.18  # dBFS RMS:  umbral activación (ref_rms  × 6)
SILENCE_PEAK_THRESH_DB       = -61.46  # dBFS peak: umbral activación (ref_peak × 6)
SILENCE_RELEASE_RMS_DB       = -73.18  # dBFS RMS: solo para logging/display (no usado en release)
SILENCE_RELEASE_PEAK_DB      = -55.46  # dBFS peak: umbral release = activación + 6 dB
SILENCE_RELEASE_PEAK_LIN     =  1.6866e-03  # lineal: 10^(-55.46/20)

# ── Timing de activación y release ───────────────────────────────────────────
# v0.20.9: activación a los 5 s exactos de señal continua bajo el umbral.
# Release: sin hold — el primer tick con señal > umbral libera inmediatamente.
# τ activación/release = 0.5 µs → α ≈ 1.0 → respuesta en 1 tick (67 ms).
SILENCE_AUTOPAUSE_SECS       =  5.0    # s: pausa tras 5 s de señal ≤ umbral
SILENCE_AUTOPAUSE_SECS_B     =  5.0    # s: ídem (ambos perfiles unificados)
# FIX-FLIP-AUDIO-GATE (v0.22.20): en la zona de tolerancia del Lado A y Lado B
# el silencio requerido para activar la auto-pausa es 60 s (1 minuto), no 5 s.
# Así la grabación no se interrumpe por silencios breves dentro de tolerancia.
SILENCE_AUTOPAUSE_SECS_TOL   =  5.0   # s: pausa en zona de tolerancia/nominal (5 s) — FIX v0.22.26
SILENCE_GUARD_ESCAPE_SECS    =  0.0   # s: FIX-FORCED-PAUSE-ESCAPE (v0.22.44): primer tick silencioso (~67ms) convierte pausa forzada por tope en pausa ordinaria
                                       # FIX v0.22.33: 1 s (antes 3 s) — mismo colchón de detección
                                       # que SILENCE_REF_CEILING_DBFS (-61.46 dBFS); suficiente para
                                       # distinguir silencio real de un transitorio de programa
SILENCE_RELEASE_SECS         =  0.0    # s: sin hold temporal — la confirmación es por ticks
SILENCE_RELEASE_MIN_TICKS    =  3      # ticks consecutivos sobre el umbral para confirmar release
                                       # 3 ticks × 67 ms ≈ 200 ms — filtra clics/pops aislados

# ── CRAC-PROFILE: clasificador de perfil espectral ───────────────────────────
# v0.20.8: el clasificador sigue activo para logging/telemetría, pero NO afecta
# el tiempo de activación (unificado a 5 s). Los umbrales se mantienen para
# compatibilidad con el código de clasificación existente.
#
# Perfil A — hum grave / deck sin cinta:
#   sub-bass (0–120 Hz) > 50 %  →  señal dominada por bajo / hum eléctrico
#   hiss (>4 kHz)       < 12 %  →  poca energía de alta frecuencia
CRAC_PROFILE_A_SUBBASS_MIN   = 0.50   # fracción mínima de energía sub-bass para A
CRAC_PROFILE_A_HISS_MAX      = 0.12   # fracción máxima de energía hiss (>4 kHz) para A
CRAC_PROFILE_A_ZCR_MAX       = 0.12   # ZCR máximo para A
CRAC_PROFILE_A_FLATNESS_MAX  = 0.12   # flatness máxima para A

# Perfil B — hiss de cinta cassette:
#   hiss (>4 kHz)       > 20 %  →  energía HF significativa (hiss de óxido)
#   ZCR                 > 0.13  →  actividad de cruce por cero elevada (ruido HF)
#   flatness            > 0.15  →  espectro más plano (ruido broadband de cinta)
CRAC_PROFILE_B_HISS_MIN      = 0.20   # fracción mínima de energía hiss (>4 kHz) para B
CRAC_PROFILE_B_ZCR_MIN       = 0.13   # ZCR mínimo para B
CRAC_PROFILE_B_FLATNESS_MIN  = 0.15   # flatness mínima para B

# ── Confirmación espectral ────────────────────────────────────────────────────
SILENCE_SPECTRAL_CONFIRM     = True    # confirmar silencio con análisis espectral
SILENCE_BLINK_INTERVAL_MS    = 480     # ms entre parpadeos en modo CAROLA ESPERANDO

# ── Sidechain de análisis (filtrado previo al detector) ──────────────────────
SILENCE_SC_HPF_HZ            = 120.0   # Hz: corte HPF del sidechain (elimina hum/HVAC)
SILENCE_SC_LPF_HZ            = 4800.0  # Hz: corte LPF del sidechain

# ── Flags de rechazo avanzado ────────────────────────────────────────────────
# v0.20.8: HISS_REJECTION y MIDBAND_DETECTOR desactivados.
# El audio de referencia ES un perfil de hiss/hum; rechazarlo bloqueaba la
# detección de silencio. Cualquier señal sobre el ceiling libera la pausa.
SILENCE_SPECTRAL_FLUX_GATE   = True    # gate de flux espectral: rechaza transientes
SILENCE_HISS_REJECTION       = False   # DESACTIVADO v0.20.8: el hiss es el silencio
SILENCE_MIDBAND_DETECTOR     = False   # DESACTIVADO v0.20.8: señal audible = release
SILENCE_TRANSIENT_DETECTOR   = True    # veto de release si hay transiente detectado

# ── Failsafe: cooldown y límite de frecuencia de pausa ───────────────────────
SILENCE_PAUSE_COOLDOWN_SECS  =  5.0    # s: mínimo entre pausas automáticas consecutivas
SILENCE_MAX_PAUSES_PER_MIN   =  3      # máximo de pausas automáticas por minuto
SILENCE_PAUSE_RATE_WINDOW    = 60.0    # s: ventana de tiempo para contar pausas (1 min)

# ── Snapshot recovery ─────────────────────────────────────────────────────────
SNAPSHOT_INTERVAL_SECS = 60       # guardar snapshot cada N segundos de grabación
SNAPSHOT_SUBDIR        = "snapshots"

# ── Crash recovery (v0.19 CrashGuard) ────────────────────────────────────────
# Archivo de heartbeat: su presencia al arrancar indica un crash previo.
CRASH_HEARTBEAT_FILE   = ".aecct2_session_active"   # relativo a ARCHIVE_DIR
# Manifest de sesión destruida: JSON con todo lo necesario para reexportar.
CRASH_MANIFEST_FILE    = ".aecct2_crash_manifest.json"  # relativo a ARCHIVE_DIR
# Intervalo de actualización del heartbeat + manifest (segundos)
CRASH_HEARTBEAT_SECS   = 15

# ── XRun Forensics log ────────────────────────────────────────────────────────
XRLOG_FILENAME         = "capture_session.xrlog"   # nombre del log de xruns
XRLOG_MAX_BYTES        = 2 * 1024 * 1024            # 2 MB: rotar al superar

# ── Telemetría compacta: ventana de muestreo ─────────────────────────────────
TELEMETRY_WINDOW_SECS  = 5.0      # ventana para calcular MB/s y jitter promedio

# ── Backpressure v0.08: nivel EXTREME ────────────────────────────────────────
BP_EXTREME_RATIO       = 0.95     # > 95% cola → EXTREME

# ── Clipping detector ────────────────────────────────────────────────────────
CLIP_THRESHOLD         = 0.999    # nivel de clip (float32 [-1, 1])

# ── Modo Archival Safe ────────────────────────────────────────────────────────
ARCHIVAL_SAFE_FPS      = 10       # FPS GUI en modo archival (vs 30)
ARCHIVAL_SAFE_WATCHDOG = 2.0      # watchdog más agresivo en segundos

# ── Opciones de codec para la UI ─────────────────────────────────────────────
# Listas que pueblan los QComboBox en _update_codec_ui().
# Los dicts *_SUBTYPE / *_COMP_N / *_QUAL_N / WV_FLAGS mapean cada label
# al valor interno que usan los exporters.
WAV_DEPTHS  = ["16-bit PCM", "24-bit PCM", "32-bit PCM", "32-bit Float"]
WAV_SUBTYPE = {
    "16-bit PCM":   "PCM_16",
    "24-bit PCM":   "PCM_24",
    "32-bit PCM":   "PCM_32",
    "32-bit Float": "FLOAT",
}

FLAC_DEPTHS  = ["16-bit PCM", "24-bit PCM"]
FLAC_SUBTYPE = {
    "16-bit PCM": "PCM_16",
    "24-bit PCM": "PCM_24",
}
FLAC_COMPS  = ["0 (sin comprimir)", "1", "2", "3", "4 (estandar)", "5", "6", "7", "8 (maximo)"]
FLAC_COMP_N = {
    "0 (sin comprimir)": 0, "1": 1, "2": 2, "3": 3,
    "4 (estandar)": 4,      "5": 5, "6": 6, "7": 7,
    "8 (maximo)": 8,
}

OGG_QUALS  = ["1 (baja)", "2", "3", "4", "5 (estandar)", "6", "7", "8", "9", "10 (maxima)"]
OGG_QUAL_N = {
    "1 (baja)": 1, "2": 2, "3": 3, "4": 4,
    "5 (estandar)": 5, "6": 6, "7": 7, "8": 8,
    "9": 9, "10 (maxima)": 10,
}

WV_MODES = ["Rapido", "Estandar", "Alto", "Maximo"]
WV_FLAGS  = {
    "Rapido":    "1",
    "Estandar":  "5",
    "Alto":      "7",
    "Maximo":    "8",
}

# ── Perfiles de latencia (blocksize del stream de captura) ────────────────────
# Usados en start_record() para seleccionar el blocksize inicial.
# Los valores coinciden con los bs_candidates del motor (512, 1024, 2048, 4096).
LATENCY_PROFILES = {
    "low":      512,    # ~10.7 ms @ 48 kHz — menor latencia, más CPU
    "balanced": 2048,   # ~42.7 ms @ 48 kHz — equilibrio latencia/estabilidad
    "safe":     4096,   # ~85.3 ms @ 48 kHz — máxima estabilidad, sesiones largas
}
DEFAULT_PROFILE = "balanced"

# ── Prioridades RT (SCHED_FIFO) ───────────────────────────────────────────────
# Usadas por _apply_rt_via_rtkit(), _set_rt_priority() y _init_rt_privileges().
# Los mismos valores se replican como atributos de clase en CaptureEngineV2
# (_RT_PRIORITY_*) para uso interno del motor; estas constantes de módulo son
# la referencia canónica para el resto del código.
RT_PRIORITY_CALLBACK   = 80   # callback sounddevice (mayor prioridad)
RT_PRIORITY_DRAIN      = 58   # thread de drain / procesamiento
RT_PRIORITY_DISK       = 45   # thread de escritura a disco

# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 1: CONSTANTES DEL NUEVO MOTOR
# ══════════════════════════════════════════════════════════════════════════════

# ── Clock y timing ────────────────────────────────────────────────────────────
CE_SAMPLE_RATE_DEFAULT   = 48_000
CE_CHANNELS              = 2

# ── Buffers multinivel ────────────────────────────────────────────────────────
#
# NIVEL 0 — Slot atómico de intercambio callback→drain (lock-free):
#   Un solo slot de frames para transferencia zero-lock entre el callback RT
#   y el drain. El callback escribe; el drain lee. No hay overrun posible:
#   si el drain es lento, el slot de sobrescritura absorbe el exceso.
#
# NIVEL 1 — Ring Buffer de Absorción (RBA):
#   Buffer principal de absorción. Dimensionado para absorber bursts del
#   scheduler de hasta 8 segundos sin pérdida. Inspirado en el buffer
#   antiskip de reproductores CD portátiles: mantiene audio suficiente
#   para que un stall de disco/CPU de varios segundos sea invisible.
#   Prealocado completamente al inicio. Sin allocaciones dinámicas.
#
# NIVEL 2 — Cola Elástica de Disco (CED):
#   Cola entre drain y DiskWriter. Capacidad generosa para absorber picos
#   de I/O lento. El drain NUNCA bloquea por esta cola.
#
# NIVEL 3 — Buffer de Prefetch de Disco (BPD):
#   Buffer de escritura agrupada para el DiskWriter. Agrupa bloques en
#   batches de 64KB antes de escribir a disco, reduciendo llamadas a
#   sf.write() y la presión de fsync.

# ── RBA: Ring Buffer de Absorción ─────────────────────────────────────────────
# 8 segundos de audio a 48kHz/2048 = ~187 bloques. Usamos 512 para tener
# margen ante blocksize variable y para soportar stalls de scheduler hasta
# ~20s en condiciones extremas.
CE_RBA_SLOTS            = 512      # slots prealocados en el Ring de Absorción
CE_RBA_FRAMES_MAX       = 4096     # máximo frames por bloque (blocksize máximo)
CE_RBA_WATERMARK_LOW    = 0.10     # 10% → presión baja, drenar agresivamente
CE_RBA_WATERMARK_MID    = 0.30     # 30% → presión media
CE_RBA_WATERMARK_HIGH   = 0.60     # 60% → presión alta, reducir velocidad drain
CE_RBA_WATERMARK_CRIT   = 0.85     # 85% → crítico, máxima velocidad drain

# ── CED: Cola Elástica de Disco ───────────────────────────────────────────────
CE_CED_CAPACITY         = 512_000  # frames máximos en cola elástica (~10min)
CE_CED_BATCH_FRAMES     = 65536    # frames por batch de escritura a disco (~1.4s)

# ── Drain loop: parámetros adaptativos ───────────────────────────────────────
CE_DRAIN_SLEEP_MIN_US   = 100      # 100µs — sleep mínimo del drain (µs)
CE_DRAIN_SLEEP_MAX_US   = 5000     # 5ms — sleep máximo del drain (µs)
CE_DRAIN_BATCH_MIN      = 1        # mínimo bloques por ciclo de drain
CE_DRAIN_BATCH_MAX      = 256      # máximo bloques por ciclo de drain

# ── Watchdog: fases de alerta ─────────────────────────────────────────────────
CE_WD_TICK_SECS         = 0.25     # tick del watchdog (250ms)
CE_WD_YELLOW_SECS       = 1.5     # 1.5s sin callback → YELLOW
CE_WD_ORANGE_SECS       = 3.5     # 3.5s sin callback → ORANGE (expansión defensiva)
CE_WD_RED_SECS          = 7.0     # 7.0s sin callback → RED (recovery)

# ── Watermark dinámico: histéresis ────────────────────────────────────────────
CE_WM_HYSTERESIS        = 0.05    # banda de histéresis del watermark (±5%)

# ── Recovery: backoff ────────────────────────────────────────────────────────
CE_RECOVERY_MAX_ATTEMPTS= 12
CE_RECOVERY_BACKOFF_BASE= 0.2     # 200ms inicial
CE_RECOVERY_BACKOFF_CAP = 12.0    # 12s máximo
CE_RECOVERY_COOLDOWN    = 45.0    # 45s entre cadenas de recovery

# ── DiskWriter ────────────────────────────────────────────────────────────────
CE_DISK_FSYNC_EVERY     = 400     # fsync cada N bloques escritos
CE_DISK_WRITE_RETRY_MAX = 3       # reintentos ante excepción de sf.write()
CE_DISK_WRITE_RETRY_SLEEP= 0.010  # 10ms entre reintentos

# GAP-064: margen de "settle" para `DiskWriterV2.flush()` tras ver la
# CED vacía — cubre el batch en vuelo (`f.write()` ya en curso cuando
# la cola llegó a 0) sin depender de que el hilo de escritura haya
# TERMINADO (`_flush_done` solo se marca al salir del hilo, nunca
# mientras sigue activo esperando más datos). Generoso frente al peor
# caso real: un batch de CE_CED_BATCH_FRAMES (~1.4s de audio, cientos
# de KB en disco) más CE_DISK_WRITE_RETRY_MAX reintentos de
# CE_DISK_WRITE_RETRY_SLEEP cada uno (~30ms) — sin este límite, cada
# llamada a `flush()` con el hilo aún activo esperaba el `timeout`
# COMPLETO (30s por defecto) sin motivo, medido con ejecución real.
CE_DISK_FLUSH_SETTLE_MAX_S = 2.0

# ── Pre-roll ──────────────────────────────────────────────────────────────────
CE_PREROLL_SECS_DEFAULT = 15      # segundos de pre-roll
CE_PREROLL_SECS_MAX     = 30      # máximo configurable

# ── Jitter y drift ────────────────────────────────────────────────────────────
CE_JITTER_EWMA_ALPHA    = 0.08    # factor EMA para jitter
CE_DRIFT_CHECK_SECS     = 10.0    # intervalo de chequeo de drift
CE_DRIFT_WARN_MS        = 100.0   # ms de drift antes de warning

# ── Telemetría ────────────────────────────────────────────────────────────────
CE_JITTER_HIST_SIZE     = 512     # slots del histograma circular de jitter
CE_LATENCY_BUF_SIZE     = 100     # ventana de latencias de callback

# [LIMPIEZA v0.22.01] _CE_LIBC eliminado — usar _LIBC (singleton global, líneas 13-18)

_ce_log = logging.getLogger("crac.capture_engine")
