from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Parches de compatibilidad aplicados al arrancar la aplicación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import math as _math

from lorito_aldhiro.backend.audio.lorito_audio_backend import _status

# [LIMPIEZA v0.22.01 BUG10] Imports redundantes eliminados (json, os, time, math,
# threading, enum, typing, numpy ya importados globalmente en líneas 3-22).
# Dict, Any migrados al import global de typing.

# ─────────────────────────────────────────────────────────────────────────────
#  PARCHE DE BackendStatus — nuevos campos sin romper __slots__
# ─────────────────────────────────────────────────────────────────────────────

def _patch_backend_status() -> None:
    """
    Inyecta los campos nuevos de v0.21 en la instancia global _status.
    Se ejecuta una sola vez al importar el patch.
    No modifica __slots__ (que es inmutable) — añade los atributos directamente.
    Esto es seguro porque BackendStatus.snapshot() usa getattr() sobre __slots__,
    y los campos nuevos simplemente no aparecerán en snapshots viejos (retrocompatible).
    """
    # NOTA MODULARIZACION: el original hacia "from __main__ import _status"
    # (valido solo cuando todo el codigo vivia en un unico script). En la
    # version modular, _status vive en backend.audio_backend; se importa
    # directamente para que el parche se aplique siempre, igual que en el
    # monolito original al ejecutarse como script unico.
    _st = _status

    defaults = {
        # AUTO / preset decision fields
        "auto_normalization_decision":     "",   # str: decisión compacta del modo AUTO
        "auto_normalization_reason":       "",   # str: razón detallada de la decisión
        # Extra normalization metrics (v0.21)
        "normalization_rms_final_db":      float("-inf"),  # RMS post-normalización
        "normalization_percentile_5":      float("-inf"),  # percentil 5 RMS (bloques)
        "normalization_percentile_95":     float("-inf"),  # percentil 95 RMS (bloques)
        "normalization_true_peak_final_db":float("-inf"),  # true peak post-normalización
        "normalization_report_path":       "",   # ruta al reporte JSON guardado
    }
    for attr, val in defaults.items():
        if not hasattr(_st, attr):
            object.__setattr__(_st, attr, val)


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS — reutiliza los del módulo principal si están disponibles
# ─────────────────────────────────────────────────────────────────────────────

def _db_to_lin(db: float) -> float:
    return 10.0 ** (db / 20.0)

def _lin_to_db(lin: float) -> float:
    if lin < 1e-12:
        return float("-inf")
    return 20.0 * _math.log10(lin)
