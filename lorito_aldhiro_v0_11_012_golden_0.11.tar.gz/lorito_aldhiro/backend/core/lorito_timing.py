from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Reloj de captura monotónico y utilidades de sincronización temporal.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import threading
import time
import ctypes
import ctypes.util
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_constants import CE_SAMPLE_RATE_DEFAULT
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _LIBC, _Timespec



# ─────────────────────────────────────────────────────────────────────────────
#  v0.09 — TIMESTAMPING MONOTÓNICO INTERNO (CLOCK_MONOTONIC_RAW)
# ─────────────────────────────────────────────────────────────────────────────

CLOCK_MONOTONIC_RAW = 4  # Linux kernel/time.h — sin ajuste NTP

def _monotonic_raw_ns() -> int:
    """
    Lee CLOCK_MONOTONIC_RAW via ctypes (Linux).
    Retorna nanosegundos. Sin allocations. Fallback a time.monotonic_ns().
    No usar dentro del callback RT — solo para drain/disk/watchdog.
    Usa el singleton _LIBC — sin carga dinámica repetitiva.

    """
    if sys.platform != "linux" or _LIBC is None:
        return time.monotonic_ns()
    try:
        ts = _Timespec()
        if _LIBC.clock_gettime(CLOCK_MONOTONIC_RAW, ctypes.byref(ts)) == 0:
            return ts.tv_sec * 1_000_000_000 + ts.tv_nsec
    except Exception:
        pass
    return time.monotonic_ns()


def _monotonic_raw_ms() -> float:
    """Retorna CLOCK_MONOTONIC_RAW en milisegundos."""
    return _monotonic_raw_ns() / 1_000_000.0


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 2: CLOCK MONOTÓNICO HARDENED
#  Desacoplado del reloj del sistema, de la GUI y del encoder.
#  Fuente de verdad temporal para toda la sesión de captura.
# ══════════════════════════════════════════════════════════════════════════════



class CaptureClock:
    """
    Reloj lógico de captura: clock monotónico hardened con PLL suave
    para corrección de drift. Desacoplado de GUI, encoder y sistema.

    FILOSOFÍA:
    El clock lógico de captura debe ser independiente del wall clock.
    Deriva frames_received y frames_written para detectar y corregir
    drift acumulativo sin reiniciar el pipeline.

    PLL SUAVE:
    Si la tasa de llegada de frames difiere de sample_rate por más de
    drift_ppm_threshold ppm (partes por millón), aplica corrección
    progresiva en el contador lógico de frames esperados.
    Corrección máxima: 10 ppm/check para suavidad fonográfica.
    """

    def __init__(self, sample_rate: int = CE_SAMPLE_RATE_DEFAULT):
        self._rate          = sample_rate
        self._t0_ns         = _monotonic_raw_ns()
        self._frames_recv   = 0           # frames recibidos por callback
        self._frames_written= 0           # frames escritos a disco
        self._drift_ms      = 0.0         # drift actual en ms
        self._drift_ppm     = 0.0         # drift en ppm
        self._last_check_ns = self._t0_ns
        self._lock          = threading.Lock()
        # PLL
        self._pll_correction= 0.0         # corrección acumulada en frames
        self._pll_ppm_max   = 200.0       # máximo 200ppm de corrección/check

    def tick_received(self, n_frames: int):
        """Llamado por el callback RT. Path crítico — mínimo overhead."""
        self._frames_recv += n_frames

    def tick_written(self, n_frames: int):
        """Llamado por DiskWriter. No-RT."""
        self._frames_written += n_frames

    def check_drift(self) -> float:
        """
        Calcula drift entre frames esperados (según reloj real) y
        frames escritos. Aplica corrección PLL suave.
        Retorna drift en ms (positivo = más frames escritos de los esperados).
        """
        now_ns   = _monotonic_raw_ns()
        elapsed_s = (now_ns - self._t0_ns) / 1e9
        expected_frames = elapsed_s * self._rate
        written_frames  = self._frames_written

        # Drift en frames, luego en ms
        drift_frames = written_frames - expected_frames
        drift_ms     = (drift_frames / max(self._rate, 1)) * 1000.0
        drift_ppm    = (drift_frames / max(expected_frames, 1)) * 1_000_000.0

        with self._lock:
            self._drift_ms  = drift_ms
            self._drift_ppm = drift_ppm

        # PLL: si drift > umbral, ajustar _pll_correction
        # La corrección se aplica como offset al expected_frames en el
        # próximo chequeo, suavizando progresivamente.
        if abs(drift_ppm) > 50.0:  # umbral 50ppm (~2.4ms/min a 48kHz)
            correction_ppm = min(abs(drift_ppm) * 0.1, self._pll_ppm_max)
            if drift_ppm > 0:
                correction_ppm = -correction_ppm
            self._pll_correction += correction_ppm
            self._pll_correction  = max(-500.0, min(500.0, self._pll_correction))

        return drift_ms

    @property
    def drift_ms(self) -> float:
        return self._drift_ms

    @property
    def frames_received(self) -> int:
        return self._frames_recv

    @property
    def frames_written(self) -> int:
        return self._frames_written

    @property
    def session_secs(self) -> float:
        return (_monotonic_raw_ns() - self._t0_ns) / 1e9

    def reset(self, sample_rate: Optional[int] = None):
        if sample_rate:
            self._rate = sample_rate
        self._t0_ns          = _monotonic_raw_ns()
        self._frames_recv    = 0
        self._frames_written = 0
        self._drift_ms       = 0.0
        self._drift_ppm      = 0.0
        self._pll_correction = 0.0
        self._last_check_ns  = self._t0_ns
