"""
lorito_aldhiro.backend.dsp — perfiles y utilidades DSP de la cadena de
procesamiento en tiempo real (`NRCoordinator`).

Rama del árbol de módulos de Lorito Aldhiro (ver GAP-032): a partir de
esa sesión, todo subpaquete conecta sus módulos aquí — nunca se deja
un `__init__.py` vacío como simple marcador de paquete. Este
`__init__.py` estaba vacío desde su creación; poblado en GAP-037.

Módulos:
  · lorito_dsp_mpx            — `MpxProfile` (filtro de piloto FM).
  · lorito_dsp_eq_bias        — `TapeEqBiasProfile` (voicing/headroom por tipo de cinta).
  · lorito_dsp_focus          — `FocusProfile` (azimuth).
  · lorito_dsp_finite_guard   — `DSP_NONFINITE_OUTPUT` (GAP-025, Fase 10).
  · lorito_dsp_numba_utils    — utilidades JIT opcionales (fallback puro-Python).
  · lorito_dsp_resample_continuous — `resample_stateful_continuous()`
    (GAP-037): corrección medida de la deriva de fase de
    `_resample_stateful` (retirado del motor); hoy solo la usa la ruta de
    exportación (ver docstring del módulo).
"""

from lorito_aldhiro.backend.dsp.lorito_dsp_mpx import MpxProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_eq_bias import TapeEqBiasProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_focus import FocusProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import (
    sanitize_finite, DSP_SANITIZE_CLIP,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_resample_continuous import (
    resample_stateful_continuous, HISTORY_LEN,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_cristhi_cosh import CristhiCoshProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_antipestal_lola_grillo import AntipestalLolaProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import VersionOTronProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida import LuchaEnloquecidaProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import (
    MuscleEqSamirProfile, EqBand, EqBandType, MuscleEqError,
)
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import (
    MUSCLE_EQ_PRESET_CATEGORIES, get_preset_bands, list_presets_flat,
)

__all__ = [
    "MpxProfile", "TapeEqBiasProfile", "FocusProfile",
    "sanitize_finite", "DSP_SANITIZE_CLIP",
    "resample_stateful_continuous", "HISTORY_LEN",
    "CristhiCoshProfile", "AntipestalLolaProfile", "VersionOTronProfile",
    "LuchaEnloquecidaProfile",
    "MuscleEqSamirProfile", "EqBand", "EqBandType", "MuscleEqError",
    "MUSCLE_EQ_PRESET_CATEGORIES", "get_preset_bands", "list_presets_flat",
]
