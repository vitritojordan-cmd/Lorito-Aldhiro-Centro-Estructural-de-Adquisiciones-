from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Emulación arqueosónica de degradación de cinta "Gancha Striker/Kari" (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_antipestal_lola_grillo.py -- GAP-041, DSP "Antipestal de
Lola Grillo (PREVI)" -- adaptado desde CRAC (tarball
crac_v0_37_416_quad_previ_chain_derived_export, modulo original
crac.dsp_previ.antipestal_lola_grillo) al catalogo de Lorito Aldhiro.

Emulacion arqueosonica de dos "soportes" ficticios de CRAC (Gancha
Striker / Gancha Kari): limitacion de ancho de banda, ruido de piso
(marron/rosa), no linealidad con memoria (Volterra), "raspado" tipo
peine, pre/post-eco (print-through), y wow/flutter (solo Kari).

## Correccion real encontrada mediante investigacion web (pedido
explicito del usuario)

El pre/post-eco de CRAC usaba retardos de 8-14 MILISEGUNDOS. La
literatura real de ingenieria de audio (print-through en cinta
magnetica) documenta que el pre-eco/post-eco ocurre en un retardo
IGUAL A UNA VUELTA COMPLETA de la bobina en el punto donde esta el
material -- para cinta abierta a 15 ips en un carrete de 10", esto se
mide en LA PRACTICA entre 0.8 y 2 SEGUNDOS (calculo geometrico real:
circunferencia del carrete / velocidad de cinta). Para cassette
compacta (Lorito Aldhiro), la velocidad es ~4.76 cm/s (1-7/8 ips, unas
8 veces mas lenta que cinta abierta a 15 ips) y el radio de la bobina
es unas 5 veces menor -- el mismo calculo geometrico para un hub de
cassette tipico (radio ~2-2.5cm) da un tiempo por vuelta de
aproximadamente 2.6-3.3 SEGUNDOS, incluso MAS LARGO que en cinta
abierta (la velocidad mucho menor domina sobre el radio menor). Los
valores de CRAC estaban por lo tanto entre 1.5 y 2 ORDENES DE MAGNITUD
por debajo de la fisica real del fenomeno que dicen modelar. Corregido
a pre_delay_ms=2200/post_delay_ms=2900, con la linea de retardo
ampliada en consecuencia.

Wow/flutter: los rangos de frecuencia de CRAC (wow ~0.7Hz, flutter
~6Hz) SI estan dentro de los rangos reales documentados (wow: 0.5-6Hz;
flutter: 6-100Hz) -- no se corrigieron. Las profundidades (3ms wow,
0.6ms flutter) son razonables para un "reproductor Kari mediocre" --
tampoco corregidas.

## Que se recorto (mismo criterio que Cristhi Cosh, GAP-039)

- PREVIDSPBlockGuard/SafeBlockRecovery/PREVIContext/
  PREVITransitionGuard/PREVITelemetry -- reemplazado por
  sanitize_finite/NRCoordinator._sanitize_stage() ya existente.
- AntipestalDolbySEmbedded (banda de limpieza previa con un
  decodificador Dolby S embebido) -- no portado: Lorito ya tiene su
  propio sistema NR seleccionable (incluido Dolby S real) en el menu
  NR.
- AntipestalRingBuffer/selector con bloqueo/vfd_interface/
  previanalyzer_bridge/crac_antipestal_ui -- infraestructura de UI/
  telemetria propia de CRAC, no portada.
- Restriccion MONO 16kHz obligatoria (CRAC) -- NO replicada: es una
  politica de CRAC, no una necesidad matematica del DSP (todos los
  coeficientes ya se derivan del sample_rate real). Generalizado para
  operar en el sample rate y numero de canales reales de Lorito,
  procesando cada canal con su propia instancia independiente.

Verificado con tests dedicados contra la matematica original de CRAC
para los componentes reutilizables (biquad RBJ, Volterra, comb,
wow/flutter); el pre/post-eco se verifica contra la formula corregida.
"""

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit, NUMBA_OK

_MAX_NOISE_AMPLITUDE = 0.35


def _biquad_lowpass_coefs(freq_hz, q, fs):
    nyquist = fs / 2.0
    freq_hz = min(max(freq_hz, 1.0), nyquist * 0.999)
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / (2.0 * max(q, 1e-3))
    b0 = (1.0 - cw0) / 2.0
    b1 = 1.0 - cw0
    b2 = (1.0 - cw0) / 2.0
    a0 = 1.0 + alpha
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha
    return (b0 / a0, b1 / a0, b2 / a0), (a1 / a0, a2 / a0)


def _biquad_df2t_py(x, b0, b1, b2, a1, a2, z1, z2):
    n = x.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x[i]
        yi = b0 * xi + z1
        z1 = b1 * xi - a1 * yi + z2
        z2 = b2 * xi - a2 * yi
        out[i] = yi
    return out, z1, z2


_biquad_df2t_kernel = njit(cache=True)(_biquad_df2t_py)


class BiquadDF2T:
    """Direct Form II Transposed, estado (z1, z2) persistente entre
    bloques -- mismo contrato que el original de CRAC."""

    def __init__(self, freq_hz, q, fs):
        self.fs = fs
        self.set_freq(freq_hz, q)
        self.z1 = 0.0
        self.z2 = 0.0

    def set_freq(self, freq_hz, q):
        (self.b0, self.b1, self.b2), (self.a1, self.a2) = _biquad_lowpass_coefs(freq_hz, q, self.fs)

    def process(self, x: np.ndarray) -> np.ndarray:
        out, self.z1, self.z2 = _biquad_df2t_kernel(
            np.ascontiguousarray(x, dtype=np.float64),
            self.b0, self.b1, self.b2, self.a1, self.a2, self.z1, self.z2)
        return out

    def reset(self):
        self.z1 = 0.0
        self.z2 = 0.0


def _brown_step_py(n, state, rng_vals, leak):
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        state = state * leak + rng_vals[i]
        out[i] = state
    return out, state


def _wobble_step_py(n, state, rng_vals, smooth):
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        state = state * smooth + rng_vals[i] * (1.0 - smooth)
        out[i] = state
    return out, state


_brown_step_kernel = njit(cache=True)(_brown_step_py)
_wobble_step_kernel = njit(cache=True)(_wobble_step_py)


class BrownNoiseGenerator:
    """Piso de ruido marron con bamboleo lento -- Striker."""

    def __init__(self, sample_rate, seed=0, wobble_period_s=45.0):
        self.sample_rate = int(sample_rate)
        self._rng = np.random.default_rng(seed)
        self._state = 0.0
        self._leak = 0.9995
        self._wobble_state = 1.0
        self._wobble_smooth = float(np.exp(-1.0 / max(1.0, wobble_period_s * self.sample_rate / 64.0)))

    def generate(self, n_frames, excitation):
        excitation = float(np.clip(excitation, 0.0, 1.0))
        rng_vals = self._rng.standard_normal(n_frames) * 0.02
        brown, self._state = _brown_step_kernel(n_frames, self._state, rng_vals, self._leak)
        wobble_vals = self._rng.standard_normal(n_frames) * 0.01
        wobble, self._wobble_state = _wobble_step_kernel(
            n_frames, self._wobble_state, wobble_vals, self._wobble_smooth)
        amp = excitation * _MAX_NOISE_AMPLITUDE
        return (brown * (0.7 + 0.3 * wobble) * amp).astype(np.float64)

    def reset(self):
        self._state = 0.0
        self._wobble_state = 1.0


class PinkNoiseGenerator:
    """Piso de ruido rosa (Voss-McCartney simplificado) con
    "respiracion" lenta -- Kari."""

    def __init__(self, sample_rate, seed=0, wobble_period_s=35.0):
        self.sample_rate = int(sample_rate)
        self._rng = np.random.default_rng(seed)
        self._rows = np.zeros(8, dtype=np.float64)
        self._counter = 0
        self._wobble_state = 1.0
        self._wobble_smooth = float(np.exp(-1.0 / max(1.0, wobble_period_s * self.sample_rate / 64.0)))

    def generate(self, n_frames, excitation):
        excitation = float(np.clip(excitation, 0.0, 1.0))
        out = np.empty(n_frames, dtype=np.float64)
        n_rows = len(self._rows)
        for i in range(n_frames):
            self._counter += 1
            for r in range(n_rows):
                if self._counter % (1 << r) == 0:
                    self._rows[r] = self._rng.standard_normal()
            out[i] = np.sum(self._rows)
        out = out / (n_rows ** 0.5) * 0.05
        wobble_vals = self._rng.standard_normal(n_frames) * 0.01
        wobble, self._wobble_state = _wobble_step_kernel(
            n_frames, self._wobble_state, wobble_vals, self._wobble_smooth)
        amp = excitation * _MAX_NOISE_AMPLITUDE
        return out * (0.7 + 0.3 * wobble) * amp

    def reset(self):
        self._rows[:] = 0.0
        self._counter = 0
        self._wobble_state = 1.0


def _volterra_kernel_py(x, prev, k2, k3):
    n = x.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x[i]
        yi = xi + k2 * xi * prev + k3 * (xi * xi * xi)
        out[i] = np.tanh(yi)
        prev = xi
    return out, prev


_volterra_kernel = njit(cache=True)(_volterra_kernel_py)


class VolterraColorizer:
    """No linealidad Volterra de 2do orden truncado, con memoria de un
    paso -- misma matematica que el original de CRAC."""

    def __init__(self, k2=0.08, k3=-0.05):
        self.k2 = float(k2)
        self.k3 = float(k3)
        self._prev = 0.0

    def process(self, x, intensity=1.0):
        intensity = float(np.clip(intensity, 0.0, 1.0))
        out, self._prev = _volterra_kernel(
            np.ascontiguousarray(x, dtype=np.float64), self._prev,
            self.k2 * intensity, self.k3 * intensity)
        return out

    def reset(self):
        self._prev = 0.0


def _comb_kernel_py(x, history, write_pos, delay_frames, feedback, mix):
    n = x.shape[0]
    hist_len = history.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        read_pos = (write_pos - delay_frames) % hist_len
        delayed = history[read_pos]
        xi = x[i]
        fed = xi + delayed * feedback
        history[write_pos] = fed
        out[i] = xi * (1.0 - mix) + delayed * mix
        write_pos = (write_pos + 1) % hist_len
    return out, write_pos


_comb_kernel = njit(cache=True)(_comb_kernel_py)


class CombRaspadoModel:
    """"Raspado tipo peine" -- retardo fijo muy corto + realimentacion
    suave, nunca flanger/chorus (retardo SIN barrido)."""

    def __init__(self, sample_rate, delay_ms=0.6, feedback=0.15, mix=0.12,
                history_len_frames=512):
        self.sample_rate = int(sample_rate)
        self._delay_frames = max(1, int(delay_ms * sample_rate / 1000.0))
        if self._delay_frames >= history_len_frames:
            history_len_frames = self._delay_frames + 8
        self._history = np.zeros(history_len_frames, dtype=np.float64)
        self._write_pos = 0
        self.feedback = float(np.clip(feedback, -0.6, 0.6))
        self.mix = float(np.clip(mix, 0.0, 0.5))

    def process(self, x, intensity=1.0):
        intensity = float(np.clip(intensity, 0.0, 1.0))
        out, self._write_pos = _comb_kernel(
            np.ascontiguousarray(x, dtype=np.float64), self._history, self._write_pos,
            self._delay_frames, self.feedback * intensity, self.mix * intensity)
        return out

    def reset(self):
        self._history[:] = 0.0
        self._write_pos = 0


def _echo_kernel_py(x, history, write_pos, pre_delay, pre_gain, post_delay, post_gain):
    n = x.shape[0]
    hist_len = history.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        pre_pos = (write_pos - pre_delay) % hist_len
        post_pos = (write_pos - post_delay) % hist_len
        xi = x[i]
        out[i] = xi + history[pre_pos] * pre_gain + history[post_pos] * post_gain
        history[write_pos] = xi
        write_pos = (write_pos + 1) % hist_len
    return out, write_pos


_echo_kernel = njit(cache=True)(_echo_kernel_py)


class PrePostEcho:
    """Pre-eco y post-eco (print-through) -- retardos CORREGIDOS a
    escala real de cassette (ver docstring de cabecera): 2200ms/2900ms
    por defecto, no 8/14ms como en CRAC."""

    def __init__(self, sample_rate, pre_delay_ms=2200.0, pre_gain=0.04,
                post_delay_ms=2900.0, post_gain=0.05, history_len_frames=None):
        self.sample_rate = int(sample_rate)
        self._pre_delay = max(1, int(pre_delay_ms * sample_rate / 1000.0))
        self._post_delay = max(1, int(post_delay_ms * sample_rate / 1000.0))
        needed = max(self._pre_delay, self._post_delay) + 8
        if history_len_frames is None or needed > history_len_frames:
            history_len_frames = needed
        self._history = np.zeros(history_len_frames, dtype=np.float64)
        self._write_pos = 0
        self.pre_gain = float(np.clip(pre_gain, 0.0, 0.2))
        self.post_gain = float(np.clip(post_gain, 0.0, 0.2))

    def process(self, x, intensity=1.0):
        intensity = float(np.clip(intensity, 0.0, 1.0))
        out, self._write_pos = _echo_kernel(
            np.ascontiguousarray(x, dtype=np.float64), self._history, self._write_pos,
            self._pre_delay, self.pre_gain * intensity,
            self._post_delay, self.post_gain * intensity)
        return out

    def reset(self):
        self._history[:] = 0.0
        self._write_pos = 0


def _catmull_rom_py(y0, y1, y2, y3, frac):
    a0 = -0.5 * y0 + 1.5 * y1 - 1.5 * y2 + 0.5 * y3
    a1 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3
    a2 = -0.5 * y0 + 0.5 * y2
    a3 = y1
    return ((a0 * frac + a1) * frac + a2) * frac + a3


_catmull_rom = njit(cache=True)(_catmull_rom_py)


def _wow_flutter_kernel_py(x, history, write_pos, wow_phase, wow_freq_rad,
                           wow_depth_frames, flutter_phase, flutter_freq_rad,
                           flutter_depth_frames, base_delay):
    n = x.shape[0]
    hist_len = history.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        history[write_pos] = x[i]
        wow_phase += wow_freq_rad
        flutter_phase += flutter_freq_rad
        offset = (base_delay + wow_depth_frames * np.sin(wow_phase)
                 + flutter_depth_frames * np.sin(flutter_phase))
        offset = max(2.0, min(float(hist_len - 3), offset))
        read_pos = write_pos - offset
        idx1 = int(np.floor(read_pos)) % hist_len
        frac = read_pos - np.floor(read_pos)
        idx0 = (idx1 - 1) % hist_len
        idx2 = (idx1 + 1) % hist_len
        idx3 = (idx1 + 2) % hist_len
        out[i] = _catmull_rom(history[idx0], history[idx1], history[idx2], history[idx3], frac)
        write_pos = (write_pos + 1) % hist_len
    return out, write_pos, wow_phase, flutter_phase


_wow_flutter_kernel = njit(cache=True)(_wow_flutter_kernel_py)

_DELAY_LINE_FRAMES = 256


class WowFlutterModel:
    """Wow/flutter -- Kari unicamente. Rangos de frecuencia verificados
    contra literatura real (wow 0.5-6Hz, flutter 6-100Hz)."""

    def __init__(self, sample_rate, wow_rate_hz=0.7, wow_depth_ms=3.0,
                flutter_rate_hz=6.0, flutter_depth_ms=0.4):
        self.sample_rate = int(sample_rate)
        self._history = np.zeros(_DELAY_LINE_FRAMES, dtype=np.float64)
        self._write_pos = 0
        self._wow_phase = 0.0
        self._flutter_phase = 0.0
        self.set_params(wow_rate_hz, wow_depth_ms, flutter_rate_hz, flutter_depth_ms)

    def set_params(self, wow_rate_hz, wow_depth_ms, flutter_rate_hz, flutter_depth_ms):
        self._wow_freq_rad = 2.0 * np.pi * max(0.0, wow_rate_hz) / self.sample_rate
        self._wow_depth_frames = max(0.0, wow_depth_ms) * self.sample_rate / 1000.0
        self._flutter_freq_rad = 2.0 * np.pi * max(0.0, flutter_rate_hz) / self.sample_rate
        self._flutter_depth_frames = max(0.0, flutter_depth_ms) * self.sample_rate / 1000.0
        max_depth = self._wow_depth_frames + self._flutter_depth_frames
        self._base_delay = max(4.0, max_depth + 4.0)
        if self._base_delay > _DELAY_LINE_FRAMES - 4:
            self._base_delay = float(_DELAY_LINE_FRAMES - 4)

    def process(self, x):
        out, self._write_pos, self._wow_phase, self._flutter_phase = _wow_flutter_kernel(
            np.ascontiguousarray(x, dtype=np.float64), self._history, self._write_pos,
            self._wow_phase, self._wow_freq_rad, self._wow_depth_frames,
            self._flutter_phase, self._flutter_freq_rad, self._flutter_depth_frames,
            self._base_delay)
        return out

    def reset(self):
        self._history[:] = 0.0
        self._write_pos = 0
        self._wow_phase = 0.0
        self._flutter_phase = 0.0


class _GanchaChannelState:
    """Agrupa las instancias de un canal -- un juego completo por
    canal, nunca compartido entre canales."""

    def __init__(self, engine_kind, sample_rate, seed):
        self.lowpass = BiquadDF2T(
            freq_hz=8000.0 if engine_kind == "STRIKER" else 6000.0,
            q=0.55 if engine_kind == "STRIKER" else 0.5, fs=sample_rate)
        if engine_kind == "STRIKER":
            self.noise = BrownNoiseGenerator(sample_rate=sample_rate, seed=seed)
            self.comb = CombRaspadoModel(sample_rate=sample_rate, delay_ms=0.6)
            self.echo = PrePostEcho(sample_rate=sample_rate, pre_delay_ms=2200.0, post_delay_ms=2900.0)
            self.volterra = VolterraColorizer(k2=0.10, k3=-0.06)
            self.wow_flutter = None
        else:
            self.noise = PinkNoiseGenerator(sample_rate=sample_rate, seed=seed)
            self.comb = CombRaspadoModel(sample_rate=sample_rate, delay_ms=0.9, feedback=0.10, mix=0.08)
            self.echo = None
            self.volterra = VolterraColorizer(k2=0.06, k3=-0.04)
            self.wow_flutter = WowFlutterModel(sample_rate=sample_rate)


class AntipestalLolaProfile:
    """DSP ANTIPESTAL DE LOLA GRILLO (PREVI) -- vive en el menu OPTAPE.
    mode en {"BYPASS", "STRIKER", "KARI"} (seleccion unica, no
    ACTIVE/BYPASS simple -- dos ramas mutuamente excluyentes, igual
    criterio que TapeEqBiasProfile)."""

    display_name = "ANTIPESTAL LOLA GRILLO (PREVI)"
    legend_label = "PREVI DSP"

    _PARAM_DEFAULTS_STRIKER = dict(
        excitacion_ruido=0.5, bamboleo=0.5, intensidad_limitacion=0.5,
        suavidad=0.5, raspado=0.4, preeco=0.3, posteco=0.3,
        textura=0.5, coloracion=0.5)
    _PARAM_DEFAULTS_KARI = dict(
        excitacion_ruido=0.5, bamboleo=0.5, respiracion=0.4,
        intensidad_limitacion=0.5, raspado=0.3, wow=0.4, flutter=0.3,
        irregularidad=0.3, suavidad=0.5, coloracion=0.5)

    def __init__(self, mode: str = "BYPASS", sample_rate: int = 48000,
                channels: int = 2, **params):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._active = self.mode in ("STRIKER", "KARI")
        if self.mode == "KARI":
            self.params = dict(self._PARAM_DEFAULTS_KARI)
        else:
            self.params = dict(self._PARAM_DEFAULTS_STRIKER)
        self.params.update({k: v for k, v in params.items() if k in self.params})
        self._channel_states = []
        if self._active:
            self._build_channels()

    def _build_channels(self):
        self._channel_states = [
            _GanchaChannelState(self.mode, self.fs, seed=100 + ch * 17)
            for ch in range(self.channels)
        ]

    def set_params(self, **kwargs):
        for k, v in kwargs.items():
            if k in self.params:
                self.params[k] = float(np.clip(v, 0.0, 1.0))

    def reset(self):
        for st in self._channel_states:
            st.lowpass.reset()
            st.noise.reset()
            st.comb.reset()
            st.volterra.reset()
            if st.echo is not None:
                st.echo.reset()
            if st.wow_flutter is not None:
                st.wow_flutter.reset()

    def _process_striker_channel(self, xc: np.ndarray, st: _GanchaChannelState) -> np.ndarray:
        p = self.params
        limited = st.lowpass.process(xc)
        k = float(np.clip(p["intensidad_limitacion"], 0.0, 1.0))
        band_limited = xc * (1.0 - k) + limited * k
        smoothed = st.volterra.process(band_limited, intensity=p["suavidad"])
        rasped = st.comb.process(smoothed, intensity=p["raspado"])
        st.echo.pre_gain = 0.06 * float(np.clip(p["preeco"], 0.0, 1.0))
        st.echo.post_gain = 0.06 * float(np.clip(p["posteco"], 0.0, 1.0))
        echoed = st.echo.process(rasped, intensity=1.0)
        noise = st.noise.generate(xc.shape[0], excitation=p["excitacion_ruido"])
        colored = echoed * float(np.clip(p["coloracion"], 0.05, 1.0)) + noise
        return colored

    def _process_kari_channel(self, xc: np.ndarray, st: _GanchaChannelState) -> np.ndarray:
        p = self.params
        wow_ms = 3.0 * float(np.clip(p["wow"], 0.0, 1.0))
        flutter_ms = 0.6 * float(np.clip(p["flutter"], 0.0, 1.0))
        irregular = 1.0 + 0.3 * float(np.clip(p["irregularidad"], 0.0, 1.0))
        st.wow_flutter.set_params(
            wow_rate_hz=0.6 * irregular, wow_depth_ms=wow_ms,
            flutter_rate_hz=6.0 * irregular, flutter_depth_ms=flutter_ms)
        wobbled = st.wow_flutter.process(xc)
        limited = st.lowpass.process(wobbled)
        k = float(np.clip(p["intensidad_limitacion"], 0.0, 1.0))
        band_limited = wobbled * (1.0 - k) + limited * k
        smoothed = st.volterra.process(band_limited, intensity=p["suavidad"])
        rasped = st.comb.process(smoothed, intensity=p["raspado"])
        noise = st.noise.generate(xc.shape[0], excitation=p["excitacion_ruido"])
        colored = rasped * float(np.clip(p["coloracion"], 0.05, 1.0)) + noise
        return colored

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active or chunk.size == 0:
            return chunk
        mono_in = chunk.ndim == 1
        x = chunk if not mono_in else chunk[:, np.newaxis]
        x64 = x.astype(np.float64) if x.dtype != np.float64 else x
        out = np.empty_like(x64)
        proc = self._process_striker_channel if self.mode == "STRIKER" else self._process_kari_channel
        for ch in range(min(x64.shape[1], len(self._channel_states))):
            out[:, ch] = proc(x64[:, ch], self._channel_states[ch])
        out = np.clip(out, -1.0, 1.0).astype(np.float32)
        return out[:, 0] if mono_in else out
