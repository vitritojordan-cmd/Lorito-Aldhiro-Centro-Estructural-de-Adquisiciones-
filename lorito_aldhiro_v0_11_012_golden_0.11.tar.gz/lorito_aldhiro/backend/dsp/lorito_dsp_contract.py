from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: DSPBlockContract — contrato único, catálogo honesto de fidelidad y telemetría por etapa.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_contract.py — Orden Golden DSP PREVI / NR
(LA-GOLDEN-DSP-PREVI-NR-001: NR-01, NR-03, DSP-01, DSP-02, DSP-03,
DSP-05, DSP-06, DSP-07).

`DSPBlockContract` (todas las etapas encadenadas por `NRCoordinator`):
  · Entrada: `np.ndarray` float32/float64, forma `[frames, channels]`
    (o vector `[frames]` cuando channels=1, forma mono declarada),
    `channels` constante e igual al configurado (1 o 2). Cualquier otra
    cosa → `DSPContractError` ANTES de procesar (nunca truncar/duplicar
    canales implícitamente).
  · Salida: float32, misma forma exacta. Una forma distinta →
    `DSPStageError` nombrando la etapa.
  · Sample rate admitido: `SUPPORTED_RATES`. Fuera de rango → error.
  · Estado: preservado entre bloques; se reinicia SOLO por transición
    contractual (reset/reconfigure/NaN-Inf en esa etapa), registrada en
    la telemetría con su causa.
  · Parámetros: se aplican en frontera de bloque (el coordinador
    serializa mutaciones y proceso con un lock NO-RT; el callback de
    PortAudio jamás ejecuta DSP).

Catálogo de fidelidad (NR-01 / DSP-05): ninguna etapa se declara
emulación de referencia de hardware. Cada una lleva su FAMILIA de uso y
su FIDELIDAD declarada; las familias CREATIVE_EFFECT producen siempre
salida DERIVED creativa, nunca restauración del RAW.
"""

import hashlib
import json
import time
from dataclasses import dataclass, field

import numpy as np

from lorito_aldhiro.backend.errors.lorito_errors_dsp import DSPContractError

SUPPORTED_RATES = (22050, 32000, 44100, 48000, 88200, 96000, 176400, 192000)
SUPPORTED_CHANNELS = (1, 2)

# Fidelidad declarada
APPROXIMATION = "APPROXIMATION"            # aproximación de laboratorio, sin referencia medida
DESIGN = "DESIGN"                          # diseño propio (EQ/filtro), sin pretensión histórica
CREATIVE = "CREATIVE_EFFECT"               # efecto deliberadamente degradante
REFERENCE_VALIDATED = "REFERENCE_VALIDATED"  # (ninguna etapa lo cumple hoy)

# Familias / intención de uso (DSP-03)
FAM_NR_DECODE = "NR_DECODE"
FAM_NR_ENCODE = "NR_ENCODE_SIMULATION"
FAM_RECORD_BIAS = "RECORD_BIAS_SIMULATION"
FAM_LEVEL = "LEVEL_CONTROL"
FAM_EQ = "EQ_CORRECTION"
FAM_TAPE_EQ = "TAPE_EQ_VOICING"
FAM_PILOT = "PILOT_FILTER"
FAM_AZIMUTH = "AZIMUTH_SIMULATION"
FAM_RESTORATION = "RESTORATION_PREVI"
FAM_CREATIVE = "CREATIVE_EFFECT"


@dataclass(frozen=True)
class StageInfo:
    label: str
    family: str
    fidelity: str
    note: str
    # Medido (Orden Golden DSP, banco de continuidad): False si la salida
    # de la etapa depende del tamaño de bloque del host. Esas etapas se
    # envuelven en `FixedBlockAdapter` (bloques internos fijos, latencia
    # constante declarada) para que el resultado sea idéntico con
    # cualquier partición del flujo.
    block_invariant: bool = True


STAGE_CATALOG = {
    "muscle_eq": StageInfo("muscle_eq", FAM_EQ, DESIGN,
                           "EQ paramétrico (biquads RBJ, DF-II T, rampa de coeficientes)"),
    "cristhi_cosh": StageInfo("cristhi_cosh", FAM_RESTORATION, APPROXIMATION,
                              "restauración PREVI de artefactos de bias; sin medición de referencia", block_invariant=False),
    "antipestal": StageInfo("antipestal", FAM_RESTORATION, APPROXIMATION,
                            "restauración PREVI (Striker/Kari); sin medición de referencia", block_invariant=False),
    "lucha_enloquecida": StageInfo("lucha_enloquecida", FAM_CREATIVE, CREATIVE,
                                   "20 efectos degradantes A–T: DERIVED creativo, jamás restauración", block_invariant=False),
    "eq_bias": StageInfo("eq_bias", FAM_TAPE_EQ, APPROXIMATION,
                         "voicing de tipo de cinta (NORMAL/CrO2/FeCr/Metal)"),
    "mpx": StageInfo("mpx", FAM_PILOT, DESIGN, "filtro de piloto MPX 19 kHz"),
    "nr": StageInfo("nr", FAM_NR_DECODE, APPROXIMATION,
                    "topologías shelving/compander parametrizadas; NO decodificación "
                    "compatible certificada con hardware Dolby/dbx/ANRS/DNL/DNR"),
    "hx_pro": StageInfo("hx_pro", FAM_RECORD_BIAS, APPROXIMATION,
                        "HX Pro es una técnica de GRABACIÓN (bias dinámico), no un decodificador", block_invariant=False),
    "alc": StageInfo("alc", FAM_LEVEL, DESIGN, "control automático de nivel", block_invariant=False),
    "focus": StageInfo("focus", FAM_AZIMUTH, APPROXIMATION, "simulación de azimut", block_invariant=False),
    "version_o_tron": StageInfo("version_o_tron", FAM_CREATIVE, CREATIVE,
                                "coloración de medio de reproducción (efecto creativo)", block_invariant=False),
}

# Orden canónico de la cadena (declarado; ver DSP_CHAIN_SPEC.md).
CANONICAL_ORDER = ("muscle_eq", "cristhi_cosh", "antipestal", "lucha_enloquecida",
                   "eq_bias", "mpx", "nr", "hx_pro", "alc", "focus", "version_o_tron")

# Casos de uso (DSP-03)
USE_CAPTURE_LIVE = "CAPTURE_LIVE"
USE_PLAYBACK = "PLAYBACK"
USE_OFFLINE_RESTORATION = "OFFLINE_RESTORATION"
USE_CREATIVE = "CREATIVE"
USE_CASES = (USE_CAPTURE_LIVE, USE_PLAYBACK, USE_OFFLINE_RESTORATION, USE_CREATIVE)


def validate_config(sample_rate, channels) -> None:
    if int(sample_rate) not in SUPPORTED_RATES:
        raise DSPContractError(
            f"DSP_CONTRACT: sample_rate {sample_rate} no soportado {SUPPORTED_RATES}")
    if int(channels) not in SUPPORTED_CHANNELS:
        raise DSPContractError(
            f"DSP_CONTRACT: {channels} canales no soportados {SUPPORTED_CHANNELS} — "
            f"se rechaza en vez de truncar/duplicar canales implícitamente")


def validate_block(block, channels: int) -> None:
    if not isinstance(block, np.ndarray):
        raise DSPContractError(f"DSP_CONTRACT: bloque no es ndarray ({type(block).__name__})")
    if block.dtype not in (np.float32, np.float64):
        raise DSPContractError(f"DSP_CONTRACT: dtype {block.dtype} no admitido (float32/64)")
    if block.ndim == 1 and channels == 1:
        return   # forma mono declarada: vector [frames] (sin duplicar canales)
    if block.ndim != 2:
        raise DSPContractError(f"DSP_CONTRACT: forma {block.shape} — se exige [frames, canales]"
                               f" (o [frames] con channels=1)")
    if block.shape[1] != channels:
        raise DSPContractError(
            f"DSP_CONTRACT: {block.shape[1]} canales != {channels} configurados")


_P_WINDOW = 256


class StageTelemetry:
    """Telemetría por etapa (DSP-07). Escrita solo por el hilo que procesa;
    `snapshot()` es una copia de solo lectura para UI/informes. Sin
    logging síncrono por bloque."""

    __slots__ = ("blocks", "frames", "exec_ms_sum", "exec_ms_max", "_recent", "_ri",
                 "peak_in", "peak_out", "saturated_samples", "nonfinite_samples",
                 "resets", "last_reset_reason", "failures", "budget_overruns")

    def __init__(self):
        self.blocks = 0
        self.frames = 0
        self.exec_ms_sum = 0.0
        self.exec_ms_max = 0.0
        self._recent = np.zeros(_P_WINDOW, dtype=np.float64)
        self._ri = 0
        self.peak_in = 0.0
        self.peak_out = 0.0
        self.saturated_samples = 0
        self.nonfinite_samples = 0
        self.resets = 0
        self.last_reset_reason = ""
        self.failures = 0
        self.budget_overruns = 0

    def record(self, n_frames: int, dt_ms: float, peak_in: float, peak_out: float,
               saturated: int, budget_ms: float):
        self.blocks += 1
        self.frames += n_frames
        self.exec_ms_sum += dt_ms
        if dt_ms > self.exec_ms_max:
            self.exec_ms_max = dt_ms
        self._recent[self._ri % _P_WINDOW] = dt_ms
        self._ri += 1
        if peak_in > self.peak_in:
            self.peak_in = peak_in
        if peak_out > self.peak_out:
            self.peak_out = peak_out
        self.saturated_samples += saturated
        if budget_ms > 0 and dt_ms > budget_ms:
            self.budget_overruns += 1

    def snapshot(self) -> dict:
        n = min(self._ri, _P_WINDOW)
        recent = self._recent[:n] if n else np.zeros(1)
        return {
            "blocks": self.blocks, "frames": self.frames,
            "exec_ms_mean": self.exec_ms_sum / self.blocks if self.blocks else 0.0,
            "exec_ms_p50": float(np.percentile(recent, 50)),
            "exec_ms_p95": float(np.percentile(recent, 95)),
            "exec_ms_p99": float(np.percentile(recent, 99)),
            "exec_ms_max": self.exec_ms_max,
            "peak_in": self.peak_in, "peak_out": self.peak_out,
            "saturated_samples": self.saturated_samples,
            "nonfinite_samples": self.nonfinite_samples,
            "resets": self.resets, "last_reset_reason": self.last_reset_reason,
            "failures": self.failures, "budget_overruns": self.budget_overruns,
        }


@dataclass(frozen=True)
class IntegrityEvent:
    stage: str
    kind: str              # NONFINITE / STAGE_FAILURE / RESET / RECONFIGURE
    block_index: int
    frame_position: int
    count: int
    policy: str
    detail: str = ""
    t_monotonic: float = field(default_factory=time.monotonic)


def config_hash(description: list) -> str:
    return hashlib.sha256(json.dumps(description, sort_keys=True, default=str)
                          .encode()).hexdigest()[:16]


def stage_params(stage) -> dict:
    """Parámetros públicos reproducibles de una etapa (para provenance)."""
    out = {}
    for k in ("mode", "fs", "sample_rate", "channels", "preset_id",
              "correction_intensity", "dbx_type"):
        v = getattr(stage, k, None)
        if v is not None and not callable(v):
            out[k] = v if isinstance(v, (int, float, str, bool)) else str(v)
    for k, v in vars(stage).items() if hasattr(stage, "__dict__") else ():
        if k.startswith("_") or k in out:
            continue
        if isinstance(v, (int, float, str, bool)):
            out[k] = v
    return out


FIXED_BLOCK_FRAMES = 256


class FixedBlockAdapter:
    """Re-bloqueo exacto: la etapa interna SIEMPRE recibe bloques de
    `block` frames, sin importar cómo el host particione el flujo. La
    salida se retrasa exactamente `block` frames (FIFO cebado con
    ceros) y es bit-idéntica para cualquier secuencia de tamaños de
    bloque de entrada. Memoria fija, sin asignaciones proporcionales a
    la sesión. Invariante: tras cada llamada quedan ≥ 1 frames
    disponibles en la FIFO de salida, así que nunca hay subdesbordamiento."""

    def __init__(self, stage, channels: int, block: int = FIXED_BLOCK_FRAMES,
                 on_output=None):
        self.stage = stage
        # Guardia aplicada a la salida REAL de la etapa (bloque interno),
        # sin el retardo del re-bloqueo: detección y reset inmediatos.
        self.on_output = on_output
        self.block = int(block)
        self.channels = int(channels)
        cap = 1 << 16
        self._in = np.zeros((cap, self.channels), dtype=np.float32)
        self._out = np.zeros((cap, self.channels), dtype=np.float32)
        self._cap = cap
        self._prime()

    @property
    def latency_frames(self) -> int:
        return self.block

    def _prime(self):
        self._in_n = 0
        self._out_r = 0
        self._out_w = self.block      # cebado con `block` frames de silencio
        self._out[:self.block] = 0.0

    def reset(self):
        self.stage.reset()
        self._prime()

    def _ensure(self, buf_name, needed):
        buf = getattr(self, buf_name)
        if needed > buf.shape[0]:
            new = np.zeros((max(needed, buf.shape[0] * 2), self.channels), dtype=np.float32)
            new[:buf.shape[0]] = buf
            setattr(self, buf_name, new)

    def process_chunk(self, chunk):
        mono_vec = chunk.ndim == 1
        x = chunk[:, np.newaxis] if mono_vec else chunk
        n = x.shape[0]
        if n == 0:
            return chunk
        # 1) acumular entrada
        self._ensure("_in", self._in_n + n)
        self._in[self._in_n:self._in_n + n] = x
        self._in_n += n
        # 2) procesar todos los bloques completos
        B = self.block
        n_full = self._in_n // B
        if n_full:
            self._ensure("_out", self._out_w + n_full * B)
            for k in range(n_full):
                blk = self._in[k * B:(k + 1) * B]
                inp = blk[:, 0].copy() if mono_vec else blk.copy()
                y = self.stage.process_chunk(inp)
                if not isinstance(y, np.ndarray) or y.shape != inp.shape:
                    raise ValueError(f"forma de salida {getattr(y, 'shape', None)} != {inp.shape}")
                if self.on_output is not None:
                    y = self.on_output(y)
                y = np.asarray(y, dtype=np.float32)
                self._out[self._out_w:self._out_w + B] = y[:, np.newaxis] if y.ndim == 1 else y
                self._out_w += B
            rem = self._in_n - n_full * B
            if rem:
                self._in[:rem] = self._in[n_full * B:self._in_n]
            self._in_n = rem
        # 3) entregar exactamente n frames (retrasados `block`)
        out = self._out[self._out_r:self._out_r + n].copy()
        self._out_r += n
        if self._out_r >= self._cap // 2:
            pending = self._out_w - self._out_r
            self._out[:pending] = self._out[self._out_r:self._out_w]
            self._out_r, self._out_w = 0, pending
        return out[:, 0] if mono_vec else out

    def __getattr__(self, name):
        return getattr(self.stage, name)


# Tolerancia DECLARADA de ida y vuelta ENCODE→DECODE (dB), medida con
# `tools/bench_nr_fidelity.py` (100 Hz–10 kHz, −40/−20/−10 dBFS) y
# redondeada hacia arriba +0.5 dB. NO es conformidad con hardware: es el
# comportamiento repetible de la aproximación actual (ver
# NR_FIDELITY_BENCH.md). DNL y DNR son sistemas de un solo extremo (solo
# reproducción): no tienen contrato de ida y vuelta.
NR_DECLARED_ROUNDTRIP_TOL_DB = {
    "DOLBY_B": 2.2, "DOLBY_C": 10.9, "DOLBY_S": 6.8,
    "DBX/I": 9.7, "DBX/II": 11.2, "DBX/224": 10.7,
    "ANRS": 2.2, "S_ANRS": 9.7,
    "DNL": None, "DNR": None,
}
