from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Guard de saneamiento numérico (NaN/Inf) compartido por toda la cadena DSP.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_finite_guard.py — contrato DSP_NONFINITE_OUTPUT (Fase 10 de
la Orden Maestra de Saneamiento Pre-Auditoría Aldhira Phonographic,
rama 0.06.005→0.06.006/007).

Invariante que este módulo hace cumplir: **finite-in → finite-out**.
Ningún bloque que pase por la cadena DSP (EQ/BIAS, MPX, un perfil NR,
HX Pro, ALC, FOCUS) debe propagar aguas abajo una muestra NaN o ±Inf,
sin importar qué haya entrado — audio real de hardware puede traer
glitches (dropouts del driver, lecturas corruptas) que hoy no están
contenidos.

Defecto real confirmado en esta sesión (no hipotético): TODAS las
etapas de la cadena (`MpxProfile`, `TapeEqBiasProfile`, los perfiles en
`lorito_nr_profiles.py`, `HxProProfile`, `AlcProfile`, `FocusProfile`)
terminan su `process_chunk` con `np.clip(out, -1.0, 1.0)`. `np.clip`
NO sanea NaN — solo acota Inf/-Inf a los bordes; un NaN de entrada
sale como NaN de salida sin que `np.clip` lo toque. Peor aún: varias
de esas etapas mantienen estado IIR/EMA recursivo entre llamadas
(biquads Direct Form I en MPX, shelves de un polo en EQ/BIAS, EMA de
desfase en FOCUS). Una vez que un NaN entra a esa recursión, el estado
queda envenenado de forma PERMANENTE — todo bloque futuro, aunque sea
audio limpio, sale también en NaN, porque la fórmula recursiva
depende de `y1`/`y2` (o `x1`/`stb`/`sth`) previos. Verificado con
NumPy puro en `tests/test_dsp_finite_guard.py`.

Este guard es la última línea de defensa (saneamiento del síntoma),
no reemplaza corregir la causa raíz de un futuro NaN concreto si se
identifica una (p. ej. una división por cero nueva). El diseño es
deliberadamente barato en el camino sano: un único `np.isfinite(...).all()`
por bloque: si todo es finito (el caso normal, siempre), no se copia
ni se asigna memoria nueva.
"""

import numpy as np

# Mismo rango de salida ya usado por CADA etapa de la cadena
# (`np.clip(out, -1.0, 1.0)` en MPX/EQ-BIAS/NR profiles/HX Pro/ALC/FOCUS)
# — el guard satura Inf/-Inf al mismo límite en vez de inventar uno propio.
DSP_SANITIZE_CLIP = 1.0


def sanitize_finite(chunk: np.ndarray):
    """Aplica el contrato DSP_NONFINITE_OUTPUT a un bloque de audio.

    Devuelve `(clean, n_bad)`:
      - Camino sano (todo finito): devuelve el MISMO array sin copiar
        (`chunk`, no una vista/copia) y `n_bad = 0` — cero costo extra
        más allá del propio `np.isfinite(...).all()`.
      - Camino con NaN/Inf: devuelve un array NUEVO con NaN -> 0.0 e
        Inf/-Inf -> ±`DSP_SANITIZE_CLIP`, mismo dtype que la entrada, y
        `n_bad` = número de muestras no finitas encontradas (para que
        quien llame decida si además debe resetear el estado interno
        de la etapa que lo produjo).
    """
    if chunk.size == 0:
        return chunk, 0
    if np.isfinite(chunk).all():
        return chunk, 0
    n_bad = int(chunk.size - np.count_nonzero(np.isfinite(chunk)))
    clean = np.nan_to_num(
        chunk, nan=0.0, posinf=DSP_SANITIZE_CLIP, neginf=-DSP_SANITIZE_CLIP,
    ).astype(chunk.dtype, copy=False)
    return clean, n_bad
