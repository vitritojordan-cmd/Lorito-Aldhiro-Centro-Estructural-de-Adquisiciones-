from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Corrección automática de azimut (alineación de cabezal) en tiempo real.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_focus.py — DSP FOCUS: emulador de la función "Focus" de los
cassette decks de alta gama, pedido explícito del usuario, con los
mismos criterios arquitectónicos (Numba/NumPy) que MPX.

Referencia técnica investigada para esta sesión: los decks de gama alta
(p. ej. la línea Nakamichi) exponen un control de AZIMUTH del cabezal
— el ángulo del entrehierro respecto a la cinta — porque un
desalineamiento de azimuth desfasa el canal derecho respecto al
izquierdo en alta frecuencia (a mayor frecuencia, mayor desfase para
el mismo error de ángulo), lo que se mide en la práctica correlacionando
ambos canales con una señal de referencia y buscando el desfase que
maximiza la correlación. "Focus" emula aquí, en tiempo real y sin
intervención manual, exactamente esa medición-y-corrección: un
auto-azimuth continuo.

Diseño (nuevo, sin precedente directo en CRAC):
  · Por cada bloque: correlación cruzada L/R por desplazamiento entero
    en un rango pequeño (±FOCUS_MAX_LAG muestras) para estimar el
    retraso relativo entre canales — el mismo principio que un
    analizador de fase real de banco de pruebas.
  · El retraso estimado se suaviza con una media móvil exponencial
    (evita que el "Focus" persiga ruido bloque a bloque y produzca
    artefactos).
  · Corrección por interpolación lineal de muestra fraccionaria
    (fractional delay) aplicada al canal que va adelantado, para
    realinear la fase sin necesidad de que el retraso estimado sea un
    número entero de muestras.
  · Numba (`njit`) en el bucle de correlación cruzada (el más costoso)
    y en el de interpolación fraccionaria — misma degradación con
    gracia que el resto de DSP nuevos de esta sesión.
"""

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit, NUMBA_OK


@njit(cache=True)
def _estimate_lag(l: np.ndarray, r: np.ndarray, max_lag: int) -> int:
    """Retraso entero (en muestras) que maximiza la correlación
    cruzada L/R dentro de ±max_lag. Retorno > 0 → R va retrasado
    respecto a L (hay que adelantar R, o retrasar L, para realinear)."""
    n = l.shape[0]
    best_lag = 0
    best_corr = -1.0e18
    for lag in range(-max_lag, max_lag + 1):
        s = 0.0
        cnt = 0
        if lag >= 0:
            for i in range(n - lag):
                s += l[i] * r[i + lag]
                cnt += 1
        else:
            for i in range(-lag, n):
                s += l[i] * r[i + lag]
                cnt += 1
        if cnt > 0:
            s = s / cnt
        if s > best_corr:
            best_corr = s
            best_lag = lag
    return best_lag


@njit(cache=True)
def _fractional_shift(x: np.ndarray, prev_tail: np.ndarray, shift: float) -> np.ndarray:
    """
    Desplaza `x` en `shift` muestras (puede ser fraccionario y
    negativo) por interpolación lineal, usando `prev_tail` (últimas
    muestras del bloque anterior) como historia para no introducir
    silencio/click al principio de cada bloque nuevo.
    """
    n = x.shape[0]
    tail_n = prev_tail.shape[0]
    # Buffer extendido: [historia | bloque actual]
    ext = np.empty(tail_n + n, dtype=np.float64)
    ext[:tail_n] = prev_tail
    ext[tail_n:] = x
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        src_pos = (tail_n + i) - shift
        i0 = int(np.floor(src_pos))
        frac = src_pos - i0
        if i0 < 0:
            i0 = 0; frac = 0.0
        if i0 >= ext.shape[0] - 1:
            i0 = ext.shape[0] - 2; frac = 1.0
        out[i] = ext[i0] * (1.0 - frac) + ext[i0 + 1] * frac
    return out


class FocusProfile:
    """DSP FOCUS — vive en el menú OPTAPE (mismo menú que MPX/ALC/HX
    Pro, pedido explícito del usuario). Independiente del resto —
    puede convivir con cualquier NR/ALC/HX Pro/MPX activo."""

    display_name = "FOCUS"
    cell_token = "R4"
    overlay_token = "FOCUS"

    MAX_LAG_SAMPLES = 8     # rango de búsqueda de desfase (±8 muestras)
    SMOOTH = 0.15           # EMA del retraso estimado (evita "persecución" de ruido
    MAX_CORRECTION = 6.0    # tope de corrección aplicada (muestras) — nunca "se va"

    def __init__(self, mode: str = "ACTIVE", sample_rate: int = 48000, channels: int = 2):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def _build(self) -> None:
        self._active = self.mode != "BYPASS" and self.channels >= 2
        self._lag_smooth = 0.0
        self._tail_l = np.zeros(self.MAX_LAG_SAMPLES + 2, dtype=np.float64)
        self._tail_r = np.zeros(self.MAX_LAG_SAMPLES + 2, dtype=np.float64)

    def reset(self) -> None:
        self._lag_smooth = 0.0
        self._tail_l[:] = 0.0
        self._tail_r[:] = 0.0

    def reconfigure(self, mode: str, sample_rate: int, channels: int) -> None:
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active or chunk.ndim != 2 or chunk.shape[1] < 2:
            return chunk if chunk.dtype == np.float32 else chunk.astype(np.float32)

        x = np.ascontiguousarray(chunk, dtype=np.float64)
        l = x[:, 0]
        r = x[:, 1]

        # lag > 0 ⇒ r[i] ≈ l[i-lag] ⇒ R va RETRASADO respecto a L (R
        # "repite" lo que L mostró `lag` muestras atrás) ⇒ hay que
        # RETRASAR L para alcanzar a R (nunca adelantar el canal
        # retrasado — eso exigiría muestras futuras, no-causal).
        # lag < 0 ⇒ simétrico: hay que retrasar R para alcanzar a L.
        lag = _estimate_lag(l, r, self.MAX_LAG_SAMPLES)
        self._lag_smooth = (1.0 - self.SMOOTH) * self._lag_smooth + self.SMOOTH * lag
        correction = max(-self.MAX_CORRECTION, min(self.MAX_CORRECTION, self._lag_smooth))

        tail_n = self._tail_l.shape[0]
        if correction >= 0.0:
            l_corrected = _fractional_shift(l, self._tail_l, correction)
            r_corrected = r
        else:
            l_corrected = l
            r_corrected = _fractional_shift(r, self._tail_r, -correction)

        self._tail_l = l[-tail_n:] if l.shape[0] >= tail_n else \
            np.concatenate([self._tail_l[l.shape[0]:], l])
        self._tail_r = r[-tail_n:] if r.shape[0] >= tail_n else \
            np.concatenate([self._tail_r[r.shape[0]:], r])

        out = x.copy()
        out[:, 0] = l_corrected
        out[:, 1] = r_corrected
        result = np.clip(out, -1.0, 1.0).astype(np.float32)
        return result
