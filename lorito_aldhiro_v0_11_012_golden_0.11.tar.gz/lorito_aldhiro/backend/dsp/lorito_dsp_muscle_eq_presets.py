from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Catálogo de presets de ecualización de Muscle Eq Samir en 5 categorías.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_muscle_eq_presets.py -- GAP-043, catalogo de presets de
"MUSCLE EQ SAMIR (VITRITO)".

5 categorias, tal como pide la orden de ingenieria (S9): TONAL
GENERAL, MUSICAL, HISTORICAL, TECHNICAL/STANDARD, TAPE. Cada preset es
una lista de definiciones de banda (dict compatible con EqBand).

## TECHNICAL/STANDARD -- honestidad sobre que tan "real" es cada curva

RIAA y NAB se aproximan aqui con las FRECUENCIAS DE ESQUINA REALES,
investigadas y documentadas (no valores arbitrarios):

  - RIAA (fonografo): polo en 50.05 Hz (3180us), cero en 500.5 Hz
    (318us), polo en 2122 Hz (75us) -- fuente: literatura tecnica de
    audio (Lipshitz; IEC 60098; multiples articulos tecnicos
    contrastados en esta sesion).
  - NAB (cinta abierta, reproduccion a 7.5ips): corners en 50 Hz y
    3180 Hz (3180us/50us) -- comparte el corner grave con RIAA, pero
    el agudo es distinto (motivo real por el que RIAA y NAB NO son
    intercambiables, aunque comparten un corner).

Estas son APROXIMACIONES de 2-3 bandas shelf/peaking sobre el motor
generico de Muscle Eq Samir -- NO decodificadores RIAA/NAB de
precision (ver docstring de lorito_dsp_muscle_eq_samir.py, S27: sin
FFT/convolucion larga, motor de bandas generico). Identificadas
explicitamente como aproximacion en su descripcion, tal como pide la
orden (S9.4: "cuando un perfil no reproduzca exactamente un circuito
fisico documentado, debera identificarse como perfil inspirado en").

## MUSICAL/HISTORICAL -- perfiles tonales, no estandares tecnicos

Las curvas MUSICAL (ROCK/POP/JAZZ/...) son arquetipos de sonoridad de
consumo ampliamente reconocidos -- explicitamente etiquetadas como
perfiles tonales (S9.2), no estandares tecnicos. Las HISTORICAL estan
inspiradas en el caracter general de equipos de una epoca --
identificadas como "inspirado en", nunca como emulacion exacta de un
circuito (S9.3).
"""

from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import EqBandType

_LS = EqBandType.LOW_SHELF
_HS = EqBandType.HIGH_SHELF
_PK = EqBandType.PEAKING


def _band(type, freq_hz, gain_db, q=0.707, enabled=True):
    return dict(type=type, freq_hz=freq_hz, gain_db=gain_db, q=q, enabled=enabled)


_TONAL = {
    "FLAT": [],
    "BASS_BOOST": [_band(_LS, 120, 6.0)],
    "TREBLE_BOOST": [_band(_HS, 6000, 6.0)],
    "LOUDNESS": [_band(_LS, 100, 7.0), _band(_HS, 8000, 5.0)],
    "PRESENCE": [_band(_PK, 3500, 5.0, q=1.0)],
    "BRILLIANCE": [_band(_HS, 10000, 6.0)],
    "SOFT": [_band(_HS, 5000, -5.0)],
    "WARM": [_band(_LS, 200, 3.0), _band(_HS, 6000, -3.0)],
    "BRIGHT": [_band(_HS, 4000, 5.0)],
}

_MUSICAL = {
    "ROCK": [_band(_LS, 100, 5.0), _band(_PK, 1000, -2.0, q=1.0), _band(_HS, 5000, 4.0)],
    "POP": [_band(_PK, 250, -1.5, q=1.0), _band(_PK, 3000, 3.0, q=1.0), _band(_HS, 8000, 2.0)],
    "JAZZ": [_band(_LS, 120, 3.0), _band(_PK, 800, -1.0, q=0.9), _band(_HS, 7000, 2.0)],
    "CLASSICAL": [_band(_LS, 100, 2.0), _band(_HS, 8000, 1.5)],
    "VOCAL": [_band(_LS, 150, -2.0), _band(_PK, 2500, 4.0, q=1.2), _band(_HS, 9000, -1.0)],
    "DISCO": [_band(_LS, 90, 6.0), _band(_PK, 1200, -1.5, q=1.0), _band(_HS, 8000, 4.0)],
    "DANCE": [_band(_LS, 80, 7.0), _band(_PK, 1500, -1.0, q=1.0), _band(_HS, 9000, 3.5)],
    "LIVE": [_band(_PK, 500, -2.0, q=0.8), _band(_PK, 3000, 3.0, q=1.0)],
    "STADIUM": [_band(_LS, 100, 5.0), _band(_PK, 2000, 3.0, q=0.8), _band(_HS, 7000, 3.0)],
    "COUNTRY": [_band(_LS, 150, 2.0), _band(_PK, 2500, 2.5, q=1.0), _band(_HS, 8000, 2.0)],
    "SPEECH": [_band(_LS, 200, -4.0), _band(_PK, 2800, 5.0, q=1.3), _band(_HS, 8000, -3.0)],
}

_HISTORICAL = {
    "VINTAGE_HIFI": [_band(_LS, 100, 2.5), _band(_HS, 10000, 2.5)],
    "GRAPHIC_70S": [_band(_PK, 60, 3.0, q=1.4), _band(_PK, 250, -2.0, q=1.4),
                    _band(_PK, 1000, 1.0, q=1.4), _band(_PK, 4000, 2.0, q=1.4),
                    _band(_PK, 12000, 3.0, q=1.4)],
    "EQ_80S": [_band(_LS, 100, 3.0), _band(_PK, 3000, 2.0, q=1.0), _band(_HS, 8000, 4.0)],
    "EQ_90S": [_band(_LS, 80, 4.0), _band(_PK, 2500, 1.5, q=1.0), _band(_HS, 9000, 3.0)],
    "CONSOLE_ANALOG": [_band(_LS, 120, 1.5), _band(_PK, 800, 1.0, q=0.7), _band(_HS, 8000, 1.5)],
    "PULTEC_INSPIRED": [_band(_LS, 60, 4.0), _band(_PK, 200, -2.0, q=0.9), _band(_HS, 10000, 3.0)],
    "CONSOLE_TYPE": [_band(_PK, 100, 1.5, q=0.8), _band(_PK, 1000, -1.0, q=0.8),
                     _band(_PK, 10000, 2.0, q=0.8)],
    "CASSETTE_EQUIPMENT": [_band(_LS, 100, -1.5), _band(_HS, 10000, -3.0)],
}

_TECHNICAL = {
    "RIAA": [_band(_LS, 500.5, 14.0, q=0.5), _band(_HS, 2122.0, -12.0, q=0.5)],
    "NAB": [_band(_LS, 50.0, 10.0, q=0.5), _band(_HS, 3180.0, -8.0, q=0.5)],
    "IEC": [_band(_LS, 500.5, 14.0, q=0.5), _band(_HS, 2122.0, -12.0, q=0.5),
            _band(EqBandType.HPF, 20.0, 0.0, q=0.6)],
    "CCIR": [_band(_HS, 2274.0, -10.0, q=0.5)],
    "AES": [],
    "DIN": [_band(_LS, 50.0, 9.0, q=0.5), _band(_HS, 3180.0, -7.0, q=0.5)],
}

_TAPE = {
    "TYPE_I_NORMAL": [],
    "TYPE_II_CR02": [_band(_HS, 8000, 1.5)],
    "HIGH_BIAS": [_band(_HS, 8000, 1.0)],
    "TYPE_III_FECR": [_band(_LS, 150, 1.0), _band(_HS, 9000, 1.5)],
    "TYPE_IV_METAL": [_band(_HS, 10000, 2.0)],
    "CASSETTE_BRIGHT": [_band(_HS, 6000, 4.0)],
    "CASSETTE_SOFT": [_band(_HS, 6000, -4.0)],
    "CASSETTE_WARM": [_band(_LS, 200, 3.0), _band(_HS, 6000, -2.0)],
    "CASSETTE_VOCAL": [_band(_PK, 2500, 3.0, q=1.2)],
    "CASSETTE_MUSIC": [_band(_LS, 100, 2.0), _band(_HS, 8000, 2.0)],
}

MUSCLE_EQ_PRESET_CATEGORIES = {
    "TONAL": _TONAL,
    "MUSICAL": _MUSICAL,
    "HISTORICAL": _HISTORICAL,
    "TECHNICAL": _TECHNICAL,
    "TAPE": _TAPE,
}


def get_preset_bands(preset_id: str) -> list:
    for category in MUSCLE_EQ_PRESET_CATEGORIES.values():
        if preset_id in category:
            return list(category[preset_id])
    return []


def list_presets_flat() -> list:
    out = []
    for category, presets in MUSCLE_EQ_PRESET_CATEGORIES.items():
        for preset_id in presets:
            out.append((category, preset_id))
    return out
