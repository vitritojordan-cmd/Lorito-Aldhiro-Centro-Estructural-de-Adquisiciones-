from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Utilidad compartida de compilación JIT opcional (Numba) para los núcleos DSP.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_numba_utils.py — utilidad compartida de aceleración Numba para
los DSP nuevos de Lorito Aldhiro (MPX, EQ/BIAS, FOCUS — pedido explícito
del usuario: "aceleración Numba y NumPy, con tratamiento a tiempo real").

Mismo criterio de degradación con gracia que el resto del proyecto
(§GAP-010 "Fnc No Disp", etc.): si `numba` no está instalado en el
entorno (no es una dependencia dura de PySide6/NumPy/sounddevice, y
puede fallar su compilación en algunas plataformas), los bucles JIT
caen a Python/NumPy puro — más lentos, pero CORRECTOS bit a bit, nunca
una función que calla o degrada el resultado en silencio. `NUMBA_OK`
permite a cada módulo DSP registrar en su overlay/log si está corriendo
acelerado o no, sin fingir aceleración que no existe.
"""

try:
    from numba import njit
    NUMBA_OK = True
except Exception:
    NUMBA_OK = False

    def njit(*args, **kwargs):
        """Decorador de reemplazo — no compila, solo devuelve la función
        Python/NumPy tal cual (misma firma/comportamiento, sin JIT)."""
        if len(args) == 1 and callable(args[0]) and not kwargs:
            return args[0]

        def _wrap(fn):
            return fn
        return _wrap
