from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Resampleo con continuidad de fase entre bloques, sin salto en los límites de chunk.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_resample_continuous.py — GAP-037, corrección medida del
deriva de fase en `_resample_stateful` (`lorito_playback_engine.py`).

GAP-026 había documentado, sin poder medirlo (bloqueado por
`sounddevice`/PySide6 no ejecutables), que `_resample_stateful` podría
tener un "artefacto de interpolación en cada límite de bloque" porque
`i0`/`i3` (los índices de la interpolación cúbica Catmull-Rom) se
acotan (`np.clip`) a los límites del `chunk` ACTUAL, repitiendo la
muestra de borde en vez de leer la muestra real del chunk anterior o
siguiente.

Esta sesión lo MIDIÓ por primera vez (con `sounddevice`/`soundfile`
ahora importables vía stubs funcionales): para chunks de 512-8192
frames (el rango real que usa `PlaybackEngine`, `PE_CHUNK_FRAMES=4096`)
y ratios de velocidad distintos de 1.0, el error se ACUMULA en cada
límite de chunk — no es un artefacto puntual y acotado, es una deriva
de fase que CRECE con la duración de la reproducción. Con chunks de
512 frames, más del 90% de las muestras de una sesión de reproducción
sostenida terminan mensurable y perceptiblemente desalineadas respecto
al resampleo de referencia (una sola pasada sobre el array completo).

## La corrección

`resample_stateful_continuous(chunk, ratio, cursor, history)` — misma
matemática Catmull-Rom que `_resample_stateful`, pero en vez de acotar
`i0`/`i3` a los límites de `chunk`, antepone un pequeño HISTORIAL (las
últimas `HISTORY_LEN=2` muestras del chunk anterior) antes de
interpolar, y devuelve las últimas `HISTORY_LEN` muestras de ESTE
chunk como historial para la llamada siguiente. Esto le da a la
interpolación acceso a las muestras REALES vecinas en cada frontera de
chunk, en vez de repetir el borde — el mismo principio que
`_resample_stateful` ya usa DENTRO de un chunk (donde sí tiene acceso
a las muestras reales), extendido a través de los límites de llamada.

Verificado numéricamente (`tests/test_resample_continuity.py`) contra
un resampleo de referencia de una sola pasada — el error residual con
esta corrección es indistinguible del error de redondeo de punto
flotante (no una deriva progresiva).

Estado (Orden Golden SMV): la reproducción usa ahora
`backend/playback/lorito_varispeed_reader.py` (cursor absoluto, sin
fronteras de chunk). Este módulo queda para la ruta de EXPORTACIÓN
(`lorito_export_resample_transform`). SMV-13: se retiró su "zona neutra"
(|ratio−1| < 0,0005 devolvía el chunk sin avanzar el cursor).
"""

import numpy as np

HISTORY_LEN = 2  # 2 muestras bastan para Catmull-Rom (i0 = i1-1, i3 = i1+2)


def resample_stateful_continuous(chunk: np.ndarray, ratio: float,
                                 in_cursor: float, history=None):
    """Misma interfaz que `_resample_stateful` más un parámetro
    `history` (array de hasta `HISTORY_LEN` muestras del final del
    chunk anterior, o `None`/vacío para la primera llamada de la
    sesión). Devuelve `(out_chunk, next_cursor, next_history)`."""
    # Orden Golden SMV-13: la antigua "zona neutra" (|ratio-1| < 0.0005)
    # devolvía el chunk crudo SIN avanzar el cursor por lo consumido y sin
    # interpolar la fracción de fase: al pasar 1,0004 → 1,0 → 1,001 la
    # fase saltaba. Solo la identidad EXACTA (ratio 1 y cursor 0) es un
    # paso directo matemáticamente equivalente; todo lo demás interpola.
    if ratio == 1.0 and in_cursor == 0.0:
        next_cursor = 0.0
        next_history = chunk[-HISTORY_LEN:] if len(chunk) >= HISTORY_LEN else chunk
        return chunk, next_cursor, next_history

    if history is None or len(history) == 0:
        history = np.zeros((0, chunk.shape[1]), dtype=chunk.dtype)
    h_len = history.shape[0]

    # Chunk aumentado: [historial | chunk actual] — la interpolación
    # ve muestras reales en vez de repetir el borde.
    augmented = np.concatenate([history, chunk], axis=0) if h_len else chunk
    n_in_aug = len(augmented)
    n_in = len(chunk)

    n_out = max(1, int(round(n_in / ratio)))
    if n_in < 1 or n_out < 1:
        next_history = chunk[-HISTORY_LEN:] if len(chunk) >= HISTORY_LEN else chunk
        return chunk, in_cursor, next_history

    # `in_cursor` es relativo al inicio del chunk ACTUAL (sin
    # historial) — se desplaza por `h_len` para indexar en `augmented`.
    t = (in_cursor + h_len) + np.arange(n_out, dtype=np.float64) * ratio
    cur_cursor_end = t[-1] + ratio

    i1 = np.floor(t).astype(np.int64)
    i1 = np.clip(i1, 0, n_in_aug - 1)
    mu = (t - i1).astype(np.float32)
    i0 = np.maximum(i1 - 1, 0)
    i2 = np.minimum(i1 + 1, n_in_aug - 1)
    i3 = np.minimum(i1 + 2, n_in_aug - 1)

    mu2 = mu * mu
    mu3 = mu2 * mu
    c0 = (-0.5 * mu3 + mu2 - 0.5 * mu)
    c1 = (1.5 * mu3 - 2.5 * mu2 + 1.0)
    c2 = (-1.5 * mu3 + 2.0 * mu2 + 0.5 * mu)
    c3 = (0.5 * mu3 - 0.5 * mu2)

    n_ch = chunk.shape[1]
    out = np.empty((n_out, n_ch), dtype=np.float32)
    for c in range(n_ch):
        col = augmented[:, c]
        out[:, c] = np.clip(
            c0 * col[i0] + c1 * col[i1] + c2 * col[i2] + c3 * col[i3],
            -1.0, 1.0)

    next_cursor = float(max(0.0, cur_cursor_end - h_len - n_in))
    next_history = chunk[-HISTORY_LEN:] if len(chunk) >= HISTORY_LEN else chunk
    return out, next_cursor, next_history
