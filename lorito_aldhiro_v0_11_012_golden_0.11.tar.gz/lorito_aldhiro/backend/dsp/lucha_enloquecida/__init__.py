from __future__ import annotations

"""
lorito_aldhiro.backend.dsp.lucha_enloquecida -- GAP-042, DSP "Lucha
Enloquecida (PREVI)" -- adaptado desde CRAC (tarball
crac_v0_37_416_quad_previ_chain_derived_export, modulo original
crac.dsp_previ.lucha_enloquecida) al catalogo de Lorito Aldhiro.

20 sub-perfiles "LUCHALOCA LOFI A" a "LUCHALOCA LOFI T", cada uno
emulando una tecnica de degradacion lo-fi distinta -- orden alfabetico
fijo, un solo perfil activo a la vez (mismo patron de exclusion
estructural que TapeEqBiasProfile/Antipestal).

## Que se recorto (pedido explicito del usuario, reiterado para este
DSP: "se deben recortar funciones (metricas PreviAnalyzer, overlay e
indicador TMI, lo mismo que el llamado a SVG)")

- get_metrics() -- retirado del contrato (LuchaProfile) y de las 20
  subclases. Existia unicamente para alimentar PreviAnalyzer.
- Infraestructura de UI/telemetria propia de CRAC (TMI, Vitreous, VFD
  dedicado, iconos SVG "INSLUCHAENLOQDSP[A-T]") -- no portada.
- lucha_enloquecida_previanalyzer_bridge.py -- no portado.
- lucha_enloquecida_compatibility_manager.py/ring_buffer.py/
  dolby_embedded.py -- mismo criterio que Cristhi Cosh/Antipestal
  (GAP-039/041): Lorito ya tiene su propio NR y su propio guard de
  no-finitud (sanitize_finite), aplicado externamente por
  NRCoordinator.

## Que se conservo exactamente igual

Las 20 clases de perfil y biquad.py se portaron con la MISMA
matematica que el original -- cada una ya era Qt-free, stateful, y se
autolimitaba a +-1.0 antes de devolver.
"""

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import (
    LuchaProfile, ModuleStatus,
)
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_a_spring_reverb_abuse import SpringReverbAbuseProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_b_acoustic_damping import AcousticDampingProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_c_starving_voltage import StarvingVoltageProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_d_tape_loops import TapeLoopsProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_e_pipe_echo_chamber import PipeEchoChamberProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_f_toy_capsule import ToyCapsuleProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_g_circuit_bending import CircuitBendingProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_h_impedance_mismatch import ImpedanceMismatchProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_i_megaphone import MegaphoneProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_j_generation_loss import GenerationLossProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_k_wire_recording import WireRecordingProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_l_ground_hum import GroundHumProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_m_tape_warping import TapeWarpingProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_n_baked_tape import BakedTapeProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_o_carbon_mic import CarbonMicProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_p_piezo_contact import PiezoContactProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_q_am_radio_detune import AmRadioDetuneProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_r_portastudio_overdrive import PortastudioOverdriveProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_s_under_biasing import UnderBiasingProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_t_vinyl_damage import VinylDamageProfile

LUCHA_PROFILE_ORDER = [
    ("A", "LUCHALOCA LOFI A", "Abuso físico de tanques de reverberación de muelles", SpringReverbAbuseProfile),
    ("B", "LUCHALOCA LOFI B", "Atenuación acústica extrema con materiales domésticos", AcousticDampingProfile),
    ("C", "LUCHALOCA LOFI C", "Baterías hambrientas (Starving the Voltage)", StarvingVoltageProfile),
    ("D", "LUCHALOCA LOFI D", "Bucles de cinta magnética caseros (Tape Loops)", TapeLoopsProfile),
    ("E", "LUCHALOCA LOFI E", "Cámaras de eco en tuberías y bidones de acero", PipeEchoChamberProfile),
    ("F", "LUCHALOCA LOFI F", "Cápsulas de juguetes y walkie-talkies económicos", ToyCapsuleProfile),
    ("G", "LUCHALOCA LOFI G", "Circuit bending en electrónica portátil", CircuitBendingProfile),
    ("H", "LUCHALOCA LOFI H", "Desadaptación deliberada de impedancias", ImpedanceMismatchProfile),
    ("I", "LUCHALOCA LOFI I", "El efecto megáfono y bocinas de lata", MegaphoneProfile),
    ("J", "LUCHALOCA LOFI J", "Generación múltiple por copia sucesiva (Generation Loss)", GenerationLossProfile),
    ("K", "LUCHALOCA LOFI K", "Grabación con alambre magnético (Wire Recording)", WireRecordingProfile),
    ("L", "LUCHALOCA LOFI L", "Inyección de zumbido de red eléctrica (Ground Hum)", GroundHumProfile),
    ("M", "LUCHALOCA LOFI M", "Manipulación manual del cabrestante (Tape Warping)", TapeWarpingProfile),
    ("N", "LUCHALOCA LOFI N", "Método de la \"cinta horneada\" y estrés térmico", BakedTapeProfile),
    ("O", "LUCHALOCA LOFI O", "Micrófonos de carbón telefónicos", CarbonMicProfile),
    ("P", "LUCHALOCA LOFI P", "Micrófonos piezoeléctricos de contacto caseros", PiezoContactProfile),
    ("Q", "LUCHALOCA LOFI Q", "Modulación de frecuencia con radios AM detunadas", AmRadioDetuneProfile),
    ("R", "LUCHALOCA LOFI R", "Saturación extrema de pistas en cassette (Portastudio Overdrive)", PortastudioOverdriveProfile),
    ("S", "LUCHALOCA LOFI S", "Subpolarización de cinta (Under-biasing)", UnderBiasingProfile),
    ("T", "LUCHALOCA LOFI T", "Uso de vinilos dañados y \"dubplates\" de acetato blando", VinylDamageProfile),
]

_CLASS_BY_CODE = {code: cls for code, _, _, cls in LUCHA_PROFILE_ORDER}
_LABEL_BY_CODE = {code: label for code, label, _, _ in LUCHA_PROFILE_ORDER}

assert len(_CLASS_BY_CODE) == 20, "deben ser exactamente 20 perfiles A-T"


class LuchaEnloquecidaProfile:
    """DSP LUCHA ENLOQUECIDA (PREVI) -- vive en el menú OPTAPE.
    mode en {"BYPASS", "A"..."T"} -- selección única (mismo patrón de
    exclusión estructural que TapeEqBiasProfile/Antipestal)."""

    display_name = "LUCHA ENLOQUECIDA (PREVI)"
    legend_label = "PREVI DSP"

    def __init__(self, mode: str = "BYPASS", sample_rate: int = 48000,
                channels: int = 2, **params):
        self.mode = (mode or "BYPASS").upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._active = self.mode in _CLASS_BY_CODE
        self._profile = None
        if self._active:
            cls = _CLASS_BY_CODE[self.mode]
            self._profile = cls(sample_rate=self.fs, channels=self.channels, **params)
            self._profile.reset()

    @property
    def label(self) -> str:
        return _LABEL_BY_CODE.get(self.mode, "BYPASS")

    def set_params(self, **kwargs):
        if self._profile is not None and hasattr(self._profile, "set_params"):
            self._profile.set_params(**kwargs)

    def reset(self):
        if self._profile is not None:
            self._profile.reset()

    def process_chunk(self, chunk):
        if not self._active or self._profile is None or chunk.size == 0:
            return chunk
        return self._profile.process(chunk)


__all__ = [
    "LuchaProfile", "ModuleStatus", "LUCHA_PROFILE_ORDER", "LuchaEnloquecidaProfile",
    "SpringReverbAbuseProfile", "AcousticDampingProfile", "StarvingVoltageProfile",
    "TapeLoopsProfile", "PipeEchoChamberProfile", "ToyCapsuleProfile",
    "CircuitBendingProfile", "ImpedanceMismatchProfile", "MegaphoneProfile",
    "GenerationLossProfile", "WireRecordingProfile", "GroundHumProfile",
    "TapeWarpingProfile", "BakedTapeProfile", "CarbonMicProfile",
    "PiezoContactProfile", "AmRadioDetuneProfile", "PortastudioOverdriveProfile",
    "UnderBiasingProfile", "VinylDamageProfile",
]
