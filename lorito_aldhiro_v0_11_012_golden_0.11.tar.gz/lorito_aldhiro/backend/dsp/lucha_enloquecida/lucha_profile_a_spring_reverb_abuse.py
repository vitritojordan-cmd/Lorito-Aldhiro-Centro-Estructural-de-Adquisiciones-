# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI A — Abuso físico de tanques de reverberación de muelles (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_a_spring_reverb_abuse.py — LUCHALOCA LOFI A
════════════════════════════════════════════════════════════════════════════
Técnica base: Abuso físico de tanques de reverberación de muelles.

"Emular la excitación violenta de una unidad de reverberación de
muelles mediante impulsos/resonancias metálicas controladas. El
procesador deberá producir: energía metálica; golpes resonantes;
truenos artificiales; vibración de muelles; comportamiento dependiente
de intensidad."

Cadena real: un tanque de muelles real ES la reverberación (procesa la
señal continuamente) — "abusarlo" (golpearlo/sacudirlo) añade
transitorios violentos que excitan sus modos resonantes por encima del
nivel normal. Se modela con un banco de 5 resonadores
`BiquadBandpassDF2T` en frecuencias inharmónicas (característica
dispersiva real de un muelle helicoidal — nunca una serie armónica);
la "vibración de muelles" sostenida ("golpes resonantes"/"truenos
artificiales") surge de la propia realimentación INTERNA del biquad
resonante (a1/a2, ya recursiva muestra a muestra dentro de
`BiquadBandpassDF2T`) — `decay` controla el Q de los 5 resonadores
(más Q ⇒ campana más angosta ⇒ timbre resuena más tiempo), nunca un
lazo de realimentación adicional a nivel de bloque (eso habría atado
el timbre al tamaño de bloque del host).

Un DETECTOR DE TRANSITORIOS persistente (envolvente de ataque rápido/
liberación lenta) inyecta, al superar un umbral dependiente de
`intensity`, una ráfaga de ruido en el banco de resonadores — el
"golpe"/"trueno artificial" real que excita los modos, no decorativo.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadBandpassDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_a")

__all__ = ["SpringReverbAbuseProfile"]

# Frecuencias inharmónicas representativas de los modos de un muelle
# helicoidal (dispersión real — nunca serie armónica 1:2:3...).
_MODE_FREQS_HZ = (780.0, 1450.0, 2100.0, 2850.0, 3600.0)
_Q_MIN, _Q_MAX = 6.0, 60.0


class SpringReverbAbuseProfile(LuchaProfile):
    """LUCHALOCA LOFI A — Abuso de Spring Reverb. Backend puro, sin
    Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 intensity: float = 0.6, decay: float = 0.5, mix: float = 0.6) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.intensity = float(np.clip(intensity, 0.0, 1.0))
        self.decay = float(np.clip(decay, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        q = _Q_MIN + self.decay * (_Q_MAX - _Q_MIN)
        self._resonators = [
            [BiquadBandpassDF2T(freq_hz=f, q=q, fs=self.sample_rate) for f in _MODE_FREQS_HZ]
            for _ in range(self.channels)
        ]
        self._env = [0.0] * self.channels
        self._rng = np.random.default_rng(9001)
        self._impact_activity = 0.0
        self._resonance_activity = 0.0

    def reset(self) -> None:
        for ch_res in self._resonators:
            for r in ch_res:
                r.reset()
        self._env = [0.0] * self.channels
        self._rng = np.random.default_rng(9001)
        self._impact_activity = 0.0
        self._resonance_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, intensity=None, decay=None, mix=None) -> None:
        if intensity is not None:
            self.intensity = float(np.clip(intensity, 0.0, 1.0))
        if decay is not None:
            self.decay = float(np.clip(decay, 0.0, 1.0))
            q = _Q_MIN + self.decay * (_Q_MAX - _Q_MIN)
            for ch_res in self._resonators:
                for r in ch_res:
                    r.set_params(q=q)   # nunca reinicia z1/z2 — continuidad (§7)
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)

            threshold = 1.0 - self.intensity * 0.9
            impact_energies = []
            resonance_energies = []

            for ch in range(n_ch):
                bch = ch % self.channels
                resonators = self._resonators[bch]
                env = self._env[bch]
                inp = x[:, ch].astype(np.float64)

                # Detector de transitorios — envolvente persistente,
                # ataque rápido/liberación lenta (~4ms a 48kHz).
                impact_gate = np.zeros(n, dtype=np.float64)
                for i in range(n):
                    level = abs(inp[i])
                    coef = 0.7 if level > env else 0.003
                    env = env + coef * (level - env)
                    impact_gate[i] = 1.0 if env > threshold else 0.0
                self._env[bch] = env

                noise_burst = self._rng.standard_normal(n) * impact_gate * (0.6 + self.intensity * 2.0)
                excitation = inp * (0.2 + 0.3 * self.intensity) + noise_burst

                mode_sum = np.zeros(n, dtype=np.float64)
                for res in resonators:
                    mode_sum += res.process(excitation)
                mode_sum /= len(resonators)

                out[:, ch] = mode_sum
                impact_energies.append(float(np.mean(impact_gate)))
                resonance_energies.append(float(np.sqrt(np.mean(np.square(mode_sum)) + 1e-12)))

            self._impact_activity = float(np.mean(impact_energies)) if impact_energies else 0.0
            self._resonance_activity = float(np.mean(resonance_energies)) if resonance_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("SpringReverbAbuseProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
