# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI B — Atenuación acústica extrema con materiales domésticos (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_b_acoustic_damping.py — LUCHALOCA LOFI B
════════════════════════════════════════════════════════════════════════════
Técnica base: Atenuación acústica extrema con materiales domésticos.

"Simular el efecto de envolver fuentes o micrófonos con materiales
absorbentes. El DSP deberá producir: fuerte reducción de agudos;
pérdida de brillo; proximidad artificial; reducción de reflexiones;
sensación de señal amortiguada."

Cadena real: 1) paso-bajos STATEFUL en cascada (2 etapas Butterworth,
corte controlado por `attenuation_amount`) para la "fuerte reducción
de agudos"/"pérdida de brillo" — 2) realce de graves-medios
(`BiquadDF2T` peaking ~200Hz) para la "proximidad artificial" (efecto
de bocina/mantas: la envoltura absorbe agudos pero refuerza la
resonancia de baja frecuencia de la cavidad textil) — 3) un
"amortiguador de transitorios" — envolvente persistente que reduce la
ganancia de picos súbitos (los materiales absorbentes suavizan el
ataque y las reflexiones tempranas, nunca las eliminan
instantáneamente) para "reducción de reflexiones"/"señal amortiguada".
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_b")

__all__ = ["AcousticDampingProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class AcousticDampingProfile(LuchaProfile):
    """LUCHALOCA LOFI B — Atenuación acústica extrema. Backend puro,
    sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 attenuation_amount: float = 0.6, proximity_amount: float = 0.4,
                 damping: float = 0.4, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.attenuation_amount = float(np.clip(attenuation_amount, 0.0, 1.0))
        self.proximity_amount = float(np.clip(proximity_amount, 0.0, 1.0))
        self.damping = float(np.clip(damping, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._lpf1_b = self._lpf1_a = None
        self._lpf2_b = self._lpf2_a = None
        self._lpf1_zi: list = []
        self._lpf2_zi: list = []
        self._proximity = [
            BiquadDF2T(freq_hz=200.0, q=0.9, gain_db=self.proximity_amount * 9.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._env = [0.0] * self.channels
        self._damping_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        cutoff = max(600.0, 9000.0 * (1.0 - self.attenuation_amount * 0.92))
        wn = float(np.clip(cutoff / nyq, 1e-4, 0.97))
        self._lpf1_b, self._lpf1_a = butter(2, wn, btype="low")
        self._lpf2_b, self._lpf2_a = butter(2, wn, btype="low")
        self._lpf1_zi = [_zi_at_rest(self._lpf1_b, self._lpf1_a).copy() for _ in range(self.channels)]
        self._lpf2_zi = [_zi_at_rest(self._lpf2_b, self._lpf2_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        for p in self._proximity:
            p.reset()
        self._env = [0.0] * self.channels
        self._damping_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, attenuation_amount=None, proximity_amount=None, damping=None, mix=None) -> None:
        rebuild = False
        if attenuation_amount is not None:
            self.attenuation_amount = float(np.clip(attenuation_amount, 0.0, 1.0))
            rebuild = True
        if proximity_amount is not None:
            self.proximity_amount = float(np.clip(proximity_amount, 0.0, 1.0))
            for p in self._proximity:
                p.set_params(gain_db=self.proximity_amount * 9.0)
        if damping is not None:
            self.damping = float(np.clip(damping, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if rebuild:
            self._rebuild_filters()

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._lpf1_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            damp_energies = []

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                filtered, zf1 = lfilter(self._lpf1_b, self._lpf1_a, inp, zi=self._lpf1_zi[bch])
                self._lpf1_zi[bch] = zf1
                filtered, zf2 = lfilter(self._lpf2_b, self._lpf2_a, filtered, zi=self._lpf2_zi[bch])
                self._lpf2_zi[bch] = zf2

                warmed = self._proximity[bch].process(filtered) * self.proximity_amount * 0.5 + filtered

                # Amortiguador de transitorios — envolvente rápida que
                # reduce ganancia de picos por encima de la media
                # reciente, en vez de eliminarlos de golpe.
                env = self._env[bch]
                damped = np.empty_like(warmed)
                for i in range(n):
                    level = abs(warmed[i])
                    env = env + (0.4 if level > env else 0.01) * (level - env)
                    excess = max(0.0, level - env * 1.4)
                    gain = 1.0 - self.damping * min(1.0, excess * 2.0)
                    damped[i] = warmed[i] * gain
                self._env[bch] = env
                damp_energies.append(float(np.mean(np.abs(warmed - damped))))

                out[:, ch] = damped

            self._damping_activity = float(np.mean(damp_energies)) if damp_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("AcousticDampingProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
