# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI C — Baterías hambrientas (Starving the Voltage) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_c_starving_voltage.py — LUCHALOCA LOFI C
════════════════════════════════════════════════════════════════════════════
Técnica base: Baterías Hambrientas (Starving the Voltage).

"Modelar la alteración del punto de operación producida por una
alimentación insuficiente. Parámetros mínimos: intensidad de
starving; asimetría; compresión; gating; sustain quebradizo."

Cadena real: un acumulador de "agotamiento" (`depletion`) PERSISTENTE
crece mientras el nivel de entrada es alto (la batería se descarga
bajo demanda de corriente) y se recupera lentamente en silencio —
nunca instantáneo, igual que una batería real. `depletion` alimenta
tres efectos simultáneos: 1) COMPRESIÓN progresiva (la ganancia cae
más cuanto más agotada está la fuente) con recuperación LENTA
("sag"), 2) RECORTE ASIMÉTRICO (`asymmetry` desplaza el punto de
operación — un riel de alimentación insuficiente no es simétrico) que
se vuelve más severo con `depletion`, 3) SUSTAIN QUEBRADIZO — durante
la fase de decaimiento de una nota (envolvente cayendo) con
`depletion` alto, se inyectan micro-cortes estocásticos (gate
intermitente, persistente entre bloques) — el crepitar/tartamudeo real
de una fuente que ya no sostiene la corriente pedida.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_c")

__all__ = ["StarvingVoltageProfile"]


class StarvingVoltageProfile(LuchaProfile):
    """LUCHALOCA LOFI C — Starving the Voltage. Backend puro, sin
    Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 starving_intensity: float = 0.5, asymmetry: float = 0.3,
                 gate_amount: float = 0.4, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.starving_intensity = float(np.clip(starving_intensity, 0.0, 1.0))
        self.asymmetry = float(np.clip(asymmetry, 0.0, 1.0))
        self.gate_amount = float(np.clip(gate_amount, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._env = [0.0] * self.channels
        self._depletion = [0.0] * self.channels
        self._crackle_env = [0.0] * self.channels
        self._rng = np.random.default_rng(4177)
        self._depletion_activity = 0.0
        self._gate_activity = 0.0

    def reset(self) -> None:
        self._env = [0.0] * self.channels
        self._depletion = [0.0] * self.channels
        self._crackle_env = [0.0] * self.channels
        self._rng = np.random.default_rng(4177)
        self._depletion_activity = 0.0
        self._gate_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, starving_intensity=None, asymmetry=None, gate_amount=None, mix=None) -> None:
        if starving_intensity is not None:
            self.starving_intensity = float(np.clip(starving_intensity, 0.0, 1.0))
        if asymmetry is not None:
            self.asymmetry = float(np.clip(asymmetry, 0.0, 1.0))
        if gate_amount is not None:
            self.gate_amount = float(np.clip(gate_amount, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            depletions = []
            gate_hits = []

            drain_rate = 0.01 + self.starving_intensity * 0.05
            recover_rate = 0.0008
            trigger_rand = self._rng.random(n)

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)
                env = self._env[bch]
                depletion = self._depletion[bch]
                crackle_env = self._crackle_env[bch]
                y = np.empty(n, dtype=np.float64)
                n_gate_hits = 0

                for i in range(n):
                    xi = inp[i]
                    level = abs(xi)
                    env_prev = env
                    env = env + (0.3 if level > env else 0.01) * (level - env)
                    depletion += drain_rate * env - recover_rate * (1.0 - env)
                    depletion = min(1.0, max(0.0, depletion))

                    # 1) Compresión progresiva con recuperación lenta.
                    comp_gain = 1.0 / (1.0 + self.starving_intensity * depletion * 3.0)
                    v = xi * comp_gain

                    # 2) Recorte asimétrico, más severo con depletion.
                    pos_ceiling = 1.0 - self.asymmetry * depletion * 0.5
                    neg_ceiling = 1.0 - self.asymmetry * depletion * 0.15
                    v = min(v, pos_ceiling) if v >= 0.0 else max(v, -neg_ceiling)

                    # 3) Sustain quebradizo — solo en decaimiento
                    # (envolvente bajando) con depletion alto.
                    decaying = env < env_prev
                    crackle_env *= 0.97
                    if decaying and depletion > 0.4 and self.gate_amount > 0.0:
                        chance = self.gate_amount * depletion * 0.08
                        if trigger_rand[i] < chance:
                            crackle_env = 1.0
                            n_gate_hits += 1
                    v *= (1.0 - crackle_env)

                    y[i] = v

                self._env[bch] = env
                self._depletion[bch] = depletion
                self._crackle_env[bch] = crackle_env
                out[:, ch] = y
                depletions.append(depletion)
                gate_hits.append(n_gate_hits)

            self._depletion_activity = float(np.mean(depletions)) if depletions else 0.0
            self._gate_activity = float(np.mean(gate_hits)) if gate_hits else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("StarvingVoltageProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
