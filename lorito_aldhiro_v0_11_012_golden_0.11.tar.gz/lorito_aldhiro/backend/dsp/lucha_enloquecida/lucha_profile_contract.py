from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Contrato mínimo (reset/process) que implementan los 20 emuladores Lucha Enloquecida.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_contract.py -- lucha_enloquecida (GAP-042)

Contrato minimo que cada uno de los 20 emuladores LUCHALOCA LOFI
implementa. Portado desde CRAC con una diferencia deliberada: el
original tambien exige `get_metrics()` (abstracto) para alimentar
PreviAnalyzer -- Lorito no tiene PreviAnalyzer (pedido explicito del
usuario: "se deben recortar... metricas PreviAnalyzer"), asi que este
metodo NO forma parte del contrato aqui, y se retiro de las 20
subclases al portarlas.
"""

from abc import ABC, abstractmethod
from enum import Enum

import numpy as np

__all__ = ["ModuleStatus", "LuchaProfile"]


class ModuleStatus(str, Enum):
    OFF = "off"
    ARMED = "armed"
    MONITORING = "monitoring"
    PROCESSING = "processing"
    BYPASSED = "bypassed"
    FAULT = "fault"


class LuchaProfile(ABC):
    """Contrato abstracto de un emulador LUCHALOCA LOFI."""

    status: ModuleStatus

    @abstractmethod
    def reset(self) -> None:
        """Reinicia TODO el estado interno -- buffers, filtros,
        osciladores, lineas de retardo -- a como si nunca hubiera
        procesado nada."""
        raise NotImplementedError

    @abstractmethod
    def process(self, block: np.ndarray) -> np.ndarray:
        """Procesa un bloque -- stateful y block-safe: llamadas
        consecutivas equivalen a procesar el flujo continuo. Se
        autolimita a +-1.0 antes de devolver."""
        raise NotImplementedError
