# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI D — Bucles de cinta magnética caseros (Tape Loops) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_d_tape_loops.py — LUCHALOCA LOFI D
════════════════════════════════════════════════════════════════════════════
Técnica base: Bucles de cinta magnética caseros (Tape Loops).

"Emular el comportamiento de un bucle físico de cinta: repetición,
periodicidad, discontinuidad de unión, clic/chascado, desgaste
progresivo. Deberá existir control de longitud de ciclo y cantidad/
intensidad de imperfección."

Cadena real:
  1. FASE DE GRABACIÓN — los primeros `loop_length_s` segundos de
     entrada se capturan en un buffer circular dedicado (el "bucle
     físico"); la salida en esta fase es la señal seca (§8: nunca
     fabricar un tratamiento antes de tener contenido real que
     tratar).
  2. FASE DE REPRODUCCIÓN — el buffer se reproduce en bucle,
     STATEFUL entre bloques (posición de lectura persistente).
  3. DISCONTINUIDAD DE UNIÓN — en cada vuelta del bucle ("seam") se
     inyecta un clic/chasquido real (transitorio de decaimiento
     exponencial corto), nunca solo un salto de fase silencioso.
  4. DESGASTE PROGRESIVO — cada vez que el bucle completa una vuelta
     completa, se aplica AL PROPIO CONTENIDO DEL BUFFER (no a la
     salida) un paso de degradación acumulativa: filtro paso-bajos
     STATEFUL de corte decreciente + saturación creciente + una
     pequeña cantidad de ruido — el bucle se oye objetivamente peor
     en cada pasada, igual que una cinta física que se desgasta con
     el roce repetido contra las cabezas.

Kernel de lectura/escritura por muestra (bucle explícito, patrón
`@njit`-con-fallback ya usado en `caurita_profile_aae.py`) — necesario
porque la transición grabación→reproducción y el punto de "seam" caen
en una muestra arbitraria dentro de un bloque, no en la frontera de
bloque.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

try:
    from numba import njit as _njit
    _HAVE_NUMBA = True
except Exception:  # pragma: no cover - entorno sin numba disponible
    _HAVE_NUMBA = False
    _njit = None

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_d")

__all__ = ["TapeLoopsProfile"]


def _rw_kernel(in_ch: np.ndarray, buf: np.ndarray, write_pos: int, read_pos: int,
                recording: int, click_amount: float, click_len: int) -> "tuple":
    n = in_ch.shape[0]
    loop_len = buf.shape[0]
    out = np.empty(n, dtype=np.float64)
    wraps = 0
    for i in range(n):
        if recording == 1:
            buf[write_pos] = in_ch[i]
            out[i] = in_ch[i]
            write_pos += 1
            if write_pos >= loop_len:
                write_pos = 0
                recording = 0
                read_pos = 0
        else:
            sample = buf[read_pos]
            if click_amount > 0.0 and read_pos < click_len:
                env = 1.0 - (read_pos / click_len)
                sample = sample + click_amount * env * (1.0 if (read_pos % 2 == 0) else -1.0)
            out[i] = sample
            read_pos += 1
            if read_pos >= loop_len:
                read_pos = 0
                wraps += 1
    return out, write_pos, read_pos, recording, wraps


if _HAVE_NUMBA:
    _rw_kernel = _njit(cache=True)(_rw_kernel)


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class TapeLoopsProfile(LuchaProfile):
    """LUCHALOCA LOFI D — Tape Loops. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 loop_length_s: float = 0.35, wear_amount: float = 0.4,
                 seam_click_amount: float = 0.3, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.loop_length_s = float(np.clip(loop_length_s, 0.05, 2.0))
        self.wear_amount = float(np.clip(wear_amount, 0.0, 1.0))
        self.seam_click_amount = float(np.clip(seam_click_amount, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._click_len = max(4, int(0.003 * self.sample_rate))
        self._loop_len = max(self._click_len * 2, int(self.loop_length_s * self.sample_rate))
        self._buf = np.zeros((self._loop_len, self.channels), dtype=np.float64)
        self._write_pos = 0
        self._read_pos = 0
        self._recording = 1
        self._pass_count = 0
        self._wear_lpf_zi = [None] * self.channels
        self._degrade_activity = 0.0
        self.reset()

    def reset(self) -> None:
        self._buf[:] = 0.0
        self._write_pos = 0
        self._read_pos = 0
        self._recording = 1
        self._pass_count = 0
        self._degrade_activity = 0.0
        self._wear_lpf_zi = [None] * self.channels
        self.status = ModuleStatus.ARMED

    def set_params(self, wear_amount=None, seam_click_amount=None, mix=None) -> None:
        if wear_amount is not None:
            self.wear_amount = float(np.clip(wear_amount, 0.0, 1.0))
        if seam_click_amount is not None:
            self.seam_click_amount = float(np.clip(seam_click_amount, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def _degrade_pass(self, ch: int) -> None:
        """Desgaste progresivo (§ orden): aplicado UNA VEZ por vuelta
        completa, directamente al contenido del buffer — nunca a la
        señal de salida en tránsito."""
        self._pass_count += 1
        if not _SCIPY_OK or self.wear_amount <= 0.0:
            return
        nyq = 0.5 * self.sample_rate
        # El corte baja con cada pasada — nunca por debajo de 1.2 kHz
        # (evita que el bucle degenere en silencio total, "corrupción
        # accidental" prohibida por §8).
        cutoff = max(1200.0, 12000.0 * (1.0 - self.wear_amount * 0.03) ** self._pass_count)
        wn = float(np.clip(cutoff / nyq, 1e-4, 0.97))
        b, a = butter(2, wn, btype="low")
        zi = self._wear_lpf_zi[ch]
        if zi is None:
            zi = _zi_at_rest(b, a) * self._buf[0, ch]
        filtered, zf = lfilter(b, a, self._buf[:, ch], zi=zi)
        self._wear_lpf_zi[ch] = zf
        drive = 1.0 + self.wear_amount * 0.4 * min(self._pass_count, 20)
        saturated = np.tanh(filtered * drive) / max(drive, 1.0)
        noise = self.wear_amount * 0.002 * np.random.default_rng(self._pass_count + ch).standard_normal(self._loop_len)
        self._buf[:, ch] = saturated + noise
        self._degrade_activity = min(1.0, self._pass_count * self.wear_amount * 0.05)

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = np.empty_like(x, dtype=np.float64)

            for ch in range(n_ch):
                buf_ch = self._buf[:, ch % self.channels]
                res = _rw_kernel(x[:, ch].astype(np.float64), buf_ch,
                                  self._write_pos, self._read_pos, self._recording,
                                  self.seam_click_amount, self._click_len)
                out_ch, self._write_pos, self._read_pos, self._recording, wraps = res
                out[:, ch] = out_ch
                for _ in range(wraps):
                    self._degrade_pass(ch % self.channels)

            wet = out
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + wet * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("TapeLoopsProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
