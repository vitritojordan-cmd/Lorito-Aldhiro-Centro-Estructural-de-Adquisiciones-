# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI E — Cámaras de eco en tuberías y bidones de acero (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_e_pipe_echo_chamber.py — LUCHALOCA LOFI E
════════════════════════════════════════════════════════════════════════════
Técnica base: Cámaras de eco en tuberías y bidones de acero.

"Crear una respuesta espacial metálica y claustrofóbica inspirada en
tuberías, bidones y espacios físicos improvisados. Controles:
resonancia; tamaño virtual; densidad; realimentación; absorción."

Cadena real — mismo esquema de reverberador Schroeder que fundamenta
la mayoría de reverbs algorítmicos reales: 4 líneas COMB (retardo +
realimentación, cada una con su propia línea circular STATEFUL,
`tamaño virtual` escala sus longitudes) sumadas en paralelo, cada una
con un paso-bajos de un polo PERSISTENTE en el lazo de realimentación
(`absorción` — el acero absorbe agudos en cada rebote, nunca de golpe)
y ganancia de realimentación acotada (`realimentación`, siempre < 1 —
§8: nunca runaway). `densidad` controla cuántas de las 4 líneas están
activas (1 línea = eco discreto y metálico; 4 = textura más densa y
claustrofóbica). `resonancia` es una ganancia de excitación de las
líneas comb — cuanto mayor, más domina el timbre resonante del "bidón"
sobre la señal seca en el lazo.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_e")

__all__ = ["PipeEchoChamberProfile"]

# Longitudes base de las 4 líneas comb, en ms — relación no entera
# entre sí (evita refuerzos/cancelaciones periódicas coincidentes,
# mismo criterio que un reverb Schroeder real).
_BASE_DELAYS_MS = (29.7, 37.1, 41.3, 47.9)


class _CombLine:
    __slots__ = ("buf", "pos", "damp_state", "length")

    def __init__(self, length: int) -> None:
        self.length = max(2, int(length))
        self.buf = np.zeros(self.length, dtype=np.float64)
        self.pos = 0
        self.damp_state = 0.0


class PipeEchoChamberProfile(LuchaProfile):
    """LUCHALOCA LOFI E — Cámaras de eco en tuberías/bidones. Backend
    puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 resonance: float = 0.5, size: float = 0.5, density: float = 0.75,
                 feedback: float = 0.55, absorption: float = 0.5, mix: float = 0.5) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.resonance = float(np.clip(resonance, 0.0, 1.0))
        self.size = float(np.clip(size, 0.0, 1.0))
        self.density = float(np.clip(density, 0.0, 1.0))
        self.feedback = float(np.clip(feedback, 0.0, 1.0))
        self.absorption = float(np.clip(absorption, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._combs = [self._build_combs() for _ in range(self.channels)]
        self._resonance_activity = 0.0

    def _build_combs(self):
        size_scale = 0.5 + self.size * 1.5  # 0.5x .. 2.0x
        return [
            _CombLine(int(ms * 1e-3 * self.sample_rate * size_scale))
            for ms in _BASE_DELAYS_MS
        ]

    def reset(self) -> None:
        self._combs = [self._build_combs() for _ in range(self.channels)]
        self._resonance_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, resonance=None, size=None, density=None, feedback=None,
                    absorption=None, mix=None) -> None:
        rebuild = False
        if resonance is not None:
            self.resonance = float(np.clip(resonance, 0.0, 1.0))
        if size is not None:
            self.size = float(np.clip(size, 0.0, 1.0))
            rebuild = True
        if density is not None:
            self.density = float(np.clip(density, 0.0, 1.0))
        if feedback is not None:
            self.feedback = float(np.clip(feedback, 0.0, 1.0))
        if absorption is not None:
            self.absorption = float(np.clip(absorption, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if rebuild:
            self._combs = [self._build_combs() for _ in range(self.channels)]

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)

            n_active = max(1, int(round(1 + self.density * 3)))  # 1..4 líneas
            fb_gain = min(0.985, 0.3 + self.feedback * 0.68)
            damp_coef = 0.15 + self.absorption * 0.8  # más absorción -> más damping por rebote
            excite_gain = 0.3 + self.resonance * 1.4
            resonance_energies = []

            for ch in range(n_ch):
                bch = ch % self.channels
                combs = self._combs[bch][:n_active]
                inp = x[:, ch].astype(np.float64)
                wet = np.zeros(n, dtype=np.float64)

                for comb in combs:
                    buf = comb.buf
                    length = comb.length
                    pos = comb.pos
                    damp_state = comb.damp_state
                    comb_out = np.empty(n, dtype=np.float64)
                    for i in range(n):
                        delayed = buf[pos]
                        damp_state = damp_state + damp_coef * (delayed - damp_state)
                        fed = inp[i] * excite_gain + damp_state * fb_gain
                        buf[pos] = fed
                        comb_out[i] = delayed
                        pos += 1
                        if pos >= length:
                            pos = 0
                    comb.pos = pos
                    comb.damp_state = damp_state
                    wet += comb_out

                wet /= max(1, n_active)
                out[:, ch] = wet
                resonance_energies.append(float(np.sqrt(np.mean(np.square(wet)) + 1e-12)))

            self._resonance_activity = float(np.mean(resonance_energies)) if resonance_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("PipeEchoChamberProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
