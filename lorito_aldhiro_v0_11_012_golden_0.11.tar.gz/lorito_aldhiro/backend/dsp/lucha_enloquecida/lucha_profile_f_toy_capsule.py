# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI F — Cápsulas de juguetes y walkie-talkies económicos (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_f_toy_capsule.py — LUCHALOCA LOFI F
════════════════════════════════════════════════════════════════════════════
Técnica base: Cápsulas de juguetes y Walkie-Talkies económicos.

"Simular una cápsula económica de pequeño formato. Características:
ancho de banda reducido; compresión; resonancias; carácter juguetón;
respuesta irregular."

Cadena real: 1) banda angosta (HPF+LPF Butterworth STATEFUL, ~450Hz–
3.2kHz) para el "ancho de banda reducido" — 2) `BiquadDF2T` peaking en
la resonancia característica de una cápsula diminuta (~2.1kHz) —
3) compresor barato (rodilla dura, ataque/liberación rápidos,
poco headroom) para el "carácter juguetón" de un AGC de circuito
integrado simple — 4) "respuesta irregular": la frecuencia de la
resonancia se modula con un oscilador de fase acumulada PERSISTENTE de
muy baja frecuencia (~0.35Hz) — nunca una resonancia perfectamente
estable, como una cápsula barata real cuyo timbre varía con la presión
acústica/temperatura.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_f")

__all__ = ["ToyCapsuleProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class ToyCapsuleProfile(LuchaProfile):
    """LUCHALOCA LOFI F — Cápsula de juguete/Walkie-Talkie. Backend
    puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 bandwidth_amount: float = 0.7, resonance_amount: float = 0.5,
                 compression: float = 0.5, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.bandwidth_amount = float(np.clip(bandwidth_amount, 0.0, 1.0))
        self.resonance_amount = float(np.clip(resonance_amount, 0.0, 1.0))
        self.compression = float(np.clip(compression, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._hp_b = self._hp_a = None
        self._lp_b = self._lp_a = None
        self._hp_zi: list = []
        self._lp_zi: list = []
        self._resonance = [
            BiquadDF2T(freq_hz=2100.0, q=3.5, gain_db=self.resonance_amount * 10.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._irregular_phase = [0.0] * self.channels
        self._env = [0.0] * self.channels
        self._compression_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        hp_hz = 250.0 + self.bandwidth_amount * 350.0     # 250..600 Hz
        lp_hz = 5500.0 - self.bandwidth_amount * 3000.0   # 5500..2500 Hz
        wn_hp = float(np.clip(hp_hz / nyq, 1e-4, 0.97))
        wn_lp = float(np.clip(lp_hz / nyq, 1e-4, 0.97))
        self._hp_b, self._hp_a = butter(2, wn_hp, btype="high")
        self._lp_b, self._lp_a = butter(2, wn_lp, btype="low")
        self._hp_zi = [_zi_at_rest(self._hp_b, self._hp_a).copy() for _ in range(self.channels)]
        self._lp_zi = [_zi_at_rest(self._lp_b, self._lp_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        for r in self._resonance:
            r.reset()
        self._irregular_phase = [0.0] * self.channels
        self._env = [0.0] * self.channels
        self._compression_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, bandwidth_amount=None, resonance_amount=None, compression=None, mix=None) -> None:
        rebuild = False
        if bandwidth_amount is not None:
            self.bandwidth_amount = float(np.clip(bandwidth_amount, 0.0, 1.0))
            rebuild = True
        if resonance_amount is not None:
            self.resonance_amount = float(np.clip(resonance_amount, 0.0, 1.0))
            for r in self._resonance:
                r.set_params(gain_db=self.resonance_amount * 10.0)
        if compression is not None:
            self.compression = float(np.clip(compression, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if rebuild:
            self._rebuild_filters()

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._hp_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            w_irr = 2.0 * np.pi * 0.35 / self.sample_rate
            comp_energies = []

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                banded, zf_hp = lfilter(self._hp_b, self._hp_a, inp, zi=self._hp_zi[bch])
                self._hp_zi[bch] = zf_hp
                banded, zf_lp = lfilter(self._lp_b, self._lp_a, banded, zi=self._lp_zi[bch])
                self._lp_zi[bch] = zf_lp

                # Respuesta irregular — modula sutilmente la frecuencia
                # de resonancia con un LFO de fase persistente (fase
                # actualizada una vez por bloque, suficiente para una
                # modulación de ~0.35 Hz; nunca depende del tamaño de
                # bloque, solo avanza `w_irr` radianes por muestra).
                phase = self._irregular_phase[bch]
                freq_wobble = 2100.0 + 120.0 * np.sin(phase)
                self._resonance[bch].set_params(freq_hz=float(freq_wobble))
                self._irregular_phase[bch] = float((phase + w_irr * n) % (2.0 * np.pi))
                resonant = self._resonance[bch].process(banded)

                # Compresor barato — rodilla dura, ataque/liberación
                # rápidos, poco headroom.
                env = self._env[bch]
                threshold = 1.0 - self.compression * 0.7
                compressed = np.empty(n, dtype=np.float64)
                for i in range(n):
                    level = abs(resonant[i])
                    env = env + (0.5 if level > env else 0.08) * (level - env)
                    gain = 1.0 if env <= threshold else threshold / max(env, 1e-9)
                    compressed[i] = resonant[i] * gain
                self._env[bch] = env
                comp_energies.append(float(np.mean(np.abs(resonant - compressed))))

                out[:, ch] = compressed

            self._compression_activity = float(np.mean(comp_energies)) if comp_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("ToyCapsuleProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
