# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI G — Circuit bending en electrónica portátil (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_g_circuit_bending.py — LUCHALOCA LOFI G
════════════════════════════════════════════════════════════════════════════
Técnica base: Circuit Bending en electrónica portátil.

"Emular interrupciones y comportamientos impredecibles de circuitos
electrónicos modificados. Debe incorporar: glitches; modulación
irregular; inestabilidad; pérdida de continuidad; eventos
pseudoaleatorios controlables."

Cadena real — máquina de estados muestra a muestra con 3 tipos de
"glitch" mutuamente excluyentes, disparados por un proceso estocástico
persistente (nunca recreado por bloque, mismo generador de la
instancia en todas las llamadas — continuidad estadística real):

  · CONGELAMIENTO (sample-and-hold) — repite el último valor capturado
    ("pérdida de continuidad" literal).
  · BITCRUSH — cuantiza a pocos bits durante el evento.
  · DROPOUT — atenuación severa temporal (corte de alimentación breve).

Cada evento tiene duración propia (aleatoria, escalada por
`glitch_intensity`) y solo puede dispararse uno nuevo cuando el
anterior terminó — nunca dos superpuestos. Fuera de un evento, se
aplica una modulación de amplitud lenta e IRREGULAR (paseo aleatorio
suavizado, persistente) para la "inestabilidad"/"modulación irregular"
continua del circuito, incluso sin glitches activos.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_g")

__all__ = ["CircuitBendingProfile"]

_TYPE_FREEZE, _TYPE_BITCRUSH, _TYPE_DROPOUT = 0, 1, 2


class CircuitBendingProfile(LuchaProfile):
    """LUCHALOCA LOFI G — Circuit Bending. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 glitch_rate_hz: float = 2.0, glitch_intensity: float = 0.5,
                 instability: float = 0.3, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.glitch_rate_hz = float(max(0.0, glitch_rate_hz))
        self.glitch_intensity = float(np.clip(glitch_intensity, 0.0, 1.0))
        self.instability = float(np.clip(instability, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._glitch_remaining = [0] * self.channels
        self._glitch_type = [_TYPE_FREEZE] * self.channels
        self._hold_value = [0.0] * self.channels
        self._walk_state = [0.0] * self.channels
        self._rng = np.random.default_rng(6502)
        self._glitch_activity = 0.0

    def reset(self) -> None:
        self._glitch_remaining = [0] * self.channels
        self._glitch_type = [_TYPE_FREEZE] * self.channels
        self._hold_value = [0.0] * self.channels
        self._walk_state = [0.0] * self.channels
        self._rng = np.random.default_rng(6502)
        self._glitch_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, glitch_rate_hz=None, glitch_intensity=None, instability=None, mix=None) -> None:
        if glitch_rate_hz is not None:
            self.glitch_rate_hz = float(max(0.0, glitch_rate_hz))
        if glitch_intensity is not None:
            self.glitch_intensity = float(np.clip(glitch_intensity, 0.0, 1.0))
        if instability is not None:
            self.instability = float(np.clip(instability, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            trigger_prob = self.glitch_rate_hz / self.sample_rate
            min_dur = int(0.005 * self.sample_rate)
            max_dur = int((0.02 + self.glitch_intensity * 0.15) * self.sample_rate)
            glitch_frames = []

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)
                trigger_rand = self._rng.random(n)
                type_rand = self._rng.random(n)
                dur_rand = self._rng.random(n)
                walk_rand = self._rng.random(n) - 0.5

                remaining = self._glitch_remaining[bch]
                gtype = self._glitch_type[bch]
                hold_value = self._hold_value[bch]
                walk = self._walk_state[bch]
                y = np.empty(n, dtype=np.float64)
                n_glitch_frames = 0

                for i in range(n):
                    xi = inp[i]
                    walk += 0.02 * walk_rand[i] - 0.01 * walk
                    walk = max(-1.0, min(1.0, walk))

                    if remaining <= 0 and trigger_rand[i] < trigger_prob:
                        remaining = min_dur + int(dur_rand[i] * max(1, max_dur - min_dur))
                        if type_rand[i] < 0.4:
                            gtype = _TYPE_FREEZE
                            hold_value = xi
                        elif type_rand[i] < 0.75:
                            gtype = _TYPE_BITCRUSH
                        else:
                            gtype = _TYPE_DROPOUT

                    if remaining > 0:
                        n_glitch_frames += 1
                        if gtype == _TYPE_FREEZE:
                            v = hold_value
                        elif gtype == _TYPE_BITCRUSH:
                            levels = 3.0 + (1.0 - self.glitch_intensity) * 12.0
                            v = np.round(xi * levels) / levels
                        else:
                            v = xi * 0.06
                        remaining -= 1
                    else:
                        v = xi * (1.0 + self.instability * walk * 0.4)

                    y[i] = v

                self._glitch_remaining[bch] = remaining
                self._glitch_type[bch] = gtype
                self._hold_value[bch] = hold_value
                self._walk_state[bch] = walk
                out[:, ch] = y
                glitch_frames.append(n_glitch_frames / float(n))

            self._glitch_activity = float(np.mean(glitch_frames)) if glitch_frames else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("CircuitBendingProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
