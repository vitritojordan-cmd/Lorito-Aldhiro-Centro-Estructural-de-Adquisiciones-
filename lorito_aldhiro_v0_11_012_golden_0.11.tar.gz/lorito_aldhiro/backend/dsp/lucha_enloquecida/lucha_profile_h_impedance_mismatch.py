# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI H — Desadaptación deliberada de impedancias (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_h_impedance_mismatch.py — LUCHALOCA LOFI H
════════════════════════════════════════════════════════════════════════════
Técnica base: Desadaptación deliberada de impedancias.

"Modelar una etapa de transferencia deliberadamente desadaptada.
Parámetros: impedancia virtual; carga; drive; clipping; densidad
armónica. El resultado buscado es una saturación áspera y densa
derivada de una carga eléctrica deliberadamente incorrecta."

Cadena real: una carga desadaptada no atenúa uniformemente — refuerza
una banda estrecha alrededor de una frecuencia de resonancia propia
del circuito de salida antes de saturar (efecto de "pico" eléctrico
real de una etapa mal terminada) → 1) realce resonante con
`BiquadDF2T` (`peaking`, ganancia y Q controlados por
`impedance_amount`/`load_resonance_hz`) → 2) recorte ASIMÉTRICO
(umbrales distintos para la excursión positiva/negativa — una carga
desadaptada real no recorta simétrico) → 3) mezcla de dureza
controlada por `density` (recorte duro vs. `tanh` blando).
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_h")

__all__ = ["ImpedanceMismatchProfile"]


class ImpedanceMismatchProfile(LuchaProfile):
    """LUCHALOCA LOFI H — Desadaptación de impedancias. Backend puro,
    sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 impedance_amount: float = 0.5, load_resonance_hz: float = 2200.0,
                 drive: float = 0.5, density: float = 0.5, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.impedance_amount = float(np.clip(impedance_amount, 0.0, 1.0))
        self.load_resonance_hz = float(np.clip(load_resonance_hz, 200.0, 12000.0))
        self.drive = float(np.clip(drive, 0.0, 1.0))
        self.density = float(np.clip(density, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._filters = [
            BiquadDF2T(freq_hz=self.load_resonance_hz, q=1.5,
                       gain_db=self.impedance_amount * 14.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._clip_activity = 0.0

    def reset(self) -> None:
        for f in self._filters:
            f.reset()
        self._clip_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, impedance_amount=None, load_resonance_hz=None,
                    drive=None, density=None, mix=None) -> None:
        changed_filter = False
        if impedance_amount is not None:
            self.impedance_amount = float(np.clip(impedance_amount, 0.0, 1.0))
            changed_filter = True
        if load_resonance_hz is not None:
            self.load_resonance_hz = float(np.clip(load_resonance_hz, 200.0, 12000.0))
            changed_filter = True
        if drive is not None:
            self.drive = float(np.clip(drive, 0.0, 1.0))
        if density is not None:
            self.density = float(np.clip(density, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if changed_filter:
            for f in self._filters:
                f.set_params(freq_hz=self.load_resonance_hz, gain_db=self.impedance_amount * 14.0)

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = np.empty_like(x, dtype=np.float64)

            drive_amt = 1.0 + self.drive * 8.0
            pos_threshold = 1.0 - self.impedance_amount * 0.25
            neg_threshold = 0.75 + self.impedance_amount * 0.15
            clip_energies = []
            for ch in range(n_ch):
                filt = self._filters[ch % self.channels]
                resonant = filt.process(x[:, ch].astype(np.float64)) * drive_amt

                soft = np.tanh(resonant)
                hard = np.clip(resonant, -neg_threshold, pos_threshold) / max(pos_threshold, 1e-6)
                shaped = (1.0 - self.density) * soft + self.density * hard

                out[:, ch] = shaped
                clip_energies.append(float(np.mean(np.abs(shaped) > 0.9)))

            self._clip_activity = float(np.mean(clip_energies)) if clip_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("ImpedanceMismatchProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
