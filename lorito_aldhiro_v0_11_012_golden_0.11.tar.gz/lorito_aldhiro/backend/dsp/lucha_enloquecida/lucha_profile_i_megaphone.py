# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI I — El efecto megáfono y bocinas de lata (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_i_megaphone.py — LUCHALOCA LOFI I
════════════════════════════════════════════════════════════════════════════
Técnica base: El efecto megáfono y bocinas de lata.

"Implementar una coloración de tipo megáfono: banda media dominante;
supresión de subgraves; reducción de extremos; resonancia de caja;
color plástico/metálico."

Cadena real: 1) banda media STATEFUL (HPF+LPF Butterworth en cascada,
ancho controlado por `band_amount`) para "banda media dominante" y
"supresión de subgraves"/"reducción de extremos" — 2) `BiquadDF2T`
peaking en la resonancia característica de una bocina de lata pequeña
(~1.2kHz) para "resonancia de caja" — 3) saturación asimétrica ligera
(`drive`) para el "color plástico/metálico" (una bocina de lata barata
distorsiona de forma desigual entre semiciclos por el propio diafragma
metálico deformado).
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_i")

__all__ = ["MegaphoneProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class MegaphoneProfile(LuchaProfile):
    """LUCHALOCA LOFI I — Megáfono/bocina de lata. Backend puro, sin
    Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 band_amount: float = 0.7, resonance_amount: float = 0.6,
                 drive: float = 0.4, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.band_amount = float(np.clip(band_amount, 0.0, 1.0))
        self.resonance_amount = float(np.clip(resonance_amount, 0.0, 1.0))
        self.drive = float(np.clip(drive, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._hp_b = self._hp_a = None
        self._lp_b = self._lp_a = None
        self._hp_zi: list = []
        self._lp_zi: list = []
        self._cabinet = [
            BiquadDF2T(freq_hz=1200.0, q=2.2, gain_db=self.resonance_amount * 11.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._distortion_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        hp_hz = 300.0 + self.band_amount * 250.0    # 300..550 Hz
        lp_hz = 6000.0 - self.band_amount * 2000.0  # 6000..4000 Hz
        wn_hp = float(np.clip(hp_hz / nyq, 1e-4, 0.97))
        wn_lp = float(np.clip(lp_hz / nyq, 1e-4, 0.97))
        self._hp_b, self._hp_a = butter(2, wn_hp, btype="high")
        self._lp_b, self._lp_a = butter(2, wn_lp, btype="low")
        self._hp_zi = [_zi_at_rest(self._hp_b, self._hp_a).copy() for _ in range(self.channels)]
        self._lp_zi = [_zi_at_rest(self._lp_b, self._lp_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        for c in self._cabinet:
            c.reset()
        self._distortion_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, band_amount=None, resonance_amount=None, drive=None, mix=None) -> None:
        rebuild = False
        if band_amount is not None:
            self.band_amount = float(np.clip(band_amount, 0.0, 1.0))
            rebuild = True
        if resonance_amount is not None:
            self.resonance_amount = float(np.clip(resonance_amount, 0.0, 1.0))
            for c in self._cabinet:
                c.set_params(gain_db=self.resonance_amount * 11.0)
        if drive is not None:
            self.drive = float(np.clip(drive, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if rebuild:
            self._rebuild_filters()

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._hp_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = np.empty_like(x, dtype=np.float64)
            dist_energies = []

            drive_amt = 1.0 + self.drive * 6.0
            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                banded, zf_hp = lfilter(self._hp_b, self._hp_a, inp, zi=self._hp_zi[bch])
                self._hp_zi[bch] = zf_hp
                banded, zf_lp = lfilter(self._lp_b, self._lp_a, banded, zi=self._lp_zi[bch])
                self._lp_zi[bch] = zf_lp

                resonant = self._cabinet[bch].process(banded)

                v = resonant * drive_amt
                shaped = np.where(v >= 0.0, np.tanh(v), np.tanh(v * 1.35) / 1.35)
                shaped /= max(1.0, drive_amt * 0.5)

                out[:, ch] = shaped
                dist_energies.append(float(np.mean(np.abs(shaped - resonant))))

            self._distortion_activity = float(np.mean(dist_energies)) if dist_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("MegaphoneProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
