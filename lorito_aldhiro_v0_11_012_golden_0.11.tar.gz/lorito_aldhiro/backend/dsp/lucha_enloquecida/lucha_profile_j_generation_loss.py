# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI J — Generación múltiple por copia sucesiva (Generation Loss) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_j_generation_loss.py — LUCHALOCA LOFI J
════════════════════════════════════════════════════════════════════════════
Técnica base: Generación múltiple por copia sucesiva (Generation Loss).

"Emular múltiples generaciones de copia de cassette. El usuario deberá
controlar: número virtual de generaciones; pérdida de altas
frecuencias; hiss; distorsión; degradación acumulativa."

Cadena real: una copia de cassette a cassette no es un filtro fijo —
es la MISMA cadena de pérdidas (paso-bajos + saturación leve + hiss)
aplicada N VECES en serie, una por generación. Se modela así, literal:
`generations` etapas encadenadas, cada una con su PROPIO filtro
STATEFUL (persistente entre bloques, nunca recalculado por bloque) y
su propio generador de hiss persistente — nunca un único filtro con
corte "N veces más agresivo" calculado de antemano, que perdería el
carácter de degradación ACUMULATIVA e independiente por generación que
pide la orden.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_j")

__all__ = ["GenerationLossProfile"]

_MAX_GENERATIONS = 20


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class _Stage:
    __slots__ = ("b", "a", "zi", "drive", "hiss_level", "rng")

    def __init__(self, cutoff_hz: float, sample_rate: int, drive: float,
                 hiss_level: float, seed: int) -> None:
        self.drive = drive
        self.hiss_level = hiss_level
        self.rng = np.random.default_rng(seed)
        if _SCIPY_OK:
            nyq = 0.5 * sample_rate
            wn = float(np.clip(cutoff_hz / nyq, 1e-4, 0.97))
            self.b, self.a = butter(2, wn, btype="low")
            self.zi = _zi_at_rest(self.b, self.a)
        else:
            self.b = self.a = None
            self.zi = None

    def process(self, x: np.ndarray) -> np.ndarray:
        y = x
        if self.b is not None:
            y, self.zi = lfilter(self.b, self.a, y, zi=self.zi)
        y = np.tanh(y * self.drive) / max(self.drive, 1.0)
        y = y + self.hiss_level * self.rng.standard_normal(y.shape[0])
        return y


class GenerationLossProfile(LuchaProfile):
    """LUCHALOCA LOFI J — Generation Loss. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 generations: int = 3, hf_loss_per_gen: float = 0.35,
                 hiss_per_gen: float = 0.0015, distortion_per_gen: float = 0.15,
                 mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.generations = int(np.clip(generations, 1, _MAX_GENERATIONS))
        self.hf_loss_per_gen = float(np.clip(hf_loss_per_gen, 0.0, 1.0))
        self.hiss_per_gen = float(max(0.0, hiss_per_gen))
        self.distortion_per_gen = float(np.clip(distortion_per_gen, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._stages: List[List[_Stage]] = [[] for _ in range(self.channels)]
        self._rebuild_stages()

    def _rebuild_stages(self) -> None:
        for ch in range(self.channels):
            stages = []
            for g in range(self.generations):
                # Cada generación pierde más agudos que la anterior —
                # decaimiento geométrico, nunca por debajo de 2 kHz
                # (§8: nunca degenerar en silencio total).
                cutoff = max(2000.0, 18000.0 * (1.0 - self.hf_loss_per_gen * 0.12) ** g)
                drive = 1.0 + self.distortion_per_gen * (g + 1) * 0.5
                hiss = self.hiss_per_gen * (g + 1)
                stages.append(_Stage(cutoff, self.sample_rate, drive, hiss, seed=1000 * ch + g))
            self._stages[ch] = stages

    def reset(self) -> None:
        self._rebuild_stages()
        self.status = ModuleStatus.ARMED

    def set_params(self, generations=None, hf_loss_per_gen=None, hiss_per_gen=None,
                    distortion_per_gen=None, mix=None) -> None:
        rebuild = False
        if generations is not None:
            new_gen = int(np.clip(generations, 1, _MAX_GENERATIONS))
            if new_gen != self.generations:
                self.generations = new_gen
                rebuild = True
        if hf_loss_per_gen is not None:
            self.hf_loss_per_gen = float(np.clip(hf_loss_per_gen, 0.0, 1.0))
            rebuild = True
        if hiss_per_gen is not None:
            self.hiss_per_gen = float(max(0.0, hiss_per_gen))
            rebuild = True
        if distortion_per_gen is not None:
            self.distortion_per_gen = float(np.clip(distortion_per_gen, 0.0, 1.0))
            rebuild = True
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if rebuild:
            self._rebuild_stages()

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = x.astype(np.float64).copy()

            for ch in range(n_ch):
                y = x[:, ch].astype(np.float64)
                stages = self._stages[ch % self.channels]
                for stage in stages:
                    y = stage.process(y)
                out[:, ch] = x[:, ch].astype(np.float64) * (1.0 - self.mix) + y * self.mix

            np.clip(out, -1.0, 1.0, out=out)
            self.status = ModuleStatus.PROCESSING
            return out[:, 0] if mono_in else out.astype(block.dtype)
        except Exception:
            _log.exception("GenerationLossProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
