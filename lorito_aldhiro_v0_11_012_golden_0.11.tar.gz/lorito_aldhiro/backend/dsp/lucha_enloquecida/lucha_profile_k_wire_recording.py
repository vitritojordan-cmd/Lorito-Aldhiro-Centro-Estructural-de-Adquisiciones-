# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI K — Grabación con alambre magnético (Wire Recording) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_k_wire_recording.py — LUCHALOCA LOFI K
════════════════════════════════════════════════════════════════════════════
Técnica base: Grabación con alambre magnético (Wire Recording).

"Simular la coloración de grabación mediante alambre magnético: graves
reducidos; medios/agudos dominantes; aspereza; textura metálica; ruido
de fondo."

Cadena real: 1) paso-altos STATEFUL (Butterworth, corte controlado por
`bass_reduction`) para "graves reducidos" — 2) `BiquadDF2T` peaking
en medios-agudos (~2.8kHz) para "medios/agudos dominantes" — 3)
saturación asimétrica aplicada SOLO sobre la banda ya realzada (nunca
sobre la señal completa — el alambre de acero satura de forma
desigual y concentrada en agudos, nunca uniforme) para "aspereza"/
"textura metálica" — 4) ruido de fondo persistente, filtrado en banda
media-alta (el "silbido" característico del alambre, nunca ruido
blanco plano).
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_k")

__all__ = ["WireRecordingProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class WireRecordingProfile(LuchaProfile):
    """LUCHALOCA LOFI K — Grabación con alambre magnético. Backend
    puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 bass_reduction: float = 0.6, roughness: float = 0.4,
                 noise_level: float = 0.03, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.bass_reduction = float(np.clip(bass_reduction, 0.0, 1.0))
        self.roughness = float(np.clip(roughness, 0.0, 1.0))
        self.noise_level = float(np.clip(noise_level, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._hp_b = self._hp_a = None
        self._hp_zi: list = []
        self._noise_hp_b = self._noise_hp_a = None
        self._noise_hp_zi: list = []
        self._emphasis = [
            BiquadDF2T(freq_hz=2800.0, q=1.1, gain_db=8.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._rng = np.random.default_rng(1877)
        self._roughness_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        hp_hz = 150.0 + self.bass_reduction * 500.0  # 150..650 Hz
        wn_hp = float(np.clip(hp_hz / nyq, 1e-4, 0.97))
        self._hp_b, self._hp_a = butter(2, wn_hp, btype="high")
        self._hp_zi = [_zi_at_rest(self._hp_b, self._hp_a).copy() for _ in range(self.channels)]
        self._noise_hp_b, self._noise_hp_a = butter(2, float(np.clip(1800.0 / nyq, 1e-4, 0.97)), btype="high")
        self._noise_hp_zi = [_zi_at_rest(self._noise_hp_b, self._noise_hp_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        for e in self._emphasis:
            e.reset()
        self._rng = np.random.default_rng(1877)
        self._roughness_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, bass_reduction=None, roughness=None, noise_level=None, mix=None) -> None:
        rebuild = False
        if bass_reduction is not None:
            self.bass_reduction = float(np.clip(bass_reduction, 0.0, 1.0))
            rebuild = True
        if roughness is not None:
            self.roughness = float(np.clip(roughness, 0.0, 1.0))
        if noise_level is not None:
            self.noise_level = float(np.clip(noise_level, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))
        if rebuild:
            self._rebuild_filters()

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._hp_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            rough_energies = []

            drive = 1.0 + self.roughness * 5.0
            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                thin, zf_hp = lfilter(self._hp_b, self._hp_a, inp, zi=self._hp_zi[bch])
                self._hp_zi[bch] = zf_hp

                emphasized = self._emphasis[bch].process(thin)

                # Saturación asimétrica SOLO sobre la parte realzada
                # (la banda que el alambre distorsiona de verdad).
                v = emphasized * drive
                rough = np.where(v >= 0.0, np.tanh(v), 0.7 * np.tanh(v * 1.6))
                rough /= max(1.0, drive * 0.6)
                textured = thin + rough * self.roughness

                noise = self.noise_level * 0.25 * self._rng.standard_normal(n)
                noise, zf_n = lfilter(self._noise_hp_b, self._noise_hp_a, noise, zi=self._noise_hp_zi[bch])
                self._noise_hp_zi[bch] = zf_n

                result = textured + noise
                out[:, ch] = result
                rough_energies.append(float(np.mean(np.abs(rough))))

            self._roughness_activity = float(np.mean(rough_energies)) if rough_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("WireRecordingProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
