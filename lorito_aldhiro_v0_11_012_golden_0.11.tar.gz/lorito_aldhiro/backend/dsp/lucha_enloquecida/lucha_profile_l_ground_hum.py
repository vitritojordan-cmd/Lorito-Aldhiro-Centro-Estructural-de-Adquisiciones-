# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI L — Inyección de zumbido de red eléctrica (Ground Hum) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_l_ground_hum.py — LUCHALOCA LOFI L
════════════════════════════════════════════════════════════════════════════
Técnica base: Inyección de zumbido de red eléctrica (Ground Hum
Induction).

"Generar una componente de zumbido de red controlable e integrada con
la señal. Controles: frecuencia; nivel; profundidad; modulación;
contaminación armónica. Deberá contemplar 50/60 Hz como modos
seleccionables."

Oscilador de fase acumulada PERSISTENTE entre bloques (nunca
`np.sin(2*pi*f*t)` recalculado desde t=0 en cada bloque — eso
produciría un salto de fase audible en cada frontera, la misma clase
de defecto que la orden prohíbe en §8 para cambios de parámetro).
Serie armónica (fundamental + 2º + 3er armónico, pesos decrecientes,
mezcla controlada por `harmonic_contamination`) con una modulación de
amplitud lenta propia (`depth`) para que el zumbido no suene
perfectamente estático — el defecto real de un zumbido de red
inducido por acoplamiento imperfecto, no una onda de laboratorio.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_l")

__all__ = ["GroundHumProfile"]


class GroundHumProfile(LuchaProfile):
    """LUCHALOCA LOFI L — Ground Hum Induction. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 frequency_mode: str = "60", level: float = 0.08,
                 depth: float = 0.25, harmonic_contamination: float = 0.4,
                 mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.frequency_mode = "50" if str(frequency_mode) == "50" else "60"
        self.level = float(np.clip(level, 0.0, 1.0))
        self.depth = float(np.clip(depth, 0.0, 1.0))
        self.harmonic_contamination = float(np.clip(harmonic_contamination, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._phase = 0.0          # fase acumulada del fundamental, en radianes
        self._mod_phase = 0.0      # fase acumulada de la modulación lenta de nivel
        self._hum_activity = 0.0

    def reset(self) -> None:
        self._phase = 0.0
        self._mod_phase = 0.0
        self._hum_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, frequency_mode=None, level=None, depth=None,
                    harmonic_contamination=None, mix=None) -> None:
        if frequency_mode is not None:
            self.frequency_mode = "50" if str(frequency_mode) == "50" else "60"
        if level is not None:
            self.level = float(np.clip(level, 0.0, 1.0))
        if depth is not None:
            self.depth = float(np.clip(depth, 0.0, 1.0))
        if harmonic_contamination is not None:
            self.harmonic_contamination = float(np.clip(harmonic_contamination, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n = x.shape[0]

            f0 = 50.0 if self.frequency_mode == "50" else 60.0
            w0 = 2.0 * np.pi * f0 / self.sample_rate
            w_mod = 2.0 * np.pi * 0.3 / self.sample_rate  # modulación lenta, ~0.3 Hz

            idx = np.arange(n)
            phase = self._phase + w0 * idx
            mod_phase = self._mod_phase + w_mod * idx

            fundamental = np.sin(phase)
            second = self.harmonic_contamination * 0.35 * np.sin(2.0 * phase)
            third = self.harmonic_contamination * 0.18 * np.sin(3.0 * phase)
            hum = fundamental + second + third

            amp_mod = 1.0 + self.depth * 0.3 * np.sin(mod_phase)
            hum = hum * amp_mod * self.level * 0.2

            self._phase = float((phase[-1] + w0) % (2.0 * np.pi))
            self._mod_phase = float((mod_phase[-1] + w_mod) % (2.0 * np.pi))
            self._hum_activity = float(np.sqrt(np.mean(np.square(hum)) + 1e-12))

            hum_col = hum[:, np.newaxis]
            wet = x.astype(np.float64) + hum_col * self.mix
            np.clip(wet, -1.0, 1.0, out=wet)
            self.status = ModuleStatus.PROCESSING
            return wet[:, 0] if mono_in else wet.astype(block.dtype)
        except Exception:
            _log.exception("GroundHumProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
