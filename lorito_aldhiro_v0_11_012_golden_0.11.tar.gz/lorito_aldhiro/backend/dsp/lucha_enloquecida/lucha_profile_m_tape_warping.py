# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI M — Manipulación manual del cabrestante (Tape Warping) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_m_tape_warping.py — LUCHALOCA LOFI M
════════════════════════════════════════════════════════════════════════════
Técnica base: Manipulación manual del cabrestante y rodillo (Tape
Warping).

"Simular alteraciones de velocidad y tono equivalentes a manipulación
del capstan/pinch roller. Deberá incorporar: wow; flutter; desviación
de velocidad; profundidad; irregularidad; comportamiento temporal no
perfectamente periódico."

Línea de retardo circular con lectura de posición FRACCIONARIA
(interpolación lineal), modulada por dos osciladores de fase
acumulada PERSISTENTE (wow ≈1.2 Hz, flutter ≈11 Hz — rangos físicos
reales de wow/flutter de cabrestante) más dos senoides lentas
adicionales de frecuencia incommensurable (`irregularity`) que rompen
la periodicidad estricta — "comportamiento temporal no perfectamente
periódico" sin recurrir a ruido no determinista dentro del kernel de
audio. Kernel muestra-a-muestra (patrón `@njit`-con-fallback), porque
la posición de lectura varía de forma continua dentro del bloque.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from numba import njit as _njit
    _HAVE_NUMBA = True
except Exception:  # pragma: no cover - entorno sin numba disponible
    _HAVE_NUMBA = False
    _njit = None

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_m")

__all__ = ["TapeWarpingProfile"]


def _warp_kernel(in_ch: np.ndarray, buf: np.ndarray, write_pos: int,
                  wow_phase: float, flutter_phase: float, irr_phase_a: float,
                  irr_phase_b: float, sample_rate: float, base_delay: float,
                  wow_depth: float, flutter_depth: float, irr_depth: float,
                  w_wow: float, w_flutter: float, w_irr_a: float, w_irr_b: float) -> "tuple":
    n = in_ch.shape[0]
    buf_len = buf.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        buf[write_pos] = in_ch[i]

        delay = (base_delay
                 + wow_depth * np.sin(wow_phase)
                 + flutter_depth * np.sin(flutter_phase)
                 + irr_depth * 0.6 * np.sin(irr_phase_a)
                 + irr_depth * 0.4 * np.sin(irr_phase_b))
        if delay < 1.0:
            delay = 1.0
        elif delay > buf_len - 2.0:
            delay = buf_len - 2.0

        read_pos_f = write_pos - delay
        while read_pos_f < 0.0:
            read_pos_f += buf_len
        i0 = int(read_pos_f)
        frac = read_pos_f - i0
        i1 = i0 + 1
        if i1 >= buf_len:
            i1 = 0
        out[i] = buf[i0] * (1.0 - frac) + buf[i1] * frac

        write_pos += 1
        if write_pos >= buf_len:
            write_pos = 0
        wow_phase += w_wow
        flutter_phase += w_flutter
        irr_phase_a += w_irr_a
        irr_phase_b += w_irr_b

    two_pi = 6.283185307179586
    wow_phase = wow_phase % two_pi
    flutter_phase = flutter_phase % two_pi
    irr_phase_a = irr_phase_a % two_pi
    irr_phase_b = irr_phase_b % two_pi
    return out, write_pos, wow_phase, flutter_phase, irr_phase_a, irr_phase_b


if _HAVE_NUMBA:
    _warp_kernel = _njit(cache=True)(_warp_kernel)


class TapeWarpingProfile(LuchaProfile):
    """LUCHALOCA LOFI M — Tape Warping (wow & flutter). Backend puro,
    sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 wow_depth: float = 0.4, flutter_depth: float = 0.35,
                 irregularity: float = 0.3, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.wow_depth = float(np.clip(wow_depth, 0.0, 1.0))
        self.flutter_depth = float(np.clip(flutter_depth, 0.0, 1.0))
        self.irregularity = float(np.clip(irregularity, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._base_delay_ms = 12.0
        self._buf_len = max(64, int((self._base_delay_ms + 10.0) * 1e-3 * self.sample_rate))
        self._bufs = [np.zeros(self._buf_len, dtype=np.float64) for _ in range(self.channels)]
        self._write_pos = [0] * self.channels
        self._wow_phase = [0.0] * self.channels
        self._flutter_phase = [0.0] * self.channels
        self._irr_a = [0.0] * self.channels
        self._irr_b = [0.31] * self.channels  # desfasado del A a propósito
        self._warp_activity = 0.0

    def reset(self) -> None:
        for ch in range(self.channels):
            self._bufs[ch][:] = 0.0
            self._write_pos[ch] = 0
            self._wow_phase[ch] = 0.0
            self._flutter_phase[ch] = 0.0
            self._irr_a[ch] = 0.0
            self._irr_b[ch] = 0.31
        self._warp_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, wow_depth=None, flutter_depth=None, irregularity=None, mix=None) -> None:
        if wow_depth is not None:
            self.wow_depth = float(np.clip(wow_depth, 0.0, 1.0))
        if flutter_depth is not None:
            self.flutter_depth = float(np.clip(flutter_depth, 0.0, 1.0))
        if irregularity is not None:
            self.irregularity = float(np.clip(irregularity, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = np.empty_like(x, dtype=np.float64)

            sr = float(self.sample_rate)
            base_delay = self._base_delay_ms * 1e-3 * sr
            wow_depth_s = self.wow_depth * 0.003 * sr     # hasta ~3 ms
            flutter_depth_s = self.flutter_depth * 0.001 * sr  # hasta ~1 ms
            irr_depth_s = self.irregularity * 0.0015 * sr      # hasta ~1.5 ms
            w_wow = 2.0 * np.pi * 1.2 / sr
            w_flutter = 2.0 * np.pi * 11.0 / sr
            w_irr_a = 2.0 * np.pi * 0.19 / sr
            w_irr_b = 2.0 * np.pi * 0.083 / sr

            activities = []
            for ch in range(n_ch):
                bch = ch % self.channels
                res = _warp_kernel(
                    x[:, ch].astype(np.float64), self._bufs[bch], self._write_pos[bch],
                    self._wow_phase[bch], self._flutter_phase[bch],
                    self._irr_a[bch], self._irr_b[bch], sr, base_delay,
                    wow_depth_s, flutter_depth_s, irr_depth_s,
                    w_wow, w_flutter, w_irr_a, w_irr_b,
                )
                (out_ch, self._write_pos[bch], self._wow_phase[bch], self._flutter_phase[bch],
                 self._irr_a[bch], self._irr_b[bch]) = res
                out[:, ch] = out_ch
                activities.append(float(np.mean(np.abs(out_ch - x[:, ch]))))

            self._warp_activity = float(np.mean(activities)) if activities else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("TapeWarpingProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
