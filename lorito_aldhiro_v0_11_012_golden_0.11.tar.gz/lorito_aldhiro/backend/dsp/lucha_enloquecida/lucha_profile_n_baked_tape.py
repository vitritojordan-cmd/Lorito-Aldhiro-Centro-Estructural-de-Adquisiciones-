# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI N — Método de la "cinta horneada" y estrés térmico (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_n_baked_tape.py — LUCHALOCA LOFI N
════════════════════════════════════════════════════════════════════════════
Técnica base: Método de la "cinta horneada" y estrés térmico.

"Emular la inestabilidad de una cinta sometida a estrés térmico. El
DSP deberá poder producir: dropouts; pérdida intermitente de agudos;
microinestabilidades; interrupciones; fragilidad temporal."

Cadena real, tres procesos estocásticos INDEPENDIENTES y persistentes
(cada uno con su propio disparador y duración, nunca sincronizados
entre sí — una cinta horneada falla de forma errática, no coordinada):

  · DROPOUTS/INTERRUPCIONES — un "objetivo" de ganancia (1.0 normal,
    cae a un piso bajo durante el evento) seguido por un suavizador de
    un polo PERSISTENTE — nunca un corte instantáneo (eso sería un
    clic, no una "fragilidad" real).
  · PÉRDIDA INTERMITENTE DE AGUDOS — un paso-bajos de un polo cuya
    frecuencia de corte objetivo cae temporalmente durante el evento y
    se recupera gradualmente — parches de la cinta que perdieron
    retención de agudos por el calor.
  · MICROINESTABILIDADES — paseo aleatorio suavizado, persistente,
    aplicado como jitter de amplitud sutil y continuo (nunca solo
    durante los eventos de dropout/HF).
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_n")

__all__ = ["BakedTapeProfile"]

_BASE_CUTOFF_HZ = 16000.0


class BakedTapeProfile(LuchaProfile):
    """LUCHALOCA LOFI N — Cinta horneada / estrés térmico. Backend
    puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 dropout_rate_hz: float = 0.7, dropout_severity: float = 0.6,
                 hf_instability_rate_hz: float = 0.4, microinstability: float = 0.3,
                 mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.dropout_rate_hz = float(max(0.0, dropout_rate_hz))
        self.dropout_severity = float(np.clip(dropout_severity, 0.0, 1.0))
        self.hf_instability_rate_hz = float(max(0.0, hf_instability_rate_hz))
        self.microinstability = float(np.clip(microinstability, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._dropout_gain = [1.0] * self.channels
        self._dropout_remaining = [0] * self.channels
        self._cutoff_state = [_BASE_CUTOFF_HZ] * self.channels
        self._hf_remaining = [0] * self.channels
        self._lpf_state = [0.0] * self.channels
        self._micro_walk = [0.0] * self.channels
        self._rng = np.random.default_rng(2626)
        self._dropout_activity = 0.0
        self._hf_loss_activity = 0.0

    def reset(self) -> None:
        self._dropout_gain = [1.0] * self.channels
        self._dropout_remaining = [0] * self.channels
        self._cutoff_state = [_BASE_CUTOFF_HZ] * self.channels
        self._hf_remaining = [0] * self.channels
        self._lpf_state = [0.0] * self.channels
        self._micro_walk = [0.0] * self.channels
        self._rng = np.random.default_rng(2626)
        self._dropout_activity = 0.0
        self._hf_loss_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, dropout_rate_hz=None, dropout_severity=None,
                    hf_instability_rate_hz=None, microinstability=None, mix=None) -> None:
        if dropout_rate_hz is not None:
            self.dropout_rate_hz = float(max(0.0, dropout_rate_hz))
        if dropout_severity is not None:
            self.dropout_severity = float(np.clip(dropout_severity, 0.0, 1.0))
        if hf_instability_rate_hz is not None:
            self.hf_instability_rate_hz = float(max(0.0, hf_instability_rate_hz))
        if microinstability is not None:
            self.microinstability = float(np.clip(microinstability, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)

            dropout_prob = self.dropout_rate_hz / self.sample_rate
            hf_prob = self.hf_instability_rate_hz / self.sample_rate
            dropout_floor = 1.0 - self.dropout_severity * 0.95
            low_cutoff = 6000.0 - self.dropout_severity * 4500.0  # nunca menos de 1500Hz aprox
            dropout_activities = []
            hf_activities = []

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)
                trig_drop = self._rng.random(n)
                dur_drop = self._rng.random(n)
                trig_hf = self._rng.random(n)
                dur_hf = self._rng.random(n)
                walk_rand = self._rng.random(n) - 0.5

                dgain = self._dropout_gain[bch]
                drem = self._dropout_remaining[bch]
                cutoff = self._cutoff_state[bch]
                hfrem = self._hf_remaining[bch]
                lpf_y = self._lpf_state[bch]
                walk = self._micro_walk[bch]

                y = np.empty(n, dtype=np.float64)
                n_drop_active = 0
                n_hf_active = 0

                for i in range(n):
                    # Dropout — objetivo de ganancia + suavizador.
                    if drem <= 0 and trig_drop[i] < dropout_prob:
                        drem = int(0.01 * self.sample_rate + dur_drop[i] * 0.08 * self.sample_rate)
                    target_gain = dropout_floor if drem > 0 else 1.0
                    if drem > 0:
                        drem -= 1
                        n_drop_active += 1
                    dgain += 0.02 * (target_gain - dgain)

                    # Pérdida intermitente de agudos — corte objetivo
                    # + paso-bajos de un polo con corte variable.
                    if hfrem <= 0 and trig_hf[i] < hf_prob:
                        hfrem = int(0.05 * self.sample_rate + dur_hf[i] * 0.3 * self.sample_rate)
                    target_cutoff = low_cutoff if hfrem > 0 else _BASE_CUTOFF_HZ
                    if hfrem > 0:
                        hfrem -= 1
                        n_hf_active += 1
                    cutoff += 0.01 * (target_cutoff - cutoff)
                    alpha = 1.0 - np.exp(-2.0 * np.pi * cutoff / self.sample_rate)
                    lpf_y += alpha * (inp[i] - lpf_y)

                    # Microinestabilidades — paseo aleatorio suavizado.
                    walk += 0.015 * walk_rand[i] - 0.008 * walk
                    walk = max(-1.0, min(1.0, walk))

                    y[i] = lpf_y * dgain * (1.0 + self.microinstability * walk * 0.05)

                self._dropout_gain[bch] = dgain
                self._dropout_remaining[bch] = drem
                self._cutoff_state[bch] = cutoff
                self._hf_remaining[bch] = hfrem
                self._lpf_state[bch] = lpf_y
                self._micro_walk[bch] = walk

                out[:, ch] = y
                dropout_activities.append(n_drop_active / float(n))
                hf_activities.append(n_hf_active / float(n))

            self._dropout_activity = float(np.mean(dropout_activities)) if dropout_activities else 0.0
            self._hf_loss_activity = float(np.mean(hf_activities)) if hf_activities else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("BakedTapeProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
