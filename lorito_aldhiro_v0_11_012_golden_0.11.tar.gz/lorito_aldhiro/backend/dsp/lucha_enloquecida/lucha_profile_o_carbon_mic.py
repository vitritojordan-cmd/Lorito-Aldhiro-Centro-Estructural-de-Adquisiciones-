# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI O — Micrófonos de carbón telefónicos (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_o_carbon_mic.py — LUCHALOCA LOFI O
════════════════════════════════════════════════════════════════════════════
Técnica base: Micrófonos de carbón telefónicos.

"Construir una simulación de transductor de carbón caracterizada por:
banda limitada; fuerte no linealidad; distorsión; crujido; perfil
nasal. Ancho de banda aproximado de 300 Hz–3,4 kHz, respuesta
altamente no lineal."

Cadena real: 1) banda telefónica STATEFUL (HPF 300Hz + LPF 3.4kHz,
fijos — la propia orden da la cifra exacta, no un parámetro) — 2)
recorte fuertemente no lineal (umbral bajo, rodilla dura) para la
"fuerte no linealidad"/"distorsión" — 3) CRUJIDO real: ruido
persistente cuyo NIVEL sigue la envolvente de entrada (los gránulos de
carbón crepitan más bajo mayor corriente/señal — nunca un ruido de
fondo constante) — 4) perfil nasal: `BiquadDF2T` boost ~1.3kHz + corte
~500Hz.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_o")

__all__ = ["CarbonMicProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class CarbonMicProfile(LuchaProfile):
    """LUCHALOCA LOFI O — Micrófono de carbón telefónico. Backend
    puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 distortion_amount: float = 0.6, crackle_amount: float = 0.4,
                 nasal_amount: float = 0.6, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.distortion_amount = float(np.clip(distortion_amount, 0.0, 1.0))
        self.crackle_amount = float(np.clip(crackle_amount, 0.0, 1.0))
        self.nasal_amount = float(np.clip(nasal_amount, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._hp_b = self._hp_a = None
        self._lp_b = self._lp_a = None
        self._hp_zi: list = []
        self._lp_zi: list = []
        self._nasal_boost = [
            BiquadDF2T(freq_hz=1300.0, q=1.4, gain_db=self.nasal_amount * 8.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._nasal_cut = [
            BiquadDF2T(freq_hz=500.0, q=1.2, gain_db=-self.nasal_amount * 7.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._env = [0.0] * self.channels
        self._rng = np.random.default_rng(3105)
        self._crackle_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        self._hp_b, self._hp_a = butter(2, float(np.clip(300.0 / nyq, 1e-4, 0.97)), btype="high")
        self._lp_b, self._lp_a = butter(2, float(np.clip(3400.0 / nyq, 1e-4, 0.97)), btype="low")
        self._hp_zi = [_zi_at_rest(self._hp_b, self._hp_a).copy() for _ in range(self.channels)]
        self._lp_zi = [_zi_at_rest(self._lp_b, self._lp_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        for b in self._nasal_boost:
            b.reset()
        for c in self._nasal_cut:
            c.reset()
        self._env = [0.0] * self.channels
        self._rng = np.random.default_rng(3105)
        self._crackle_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, distortion_amount=None, crackle_amount=None, nasal_amount=None, mix=None) -> None:
        if distortion_amount is not None:
            self.distortion_amount = float(np.clip(distortion_amount, 0.0, 1.0))
        if crackle_amount is not None:
            self.crackle_amount = float(np.clip(crackle_amount, 0.0, 1.0))
        if nasal_amount is not None:
            self.nasal_amount = float(np.clip(nasal_amount, 0.0, 1.0))
            for b in self._nasal_boost:
                b.set_params(gain_db=self.nasal_amount * 8.0)
            for c in self._nasal_cut:
                c.set_params(gain_db=-self.nasal_amount * 7.0)
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._hp_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            crackle_energies = []

            threshold = 1.0 - self.distortion_amount * 0.75
            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                banded, zf_hp = lfilter(self._hp_b, self._hp_a, inp, zi=self._hp_zi[bch])
                self._hp_zi[bch] = zf_hp
                banded, zf_lp = lfilter(self._lp_b, self._lp_a, banded, zi=self._lp_zi[bch])
                self._lp_zi[bch] = zf_lp

                clipped = np.clip(banded, -threshold, threshold) / max(threshold, 1e-6)

                nasal = self._nasal_boost[bch].process(clipped)
                nasal = self._nasal_cut[bch].process(nasal)

                env = self._env[bch]
                crackle = np.empty(n, dtype=np.float64)
                noise = self._rng.standard_normal(n)
                for i in range(n):
                    level = abs(banded[i])
                    env = env + (0.3 if level > env else 0.02) * (level - env)
                    crackle[i] = noise[i] * env * self.crackle_amount * 0.6
                self._env[bch] = env

                result = nasal + crackle
                out[:, ch] = result
                crackle_energies.append(float(np.sqrt(np.mean(np.square(crackle)) + 1e-12)))

            self._crackle_activity = float(np.mean(crackle_energies)) if crackle_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("CarbonMicProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
