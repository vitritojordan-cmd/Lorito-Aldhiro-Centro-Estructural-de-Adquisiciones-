# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI P — Micrófonos piezoeléctricos de contacto caseros (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_p_piezo_contact.py — LUCHALOCA LOFI P
════════════════════════════════════════════════════════════════════════════
Técnica base: Micrófonos piezoeléctricos de contacto caseros.

"Simular la captación de vibraciones mecánicas mediante un
piezoeléctrico de contacto. Debe incorporar: resonancia; sensibilidad
a transitorios; énfasis de medios-agudos; saturación; color metálico."

Cadena real: 1) paso-altos STATEFUL (los discos piezo captan mal
graves — respuesta mecánica pobre por debajo de ~180Hz) — 2)
`BiquadDF2T` peaking de alto Q en la resonancia mecánica característica
del disco (~3.8kHz) para "resonancia"/"énfasis de medios-agudos" — 3)
realce de transitorios: se suma una versión escalada de la DERIVADA
discreta de la señal (diferencia entre muestras consecutivas, con
estado persistente de la última muestra) — un piezo de contacto es
literalmente un sensor de velocidad/aceleración mecánica, mucho más
sensible al ATAQUE que a la sustain — 4) saturación semidura para el
"color metálico".
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_p")

__all__ = ["PiezoContactProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class PiezoContactProfile(LuchaProfile):
    """LUCHALOCA LOFI P — Piezo de contacto. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 resonance_amount: float = 0.6, transient_emphasis: float = 0.5,
                 saturation: float = 0.4, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.resonance_amount = float(np.clip(resonance_amount, 0.0, 1.0))
        self.transient_emphasis = float(np.clip(transient_emphasis, 0.0, 1.0))
        self.saturation = float(np.clip(saturation, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._hp_b = self._hp_a = None
        self._hp_zi: list = []
        self._resonance = [
            BiquadDF2T(freq_hz=3800.0, q=6.0, gain_db=self.resonance_amount * 12.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._prev_sample = [0.0] * self.channels
        self._transient_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        self._hp_b, self._hp_a = butter(2, float(np.clip(180.0 / nyq, 1e-4, 0.97)), btype="high")
        self._hp_zi = [_zi_at_rest(self._hp_b, self._hp_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        for r in self._resonance:
            r.reset()
        self._prev_sample = [0.0] * self.channels
        self._transient_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, resonance_amount=None, transient_emphasis=None, saturation=None, mix=None) -> None:
        if resonance_amount is not None:
            self.resonance_amount = float(np.clip(resonance_amount, 0.0, 1.0))
            for r in self._resonance:
                r.set_params(gain_db=self.resonance_amount * 12.0)
        if transient_emphasis is not None:
            self.transient_emphasis = float(np.clip(transient_emphasis, 0.0, 1.0))
        if saturation is not None:
            self.saturation = float(np.clip(saturation, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._hp_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = np.empty_like(x, dtype=np.float64)
            transient_energies = []

            drive = 1.0 + self.saturation * 5.0
            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                thin, zf_hp = lfilter(self._hp_b, self._hp_a, inp, zi=self._hp_zi[bch])
                self._hp_zi[bch] = zf_hp

                resonant = self._resonance[bch].process(thin)

                # Derivada discreta con estado persistente (§ — nunca
                # asumir muestra anterior = 0 en la frontera de bloque).
                shifted = np.empty_like(thin)
                shifted[0] = self._prev_sample[bch]
                shifted[1:] = thin[:-1]
                derivative = thin - shifted
                self._prev_sample[bch] = thin[-1]

                emphasized = resonant + derivative * self.transient_emphasis * 3.0

                v = emphasized * drive
                shaped = np.tanh(v) / max(1.0, drive * 0.5)

                out[:, ch] = shaped
                transient_energies.append(float(np.sqrt(np.mean(np.square(derivative)) + 1e-12)))

            self._transient_activity = float(np.mean(transient_energies)) if transient_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("PiezoContactProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
