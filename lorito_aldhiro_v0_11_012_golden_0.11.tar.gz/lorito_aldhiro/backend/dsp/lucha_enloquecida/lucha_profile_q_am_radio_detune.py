# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI Q — Modulación de frecuencia con radios AM detunadas (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_q_am_radio_detune.py — LUCHALOCA LOFI Q
════════════════════════════════════════════════════════════════════════════
Técnica base: Modulación de frecuencia con radios AM detunadas.

"Implementar una contaminación de radiofrecuencia/control de estática
inspirada en receptores AM fuera de sintonía. Controles: cantidad de
estática; modulación; densidad; frecuencia; interacción señal/ruido."

Cadena real: 1) banda AM STATEFUL (HPF+LPF, ~150Hz–5kHz) — 2)
ESTÁTICA con "interacción señal/ruido" real: nivel de ruido
INVERSAMENTE proporcional a la envolvente de la señal (efecto de
captura de AM — una portadora fuerte enmascara la estática, una débil
la deja pasar), nunca un piso de ruido fijo — 3) ráfagas de
interferencia (RFI) — proceso estocástico persistente de eventos
cortos de estática más intensa, controlado por `density` — 4)
"modulación"/"frecuencia": oscilador heterodino de fase acumulada
PERSISTENTE cuya frecuencia central deriva lentamente (LFO de fase
propia) alrededor de `tuning_offset_hz` — el "pitido" de batido real
de una sintonía imperfecta.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_q")

__all__ = ["AmRadioDetuneProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class AmRadioDetuneProfile(LuchaProfile):
    """LUCHALOCA LOFI Q — Radio AM detunada. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 static_amount: float = 0.35, density: float = 0.3,
                 tuning_offset_hz: float = 12.0, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.static_amount = float(np.clip(static_amount, 0.0, 1.0))
        self.density = float(np.clip(density, 0.0, 1.0))
        self.tuning_offset_hz = float(np.clip(tuning_offset_hz, 1.0, 60.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._hp_b = self._hp_a = None
        self._lp_b = self._lp_a = None
        self._hp_zi: list = []
        self._lp_zi: list = []
        self._env = [0.0] * self.channels
        self._het_phase = [0.0] * self.channels
        self._drift_phase = [0.0] * self.channels
        self._rfi_env = [0.0] * self.channels
        self._rng = np.random.default_rng(1490)
        self._static_activity = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        self._hp_b, self._hp_a = butter(2, float(np.clip(150.0 / nyq, 1e-4, 0.97)), btype="high")
        self._lp_b, self._lp_a = butter(2, float(np.clip(5000.0 / nyq, 1e-4, 0.97)), btype="low")
        self._hp_zi = [_zi_at_rest(self._hp_b, self._hp_a).copy() for _ in range(self.channels)]
        self._lp_zi = [_zi_at_rest(self._lp_b, self._lp_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        self._env = [0.0] * self.channels
        self._het_phase = [0.0] * self.channels
        self._drift_phase = [0.0] * self.channels
        self._rfi_env = [0.0] * self.channels
        self._rng = np.random.default_rng(1490)
        self._static_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, static_amount=None, density=None, tuning_offset_hz=None, mix=None) -> None:
        if static_amount is not None:
            self.static_amount = float(np.clip(static_amount, 0.0, 1.0))
        if density is not None:
            self.density = float(np.clip(density, 0.0, 1.0))
        if tuning_offset_hz is not None:
            self.tuning_offset_hz = float(np.clip(tuning_offset_hz, 1.0, 60.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._hp_b is None:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            static_energies = []

            w_het_base = 2.0 * np.pi * self.tuning_offset_hz / self.sample_rate
            w_drift = 2.0 * np.pi * 0.07 / self.sample_rate
            rfi_prob = self.density * 4.0 / self.sample_rate

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)

                banded, zf_hp = lfilter(self._hp_b, self._hp_a, inp, zi=self._hp_zi[bch])
                self._hp_zi[bch] = zf_hp
                banded, zf_lp = lfilter(self._lp_b, self._lp_a, banded, zi=self._lp_zi[bch])
                self._lp_zi[bch] = zf_lp

                env = self._env[bch]
                het_phase = self._het_phase[bch]
                drift_phase = self._drift_phase[bch]
                rfi_env = self._rfi_env[bch]
                noise = self._rng.standard_normal(n)
                trig = self._rng.random(n)

                y = np.empty(n, dtype=np.float64)
                for i in range(n):
                    level = abs(banded[i])
                    env = env + (0.05 if level > env else 0.002) * (level - env)

                    rfi_env *= 0.995
                    if trig[i] < rfi_prob:
                        rfi_env = 1.0

                    static_level = self.static_amount * (0.15 + 0.85 * (1.0 - min(1.0, env * 3.0)))
                    static_level *= (1.0 + rfi_env * 2.5)
                    static = noise[i] * static_level * 0.25

                    drift_phase += w_drift
                    het_freq_offset = w_het_base * (1.0 + 0.4 * np.sin(drift_phase))
                    het_phase += het_freq_offset
                    het = np.sin(het_phase) * self.static_amount * 0.06

                    y[i] = banded[i] + static + het

                self._env[bch] = env
                self._het_phase[bch] = float(het_phase % (2.0 * np.pi))
                self._drift_phase[bch] = float(drift_phase % (2.0 * np.pi))
                self._rfi_env[bch] = rfi_env

                out[:, ch] = y
                static_energies.append(float(np.sqrt(np.mean(np.square(y - banded)) + 1e-12)))

            self._static_activity = float(np.mean(static_energies)) if static_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("AmRadioDetuneProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
