# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI R — Saturación extrema de pistas en cassette (Portastudio Overdrive) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_r_portastudio_overdrive.py — LUCHALOCA LOFI R
════════════════════════════════════════════════════════════════════════════
Técnica base: Saturación extrema de pistas en cassette (Portastudio
Overdrive).

"Modelar la saturación extrema de pistas de cassette. Debe incorporar:
drive; saturación; compresión; densidad armónica; suavizado de
transitorios. La referencia describe niveles masivos sobre 0 dBVU y la
saturación de cinta de óxido férrico a baja velocidad."

Cadena real: 1) compresión suave previa (rodilla blanda, ataque
rápido/liberación lenta con estado persistente — "suavizado de
transitorios", el comportamiento real de la histéresis magnética antes
de saturar) → 2) sobremuestreo 2x + filtro de interpolación STATEFUL
(mismo mecanismo que `caurita_profile_aae.py`, necesario para no
aliasar los armónicos nuevos) → 3) saturación asimétrica controlada
(`tanh` + término cuadrático, `harmonic_density` mezcla impares/pares
— cinta magnética real satura de forma asimétrica según la polaridad
del flujo) → 4) diezmado 2x→1x.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_r")

__all__ = ["PortastudioOverdriveProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


class PortastudioOverdriveProfile(LuchaProfile):
    """LUCHALOCA LOFI R — Portastudio Overdrive. Backend puro, sin Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 drive: float = 0.55, harmonic_density: float = 0.5,
                 compression: float = 0.4, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.drive = float(np.clip(drive, 0.0, 1.0))
        self.harmonic_density = float(np.clip(harmonic_density, 0.0, 1.0))
        self.compression = float(np.clip(compression, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._interp_b = self._interp_a = None
        self._decim_b = self._decim_a = None
        self._interp_zi: list = []
        self._decim_zi: list = []
        self._env = [0.0] * self.channels   # envolvente del compresor, persistente
        self._dc_state = [np.zeros(2, dtype=np.float64) for _ in range(self.channels)]
        self._saturation_activity = 0.0
        self._compression_gr_db = 0.0
        self._rebuild_filters()

    def _rebuild_filters(self) -> None:
        if not _SCIPY_OK:
            return
        self._interp_b, self._interp_a = butter(4, 0.45, btype="low")
        self._decim_b, self._decim_a = butter(4, 0.45, btype="low")
        self._interp_zi = [_zi_at_rest(self._interp_b, self._interp_a).copy() for _ in range(self.channels)]
        self._decim_zi = [_zi_at_rest(self._decim_b, self._decim_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        self._rebuild_filters()
        self._env = [0.0] * self.channels
        self._dc_state = [np.zeros(2, dtype=np.float64) for _ in range(self.channels)]
        self._saturation_activity = 0.0
        self._compression_gr_db = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, drive=None, harmonic_density=None, compression=None, mix=None) -> None:
        if drive is not None:
            self.drive = float(np.clip(drive, 0.0, 1.0))
        if harmonic_density is not None:
            self.harmonic_density = float(np.clip(harmonic_density, 0.0, 1.0))
        if compression is not None:
            self.compression = float(np.clip(compression, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def _oversample_2x(self, x: np.ndarray, ch: int) -> np.ndarray:
        up = np.zeros(x.shape[0] * 2, dtype=np.float64)
        up[0::2] = x * 2.0
        filtered, zf = lfilter(self._interp_b, self._interp_a, up, zi=self._interp_zi[ch])
        self._interp_zi[ch] = zf
        return filtered

    def _decimate_2x(self, x: np.ndarray, ch: int) -> np.ndarray:
        filtered, zf = lfilter(self._decim_b, self._decim_a, x, zi=self._decim_zi[ch])
        self._decim_zi[ch] = zf
        return filtered[0::2]

    def _soft_compress(self, x: np.ndarray, ch: int) -> np.ndarray:
        """Compresor de rodilla blanda con envolvente PERSISTENTE
        (ataque rápido, liberación lenta) — "suavizado de
        transitorios"."""
        if self.compression <= 0.0:
            return x
        attack, release = 0.35, 0.01
        env = self._env[ch]
        out = np.empty_like(x)
        threshold = 1.0 - self.compression * 0.6
        ratio = 1.0 + self.compression * 5.0
        for i in range(x.shape[0]):
            level = abs(x[i])
            coef = attack if level > env else release
            env = env + coef * (level - env)
            if env > threshold:
                over_db = 20.0 * np.log10(max(env, 1e-9) / threshold)
                gain_db = -over_db * (1.0 - 1.0 / ratio)
                gain = 10.0 ** (gain_db / 20.0)
            else:
                gain = 1.0
            out[i] = x[i] * gain
        self._env[ch] = env
        self._compression_gr_db = round(20.0 * np.log10(max(np.mean(np.abs(out)) + 1e-9,
                                                              1e-9) / max(np.mean(np.abs(x)) + 1e-9, 1e-9)), 3)
        return out

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0 or self._interp_b is None:
            self.status = ModuleStatus.BYPASSED if self._interp_b is None else self.status
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            out = np.empty_like(x, dtype=np.float64)

            drive_amt = 1.0 + self.drive * 9.0
            sat_energies = []
            for ch in range(n_ch):
                bch = ch % self.channels
                pre = self._soft_compress(x[:, ch].astype(np.float64), bch)
                oversampled = self._oversample_2x(pre, bch)
                v = oversampled * drive_amt
                odd = np.tanh(v)
                dc_state = self._dc_state[bch]
                even_raw = v * v
                r = 0.995
                dc_out = np.empty_like(even_raw)
                prev_in, prev_out = dc_state[0], dc_state[1]
                for i in range(even_raw.shape[0]):
                    cur = even_raw[i] - prev_in + r * prev_out
                    dc_out[i] = cur
                    prev_in, prev_out = even_raw[i], cur
                dc_state[0], dc_state[1] = prev_in, prev_out
                shaped = (1.0 - self.harmonic_density) * odd + self.harmonic_density * dc_out
                shaped = shaped / max(1.0, drive_amt * 0.3)
                decimated = self._decimate_2x(shaped, bch)
                out[:, ch] = decimated
                sat_energies.append(float(np.sqrt(np.mean(np.square(decimated)) + 1e-12)))

            self._saturation_activity = float(np.mean(sat_energies)) if sat_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("PortastudioOverdriveProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
