# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI S — Subpolarización de cinta (Under-biasing) (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_s_under_biasing.py — LUCHALOCA LOFI S
════════════════════════════════════════════════════════════════════════════
Técnica base: Subpolarización de cinta (Under-biasing).

"Simular una corriente de bias inferior al punto óptimo. Debe
producir: incremento áspero de altas frecuencias; excitación armónica;
distorsión; comportamiento magnético no lineal."

Cadena real: 1) preénfasis STATEFUL (`BiquadDF2T` shelving-like vía
peaking en agudos) ANTES de la saturación — concentra la distorsión
que sigue en la banda alta, el "incremento áspero de altas
frecuencias" real (nunca un EQ posterior, que sonaría brillante pero
limpio) — 2) saturación magnética con MEMORIA — `y[n] = tanh(drive·
x[n] + hysteresis·y[n-1])`, un IIR no lineal de un polo con estado
persistente entre bloques — el comportamiento "pegajoso" real de la
curva de histéresis de un cabezal subpolarizado, deliberadamente
distinto de un `tanh` sin memoria (que sería solo recorte estático).
`bias_amount` controla tanto el drive de entrada como el coeficiente
de histéresis — a menor bias real, más áspera y con más memoria la
respuesta.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

from lorito_aldhiro.backend.dsp.lucha_enloquecida.biquad import BiquadDF2T
from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_s")

__all__ = ["UnderBiasingProfile"]


class UnderBiasingProfile(LuchaProfile):
    """LUCHALOCA LOFI S — Subpolarización de cinta. Backend puro, sin
    Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 bias_amount: float = 0.5, hf_emphasis: float = 0.5,
                 harmonic_excitation: float = 0.5, mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.bias_amount = float(np.clip(bias_amount, 0.0, 1.0))
        self.hf_emphasis = float(np.clip(hf_emphasis, 0.0, 1.0))
        self.harmonic_excitation = float(np.clip(harmonic_excitation, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._preemphasis = [
            BiquadDF2T(freq_hz=6000.0, q=0.7, gain_db=self.hf_emphasis * 12.0, fs=self.sample_rate)
            for _ in range(self.channels)
        ]
        self._hysteresis_state = [0.0] * self.channels
        self._harmonic_activity = 0.0

    def reset(self) -> None:
        for p in self._preemphasis:
            p.reset()
        self._hysteresis_state = [0.0] * self.channels
        self._harmonic_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, bias_amount=None, hf_emphasis=None, harmonic_excitation=None, mix=None) -> None:
        if bias_amount is not None:
            self.bias_amount = float(np.clip(bias_amount, 0.0, 1.0))
        if hf_emphasis is not None:
            self.hf_emphasis = float(np.clip(hf_emphasis, 0.0, 1.0))
            for p in self._preemphasis:
                p.set_params(gain_db=self.hf_emphasis * 12.0)
        if harmonic_excitation is not None:
            self.harmonic_excitation = float(np.clip(harmonic_excitation, 0.0, 1.0))
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)
            harmonic_energies = []

            drive = 0.6 + self.bias_amount * self.harmonic_excitation * 5.0
            hysteresis = self.bias_amount * 0.35

            for ch in range(n_ch):
                bch = ch % self.channels
                inp = x[:, ch].astype(np.float64)
                emphasized = self._preemphasis[bch].process(inp)

                y_prev = self._hysteresis_state[bch]
                saturated = np.empty(n, dtype=np.float64)
                for i in range(n):
                    v = np.tanh(emphasized[i] * drive + y_prev * hysteresis)
                    saturated[i] = v
                    y_prev = v
                self._hysteresis_state[bch] = y_prev

                out[:, ch] = saturated
                harmonic_energies.append(float(np.sqrt(np.mean(np.square(saturated - np.tanh(inp))) + 1e-12)))

            self._harmonic_activity = float(np.mean(harmonic_energies)) if harmonic_energies else 0.0
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("UnderBiasingProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
