# -*- coding: utf-8 -*-


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LUCHALOCA LOFI T — Uso de vinilos dañados y "dubplates" de acetato blando (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lucha_profile_t_vinyl_damage.py — LUCHALOCA LOFI T
════════════════════════════════════════════════════════════════════════════
Técnica base: Uso de vinilos dañados y "Dubplates" de acetato blando.

"Emular un soporte de vinilo extremadamente degradado. Debe incorporar:
surface noise; clicks; pops; saltos; microvariaciones; desgaste."

Cadena real, cuatro fenómenos independientes combinados en un único
kernel muestra-a-muestra:
  1. SURFACE NOISE — ruido persistente de bajo nivel, generado con un
     `Generator` de NumPy PROPIO de la instancia (nunca recreado por
     bloque — mismo criterio de continuidad estadística que el resto
     de generadores de ruido del catálogo, p.ej. `noise_generators.py`
     de Antipestal).
  2. CLICKS/POPS — proceso de disparo estocástico (probabilidad por
     muestra) con envolvente de decaimiento exponencial PERSISTENTE
     entre bloques — un clic que empieza cerca del final de un bloque
     sigue decayendo de forma continua en el siguiente, nunca se corta
     en la frontera.
  3. MICROVARIACIONES ("saltos") — línea de retardo con un único
     oscilador lento (mismo mecanismo de línea de retardo fraccionaria
     que LUCHALOCA LOFI M, pero con un solo LFO de baja frecuencia,
     ~0.55 Hz, equivalente a la excentricidad de un disco a 33⅓ RPM).
  4. DESGASTE — paso-bajos STATEFUL que recorta agudos de forma
     proporcional a `wear_amount` (el vinilo desgastado pierde brillo
     antes que nada).
"""
from __future__ import annotations

import logging
from typing import Any, Dict

import numpy as np

try:
    from scipy.signal import butter, lfilter
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

try:
    from numba import njit as _njit
    _HAVE_NUMBA = True
except Exception:  # pragma: no cover - entorno sin numba disponible
    _HAVE_NUMBA = False
    _njit = None

from lorito_aldhiro.backend.dsp.lucha_enloquecida.lucha_profile_contract import LuchaProfile, ModuleStatus

_log = logging.getLogger("lorito.lucha_enloquecida.profile_t")

__all__ = ["VinylDamageProfile"]


def _zi_at_rest(b, a) -> np.ndarray:
    return np.zeros(max(len(a), len(b)) - 1, dtype=np.float64)


def _vinyl_kernel(in_ch: np.ndarray, buf: np.ndarray, write_pos: int, warp_phase: float,
                   w_warp: float, warp_depth: float, base_delay: float, click_env: float,
                   click_sign: float, trigger_rand: np.ndarray, amp_rand: np.ndarray,
                   sign_rand: np.ndarray, noise: np.ndarray, click_prob: float,
                   decay_per_sample: float, surface_level: float) -> "tuple":
    n = in_ch.shape[0]
    buf_len = buf.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        buf[write_pos] = in_ch[i]

        delay = base_delay + warp_depth * np.sin(warp_phase)
        if delay < 1.0:
            delay = 1.0
        elif delay > buf_len - 2.0:
            delay = buf_len - 2.0
        read_pos_f = write_pos - delay
        while read_pos_f < 0.0:
            read_pos_f += buf_len
        i0 = int(read_pos_f)
        frac = read_pos_f - i0
        i1 = i0 + 1
        if i1 >= buf_len:
            i1 = 0
        warped = buf[i0] * (1.0 - frac) + buf[i1] * frac

        write_pos += 1
        if write_pos >= buf_len:
            write_pos = 0
        warp_phase += w_warp

        click_env *= decay_per_sample
        if click_env < 0.02 and trigger_rand[i] < click_prob:
            click_env = 0.35 + 0.65 * amp_rand[i]
            click_sign = 1.0 if sign_rand[i] < 0.5 else -1.0
        click_val = click_env * click_sign

        out[i] = warped + click_val + surface_level * noise[i]

    two_pi = 6.283185307179586
    warp_phase = warp_phase % two_pi
    return out, write_pos, warp_phase, click_env, click_sign


if _HAVE_NUMBA:
    _vinyl_kernel = _njit(cache=True)(_vinyl_kernel)


class VinylDamageProfile(LuchaProfile):
    """LUCHALOCA LOFI T — Vinilo dañado / Dubplate. Backend puro, sin
    Qt."""

    def __init__(self, sample_rate: int = 96000, channels: int = 2,
                 surface_noise_level: float = 0.03, click_rate_hz: float = 4.0,
                 warp_depth: float = 0.25, wear_amount: float = 0.3,
                 mix: float = 1.0) -> None:
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.surface_noise_level = float(np.clip(surface_noise_level, 0.0, 1.0))
        self.click_rate_hz = float(max(0.0, click_rate_hz))
        self.warp_depth = float(np.clip(warp_depth, 0.0, 1.0))
        self.wear_amount = float(np.clip(wear_amount, 0.0, 1.0))
        self.mix = float(np.clip(mix, 0.0, 1.0))
        self.status = ModuleStatus.OFF

        self._base_delay_ms = 6.0
        self._buf_len = max(64, int((self._base_delay_ms + 4.0) * 1e-3 * self.sample_rate))
        self._bufs = [np.zeros(self._buf_len, dtype=np.float64) for _ in range(self.channels)]
        self._write_pos = [0] * self.channels
        self._warp_phase = [0.0] * self.channels
        self._click_env = [0.0] * self.channels
        self._click_sign = [1.0] * self.channels
        self._rng = np.random.default_rng(4207)
        self._wear_b = self._wear_a = None
        self._wear_zi: list = []
        self._click_activity = 0.0
        self._surface_activity = 0.0
        self._rebuild_wear_filter()

    def _rebuild_wear_filter(self) -> None:
        if not _SCIPY_OK:
            return
        nyq = 0.5 * self.sample_rate
        cutoff = max(1500.0, 16000.0 * (1.0 - self.wear_amount * 0.85))
        wn = float(np.clip(cutoff / nyq, 1e-4, 0.97))
        self._wear_b, self._wear_a = butter(2, wn, btype="low")
        self._wear_zi = [_zi_at_rest(self._wear_b, self._wear_a).copy() for _ in range(self.channels)]

    def reset(self) -> None:
        for ch in range(self.channels):
            self._bufs[ch][:] = 0.0
            self._write_pos[ch] = 0
            self._warp_phase[ch] = 0.0
            self._click_env[ch] = 0.0
            self._click_sign[ch] = 1.0
        self._rng = np.random.default_rng(4207)
        self._rebuild_wear_filter()
        self._click_activity = 0.0
        self._surface_activity = 0.0
        self.status = ModuleStatus.ARMED

    def set_params(self, surface_noise_level=None, click_rate_hz=None, warp_depth=None,
                    wear_amount=None, mix=None) -> None:
        if surface_noise_level is not None:
            self.surface_noise_level = float(np.clip(surface_noise_level, 0.0, 1.0))
        if click_rate_hz is not None:
            self.click_rate_hz = float(max(0.0, click_rate_hz))
        if warp_depth is not None:
            self.warp_depth = float(np.clip(warp_depth, 0.0, 1.0))
        if wear_amount is not None:
            self.wear_amount = float(np.clip(wear_amount, 0.0, 1.0))
            self._rebuild_wear_filter()
        if mix is not None:
            self.mix = float(np.clip(mix, 0.0, 1.0))

    def process(self, block: np.ndarray) -> np.ndarray:
        if block.size == 0:
            return block
        try:
            mono_in = block.ndim == 1
            x = block if not mono_in else block[:, np.newaxis]
            n_ch = x.shape[1]
            n = x.shape[0]
            out = np.empty_like(x, dtype=np.float64)

            sr = float(self.sample_rate)
            base_delay = self._base_delay_ms * 1e-3 * sr
            warp_depth_s = self.warp_depth * 0.004 * sr
            w_warp = 2.0 * np.pi * 0.55 / sr
            click_prob = self.click_rate_hz / sr
            decay_per_sample = np.exp(-1.0 / (0.004 * sr))  # ~4 ms de decaimiento

            trigger_rand = self._rng.random(n)
            amp_rand = self._rng.random(n)
            sign_rand = self._rng.random(n)
            noise = self._rng.standard_normal(n)

            click_energies = []
            for ch in range(n_ch):
                bch = ch % self.channels
                res = _vinyl_kernel(
                    x[:, ch].astype(np.float64), self._bufs[bch], self._write_pos[bch],
                    self._warp_phase[bch], w_warp, warp_depth_s, base_delay,
                    self._click_env[bch], self._click_sign[bch],
                    trigger_rand, amp_rand, sign_rand, noise, click_prob,
                    decay_per_sample, self.surface_noise_level * 0.15,
                )
                (out_ch, self._write_pos[bch], self._warp_phase[bch],
                 self._click_env[bch], self._click_sign[bch]) = res

                if self._wear_b is not None:
                    zi = self._wear_zi[bch]
                    out_ch, zf = lfilter(self._wear_b, self._wear_a, out_ch, zi=zi)
                    self._wear_zi[bch] = zf

                out[:, ch] = out_ch
                click_energies.append(float(self._click_env[bch]))

            self._click_activity = float(np.mean(click_energies)) if click_energies else 0.0
            self._surface_activity = self.surface_noise_level
            dry = x.astype(np.float64)
            mixed = dry * (1.0 - self.mix) + out * self.mix
            np.clip(mixed, -1.0, 1.0, out=mixed)
            self.status = ModuleStatus.PROCESSING
            return mixed[:, 0] if mono_in else mixed.astype(block.dtype)
        except Exception:
            _log.exception("VinylDamageProfile: fallo procesando bloque — bypass")
            self.status = ModuleStatus.FAULT
            return block
