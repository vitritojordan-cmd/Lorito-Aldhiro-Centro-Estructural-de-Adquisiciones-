from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Taxonomía formal de errores de Lorito Aldhiro — raíz común de la que heredan las excepciones tipificadas del proyecto.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_errors_base.py — §15, FASE 1 ("Contratos + errores") de la Orden
Maestra de Saneamiento, Integración y Consolidación de Lorito Aldhiro.

Antes de esta fase, cada subsistema definía su propia excepción ad-hoc
heredando directamente de `RuntimeError` (`FormatMismatchError`,
`ExportAbortError`, `SegmentReadError`, `InvalidTransitionError`,
`MuscleEqError`) — funcionalmente correctas y ya usadas en producción,
pero sin ninguna relación formal entre sí: nada permitía a un llamador
preguntar "¿esto es un fallo de integridad?" sin enumerar a mano las
clases hoja existentes.

`LoritoError` es la raíz común (§15). Decisiones de diseño registradas
aquí — ver también `gaps/GAP-051.md` para el detalle completo:

  1. `LoritoError` hereda de `RuntimeError`, no de `Exception` a secas.
     Las 5 excepciones ad-hoc mencionadas arriba YA heredaban de
     `RuntimeError`, y la GUI (`lorito_mw_export.py`) tiene sitios
     reales `except RuntimeError as e:` que dependen de esa
     ascendencia para mostrarle un mensaje de error al usuario en vez
     de dejar que la excepción escape sin manejar. Que `LoritoError`
     extienda `RuntimeError` preserva esos sitios intactos — cualquier
     error tipificado nuevo sigue siendo capturable por código legado
     que todavía no conoce esta taxonomía.

  2. `EnvironmentError` (nombrada así literalmente en el diagrama de
     la Orden, §15) se renombra aquí a `LoritoEnvironmentError`. En
     Python, `EnvironmentError` es desde 3.3 un alias del built-in
     `OSError` — reutilizar ese nombre sombrearía el built-in dentro
     de este módulo y confundiría a cualquiera que escribiera `except
     EnvironmentError` esperando el comportamiento estándar de la
     librería. Es la única desviación de nombres respecto al diagrama
     original de la Orden.

  3. Las 7 categorías (`RecoverableError`, `DegradedError`,
     `FatalError`, `IntegrityError`, `CorruptionError`,
     `LoritoEnvironmentError`, `UserAbortError`) son hermanas directas
     de `LoritoError`, exactamente como en el diagrama de §15 — un
     árbol independiente del de `ExportError` (§11,
     `lorito_errors_export.py`). `ExportError` NO subclasea ninguna de
     estas 7 categorías: la política de recuperación se expresa en su
     lugar mediante el campo `recoverable`, ya parte del contrato de
     §11. Se prefirió esto a la herencia múltiple en diamante (p. ej.
     `class SegmentReadError(ExportError, IntegrityError)`) para no
     arriesgar problemas de MRO / doble inicialización en la primera
     sesión que introduce esta taxonomía — reevaluar en una sesión
     futura si aparece código real que necesite
     `isinstance(err, IntegrityError)` sobre un `ExportError`.
"""


class LoritoError(RuntimeError):
    """Raíz común de toda excepción tipificada de Lorito Aldhiro (§15).

    Atributos (siempre presentes, nunca requieren ``getattr`` defensivo):
        cause: excepción original encadenada, o ``None``. También se
            asigna a ``__cause__`` (equivalente a ``raise X from cause``)
            para que el traceback muestre la causa real aunque el
            llamador no haya usado la sintaxis ``from``.
        recoverable: ``True`` si el llamador puede razonablemente
            reintentar/continuar tras manejar este error. Por defecto
            ``False`` — el valor seguro cuando no se sabe.
    """

    def __init__(self, message: str, *, cause: Exception | None = None,
                 recoverable: bool = False):
        super().__init__(message)
        self.cause = cause
        self.recoverable = recoverable
        if cause is not None and self.__cause__ is None:
            self.__cause__ = cause


class RecoverableError(LoritoError):
    """Política §15: DSP recuperable → reset/continuar; I/O recuperable
    → recovery. ``recoverable`` queda fijo en ``True``."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=True)


class DegradedError(LoritoError):
    """La operación continúa pero el resultado debe quedar marcado
    DEGRADED — nunca se disfraza de éxito completo."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=False)


class FatalError(LoritoError):
    """Política §15: detener la operación en curso por completo."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=False)


class IntegrityError(LoritoError):
    """Política §15: marcar la sesión/ruta afectada DEGRADED o INVALID."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=False)


class CorruptionError(LoritoError):
    """Política §15: detener la ruta afectada — nunca dejar que datos
    corruptos se propaguen aguas abajo como si fueran válidos."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=False)


class LoritoEnvironmentError(LoritoError):
    """Fallo del entorno de ejecución (disco lleno, permisos, recursos
    del sistema) — ver nota de renombrado en el docstring del módulo."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=False)


class UserAbortError(LoritoError):
    """El usuario canceló la operación explícitamente — nunca debe
    tratarse ni registrarse como un fallo del sistema."""

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message, cause=cause, recoverable=False)
