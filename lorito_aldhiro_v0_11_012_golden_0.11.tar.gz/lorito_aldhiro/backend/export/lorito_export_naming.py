from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Lógica pura de exportación extraída del God Object — extensión de archivo por códec y formateo del tag/leyenda de velocidad y de clips.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_naming.py — GAP-071, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Extracción MECÁNICA de 4 fragmentos puros (sin Qt, sin hilos, sin I/O,
sin estado de instancia) que vivían inline dentro de `_do_export()`
(`ExportMixin`, `lorito_mw_export.py`, la función interna lanzada en
un hilo de fondo por `export()`) — mismo patrón de extracción ya
usado en GAP-056 (`lorito_export_session_spec.py`), GAP-062
(`lorito_speed_zone_labels.py`) y GAP-070
(`lorito_playback_scrub_sync.py`).

A diferencia de esas tres extracciones previas, esta NO es
principalmente para eliminar duplicación (ninguno de estos 4
fragmentos se repetía dentro de `lorito_mw_export.py`) sino para dar
cobertura de test DIRECTA a lógica de formato que, hasta ahora, solo
se verificaba indirectamente a través de una exportación real
completa (`tests/test_export_end_to_end_with_spec_file.py`,
GAP-056/060) — exactamente el hueco que describe §13: lógica pura
enterrada dentro del God Object, sin unidad de test propia.

## Las 4 funciones

- `export_codec_extension(codec)` — la extensión de archivo de
  salida por códec (`{"WAV":"wav", "FLAC":"flac", "OGG":"ogg",
  "WV":"wv"}`, `"wav"` por defecto para un códec desconocido —
  mismo default que el `.get(codec, "wav")` original).
- `export_speed_filename_tag(ratio)` — el tag `_x{ratio:.2f}` (con el
  punto decimal reemplazado por `"p"`, p. ej. `"_x1p50"`) que se
  añade al nombre del archivo cuando la velocidad de exportación no es
  ≈1.0 (umbral `abs(ratio - 1.0) > 0.005`, IDÉNTICO al original) —
  cadena vacía en caso contrario. Verificado end-to-end desde GAP-060
  (`test_export_with_speed_resample_completes_end_to_end`, confirma
  `"_x1p50"` en el nombre real de archivo); esta extracción añade
  además cobertura DIRECTA de las fronteras del umbral.
- `export_speed_display_suffix(ratio)` — el sufijo `"  ×{ratio:.2f}"`
  para el mensaje final de "exportación guardada", mismo umbral que
  la función anterior, cadena vacía en caso contrario.
- `export_clip_tag(clip_l, clip_r)` — el tag `"  clips:L{n}/R{n}"` para
  el mismo mensaje final, solo si hubo al menos un clip registrado en
  cualquier canal; cadena vacía en caso contrario.

Ninguna toca `self`, ningún widget de Qt, `_bridge`, ni ningún hilo —
son formateo de texto puro a partir de un `float`/`int` de entrada, un
`str` de salida. El resto de `_do_export()` (lectura de segmentos,
normalización, resampleo, invocación del exportador modular,
progreso, validación post-export, checksum, integridad end-to-end,
imagen espectral, log de especificación — todo lo que SÍ toca I/O,
`_bridge` o el global `_status`) NO se toca aquí — sigue viviendo en
`lorito_mw_export.py`, tal como pide la Orden para código de
exportación real sin poder verificar una reestructuración mayor con
la GUI real (PySide6 bloqueado en este sandbox, ver GAP-054 §7).
"""


_CODEC_EXTENSIONS = {"WAV": "wav", "FLAC": "flac", "OGG": "ogg", "WV": "wv"}

# Mismo umbral que el código original (`abs(ratio - 1.0) > 0.005`) —
# por debajo de este margen el Velocista se considera en neutro y no
# se etiqueta la exportación con ningún tag/sufijo de velocidad.
_SPEED_NEUTRAL_THRESHOLD = 0.005


def export_codec_extension(codec: str) -> str:
    """Extensión de archivo de salida para `codec` — `"wav"` por
    defecto si `codec` no es uno de los 4 reconocidos (mismo default
    que el `.get(codec, "wav")` original)."""
    return _CODEC_EXTENSIONS.get(codec, "wav")


def export_speed_filename_tag(ratio: float) -> str:
    """Tag de velocidad para el NOMBRE de archivo (p. ej. `"_x1p50"`),
    o `""` si `ratio` está dentro del margen neutro."""
    if abs(ratio - 1.0) <= _SPEED_NEUTRAL_THRESHOLD:
        return ""
    return f"_x{ratio:.2f}".replace(".", "p")


def export_speed_display_suffix(ratio: float) -> str:
    """Sufijo de velocidad para el MENSAJE final (p. ej.
    `"  ×1.50"`), o `""` si `ratio` está dentro del margen neutro."""
    if abs(ratio - 1.0) <= _SPEED_NEUTRAL_THRESHOLD:
        return ""
    return f"  ×{ratio:.2f}"


def export_clip_tag(clip_l: int, clip_r: int) -> str:
    """Tag de clips para el mensaje final (p. ej.
    `"  clips:L3/R1"`), o `""` si no hubo ningún clip registrado en
    ningún canal."""
    if clip_l + clip_r <= 0:
        return ""
    return f"  clips:L{clip_l}/R{clip_r}"
