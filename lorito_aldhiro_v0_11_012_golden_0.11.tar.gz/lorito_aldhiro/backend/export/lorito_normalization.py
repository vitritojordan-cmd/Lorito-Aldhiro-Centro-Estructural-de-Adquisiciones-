from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Los 20 modos de normalización de exportación — implementación de referencia.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import time
import math as _math
import numpy as np

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode



# ─────────────────────────────────────────────────────────────────────────────
#  LEYENDAS DE VELOCIDAD
# ─────────────────────────────────────────────────────────────────────────────

def _carol_speed_label(ratio: float) -> str:
    """
    Devuelve la leyenda de velocidad/tempo según el factor de reproducción.
    Rangos sincronizados con SpeedScrubBar.SPEED_LEGENDS (v0.21.06).

    Rango neutro:
      ~1.00              → Sin

    Rango acelerado (ratio > 1.00):
      1.01 … 1.10        → Calibrante
      1.11 … 1.40        → Verilucha
      1.41 … 1.60        → Pactorald
      1.61 … 2.00        → Pactorald Plus

    Rango desacelerado (0.50 ≤ ratio < 1.00):
      0.90 … 0.99        → Calibrante
      0.70 … 0.89        → Aguilar
      0.60 … 0.69        → Cromantina
      0.50 … 0.59        → Superprador
    """
    if abs(ratio - 1.0) < 0.005:
        return "Sin"
    if ratio > 1.0:
        if ratio >= 1.61:
            return "Pactorald Plus"
        if ratio >= 1.41:
            return "Pactorald"
        if ratio >= 1.11:
            return "Verilucha"
        return "Calibrante"   # 1.01 … 1.10
    # ratio < 1.0 — rango [0.50, 0.99]
    if ratio >= 0.90:
        return "Calibrante"   # 0.90 … 0.99
    if ratio >= 0.70:
        return "Aguilar"      # 0.70 … 0.89
    if ratio >= 0.60:
        return "Cromantina"   # 0.60 … 0.69
    return "Superprador"      # 0.50 … 0.59


# ══════════════════════════════════════════════════════════════════════════════
#  MOTOR DE NORMALIZACIÓN AVANZADA v0.20 — 7 modos
#  Funciones puras, sin estado, sin allocations RT.
#  Todas operan sobre arrays numpy float32 en memoria (post-lectura streaming).
#  Llamadas ÚNICAMENTE desde el hilo de exportación (background), nunca del RT.
#
#  Función pública de entrada: _apply_normalization_advanced(audio, mode, rate)
#  Retorna: (audio_normalizado: np.ndarray, stats: dict)
#
#  RIESGOS Y MITIGACIONES DOCUMENTADOS:
#  ─────────────────────────────────────
#  · CPU spike: análisis RMS/LUFS/True Peak son O(N). En 10h de audio a 96 kHz
#    ≈ 3.5G muestras → segundos de CPU. Mitigación: todos los modos usan
#    procesamiento chunked con NORM_ANALYSIS_CHUNK frames por iteración.
#    El hilo de exportación ya es background (daemon=True), no bloquea GUI ni RT.
#
#  · RAM spike: los algoritmos de análisis no cargan el array dos veces.
#    El array ya está en memoria al llegar aquí (post-_build_export_array).
#    No se crean copias adicionales de tamaño full; solo buffers de análisis
#    de tamaño NORM_ANALYSIS_CHUNK.
#
#  · Clipping post-ganancia: todos los modos aplican np.clip(-1, 1) al final
#    + ceiling configurable. Se loguea si se detectan samples clippeados.
#
#  · Pumping (Adaptive Block): crossfade de NORM_BLOCK_XFADE_FRAMES muestras
#    entre segmentos. Ventana de Hann para transiciones suaves.
#    Riesgo residual: en grabaciones con silencios largos puede haber pumping
#    si el bloque es demasiado corto. Solución: NORM_BLOCK_SECS ≥ 5 s.
#
#  · True Peak falsos positivos: el oversampling x2/x4 por interpolación
#    lineal/cúbica puede sobrestimar hasta +0.5 dBTP en señales sinusoidales
#    near-Nyquist. Mitigación: los targets de TP se establecen con -0.5 dB de
#    margen extra (TP_CEILING_DB) y se loguea cuando la estimación difiere del
#    peak simple por más de 1 dBTP.
#
#  · Hiss amplification (Noise-aware): si el noise floor está muy cerca del
#    target RMS, la ganancia calculada puede ser casi nula o negativa.
#    Mitigación: floor mínimo de +0 dB de ganancia (no se atenúa), y se loguea
#    la decisión para que el operador pueda elegir otro modo.
#
#  · Drift exportador: los modos de análisis en dos pasadas (RMS, LUFS,
#    Noise-aware) no modifican el array de audio durante el análisis.
#    La ganancia se aplica en una única pasada in-place. Sin drift posible.
#
#  · Incompatibilidad codecs: la normalización produce float32 en [-1, 1].
#    Los exporters (WAV/FLAC/OGG/WV) ya trabajan con este rango.
#    Los codecs lossy (OGG/WV) pueden producir true peaks ligeramente por encima
#    de 0 dBFS tras encodificación (intersample peaks). Mitigación: True Peak
#    mode con ceiling de -1 dBTP antes de exportar a lossy.
# ══════════════════════════════════════════════════════════════════════════════

# Tamaño de chunk para análisis (sin cargar el array entero de nuevo).
# 65536 frames ≈ 1.36 s a 48 kHz — granularidad suficiente para RMS/LUFS/Noise.
NORM_ANALYSIS_CHUNK = 65_536

# Ceiling por defecto para todos los modos (evita clip post-ganancia).
# Overrideable por modo: Preservativa usa -6 dBFS, True Peak -1 dBTP.
NORM_DEFAULT_CEILING_DBFS = -0.2

# Duración de bloques para Adaptive Block Normalization (segundos).
NORM_BLOCK_SECS = 10.0

# Crossfade entre bloques para evitar pumping (muestras).
# A 48 kHz → 4096 frames ≈ 85 ms. Suficiente para transiciones imperceptibles.
NORM_BLOCK_XFADE_FRAMES = 4_096


def _norm_db_to_linear(db: float) -> float:
    """Conversión dB → linear. Segura ante -inf."""
    try:
        return 10.0 ** (db / 20.0)
    except Exception:
        return 0.0


def _norm_linear_to_db(lin: float) -> float:
    """Conversión linear → dBFS. Segura ante 0."""
    if lin < 1e-12:
        return float("-inf")
    return 20.0 * float(np.log10(lin))


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 1 — RMS NORMALIZATION
# ─────────────────────────────────────────────────────────────────────────────

def _norm_rms(audio: np.ndarray, rate: int,
              target_rms_db: float = -20.0,
              ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
              max_gain_db: float = 40.0) -> tuple:
    """
    Normalización RMS (Root Mean Square).

    Algoritmo:
      1. Calcula RMS en pasada de análisis chunked → RMS = sqrt(mean(x²)).
         Sin cargar el array dos veces; itera por NORM_ANALYSIS_CHUNK frames.
      2. Calcula ganancia necesaria: gain = target_rms / rms_medido.
      3. Aplica ceiling: si peak_post > ceiling, reduce la ganancia.
      4. Aplica ganancia in-place + clip final.

    Riesgos:
      · Si el audio tiene muchos silencios, el RMS puede ser muy bajo y la
        ganancia resultante muy alta → se verifica contra el ceiling antes de aplicar.
      · Compatible con mono y estéreo (calcula RMS sobre todos los canales).

    Retorna: (audio_normalizado, stats_dict)
    """
    # Paso 1: análisis RMS chunked
    sum_sq = 0.0
    n_total = 0
    peak_linear = 0.0
    n_frames = len(audio)

    for start in range(0, n_frames, NORM_ANALYSIS_CHUNK):
        chunk = audio[start:start + NORM_ANALYSIS_CHUNK]
        sum_sq  += float(np.sum(chunk.astype(np.float64) ** 2))
        n_total += chunk.size
        pk = float(np.max(np.abs(chunk)))
        if pk > peak_linear:
            peak_linear = pk

    rms_linear = float(np.sqrt(sum_sq / max(n_total, 1)))
    rms_db = _norm_linear_to_db(rms_linear)
    peak_db = _norm_linear_to_db(peak_linear)

    if rms_linear < 1e-9:
        _log.warning("RMS norm: señal silenciosa (RMS=%.2f dB) — sin ganancia aplicada", rms_db)
        return audio.astype(np.float32), {
            "mode": "RMS", "target_db": target_rms_db,
            "rms_db": rms_db, "peak_db": peak_db,
            "gain_db": 0.0, "clipped_samples": 0,
        }

    # Paso 2: ganancia RMS
    target_rms_linear = _norm_db_to_linear(target_rms_db)
    gain = target_rms_linear / rms_linear

    # Paso 2b: límite de ganancia máxima (anti-hiss para presets de cinta)
    max_gain_linear = _norm_db_to_linear(max_gain_db)
    if gain > max_gain_linear:
        gain = max_gain_linear
        _log.info("RMS norm: ganancia limitada por max_gain_db %.1f dB", max_gain_db)

    # Paso 3: ceiling check
    ceiling_linear = _norm_db_to_linear(ceiling_db)
    peak_post = peak_linear * gain
    if peak_post > ceiling_linear:
        gain = ceiling_linear / max(peak_linear, 1e-12)
        _log.info("RMS norm: ganancia limitada por ceiling %.1f dBFS", ceiling_db)

    gain_db = _norm_linear_to_db(gain)

    # Paso 4: aplicar ganancia + clip
    audio_out = np.clip((audio.astype(np.float32) * np.float32(gain)),
                        -1.0, 1.0)
    n_clipped = int(np.sum(np.abs(audio_out) >= 0.9999))
    if n_clipped > 0:
        _log.warning("RMS norm: %d samples clippeados tras ganancia — ceiling efectivo", n_clipped)

    _log.info("RMS norm [target=%.1f dB]: rms_in=%.2f dB → gain=%.2f dB  peak_in=%.2f dBFS",
              target_rms_db, rms_db, gain_db, peak_db)

    return audio_out, {
        "mode": "RMS",
        "target_db": target_rms_db,
        "rms_db": rms_db,
        "peak_db": peak_db,
        "gain_db": gain_db,
        "gain_linear": gain,
        "ceiling_db": ceiling_db,
        "clipped_samples": n_clipped,
        "lufs": float("-inf"),
        "noise_floor_db": float("-inf"),
        "true_peak_db": peak_db + gain_db,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 2 — LUFS NORMALIZATION (BS.1770 simplificado)
# ─────────────────────────────────────────────────────────────────────────────

def _norm_lufs(audio: np.ndarray, rate: int,
               target_lufs: float = -23.0,
               ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
               max_gain_db: float = 40.0) -> tuple:
    """
    Normalización LUFS basada en ITU-R BS.1770 simplificado.

    Implementación:
      · Pre-filter K-weighting aproximado con filtro shelving de 2 etapas.
        Sin dependencias externas (solo numpy).
      · Gating básico: bloques de 400 ms con solapamiento 75% (BS.1770-4 §2.6).
        Umbral de gating absoluto: -70 LUFS; umbral relativo: media - 10 LU.
      · Integrated loudness = media de bloques gateados.

    Weighting aproximado (coeficientes prácticos a 48 kHz):
      Stage 1 (high-shelf): compensación de difracción de cabeza.
      Stage 2 (high-pass): corte a bajas frecuencias.
      Los coeficientes se recalculan para frecuencias distintas de 48 kHz.

    Riesgos:
      · Implementación simplificada: puede diferir ±0.5-1 LU de un medidor
        certificado en material con mucho bajo o muy dinámico.
        Suficiente para cassette/voz/radio FM pero no apto para master de cine.
      · Gating puede fallar si el audio es casi silencioso (<-70 LUFS promedio).
        Fallback a análisis sin gating en ese caso.

    Retorna: (audio_normalizado, stats_dict)
    """
    # ── Filtro K-weighting aproximado (biquad IIR) ───────────────────────────
    # Pre-filter stage 1: high-shelf +4 dB a 1 kHz (difracción de cabeza)
    # Stage 2: high-pass 2do orden 38 Hz
    # Coeficientes calculados para la frecuencia de muestreo dada.
    # Referencia: Grimm Audio / EBU Tech 3341 (implementación práctica sin scipy)

    def _apply_biquad_chunked(sig: np.ndarray, b: np.ndarray, a: np.ndarray) -> np.ndarray:
        """
        Aplica filtro biquad IIR de forma vectorizada por chunks.
        Usa numpy para evitar el loop Python puro que sería O(N) con overhead
        masivo en 10h de audio a 96 kHz (>3.5G iteraciones Python → horas).
        Estrategia: scipy.signal.lfilter si disponible; si no, chunked con
        estado llevado manualmente entre chunks (correcta continuidad de fase).
        """
        try:
            from scipy.signal import lfilter as _lfilter
            # scipy: la más rápida y precisa; coeficientes en forma directa II
            return _lfilter(b, a, sig.astype(np.float64))
        except ImportError:
            pass
        # Fallback: chunks de 65536 con estado manual entre chunks
        # Usa la forma directa I: y[n] = b0*x[n]+b1*x[n-1]+b2*x[n-2]-a1*y[n-1]-a2*y[n-2]
        sig64 = sig.astype(np.float64)
        out   = np.empty_like(sig64)
        n     = len(sig64)
        b0, b1, b2 = float(b[0]), float(b[1]), float(b[2])
        a1, a2     = float(a[1]), float(a[2])
        x1 = x2 = y1 = y2 = 0.0
        CHUNK = 4096
        for base in range(0, n, CHUNK):
            end = min(base + CHUNK, n)
            for i in range(base, end):
                x0 = sig64[i]
                y0 = b0*x0 + b1*x1 + b2*x2 - a1*y1 - a2*y2
                out[i] = y0
                x2, x1 = x1, x0
                y2, y1 = y1, y0
        return out

    def _k_weight_channel(sig: np.ndarray, fs: int) -> np.ndarray:
        """Aplica K-weighting aproximado a un canal mono."""
        sig64 = sig.astype(np.float64)

        # Stage 1: high-shelf (coeficientes estándar BS.1770 para 48 kHz)
        # Para otras frecuencias, se escalan los coeficientes bilinealmente.
        if abs(fs - 48000) < 100:
            b1s = np.array([1.53512485958697, -2.69169618940638, 1.19839281085285])
            a1s = np.array([1.0,               -1.69065929318241, 0.73248077421585])
        elif abs(fs - 44100) < 100:
            b1s = np.array([1.5308412300498, -2.6509948062498, 1.1690668057498])
            a1s = np.array([1.0,              -1.6636551132791, 0.7125954280786])
        else:
            # Aproximación genérica: escalar por ratio de frecuencias
            ratio = fs / 48000.0
            b1s = np.array([1.53512485958697 / ratio, -2.69169618940638, 1.19839281085285 * ratio])
            a1s = np.array([1.0, -1.69065929318241, 0.73248077421585])

        # Stage 2: high-pass 2do orden 38 Hz
        f0 = 38.5 / fs
        Q  = 0.5
        w0 = 2.0 * np.pi * f0
        alpha = np.sin(w0) / (2.0 * Q)
        b2s = np.array([1.0, -2.0, 1.0])
        a2s = np.array([1.0 + alpha, -2.0 * np.cos(w0), 1.0 - alpha])
        b2s /= a2s[0]; a2s /= a2s[0]

        out = _apply_biquad_chunked(sig64, b1s, a1s)
        out = _apply_biquad_chunked(out,  b2s, a2s)
        return out

    # ── Aplicar K-weighting por canal ────────────────────────────────────────
    n_ch = audio.shape[1] if audio.ndim == 2 else 1
    if audio.ndim == 1:
        audio2d = audio.reshape(-1, 1)
    else:
        audio2d = audio

    # K-weighted squared signal (media de canales para loudness total)
    k_sq = np.zeros(len(audio2d), dtype=np.float64)
    for ch in range(n_ch):
        kw = _k_weight_channel(audio2d[:, ch], rate)
        k_sq += kw ** 2
    k_sq /= n_ch  # media de canales

    # ── Gating BS.1770-4 ────────────────────────────────────────────────────
    # Bloques de 400 ms, hop de 100 ms (75% solapamiento)
    block_frames = int(0.400 * rate)
    hop_frames   = int(0.100 * rate)
    if block_frames < 1:
        block_frames = max(1, len(k_sq) // 4)
        hop_frames   = block_frames // 4

    block_loudnesses = []
    pos = 0
    while pos + block_frames <= len(k_sq):
        block_mean_sq = float(np.mean(k_sq[pos:pos + block_frames]))
        if block_mean_sq > 1e-12:
            loudness_lu = -0.691 + 10.0 * float(np.log10(block_mean_sq))
            block_loudnesses.append(loudness_lu)
        pos += hop_frames

    if not block_loudnesses:
        # Fallback sin gating: usar todo el audio
        mean_sq = float(np.mean(k_sq))
        lufs_measured = -0.691 + 10.0 * float(np.log10(max(mean_sq, 1e-12)))
        _log.warning("LUFS: gating vacío — usando loudness sin gateway = %.2f LUFS", lufs_measured)
    else:
        # Umbral absoluto: -70 LUFS
        abs_thresh = -70.0
        gated_abs = [l for l in block_loudnesses if l > abs_thresh]
        if not gated_abs:
            gated_abs = block_loudnesses  # fallback: sin gating absoluto

        # Umbral relativo: media_gateada - 10 LU
        mean_abs = float(np.mean(gated_abs))
        rel_thresh = mean_abs - 10.0
        gated_rel = [l for l in gated_abs if l > rel_thresh]
        if not gated_rel:
            gated_rel = gated_abs

        lufs_measured = float(np.mean(gated_rel))

    peak_linear = float(np.max(np.abs(audio)))
    peak_db = _norm_linear_to_db(peak_linear)

    if lufs_measured <= float("-inf") or lufs_measured < -200:
        _log.warning("LUFS: señal silenciosa — sin ganancia aplicada")
        return audio.astype(np.float32), {
            "mode": "LUFS", "target_db": target_lufs,
            "lufs": lufs_measured, "peak_db": peak_db,
            "gain_db": 0.0, "clipped_samples": 0,
        }

    # Ganancia necesaria
    gain_db = target_lufs - lufs_measured
    gain    = _norm_db_to_linear(gain_db)

    # Límite de ganancia máxima (anti-hiss para presets de cinta)
    max_gain_linear = _norm_db_to_linear(max_gain_db)
    if gain > max_gain_linear:
        gain    = max_gain_linear
        gain_db = _norm_linear_to_db(gain)
        _log.info("LUFS norm: ganancia limitada por max_gain_db %.1f dB", max_gain_db)

    # Ceiling check
    ceiling_linear = _norm_db_to_linear(ceiling_db)
    if peak_linear * gain > ceiling_linear:
        gain_ceiling = ceiling_linear / max(peak_linear, 1e-12)
        if gain_ceiling < gain:
            gain    = gain_ceiling
            gain_db = _norm_linear_to_db(gain)
            _log.info("LUFS norm: ganancia limitada por ceiling %.1f dBFS — "
                      "loudness resultante puede no alcanzar el target exacto", ceiling_db)

    audio_out = np.clip((audio.astype(np.float32) * np.float32(gain)), -1.0, 1.0)
    n_clipped = int(np.sum(np.abs(audio_out) >= 0.9999))

    _log.info("LUFS norm [target=%.1f LUFS]: medido=%.2f LUFS → gain=%.2f dB  peak=%.2f dBFS",
              target_lufs, lufs_measured, gain_db, peak_db)

    return audio_out, {
        "mode": "LUFS",
        "target_db": target_lufs,
        "lufs": lufs_measured,
        "peak_db": peak_db,
        "gain_db": gain_db,
        "ceiling_db": ceiling_db,
        "clipped_samples": n_clipped,
        "noise_floor_db": float("-inf"),
        "true_peak_db": peak_db + gain_db,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 3 — INTELLIGENT PEAK NORMALIZATION
# ─────────────────────────────────────────────────────────────────────────────

def _norm_intelligent_peak(audio: np.ndarray, rate: int,
                            percentile: float = 99.9,
                            ceiling_db: float = NORM_DEFAULT_CEILING_DBFS) -> tuple:
    """
    Normalización peak-aware que ignora picos anómalos (clicks, glitches).

    Algoritmo:
      1. Calcula la distribución de valores absolutos del audio.
      2. Usa el percentil configurable (99.5 o 99.9) como "peak efectivo"
         en lugar del máximo absoluto.
      3. Aplica ganancia para que el peak efectivo llegue al ceiling.
      4. Si el análisis falla (array vacío, percentil inválido), fallback
         a peak clásico.

    Riesgo principal:
      · Si hay muchos clicks seguidos (>0.1% de samples), el percentil 99.9
        puede seguir siendo un click. Mitigación: el ceiling protege contra
        clipping catastrófico incluso si el peak "efectivo" es un click.

    Retorna: (audio_normalizado, stats_dict)
    """
    try:
        abs_vals = np.abs(audio).ravel()
        effective_peak = float(np.percentile(abs_vals, percentile))
        true_peak      = float(np.max(abs_vals))
        outlier_ratio  = float(np.mean(abs_vals > effective_peak))
        use_effective  = True
    except Exception as e:
        _log.warning("Intelligent Peak: fallo en análisis percentil (%s) — fallback a peak clásico", e)
        effective_peak = float(np.max(np.abs(audio)))
        true_peak      = effective_peak
        outlier_ratio  = 0.0
        use_effective  = False

    peak_db     = _norm_linear_to_db(true_peak)
    eff_peak_db = _norm_linear_to_db(effective_peak)

    if effective_peak < 1e-9:
        _log.warning("Intelligent Peak: señal silenciosa — sin ganancia")
        return audio.astype(np.float32), {
            "mode": "INTELLIGENT_PEAK",
            "peak_db": peak_db, "effective_peak_db": eff_peak_db,
            "percentile_used": percentile, "outlier_ratio": outlier_ratio,
            "gain_db": 0.0, "clipped_samples": 0,
        }

    ceiling_linear = _norm_db_to_linear(ceiling_db)
    gain           = ceiling_linear / effective_peak
    gain_db        = _norm_linear_to_db(gain)

    # Protección: no aplicar más de +40 dB de ganancia (señal demasiado baja)
    MAX_GAIN_DB = 40.0
    if gain_db > MAX_GAIN_DB:
        _log.warning("Intelligent Peak: ganancia calculada %.2f dB excede límite %.1f dB — limitando",
                     gain_db, MAX_GAIN_DB)
        gain    = _norm_db_to_linear(MAX_GAIN_DB)
        gain_db = MAX_GAIN_DB

    audio_out  = np.clip((audio.astype(np.float32) * np.float32(gain)), -1.0, 1.0)
    n_clipped  = int(np.sum(np.abs(audio_out) >= 0.9999))
    n_expected = int(len(abs_vals) * (1.0 - percentile / 100.0))

    _log.info("Intelligent Peak [P=%.1f%%]: eff_peak=%.2f dBFS  true_peak=%.2f dBFS"
              "  gain=%.2f dB  outliers=%.3f%%",
              percentile, eff_peak_db, peak_db, gain_db, outlier_ratio * 100)

    return audio_out, {
        "mode": "INTELLIGENT_PEAK",
        "peak_db": peak_db,
        "effective_peak_db": eff_peak_db,
        "percentile_used": percentile,
        "outlier_ratio": outlier_ratio,
        "expected_clipped_samples": n_expected,
        "gain_db": gain_db,
        "ceiling_db": ceiling_db,
        "clipped_samples": n_clipped,
        "lufs": float("-inf"),
        "noise_floor_db": float("-inf"),
        "true_peak_db": eff_peak_db + gain_db,
        "use_effective_peak": use_effective,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 4 — TRUE PEAK NORMALIZATION (oversampling x2 / x4)
# ─────────────────────────────────────────────────────────────────────────────

def _norm_true_peak(audio: np.ndarray, rate: int,
                    oversample: int = 2,
                    ceiling_db: float = -1.0) -> tuple:
    """
    True Peak aproximado por oversampling lineal/cúbico.

    Método:
      · Oversample x2 o x4 con interpolación lineal (rápida) o cúbica (precisa).
        x2: interpolación lineal. Suficiente para detectar la mayoría de
            intersample peaks (error max ~0.3 dBTP según EBU Tech 3341).
        x4: interpolación cúbica de Catmull-Rom. Más preciso pero 4× más lento.
      · El análisis se hace en bloques (chunked) — sin oversamplear todo el
        array de una vez para controlar RAM.
      · El audio de salida es el original (no oversampled) con ganancia ajustada.

    Riesgo de falsos positivos:
      · La interpolación puede sobre-estimar el true peak hasta +0.5 dBTP en
        señales sinusoidales a Nyquist/2. Mitigación: ceiling_db = -1.0 por
        defecto (margen de 1 dB sobre el ceiling de -0.2 dBFS de otros modos).

    Riesgo de stall largo:
      · A x4 con audio de 10h a 96 kHz: ~140M frames × 4 → ~560M operaciones.
        En CPU de gama media: 30-60 s. El hilo es background; sin impacto RT.
        Se loguea el tiempo de análisis.

    Retorna: (audio_normalizado, stats_dict)
    """
    t_start = time.monotonic()
    n_frames = len(audio)
    n_ch     = audio.shape[1] if audio.ndim == 2 else 1
    if audio.ndim == 1:
        audio2d = audio.reshape(-1, 1)
    else:
        audio2d = audio

    true_peak_linear = 0.0

    for start in range(0, n_frames, NORM_ANALYSIS_CHUNK):
        chunk = audio2d[start:start + NORM_ANALYSIS_CHUNK].astype(np.float64)
        n_c   = len(chunk)
        if n_c < 2:
            continue

        if oversample == 2:
            # Interpolación lineal x2
            t_os = np.linspace(0, n_c - 1, n_c * 2, dtype=np.float64)
            xi   = np.floor(t_os).astype(np.int64)
            frac = (t_os - xi).astype(np.float64)
            xi1  = np.minimum(xi + 1, n_c - 1)
            for ch in range(n_ch):
                col = chunk[:, ch]
                os_ch = col[xi] + frac * (col[xi1] - col[xi])
                pk = float(np.max(np.abs(os_ch)))
                if pk > true_peak_linear:
                    true_peak_linear = pk
        else:
            # Oversample x4 con interpolación cúbica Catmull-Rom
            t_os = np.linspace(0, n_c - 1, n_c * 4, dtype=np.float64)
            i1   = np.floor(t_os).astype(np.int64)
            mu   = (t_os - i1).astype(np.float64)
            i0   = np.maximum(i1 - 1, 0)
            i2   = np.minimum(i1 + 1, n_c - 1)
            i3   = np.minimum(i1 + 2, n_c - 1)
            mu2  = mu * mu; mu3 = mu2 * mu
            c0 = -0.5*mu3 + mu2 - 0.5*mu
            c1 =  1.5*mu3 - 2.5*mu2 + 1.0
            c2 = -1.5*mu3 + 2.0*mu2 + 0.5*mu
            c3 =  0.5*mu3 - 0.5*mu2
            for ch in range(n_ch):
                col = chunk[:, ch]
                os_ch = c0*col[i0] + c1*col[i1] + c2*col[i2] + c3*col[i3]
                pk = float(np.max(np.abs(os_ch)))
                if pk > true_peak_linear:
                    true_peak_linear = pk

    t_elapsed = time.monotonic() - t_start
    peak_simple  = float(np.max(np.abs(audio)))
    tp_db        = _norm_linear_to_db(true_peak_linear)
    peak_db      = _norm_linear_to_db(peak_simple)
    diff_db      = tp_db - peak_db

    if diff_db > 1.0:
        _log.warning("True Peak: TP=%.2f dBTP > peak_simple=%.2f dBFS → diff=%.2f dB "
                     "(posibles intersample peaks)", tp_db, peak_db, diff_db)

    ceiling_linear = _norm_db_to_linear(ceiling_db)

    if true_peak_linear < 1e-9:
        _log.warning("True Peak: señal silenciosa — sin ganancia")
        gain = 1.0
    else:
        gain = ceiling_linear / true_peak_linear

    gain_db  = _norm_linear_to_db(gain)
    audio_out = np.clip((audio.astype(np.float32) * np.float32(gain)), -1.0, 1.0)
    n_clipped = int(np.sum(np.abs(audio_out) >= 0.9999))

    _log.info("True Peak x%d [ceiling=%.1f dBTP]: tp=%.2f dBTP  peak=%.2f dBFS"
              "  gain=%.2f dB  análisis=%.1f s",
              oversample, ceiling_db, tp_db, peak_db, gain_db, t_elapsed)

    return audio_out, {
        "mode": f"TRUE_PEAK_X{oversample}",
        "oversample": oversample,
        "true_peak_db": tp_db,
        "peak_db": peak_db,
        "tp_vs_peak_diff_db": diff_db,
        "gain_db": gain_db,
        "ceiling_db": ceiling_db,
        "clipped_samples": n_clipped,
        "analysis_secs": round(t_elapsed, 2),
        "lufs": float("-inf"),
        "noise_floor_db": float("-inf"),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 5 — PRESERVATIVE NORMALIZATION
# ─────────────────────────────────────────────────────────────────────────────

def _norm_preservative(audio: np.ndarray, rate: int,
                        ceiling_db: float = -6.0,
                        max_gain_db: float = 40.0) -> tuple:
    """
    Normalización preservativa para archivos históricos/masters antiguos.

    Reglas:
      · NO maximizar agresivamente (ceiling = -6 dBFS por defecto).
      · NO modificar la dinámica original (sin compresión implícita).
      · Preservar el crest factor: la ganancia se calcula para que el peak
        llegue al ceiling (como peak clásico), pero el ceiling es conservador.
      · Si el audio ya está por encima del ceiling, se atenúa (nunca se amplifca
        más allá de ceiling).
      · Si el peak ya está dentro del headroom (ceiling - 6 dB): no se aplica
        ninguna ganancia (preservación total de la ganancia original).

    Ideal para:
      · Masters de los 50-70s grabados con headroom amplio.
      · Cintas de baja saturación donde subir el volumen amplificaría el hiss.
      · Archivos RIAA sin énfasis flat donde la dinámica es la característica.

    Retorna: (audio_normalizado, stats_dict)
    """
    peak_linear = float(np.max(np.abs(audio)))
    peak_db     = _norm_linear_to_db(peak_linear)
    ceiling_lin = _norm_db_to_linear(ceiling_db)

    # Headroom actual
    headroom_db = ceiling_db - peak_db  # negativo = por encima del ceiling

    # Rango de "no tocar": si el peak está entre ceiling-6 y ceiling
    NO_TOUCH_RANGE_DB = 6.0
    low_threshold_db  = ceiling_db - NO_TOUCH_RANGE_DB

    if peak_db >= low_threshold_db:
        # Ya está en el rango objetivo (incluye casos por encima del ceiling → atenuar)
        gain    = ceiling_lin / max(peak_linear, 1e-12)
        gain_db = _norm_linear_to_db(gain)
        action  = "ajuste conservador al ceiling"
    else:
        # Muy bajo: aplicar ganancia hasta ceiling
        gain    = ceiling_lin / max(peak_linear, 1e-12)
        gain_db = _norm_linear_to_db(gain)
        action  = "amplificiación al ceiling"

    # Límite de ganancia máxima (anti-hiss para presets de cinta)
    max_gain_linear = _norm_db_to_linear(max_gain_db)
    if gain > max_gain_linear:
        gain    = max_gain_linear
        gain_db = _norm_linear_to_db(gain)
        action  = action + f" (limitado por max_gain {max_gain_db:.1f} dB)"
        _log.info("Preservativa: ganancia limitada por max_gain_db %.1f dB", max_gain_db)

    # Calcular crest factor antes y después para verificar preservación
    rms_linear = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2)))
    crest_db_before = peak_db - _norm_linear_to_db(rms_linear)

    audio_out  = np.clip((audio.astype(np.float32) * np.float32(gain)), -1.0, 1.0)
    n_clipped  = int(np.sum(np.abs(audio_out) >= 0.9999))
    peak_after = _norm_linear_to_db(float(np.max(np.abs(audio_out))))

    # El crest factor debe ser idéntico (ganancia lineal no altera CF)
    crest_db_after = crest_db_before  # invariante garantizado por ganancia lineal

    _log.info("Preservativa [ceiling=%.1f dBFS]: peak_in=%.2f dBFS  headroom=%.2f dB"
              "  gain=%.2f dB  crest_factor=%.2f dB  acción=%s",
              ceiling_db, peak_db, headroom_db, gain_db, crest_db_before, action)

    if n_clipped > 0:
        _log.warning("Preservativa: %d samples clippeados — audio original excedía ceiling", n_clipped)

    return audio_out, {
        "mode": "PRESERVATIVE",
        "ceiling_db": ceiling_db,
        "peak_db": peak_db,
        "peak_after_db": peak_after,
        "headroom_db": headroom_db,
        "gain_db": gain_db,
        "crest_factor_db": crest_db_before,
        "action": action,
        "clipped_samples": n_clipped,
        "lufs": float("-inf"),
        "noise_floor_db": float("-inf"),
        "true_peak_db": peak_db + gain_db,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 6 — NOISE-AWARE NORMALIZATION
# ─────────────────────────────────────────────────────────────────────────────

def _norm_noise_aware(audio: np.ndarray, rate: int,
                       target_rms_db: float = -18.0,
                       max_gain_db: float = 20.0,
                       ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                       noise_threshold_db: float = -50.0) -> tuple:
    """
    Normalización consciente del ruido de fondo (hiss de cinta).

    Algoritmo:
      1. Estima el noise floor analizando el percentil 10 de los bloques RMS
         de 100 ms. El noise floor es la energía promedio de los bloques más
         silenciosos (los que contienen solo ruido de fondo, no señal).
      2. Calcula el SNR efectivo: SNR = RMS_señal - noise_floor.
      3. Si el noise floor está por encima del umbral (noise_threshold_db),
         limita la ganancia máxima para no elevar el hiss excesivamente.
         Fórmula: max_gain_efectivo = min(max_gain_db, target - noise_floor - 6)
         Esto garantiza que el noise floor resultante quede al menos 6 dB
         por debajo del target RMS.
      4. Aplica normalización RMS con la ganancia máxima limitada.

    Casos de uso:
      · Type I (ferric) domésticas degradadas: noise floor típico -50 a -40 dBFS.
      · Type II (chrome): -55 a -48 dBFS.
      · Cintas demagnetizadas: -35 a -30 dBFS (necesita limitación agresiva).

    Retorna: (audio_normalizado, stats_dict)
    """
    # Paso 1: estimar noise floor con bloques RMS de 100 ms
    block_f  = max(1, int(0.100 * rate))
    n_frames = len(audio)
    block_rmss = []

    for start in range(0, n_frames - block_f, block_f * 4):  # submuestreo x4 para velocidad
        chunk = audio[start:start + block_f].astype(np.float64)
        rms   = float(np.sqrt(np.mean(chunk ** 2)))
        if rms > 1e-12:
            block_rmss.append(rms)

    if not block_rmss:
        # Fallback a análisis global
        rms_global    = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2)))
        noise_floor_db = _norm_linear_to_db(rms_global)
        _log.warning("Noise-aware: no se pudieron calcular bloques RMS — usando RMS global")
    else:
        # Percentil 10 de los bloques RMS = noise floor estimado
        block_rmss.sort()
        p10_idx      = max(0, int(len(block_rmss) * 0.10))
        noise_floor_linear = block_rmss[p10_idx]
        noise_floor_db = _norm_linear_to_db(noise_floor_linear)

    # Paso 2: SNR y decisión de ganancia
    rms_linear = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2)))
    rms_db     = _norm_linear_to_db(rms_linear)
    peak_db    = _norm_linear_to_db(float(np.max(np.abs(audio))))
    snr_db     = rms_db - noise_floor_db

    # Paso 3: limitar ganancia si hay hiss significativo
    noise_limited = False
    effective_max_gain_db = max_gain_db

    if noise_floor_db > noise_threshold_db:
        # El hiss supera el umbral: limitar ganancia para que
        # noise_floor + gain < target_rms - 6 dB
        safe_gain_limit = (target_rms_db - 6.0) - noise_floor_db
        if safe_gain_limit < effective_max_gain_db:
            effective_max_gain_db = max(0.0, safe_gain_limit)  # no atenuar
            noise_limited = True
            _log.info("Noise-aware: noise floor %.2f dBFS > umbral %.2f dBFS → "
                      "ganancia limitada a %.2f dB (era %.2f dB)",
                      noise_floor_db, noise_threshold_db,
                      effective_max_gain_db, max_gain_db)

    # Paso 4: normalización RMS con ganancia limitada
    target_rms_lin = _norm_db_to_linear(target_rms_db)
    gain_needed    = target_rms_lin / max(rms_linear, 1e-12)
    gain_needed_db = _norm_linear_to_db(gain_needed)

    if gain_needed_db > effective_max_gain_db:
        gain    = _norm_db_to_linear(effective_max_gain_db)
        gain_db = effective_max_gain_db
    else:
        gain    = gain_needed
        gain_db = gain_needed_db

    # Ceiling check
    ceiling_lin = _norm_db_to_linear(ceiling_db)
    peak_lin    = float(np.max(np.abs(audio)))
    if peak_lin * gain > ceiling_lin:
        gain    = ceiling_lin / max(peak_lin, 1e-12)
        gain_db = _norm_linear_to_db(gain)
        _log.info("Noise-aware: ganancia reducida por ceiling %.1f dBFS", ceiling_db)

    audio_out   = np.clip((audio.astype(np.float32) * np.float32(gain)), -1.0, 1.0)
    n_clipped   = int(np.sum(np.abs(audio_out) >= 0.9999))
    noise_after = noise_floor_db + gain_db  # dBFS del hiss tras la ganancia

    _log.info("Noise-aware [target=%.1f dB RMS]: noise_floor=%.2f dBFS  SNR=%.1f dB"
              "  gain=%.2f dB  noise_after=%.2f dBFS  limitado=%s",
              target_rms_db, noise_floor_db, snr_db, gain_db, noise_after,
              "SÍ" if noise_limited else "NO")

    return audio_out, {
        "mode": "NOISE_AWARE",
        "target_rms_db": target_rms_db,
        "rms_db": rms_db,
        "peak_db": peak_db,
        "noise_floor_db": noise_floor_db,
        "noise_after_db": noise_after,
        "snr_db": snr_db,
        "gain_db": gain_db,
        "noise_limited": noise_limited,
        "effective_max_gain_db": effective_max_gain_db,
        "ceiling_db": ceiling_db,
        "clipped_samples": n_clipped,
        "lufs": float("-inf"),
        "true_peak_db": peak_db + gain_db,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  MODO 7 — ADAPTIVE BLOCK NORMALIZATION
# ─────────────────────────────────────────────────────────────────────────────

def _norm_adaptive_block(audio: np.ndarray, rate: int,
                          block_secs: float = NORM_BLOCK_SECS,
                          target_rms_db: float = -18.0,
                          ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                          xfade_frames: int = NORM_BLOCK_XFADE_FRAMES) -> tuple:
    """
    Normalización adaptativa por bloques con crossfade.

    Objetivo: zonas extremadamente bajas (silencios, dropout de cinta) no limiten
    la ganancia del audio circundante. Útil para cintas deterioradas o entrevistas
    con silencios largos.

    Algoritmo:
      1. Segmenta el audio en bloques de block_secs segundos.
      2. Calcula RMS por bloque.
      3. Bloque muy silencioso (RMS < -60 dBFS): no aplicar ganancia extra
         (preservar silencio/fade natural).
      4. Bloque con señal: calcular ganancia RMS independiente.
      5. Suavizado temporal de ganancias entre bloques (Gaussian smoothing 3-tap)
         para evitar saltos bruscos de ganancia.
      6. Crossfade entre bloques adyacentes (ventana de Hann de xfade_frames)
         para evitar artefactos de transición.

    Riesgo de pumping:
      · Si block_secs es demasiado corto (<3 s), las variaciones de ganancia
        entre bloques pueden ser audibles. Por defecto: 10 s.
      · Si xfade_frames es demasiado pequeño, las transiciones tienen click.
        Por defecto: 4096 frames (~85 ms a 48 kHz).

    Riesgo de stall:
      · Audio de 10h con bloques de 10s → 3600 bloques. El procesamiento es
        O(N) total. El stall es mínimo comparado con otros modos.

    Retorna: (audio_normalizado, stats_dict)
    """
    n_frames    = len(audio)
    block_f     = max(int(block_secs * rate), 1)
    ceiling_lin = _norm_db_to_linear(ceiling_db)
    SILENCE_THRESHOLD_DB = -60.0  # bloques más silenciosos que esto: no tocar

    # Paso 1-3: calcular ganancia para cada bloque
    n_blocks      = (n_frames + block_f - 1) // block_f
    block_gains   = np.ones(n_blocks, dtype=np.float64)
    block_rms_dbs = []

    for bi in range(n_blocks):
        start = bi * block_f
        end   = min(start + block_f, n_frames)
        chunk = audio[start:end].astype(np.float64)
        rms   = float(np.sqrt(np.mean(chunk ** 2)))
        rms_db = _norm_linear_to_db(rms)
        block_rms_dbs.append(rms_db)

        if rms_db < SILENCE_THRESHOLD_DB or rms < 1e-9:
            # Silencio o casi silencio: mantener ganancia = 1.0 (sin amplificar ruido)
            block_gains[bi] = 1.0
            continue

        target_lin = _norm_db_to_linear(target_rms_db)
        gain_raw   = target_lin / rms

        # Ceiling por bloque
        peak_block = float(np.max(np.abs(chunk)))
        if peak_block * gain_raw > ceiling_lin:
            gain_raw = ceiling_lin / max(peak_block, 1e-12)

        block_gains[bi] = gain_raw

    # Paso 4: suavizado Gaussian 3-tap de las ganancias
    if n_blocks >= 3:
        kernel = np.array([0.25, 0.50, 0.25], dtype=np.float64)
        smoothed = block_gains.copy()
        for i in range(1, n_blocks - 1):
            smoothed[i] = (block_gains[i-1]*0.25 +
                           block_gains[i  ]*0.50 +
                           block_gains[i+1]*0.25)
        block_gains = smoothed

    gain_db_stats = float(np.mean(np.log10(np.maximum(block_gains, 1e-12)) * 20))

    # Paso 5: aplicar ganancias con crossfade entre bloques
    audio_out   = audio.astype(np.float32).copy()
    xfade_f     = min(xfade_frames, block_f // 4)  # nunca más de 1/4 del bloque
    hann_half   = np.hanning(xfade_f * 2).astype(np.float32)
    fade_out    = hann_half[:xfade_f]     # [1→0] (primera mitad de Hann invertida)
    fade_in     = hann_half[xfade_f:]     # [0→1] (segunda mitad de Hann)
    # Corrección: Hann comienza y termina en 0, así que la zona de fade-out
    # real es la parte de 0→1 aplicada al bloque anterior, y fade-in al nuevo.
    # Reemplazar por rampa simple para comportamiento más predecible:
    fade_in_ramp  = np.linspace(0.0, 1.0, xfade_f, dtype=np.float32)
    fade_out_ramp = np.linspace(1.0, 0.0, xfade_f, dtype=np.float32)

    for bi in range(n_blocks):
        start  = bi * block_f
        end    = min(start + block_f, n_frames)
        g      = np.float32(block_gains[bi])
        audio_out[start:end] *= g

        # Crossfade con bloque anterior en la zona de transición
        if bi > 0 and xfade_f > 0 and start + xfade_f <= n_frames:
            xf_start = start
            xf_end   = min(xf_start + xfade_f, n_frames)
            xf_len   = xf_end - xf_start
            g_prev   = np.float32(block_gains[bi - 1])

            # Mezcla ponderada: zona anterior × fade_out + zona actual × fade_in
            # (El bloque actual ya fue multiplicado por g arriba)
            # GAP-029: los ramps son 1D (xf_len,) — con audio estéreo
            # (xf_len, n_ch) el broadcast fallaba con ValueError (nunca
            # antes ejercitado: ninguna sesión previa había forzado una
            # zona de crossfade con audio estéreo real). Se amplía a
            # columna cuando el audio es 2D.
            prev_block  = audio[xf_start:xf_end].astype(np.float32) * g_prev
            curr_block  = audio[xf_start:xf_end].astype(np.float32) * g
            fo_ramp = fade_out_ramp[:xf_len]
            fi_ramp = fade_in_ramp[:xf_len]
            if prev_block.ndim > 1:
                fo_ramp = fo_ramp[:, np.newaxis]
                fi_ramp = fi_ramp[:, np.newaxis]
            blended     = (prev_block  * fo_ramp +
                           curr_block  * fi_ramp)
            audio_out[xf_start:xf_end] = blended

    # Clip final de seguridad
    audio_out = np.clip(audio_out, -1.0, 1.0)
    n_clipped = int(np.sum(np.abs(audio_out) >= 0.9999))

    _log.info("Adaptive Block [%.1f s/bloque, target=%.1f dB RMS, ceiling=%.1f dBFS]: "
              "%d bloques  gain_avg=%.2f dB  clipped=%d",
              block_secs, target_rms_db, ceiling_db,
              n_blocks, gain_db_stats, n_clipped)

    return audio_out, {
        "mode": "ADAPTIVE_BLOCK",
        "block_secs": block_secs,
        "target_rms_db": target_rms_db,
        "ceiling_db": ceiling_db,
        "n_blocks": n_blocks,
        "gain_db": gain_db_stats,
        "peak_db": _norm_linear_to_db(float(np.max(np.abs(audio)))),
        "clipped_samples": n_clipped,
        "xfade_frames": xfade_f,
        "block_rms_range_db": [
            round(float(np.min(block_rms_dbs)), 2),
            round(float(np.max(block_rms_dbs)), 2),
        ] if block_rms_dbs else [0.0, 0.0],
        "lufs": float("-inf"),
        "noise_floor_db": float("-inf"),
        "true_peak_db": _norm_linear_to_db(float(np.max(np.abs(audio_out)))),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  CRAC 0.20 — BLOQUE DE NORMALIZACIÓN AVANZADA (cierre funcional pre-1.x)
# ─────────────────────────────────────────────────────────────────────────────
#
#  Sistema 1 — Pipeline de doble normalización (pre + post procesamiento)
#  Sistema 2 — Análisis Mid/Side opcional con protección estéreo
#  Sistema 3 — Protección de microdinámica por crest factor
#  Sistema 4 — Análisis estadístico de amplitud (histograma chunked)
#  Sistema 5 — Modo automático inteligente (AUTO)
#
#  Principios de diseño:
#  · Todo es opcional y desactivable individualmente.
#  · Sin desacoplamiento — integrado en el pipeline de exportación existente.
#  · Sin dependencias nuevas — solo numpy (ya requerido).
#  · Thread-safe: ninguna función modifica _status ni accede a GUI.
#  · Logging exhaustivo de ambas ganancias, métricas M/S, crest factor,
#    histograma y decisión automática para forensics/telemetría.
# ─────────────────────────────────────────────────────────────────────────────

# ── Constantes del bloque avanzado ───────────────────────────────────────────
_CRAC_ANALYSIS_BLOCK  = 65536   # frames por bloque de análisis (≈1.36 s @48k)
_CRAC_HIST_BINS       = 256     # bins del histograma de amplitud chunked
_CRAC_SILENCE_THR     = -60.0   # dBFS: umbral de silencio por bloque RMS
_CRAC_CLIPPING_THR    = -0.1    # dBFS: peak ≥ este valor → sospecha de clipping
_CRAC_HISS_RMS_MAX    = -50.0   # dBFS: RMS ≤ esto con poca dinámica → hiss probable
_CRAC_MIN_CF_DEFAULT  = 8.0     # dB: crest factor mínimo por defecto
_CRAC_STEREO_MAX_DIFF = 6.0     # dB: desequilibrio Mid/Side máximo tolerado


# ─────────────────────────────────────────────────────────────────────────────
#  SISTEMA 1 — PIPELINE DE DOBLE NORMALIZACIÓN (pre + post)
# ─────────────────────────────────────────────────────────────────────────────

def _prenorm_conservative(audio: np.ndarray,
                           headroom_db: float = -3.0) -> tuple:
    """
    Pre-normalización conservadora — ETAPA 1 del pipeline doble.

    Objetivo:
      · Garantizar que el audio entra al bloque de restauración (denoise,
        declick, wow/flutter, filtros opcionales) con un nivel controlado,
        evitando que filtros o correcciones eleven el RMS/peak de forma
        inesperada antes de la normalización final.
      · Preserva headroom intermedio: aplica ganancia solo si el peak está
        por encima de headroom_db o más de 12 dB por debajo (señal muy débil).

    Retorna:
      (audio_out, stats) donde stats contiene:
        pre_normalization_gain_db   — ganancia aplicada en dB (0.0 si sin cambio)
        pre_norm_peak_db            — peak original antes de prenorm
        pre_norm_rms_db             — RMS antes de prenorm
        pre_norm_action             — "applied" | "headroom_ok" | "silent"
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    peak_linear = float(np.max(np.abs(audio)))
    if peak_linear < 1e-9:
        return audio.copy(), {
            "pre_normalization_gain_db": 0.0,
            "pre_norm_peak_db": float("-inf"),
            "pre_norm_rms_db":  float("-inf"),
            "pre_norm_action":  "silent",
        }

    peak_db = _norm_linear_to_db(peak_linear)
    rms_db  = _norm_linear_to_db(float(np.sqrt(np.mean(audio.astype(np.float64) ** 2))))

    # Margen de trabajo: zona [headroom_db - 12, headroom_db]
    if headroom_db - 12.0 <= peak_db <= headroom_db:
        # Ya está en zona segura — sin tocarlo
        return audio.copy(), {
            "pre_normalization_gain_db": 0.0,
            "pre_norm_peak_db": round(peak_db, 3),
            "pre_norm_rms_db":  round(rms_db, 3),
            "pre_norm_action":  "headroom_ok",
        }

    # Llevar el peak al headroom objetivo
    target_linear = _norm_db_to_linear(headroom_db)
    gain          = target_linear / peak_linear
    gain_db       = _norm_linear_to_db(gain)

    # Aplicar sin clipping (el headroom garantiza que no supera 0 dBFS)
    audio_out = np.clip(audio * np.float32(gain), -1.0, 1.0)

    _log.info("Pre-norm conservadora: peak_in=%.2f dBFS → headroom=%.1f dBFS  "
              "gain=%.2f dB  rms_in=%.2f dBFS",
              peak_db, headroom_db, gain_db, rms_db)

    return audio_out, {
        "pre_normalization_gain_db": round(gain_db, 4),
        "pre_norm_peak_db": round(peak_db, 3),
        "pre_norm_rms_db":  round(rms_db, 3),
        "pre_norm_action":  "applied",
    }


def _apply_double_norm_pipeline(audio: np.ndarray,
                                 rate: int,
                                 final_mode: "NormalizationMode",
                                 pre_headroom_db: float = -3.0,
                                 restoration_fn=None) -> tuple:
    """
    Pipeline de doble normalización completo:

      ETAPA 1: pre-normalización conservadora (peak → headroom_db)
      ETAPA 2: restauración opcional (denoise/declick/wow-flutter/filtros)
               Se llama restoration_fn(audio, rate) → audio si se provee.
      ETAPA 3: normalización final con el modo seleccionado.

    Retorna:
      (audio_out, stats_combined) donde stats_combined incluye:
        pre_normalization_gain_db   — ganancia de la etapa 1
        post_normalization_gain_db  — ganancia de la etapa 3 (del modo final)
        + todos los campos del modo final (peak_db, lufs, noise_floor_db, etc.)

    Uso típico desde el dispatcher:
      _apply_double_norm_pipeline(audio, rate,
          final_mode=NormalizationMode.LUFS_16,
          pre_headroom_db=-3.0,
          restoration_fn=my_restoration)

    Si restoration_fn es None el pipeline omite la etapa 2 (útil para testear
    las etapas de normalización puras sin restauración).
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    # ETAPA 1 — Pre-normalización conservadora
    audio_stage1, pre_stats = _prenorm_conservative(audio, pre_headroom_db)
    pre_gain_db = pre_stats["pre_normalization_gain_db"]

    # ETAPA 2 — Restauración opcional (no implementada en CRAC 0.20 todavía,
    #           pero el slot está listo para conectar en CRAC 1.x)
    if restoration_fn is not None:
        try:
            audio_stage2 = restoration_fn(audio_stage1, rate)
            if audio_stage2 is None or not isinstance(audio_stage2, np.ndarray):
                _log.warning("Double-norm pipeline: restoration_fn retornó None — usando audio prenorm")
                audio_stage2 = audio_stage1
        except Exception as exc_rest:
            _log.error("Double-norm pipeline: restoration_fn error — %s — continuando sin restauración",
                       exc_rest, exc_info=True)
            audio_stage2 = audio_stage1
    else:
        audio_stage2 = audio_stage1

    # Detectar si la restauración alteró significativamente el nivel
    peak_post_rest = float(np.max(np.abs(audio_stage2)))
    peak_post_rest_db = _norm_linear_to_db(peak_post_rest) if peak_post_rest > 1e-9 else float("-inf")
    if peak_post_rest_db > -0.5:
        # La restauración empujó el audio cerca de clipping — advertencia
        _log.warning("Double-norm pipeline: post-restauración peak=%.2f dBFS — "
                     "posible clipping acumulativo detectado", peak_post_rest_db)

    # ETAPA 3 — Normalización final
    audio_final, final_stats = _apply_normalization_advanced(audio_stage2, final_mode, rate)
    post_gain_db = final_stats.get("gain_db", 0.0)

    # Combinar estadísticas de ambas etapas
    combined = dict(final_stats)
    combined["pre_normalization_gain_db"]  = round(pre_gain_db, 4)
    combined["post_normalization_gain_db"] = round(post_gain_db, 4)
    combined["double_norm_total_gain_db"]  = round(pre_gain_db + post_gain_db, 4)
    combined["pre_norm_peak_db"]           = pre_stats.get("pre_norm_peak_db", float("-inf"))
    combined["pre_norm_rms_db"]            = pre_stats.get("pre_norm_rms_db",  float("-inf"))
    combined["pre_norm_action"]            = pre_stats.get("pre_norm_action",  "unknown")

    _log.info("Double-norm pipeline: etapa1_gain=%.2f dB  etapa3_gain=%.2f dB  "
              "total=%.2f dB  peak_post_rest=%.2f dBFS",
              pre_gain_db, post_gain_db,
              pre_gain_db + post_gain_db,
              peak_post_rest_db)

    return audio_final, combined


# ─────────────────────────────────────────────────────────────────────────────
#  SISTEMA 2 — ANÁLISIS Y NORMALIZACIÓN MID/SIDE
# ─────────────────────────────────────────────────────────────────────────────

def _analyze_mid_side(audio: np.ndarray) -> dict:
    """
    Analiza las componentes Mid y Side de una señal estéreo.

    Fórmulas estándar:
      Mid  = (L + R) / sqrt(2)    — información de suma (mono)
      Side = (L - R) / sqrt(2)    — información de diferencia (espacialidad)

    Retorna dict con:
      mid_rms         — RMS de la componente Mid en dBFS
      side_rms        — RMS de la componente Side en dBFS
      stereo_balance_index — índice 0..1: 0=puro mono, 1=estéreo máximo
                             calculado como Side_rms / (Mid_rms + Side_rms)
                             en escala lineal. Valores >0.7 indican
                             expansión estéreo excesiva.
      mid_peak_db     — peak de Mid en dBFS
      side_peak_db    — peak de Side en dBFS
    """
    if audio.ndim != 2 or audio.shape[1] < 2:
        # Mono — mid es la señal misma, side = 0
        sig = audio[:, 0] if audio.ndim == 2 else audio
        rms_db = _norm_linear_to_db(float(np.sqrt(np.mean(sig.astype(np.float64) ** 2))))
        return {
            "mid_rms": round(rms_db, 3),
            "side_rms": float("-inf"),
            "stereo_balance_index": 0.0,
            "mid_peak_db": round(_norm_linear_to_db(float(np.max(np.abs(sig)))), 3),
            "side_peak_db": float("-inf"),
            "is_mono": True,
        }

    L = audio[:, 0].astype(np.float64)
    R = audio[:, 1].astype(np.float64)
    INV_SQRT2 = 1.0 / _math.sqrt(2.0)
    mid  = (L + R) * INV_SQRT2
    side = (L - R) * INV_SQRT2

    mid_rms_lin  = float(np.sqrt(np.mean(mid  ** 2)))
    side_rms_lin = float(np.sqrt(np.mean(side ** 2)))

    mid_rms_db  = _norm_linear_to_db(mid_rms_lin)  if mid_rms_lin  > 1e-9 else float("-inf")
    side_rms_db = _norm_linear_to_db(side_rms_lin) if side_rms_lin > 1e-9 else float("-inf")

    # Índice de balance estéreo: 0 = mono puro, 1 = máximo estéreo
    denom = mid_rms_lin + side_rms_lin
    sbi   = (side_rms_lin / denom) if denom > 1e-9 else 0.0

    mid_peak_db  = _norm_linear_to_db(float(np.max(np.abs(mid))))
    side_peak_db = _norm_linear_to_db(float(np.max(np.abs(side))))

    return {
        "mid_rms":              round(mid_rms_db, 3),
        "side_rms":             round(side_rms_db, 3),
        "stereo_balance_index": round(sbi, 4),
        "mid_peak_db":          round(mid_peak_db, 3),
        "side_peak_db":         round(side_peak_db, 3),
        "is_mono":              False,
    }


def _norm_mid_side(audio: np.ndarray,
                   rate: int,
                   ms_norm_mode: "NormalizationMode" = None,
                   max_side_gain_db: float = 6.0,
                   max_stereo_balance_index: float = 0.70) -> tuple:
    """
    Normalización Mid/Side opcional.

    Objetivo:
      · Corregir desequilibrios estéreo en grabaciones FM/cassette deterioradas.
      · Rescatar espacialidad sin expandir el campo estéreo excesivamente.
      · Mantener compatibilidad mono (normalizar Mid preserva la suma L+R).

    Parámetros:
      ms_norm_mode           — modo de normalización a aplicar a Mid y Side
                               individualmente. Si None, usa RMS_18 por defecto.
      max_side_gain_db       — límite de ganancia máxima sobre Side para
                               proteger contra expansión estéreo excesiva.
      max_stereo_balance_index — si SBI post-norm supera este valor, se reduce
                               la ganancia de Side hasta cumplirlo.

    Retorna:
      (audio_out, stats) con stats incluyendo:
        mid_rms, side_rms, stereo_balance_index (antes y después)
        ms_mid_gain_db, ms_side_gain_db
        ms_side_clamped — True si se limitó la ganancia de Side

    Si el audio es mono, retorna sin cambios con stats indicando is_mono=True.
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    ms_stats_before = _analyze_mid_side(audio)
    _log.info("M/S análisis PRE: mid_rms=%.2f dBFS  side_rms=%.2f dBFS  "
              "SBI=%.3f  mid_peak=%.2f dBFS  side_peak=%.2f dBFS",
              ms_stats_before["mid_rms"], ms_stats_before["side_rms"],
              ms_stats_before["stereo_balance_index"],
              ms_stats_before["mid_peak_db"], ms_stats_before["side_peak_db"])

    if ms_stats_before.get("is_mono", False):
        _log.info("M/S norm: audio mono detectado — sin procesamiento M/S")
        stats = dict(ms_stats_before)
        stats.update({
            "ms_mid_gain_db": 0.0, "ms_side_gain_db": 0.0,
            "ms_side_clamped": False, "ms_action": "skipped_mono",
        })
        return audio.copy(), stats

    if ms_norm_mode is None:
        ms_norm_mode = NormalizationMode.RMS_18

    L = audio[:, 0].astype(np.float64)
    R = audio[:, 1].astype(np.float64)
    INV_SQRT2 = 1.0 / _math.sqrt(2.0)
    mid  = (L + R) * INV_SQRT2
    side = (L - R) * INV_SQRT2

    # Normalizar Mid y Side independientemente
    mid_f32  = mid.astype(np.float32).reshape(-1, 1)
    side_f32 = side.astype(np.float32).reshape(-1, 1)

    mid_norm,  mid_nstats  = _apply_normalization_advanced(mid_f32,  ms_norm_mode, rate)
    side_norm, side_nstats = _apply_normalization_advanced(side_f32, ms_norm_mode, rate)

    mid_gain_db  = mid_nstats.get("gain_db", 0.0)
    side_gain_db = side_nstats.get("gain_db", 0.0)

    # Protección anti-expansión estéreo excesiva:
    # Si la ganancia de Side superaría max_side_gain_db, recortarla
    side_clamped = False
    if side_gain_db > max_side_gain_db:
        _log.warning("M/S norm: Side gain %.2f dB supera límite %.2f dB — recortando",
                     side_gain_db, max_side_gain_db)
        # Aplicar ganancia limitada manualmente en vez de usar la normalizada
        clamp_linear = _norm_db_to_linear(max_side_gain_db)
        side_norm_arr = np.clip(side_f32[:, 0].astype(np.float64) * clamp_linear,
                                -1.0, 1.0).astype(np.float32)
        side_gain_db  = max_side_gain_db
        side_clamped  = True
    else:
        side_norm_arr = side_norm[:, 0]

    # Verificar SBI post-norm antes de comprometer
    mid_rms_post  = float(np.sqrt(np.mean(mid_norm[:, 0].astype(np.float64) ** 2)))
    side_rms_post = float(np.sqrt(np.mean(side_norm_arr.astype(np.float64) ** 2)))
    denom_post = mid_rms_post + side_rms_post
    sbi_post   = (side_rms_post / denom_post) if denom_post > 1e-9 else 0.0

    if sbi_post > max_stereo_balance_index:
        # Reducir ganancia de Side hasta que SBI ≤ límite
        # SBI = side / (mid + side) ≤ limit  →  side ≤ limit * mid / (1 - limit)
        if max_stereo_balance_index < 1.0:
            target_side_rms = mid_rms_post * max_stereo_balance_index / (1.0 - max_stereo_balance_index)
            if side_rms_post > 1e-9:
                reduction = target_side_rms / side_rms_post
                side_norm_arr = np.clip(side_norm_arr.astype(np.float64) * reduction,
                                        -1.0, 1.0).astype(np.float32)
                side_gain_db  += _norm_linear_to_db(reduction)
                side_clamped  = True
                _log.warning("M/S norm: SBI post=%.3f > límite %.3f — "
                             "Side reducido %.2f dB para preservar mono-compatibility",
                             sbi_post, max_stereo_balance_index,
                             _norm_linear_to_db(reduction))

    # Decodificar M/S de vuelta a L/R
    mid_arr = mid_norm[:, 0].astype(np.float64)
    side_arr = side_norm_arr.astype(np.float64)
    L_out = np.clip((mid_arr + side_arr) * INV_SQRT2, -1.0, 1.0).astype(np.float32)
    R_out = np.clip((mid_arr - side_arr) * INV_SQRT2, -1.0, 1.0).astype(np.float32)
    audio_out = np.stack([L_out, R_out], axis=1)

    ms_stats_after = _analyze_mid_side(audio_out)
    _log.info("M/S análisis POST: mid_rms=%.2f dBFS  side_rms=%.2f dBFS  "
              "SBI=%.3f  mid_gain=%.2f dB  side_gain=%.2f dB  clamped=%s",
              ms_stats_after["mid_rms"], ms_stats_after["side_rms"],
              ms_stats_after["stereo_balance_index"],
              mid_gain_db, side_gain_db, side_clamped)

    stats = {
        # Métricas requeridas
        "mid_rms":              ms_stats_before["mid_rms"],
        "side_rms":             ms_stats_before["side_rms"],
        "stereo_balance_index": ms_stats_before["stereo_balance_index"],
        # Post-proceso
        "mid_rms_post":              ms_stats_after["mid_rms"],
        "side_rms_post":             ms_stats_after["side_rms"],
        "stereo_balance_index_post": ms_stats_after["stereo_balance_index"],
        # Ganancias
        "ms_mid_gain_db":   round(mid_gain_db, 4),
        "ms_side_gain_db":  round(side_gain_db, 4),
        "ms_side_clamped":  side_clamped,
        "ms_norm_mode":     ms_norm_mode.value,
        "ms_action":        "processed",
        "gain_db":          round((mid_gain_db + side_gain_db) / 2.0, 4),  # promedio para telemetría
        "peak_db":          ms_stats_before["mid_peak_db"],
        "lufs":             float("-inf"),
        "noise_floor_db":   float("-inf"),
        "true_peak_db":     0.0,
        "mode":             "MID_SIDE",
    }
    return audio_out, stats


# ─────────────────────────────────────────────────────────────────────────────
#  SISTEMA 3 — PROTECCIÓN DE MICRODINÁMICA (CREST FACTOR GUARD)
# ─────────────────────────────────────────────────────────────────────────────

def _calc_crest_factor(audio: np.ndarray) -> tuple:
    """
    Calcula el crest factor del audio.

      crest_factor_db = peak_db - rms_db

    Retorna:
      (crest_factor_db, peak_db, rms_db)

    Un crest factor alto (>15 dB) indica material dinámico con transientes
    bien preservados (cassette Tipo II, masters analógicos).
    Un crest factor bajo (<6 dB) sugiere sobrecompresión o limitación agresiva.
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)
    peak_linear = float(np.max(np.abs(audio)))
    if peak_linear < 1e-9:
        return float("inf"), float("-inf"), float("-inf")
    rms_linear = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2)))
    if rms_linear < 1e-9:
        return float("inf"), _norm_linear_to_db(peak_linear), float("-inf")
    peak_db = _norm_linear_to_db(peak_linear)
    rms_db  = _norm_linear_to_db(rms_linear)
    return peak_db - rms_db, peak_db, rms_db


def _apply_with_crest_guard(audio: np.ndarray,
                             rate: int,
                             norm_mode: "NormalizationMode",
                             min_crest_factor_db: float = _CRAC_MIN_CF_DEFAULT,
                             ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                             max_gain_db: float = 40.0) -> tuple:
    """
    Aplica normalización preservando el crest factor mínimo.

    Objetivo:
      · Evitar sobrecompresión perceptual.
      · Preservar transientes originales del material analógico.
      · Mantener carácter de cassette Tipo II / masters musicales.

    Algoritmo:
      1. Calcula crest factor pre-normalización.
      2. Aplica el modo de normalización seleccionado.
      3. Calcula crest factor post-normalización.
      4. Si CF post < min_crest_factor_db: revierte la ganancia parcialmente
         hasta restaurar CF = min_crest_factor_db.
         Esto puede implicar un nivel final ligeramente más bajo que el target.

    La ganancia aplicada puede ser 0 dBFS si el material ya está sobrecomprimido
    antes de normalizar — en ese caso se registra un WARNING.

    Retorna stats con:
      crest_factor_db        — CF antes de normalizar
      crest_factor_post_db   — CF después (garantizado ≥ min si fue posible)
      crest_guard_triggered  — True si se redujo la ganancia para proteger CF
      crest_guard_reduction_db — dB reducidos por la guarda
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    cf_pre, peak_pre, rms_pre = _calc_crest_factor(audio)

    if cf_pre < min_crest_factor_db:
        _log.warning("Crest factor PRE (%.2f dB) < mínimo (%.2f dB) — "
                     "material ya sobrecomprimido antes de normalizar",
                     cf_pre, min_crest_factor_db)

    # Aplicar normalización base
    # Si ceiling_db o max_gain_db difieren de los defaults, llamar _norm_rms
    # directamente para que los parámetros del preset tengan efecto.
    _use_direct = (ceiling_db != NORM_DEFAULT_CEILING_DBFS or max_gain_db < 40.0)
    if _use_direct:
        audio_norm, norm_stats = _norm_rms(
            audio, rate,
            ceiling_db=ceiling_db,
            max_gain_db=max_gain_db,
        )
    else:
        audio_norm, norm_stats = _apply_normalization_advanced(audio, norm_mode, rate)
    gain_applied_db = norm_stats.get("gain_db", 0.0)

    cf_post, peak_post, rms_post = _calc_crest_factor(audio_norm)
    crest_guard_triggered  = False
    crest_guard_reduction  = 0.0

    if cf_post < min_crest_factor_db and gain_applied_db > 0.0:
        # La ganancia comprimió perceptualmente el material.
        # Reducir la ganancia hasta que el CF vuelva al mínimo.
        #
        # CF_post = peak_post - rms_post
        # Queremos CF_target ≥ min_crest_factor_db
        # Una reducción de Δ dB en ganancia no cambia el CF (es lineal),
        # PERO si el ceiling estaba limitando el peak y el RMS sigue subiendo,
        # el CF puede haberse reducido por clipping acumulativo del peak.
        #
        # Estrategia: calcular cuánto hay que bajar la ganancia para que
        # peak_post / rms_post ≥ db2lin(min_CF).
        # Si el peak ya está al ceiling (-0.2 dBFS) y el RMS es demasiado alto:
        #   target_rms_db = peak_post_db - min_CF
        #   reduction_db  = rms_post_db - target_rms_db
        if rms_post > 1e-9 and peak_post > 1e-9:
            target_rms_db_cg = peak_post - min_crest_factor_db
            if target_rms_db_cg < rms_post:
                # Necesitamos reducir la señal para bajar el RMS
                reduction_linear = _norm_db_to_linear(target_rms_db_cg) / rms_post
                if reduction_linear < 1.0:
                    audio_norm = audio_norm * np.float32(reduction_linear)
                    crest_guard_reduction  = _norm_linear_to_db(reduction_linear)
                    crest_guard_triggered  = True
                    # Actualizar ganancia neta en stats
                    gain_applied_db += crest_guard_reduction
                    cf_post, peak_post, rms_post = _calc_crest_factor(audio_norm)
                    _log.info("Crest guard activado: CF_pre=%.2f dB → CF_post=%.2f dB  "
                              "reducción=%.2f dB  gain_neto=%.2f dB",
                              cf_pre, cf_post, crest_guard_reduction, gain_applied_db)

    if not crest_guard_triggered:
        _log.info("Crest guard: CF_pre=%.2f dB  CF_post=%.2f dB  "
                  "gain=%.2f dB  [sin activación]",
                  cf_pre, cf_post, gain_applied_db)

    combined = dict(norm_stats)
    combined.update({
        "crest_factor_db":          round(cf_pre,  3),
        "crest_factor_post_db":     round(cf_post, 3),
        "crest_guard_triggered":    crest_guard_triggered,
        "crest_guard_reduction_db": round(crest_guard_reduction, 4),
        "gain_db":                  round(gain_applied_db, 4),
        "peak_db":                  round(peak_pre, 3),
        "rms_db_pre":               round(rms_pre, 3),
        "min_crest_factor_db":      min_crest_factor_db,
    })
    return audio_norm, combined


# ─────────────────────────────────────────────────────────────────────────────
#  SISTEMA 4 — ANÁLISIS ESTADÍSTICO DE AMPLITUD (HISTOGRAMA CHUNKED)
# ─────────────────────────────────────────────────────────────────────────────

def _analyze_amplitude_histogram(audio: np.ndarray,
                                  rate: int,
                                  n_bins: int = _CRAC_HIST_BINS,
                                  chunk_frames: int = _CRAC_ANALYSIS_BLOCK
                                  ) -> dict:
    """
    Análisis estadístico de amplitud con histograma chunked.

    No carga el archivo completo — procesa en bloques de chunk_frames.
    Apto para sesiones de 10+ horas con el array ya construido en memoria
    mapeada.

    Detecta:
      · Silencios dominantes  (silence_ratio)
      · Clipping previo       (histogram_peak_density)
      · Audio excesivamente comprimido (dynamic_range_estimate bajo)
      · Hiss dominante        (noise_floor cercano al RMS)

    Retorna dict con:
      dynamic_range_estimate  — dB entre percentil 95 y 5 de los bloques RMS
      histogram_peak_density  — fracción de muestras en los bins extremos
                                (abs(sample) > 0.99). Valores >0.01 indican
                                clipping previo probable.
      silence_ratio           — fracción de bloques con RMS < -60 dBFS
      noise_floor_estimate_db — estimación del noise floor (percentil 10 RMS)
      rms_db                  — RMS global
      peak_db                 — peak global
      suggested_norm_mode     — sugerencia automática de modo ("RMS" | "LUFS" |
                                "PRESERVATIVE" | "NOISE_AWARE" | "ADAPTIVE_BLOCK")
      warnings                — lista de strings con avisos para la GUI
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    n_frames   = len(audio)
    n_channels = audio.shape[1] if audio.ndim == 2 else 1

    # Acumuladores
    peak_global    = 0.0
    sum_sq_global  = 0.0
    n_samples_total = 0
    clip_samples   = 0       # abs > 0.99
    block_rms_list = []
    silent_blocks  = 0
    n_blocks       = 0

    for start in range(0, n_frames, chunk_frames):
        chunk = audio[start:start + chunk_frames]
        if chunk.size == 0:
            continue
        flat   = chunk.ravel()
        absmax = float(np.max(np.abs(flat)))
        if absmax > peak_global:
            peak_global = absmax
        sum_sq_global  += float(np.sum(flat.astype(np.float64) ** 2))
        n_samples_total += len(flat)
        clip_samples    += int(np.sum(np.abs(flat) > 0.99))
        rms_chunk = float(np.sqrt(np.mean(flat.astype(np.float64) ** 2)))
        block_rms_list.append(rms_chunk)
        rms_chunk_db = _norm_linear_to_db(rms_chunk) if rms_chunk > 1e-9 else float("-inf")
        if rms_chunk_db < _CRAC_SILENCE_THR or rms_chunk <= 1e-9:
            silent_blocks += 1
        n_blocks += 1

    if n_blocks == 0 or n_samples_total == 0:
        return {
            "dynamic_range_estimate":  0.0,
            "histogram_peak_density":  0.0,
            "silence_ratio":           1.0,
            "noise_floor_estimate_db": float("-inf"),
            "rms_db":                  float("-inf"),
            "peak_db":                 float("-inf"),
            "suggested_norm_mode":     "PRESERVATIVE",
            "warnings":                ["Audio vacío o completamente silencioso"],
        }

    rms_global_db  = _norm_linear_to_db(
        float(_math.sqrt(sum_sq_global / n_samples_total))
    ) if (sum_sq_global / n_samples_total) > 1e-18 else float("-inf")
    peak_global_db = _norm_linear_to_db(peak_global) if peak_global > 1e-9 else float("-inf")

    # Estadísticas de bloques RMS
    block_rms_arr    = sorted([r for r in block_rms_list if r > 1e-9])
    silence_ratio    = silent_blocks / n_blocks

    if block_rms_arr:
        p05_idx  = max(0, int(len(block_rms_arr) * 0.05) - 1)
        p95_idx  = min(len(block_rms_arr) - 1, int(len(block_rms_arr) * 0.95))
        p10_idx  = max(0, int(len(block_rms_arr) * 0.10) - 1)
        p05_db   = _norm_linear_to_db(block_rms_arr[p05_idx])
        p95_db   = _norm_linear_to_db(block_rms_arr[p95_idx])
        noise_floor_db = _norm_linear_to_db(block_rms_arr[p10_idx])
        dynamic_range  = p95_db - p05_db
    else:
        p05_db = p95_db = noise_floor_db = float("-inf")
        dynamic_range = 0.0

    histogram_peak_density = clip_samples / n_samples_total

    # ── Construcción de warnings y sugerencia de modo ────────────────────────
    warnings_list = []

    if histogram_peak_density > 0.01:
        warnings_list.append(
            f"Clipping previo detectado: {histogram_peak_density*100:.1f}% de muestras "
            f"en zona de saturación (>0.99). Revisar fuente."
        )

    if silence_ratio > 0.40:
        warnings_list.append(
            f"Silencios dominantes: {silence_ratio*100:.0f}% de bloques son silenciosos. "
            f"RMS global puede subestimar el nivel real."
        )

    if dynamic_range < 3.0 and rms_global_db != float("-inf"):
        warnings_list.append(
            f"Rango dinámico muy bajo ({dynamic_range:.1f} dB) — audio posiblemente "
            f"sobrecomprimido o limitado agresivamente."
        )

    if (noise_floor_db != float("-inf") and rms_global_db != float("-inf")
            and (rms_global_db - noise_floor_db) < 12.0
            and rms_global_db < _CRAC_HISS_RMS_MAX):
        warnings_list.append(
            f"Posible hiss dominante: SNR estimado "
            f"{rms_global_db - noise_floor_db:.1f} dB con RMS={rms_global_db:.1f} dBFS."
        )

    # ── Sugerencia automática de modo ────────────────────────────────────────
    # (lógica simplificada — el AUTO completo está en Sistema 5)
    if histogram_peak_density > 0.01:
        suggested = "PRESERVATIVE"
    elif silence_ratio > 0.40:
        suggested = "NOISE_AWARE"
    elif dynamic_range < 3.0:
        suggested = "ADAPTIVE_BLOCK"
    elif (noise_floor_db != float("-inf") and rms_global_db != float("-inf")
          and (rms_global_db - noise_floor_db) < 15.0):
        suggested = "NOISE_AWARE"
    else:
        suggested = "LUFS"

    _log.info("Histograma amplitud: n_blocks=%d  silence_ratio=%.2f  "
              "dynamic_range=%.1f dB  peak_density=%.4f  "
              "noise_floor=%.1f dBFS  rms=%.1f dBFS  peak=%.1f dBFS  "
              "suggested=%s  warnings=%d",
              n_blocks, silence_ratio, dynamic_range,
              histogram_peak_density, noise_floor_db,
              rms_global_db, peak_global_db,
              suggested, len(warnings_list))

    return {
        "dynamic_range_estimate":  round(dynamic_range, 2),
        "histogram_peak_density":  round(histogram_peak_density, 6),
        "silence_ratio":           round(silence_ratio, 4),
        "noise_floor_estimate_db": round(noise_floor_db, 2)
                                   if noise_floor_db != float("-inf") else float("-inf"),
        "rms_db":                  round(rms_global_db, 3)
                                   if rms_global_db != float("-inf") else float("-inf"),
        "peak_db":                 round(peak_global_db, 3)
                                   if peak_global_db != float("-inf") else float("-inf"),
        "p05_rms_db":              round(p05_db, 3) if p05_db != float("-inf") else float("-inf"),
        "p95_rms_db":              round(p95_db, 3) if p95_db != float("-inf") else float("-inf"),
        "n_blocks_analyzed":       n_blocks,
        "suggested_norm_mode":     suggested,
        "warnings":                warnings_list,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  SISTEMA 5 — MODO AUTOMÁTICO INTELIGENTE (AUTO)
# ─────────────────────────────────────────────────────────────────────────────

def _norm_auto_intelligent(audio: np.ndarray, rate: int) -> tuple:
    """
    Modo automático inteligente para usuarios no expertos.

    CRAC analiza el material y selecciona automáticamente el modo óptimo:

      · RMS        — material dinámico normal, SNR bueno
      · LUFS       — contenido con loudness target (podcast, streaming)
      · PRESERVATIVE — material con clipping previo o picos altos
      · NOISE_AWARE — material con ruido dominante (hiss, grabación cassette)
      · ADAPTIVE_BLOCK — material con dinámicas muy variables o silencio dominante

    Principios:
      · PRIORIZAR PRESERVACIÓN antes que loudness.
      · EVITAR decisiones agresivas.
      · Nunca aplicar ganancia si el resultado puede dañar el material.

    Criterios de decisión (en orden de prioridad):
      1. Clipping previo        → PRESERVATIVE (no amplificar material dañado)
      2. Muy corto (<5s)        → PEAK_SIMPLE (análisis estadístico poco fiable)
      3. Silencio >60%          → ADAPTIVE_BLOCK (silencio masivo, por bloques)
      4. SNR < 12 dB            → NOISE_AWARE (hiss/ruido prominente)
      5. Dynamic range < 3 dB  → ADAPTIVE_BLOCK (material sobrecomprimido)
      6. Duración > 3600s       → NOISE_AWARE (sesiones muy largas → cassette)
      7. RMS > -12 dBFS         → PRESERVATIVE (ya está alto, cuidado con headroom)
      8. Default                → LUFS_16 (streaming, balance calidad/loudness)

    Retorna:
      (audio_out, stats) con campo "auto_selected_mode" indicando qué modo
      se seleccionó y "auto_decision_reason" explicando el criterio.
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    dur_s = len(audio) / max(rate, 1)

    _log.info("AUTO mode: analizando %.1f s de audio...", dur_s)

    # ── Análisis estadístico completo ────────────────────────────────────────
    hist = _analyze_amplitude_histogram(audio, rate)
    cf, peak_db, rms_db = _calc_crest_factor(audio)

    clip_density    = hist["histogram_peak_density"]
    silence_ratio   = hist["silence_ratio"]
    dynamic_range   = hist["dynamic_range_estimate"]
    noise_floor_db  = hist["noise_floor_estimate_db"]
    snr_db          = ((rms_db - noise_floor_db)
                       if (rms_db != float("-inf") and noise_floor_db != float("-inf"))
                       else float("inf"))

    # ── Árbol de decisión ────────────────────────────────────────────────────
    selected_mode   = None
    decision_reason = ""

    if clip_density > 0.005:
        selected_mode   = NormalizationMode.PRESERVATIVE
        decision_reason = (
            f"Clipping previo detectado ({clip_density*100:.2f}% muestras saturadas). "
            f"Modo preservativo para no amplificar material dañado."
        )

    elif dur_s < 5.0:
        selected_mode   = NormalizationMode.PEAK_SIMPLE
        decision_reason = (
            f"Audio muy corto ({dur_s:.1f}s) — análisis estadístico poco fiable. "
            f"Peak simple como modo conservador."
        )

    elif silence_ratio > 0.60:
        selected_mode   = NormalizationMode.ADAPTIVE_BLOCK
        decision_reason = (
            f"Silencio dominante ({silence_ratio*100:.0f}% de bloques). "
            f"Adaptativa por bloques para ignorar silencios al calcular ganancia."
        )

    elif snr_db != float("inf") and snr_db < 12.0:
        selected_mode   = NormalizationMode.NOISE_AWARE
        decision_reason = (
            f"SNR bajo ({snr_db:.1f} dB) — posible hiss o ruido de fondo prominente. "
            f"Noise-aware para limitar amplificación del ruido."
        )

    elif dynamic_range < 3.0:
        selected_mode   = NormalizationMode.ADAPTIVE_BLOCK
        decision_reason = (
            f"Rango dinámico muy bajo ({dynamic_range:.1f} dB) — material "
            f"sobrecomprimido o saturado. Adaptativa por bloques para mayor uniformidad."
        )

    elif dur_s > 3600.0:
        selected_mode   = NormalizationMode.NOISE_AWARE
        decision_reason = (
            f"Sesión muy larga ({dur_s/3600:.1f}h) — posiblemente cassette o FM. "
            f"Noise-aware como modo conservador para grabaciones largas."
        )

    elif rms_db != float("-inf") and rms_db > -12.0:
        selected_mode   = NormalizationMode.PRESERVATIVE
        decision_reason = (
            f"RMS ya alto ({rms_db:.1f} dBFS). "
            f"Modo preservativo para evitar sobrecarga del headroom."
        )

    else:
        selected_mode   = NormalizationMode.LUFS_16
        decision_reason = (
            f"Material normal (SNR={snr_db:.1f} dB, "
            f"dynamic_range={dynamic_range:.1f} dB, "
            f"RMS={rms_db:.1f} dBFS). "
            f"LUFS -16 como balance óptimo calidad/loudness."
        )

    _log.info("AUTO seleccionó modo: %s — %s", selected_mode.value, decision_reason)
    for w in hist.get("warnings", []):
        _log.warning("AUTO warning: %s", w)

    # ── Aplicar modo seleccionado ────────────────────────────────────────────
    audio_out, norm_stats = _apply_normalization_advanced(audio, selected_mode, rate)

    # ── Construir stats completos ────────────────────────────────────────────
    combined = dict(norm_stats)
    combined.update({
        "mode":                    "AUTO",
        "auto_selected_mode":      selected_mode.value,
        "auto_decision_reason":    decision_reason,
        "auto_clip_density":       round(clip_density, 6),
        "auto_silence_ratio":      round(silence_ratio, 4),
        "auto_dynamic_range":      round(dynamic_range, 2),
        "auto_snr_db":             round(snr_db, 2) if snr_db != float("inf") else None,
        "auto_crest_factor_db":    round(cf, 2) if cf != float("inf") else None,
        "auto_duration_s":         round(dur_s, 1),
        "auto_noise_floor_db":     (round(noise_floor_db, 2)
                                    if noise_floor_db != float("-inf") else float("-inf")),
        # Campos del histograma (requeridos por GUI)
        "dynamic_range_estimate":  hist["dynamic_range_estimate"],
        "histogram_peak_density":  hist["histogram_peak_density"],
        "silence_ratio":           hist["silence_ratio"],
        "auto_warnings":           hist.get("warnings", []),
    })
    return audio_out, combined


# ─────────────────────────────────────────────────────────────────────────────
#  DISPATCHER PRINCIPAL — _apply_normalization_advanced
# ─────────────────────────────────────────────────────────────────────────────

def _apply_normalization_advanced(audio: np.ndarray,
                                   mode: NormalizationMode,
                                   rate: int) -> tuple:
    """
    Dispatcher que enruta al algoritmo correcto según el NormalizationMode.

    Garantías:
      · Siempre retorna float32 en [-1, 1].
      · En caso de error en cualquier modo: fallback a peak simple -0.2 dBFS
        con log de error (sin crash del hilo de exportación).
      · Nunca modifica _status ni accede a la GUI (thread-safe).
      · Siempre retorna (audio_out: np.ndarray, stats: dict).

    El llamador (export()) es responsable de actualizar _status con stats.
    """
    # Asegurar float32 de entrada
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)
    # Asegurar 2D (siempre estéreo en CRAC)
    if audio.ndim == 1:
        audio = audio.reshape(-1, 1)

    try:
        if mode == NormalizationMode.NONE:
            return np.clip(audio, -1.0, 1.0), {"mode": "NONE", "gain_db": 0.0,
                                                 "peak_db": 0.0, "lufs": float("-inf"),
                                                 "noise_floor_db": float("-inf"),
                                                 "true_peak_db": 0.0}

        elif mode == NormalizationMode.PEAK_SIMPLE:
            # Modo heredado: peak a -0.2 dBFS
            pk = float(np.max(np.abs(audio)))
            if pk < 1e-9:
                return np.clip(audio, -1.0, 1.0), {"mode": "PEAK_SIMPLE", "gain_db": 0.0,
                                                     "peak_db": float("-inf"), "lufs": float("-inf"),
                                                     "noise_floor_db": float("-inf"), "true_peak_db": float("-inf")}
            gain    = _norm_db_to_linear(-0.2) / pk
            gain_db = _norm_linear_to_db(gain)
            return (np.clip(audio * np.float32(gain), -1.0, 1.0),
                    {"mode": "PEAK_SIMPLE", "gain_db": gain_db,
                     "peak_db": _norm_linear_to_db(pk), "lufs": float("-inf"),
                     "noise_floor_db": float("-inf"),
                     "true_peak_db": _norm_linear_to_db(pk) + gain_db})

        elif mode == NormalizationMode.RMS_20:
            return _norm_rms(audio, rate, target_rms_db=-20.0)
        elif mode == NormalizationMode.RMS_18:
            return _norm_rms(audio, rate, target_rms_db=-18.0)
        elif mode == NormalizationMode.RMS_14:
            return _norm_rms(audio, rate, target_rms_db=-14.0)

        elif mode == NormalizationMode.LUFS_23:
            return _norm_lufs(audio, rate, target_lufs=-23.0)
        elif mode == NormalizationMode.LUFS_16:
            return _norm_lufs(audio, rate, target_lufs=-16.0)
        elif mode == NormalizationMode.LUFS_14:
            return _norm_lufs(audio, rate, target_lufs=-14.0)

        elif mode == NormalizationMode.INTELLIGENT_PEAK:
            return _norm_intelligent_peak(audio, rate, percentile=99.9)

        elif mode == NormalizationMode.TRUE_PEAK:
            return _norm_true_peak(audio, rate, oversample=2)
        elif mode == NormalizationMode.TRUE_PEAK_X4:
            return _norm_true_peak(audio, rate, oversample=4)

        elif mode == NormalizationMode.PRESERVATIVE:
            return _norm_preservative(audio, rate, ceiling_db=-6.0)

        elif mode == NormalizationMode.NOISE_AWARE:
            return _norm_noise_aware(audio, rate)

        elif mode == NormalizationMode.ADAPTIVE_BLOCK:
            return _norm_adaptive_block(audio, rate)

        # ── CRAC 0.20 — nuevos modos ─────────────────────────────────────────
        elif mode == NormalizationMode.MID_SIDE:
            # Normalización Mid/Side con protección de expansión estéreo.
            # Usa RMS_18 por defecto sobre Mid y Side separadamente.
            return _norm_mid_side(audio, rate,
                                  ms_norm_mode=NormalizationMode.RMS_18,
                                  max_side_gain_db=6.0,
                                  max_stereo_balance_index=0.70)

        elif mode == NormalizationMode.CREST_GUARD:
            # Preservación de microdinámica: normaliza con RMS_18 pero
            # limita la ganancia si el crest factor cae bajo el mínimo.
            return _apply_with_crest_guard(audio, rate,
                                           norm_mode=NormalizationMode.RMS_18,
                                           min_crest_factor_db=_CRAC_MIN_CF_DEFAULT)

        elif mode == NormalizationMode.AUTO:
            # Modo automático inteligente — analiza el material y elige.
            return _norm_auto_intelligent(audio, rate)

        else:
            # Modo desconocido: fallback a peak simple
            _log.warning("Modo de normalización desconocido: %s — fallback a PEAK_SIMPLE", mode)
            return _apply_normalization_advanced(audio, NormalizationMode.PEAK_SIMPLE, rate)

    except Exception as exc:
        _log.error("Error en normalización [%s]: %s — fallback a peak simple",
                   mode, exc, exc_info=True)
        # Fallback seguro: peak a -0.2 dBFS sin crash
        try:
            pk = float(np.max(np.abs(audio)))
            if pk > 1e-9:
                audio = np.clip(audio * np.float32(_norm_db_to_linear(-0.2) / pk), -1.0, 1.0)
        except Exception:
            audio = np.clip(audio, -1.0, 1.0)
        return audio.astype(np.float32), {
            "mode": f"FALLBACK_FROM_{mode}",
            "error": str(exc),
            "gain_db": 0.0, "peak_db": 0.0,
            "lufs": float("-inf"), "noise_floor_db": float("-inf"),
            "true_peak_db": 0.0,
        }
