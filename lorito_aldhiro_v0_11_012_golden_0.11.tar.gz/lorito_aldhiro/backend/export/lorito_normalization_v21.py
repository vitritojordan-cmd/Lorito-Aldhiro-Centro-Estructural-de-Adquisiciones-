from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Extensión de los modos de normalización a la versión 21 del catálogo.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import time
from enum import Enum, auto
import math as _math
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.export.lorito_normalization import _norm_db_to_linear
from lorito_aldhiro.backend.core.lorito_patches import _db_to_lin, _lin_to_db
from lorito_aldhiro.backend.playback.lorito_tape_presets import TAPE_PRESETS



# ─────────────────────────────────────────────────────────────────────────────
#  NORMALIZACIÓN CON PRESET DE CINTA
# ─────────────────────────────────────────────────────────────────────────────

def _norm_with_tape_preset(audio: np.ndarray,
                           rate: int,
                           preset: TapePreset) -> tuple:
    """
    Normalización inteligente usando un TapePreset.

    Algoritmo adaptativo:
      1. Análisis del material (noise floor, RMS, crest factor, clipping).
      2. Decisión de modo basada en el preset + características detectadas.
      3. Aplicación con parámetros del preset.
      4. Activación automática del soft limiter si el resultado supera el ceiling.

    Retorna: (audio_out, stats_dict)
    stats_dict incluye:
      preset_name, preset_display_name,
      auto_normalization_decision, auto_normalization_reason,
      + todos los campos estándar de normalización.
    """

    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    dur_s = len(audio) / max(rate, 1)
    _log.info("TapePreset [%s]: analizando %.1f s @ %d Hz",
              preset.name, dur_s, rate)

    # ── Análisis del material ─────────────────────────────────────────────────
    peak_linear = float(np.max(np.abs(audio)))
    if peak_linear < 1e-9:
        return audio.copy(), {
            "preset_name": preset.name,
            "preset_display_name": preset.display_name,
            "mode": f"PRESET_{preset.name}",
            "auto_normalization_decision": "silent",
            "auto_normalization_reason": "Señal silenciosa — sin procesamiento.",
            "gain_db": 0.0, "peak_db": float("-inf"),
            "lufs": float("-inf"), "noise_floor_db": float("-inf"),
            "true_peak_db": float("-inf"), "rms_db": float("-inf"),
        }

    peak_db = _lin_to_db(peak_linear)
    rms_linear = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2)))
    rms_db = _lin_to_db(rms_linear)
    cf_db = peak_db - rms_db if rms_linear > 1e-9 else float("inf")

    # Estimar noise floor (percentil 5 de bloques RMS de 100ms)
    block_f = max(1, int(0.100 * rate))
    block_rmss = []
    for start in range(0, len(audio) - block_f, block_f * 4):
        chunk = audio[start:start + block_f].astype(np.float64)
        rms_b = float(np.sqrt(np.mean(chunk ** 2)))
        if rms_b > 1e-12:
            block_rmss.append(rms_b)

    if block_rmss:
        block_rmss.sort()
        p5_idx = max(0, int(len(block_rmss) * 0.05))
        noise_floor_db = _lin_to_db(block_rmss[p5_idx])
    else:
        noise_floor_db = rms_db

    snr_db = rms_db - noise_floor_db if noise_floor_db != float("-inf") else float("inf")
    clip_density = float(np.mean(np.abs(audio) >= 0.9990))

    # ── Árbol de decisión adaptativa al preset ────────────────────────────────
    decision = "rms"
    reason   = ""

    if clip_density > 0.001:
        decision = "preservative"
        reason   = (f"Clipping previo ({clip_density*100:.3f}% muestras) — "
                    f"modo preservativo para no amplificar material saturado.")

    elif dur_s < 3.0:
        decision = "peak_simple"
        reason   = (f"Audio muy corto ({dur_s:.1f}s) — peak simple conservador.")

    elif noise_floor_db > preset.hiss_tolerance_db:
        decision = "noise_aware"
        reason   = (f"Noise floor ({noise_floor_db:.1f} dBFS) supera tolerancia "
                    f"del preset ({preset.hiss_tolerance_db:.1f} dBFS). "
                    f"Noise-aware con target RMS {preset.target_rms_db:.1f} dBFS.")

    elif cf_db < preset.min_crest_factor_db and cf_db != float("inf"):
        decision = "crest_guard"
        reason   = (f"Crest factor ({cf_db:.1f} dB) por debajo del mínimo del preset "
                    f"({preset.min_crest_factor_db:.1f} dB). "
                    f"Crest Guard para preservar microdinámica.")

    elif preset.prefer_rms:
        decision = "rms"
        reason   = (f"Preset {preset.name} prefiere RMS. "
                    f"Target: {preset.target_rms_db:.1f} dBFS.")

    else:
        decision = "lufs"
        reason   = (f"Preset {preset.name} prefiere LUFS. "
                    f"Target: {preset.target_lufs:.1f} LUFS.")

    _log.info("TapePreset [%s] decisión: %s — %s", preset.name, decision, reason)

    # ── Aplicar normalización ─────────────────────────────────────────────────
    try:
        # NOTA MODULARIZACION: el original hacia "from __main__ import (...)"
        # para tomar estas funciones del script principal. En la version
        # modular viven en backend.normalization / backend.audio_backend.
        from lorito_aldhiro.backend.export.lorito_normalization import (
            _norm_rms, _norm_lufs, _norm_preservative,
            _norm_noise_aware, _apply_with_crest_guard,
            _apply_normalization_advanced,
        )
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
    except ImportError:
        # Fallback si se ejecuta el patch de forma aislada
        _log.error("TapePreset: no se pudo importar funciones de normalización del módulo principal.")
        return audio.copy(), {
            "preset_name": preset.name,
            "auto_normalization_decision": "import_error",
            "auto_normalization_reason": "Módulo principal no disponible.",
            "gain_db": 0.0, "peak_db": peak_db,
            "lufs": float("-inf"), "noise_floor_db": noise_floor_db,
            "true_peak_db": peak_db, "rms_db": rms_db, "mode": f"PRESET_{preset.name}",
        }

    if decision == "rms":
        audio_out, norm_stats = _norm_rms(
            audio, rate,
            target_rms_db=preset.target_rms_db,
            ceiling_db=preset.ceiling_db,
            max_gain_db=preset.max_gain_db,
        )
    elif decision == "lufs":
        audio_out, norm_stats = _norm_lufs(
            audio, rate,
            target_lufs=preset.target_lufs,
            ceiling_db=preset.ceiling_db,
            max_gain_db=preset.max_gain_db,
        )
    elif decision == "noise_aware":
        audio_out, norm_stats = _norm_noise_aware(
            audio, rate,
            target_rms_db=preset.target_rms_db,
            max_gain_db=preset.max_gain_db,
            ceiling_db=preset.ceiling_db,
        )
    elif decision == "preservative":
        audio_out, norm_stats = _norm_preservative(
            audio, rate,
            ceiling_db=preset.ceiling_db,
            max_gain_db=preset.max_gain_db,
        )
    elif decision == "crest_guard":
        audio_out, norm_stats = _apply_with_crest_guard(
            audio, rate,
            norm_mode=NormalizationMode.RMS_18,
            min_crest_factor_db=preset.min_crest_factor_db,
            ceiling_db=preset.ceiling_db,
            max_gain_db=preset.max_gain_db,
        )
    else:  # peak_simple fallback
        pk = float(np.max(np.abs(audio)))
        gain = _norm_db_to_linear(preset.ceiling_db) / max(pk, 1e-9)
        max_gain_linear = _norm_db_to_linear(preset.max_gain_db)
        if gain > max_gain_linear:
            gain = max_gain_linear
        audio_out = np.clip(audio * np.float32(gain), -1.0, 1.0)
        norm_stats = {
            "mode": "PEAK_SIMPLE",
            "gain_db": _lin_to_db(gain),
            "peak_db": _lin_to_db(pk),
            "lufs": float("-inf"),
            "noise_floor_db": noise_floor_db,
            "true_peak_db": _lin_to_db(pk) + _lin_to_db(gain),
        }

    # ── Soft limiter post-normalización (si hay overs) ────────────────────────
    audio_out, limiter_stats = _soft_limiter_conservative(
        audio_out, ceiling_db=preset.ceiling_db
    )

    # ── Construir stats completos ─────────────────────────────────────────────
    combined = dict(norm_stats)
    combined.update({
        "preset_name":                  preset.name,
        "preset_display_name":          preset.display_name,
        "mode":                         f"PRESET_{preset.name}",
        "auto_normalization_decision":  decision,
        "auto_normalization_reason":    reason,
        "preset_target_rms_db":         preset.target_rms_db,
        "preset_target_lufs":           preset.target_lufs,
        "preset_ceiling_db":            preset.ceiling_db,
        "preset_hiss_tolerance_db":     preset.hiss_tolerance_db,
        "preset_min_crest_factor_db":   preset.min_crest_factor_db,
        "noise_floor_db":               round(noise_floor_db, 2),
        "snr_db":                       round(snr_db, 2) if snr_db != float("inf") else None,
        "clip_density":                 round(clip_density, 6),
        "crest_factor_input_db":        round(cf_db, 2) if cf_db != float("inf") else None,
        "soft_limiter_triggered":       limiter_stats.get("triggered", False),
        "soft_limiter_reduction_db":    limiter_stats.get("max_reduction_db", 0.0),
        "preset_note":                  preset.note,
    })

    _log.info("TapePreset [%s] completado: gain=%.2f dB  decision=%s  "
              "limiter_triggered=%s",
              preset.name,
              combined.get("gain_db", 0.0),
              decision,
              limiter_stats.get("triggered", False))

    return audio_out, combined


# ─────────────────────────────────────────────────────────────────────────────
#  2. NUEVOS MODOS EN NormalizationMode (extensión de enum)
# ─────────────────────────────────────────────────────────────────────────────
# Python no permite reabrir un Enum — los nuevos valores se añaden como
# un Enum separado y se registra un dispatcher en el parche.

class NormalizationModeV21(Enum):
    """Modos adicionales introducidos en CRAC v0.21."""
    # Presets de cinta
    PRESET_TYPE_I      = "Preset: Type I Ferric"
    PRESET_TYPE_II     = "Preset: Type II Chrome"
    PRESET_TYPE_IV     = "Preset: Type IV Metal"
    PRESET_VOICE       = "Preset: Voice/Dictaphone"
    PRESET_FM          = "Preset: Radio FM Broadcast"
    PRESET_MICRO       = "Preset: Microcassette"
    PRESET_VHS_HIFI    = "Preset: VHS HiFi Audio"
    PRESET_REEL        = "Preset: Reel-to-Reel Transfer"
    # Análisis en dos pasadas
    TWO_PASS           = "Análisis 2-pass (profundo)"
    # Soft limiter como modo standalone (protección de exportación)
    SOFT_LIMIT_ONLY    = "Soft-limit (protección overs)"

    @classmethod
    def from_label(cls, label: str) -> Optional["NormalizationModeV21"]:
        for m in cls:
            if m.value == label:
                return m
        return None


# Etiquetas a añadir al QComboBox norm_box
NORM_ITEMS_V21 = [m.value for m in NormalizationModeV21]

# Mapeo display_name → TapePreset para el dispatcher
_PRESET_MODE_MAP = {
    NormalizationModeV21.PRESET_TYPE_I:   TAPE_PRESETS["TYPE_I_FERRIC"],
    NormalizationModeV21.PRESET_TYPE_II:  TAPE_PRESETS["TYPE_II_CHROME"],
    NormalizationModeV21.PRESET_TYPE_IV:  TAPE_PRESETS["TYPE_IV_METAL"],
    NormalizationModeV21.PRESET_VOICE:    TAPE_PRESETS["VOICE_TAPE"],
    NormalizationModeV21.PRESET_FM:       TAPE_PRESETS["RADIO_FM"],
    NormalizationModeV21.PRESET_MICRO:    TAPE_PRESETS["MICROCASSETTE"],
    NormalizationModeV21.PRESET_VHS_HIFI: TAPE_PRESETS["VHS_HIFI"],
    NormalizationModeV21.PRESET_REEL:     TAPE_PRESETS["REEL_TRANSFER"],
}


def _dispatch_v21(audio: np.ndarray,
                  mode_label: str,
                  rate: int) -> Optional[tuple]:
    """
    Dispatcher de modos v0.21.
    Retorna (audio_out, stats) si mode_label corresponde a un modo v0.21,
    o None si el label debe ser manejado por el dispatcher original (v0.20).

    Uso desde export():
        result = _dispatch_v21(audio_raw, norm_val, rate)
        if result is not None:
            audio_raw, _norm_stats = result
        else:
            audio_raw, _norm_stats = _apply_normalization_advanced(audio_raw, _norm_mode, rate)
    """
    mode_v21 = NormalizationModeV21.from_label(mode_label)
    if mode_v21 is None:
        return None

    if mode_v21 in _PRESET_MODE_MAP:
        preset = _PRESET_MODE_MAP[mode_v21]
        return _norm_with_tape_preset(audio, rate, preset)

    if mode_v21 == NormalizationModeV21.TWO_PASS:
        return _two_pass_analysis(audio, rate)

    if mode_v21 == NormalizationModeV21.SOFT_LIMIT_ONLY:
        return _soft_limit_only_mode(audio, rate)

    return None


# ─────────────────────────────────────────────────────────────────────────────
#  3. SOFT LIMITER CONSERVADOR
# ─────────────────────────────────────────────────────────────────────────────

def _soft_limiter_conservative(audio: np.ndarray,
                                ceiling_db: float = -0.2,
                                knee_db: float = 6.0,
                                attack_frames: int = 64,
                                release_frames: int = 2048) -> tuple:
    """
    Soft limiter extremadamente conservador para proteger exportaciones.

    FILOSOFÍA:
      · SOLO actúa si hay muestras por encima del ceiling (overs).
      · NO es compresor: no altera señales por debajo del knee inferior.
      · Mínimo impacto dinámico: solo salva overs ocasionales.
      · Totalmente transparente cuando no hay overs.

    ALGORITMO (knee suave):
      · Zona transparente: sample ≤ ceiling - knee_db  → sin cambio
      · Zona de knee:      ceiling - knee_db < sample ≤ ceiling
                           → reducción cuadrática suave (no lineal)
      · Zona hard limit:   sample > ceiling
                           → reducción al ceiling con ataque/release suaves

    PARÁMETROS:
      ceiling_db    — nivel máximo de salida en dBFS (default: -0.2 dBFS)
      knee_db       — ancho del knee suave en dB (default: 6 dB)
      attack_frames — ventana de ataque en frames (default: 64 ≈ 1.3ms @48k)
      release_frames— ventana de release en frames (default: 2048 ≈ 42ms @48k)

    RETORNA:
      (audio_out, stats) donde stats incluye:
        triggered           — bool: True si se aplicó reducción
        max_reduction_db    — máxima reducción puntual en dB
        n_overs_input       — muestras sobre ceiling antes del limiter
        n_overs_output      — muestras sobre ceiling después (debe ser 0)
        ceiling_db          — ceiling usado
        knee_db             — knee usado
    """
    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    ceiling_lin   = _db_to_lin(ceiling_db)
    knee_low_lin  = _db_to_lin(ceiling_db - knee_db)
    knee_range    = ceiling_lin - knee_low_lin  # ancho del knee en lineal

    # Check rápido: ¿hay overs en absoluto?
    peak_in = float(np.max(np.abs(audio)))
    n_overs_input = int(np.sum(np.abs(audio) > ceiling_lin * 1.0001))

    if n_overs_input == 0:
        # Ningún over → retornar sin modificaciones (100% transparente)
        return audio.copy(), {
            "triggered":         False,
            "max_reduction_db":  0.0,
            "n_overs_input":     0,
            "n_overs_output":    0,
            "ceiling_db":        ceiling_db,
            "knee_db":           knee_db,
        }

    _log.info("SoftLimiter: %d overs detectados (peak=%.3f dBFS, ceiling=%.1f dBFS) — activando",
              n_overs_input, _lin_to_db(peak_in), ceiling_db)

    # Trabajar en float64 para mayor precisión en el cálculo de ganancia
    audio_f64 = audio.astype(np.float64)
    n_samples = audio_f64.shape[0]
    n_ch      = audio_f64.shape[1] if audio_f64.ndim > 1 else 1

    # Calcular nivel pico instantáneo (max de todos los canales por muestra)
    if audio_f64.ndim > 1:
        inst_peak = np.max(np.abs(audio_f64), axis=1)  # (n_samples,)
    else:
        inst_peak = np.abs(audio_f64)

    # ── Calcular gain_reduction per sample ────────────────────────────────────
    gain = np.ones(n_samples, dtype=np.float64)

    # Zona transparente: inst_peak <= knee_low_lin → gain = 1.0 (ya inicializado)

    # Zona de knee suave: knee_low_lin < inst_peak <= ceiling_lin
    knee_mask = (inst_peak > knee_low_lin) & (inst_peak <= ceiling_lin)
    if np.any(knee_mask):
        # Reducción cuadrática: gain = 1 - 0.5 * ((x - knee_low) / knee_range)²
        x_knee = (inst_peak[knee_mask] - knee_low_lin) / knee_range  # [0, 1]
        gain[knee_mask] = 1.0 - 0.5 * (x_knee ** 2)

    # Zona hard limit: inst_peak > ceiling_lin
    over_mask = inst_peak > ceiling_lin
    if np.any(over_mask):
        gain[over_mask] = ceiling_lin / np.maximum(inst_peak[over_mask], 1e-12)

    # ── Suavizado de la curva de ganancia (ataque/release) ────────────────────
    # Ataque: la reducción no puede caer más rápido que el slew rate de ataque
    # Release: la reducción no puede subir más rápido que el slew rate de release
    # Implementación: filtro de tiempo unilateral (peak holder + release exponencial)
    attack_coef  = 1.0 - _math.exp(-1.0 / max(attack_frames, 1))
    release_coef = 1.0 - _math.exp(-1.0 / max(release_frames, 1))

    smoothed_gain = np.ones(n_samples, dtype=np.float64)
    g_prev = 1.0
    for i in range(n_samples):
        g_target = gain[i]
        if g_target < g_prev:
            # Ataque: perseguir reducción rápidamente
            g_new = g_prev + attack_coef * (g_target - g_prev)
        else:
            # Release: recuperar lentamente
            g_new = g_prev + release_coef * (g_target - g_prev)
        g_new = min(1.0, max(g_new, 1e-6))
        smoothed_gain[i] = g_new
        g_prev = g_new

    # ── Aplicar ganancia ──────────────────────────────────────────────────────
    if audio_f64.ndim > 1:
        gain_2d = smoothed_gain.reshape(-1, 1)
        audio_out = np.clip(audio_f64 * gain_2d, -1.0, 1.0).astype(np.float32)
    else:
        audio_out = np.clip(audio_f64 * smoothed_gain, -1.0, 1.0).astype(np.float32)

    # ── Estadísticas ──────────────────────────────────────────────────────────
    n_overs_output  = int(np.sum(np.abs(audio_out) > ceiling_lin * 1.0001))
    min_gain        = float(np.min(smoothed_gain))
    max_reduction_db = -_lin_to_db(min_gain) if min_gain > 1e-9 else 0.0

    _log.info("SoftLimiter completado: overs_in=%d overs_out=%d "
              "max_reduction=%.2f dB",
              n_overs_input, n_overs_output, max_reduction_db)

    if n_overs_output > 0:
        _log.warning("SoftLimiter: %d overs residuales post-limitación — "
                     "ceiling muy cercano al peak de entrada", n_overs_output)

    return audio_out, {
        "triggered":         True,
        "max_reduction_db":  round(max_reduction_db, 3),
        "n_overs_input":     n_overs_input,
        "n_overs_output":    n_overs_output,
        "ceiling_db":        ceiling_db,
        "knee_db":           knee_db,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  3b. SOFT-LIMIT COMO MODO STANDALONE — _soft_limit_only_mode()
# ─────────────────────────────────────────────────────────────────────────────

def _soft_limit_only_mode(audio: np.ndarray,
                           rate: int,
                           ceiling_db: float = -0.2,
                           knee_db: float = 6.0) -> tuple:
    """
    Modo de normalización standalone: Soft-limit (protección overs).

    FILOSOFÍA:
      · NO aplica ninguna ganancia de normalización al audio.
      · SOLO actúa si hay muestras por encima del ceiling (overs).
      · Equivale a ejecutar _soft_limiter_conservative() sin etapa previa de
        normalización: cero impacto dinámico si el material ya está bajo el
        ceiling.
      · Uso ideal: exportar sin cambio de nivel pero con protección frente a
        clipping accidental causado por cuantización, dithering o conversión
        de formato.

    CUÁNDO USAR:
      · Material bien grabado que no necesita ajuste de ganancia.
      · Proteger exportaciones de archivos cuyo peak esté muy próximo a 0 dBFS.
      · Compilaciones donde cada pista tiene su propio nivel y no se desea
        normalización global.

    PARÁMETROS:
      ceiling_db  — nivel máximo de salida en dBFS (default: -0.2 dBFS)
      knee_db     — ancho del knee suave en dB (default: 6 dB)

    RETORNA:
      (audio_out, stats_dict) compatible con el dispatcher de export().
      stats_dict incluye todos los campos estándar de normalización, más:
        soft_limit_only     — True (marca el modo)
        triggered           — bool: True si se aplicó reducción
        max_reduction_db    — máxima reducción puntual en dB
        n_overs_input       — muestras sobre ceiling antes
        n_overs_output      — muestras sobre ceiling después (debe ser 0)
    """

    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    # Métricas pre-procesado (para stats / telemetría)
    peak_in_lin  = float(np.max(np.abs(audio))) if audio.size > 0 else 0.0
    peak_in_db   = _lin_to_db(peak_in_lin) if peak_in_lin > 1e-9 else float("-inf")
    rms_lin      = float(np.sqrt(np.mean(audio.astype(np.float64) ** 2))) if audio.size > 0 else 0.0
    rms_db       = _lin_to_db(rms_lin) if rms_lin > 1e-9 else float("-inf")

    _log.info(
        "SoftLimitOnly: peak_in=%.2f dBFS  rms=%.2f dBFS  ceiling=%.1f dBFS  knee=%.1f dB",
        peak_in_db, rms_db, ceiling_db, knee_db
    )

    # Delegar en _soft_limiter_conservative() — toda la lógica real está allí
    audio_out, limiter_stats = _soft_limiter_conservative(
        audio,
        ceiling_db=ceiling_db,
        knee_db=knee_db,
    )

    # Métricas post-procesado
    peak_out_lin = float(np.max(np.abs(audio_out))) if audio_out.size > 0 else 0.0
    peak_out_db  = _lin_to_db(peak_out_lin) if peak_out_lin > 1e-9 else float("-inf")

    triggered       = limiter_stats.get("triggered", False)
    max_reduc_db    = limiter_stats.get("max_reduction_db", 0.0)
    n_overs_in      = limiter_stats.get("n_overs_input",  0)
    n_overs_out     = limiter_stats.get("n_overs_output", 0)

    if triggered:
        _log.info(
            "SoftLimitOnly: ACTIVADO — %d overs reducidos  max_reduction=%.2f dB"
            "  peak_out=%.2f dBFS",
            n_overs_in, max_reduc_db, peak_out_db
        )
    else:
        _log.info("SoftLimitOnly: sin overs — audio inalterado (100%% transparente)")

    stats = {
        # Identificación del modo
        "mode":                     "SOFT_LIMIT_ONLY",
        "soft_limit_only":          True,
        # Campos estándar de normalización (sin ganancia: gain_db = 0)
        "gain_db":                  0.0,
        "peak_db":                  peak_in_db,
        "rms_db":                   rms_db,
        "lufs":                     float("-inf"),   # no medido en este modo
        "noise_floor_db":           float("-inf"),   # no medido en este modo
        "true_peak_db":             peak_in_db,      # aproximación conservadora
        # Resultado del limiter
        "soft_limiter_triggered":   triggered,
        "soft_limiter_reduction_db": max_reduc_db,
        "n_overs_input":            n_overs_in,
        "n_overs_output":           n_overs_out,
        "ceiling_db_used":          ceiling_db,
        "knee_db_used":             knee_db,
        "peak_out_db":              peak_out_db,
        # Campos v0.21 extendidos
        "pre_normalization_gain_db":  0.0,
        "post_normalization_gain_db": 0.0,
        "mid_rms":                    float("-inf"),
        "side_rms":                   float("-inf"),
        "stereo_balance_index":       0.0,
        "crest_factor_db":            float("inf"),
        "dynamic_range_estimate":     0.0,
        "histogram_peak_density":     0.0,
        "silence_ratio":              0.0,
        "auto_selected_mode":         "",
        "auto_normalization_decision": "soft_limit_only",
        "auto_normalization_reason":  (
            "Soft-limit standalone: sin normalización de ganancia. "
            + (f"{n_overs_in} overs reducidos ({max_reduc_db:.2f} dB max)."
               if triggered else "Sin overs — audio inalterado.")
        ),
    }

    return audio_out, stats


# ─────────────────────────────────────────────────────────────────────────────
#  4. ANÁLISIS EN DOS PASADAS — _two_pass_analysis()
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TwoPassAnalysis:
    """Resultado del análisis de PASS 1."""
    # Métricas globales
    peak_db:            float = float("-inf")
    rms_db:             float = float("-inf")
    noise_floor_db:     float = float("-inf")
    true_peak_db:       float = float("-inf")
    # Histograma
    clip_density:       float = 0.0
    silence_ratio:      float = 0.0
    dynamic_range_db:   float = 0.0
    # Percentiles de bloques RMS
    p05_rms_db:         float = float("-inf")
    p25_rms_db:         float = float("-inf")
    p50_rms_db:         float = float("-inf")  # mediana
    p75_rms_db:         float = float("-inf")
    p95_rms_db:         float = float("-inf")
    # Drift exportador (picos no esperados al inicio/final)
    export_drift_detected: bool = False
    export_drift_db:       float = 0.0
    # Duración y tasa
    duration_s:         float = 0.0
    sample_rate:        int   = 48000
    n_channels:         int   = 2
    n_frames:           int   = 0
    n_blocks_analyzed:  int   = 0
    # Decisión sugerida
    suggested_mode:     str   = ""
    suggested_reason:   str   = ""
    warnings:           List[str] = field(default_factory=list)


def _two_pass_analysis(audio: np.ndarray,
                       rate: int,
                       chunk_size: int = 65536) -> tuple:
    """
    Normalización con análisis previo en dos pasadas.

    PASS 1 — Análisis chunked (sin cargar todo en RAM):
      · Noise floor (percentil 5 de bloques RMS de 100ms)
      · Peak global y por canales
      · RMS global
      · Histograma de amplitud por bins
      · Detección de clipping
      · Percentiles de bloques RMS (p05, p25, p50, p75, p95)
      · Drift exportador: detección de nivel anormalmente bajo al inicio/final
        (indica silencio de cabezal o fade incorrecto)

    PASS 2 — Normalización óptima basada en el análisis:
      · Modo elegido según el análisis (árbol de decisión mejorado)
      · Aplicación con parámetros refinados por los percentiles
      · Soft limiter post-normalización automático

    Funciona chunked: tolera archivos enormes sin RAM spikes.
    El array completo es necesario para PASS 2 (normalización), pero el
    análisis de PASS 1 solo necesita un bloque en RAM a la vez.

    Retorna: (audio_out, stats_dict)
    """

    if audio.dtype != np.float32:
        audio = audio.astype(np.float32)

    n_frames  = len(audio)
    n_ch      = audio.shape[1] if audio.ndim > 1 else 1
    dur_s     = n_frames / max(rate, 1)

    _log.info("TwoPass PASS 1: analizando %.1f s (%d frames) chunked...", dur_s, n_frames)

    # ── PASS 1: análisis chunked ──────────────────────────────────────────────
    block_f    = max(1, int(0.100 * rate))    # 100ms por bloque de análisis
    peak_global = 0.0
    sum_sq      = 0.0
    n_sq        = 0
    n_clips     = 0
    n_silence   = 0
    block_rmss  = []
    block_peaks = []

    # Histograma de amplitud (256 bins de 0 a 1)
    hist_bins = 256
    hist      = np.zeros(hist_bins, dtype=np.int64)

    t_pass1_start = time.monotonic()

    for start in range(0, n_frames, block_f):
        chunk = audio[start:start + block_f]
        chunk_abs = np.abs(chunk)

        # Peak
        chunk_peak = float(np.max(chunk_abs))
        if chunk_peak > peak_global:
            peak_global = chunk_peak

        # RMS del bloque
        chunk_sq = float(np.sum(chunk.astype(np.float64) ** 2))
        chunk_n  = chunk.size
        sum_sq  += chunk_sq
        n_sq    += chunk_n

        chunk_rms = _math.sqrt(chunk_sq / max(chunk_n, 1))
        block_rmss.append(chunk_rms)
        block_peaks.append(chunk_peak)

        # Clipping
        n_clips += int(np.sum(chunk_abs >= 0.9990))

        # Silencio (umbral -60 dBFS ≈ 0.001 lineal)
        if chunk_rms < 0.001:
            n_silence += 1

        # Histograma de amplitud
        if chunk_abs.size > 0:
            bins_idx = np.minimum(
                (chunk_abs.flatten() * hist_bins).astype(np.int32),
                hist_bins - 1
            )
            for bi in bins_idx:
                hist[bi] += 1

    t_pass1 = time.monotonic() - t_pass1_start

    # ── Calcular métricas globales ────────────────────────────────────────────
    rms_global = _math.sqrt(sum_sq / max(n_sq, 1))
    peak_db    = _lin_to_db(peak_global)
    rms_db     = _lin_to_db(rms_global)
    cf_db      = peak_db - rms_db if rms_global > 1e-9 else float("inf")

    # Percentiles de bloques RMS
    sorted_rmss = sorted(r for r in block_rmss if r > 1e-12)
    n_b = len(sorted_rmss)
    if n_b > 0:
        def _pct_db(p):
            idx = max(0, min(n_b - 1, int(n_b * p)))
            return _lin_to_db(sorted_rmss[idx])
        p05_db = _pct_db(0.05)
        p25_db = _pct_db(0.25)
        p50_db = _pct_db(0.50)
        p75_db = _pct_db(0.75)
        p95_db = _pct_db(0.95)
        noise_floor_db = _pct_db(0.05)
    else:
        p05_db = p25_db = p50_db = p75_db = p95_db = rms_db
        noise_floor_db = rms_db

    # Métricas del histograma
    total_h       = int(np.sum(hist))
    clip_bin_start= max(0, int(hist_bins * 0.999))
    clip_density  = float(np.sum(hist[clip_bin_start:])) / max(total_h, 1)
    silence_ratio = n_silence / max(len(block_rmss), 1)
    dynamic_range = p95_db - p05_db if (p95_db != float("-inf") and
                                         p05_db != float("-inf")) else 0.0

    snr_db = rms_db - noise_floor_db if noise_floor_db != float("-inf") else float("inf")

    # Estimación True Peak simplificada (interpolación lineal × 2)
    # Para un análisis exacto se usaría _norm_true_peak, pero es costoso en PASS 1.
    # Estimamos como peak_db + 1.5 dB (heurístico conservador para overs intersample)
    true_peak_estimated_db = peak_db + 1.5 if peak_db != float("-inf") else float("-inf")

    # Drift exportador: los primeros/últimos 200ms deberían estar dentro del SNR
    drift_detected = False
    drift_db       = 0.0
    check_frames   = min(n_frames, int(0.200 * rate))
    if check_frames > 0 and rms_global > 1e-9:
        head_rms = float(np.sqrt(np.mean(audio[:check_frames].astype(np.float64) ** 2)))
        tail_rms = float(np.sqrt(np.mean(audio[-check_frames:].astype(np.float64) ** 2)))
        head_db  = _lin_to_db(head_rms) if head_rms > 1e-12 else float("-inf")
        tail_db  = _lin_to_db(tail_rms) if tail_rms > 1e-12 else float("-inf")
        # Si cabeza o cola están > 20 dB por debajo del RMS global → drift
        if head_db != float("-inf") and head_db < rms_db - 20.0:
            drift_detected = True
            drift_db = rms_db - head_db
            _log.info("TwoPass PASS 1: drift exportador en cabeza: %.1f dB por debajo del RMS", drift_db)
        if tail_db != float("-inf") and tail_db < rms_db - 20.0:
            drift_detected = True
            drift_db = max(drift_db, rms_db - tail_db)
            _log.info("TwoPass PASS 1: drift exportador en cola: %.1f dB por debajo del RMS",
                      rms_db - tail_db)

    warnings = []
    if clip_density > 0.001:
        warnings.append(f"Clipping previo detectado ({clip_density*100:.3f}% muestras).")
    if silence_ratio > 0.50:
        warnings.append(f"Silencio dominante ({silence_ratio*100:.0f}% de bloques).")
    if snr_db != float("inf") and snr_db < 10.0:
        warnings.append(f"SNR bajo ({snr_db:.1f} dB) — ruido prominente.")
    if drift_detected:
        warnings.append(f"Drift exportador detectado (cabeza/cola {drift_db:.1f} dB bajo).")
    if dynamic_range < 3.0:
        warnings.append(f"Rango dinámico muy bajo ({dynamic_range:.1f} dB) — material comprimido.")

    # ── Árbol de decisión mejorado (aprovecha los percentiles de PASS 1) ──────
    if clip_density > 0.001:
        suggested = "PRESERVATIVE"
        reason    = (f"Clipping previo ({clip_density*100:.3f}%). "
                     f"Preservativo para no amplificar saturación.")
    elif dur_s < 3.0:
        suggested = "PEAK_SIMPLE"
        reason    = f"Audio muy corto ({dur_s:.1f}s)."
    elif silence_ratio > 0.60:
        suggested = "ADAPTIVE_BLOCK"
        reason    = (f"Silencio dominante ({silence_ratio*100:.0f}%). "
                     f"Adaptativa por bloques para ignorar silencios.")
    elif snr_db != float("inf") and snr_db < 12.0:
        suggested = "NOISE_AWARE"
        reason    = (f"SNR bajo ({snr_db:.1f} dB, noise_floor={noise_floor_db:.1f} dBFS). "
                     f"Noise-aware para limitar amplificación del ruido.")
    elif dynamic_range < 3.0:
        suggested = "ADAPTIVE_BLOCK"
        reason    = (f"Rango dinámico ({dynamic_range:.1f} dB) muy bajo. "
                     f"Material sobrecomprimido.")
    elif p95_db != float("-inf") and p95_db > -8.0:
        suggested = "PRESERVATIVE"
        reason    = (f"Percentil 95 RMS ({p95_db:.1f} dBFS) muy alto. "
                     f"Preservativo para evitar sobrecarga.")
    elif dur_s > 3600.0:
        suggested = "NOISE_AWARE"
        reason    = (f"Sesión larga ({dur_s/3600:.1f}h) — posible cassette/FM. "
                     f"Noise-aware conservador.")
    else:
        suggested = "LUFS_16"
        reason    = (f"Material normal (SNR={snr_db:.1f} dB, "
                     f"DR={dynamic_range:.1f} dB, p50={p50_db:.1f} dBFS). "
                     f"LUFS -16 como balance óptimo.")

    _log.info("TwoPass PASS 1 completado en %.2f s: peak=%.2f dBFS  rms=%.2f dBFS  "
              "noise_floor=%.2f dBFS  clips=%d  silence=%.0f%%  suggested=%s",
              t_pass1, peak_db, rms_db, noise_floor_db,
              n_clips, silence_ratio * 100, suggested)

    # ── PASS 2: normalización con el modo sugerido ────────────────────────────
    _log.info("TwoPass PASS 2: aplicando %s...", suggested)
    t_pass2_start = time.monotonic()

    try:
        # NOTA MODULARIZACION: idem — import directo de modulos backend
        # en lugar de "from __main__ import (...)" del monolito original.
        from lorito_aldhiro.backend.export.lorito_normalization import (
            _norm_rms, _norm_lufs, _norm_preservative,
            _norm_noise_aware, _norm_adaptive_block,
            _apply_normalization_advanced,
        )
        from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
        mode_map = {
            "LUFS_16":        NormalizationMode.LUFS_16,
            "NOISE_AWARE":    NormalizationMode.NOISE_AWARE,
            "PRESERVATIVE":   NormalizationMode.PRESERVATIVE,
            "ADAPTIVE_BLOCK": NormalizationMode.ADAPTIVE_BLOCK,
            "PEAK_SIMPLE":    NormalizationMode.PEAK_SIMPLE,
        }
        norm_mode = mode_map.get(suggested, NormalizationMode.LUFS_16)
        audio_out, norm_stats = _apply_normalization_advanced(audio, norm_mode, rate)
    except Exception as e:
        _log.error("TwoPass PASS 2 error: %s — fallback peak simple", e)
        pk = float(np.max(np.abs(audio)))
        gain = _db_to_lin(-0.2) / max(pk, 1e-9)
        audio_out = np.clip(audio * np.float32(gain), -1.0, 1.0)
        norm_stats = {"mode": "PEAK_SIMPLE_FALLBACK", "gain_db": _lin_to_db(gain),
                      "peak_db": _lin_to_db(pk), "lufs": float("-inf"),
                      "noise_floor_db": noise_floor_db, "true_peak_db": _lin_to_db(pk)}

    # Soft limiter post-normalización
    audio_out, limiter_stats = _soft_limiter_conservative(audio_out, ceiling_db=-0.2)

    t_pass2 = time.monotonic() - t_pass2_start

    # ── Construir stats completos ─────────────────────────────────────────────
    combined = dict(norm_stats)
    combined.update({
        "mode":                         "TWO_PASS",
        "two_pass_suggested_mode":      suggested,
        "two_pass_suggested_reason":    reason,
        "auto_normalization_decision":  suggested,
        "auto_normalization_reason":    reason,
        # Métricas de PASS 1
        "pass1_peak_db":                round(peak_db, 3),
        "pass1_rms_db":                 round(rms_db, 3),
        "pass1_noise_floor_db":         round(noise_floor_db, 2),
        "pass1_true_peak_estimated_db": round(true_peak_estimated_db, 2),
        "pass1_clip_density":           round(clip_density, 6),
        "pass1_silence_ratio":          round(silence_ratio, 4),
        "pass1_dynamic_range_db":       round(dynamic_range, 2),
        "pass1_p05_rms_db":             round(p05_db, 2) if p05_db != float("-inf") else None,
        "pass1_p25_rms_db":             round(p25_db, 2) if p25_db != float("-inf") else None,
        "pass1_p50_rms_db":             round(p50_db, 2) if p50_db != float("-inf") else None,
        "pass1_p75_rms_db":             round(p75_db, 2) if p75_db != float("-inf") else None,
        "pass1_p95_rms_db":             round(p95_db, 2) if p95_db != float("-inf") else None,
        "pass1_snr_db":                 round(snr_db, 2) if snr_db != float("inf") else None,
        "pass1_crest_factor_db":        round(cf_db, 2) if cf_db != float("inf") else None,
        "pass1_export_drift_detected":  drift_detected,
        "pass1_export_drift_db":        round(drift_db, 2),
        "pass1_n_blocks_analyzed":      len(block_rmss),
        "pass1_warnings":               warnings,
        "pass1_time_s":                 round(t_pass1, 3),
        "pass2_time_s":                 round(t_pass2, 3),
        # Soft limiter
        "soft_limiter_triggered":       limiter_stats.get("triggered", False),
        "soft_limiter_reduction_db":    limiter_stats.get("max_reduction_db", 0.0),
        # Compatibilidad con campos estándar que esperan los snapshots
        "noise_floor_db":               round(noise_floor_db, 2),
        "peak_db":                      combined.get("peak_db", round(peak_db, 3)),
    })

    _log.info("TwoPass completado: PASS1=%.2fs  PASS2=%.2fs  "
              "gain=%.2f dB  suggested=%s  limiter=%s",
              t_pass1, t_pass2,
              combined.get("gain_db", 0.0),
              suggested,
              limiter_stats.get("triggered", False))

    return audio_out, combined
