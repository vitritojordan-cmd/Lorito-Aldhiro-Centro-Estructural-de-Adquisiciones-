"""
lorito_aldhiro.backend.export_streaming — motor de exportación en dos
pasadas, memoria O(bloque) en vez de O(duración) (Fase 1 y
normalización, GAP-002 a GAP-030).

Rama del árbol de módulos de Lorito Aldhiro (ver GAP-032): a partir de
esta sesión, todo subpaquete conecta sus módulos aquí — nunca se deja
un `__init__.py` vacío como simple marcador de paquete.

Módulos:
  · lorito_export_blocks       — `Block`, unidad de transferencia entre etapas.
  · lorito_segment_provider    — `SegmentProvider`, lectura streaming de segmentos.
  · lorito_encoder_base        — `Encoder`, contrato base de encoder de salida.
  · lorito_wav_encoder         — `WavEncoder` (PCM 16/24/32, bit-exacto — GAP-026).
  · lorito_atomic_finalizer    — `AtomicFinalizer`, finalización sin archivos huérfanos.
  · lorito_export_session      — `ExportSession`, orquesta el pase único de escritura.
  · lorito_normalization_streaming — los 20 modos de `NormalizationMode`
    en dos pasadas (GAP-027 a GAP-030).
"""

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import (
    Block, FormatMismatchError, ExportAbortError,
)
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider, DEFAULT_BLOCK_FRAMES, SegmentReadError,
)
from lorito_aldhiro.backend.export_streaming.lorito_encoder_base import Encoder
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import AtomicFinalizer
from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
    ExportSession, ExportSessionReport,
)
from lorito_aldhiro.backend.export_streaming import lorito_normalization_streaming

__all__ = [
    "Block", "SegmentProvider", "DEFAULT_BLOCK_FRAMES", "SegmentReadError",
    "FormatMismatchError", "ExportAbortError",
    "Encoder", "WavEncoder", "AtomicFinalizer",
    "ExportSession", "ExportSessionReport",
    "lorito_normalization_streaming",
]
