from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Finalización atómica de exportación — nunca deja un archivo final a medias.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_atomic_finalizer.py — finalización atómica (§24, §37, §38, FASE 8):

    output.partial → write → flush → fsync → validate → checksum
                   → atomic rename → output.final

Si falla cualquier etapa, `output.final` NO debe existir como archivo
válido. Envuelve cualquier `Encoder` (§23) sin conocer sus detalles de
codec — funciona igual para WAV nativo (`lorito_wav_encoder.py`) que
para los adaptadores futuros de FLAC/OGG/WV.

Reutiliza los helpers de integridad ya existentes y verificados en el
proyecto (`lorito_export_integrity._sha256_file` /
`_write_checksum_file`, streaming — nunca cargan el archivo completo en
RAM), en vez de reimplementar SHA-256.
"""

import os

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import ExportAbortError
# GAP-051 (§4/§11, FASE 1): usadas para adjuntar, además del string ya
# existente en `report["error"]` (preservado tal cual), la excepción
# tipificada y estructurada correspondiente en `report["exception"]`.
from lorito_aldhiro.backend.errors import (
    ExportError, FrameAccountingError, ExportFinalizeError, ChecksumMismatchError,
    ExportCancelledError,
)


def _sha256_file(path: str, chunk_size: int = 1 << 20) -> str:
    """
    Import diferido de `lorito_export_integrity._sha256_file` para no
    forzar la dependencia de `soundfile` (import a nivel de módulo en
    `lorito_export_integrity.py`) sobre algo que no la necesita — la
    propia función es pura stdlib (`hashlib`). Import perezoso dentro de
    la función; si `lorito_export_integrity` no puede importarse (p. ej.
    este sandbox, sin `soundfile` instalado), se usa una copia idéntica
    como fallback, NUNCA una versión distinta.
    """
    try:
        from lorito_aldhiro.backend.export.lorito_export_integrity import (
            _sha256_file as _real_sha256_file,
        )
        return _real_sha256_file(path, chunk_size)
    except ImportError:
        import hashlib
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                blk = f.read(chunk_size)
                if not blk:
                    break
                h.update(blk)
        return h.hexdigest()


def _write_checksum_file(audio_path: str, sha256: str,
                         duration_secs: float, frames: int) -> str:
    """Ver nota de `_sha256_file` — mismo patrón de import perezoso con
    fallback idéntico en forma, para no acoplar este módulo (sin
    dependencias externas) a `soundfile` solo por compartir paquete con
    `lorito_export_integrity.py`."""
    try:
        from lorito_aldhiro.backend.export.lorito_export_integrity import (
            _write_checksum_file as _real_write_checksum_file,
        )
        return _real_write_checksum_file(audio_path, sha256, duration_secs, frames)
    except ImportError:
        chk_path = audio_path + ".sha256"
        try:
            with open(chk_path, "w", encoding="utf-8") as f:
                f.write(f"{sha256}  {os.path.basename(audio_path)}\n")
                f.write(f"# Frames: {frames}\n# Duracion: {duration_secs:.3f} s\n")
        except OSError:
            chk_path = ""
        return chk_path


class AtomicFinalizer:
    """
    Orden Golden de Exportación (EX-08/EX-09/EX-10/EX-T08…T14):

        .partial (mismo directorio) → write* → flush → finalize (errores
        PROPAGADOS) → fsync(partial) → validate (lector independiente)
        → frame accounting → SHA-256 releyendo de disco → os.replace →
        fsync(directorio) → sidecar .sha256 atómico (tmp→fsync→replace→
        fsync dir) → RELECTURA post-publicación: SHA-256 del final y
        del sidecar deben coincidir.

    Ningún fallo deja un final nuevo publicado; un final ANTERIOR válido
    con el mismo nombre solo se sustituye en el `os.replace` del final
    ya verificado. Cancelación cooperativa vía `cancel_event`.

    Uso:
        finalizer = AtomicFinalizer(encoder_cls=WavEncoder,
                                     fmt=fmt, final_path="captura.wav",
                                     encoder_kwargs={"subtype": "PCM_24",
                                                      "total_frames_hint": N})
        report = finalizer.run(blocks_iterable, total_frames_expected=N)
    """

    def __init__(self, encoder_cls, fmt, final_path: str,
                 encoder_kwargs: dict | None = None,
                 sidecar_metadata: dict | None = None):
        self.encoder_cls = encoder_cls
        self.fmt = fmt
        self.final_path = final_path
        self.partial_path = final_path + ".partial"
        self.encoder_kwargs = dict(encoder_kwargs or {})
        self.sidecar_metadata = dict(sidecar_metadata or {})
        self.encoder = None
        self.durability = ""

    def run(self, blocks_iterable, total_frames_expected: int = 0,
            cancel_event=None, progress_cb=None) -> dict:
        report = {
            "ok": False, "path": self.final_path, "error": "",
            "frames_in": 0, "frames_out": 0, "sha256": "",
            "checksum_path": "", "exception": None,
            "cancelled": False, "sha256_reread_ok": False,
            "sidecar_ok": False, "durability": "", "stage": "",
            "validation": {},
        }

        def _abort(stage, msg, exc):
            report["stage"] = stage
            report["error"] = msg
            report["exception"] = exc
            self._cleanup_partial()
            return report

        if os.path.exists(self.partial_path):
            try:
                os.remove(self.partial_path)
            except OSError:
                pass

        encoder = self.encoder_cls(self.fmt, self.partial_path, **self.encoder_kwargs)
        self.encoder = encoder
        frames_in = 0
        try:
            encoder.open()
            for blk in blocks_iterable:
                if cancel_event is not None and cancel_event.is_set():
                    raise ExportCancelledError("exportación cancelada por el operador",
                                               frame_start=frames_in)
                encoder.write(blk)
                frames_in += blk.n_frames
                if progress_cb is not None:
                    try:
                        progress_cb(frames_in, total_frames_expected)
                    except Exception:
                        pass
            encoder.flush()
            encoder.finalize()            # Orden Golden: errores PROPAGADOS
        except ExportCancelledError as e:
            self._abort_encoder(encoder)
            report["cancelled"] = True
            return _abort("cancel", str(e), e)
        except Exception as e:
            self._abort_encoder(encoder)
            exc = e if isinstance(e, ExportError) else ExportError(
                f"fallo durante codificación: {e}", cause=e)
            return _abort("encode", f"fallo durante codificación: {e}", exc)

        report["frames_in"] = frames_in
        try:
            _fsync_path(self.partial_path)
        except OSError as e:
            return _abort("fsync", f"fsync del parcial falló: {e}",
                          ExportFinalizeError(f"fsync falló: {e}", cause=e,
                                              path=self.partial_path))

        validation = encoder.validate()
        report["validation"] = validation
        if not validation.get("ok"):
            msg = f"validación falló: {validation.get('error')}"
            return _abort("validate", msg, ExportFinalizeError(msg))
        report["frames_out"] = validation.get("actual_frames", 0)

        if total_frames_expected and frames_in != total_frames_expected:
            msg = (f"frame accounting: se procesaron {frames_in} frames pero se "
                   f"esperaban {total_frames_expected} (fuente incompleta)")
            return _abort("accounting", msg,
                          FrameAccountingError(msg, frame_count=total_frames_expected))
        if report["frames_out"] != frames_in:
            msg = (f"frame accounting: frames_in={frames_in} != "
                   f"frames_out={report['frames_out']} — archivo final descartado")
            return _abort("accounting", msg, FrameAccountingError(msg, frame_count=frames_in))

        try:
            sha = _sha256_file(self.partial_path)
        except OSError as e:
            sha = ""
        if not sha:
            msg = "no se pudo calcular checksum del archivo válido"
            return _abort("checksum", msg, ChecksumMismatchError(msg))
        report["sha256"] = sha

        try:
            os.replace(self.partial_path, self.final_path)
        except OSError as e:
            return _abort("rename", f"rename atómico falló: {e}",
                          ExportFinalizeError(f"rename atómico falló: {e}", cause=e))
        try:
            dir_synced = _fsync_dir(self.final_path)
        except OSError as e:
            # El final ya está publicado pero su entrada de directorio no
            # es durable: se informa como fallo (nunca SUCCESS).
            report["stage"] = "dir_fsync"
            report["error"] = f"fsync del directorio falló: {e}"
            report["exception"] = ExportFinalizeError(report["error"], cause=e)
            return report
        self.durability = ("FILE_FSYNC+DIR_FSYNC" if dir_synced
                           else "FILE_FSYNC (directorio no sincronizable)")
        report["durability"] = self.durability

        duration = report["frames_out"] / max(self.fmt.rate, 1)
        try:
            chk_path = _write_sidecar_atomic(self.final_path, sha, duration,
                                             report["frames_out"], self.sidecar_metadata)
        except OSError as e:
            report["stage"] = "sidecar"
            report["error"] = f"no se pudo publicar el sidecar .sha256: {e}"
            report["exception"] = ExportFinalizeError(report["error"], cause=e)
            return report
        report["checksum_path"] = chk_path

        # Relectura post-publicación (EX-09/EX-T13).
        try:
            sha_final = _sha256_file(self.final_path)
        except OSError:
            sha_final = ""
        report["sha256_reread_ok"] = sha_final == sha
        side = _read_sidecar_hash(chk_path)
        report["sidecar_ok"] = side == sha
        if not report["sha256_reread_ok"] or not report["sidecar_ok"]:
            report["stage"] = "reread"
            report["error"] = (f"verificación post-publicación falló: "
                               f"reread={sha_final[:16]} sidecar={str(side)[:16]} "
                               f"esperado={sha[:16]}")
            report["exception"] = ChecksumMismatchError(report["error"], path=self.final_path)
            return report
        report["stage"] = "done"
        report["ok"] = True
        return report

    @staticmethod
    def _abort_encoder(encoder):
        abort = getattr(encoder, "abort", None)
        try:
            if abort is not None:
                abort()
            else:
                encoder.finalize()
        except Exception:
            pass

    def _cleanup_partial(self) -> None:
        """Elimina SOLO el `.partial` de este intento. Nunca toca un final
        anterior válido."""
        if os.path.exists(self.partial_path):
            try:
                os.remove(self.partial_path)
            except OSError:
                pass


def _fsync_path(path: str) -> None:
    flags = os.O_RDONLY
    if os.name == "nt":
        flags = os.O_RDWR | getattr(os, "O_BINARY", 0)
    fd = os.open(path, flags)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _fsync_dir(path: str) -> bool:
    if os.name == "nt":
        return False
    d = os.path.dirname(os.path.abspath(path)) or "."
    fd = os.open(d, os.O_RDONLY)
    try:
        os.fsync(fd)
        return True
    except OSError as e:
        import errno as _errno
        if e.errno in (_errno.EINVAL, getattr(_errno, "ENOTSUP", _errno.EINVAL)):
            return False
        raise
    finally:
        os.close(fd)


def _write_sidecar_atomic(audio_path: str, sha256: str, duration_secs: float,
                          frames: int, metadata: dict) -> str:
    """Sidecar `<final>.sha256` publicado de forma atómica. Primera línea
    con el formato estándar `sha256sum` (`<hash>  <nombre>`)."""
    import datetime as _dt
    chk_path = audio_path + ".sha256"
    tmp_path = chk_path + ".tmp"
    lines = [f"{sha256}  {os.path.basename(audio_path)}",
             f"# Generado: {_dt.datetime.now().isoformat()}",
             f"# Tamaño: {os.path.getsize(audio_path)} bytes",
             f"# Duración: {duration_secs:.3f} s",
             f"# Frames: {frames}"]
    for k, v in metadata.items():
        lines.append(f"# {k}: {v}")
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, chk_path)
    _fsync_dir(chk_path)
    return chk_path


def _read_sidecar_hash(chk_path: str) -> str:
    try:
        with open(chk_path, "r", encoding="utf-8") as f:
            first = f.readline()
        return first.split()[0] if first.strip() else ""
    except OSError:
        return ""


def cleanup_orphans(output_dir: str) -> list:
    """EX-T14: tras un fallo/caída, elimina `*.partial` y `*.sha256.tmp`
    huérfanos del directorio de exportación. Nunca borra un archivo
    final ni un `.sha256` publicado. Devuelve la lista de eliminados."""
    removed = []
    try:
        names = os.listdir(output_dir)
    except OSError:
        return removed
    for n in names:
        if n.endswith((".partial", ".sha256.tmp", ".manifest.json.tmp")):
            p = os.path.join(output_dir, n)
            try:
                os.remove(p)
                removed.append(p)
            except OSError:
                pass
    return removed
