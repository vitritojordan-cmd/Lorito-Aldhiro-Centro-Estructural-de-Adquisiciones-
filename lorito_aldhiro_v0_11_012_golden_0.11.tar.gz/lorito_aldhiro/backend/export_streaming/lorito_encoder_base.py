from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Interfaz base de encoder de exportación streaming.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_encoder_base.py — contrato común de encoder (§23 de la orden):

    Encoder.open()
    Encoder.write(block)
    Encoder.flush()
    Encoder.finalize()
    Encoder.validate()

Los fallos de un codec no pueden dejar un archivo final aparentemente
válido (§23) — ver `lorito_atomic_finalizer.py`, que envuelve cualquier
`Encoder` con la disciplina `.partial → validate → checksum → rename`
de §24, sea cual sea el codec.
"""

from abc import ABC, abstractmethod

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import AudioFormat, Block


class Encoder(ABC):
    """
    Contrato mínimo de encoder streaming. `out_path` es la ruta FINAL
    deseada — la implementación (o el `AtomicFinalizer` que la envuelve)
    decide si escribe directo o vía `.partial`.
    """

    codec_name: str = "BASE"

    def __init__(self, fmt: AudioFormat, out_path: str, **options):
        self.fmt = fmt
        self.out_path = out_path
        self.options = options
        self.frames_written = 0
        self._opened = False

    @abstractmethod
    def open(self) -> None:
        """Prepara el archivo/proceso de salida. No debe requerir conocer
        el total de frames de antemano (streaming real)."""
        raise NotImplementedError

    @abstractmethod
    def write(self, block: Block) -> None:
        """Escribe un bloque. Debe poder llamarse repetidamente sin
        acumular en RAM lo ya escrito."""
        raise NotImplementedError

    @abstractmethod
    def flush(self) -> None:
        """Fuerza la escritura de cualquier dato pendiente al SO (no
        necesariamente fsync — ver `finalize()`)."""
        raise NotImplementedError

    @abstractmethod
    def finalize(self) -> None:
        """Cierra el archivo/proceso de forma limpia. A partir de aquí
        `out_path` debe ser un archivo completo y válido (o no existir)."""
        raise NotImplementedError

    @abstractmethod
    def validate(self) -> dict:
        """
        Reabre el archivo final y confirma que es decodificable y que
        sus metadatos (frames/rate/canales) son consistentes con lo
        escrito. Devuelve {"ok": bool, "error": str, ...}.
        """
        raise NotImplementedError

    # ── Helper de uso común ──────────────────────────────────────────
    def encode_all(self, blocks) -> dict:
        """
        Orquesta open→write*→flush→finalize→validate sobre un iterable
        de `Block`. Punto de entrada estándar para `ExportSession`.
        """
        self.open()
        self._opened = True
        try:
            for blk in blocks:
                self.write(blk)
                self.frames_written += blk.n_frames
            self.flush()
        finally:
            self.finalize()
        return self.validate()
