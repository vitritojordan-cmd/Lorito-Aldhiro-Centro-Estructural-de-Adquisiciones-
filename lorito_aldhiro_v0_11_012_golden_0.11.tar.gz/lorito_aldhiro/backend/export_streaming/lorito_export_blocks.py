from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Tipos de datos compartidos del pipeline de exportación streaming (Block, AudioFormat).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_blocks.py — contratos de bloque para el motor de exportación
streaming (Orden Maestra de Refundación §1, §17-§24, FASE 1: Contratos).

Ningún tipo de aquí carga audio completo en memoria: `AudioFormat` describe
metadatos calculados de antemano (headers), y `Block` es siempre un
fragmento acotado (nunca la sesión entera).
"""

from dataclasses import dataclass
import numpy as np

# GAP-051 (FASE 1 de la Orden de Saneamiento, Integración y
# Consolidación): antes, estas dos clases se definían aquí mismo como
# `RuntimeError` sueltos. Ahora viven en `backend/errors/` (§11),
# consolidadas junto con el resto de la familia `ExportError` —
# reimportadas aquí con el MISMO nombre para que ningún sitio de
# import existente (`from ...lorito_export_blocks import
# FormatMismatchError`, usado en `lorito_segment_provider.py` y en
# `tests/test_export_streaming.py`) necesite cambiar.
from lorito_aldhiro.backend.errors import FormatMismatchError, ExportAbortError


@dataclass(frozen=True)
class AudioFormat:
    """
    Formato de audio válido para una sesión de exportación completa.
    Se calcula UNA vez a partir de los headers de los segmentos (§21),
    nunca leyendo las muestras.
    """
    rate: int
    channels: int
    sample_width_bytes: int   # 2=PCM_16, 3=PCM_24, 4=PCM_32/FLOAT
    is_float: bool = False

    def matches(self, other: "AudioFormat") -> bool:
        return (self.rate == other.rate
                and self.channels == other.channels
                and self.sample_width_bytes == other.sample_width_bytes
                and self.is_float == other.is_float)


@dataclass(frozen=True)
class Block:
    """
    Fragmento acotado de audio. `data` es SIEMPRE float32 en [-1.0, 1.0],
    shape (n_frames, n_channels) — el mismo contrato que ya usan los
    encoders actuales (`_encode(audio: np.ndarray, ...)`), de modo que
    adaptarlos a este contrato es un cambio de origen del dato, no de su
    forma.
    """
    data: np.ndarray
    frame_offset: int     # posición absoluta del primer frame de este bloque
    is_last: bool = False

    @property
    def n_frames(self) -> int:
        return self.data.shape[0]



