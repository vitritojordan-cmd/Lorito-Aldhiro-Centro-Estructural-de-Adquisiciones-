from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: block_transform de resampleo por velocidad para ExportSession, sin deriva de fase ni de conteo de frames.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_resample_transform.py — GAP-065 (cierre de FASE 3, hueco
(a): "el resampleo por velocidad no tiene equivalente streaming").

El camino legado (`lorito_mw_export.py`, `_build_export_array` +
`PlaybackEngine._resample_chunk(audio_raw, ratio)`) resamplea el
array COMPLETO de la sesión de una sola vez — correcto (una sola
llamada, sin fronteras de bloque que puedan introducir deriva de
fase) pero exige tener toda la sesión en RAM, justo lo que
`ExportSession`/§20 busca evitar.

Este módulo aplica `resample_stateful_continuous()`
(`backend/dsp/lorito_dsp_resample_continuous.py`, construida y
verificada en GAP-037, cableada a producción en `PlaybackEngine` en
GAP-062) BLOQUE A BLOQUE, igual que `PlaybackEngine` ya hace en
reproducción — la fase de interpolación (`cursor`/`history`) viaja de
un bloque al siguiente sin reiniciarse, evitando exactamente la
deriva medida en GAP-062 para `_resample_stateful` de un solo golpe
por bloque.

## El problema de conteo de frames (y su solución)

`resample_stateful_continuous()` calcula, para CADA llamada,
`n_out = round(n_in_del_bloque / ratio)` de forma INDEPENDIENTE. Con
bloques de tamaño uniforme (`DEFAULT_BLOCK_FRAMES`, todos iguales
salvo el último), ese redondeo es EL MISMO en cada bloque completo —
no es un paseo aleatorio que se cancela en promedio, es una deriva
SISTEMÁTICA que crece linealmente con el número de bloques (p. ej.
1000 bloques × hasta 0.5 muestras de redondeo = hasta 500 muestras de
diferencia real al final de la sesión). `AtomicFinalizer` (§28) exige
`frames_in == total_frames_expected` de forma ESTRICTA — con
resampleo, ese conteo esperado ya no es el conteo de frames de
ENTRADA (lo que `ExportSession.run()` pasa por defecto), sino el
conteo de frames de SALIDA tras resamplear, y debe ser EXACTO, no
aproximado.

Técnica aplicada — "objetivo acumulado" (idéntica en espíritu al
acumulador de Bresenham para conversión de tasa exacta, ya estándar
en DSP): en vez de dejar que cada bloque calcule su propio `n_out`
independiente, se calcula por adelantado cuántas muestras de salida
le CORRESPONDEN acumulativamente a cada bloque
(`round(frames_entrada_acumulados / ratio)`), y se le pide al
resampleador EXACTAMENTE esa cantidad para este bloque —
perturbando el ratio de ESTE bloque en una cantidad
imperceptible (`ratio_local = n_in_bloque / objetivo_este_bloque`,
una desviación relativa típica <0.01% para bloques de miles de
frames) en vez de tocar la función compartida
`resample_stateful_continuous()` (que no cambia, y sigue sirviendo
sin modificar a `PlaybackEngine`). El resultado es CERO deriva de
conteo acumulada, sin importar la duración de la sesión — verificado
en `tests/test_export_resample_transform.py`.
"""

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block
from lorito_aldhiro.backend.dsp.lorito_dsp_resample_continuous import (
    resample_stateful_continuous,
)


def expected_resampled_frames(total_in_frames: int, ratio: float) -> int:
    """Conteo EXACTO de frames de salida esperados para una sesión
    completa de `total_in_frames` a un `ratio` de velocidad fijo —
    el mismo valor que `StreamingSpeedResampleTransform` garantiza
    alcanzar exactamente al procesar todos sus bloques. Usar este
    valor como `expected_output_frames` de `ExportSession` (ver
    `lorito_export_session.py`)."""
    if total_in_frames <= 0:
        return 0
    return max(1, int(round(total_in_frames / ratio)))


class StreamingSpeedResampleTransform:
    """`block_transform` con estado para `ExportSession` — resamplea
    cada `Block` a un `ratio` de velocidad FIJO para toda la sesión
    (mismo contrato que el camino legado: una sola velocidad para la
    exportación completa, no una curva de velocidad variable en el
    tiempo — eso no existe hoy ni en el camino legado). Instanciar
    UNA vez por sesión y pasar la instancia como `block_transform` —
    lleva su propio `cursor`/`history` de fase y su propio contador
    de frames de salida ya emitidos, así que NO es reutilizable entre
    sesiones distintas (crear una instancia nueva por cada `run()`).
    """

    def __init__(self, ratio: float, total_in_frames: int):
        if ratio is None or ratio <= 0:
            raise ValueError(f"ratio de resampleo inválido: {ratio!r}")
        self.ratio = float(ratio)
        self.total_in_frames = int(total_in_frames)
        self.total_out_frames = expected_resampled_frames(
            self.total_in_frames, self.ratio)
        self._cursor = 0.0
        self._history = None
        self._in_consumed = 0
        self._out_produced = 0

    def __call__(self, block: Block) -> Block:
        n_in = block.n_frames
        self._in_consumed += n_in

        if block.is_last:
            target_cum_out = self.total_out_frames
        else:
            target_cum_out = int(round(self._in_consumed / self.ratio))
        # Al menos 1 muestra de salida por llamada — mismo suelo que
        # `resample_stateful_continuous()` ya impone internamente; en
        # la práctica nunca se alcanza con los tamaños de bloque de
        # este pipeline (`DEFAULT_BLOCK_FRAMES=32768`), solo protege
        # el caso degenerado de un último bloque parcial diminuto
        # combinado con `ratio` grande.
        target_this_block = max(1, target_cum_out - self._out_produced)

        # Perturbación local del ratio — ver docstring del módulo.
        # `n_in` siempre >0 aquí (SegmentProvider nunca emite bloques
        # vacíos), así que la división es segura.
        local_ratio = n_in / target_this_block

        data_out, self._cursor, self._history = resample_stateful_continuous(
            block.data, local_ratio, self._cursor, self._history)

        # Red de seguridad determinista: si por el suelo de "al menos
        # 1" (caso degenerado arriba) `data_out` no tiene EXACTAMENTE
        # `target_this_block` frames, recortar/rellenar aquí mismo —
        # nunca dejar que la discrepancia se propague al resto de la
        # sesión. `resample_stateful_continuous()` con `local_ratio`
        # calculado como arriba siempre produce exactamente
        # `target_this_block` en la práctica (ver docstring), así que
        # esta rama solo se ejercita en el caso degenerado.
        if data_out.shape[0] != target_this_block:
            data_out = _resize_frames(data_out, target_this_block)

        self._out_produced += data_out.shape[0]
        out_block = Block(data=data_out, frame_offset=0, is_last=block.is_last)
        return out_block


def _resize_frames(data: np.ndarray, n_target: int) -> np.ndarray:
    """Ajusta `data` (n_frames, n_ch) a EXACTAMENTE `n_target` frames
    — recorta el excedente por el final, o repite la última muestra
    (inaudible: como mucho 1-2 frames, caso degenerado documentado en
    `StreamingSpeedResampleTransform.__call__`) si falta."""
    n_cur = data.shape[0]
    if n_cur == n_target:
        return data
    if n_cur > n_target:
        return data[:n_target]
    if n_cur == 0:
        return np.zeros((n_target, data.shape[1]), dtype=data.dtype)
    pad = np.repeat(data[-1:], n_target - n_cur, axis=0)
    return np.concatenate([data, pad], axis=0)
