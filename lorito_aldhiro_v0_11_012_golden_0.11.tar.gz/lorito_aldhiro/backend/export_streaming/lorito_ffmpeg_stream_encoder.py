from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Encoders streaming FLAC/OGG/WavPack vía subproceso ffmpeg, sin soundfile.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_ffmpeg_stream_encoder.py — GAP-066 (cierre de FASE 3, hueco (b):
"faltan encoders streaming de FLAC/OGG/WV — el camino nuevo
(`ExportSession`) solo tiene `WavEncoder`").

`soundfile` no es instalable en este sandbox (GAP-003 §5, ver también
la nota de cabecera de `lorito_wav_encoder.py`), así que estos
encoders NO pueden usar el mismo camino que
`backend/export/lorito_exporters.py` (`import soundfile as sf`). En su
lugar, generalizan el patrón que YA usa `WVExporter` en ese mismo
archivo — probado en producción, el más "streaming" de los cuatro
exportadores legados — a los tres codecs comprimidos (FLAC/OGG/WV) y
al contrato `Encoder` streaming (§23):

    Block (float32, [-1,1]) → stdin de un proceso `ffmpeg` (formato
    de entrada crudo `f32le`, sin conversión de tipo de muestra en
    Python) → códec comprimido → archivo final

Esto reemplaza la conversión manual a PCM s24le que `WVExporter` hacía
a mano (necesaria allí porque alimentaba un WAV intermedio pensado
para `soundfile`) por algo más simple: `ffmpeg` decodifica `f32le`
directamente, así que ninguna de las tres clases de aquí necesita
tocar los bytes de las muestras — la única responsabilidad de Python
es la disciplina de streaming en sí (`open`/`write`/`flush`/
`finalize`/`validate` de §23), no la codificación de bits.

## Validación exacta sin soundfile

`validate()` (§23: "reabre el archivo final y confirma que es
decodificable y que sus metadatos son consistentes") decodifica el
archivo final DE VUELTA a PCM `f32le` crudo vía otro proceso `ffmpeg`
y cuenta los frames exactos a partir del tamaño en bytes — ni FLAC ni
WavPack (sin pérdida, por diseño) ni un OGG/Vorbis bien formado
(cuyo `granulepos` de la última página codifica la duración EXACTA,
ver los comentarios extensos de `OGGExporter._encode()` en
`lorito_exporters.py` sobre `-page_duration`/`-map_metadata -1`,
flags que este módulo también aplica) deberían perder ni un frame en
el viaje de ida y vuelta — verificado con ejecución real en
`tests/test_ffmpeg_stream_encoders.py`, no solo argumentado.

Los tres codecs comparten la MISMA base (`_FfmpegPipeEncoder`) — las
subclases solo declaran qué encoder(es) de ffmpeg probar (en orden de
preferencia, igual que los "Intento 1/2" de `OGGExporter`) y los
argumentos de salida específicos del códec.
"""

import collections
import os
import subprocess
import threading

import numpy as np

from lorito_aldhiro.backend.audio.lorito_audio_backend import FFMPEG_CAPS
from lorito_aldhiro.backend.export_streaming.lorito_encoder_base import Encoder
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block, ExportAbortError


class _FfmpegPipeEncoder(Encoder):
    """Base común: pipe de PCM `f32le` crudo al stdin de un proceso
    `ffmpeg`, sin WAV intermedio en disco (memoria = O(block_frames),
    igual que `WavEncoder` — nunca materializa la sesión completa).
    No instanciable directamente: una subclase debe declarar
    `_ffmpeg_encoder_candidates`/`_caps_keys` y `_output_args()`."""

    _ffmpeg_encoder_candidates: tuple = ()   # p.ej. ("libvorbis", "vorbis")
    _caps_keys: tuple = ()                   # claves paralelas en FFMPEG_CAPS
    # Nombre del MUXER de contenedor de ffmpeg (`-f <formato>` de
    # SALIDA) — declarado explícitamente por cada subclase. `open()`
    # NO puede confiar en que ffmpeg infiera el contenedor por la
    # extensión de `out_path` (comportamiento normal de ffmpeg sin
    # `-f` de salida): `AtomicFinalizer` (§24/§37) SIEMPRE escribe
    # primero a `final_path + ".partial"` (p. ej. "captura.flac.
    # partial"), una extensión que ffmpeg no reconoce — sin este
    # `-f` explícito, `open()` fallaba con "Unable to choose an
    # output format" (código de salida 234), un defecto real
    # descubierto con ejecución real de `ExportSession` de punta a
    # punta (no aparece al instanciar un encoder de forma aislada con
    # una ruta ya terminada en la extensión correcta) — ver GAP-066.
    _ffmpeg_container_format: str = ""
    lossless: bool = True

    def __init__(self, fmt, out_path, total_frames_hint: int = 0, **options):
        super().__init__(fmt, out_path, **options)
        self.total_frames_hint = total_frames_hint
        self._proc = None
        self._encoder_used = None
        self._closed = False
        # Orden Golden de Exportación (EX-10): stderr se drena en un hilo
        # dedicado a un buffer ACOTADO — un ffmpeg verboso nunca puede
        # llenar el pipe y bloquear la escritura de audio en stdin.
        self._stderr_tail = collections.deque(maxlen=64)
        self._stderr_thread = None
        self.process_timeout_s = None   # None → proporcional a la duración

    # ── a implementar por subclase ──────────────────────────────────
    def _output_args(self, encoder_name: str) -> list:
        raise NotImplementedError

    def _pick_encoder_name(self) -> str:
        if not FFMPEG_CAPS.get("available"):
            raise ExportAbortError(
                f"{self.codec_name}: ffmpeg no está disponible en este sistema "
                f"— no se puede exportar a {self.codec_name} vía streaming.")
        for name, caps_key in zip(self._ffmpeg_encoder_candidates, self._caps_keys):
            if FFMPEG_CAPS.get(caps_key):
                return name
        raise ExportAbortError(
            f"{self.codec_name}: ningún encoder ffmpeg disponible "
            f"(se probaron: {', '.join(self._ffmpeg_encoder_candidates)}).")

    def open(self) -> None:
        if not self._ffmpeg_container_format:
            raise NotImplementedError(
                f"{type(self).__name__} no declara _ffmpeg_container_format")
        encoder_name = self._pick_encoder_name()
        self._encoder_used = encoder_name
        cmd = ([FFMPEG_CAPS["path"], "-y", "-v", "error",
                "-f", "f32le", "-ar", str(self.fmt.rate),
                "-ac", str(self.fmt.channels), "-i", "pipe:0"]
               + self._output_args(encoder_name)
               + ["-f", self._ffmpeg_container_format, self.out_path])
        try:
            self._proc = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE)
        except OSError as e:
            raise ExportAbortError(
                f"{self.codec_name}: no se pudo iniciar el proceso ffmpeg: {e}")
        self._closed = False
        self._stderr_thread = threading.Thread(
            target=self._drain_stderr, args=(self._proc,), daemon=True,
            name=f"ffmpeg-stderr-{self.codec_name}")
        self._stderr_thread.start()

    def _drain_stderr(self, proc):
        try:
            for line in iter(proc.stderr.readline, b""):
                self._stderr_tail.append(line.decode(errors="replace").rstrip())
        except Exception:
            pass
        finally:
            try:
                proc.stderr.close()
            except Exception:
                pass

    @property
    def stderr_text(self) -> str:
        return "\n".join(self._stderr_tail)

    def _reap(self, timeout: float) -> None:
        """Espera al proceso con timeout; si vence: terminate → kill →
        wait. Nunca deja un proceso huérfano ni un hilo de stderr vivo."""
        proc = self._proc
        if proc is None:
            return
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            self._stderr_tail.append(f"[lorito] ffmpeg excedió {timeout:.0f}s — terminado")
        t = self._stderr_thread
        if t is not None:
            t.join(timeout=5)

    def abort(self) -> None:
        """Cancelación/limpieza: cierra stdin y mata el proceso."""
        proc = self._proc
        if proc is None:
            return
        self._closed = True
        try:
            if proc.stdin is not None:
                proc.stdin.close()
        except Exception:
            pass
        proc.stdin = None
        if proc.poll() is None:
            proc.kill()
        self._reap(timeout=5)

    def write(self, block: Block) -> None:
        if self._proc is None:
            raise ExportAbortError(
                f"{self.codec_name}Encoder.write() llamado sin open()")
        if self._proc.poll() is not None:
            self._raise_process_died()
        data = np.ascontiguousarray(block.data, dtype=np.float32)
        try:
            self._proc.stdin.write(data.tobytes())
        except (BrokenPipeError, OSError):
            self._raise_process_died()
        self.frames_written += block.n_frames

    def flush(self) -> None:
        if self._proc is None or self._proc.stdin is None:
            return
        try:
            self._proc.stdin.flush()
        except (BrokenPipeError, OSError):
            self._raise_process_died()

    def _raise_process_died(self):
        try:
            if self._proc.stdin is not None:
                self._proc.stdin.close()
        except Exception:
            pass
        self._proc.stdin = None
        self._reap(timeout=5)
        rc = self._proc.returncode
        raise ExportAbortError(
            f"{self.codec_name}: el proceso ffmpeg terminó de forma prematura "
            f"(código={rc}): {self.stderr_text[-300:]}")

    def _io_timeout(self) -> int:
        # Igual filosofía que los timeouts dinámicos del camino legado
        # (`OGGExporter._calc_ffmpeg_timeout`/`WVExporter`): proporcional
        # a la duración real, con un mínimo generoso — nunca un valor
        # fijo insuficiente para sesiones largas.
        dur_s = self.frames_written / max(self.fmt.rate, 1)
        return max(30, int(dur_s * 6 + 60))

    def finalize(self) -> None:
        if self._proc is None or self._closed:
            return
        self._closed = True
        if self._proc.stdin is not None:
            try:
                self._proc.stdin.close()
            except (BrokenPipeError, OSError):
                pass
            self._proc.stdin = None
        timeout = self.process_timeout_s or self._io_timeout()
        self._reap(timeout=timeout)
        if self._proc.returncode != 0:
            raise ExportAbortError(
                f"{self.codec_name}: ffmpeg terminó con código "
                f"{self._proc.returncode}: {self.stderr_text[-300:]}")

    def validate(self) -> dict:
        result = {"ok": False, "path": self.out_path, "error": "",
                   "actual_frames": 0, "actual_rate": self.fmt.rate,
                   "actual_channels": self.fmt.channels,
                   "encoder": self._encoder_used}
        if self._proc is not None and self._proc.returncode not in (0, None):
            result["error"] = f"ffmpeg terminó con código {self._proc.returncode}"
            return result
        if not os.path.exists(self.out_path):
            result["error"] = "archivo de salida no generado"
            return result
        if os.path.getsize(self.out_path) == 0:
            result["error"] = "archivo de salida vacío"
            return result

        exact = self._exact_frames_via_ffprobe()
        if exact is not None:
            result["actual_frames"] = exact
            result["ok"] = True
            if self.lossless:
                # Códec sin pérdida: el decodificador independiente debe
                # coincidir EXACTAMENTE con el conteo del contenedor.
                decoded = self._decode_count_frames()
                result["decoded_frames"] = decoded
                if decoded != exact:
                    result["ok"] = False
                    result["error"] = (f"decodificación independiente={decoded} "
                                       f"!= contenedor={exact}")
            return result

        # Fallback (solo si `ffprobe` no está disponible en este
        # sistema — ver `_ffprobe_path()`): decodificar el archivo
        # final completo a PCM crudo y contar bytes. Válido y exacto
        # para FLAC/WavPack (sin pérdida, verificado con ejecución
        # real a todos los tamaños probados, incluidos clips muy
        # cortos). Para OGG/Vorbis, este método puede SOBREESTIMAR el
        # conteo en streams MUY cortos (<~1.1 s) — se descubrió con
        # ejecución real (no documentado antes de este GAP) que el
        # propio decodificador de `ffmpeg` (no el muxer: `ffprobe`
        # confirma que el `duration_ts` del contenedor es exacto en
        # todos los casos) redondea la salida al siguiente múltiplo
        # del tamaño de bloque largo de Vorbis en vez de recortar al
        # `granulepos` real cuando hay muy pocos paquetes. Por eso
        # `_exact_frames_via_ffprobe()` es SIEMPRE el camino preferido
        # — este fallback solo se ejercita si `ffprobe` falta.
        decoded = self._decode_count_frames()
        if decoded is None:
            result["error"] = "decodificador independiente no pudo leer el archivo final"
            return result
        result["actual_frames"] = decoded
        result["decoded_frames"] = decoded
        result["ok"] = True
        return result

    def _decode_count_frames(self):
        """Decodifica el archivo final con un proceso ffmpeg
        INDEPENDIENTE y cuenta los frames leyendo stdout en trozos
        (memoria acotada; antes se acumulaba todo el PCM en RAM)."""
        try:
            cmd = [FFMPEG_CAPS["path"], "-nostdin", "-v", "error", "-i", self.out_path,
                   "-f", "f32le", "-ar", str(self.fmt.rate),
                   "-ac", str(self.fmt.channels), "-"]
            # stdin=DEVNULL: un decodificador que heredara el stdin del
            # proceso padre (terminal o pipe que nunca cierra) podía quedar
            # bloqueado para siempre — hallado con la batería completa en
            # segundo plano. La lectura de stdout es bloqueante, así que el
            # plazo lo impone un temporizador que MATA el proceso (el read
            # recibe EOF), no una comprobación entre lecturas.
            proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL)
            n_bytes = 0
            timed_out = threading.Event()

            def _expire():
                timed_out.set()
                try:
                    proc.kill()
                except OSError:
                    pass
            watchdog = threading.Timer(self._io_timeout(), _expire)
            watchdog.daemon = True
            watchdog.start()
            try:
                while True:
                    chunk = proc.stdout.read(1 << 20)
                    if not chunk:
                        break
                    n_bytes += len(chunk)
            finally:
                watchdog.cancel()
            if timed_out.is_set():
                proc.stdout.close()
                proc.wait()
                return None
            proc.stdout.close()
            rc = proc.wait(timeout=30)
            bytes_per_frame = 4 * self.fmt.channels
            if rc != 0 or n_bytes % bytes_per_frame != 0:
                return None
            return n_bytes // bytes_per_frame
        except Exception:
            return None

    @staticmethod
    def _ffprobe_path():
        """`ffprobe` viaja en el mismo paquete que `ffmpeg` (mismo
        directorio de instalación en la enorme mayoría de sistemas —
        confirmado en este sandbox: `/usr/bin/ffmpeg` +
        `/usr/bin/ffprobe`), pero `FFMPEG_CAPS` (`_probe_ffmpeg()`,
        `lorito_audio_backend.py`) solo sondea `ffmpeg` — se busca
        aquí, sin cachear (llamada barata, y así una instalación de
        `ffprobe` posterior al arranque de la app también se detecta).
        """
        import shutil
        p = shutil.which("ffprobe")
        if p:
            return p
        ffmpeg_path = FFMPEG_CAPS.get("path", "")
        if ffmpeg_path:
            candidate = os.path.join(os.path.dirname(ffmpeg_path), "ffprobe")
            if os.path.exists(candidate):
                return candidate
        return None

    def _exact_frames_via_ffprobe(self):
        """Conteo EXACTO de frames leyendo el `duration_ts`/`time_base`
        del stream de audio del contenedor final (metadato del muxer,
        NO un decode completo) — evita por completo el defecto de
        redondeo del decodificador de `ffmpeg` para streams Vorbis muy
        cortos documentado en `validate()`. Devuelve `None` (nunca un
        valor adivinado) si `ffprobe` no está disponible o si el
        `time_base` reportado no es exactamente `1/fmt.rate` (caso no
        visto en la práctica para estos tres codecs, pero verificado
        explícitamente en vez de asumido)."""
        ffprobe_path = self._ffprobe_path()
        if not ffprobe_path:
            return None
        try:
            cmd = [ffprobe_path, "-v", "error", "-select_streams", "a:0",
                   "-show_entries", "stream=duration_ts,time_base",
                   "-of", "default=noprint_wrappers=1", self.out_path]
            proc = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, timeout=30)
            if proc.returncode != 0:
                return None
            info = {}
            for line in proc.stdout.decode(errors="replace").splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    info[k.strip()] = v.strip()
            duration_ts_raw = info.get("duration_ts")
            time_base_raw = info.get("time_base")
            if not duration_ts_raw or duration_ts_raw == "N/A":
                return None
            if not time_base_raw or "/" not in time_base_raw:
                return None
            duration_ts = int(duration_ts_raw)
            num_str, den_str = time_base_raw.split("/", 1)
            num, den = int(num_str), int(den_str)
            if den <= 0 or num <= 0:
                return None
            frames_f = duration_ts * num * self.fmt.rate / den
            frames = round(frames_f)
            if abs(frames_f - frames) > 1e-6:
                # `time_base` no es exactamente `1/fmt.rate` — no
                # adivinar, dejar que el fallback de decode se
                # encargue (o falle de forma explícita).
                return None
            return frames
        except Exception:
            return None


class FlacEncoder(_FfmpegPipeEncoder):
    """FLAC streaming — sin pérdida, por diseño round-trip exacto."""

    codec_name = "FLAC"
    _ffmpeg_encoder_candidates = ("flac",)
    _caps_keys = ("flac",)
    _ffmpeg_container_format = "flac"

    def __init__(self, fmt, out_path, compression_level: int = 4,
                 bit_depth: int = 24, total_frames_hint: int = 0, **options):
        super().__init__(fmt, out_path, total_frames_hint=total_frames_hint, **options)
        # Mismo rango 0-8 que `FLAC_COMP_N` (`lorito_constants.py`) — el
        # camino legado (`FLACExporter`) usa el mismo valor tal cual.
        self.compression_level = compression_level
        # Orden Golden (Fase 3): profundidad EXPLÍCITA. Antes el pipe
        # f32le → flac dejaba que ffmpeg eligiera el formato de muestra.
        if bit_depth not in (16, 24):
            raise ExportAbortError(f"FLAC: profundidad no soportada: {bit_depth}")
        self.bit_depth = bit_depth

    def _output_args(self, encoder_name: str) -> list:
        if self.bit_depth == 16:
            depth = ["-sample_fmt", "s16"]
        else:
            depth = ["-sample_fmt", "s32", "-bits_per_raw_sample", "24"]
        return ["-c:a", encoder_name, *depth,
                "-compression_level", str(self.compression_level)]


class OggEncoder(_FfmpegPipeEncoder):
    """OGG/Vorbis streaming — mismas flags de calidad probadas en
    `OGGExporter` (VBR puro, sin `-maxrate`/`-minrate`/`-bufsize`,
    `-page_duration 500000` para páginas Ogg del tamaño correcto para
    seek preciso, ver los comentarios extensos en
    `lorito_exporters.py::OGGExporter._encode()` sobre por qué esas
    flags concretas corrigen el `granulepos` de la página EOS).

    Nota real (no documentada antes de GAP-066, descubierta con
    ejecución real): el candidato de respaldo "vorbis" (el nativo de
    ffmpeg, distinto de "libvorbis") solo admite audio ESTÉREO (2
    canales) — con mono falla con "Current FFmpeg Vorbis encoder only
    supports 2 channels". Sin impacto práctico en este proyecto (la
    producción captura siempre en estéreo, `CE_CHANNELS=2`, sin ruta
    de captura mono hoy — ver FASE 6/GAP-014), pero documentado aquí
    por si alguna vez se usa este encoder con audio mono y solo
    "vorbis" está disponible (sin "libvorbis", que sí admite mono)."""

    codec_name = "OGG"
    lossless = False
    _ffmpeg_encoder_candidates = ("libvorbis", "vorbis")
    _caps_keys = ("libvorbis", "vorbis")
    _ffmpeg_container_format = "ogg"

    def __init__(self, fmt, out_path, quality: float = 5.0,
                 total_frames_hint: int = 0, **options):
        super().__init__(fmt, out_path, total_frames_hint=total_frames_hint, **options)
        # Mismo rango 1-10 que `OGG_QUAL_N` (`lorito_constants.py`).
        self.quality = float(quality)

    def _output_args(self, encoder_name: str) -> list:
        args = ["-vn", "-map_metadata", "-1", "-c:a", encoder_name]
        if encoder_name == "vorbis":
            # El encoder nativo "vorbis" (no libvorbis) de ffmpeg exige
            # -strict -2 — mismo flag que `OGGExporter` usa para su
            # "Intento 2" con este mismo encoder.
            args += ["-strict", "-2"]
        args += ["-q:a", f"{self.quality:.1f}", "-page_duration", "500000"]
        return args


class WvEncoder(_FfmpegPipeEncoder):
    """WavPack streaming — sin pérdida, generaliza el patrón de pipe
    directo que `WVExporter` ya usa en producción (antes con WAV
    intermedio en RAM; aquí con `f32le` crudo directo, sin necesitar
    la conversión manual a s24le)."""

    codec_name = "WV"
    _ffmpeg_encoder_candidates = ("libwavpack", "wavpack")
    _caps_keys = ("libwavpack", "wavpack")
    _ffmpeg_container_format = "wv"

    def __init__(self, fmt, out_path, compression_level: str = "5",
                 total_frames_hint: int = 0, **options):
        super().__init__(fmt, out_path, total_frames_hint=total_frames_hint, **options)
        # Mismos valores string ("1"/"5"/"7"/"8") que `WV_FLAGS`
        # (`lorito_constants.py`) — el camino legado (`WVExporter`)
        # los usa tal cual como `-compression_level`.
        self.compression_level = str(compression_level)

    def _output_args(self, encoder_name: str) -> list:
        return ["-c:a", encoder_name, "-compression_level", self.compression_level]
