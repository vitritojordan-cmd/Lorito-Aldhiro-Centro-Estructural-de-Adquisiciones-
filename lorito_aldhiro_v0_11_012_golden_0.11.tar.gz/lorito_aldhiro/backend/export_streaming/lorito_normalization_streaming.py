from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Los 20 modos de normalización de exportación, en streaming de dos pasadas.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_normalization_streaming.py — cierre completo del frente de
normalización streaming (GAP-028 + GAP-029), diseño de dos pasadas de
GAP-027 (auditoría de streamabilidad de los 20 modos de
`NormalizationMode`).

Patrón general — PASE 1 medir → PASE 2 aplicar:
  1. `measure_*` — recorren los segmentos vía `SegmentProvider.
     iter_blocks()`, acumulando solo escalares o arrays pequeños
     O(n_bloques) — nunca O(duración).
  2. `compute_*_gain` — misma fórmula EXACTA que la función legada
     correspondiente en `lorito_normalization.py`/`lorito_
     normalization_v21.py` — se importa `_norm_db_to_linear`/
     `_norm_linear_to_db` directamente, nunca se reimplementa la
     matemática, para que el camino streaming y el legado (el que la
     GUI sigue usando hoy) no puedan divergir.
  3. `export_with_scalar_gain` / `export_with_block_transform` — PASE
     2: nuevo `SegmentProvider` (segunda lectura real desde disco,
     nunca se retiene el array del pase 1) + `ExportSession.
     block_transform` (GAP-028) aplicando la ganancia/curva ya
     calculada mientras se codifica.

Clasificación completa (ver GAP-027):
  Categoría A (ganancia escalar): PEAK_SIMPLE, RMS_20/18/14, LUFS_23/
    16/14, INTELLIGENT_PEAK, TRUE_PEAK/x4, PRESERVATIVE, NOISE_AWARE,
    MID_SIDE, CREST_GUARD.
  Categoría B (curva por bloque): ADAPTIVE_BLOCK.
  Categoría C (meta-modo, se resuelve en A o B): AUTO, presets de
    cinta (v21), TWO_PASS (v21) — no implementados como funciones
    aparte en este módulo: la GUI ya los resuelve eligiendo el modo
    base antes de llamar a export(); una vez resuelto el modo, cae en
    A o B.
  Proceso adicional: soft limiter (v21, `make_soft_limiter_transform`)
    — causal/stateful, streaming por construcción.

Única excepción documentada a la bit-exactitud (no un bug, un límite
real): `measure_intelligent_peak_streaming` aproxima
`np.percentile(abs(audio), percentile)` con un histograma de 65536
bins — un percentil exacto requiere orden total de los datos,
incompatible con memoria O(1). El error resultante se mide y se acota
explícitamente en los tests (`tests/test_normalization_streaming.py`),
nunca se afirma una bit-exactitud que no se puede lograr sin
materializar la señal completa.

`measure_true_peak_streaming` tiene una nota similar y ACOTADA (no
aproximada, sino potencialmente distinta solo en los límites de
segmento) — ver su docstring.

Todavía NO wireado a `main_window.export()` — sigue bloqueado por la
falta de PySide6 ejecutable en este sandbox (GAP-025/026/027/028).
"""

import math as _math

import numpy as np
from scipy.signal import lfilter

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider, DEFAULT_BLOCK_FRAMES,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
    ExportSession, ExportSessionReport,
)
from lorito_aldhiro.backend.export.lorito_normalization import (
    _norm_db_to_linear, _norm_linear_to_db, NORM_DEFAULT_CEILING_DBFS,
    NORM_BLOCK_SECS, NORM_BLOCK_XFADE_FRAMES, _CRAC_MIN_CF_DEFAULT,
    _CRAC_ANALYSIS_BLOCK, _CRAC_SILENCE_THR,
)

NORM_ANALYSIS_CHUNK = 65536  # mismo valor que lorito_normalization.py


# ═════════════════════════════════════════════════════════════════════
#  Acumuladores base
# ═════════════════════════════════════════════════════════════════════

def measure_peak_rms_streaming(segment_paths, block_frames: int = DEFAULT_BLOCK_FRAMES):
    """Peak global + RMS global en una sola pasada. Devuelve
    (peak_linear, rms_linear)."""
    provider = SegmentProvider(segment_paths)
    peak = 0.0
    sum_sq = 0.0
    n_total = 0
    for blk in provider.iter_blocks(block_frames):
        if blk.data.size == 0:
            continue
        pk = float(np.max(np.abs(blk.data)))
        if pk > peak:
            peak = pk
        sum_sq += float(np.sum(blk.data.astype(np.float64) ** 2))
        n_total += blk.data.size
    rms = float(np.sqrt(sum_sq / max(n_total, 1)))
    return peak, rms


def measure_peak_streaming(segment_paths, block_frames: int = DEFAULT_BLOCK_FRAMES) -> float:
    """Pico absoluto lineal de toda la sesión, medido en streaming
    (memoria O(block_frames))."""
    peak, _ = measure_peak_rms_streaming(segment_paths, block_frames)
    return peak


def measure_rms_streaming(segment_paths, block_frames: int = DEFAULT_BLOCK_FRAMES):
    """Réplica streaming exacta del PASO 1 de `_norm_rms`. Devuelve
    (rms_linear, peak_linear) — ORDEN histórico de GAP-028, mantenido
    por compatibilidad con el código/tests existentes."""
    peak, rms = measure_peak_rms_streaming(segment_paths, block_frames)
    return rms, peak


def measure_block_rms_streaming(segment_paths, block_frames: int, subsample: int = 1):
    """Réplica streaming exacta del patrón `for start in range(0, n,
    block_f*subsample): rms(audio[start:start+block_f])` usado por
    `_norm_noise_aware`/`_norm_with_tape_preset` (subsample=4) y por
    `_two_pass_analysis` (subsample=1).

    Los bloques se alinean a POSICIÓN ABSOLUTA (vía `Block.
    frame_offset`), no a los límites de lectura de disco — el
    resultado no depende de cómo `SegmentProvider` trocee los
    segmentos. Descarta el último bloque parcial, igual que el legado
    (`range(0, n_frames - block_f, stride)`).

    Devuelve la lista de RMS por bloque (float lineal), en orden."""
    provider = SegmentProvider(segment_paths)
    total_frames = provider.total_frames
    block_f = block_frames
    stride = block_f * subsample
    starts = list(range(0, max(total_frames - block_f, 0), stride))
    if not starts:
        return []

    results = [None] * len(starts)
    next_idx = 0
    pending = []
    pending_start_abs = 0
    pending_len = 0

    def _flush_ready():
        nonlocal next_idx, pending, pending_start_abs, pending_len
        while next_idx < len(starts):
            s = starts[next_idx]
            need_end = s + block_f
            if need_end > pending_start_abs + pending_len:
                break
            buf = np.concatenate(pending, axis=0) if len(pending) > 1 else pending[0]
            lo = s - pending_start_abs
            hi = lo + block_f
            chunk = buf[lo:hi]
            rms = float(np.sqrt(np.mean(chunk.astype(np.float64) ** 2)))
            results[next_idx] = rms
            next_idx += 1
            new_start = starts[next_idx] if next_idx < len(starts) else pending_start_abs + pending_len
            # BUG real corregido en GAP-029: recortar el buffer más allá
            # de los datos que REALMENTE tiene (cuando `new_start` cae
            # en una posición aún no leída del disco) desalinea
            # `pending_start_abs` respecto al contenido real del buffer
            # — toda ventana posterior queda desplazada. `cut` se acota
            # al tamaño real del buffer.
            cut = min(new_start - pending_start_abs, buf.shape[0])
            if cut > 0:
                buf = buf[cut:]
                pending_start_abs += cut
                pending_len = buf.shape[0]
                pending = [buf] if buf.shape[0] else []

    for blk in provider.iter_blocks(block_frames=max(block_f, DEFAULT_BLOCK_FRAMES)):
        if blk.data.size == 0:
            continue
        pending.append(blk.data)
        pending_len += blk.data.shape[0]
        _flush_ready()

    return [r for r in results if r is not None]


# ═════════════════════════════════════════════════════════════════════
#  Categoría A — modos de ganancia escalar
# ═════════════════════════════════════════════════════════════════════

def compute_peak_simple_gain(peak_linear: float) -> float:
    """Misma fórmula EXACTA que la rama `PEAK_SIMPLE` de
    `_apply_normalization_advanced`: ganancia a -0.2 dBFS."""
    if peak_linear < 1e-9:
        return 1.0
    return _norm_db_to_linear(-0.2) / peak_linear


def compute_rms_gain(rms_linear: float, peak_linear: float,
                     target_rms_db: float,
                     ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                     max_gain_db: float = 40.0) -> float:
    """Misma fórmula EXACTA que los PASOS 2-3 de `_norm_rms`."""
    if rms_linear < 1e-9:
        return 1.0
    target_rms_linear = _norm_db_to_linear(target_rms_db)
    gain = target_rms_linear / rms_linear
    max_gain_linear = _norm_db_to_linear(max_gain_db)
    if gain > max_gain_linear:
        gain = max_gain_linear
    ceiling_linear = _norm_db_to_linear(ceiling_db)
    peak_post = peak_linear * gain
    if peak_post > ceiling_linear:
        gain = ceiling_linear / max(peak_linear, 1e-12)
    return gain


def compute_preservative_gain(peak_linear: float, ceiling_db: float = -6.0,
                              max_gain_db: float = 40.0) -> float:
    """Misma fórmula que `_norm_preservative` — ambas ramas de su
    if/else calculan el mismo `gain = ceiling_lin / peak_linear`."""
    ceiling_lin = _norm_db_to_linear(ceiling_db)
    gain = ceiling_lin / max(peak_linear, 1e-12)
    max_gain_linear = _norm_db_to_linear(max_gain_db)
    if gain > max_gain_linear:
        gain = max_gain_linear
    return gain


def compute_noise_aware_gain(rms_linear: float, peak_linear: float,
                             block_rmss_sorted: list,
                             target_rms_db: float = -18.0,
                             max_gain_db: float = 20.0,
                             ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                             noise_threshold_db: float = -50.0) -> float:
    """Misma fórmula que `_norm_noise_aware`. `block_rmss_sorted` debe
    venir ordenado, típicamente de
    `measure_block_rms_streaming(..., subsample=4)` + `sorted()`."""
    if block_rmss_sorted:
        p10_idx = max(0, int(len(block_rmss_sorted) * 0.10))
        p10_idx = min(p10_idx, len(block_rmss_sorted) - 1)
        noise_floor_db = _norm_linear_to_db(block_rmss_sorted[p10_idx])
    else:
        noise_floor_db = _norm_linear_to_db(rms_linear)

    effective_max_gain_db = max_gain_db
    if noise_floor_db > noise_threshold_db:
        safe_gain_limit = (target_rms_db - 6.0) - noise_floor_db
        if safe_gain_limit < effective_max_gain_db:
            effective_max_gain_db = max(0.0, safe_gain_limit)

    target_rms_lin = _norm_db_to_linear(target_rms_db)
    gain_needed = target_rms_lin / max(rms_linear, 1e-12)
    gain_needed_db = _norm_linear_to_db(gain_needed)

    gain = (_norm_db_to_linear(effective_max_gain_db)
            if gain_needed_db > effective_max_gain_db else gain_needed)

    ceiling_lin = _norm_db_to_linear(ceiling_db)
    if peak_linear * gain > ceiling_lin:
        gain = ceiling_lin / max(peak_linear, 1e-12)
    return gain


def compute_crest_guard_gain(rms_linear: float, peak_linear: float,
                             min_crest_factor_db: float = _CRAC_MIN_CF_DEFAULT,
                             target_rms_db: float = -18.0,
                             ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                             max_gain_db: float = 40.0) -> float:
    """Misma fórmula que `_apply_with_crest_guard` (rama RMS_18, la
    que usa el dispatcher para CREST_GUARD). La ganancia lineal no
    altera el crest factor — CF_post == CF_pre salvo que el ceiling ya
    hubiera recortado, así que basta evaluar el guard analíticamente
    sobre el resultado de `compute_rms_gain`."""
    gain = compute_rms_gain(rms_linear, peak_linear, target_rms_db, ceiling_db, max_gain_db)
    if peak_linear < 1e-9 or rms_linear < 1e-9:
        return gain
    peak_db = _norm_linear_to_db(peak_linear)
    rms_db = _norm_linear_to_db(rms_linear)
    gain_db = _norm_linear_to_db(gain)
    peak_post_db = peak_db + gain_db
    rms_post_db = rms_db + gain_db
    cf_post = peak_post_db - rms_post_db
    if cf_post < min_crest_factor_db and gain_db > 0.0:
        target_rms_db_cg = peak_post_db - min_crest_factor_db
        if target_rms_db_cg < rms_post_db:
            reduction_linear = (_norm_db_to_linear(target_rms_db_cg)
                                / _norm_db_to_linear(rms_post_db))
            if reduction_linear < 1.0:
                gain *= reduction_linear
    return gain


def measure_mid_side_streaming(segment_paths, block_frames: int = DEFAULT_BLOCK_FRAMES):
    """mid_rms_linear, side_rms_linear — misma fórmula que
    `_analyze_mid_side` (`mid=(L+R)/sqrt2`, `side=(L-R)/sqrt2`)."""
    provider = SegmentProvider(segment_paths)
    INV_SQRT2 = 1.0 / _math.sqrt(2.0)
    sum_sq_mid = 0.0
    sum_sq_side = 0.0
    n_total = 0
    for blk in provider.iter_blocks(block_frames):
        if blk.data.size == 0 or blk.data.shape[1] < 2:
            continue
        L = blk.data[:, 0].astype(np.float64)
        R = blk.data[:, 1].astype(np.float64)
        mid = (L + R) * INV_SQRT2
        side = (L - R) * INV_SQRT2
        sum_sq_mid += float(np.sum(mid ** 2))
        sum_sq_side += float(np.sum(side ** 2))
        n_total += L.shape[0]
    mid_rms = float(np.sqrt(sum_sq_mid / max(n_total, 1)))
    side_rms = float(np.sqrt(sum_sq_side / max(n_total, 1)))
    return mid_rms, side_rms


def compute_mid_side_gains(mid_rms_linear: float, side_rms_linear: float,
                           ms_target_rms_db: float = -18.0,
                           max_side_gain_db: float = 6.0,
                           max_stereo_balance_index: float = 0.70):
    """Misma fórmula que `_norm_mid_side` con `ms_norm_mode=RMS_18`
    (el default del dispatcher). Devuelve (mid_gain, side_gain)."""
    mid_gain = compute_rms_gain(mid_rms_linear, mid_rms_linear, ms_target_rms_db)
    side_gain = compute_rms_gain(side_rms_linear, side_rms_linear, ms_target_rms_db)

    if _norm_linear_to_db(side_gain) > max_side_gain_db:
        side_gain = _norm_db_to_linear(max_side_gain_db)

    mid_rms_post = mid_rms_linear * mid_gain
    side_rms_post = side_rms_linear * side_gain
    denom_post = mid_rms_post + side_rms_post
    sbi_post = (side_rms_post / denom_post) if denom_post > 1e-9 else 0.0

    if sbi_post > max_stereo_balance_index and max_stereo_balance_index < 1.0:
        target_side_rms = mid_rms_post * max_stereo_balance_index / (1.0 - max_stereo_balance_index)
        if side_rms_post > 1e-9:
            side_gain *= target_side_rms / side_rms_post

    return mid_gain, side_gain


def _mid_side_gain_transform(mid_gain: float, side_gain: float):
    INV_SQRT2 = np.float32(1.0 / _math.sqrt(2.0))
    mg = np.float32(mid_gain)
    sg = np.float32(side_gain)

    def _transform(blk: Block) -> Block:
        data = blk.data
        if data.shape[1] < 2:
            return blk
        L = data[:, 0]
        R = data[:, 1]
        mid = (L + R) * INV_SQRT2
        side = (L - R) * INV_SQRT2
        mid_n = mid * mg
        side_n = side * sg
        L_out = np.clip((mid_n + side_n) * INV_SQRT2, -1.0, 1.0).astype(np.float32)
        R_out = np.clip((mid_n - side_n) * INV_SQRT2, -1.0, 1.0).astype(np.float32)
        out = np.stack([L_out, R_out], axis=1)
        return Block(data=out, frame_offset=blk.frame_offset, is_last=blk.is_last)

    return _transform


def measure_true_peak_streaming(segment_paths, oversample: int = 2,
                                chunk_frames: int = NORM_ANALYSIS_CHUNK) -> float:
    """Réplica streaming de `_norm_true_peak` — mismo tamaño de chunk
    (`NORM_ANALYSIS_CHUNK`), misma interpolación con clamp en los
    bordes. Nota ACOTADA (no aproximación, un límite de posición):
    igual que `_resample_stateful` (GAP-026), el clamp de borde ocurre
    en cada límite de CHUNK, y `SegmentProvider` reinicia el trozado
    en cada límite de SEGMENTO — para sesiones reales (segmentos de
    minutos, chunk ~1.4s) la discrepancia queda acotada a como mucho
    una interpolación de borde por segmento; medida explícitamente en
    los tests con sesiones multi-segmento, no asumida cero."""
    provider = SegmentProvider(segment_paths)
    true_peak_linear = 0.0
    n_ch = provider.channels

    for blk in provider.iter_blocks(block_frames=chunk_frames):
        chunk = blk.data.astype(np.float64)
        n_c = len(chunk)
        if n_c < 2:
            continue
        if oversample == 2:
            t_os = np.linspace(0, n_c - 1, n_c * 2, dtype=np.float64)
            xi = np.floor(t_os).astype(np.int64)
            frac = (t_os - xi).astype(np.float64)
            xi1 = np.minimum(xi + 1, n_c - 1)
            for ch in range(n_ch):
                col = chunk[:, ch]
                os_ch = col[xi] + frac * (col[xi1] - col[xi])
                pk = float(np.max(np.abs(os_ch)))
                if pk > true_peak_linear:
                    true_peak_linear = pk
        else:
            t_os = np.linspace(0, n_c - 1, n_c * 4, dtype=np.float64)
            i1 = np.floor(t_os).astype(np.int64)
            mu = (t_os - i1).astype(np.float64)
            i0 = np.maximum(i1 - 1, 0)
            i2 = np.minimum(i1 + 1, n_c - 1)
            i3 = np.minimum(i1 + 2, n_c - 1)
            mu2 = mu * mu
            mu3 = mu2 * mu
            c0 = -0.5 * mu3 + mu2 - 0.5 * mu
            c1 = 1.5 * mu3 - 2.5 * mu2 + 1.0
            c2 = -1.5 * mu3 + 2.0 * mu2 + 0.5 * mu
            c3 = 0.5 * mu3 - 0.5 * mu2
            for ch in range(n_ch):
                col = chunk[:, ch]
                os_ch = c0 * col[i0] + c1 * col[i1] + c2 * col[i2] + c3 * col[i3]
                pk = float(np.max(np.abs(os_ch)))
                if pk > true_peak_linear:
                    true_peak_linear = pk
    return true_peak_linear


def compute_true_peak_gain(true_peak_linear: float, ceiling_db: float = -1.0) -> float:
    if true_peak_linear < 1e-9:
        return 1.0
    return _norm_db_to_linear(ceiling_db) / true_peak_linear


# ── LUFS ────────────────────────────────────────────────────────────

def _k_weight_coeffs(fs: int):
    if abs(fs - 48000) < 100:
        b1s = np.array([1.53512485958697, -2.69169618940638, 1.19839281085285])
        a1s = np.array([1.0, -1.69065929318241, 0.73248077421585])
    elif abs(fs - 44100) < 100:
        b1s = np.array([1.5308412300498, -2.6509948062498, 1.1690668057498])
        a1s = np.array([1.0, -1.6636551132791, 0.7125954280786])
    else:
        ratio = fs / 48000.0
        b1s = np.array([1.53512485958697 / ratio, -2.69169618940638, 1.19839281085285 * ratio])
        a1s = np.array([1.0, -1.69065929318241, 0.73248077421585])

    f0 = 38.5 / fs
    Q = 0.5
    w0 = 2.0 * np.pi * f0
    alpha = np.sin(w0) / (2.0 * Q)
    b2s = np.array([1.0, -2.0, 1.0])
    a2s = np.array([1.0 + alpha, -2.0 * np.cos(w0), 1.0 - alpha])
    b2s = b2s / a2s[0]
    a2s = a2s / a2s[0]
    return b1s, a1s, b2s, a2s


def measure_lufs_streaming(segment_paths, rate: int,
                           block_frames: int = DEFAULT_BLOCK_FRAMES):
    """Réplica streaming de `_norm_lufs` (K-weighting BS.1770
    simplificado + gating de bloques de 400ms/hop 100ms). El biquad se
    aplica con `scipy.signal.lfilter(zi=..., zf=...)` encadenado entre
    bloques — matemáticamente idéntico a una sola llamada sobre el
    array completo (verificado en GAP-029). La ventana deslizante de
    gating se mantiene en un buffer acotado a ~400ms, memoria O(1)
    respecto a la duración. Devuelve (lufs_measured, peak_linear)."""
    b1s, a1s, b2s, a2s = _k_weight_coeffs(rate)
    provider = SegmentProvider(segment_paths)
    n_ch = provider.channels

    block_f = int(0.400 * rate)
    hop_f = int(0.100 * rate)
    if block_f < 1:
        block_f = max(1, provider.total_frames // 4)
        hop_f = max(1, block_f // 4)

    zi_stage1 = [np.zeros(2) for _ in range(n_ch)]
    zi_stage2 = [np.zeros(2) for _ in range(n_ch)]

    peak = 0.0
    block_loudnesses = []
    k_sq_pending = []
    k_sq_start_abs = 0
    k_sq_len = 0
    next_pos = 0

    def _flush_ready():
        nonlocal next_pos, k_sq_pending, k_sq_start_abs, k_sq_len
        while True:
            need_end = next_pos + block_f
            avail_end = k_sq_start_abs + k_sq_len
            if need_end > avail_end:
                break
            buf = np.concatenate(k_sq_pending, axis=0) if len(k_sq_pending) > 1 else k_sq_pending[0]
            lo = next_pos - k_sq_start_abs
            hi = lo + block_f
            window = buf[lo:hi]
            block_mean_sq = float(np.mean(window))
            if block_mean_sq > 1e-12:
                loudness_lu = -0.691 + 10.0 * float(np.log10(block_mean_sq))
                block_loudnesses.append(loudness_lu)
            next_pos += hop_f
            new_start = next_pos
            cut = new_start - k_sq_start_abs
            if cut > 0 and cut <= buf.shape[0]:
                buf = buf[cut:]
                k_sq_start_abs = new_start
                k_sq_len = buf.shape[0]
                k_sq_pending = [buf] if buf.shape[0] else []
            else:
                break

    for blk in provider.iter_blocks(block_frames):
        if blk.data.size == 0:
            continue
        pk = float(np.max(np.abs(blk.data)))
        if pk > peak:
            peak = pk

        k_sq_block = np.zeros(blk.data.shape[0], dtype=np.float64)
        for ch in range(n_ch):
            sig = blk.data[:, ch].astype(np.float64)
            y1, zi_stage1[ch] = lfilter(b1s, a1s, sig, zi=zi_stage1[ch])
            y2, zi_stage2[ch] = lfilter(b2s, a2s, y1, zi=zi_stage2[ch])
            k_sq_block += y2 ** 2
        k_sq_block /= n_ch

        k_sq_pending.append(k_sq_block)
        k_sq_len += k_sq_block.shape[0]
        _flush_ready()

    if not block_loudnesses:
        lufs_measured = float("-inf")
    else:
        abs_thresh = -70.0
        gated_abs = [l for l in block_loudnesses if l > abs_thresh]
        if not gated_abs:
            gated_abs = block_loudnesses
        mean_abs = float(np.mean(gated_abs))
        rel_thresh = mean_abs - 10.0
        gated_rel = [l for l in gated_abs if l > rel_thresh]
        if not gated_rel:
            gated_rel = gated_abs
        lufs_measured = float(np.mean(gated_rel))

    return lufs_measured, peak


def compute_lufs_gain(lufs_measured: float, peak_linear: float,
                      target_lufs: float, ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                      max_gain_db: float = 40.0) -> float:
    if lufs_measured <= float("-inf") or lufs_measured < -200:
        return 1.0
    gain_db = target_lufs - lufs_measured
    gain = _norm_db_to_linear(gain_db)
    max_gain_linear = _norm_db_to_linear(max_gain_db)
    if gain > max_gain_linear:
        gain = max_gain_linear
    ceiling_linear = _norm_db_to_linear(ceiling_db)
    if peak_linear * gain > ceiling_linear:
        gain_ceiling = ceiling_linear / max(peak_linear, 1e-12)
        if gain_ceiling < gain:
            gain = gain_ceiling
    return gain


# ── INTELLIGENT_PEAK (única aproximación del módulo — ver docstring) ─

def measure_intelligent_peak_streaming(segment_paths, percentile: float = 99.9,
                                       n_bins: int = 65536,
                                       block_frames: int = DEFAULT_BLOCK_FRAMES):
    """Aproxima `np.percentile(abs(audio), percentile)` con un
    histograma de `n_bins` acumulado en streaming sobre [0,1].
    Devuelve (effective_peak, true_peak), ambos lineales."""
    provider = SegmentProvider(segment_paths)
    hist = np.zeros(n_bins, dtype=np.int64)
    true_peak = 0.0
    n_total = 0
    for blk in provider.iter_blocks(block_frames):
        if blk.data.size == 0:
            continue
        abs_vals = np.abs(blk.data).ravel()
        pk = float(np.max(abs_vals)) if abs_vals.size else 0.0
        if pk > true_peak:
            true_peak = pk
        idx = np.minimum((abs_vals * n_bins).astype(np.int64), n_bins - 1)
        hist += np.bincount(idx, minlength=n_bins)
        n_total += abs_vals.size

    if n_total == 0:
        return 0.0, 0.0

    target_count = percentile / 100.0 * n_total
    cum = 0
    eff_bin = n_bins - 1
    for i in range(n_bins):
        cum += hist[i]
        if cum >= target_count:
            eff_bin = i
            break
    effective_peak = (eff_bin + 0.5) / n_bins
    return effective_peak, true_peak


def compute_intelligent_peak_gain(effective_peak: float,
                                  ceiling_db: float = NORM_DEFAULT_CEILING_DBFS) -> float:
    if effective_peak < 1e-9:
        return 1.0
    gain = _norm_db_to_linear(ceiling_db) / effective_peak
    gain_db = _norm_linear_to_db(gain)
    MAX_GAIN_DB = 40.0
    if gain_db > MAX_GAIN_DB:
        gain = _norm_db_to_linear(MAX_GAIN_DB)
    return gain


# ═════════════════════════════════════════════════════════════════════
#  Categoría B — ADAPTIVE_BLOCK (curva por bloque)
# ═════════════════════════════════════════════════════════════════════

def measure_adaptive_block_gains(segment_paths, rate: int,
                                 block_secs: float = NORM_BLOCK_SECS,
                                 target_rms_db: float = -18.0,
                                 ceiling_db: float = NORM_DEFAULT_CEILING_DBFS):
    """Réplica streaming de los PASOS 1-4 de `_norm_adaptive_block`
    (ganancia por bloque + suavizado gaussiano 3-tap). Devuelve
    (block_gains: np.ndarray, block_f: int)."""
    block_f = max(int(block_secs * rate), 1)
    provider = SegmentProvider(segment_paths)
    total_frames = provider.total_frames
    n_blocks = (total_frames + block_f - 1) // block_f if total_frames else 0

    sum_sq = np.zeros(max(n_blocks, 1), dtype=np.float64)
    peak_b = np.zeros(max(n_blocks, 1), dtype=np.float64)
    count = np.zeros(max(n_blocks, 1), dtype=np.int64)
    ceiling_lin = _norm_db_to_linear(ceiling_db)

    for blk in provider.iter_blocks(block_frames=max(block_f, DEFAULT_BLOCK_FRAMES)):
        if blk.data.size == 0:
            continue
        start_abs = blk.frame_offset
        n = blk.data.shape[0]
        pos = 0
        while pos < n:
            abs_pos = start_abs + pos
            bi = abs_pos // block_f
            bi_end_abs = min((bi + 1) * block_f, total_frames)
            take = min(bi_end_abs - abs_pos, n - pos)
            if take <= 0:
                break
            seg = blk.data[pos:pos + take]
            sum_sq[bi] += float(np.sum(seg.astype(np.float64) ** 2))
            pk = float(np.max(np.abs(seg))) if seg.size else 0.0
            if pk > peak_b[bi]:
                peak_b[bi] = pk
            count[bi] += seg.size
            pos += take

    SILENCE_THRESHOLD_DB = -60.0
    block_gains = np.ones(n_blocks, dtype=np.float64)
    for bi in range(n_blocks):
        n_c = max(count[bi], 1)
        rms = float(np.sqrt(sum_sq[bi] / n_c))
        rms_db = _norm_linear_to_db(rms)
        if rms_db < SILENCE_THRESHOLD_DB or rms < 1e-9:
            block_gains[bi] = 1.0
            continue
        target_lin = _norm_db_to_linear(target_rms_db)
        gain_raw = target_lin / rms
        if peak_b[bi] * gain_raw > ceiling_lin:
            gain_raw = ceiling_lin / max(peak_b[bi], 1e-12)
        block_gains[bi] = gain_raw

    if n_blocks >= 3:
        smoothed = block_gains.copy()
        for i in range(1, n_blocks - 1):
            smoothed[i] = (block_gains[i - 1] * 0.25 +
                          block_gains[i] * 0.50 +
                          block_gains[i + 1] * 0.25)
        block_gains = smoothed

    return block_gains, block_f


def _adaptive_block_transform(block_gains: np.ndarray, block_f: int,
                              xfade_frames: int, total_frames: int):
    """Transform de PASE 2 — puramente posicional (usa `Block.
    frame_offset`), misma matemática de crossfade que el PASO 5 de
    `_norm_adaptive_block`: `blended = raw*(g_prev*fade_out +
    g*fade_in)` es idéntico a recalcular `prev_block`/`curr_block` por
    separado porque ambos parten del mismo `raw` (ver GAP-029)."""
    xfade_f = min(xfade_frames, block_f // 4) if block_f >= 4 else 0

    def _transform(blk: Block) -> Block:
        data = blk.data.astype(np.float32)
        n = data.shape[0]
        out = np.empty_like(data)
        pos = 0
        while pos < n:
            abs_pos = blk.frame_offset + pos
            bi = abs_pos // block_f
            bi_start_abs = bi * block_f
            bi_end_abs = min(bi_start_abs + block_f, total_frames)
            take = min(bi_end_abs - abs_pos, n - pos)
            if take <= 0:
                break
            g = np.float32(block_gains[bi]) if bi < len(block_gains) else np.float32(1.0)
            seg = data[pos:pos + take]
            seg_out = seg * g

            rel_in_block = abs_pos - bi_start_abs
            if bi > 0 and xfade_f > 0 and rel_in_block < xfade_f:
                n_xf = min(take, xfade_f - rel_in_block)
                if n_xf > 0:
                    g_prev = np.float32(block_gains[bi - 1])
                    ramp_idx = np.arange(rel_in_block, rel_in_block + n_xf)
                    fade_in = ramp_idx.astype(np.float32) / np.float32(xfade_f)
                    fade_out = 1.0 - fade_in
                    if seg.ndim > 1:
                        fade_in = fade_in[:, np.newaxis]
                        fade_out = fade_out[:, np.newaxis]
                    raw_seg = seg[:n_xf]
                    seg_out[:n_xf] = raw_seg * (g_prev * fade_out + g * fade_in)

            out[pos:pos + take] = seg_out
            pos += take

        out = np.clip(out, -1.0, 1.0)
        return Block(data=out, frame_offset=blk.frame_offset, is_last=blk.is_last)

    return _transform


def export_adaptive_block(segment_paths, encoder_cls, final_path: str,
                          rate: int, encoder_kwargs: dict | None = None,
                          block_secs: float = NORM_BLOCK_SECS,
                          target_rms_db: float = -18.0,
                          ceiling_db: float = NORM_DEFAULT_CEILING_DBFS,
                          xfade_frames: int = NORM_BLOCK_XFADE_FRAMES,
                          block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    block_gains, block_f = measure_adaptive_block_gains(
        segment_paths, rate, block_secs, target_rms_db, ceiling_db)
    provider_probe = SegmentProvider(segment_paths)
    total_frames = provider_probe.total_frames
    transform = _adaptive_block_transform(block_gains, block_f, xfade_frames, total_frames)
    session = ExportSession(
        segment_paths, encoder_cls=encoder_cls, final_path=final_path,
        encoder_kwargs=encoder_kwargs, block_frames=block_frames,
        block_transform=transform,
    )
    return session.run()


# ═════════════════════════════════════════════════════════════════════
#  Soft limiter (v21) — causal/stateful, streaming por construcción
# ═════════════════════════════════════════════════════════════════════

def measure_soft_limiter_needed(segment_paths, ceiling_db: float = -0.2,
                                block_frames: int = DEFAULT_BLOCK_FRAMES) -> bool:
    """Réplica del check rápido de `_soft_limiter_conservative`: ¿hay
    algún over en TODA la sesión? Permite al pase 2 saltarse el
    limitador por completo cuando es innecesario, igual que el
    legado."""
    ceiling_lin = _norm_db_to_linear(ceiling_db)
    provider = SegmentProvider(segment_paths)
    for blk in provider.iter_blocks(block_frames):
        if blk.data.size == 0:
            continue
        if np.any(np.abs(blk.data) > ceiling_lin * 1.0001):
            return True
    return False


def make_soft_limiter_transform(ceiling_db: float = -0.2, knee_db: float = 6.0,
                                attack_frames: int = 64, release_frames: int = 2048):
    """`block_transform` con estado propio (closure) que replica
    `_soft_limiter_conservative` bloque a bloque. El suavizado
    ataque/release es una recursión puramente causal (solo depende de
    `g_prev`), así que encadenar el estado entre bloques da resultado
    IDÉNTICO a una sola llamada sobre el array completo (mismo
    argumento que `_resample_stateful` y el guard de la Fase 10)."""
    ceiling_lin = _norm_db_to_linear(ceiling_db)
    knee_low_lin = _norm_db_to_linear(ceiling_db - knee_db)
    knee_range = ceiling_lin - knee_low_lin
    attack_coef = 1.0 - _math.exp(-1.0 / max(attack_frames, 1))
    release_coef = 1.0 - _math.exp(-1.0 / max(release_frames, 1))
    state = {"g_prev": 1.0}

    def _transform(blk: Block) -> Block:
        audio_f64 = blk.data.astype(np.float64)
        n_samples = audio_f64.shape[0]
        if n_samples == 0:
            return blk
        inst_peak = (np.max(np.abs(audio_f64), axis=1) if audio_f64.ndim > 1
                    else np.abs(audio_f64))

        gain = np.ones(n_samples, dtype=np.float64)
        knee_mask = (inst_peak > knee_low_lin) & (inst_peak <= ceiling_lin)
        if np.any(knee_mask):
            x_knee = (inst_peak[knee_mask] - knee_low_lin) / knee_range
            gain[knee_mask] = 1.0 - 0.5 * (x_knee ** 2)
        over_mask = inst_peak > ceiling_lin
        if np.any(over_mask):
            gain[over_mask] = ceiling_lin / np.maximum(inst_peak[over_mask], 1e-12)

        smoothed_gain = np.ones(n_samples, dtype=np.float64)
        g_prev = state["g_prev"]
        for i in range(n_samples):
            g_target = gain[i]
            if g_target < g_prev:
                g_new = g_prev + attack_coef * (g_target - g_prev)
            else:
                g_new = g_prev + release_coef * (g_target - g_prev)
            g_new = min(1.0, max(g_new, 1e-6))
            smoothed_gain[i] = g_new
            g_prev = g_new
        state["g_prev"] = g_prev

        if audio_f64.ndim > 1:
            out = np.clip(audio_f64 * smoothed_gain.reshape(-1, 1), -1.0, 1.0).astype(np.float32)
        else:
            out = np.clip(audio_f64 * smoothed_gain, -1.0, 1.0).astype(np.float32)
        return Block(data=out, frame_offset=blk.frame_offset, is_last=blk.is_last)

    return _transform


# ═════════════════════════════════════════════════════════════════════
#  PASE 2 genérico — ganancia escalar (GAP-028) y M/S (GAP-029)
# ═════════════════════════════════════════════════════════════════════

def _gain_block_transform(gain: float):
    gain32 = np.float32(gain)

    def _transform(blk: Block) -> Block:
        out = np.clip(blk.data * gain32, -1.0, 1.0).astype(np.float32, copy=False)
        return Block(data=out, frame_offset=blk.frame_offset, is_last=blk.is_last)

    return _transform


def export_with_scalar_gain(segment_paths, encoder_cls, final_path: str,
                            gain: float, encoder_kwargs: dict | None = None,
                            block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    """PASE 2 para cualquier modo de Categoría A que se reduzca a un
    único escalar (PEAK_SIMPLE, RMS_*, LUFS_*, INTELLIGENT_PEAK,
    TRUE_PEAK*, PRESERVATIVE, NOISE_AWARE, CREST_GUARD)."""
    session = ExportSession(
        segment_paths, encoder_cls=encoder_cls, final_path=final_path,
        encoder_kwargs=encoder_kwargs, block_frames=block_frames,
        block_transform=_gain_block_transform(gain),
    )
    return session.run()


def export_with_mid_side_gain(segment_paths, encoder_cls, final_path: str,
                              mid_gain: float, side_gain: float,
                              encoder_kwargs: dict | None = None,
                              block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    session = ExportSession(
        segment_paths, encoder_cls=encoder_cls, final_path=final_path,
        encoder_kwargs=encoder_kwargs, block_frames=block_frames,
        block_transform=_mid_side_gain_transform(mid_gain, side_gain),
    )
    return session.run()


def export_with_block_transform(segment_paths, encoder_cls, final_path: str,
                                block_transform, encoder_kwargs: dict | None = None,
                                block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    """PASE 2 genérico — para composición (p. ej. ganancia + soft
    limiter encadenados) pasar un `block_transform` que aplique ambos
    en secuencia."""
    session = ExportSession(
        segment_paths, encoder_cls=encoder_cls, final_path=final_path,
        encoder_kwargs=encoder_kwargs, block_frames=block_frames,
        block_transform=block_transform,
    )
    return session.run()


def compose_transforms(*transforms):
    """Encadena varios `block_transform` en orden — p. ej. ganancia
    de normalización seguida del soft limiter, igual que hacen
    `_norm_with_tape_preset`/`_two_pass_analysis` en el legado."""
    def _composed(blk: Block) -> Block:
        for t in transforms:
            blk = t(blk)
        return blk
    return _composed


# ═════════════════════════════════════════════════════════════════════
#  Categoría C — meta-modos (AUTO, presets de cinta, TWO_PASS)
#  Se resuelven en Categoría A/B tras un análisis de histograma —
#  ver GAP-029.
# ═════════════════════════════════════════════════════════════════════

def measure_amplitude_histogram_streaming(segment_paths, rate: int,
                                          chunk_frames: int = _CRAC_ANALYSIS_BLOCK) -> dict:
    """Réplica streaming EXACTA de `_analyze_amplitude_histogram`
    (usada por AUTO). Mismo tamaño de chunk (`_CRAC_ANALYSIS_BLOCK`),
    mismos acumuladores (peak, sum_sq, clip_samples, block_rms_list,
    silent_blocks) — memoria O(n_blocks), nunca O(duración)."""
    provider = SegmentProvider(segment_paths)
    peak_global = 0.0
    sum_sq_global = 0.0
    n_samples_total = 0
    clip_samples = 0
    block_rms_list = []
    silent_blocks = 0
    n_blocks = 0

    for blk in provider.iter_blocks(block_frames=chunk_frames):
        chunk = blk.data
        if chunk.size == 0:
            continue
        flat = chunk.ravel()
        absmax = float(np.max(np.abs(flat)))
        if absmax > peak_global:
            peak_global = absmax
        sum_sq_global += float(np.sum(flat.astype(np.float64) ** 2))
        n_samples_total += len(flat)
        clip_samples += int(np.sum(np.abs(flat) > 0.99))
        rms_chunk = float(np.sqrt(np.mean(flat.astype(np.float64) ** 2)))
        block_rms_list.append(rms_chunk)
        rms_chunk_db = _norm_linear_to_db(rms_chunk) if rms_chunk > 1e-9 else float("-inf")
        if rms_chunk_db < _CRAC_SILENCE_THR or rms_chunk <= 1e-9:
            silent_blocks += 1
        n_blocks += 1

    if n_blocks == 0 or n_samples_total == 0:
        return {
            "dynamic_range_estimate": 0.0, "histogram_peak_density": 0.0,
            "silence_ratio": 1.0, "noise_floor_estimate_db": float("-inf"),
            "rms_db": float("-inf"), "peak_db": float("-inf"),
        }

    rms_global_db = (_norm_linear_to_db(float(_math.sqrt(sum_sq_global / n_samples_total)))
                     if (sum_sq_global / n_samples_total) > 1e-18 else float("-inf"))
    peak_global_db = _norm_linear_to_db(peak_global) if peak_global > 1e-9 else float("-inf")

    block_rms_arr = sorted(r for r in block_rms_list if r > 1e-9)
    silence_ratio = silent_blocks / n_blocks

    if block_rms_arr:
        p05_idx = max(0, int(len(block_rms_arr) * 0.05) - 1)
        p95_idx = min(len(block_rms_arr) - 1, int(len(block_rms_arr) * 0.95))
        p10_idx = max(0, int(len(block_rms_arr) * 0.10) - 1)
        p05_db = _norm_linear_to_db(block_rms_arr[p05_idx])
        p95_db = _norm_linear_to_db(block_rms_arr[p95_idx])
        noise_floor_db = _norm_linear_to_db(block_rms_arr[p10_idx])
        dynamic_range = p95_db - p05_db
    else:
        noise_floor_db = float("-inf")
        dynamic_range = 0.0

    return {
        "dynamic_range_estimate": round(dynamic_range, 2),
        "histogram_peak_density": round(clip_samples / n_samples_total, 6),
        "silence_ratio": round(silence_ratio, 4),
        "noise_floor_estimate_db": round(noise_floor_db, 2) if noise_floor_db != float("-inf") else float("-inf"),
        "rms_db": round(rms_global_db, 3) if rms_global_db != float("-inf") else float("-inf"),
        "peak_db": round(peak_global_db, 3) if peak_global_db != float("-inf") else float("-inf"),
    }


def resolve_auto_mode(segment_paths, rate: int, total_frames: int) -> str:
    """Réplica streaming exacta del árbol de decisión de
    `_norm_auto_intelligent` — devuelve el nombre del modo base
    (`NormalizationMode.value` de `mode.name`, p. ej. "PRESERVATIVE")
    al que hay que aplicar `export_with_scalar_gain`/
    `export_adaptive_block` a continuación."""
    hist = measure_amplitude_histogram_streaming(segment_paths, rate)
    peak, rms = measure_peak_rms_streaming(segment_paths)
    peak_db = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
    rms_db = _norm_linear_to_db(rms) if rms > 1e-9 else float("-inf")
    cf = (float("inf") if peak < 1e-9 or rms < 1e-9 else peak_db - rms_db)

    clip_density = hist["histogram_peak_density"]
    silence_ratio = hist["silence_ratio"]
    dynamic_range = hist["dynamic_range_estimate"]
    noise_floor_db = hist["noise_floor_estimate_db"]
    snr_db = ((rms_db - noise_floor_db)
             if (rms_db != float("-inf") and noise_floor_db != float("-inf"))
             else float("inf"))
    dur_s = total_frames / max(rate, 1)

    if clip_density > 0.005:
        return "PRESERVATIVE"
    elif dur_s < 5.0:
        return "PEAK_SIMPLE"
    elif silence_ratio > 0.60:
        return "ADAPTIVE_BLOCK"
    elif snr_db != float("inf") and snr_db < 12.0:
        return "NOISE_AWARE"
    elif dynamic_range < 3.0:
        return "ADAPTIVE_BLOCK"
    elif dur_s > 3600.0:
        return "NOISE_AWARE"
    elif rms_db != float("-inf") and rms_db > -12.0:
        return "PRESERVATIVE"
    else:
        return "LUFS_16"


_BASE_MODE_TARGET_RMS = {"NOISE_AWARE": -18.0, "RMS_18": -18.0, "RMS_20": -20.0, "RMS_14": -14.0}
_BASE_MODE_LUFS_TARGET = {"LUFS_23": -23.0, "LUFS_16": -16.0, "LUFS_14": -14.0}


def export_resolved_mode(segment_paths, encoder_cls, final_path: str,
                         resolved_mode: str, rate: int,
                         encoder_kwargs: dict | None = None,
                         apply_soft_limiter: bool = True,
                         soft_limiter_ceiling_db: float = -0.2,
                         block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    """PASE 2 genérico — dado el nombre de un modo BASE ya resuelto
    (por `resolve_auto_mode` o una decisión de preset/two-pass), mide
    lo que ese modo necesita y exporta. Usado por AUTO/presets de
    cinta/TWO_PASS para no duplicar el dispatch por modo."""
    if resolved_mode == "ADAPTIVE_BLOCK":
        return export_adaptive_block(segment_paths, encoder_cls, final_path, rate,
                                     encoder_kwargs=encoder_kwargs, block_frames=block_frames)

    if resolved_mode == "PEAK_SIMPLE":
        peak = measure_peak_streaming(segment_paths)
        gain = compute_peak_simple_gain(peak)
    elif resolved_mode == "PRESERVATIVE":
        peak, _ = measure_peak_rms_streaming(segment_paths)
        gain = compute_preservative_gain(peak)
    elif resolved_mode in _BASE_MODE_LUFS_TARGET:
        lufs, peak = measure_lufs_streaming(segment_paths, rate)
        gain = compute_lufs_gain(lufs, peak, _BASE_MODE_LUFS_TARGET[resolved_mode])
    elif resolved_mode == "NOISE_AWARE":
        peak, rms = measure_peak_rms_streaming(segment_paths)
        block_f = max(1, int(0.100 * rate))
        block_rmss = sorted(measure_block_rms_streaming(segment_paths, block_f, subsample=4))
        gain = compute_noise_aware_gain(rms, peak, block_rmss)
    elif resolved_mode in _BASE_MODE_TARGET_RMS:
        peak, rms = measure_peak_rms_streaming(segment_paths)
        gain = compute_rms_gain(rms, peak, _BASE_MODE_TARGET_RMS[resolved_mode])
    else:
        peak = measure_peak_streaming(segment_paths)
        gain = compute_peak_simple_gain(peak)

    if apply_soft_limiter and measure_soft_limiter_needed(segment_paths, soft_limiter_ceiling_db):
        transform = compose_transforms(
            _gain_block_transform(gain),
            make_soft_limiter_transform(ceiling_db=soft_limiter_ceiling_db),
        )
        return export_with_block_transform(segment_paths, encoder_cls, final_path,
                                           transform, encoder_kwargs, block_frames)
    return export_with_scalar_gain(segment_paths, encoder_cls, final_path, gain,
                                   encoder_kwargs, block_frames)


# ── Presets de cinta (v21) ─────────────────────────────────────────

def resolve_tape_preset_mode(segment_paths, rate: int, preset) -> str:
    """Réplica streaming exacta del árbol de decisión de
    `_norm_with_tape_preset` (v21) — devuelve una de: "rms", "lufs",
    "noise_aware", "preservative", "crest_guard", "peak_simple".
    `preset` es un `TapePreset` (`lorito_tape_presets.TAPE_PRESETS`)."""
    peak, rms = measure_peak_rms_streaming(segment_paths)
    if peak < 1e-9:
        return "silent"

    peak_db = _norm_linear_to_db(peak)
    rms_db = _norm_linear_to_db(rms) if rms > 1e-9 else float("-inf")
    cf_db = peak_db - rms_db if rms > 1e-9 else float("inf")

    block_f = max(1, int(0.100 * rate))
    block_rmss = sorted(measure_block_rms_streaming(segment_paths, block_f, subsample=4))
    if block_rmss:
        p5_idx = max(0, int(len(block_rmss) * 0.05))
        p5_idx = min(p5_idx, len(block_rmss) - 1)
        noise_floor_db = _norm_linear_to_db(block_rmss[p5_idx])
    else:
        noise_floor_db = rms_db

    provider = SegmentProvider(segment_paths)
    dur_s = provider.total_frames / max(rate, 1)
    clip_density = _measure_clip_density_streaming(segment_paths, thr=0.9990)

    if clip_density > 0.001:
        return "preservative"
    elif dur_s < 3.0:
        return "peak_simple"
    elif noise_floor_db > preset.hiss_tolerance_db:
        return "noise_aware"
    elif cf_db < preset.min_crest_factor_db and cf_db != float("inf"):
        return "crest_guard"
    elif preset.prefer_rms:
        return "rms"
    else:
        return "lufs"


def _measure_clip_density_streaming(segment_paths, thr: float = 0.9990,
                                    block_frames: int = DEFAULT_BLOCK_FRAMES) -> float:
    provider = SegmentProvider(segment_paths)
    n_over = 0
    n_total = 0
    for blk in provider.iter_blocks(block_frames):
        if blk.data.size == 0:
            continue
        n_over += int(np.sum(np.abs(blk.data) >= thr))
        n_total += blk.data.size
    return n_over / max(n_total, 1)


def plan_tape_preset_gain(segment_paths, rate: int, preset):
    """Árbol de decisión de `export_tape_preset` SIN exportar (Orden
    Golden de Exportación: el plan se separa de la escritura para que
    `ExportService` componga normalización + velocidad + códec en una
    única `ExportSession`). Devuelve `(gain, decision, ceiling_db)`;
    `decision == "silent"` implica ganancia 1.0 y sin limitador."""
    decision = resolve_tape_preset_mode(segment_paths, rate, preset)
    if decision == "silent":
        return 1.0, decision, None

    peak, rms = measure_peak_rms_streaming(segment_paths)

    if decision == "rms":
        gain = compute_rms_gain(rms, peak, preset.target_rms_db,
                                preset.ceiling_db, preset.max_gain_db)
    elif decision == "lufs":
        lufs, _ = measure_lufs_streaming(segment_paths, rate)
        gain = compute_lufs_gain(lufs, peak, preset.target_lufs,
                                 preset.ceiling_db, preset.max_gain_db)
    elif decision == "noise_aware":
        block_f = max(1, int(0.100 * rate))
        block_rmss = sorted(measure_block_rms_streaming(segment_paths, block_f, subsample=4))
        gain = compute_noise_aware_gain(rms, peak, block_rmss, preset.target_rms_db,
                                        preset.max_gain_db, preset.ceiling_db)
    elif decision == "preservative":
        gain = compute_preservative_gain(peak, preset.ceiling_db, preset.max_gain_db)
    elif decision == "crest_guard":
        # NOTA: `_apply_with_crest_guard`, cuando ceiling_db/max_gain_db
        # difieren de los defaults globales (como aquí, por venir del
        # preset), llama a `_norm_rms` DIRECTAMENTE sin pasar
        # `target_rms_db` — usa el default de esa función (-20.0), NO
        # el -18.0 de RMS_18 que el `norm_mode` sugeriría a simple
        # vista. Replicado tal cual (ver `_apply_with_crest_guard`,
        # rama `_use_direct`).
        gain = compute_crest_guard_gain(rms, peak, preset.min_crest_factor_db,
                                        target_rms_db=-20.0,
                                        ceiling_db=preset.ceiling_db,
                                        max_gain_db=preset.max_gain_db)
    else:  # peak_simple
        gain = compute_preservative_gain(peak, preset.ceiling_db, preset.max_gain_db)
    return gain, decision, preset.ceiling_db


def export_tape_preset(segment_paths, encoder_cls, final_path: str,
                       rate: int, preset, encoder_kwargs: dict | None = None,
                       block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    """PASE 2 completo para un `TapePreset` — resuelve la decisión y
    aplica el modo correspondiente CON los parámetros del preset
    (`target_rms_db`/`target_lufs`/`ceiling_db`/`max_gain_db`), más el
    soft limiter final (mismo orden que `_norm_with_tape_preset`)."""
    gain, decision, ceiling_db = plan_tape_preset_gain(segment_paths, rate, preset)
    if decision == "silent":
        return export_with_scalar_gain(segment_paths, encoder_cls, final_path, 1.0,
                                       encoder_kwargs, block_frames)
    transform = compose_transforms(
        _gain_block_transform(gain),
        make_soft_limiter_transform(ceiling_db=ceiling_db),
    )
    return export_with_block_transform(segment_paths, encoder_cls, final_path,
                                       transform, encoder_kwargs, block_frames)


# ── TWO_PASS (v21) — última pieza del catálogo de 20 modos ───────────

def resolve_two_pass_mode(segment_paths, rate: int) -> str:
    """Réplica streaming del árbol de decisión de `_two_pass_analysis`
    (v21) — devuelve uno de: "PRESERVATIVE", "PEAK_SIMPLE",
    "ADAPTIVE_BLOCK", "NOISE_AWARE", "LUFS_16" (mismo espacio de
    salida que `resolve_auto_mode`, árbol de decisión DISTINTO —
    usa percentiles p05/p95 de bloques de 100ms SIN subsample, a
    diferencia de `resolve_auto_mode` que usa el histograma chunked de
    `_CRAC_ANALYSIS_BLOCK`).

    Nota de alcance (ver GAP-029/030): replica solo la rama de
    decisión (`suggested`), no los campos de telemetría completos
    (percentiles p25/p50/p75, detección de drift) que
    `_two_pass_analysis` también calcula mas no usa para elegir el
    modo."""
    provider = SegmentProvider(segment_paths)
    total_frames = provider.total_frames
    dur_s = total_frames / max(rate, 1)

    peak_global, rms_global = measure_peak_rms_streaming(segment_paths)
    peak_db = _norm_linear_to_db(peak_global) if peak_global > 1e-9 else float("-inf")
    rms_db = _norm_linear_to_db(rms_global) if rms_global > 1e-9 else float("-inf")

    block_f = max(1, int(0.100 * rate))
    block_rmss_raw = measure_block_rms_streaming(segment_paths, block_f, subsample=1)
    n_silence = sum(1 for r in block_rmss_raw if r < 0.001)
    n_blocks = len(block_rmss_raw)
    silence_ratio = n_silence / max(n_blocks, 1)

    sorted_rmss = sorted(r for r in block_rmss_raw if r > 1e-12)
    n_b = len(sorted_rmss)
    if n_b > 0:
        def _pct_db(p):
            idx = max(0, min(n_b - 1, int(n_b * p)))
            return _norm_linear_to_db(sorted_rmss[idx])
        p05_db = _pct_db(0.05)
        p95_db = _pct_db(0.95)
        noise_floor_db = p05_db
    else:
        p05_db = p95_db = noise_floor_db = rms_db

    dynamic_range = (p95_db - p05_db) if (p95_db != float("-inf") and p05_db != float("-inf")) else 0.0
    snr_db = rms_db - noise_floor_db if noise_floor_db != float("-inf") else float("inf")

    # clip_density — equivalente al único bin superior (255/256) del
    # histograma de 256 bins que usa el legado (ver docstring).
    clip_density = _measure_clip_density_streaming(segment_paths, thr=255.0 / 256.0)

    if clip_density > 0.001:
        return "PRESERVATIVE"
    elif dur_s < 3.0:
        return "PEAK_SIMPLE"
    elif silence_ratio > 0.60:
        return "ADAPTIVE_BLOCK"
    elif snr_db != float("inf") and snr_db < 12.0:
        return "NOISE_AWARE"
    elif dynamic_range < 3.0:
        return "ADAPTIVE_BLOCK"
    elif p95_db != float("-inf") and p95_db > -8.0:
        return "PRESERVATIVE"
    elif dur_s > 3600.0:
        return "NOISE_AWARE"
    else:
        return "LUFS_16"


def export_two_pass(segment_paths, encoder_cls, final_path: str, rate: int,
                    encoder_kwargs: dict | None = None,
                    block_frames: int = DEFAULT_BLOCK_FRAMES) -> ExportSessionReport:
    """PASE 2 completo para TWO_PASS: resuelve el modo sugerido y lo
    ejecuta con el soft limiter final, reutilizando
    `export_resolved_mode` (mismo orquestador que AUTO)."""
    resolved = resolve_two_pass_mode(segment_paths, rate)
    return export_resolved_mode(segment_paths, encoder_cls, final_path, resolved, rate,
                                encoder_kwargs=encoder_kwargs,
                                apply_soft_limiter=True,
                                soft_limiter_ceiling_db=-0.2,
                                block_frames=block_frames)
