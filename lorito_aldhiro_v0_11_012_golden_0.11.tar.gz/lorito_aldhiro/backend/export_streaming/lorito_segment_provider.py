from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Lectura secuencial de segmentos de captura en bloques acotados, sin cargar la sesión completa.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_segment_provider.py — Segment Provider + Block Iterator (§16, §21,
FASE 6 de la Orden Maestra de Refundación).

Sustituye la lectura que hacía `_build_export_array()`
(`lorito_main_window.py`, congelado — ver GAP-002 §2/§3) de:

    segmento 1 → RAM
    segmento 2 → RAM
    ...
    np.concatenate(todos)

por:

    segmento 1 → bloques → liberar
    segmento 2 → bloques → liberar
    ...

Nunca hay más de un bloque (`block_frames`, por defecto 32768 frames,
igual que `PATCH 10H+` en los encoders actuales) residente en memoria por
segmento. Los segmentos de la sesión son siempre WAV PCM enteros — los
mismos que escribe `DiskWriterV2` (`lorito_capture_engine.py`, subtype
"PCM_24" para captura en curso; PCM_16/24/32 soportados en general para
reutilizar este lector sobre cualquier WAV entero existente).

Sin dependencia de `soundfile`: usa el módulo `wave` de la librería
estándar (siempre disponible), suficiente para WAV PCM entero — que es
exactamente lo que escriben los segmentos de captura. No cubre WAV en
punto flotante (no es el formato de segmento de este proyecto); si algún
día lo fuera, este módulo debe ampliarse explícitamente, nunca asumir.
"""

import os
import wave
from typing import Iterable, Iterator, List

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import (
    AudioFormat, Block, FormatMismatchError,
)
# GAP-051 (FASE 1 de la Orden de Saneamiento, Integración y
# Consolidación): `SegmentReadError` se definía aquí mismo como
# `RuntimeError` suelto. Ahora vive en `backend/errors/` (§11),
# reimportada con el MISMO nombre para que `tests/
# test_segment_read_errors.py` y `tests/test_main_window_export_
# exploration.py` sigan importándola de este módulo sin cambios.
from lorito_aldhiro.backend.errors import SegmentReadError

DEFAULT_BLOCK_FRAMES = 32768   # ≈0.68s @ 48kHz — mismo tamaño que WRITE_BLOCK
                                # en los encoders legados (lorito_exporters.py)

# Docstring original de `SegmentReadError`, preservado aquí como
# referencia histórica de la Fase 2 (GAP-034) que la creó — la clase
# en sí ahora vive en `backend/errors/lorito_errors_export.py`:
#
#   Se lanza cuando un segmento no puede leerse de forma fiable:
#   header corrupto/no-WAV (`_read_segment_format`/`_segment_nframes`,
#   detectado ANTES de emitir un solo bloque, igual que
#   `FormatMismatchError`), o un segmento TRUNCADO — el header declara
#   más frames de los que el archivo físicamente contiene (escenario
#   real: proceso de captura interrumpido/matado antes de que
#   `DiskWriterV2` corrigiera el tamaño final del header).
#
#   Antes de la Fase 2, un segmento truncado no producía ESTE error —
#   `SegmentProvider.iter_blocks()` entregaba silenciosamente menos
#   frames de los que el header prometía, marcando incorrectamente el
#   bloque corto como `is_last=True`. El defecto SÍ terminaba
#   detectándose, pero varias capas más abajo (`AtomicFinalizer`
#   comparando `frames_in` contra `total_frames_expected`), con un
#   mensaje genérico de "frame accounting" que no nombra qué segmento
#   es el corrupto. Ahora se detecta y se nombra el segmento exacto en
#   el momento en que ocurre — y, desde GAP-051, también de forma
#   estructurada (`segment_id`/`path`/`cause`), no solo en el texto.


def _read_segment_format(path: str) -> AudioFormat:
    try:
        with wave.open(path, "rb") as wf:
            return AudioFormat(
                rate=wf.getframerate(),
                channels=wf.getnchannels(),
                sample_width_bytes=wf.getsampwidth(),
                is_float=False,   # los segmentos de captura son siempre PCM entero
            )
    except (wave.Error, EOFError, OSError) as e:
        raise SegmentReadError(
            f"EXPORT_ABORT_SEGMENT_READ_ERROR: no se pudo leer el header "
            f"WAV de '{path}' ({e.__class__.__name__}: {e}) — segmento "
            f"corrupto o no es un WAV válido.",
            segment_id=path, path=path, cause=e) from e


def _segment_nframes(path: str) -> int:
    try:
        with wave.open(path, "rb") as wf:
            return wf.getnframes()
    except (wave.Error, EOFError, OSError) as e:
        raise SegmentReadError(
            f"EXPORT_ABORT_SEGMENT_READ_ERROR: no se pudo leer el header "
            f"WAV de '{path}' ({e.__class__.__name__}: {e}) — segmento "
            f"corrupto o no es un WAV válido.",
            segment_id=path, path=path, cause=e) from e


def _pcm_bytes_to_float32(raw: bytes, sample_width: int, n_channels: int) -> np.ndarray:
    """
    Convierte bytes PCM entero little-endian (8/16/24/32 bit) a float32
    normalizado en [-1.0, 1.0], shape (n_frames, n_channels).

    24-bit es el caso real de este proyecto (subtype PCM_24 en
    DiskWriterV2) y no tiene tipo numpy nativo — se reconstruye a int32
    insertando un byte de signo antes de la conversión, técnica estándar
    para PCM24 empaquetado.
    """
    if sample_width == 1:
        # PCM8 es unsigned en WAV
        u8 = np.frombuffer(raw, dtype=np.uint8)
        pcm = (u8.astype(np.int16) - 128) << 8
        pcm = pcm.astype(np.int32)
        scale = 32768.0
    elif sample_width == 2:
        pcm = np.frombuffer(raw, dtype="<i2").astype(np.int32)
        scale = 32768.0
    elif sample_width == 3:
        n_samples = len(raw) // 3
        u8 = np.frombuffer(raw, dtype=np.uint8).reshape(n_samples, 3)
        # Empaquetar a int32 con signo: [b0,b1,b2,0] LE y luego shift/sign-extend
        buf32 = np.zeros((n_samples, 4), dtype=np.uint8)
        buf32[:, 0:3] = u8
        # Sign-extend: si el bit más alto de b2 está activo, byte 3 = 0xFF
        buf32[:, 3] = np.where(u8[:, 2] & 0x80, 0xFF, 0x00)
        pcm = np.frombuffer(buf32.tobytes(), dtype="<i4").astype(np.int32)
        scale = 8388608.0  # 2**23
    elif sample_width == 4:
        pcm = np.frombuffer(raw, dtype="<i4").astype(np.int32)
        scale = 2147483648.0
    else:
        raise ValueError(f"sample_width no soportado: {sample_width}")

    f32 = (pcm.astype(np.float32) / scale)
    return f32.reshape(-1, n_channels)


class SegmentProvider:
    """
    Valida formato de todos los segmentos ANTES de emitir un solo bloque
    (§21) y expone `total_frames`/`fmt` calculados solo de headers.

    Una discrepancia de rate/canales/ancho de muestra produce
    `FormatMismatchError` (EXPORT_ABORT_FORMAT_MISMATCH) — nunca una
    concatenación silenciosa.
    """

    def __init__(self, segment_paths: Iterable[str]):
        self.segment_paths: List[str] = list(segment_paths)
        if not self.segment_paths:
            raise FormatMismatchError("EXPORT_ABORT_FORMAT_MISMATCH: sin segmentos")

        for p in self.segment_paths:
            if not os.path.exists(p):
                raise FormatMismatchError(
                    f"EXPORT_ABORT_FORMAT_MISMATCH: segmento faltante: {p}",
                    segment_id=p, path=p)

        fmts = [_read_segment_format(p) for p in self.segment_paths]
        base = fmts[0]
        for p, f in zip(self.segment_paths, fmts):
            if not f.matches(base):
                raise FormatMismatchError(
                    "EXPORT_ABORT_FORMAT_MISMATCH: "
                    f"'{p}' ({f}) no coincide con el formato base ({base})",
                    segment_id=p, path=p)

        self.fmt: AudioFormat = base
        self.total_frames: int = sum(_segment_nframes(p) for p in self.segment_paths)

    # ── Compatibilidad con los encoders actuales (§17-§26) ──────────────
    @property
    def rate(self) -> int:
        return self.fmt.rate

    @property
    def channels(self) -> int:
        return self.fmt.channels

    def iter_blocks(self, block_frames: int = DEFAULT_BLOCK_FRAMES) -> Iterator[Block]:
        """
        Itera los segmentos SECUENCIALMENTE (§21: nunca
        "load segment 1, load segment 2, ... concatenate all").
        Cada segmento se abre, se lee en bloques acotados, y se libera
        (cierra el file handle) antes de abrir el siguiente.

        Fase 2 (GAP-034): si un segmento está TRUNCADO (el header
        declara más frames de los que el archivo físicamente contiene
        — `wave.readframes()` no lanza excepción en ese caso, solo
        devuelve menos bytes de los pedidos, silenciosamente), se
        detecta aquí mismo y se lanza `SegmentReadError` nombrando el
        segmento exacto y el faltante — en vez de dejar que el bloque
        corto se entregue como si fuera el final normal de la sesión.
        """
        absolute_frame = 0
        total = self.total_frames
        for seg_idx, path in enumerate(self.segment_paths):
            try:
                with wave.open(path, "rb") as wf:
                    remaining = wf.getnframes()
                    while remaining > 0:
                        take = min(block_frames, remaining)
                        raw = wf.readframes(take)
                        frames_read = len(raw) // (self.fmt.sample_width_bytes
                                                    * self.fmt.channels)
                        if frames_read < take:
                            raise SegmentReadError(
                                "EXPORT_ABORT_SEGMENT_READ_ERROR: segmento "
                                f"truncado: '{path}' — el header declara "
                                f"{wf.getnframes()} frames pero solo se "
                                f"pudieron leer {frames_read} de los {take} "
                                f"pedidos en esta posición (faltan "
                                f"{take - frames_read} frames de este "
                                "bloque). El proceso de captura pudo haberse "
                                "interrumpido antes de cerrar el segmento "
                                "correctamente.",
                                segment_id=path, path=path,
                                frame_start=absolute_frame,
                                frame_count=wf.getnframes())
                        data = _pcm_bytes_to_float32(
                            raw, self.fmt.sample_width_bytes, self.fmt.channels)
                        absolute_frame += data.shape[0]
                        remaining -= take
                        is_last = (seg_idx == len(self.segment_paths) - 1
                                   and remaining == 0)
                        yield Block(data=data, frame_offset=absolute_frame - data.shape[0],
                                    is_last=is_last)
            except (wave.Error, EOFError, OSError) as e:
                raise SegmentReadError(
                    f"EXPORT_ABORT_SEGMENT_READ_ERROR: fallo leyendo "
                    f"'{path}' ({e.__class__.__name__}: {e}).",
                    segment_id=path, path=path,
                    frame_start=absolute_frame, cause=e) from e
            # `with wave.open` cierra el segmento aquí — release real antes
            # de continuar con el siguiente (§21).
