from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Control automático de nivel (ALC) del catálogo NR.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_alc.py — ALC (Auto Level Control), §GAP-011.

A diferencia de CRAC (donde ALC existe solo como referencia de nombre/
color en el registro de leyendas, sin motor DSP real), el usuario pidió
explícitamente que la implementación de Lorito Aldhiro SÍ produzca un
efecto analógico real: el "respiro" (breathing/pumping) característico
de los ALC de radiograbadoras baratas de los 80 — un control automático
de nivel de una sola banda, con ganancia que sube perceptiblemente
sobre el ruido de fondo entre pasajes de música, en vez del
comportamiento inaudible y transparente de un limitador profesional
moderno.

Diseño (nuevo, sin precedente directo en CRAC):
  · Envolvente de nivel RMS de ventana corta (favorece reaccionar a
    picos de programa, como el ALC real).
  · Ataque RÁPIDO (~5ms) — baja la ganancia casi de inmediato ante un
    pico, evitando saturación de cinta (la función real del ALC).
  · Release LENTO Y NO LINEAL (~800ms, con una cola aún más lenta al
    final) — es precisamente esta recuperación lenta y perceptible la
    que produce el "respiro": el ruido de fondo/silencio entre frases
    sube de volumen audiblemente mientras la ganancia se recupera.
  · Sin "look-ahead" ni compensación de banda (a diferencia de un
    limitador moderno) — el propio retraso del detector RMS introduce
    un ligero "adelanto" de la reducción de ganancia justo antes del
    pico, imitando la imprecisión real de un ALC analógico simple.
  · Ruido de piso sintético opcional (`floor_noise_level`) mezclado
    DESPUÉS de la ganancia — para que el "respiro" se perciba como
    ruido de fondo que sube/baja, no como silencio perfecto que solo
    cambia de volumen (que sonaría artificial).
"""

import math

import numpy as np


class AlcProfile:
    display_name = "ALC"
    cell_token = "ALC"
    overlay_token = "ALC"

    THRESHOLD_DB = -18.0
    MAX_GAIN_DB = 12.0          # ganancia máxima cuando no hay señal (silencio)
    ATTACK_MS = 5.0
    RELEASE_MS = 800.0
    RELEASE_TAIL_MS = 2400.0    # cola de release aún más lenta (el "respiro" final)
    RMS_WINDOW_MS = 12.0
    FLOOR_NOISE_LEVEL = 0.0006  # ruido de piso sintético mezclado tras la ganancia

    def __init__(self, mode: str = "ACTIVE", sample_rate: int = 48000, channels: int = 2):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def _build(self) -> None:
        self._active = self.mode != "BYPASS"
        if not self._active:
            return
        self.threshold_lin = 10.0 ** (self.THRESHOLD_DB / 20.0)
        self.max_gain = 10.0 ** (self.MAX_GAIN_DB / 20.0)
        self.rms_win = max(1, int(self.fs * self.RMS_WINDOW_MS / 1000.0))
        # La envolvente avanza UNA VEZ POR BLOQUE de `rms_win` muestras
        # (ver process_chunk), no por muestra — los coeficientes deben
        # calibrarse contra el número de BLOQUES en cada ventana de
        # tiempo, no contra `fs` directamente, o el ataque/release
        # reales terminan siendo ~rms_win veces más lentos que lo pedido.
        blocks_per_sec = self.fs / self.rms_win
        self.att = math.exp(-1.0 / max(1, blocks_per_sec * self.ATTACK_MS / 1000.0))
        self.rel = math.exp(-1.0 / max(1, blocks_per_sec * self.RELEASE_MS / 1000.0))
        self.rel_tail = math.exp(-1.0 / max(1, blocks_per_sec * self.RELEASE_TAIL_MS / 1000.0))
        self.env_sq = np.full(self.channels, self.threshold_lin ** 2, dtype=np.float64)
        self.gain_smooth = np.ones(self.channels, dtype=np.float64)
        self._rng = np.random.default_rng(1986)  # semilla fija: reproducible en tests

    def reset(self) -> None:
        if not self._active:
            return
        self.env_sq[:] = self.threshold_lin ** 2
        self.gain_smooth[:] = 1.0

    def reconfigure(self, mode: str, sample_rate: int, channels: int) -> None:
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return chunk if chunk.dtype == np.float32 else chunk.astype(np.float32)

        x = np.ascontiguousarray(chunk, dtype=np.float32)
        mono = x.ndim == 1
        x2 = x[:, np.newaxis] if mono else x
        n_samples, n_ch = x2.shape
        if self.env_sq.shape[0] != n_ch:
            self.env_sq = np.full(n_ch, self.threshold_lin ** 2, dtype=np.float64)
            self.gain_smooth = np.ones(n_ch, dtype=np.float64)

        out = np.empty_like(x2, dtype=np.float64)
        thr_sq = self.threshold_lin ** 2
        att, rel, rel_tail = self.att, self.rel, self.rel_tail
        win = self.rms_win

        xf = x2.astype(np.float64)
        for ch in range(n_ch):
            col = xf[:, ch]
            env_sq = self.env_sq[ch]
            g = self.gain_smooth[ch]
            out_ch = out[:, ch]
            i = 0
            while i < n_samples:
                block = col[i:i + win]
                block_sq = float(np.mean(block * block)) if block.size else 0.0
                if block_sq > env_sq:
                    env_sq = att * env_sq + (1.0 - att) * block_sq
                else:
                    near_floor = env_sq < thr_sq * 4.0
                    r = rel_tail if near_floor else rel
                    env_sq = r * env_sq + (1.0 - r) * block_sq
                self.env_sq[ch] = env_sq

                level = math.sqrt(max(env_sq, 1e-12))
                target_gain = self.threshold_lin / level if level > 1e-9 else self.max_gain
                target_gain = min(max(target_gain, 1.0 / self.max_gain), self.max_gain)
                g = 0.85 * g + 0.15 * target_gain

                block_len = block.size
                out_ch[i:i + block_len] = block * g
                i += win
            self.gain_smooth[ch] = g

        if self.FLOOR_NOISE_LEVEL > 0.0:
            noise = self._rng.normal(0.0, self.FLOOR_NOISE_LEVEL, size=out.shape)
            out = out + noise

        result = np.clip(out, -1.0, 1.0).astype(np.float32)
        return result[:, 0] if mono else result
