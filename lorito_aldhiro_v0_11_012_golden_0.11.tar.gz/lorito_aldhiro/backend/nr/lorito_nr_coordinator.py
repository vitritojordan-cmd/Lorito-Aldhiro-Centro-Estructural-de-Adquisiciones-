from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Orquestador de toda la cadena DSP en tiempo real — un solo punto de entrada por bloque.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_coordinator.py — coordinador de selección única de reducción
de ruido (§GAP-011), mismo patrón `_active` de exclusión estructural ya
usado en el proyecto hermano (VitriCarola/PARMOSOC: un único perfil
activo a la vez, nunca cascada).

HX Pro y ALC son independientes entre sí y del selector NR (pueden
convivir con un perfil NR activo y entre ellos — no son parte de la
familia de doble/único extremo, son técnicas de grabación/nivelación
distintas), tal como especificó el usuario (menú OPTAPE separado del
menú NR).

── Orden Golden DSP PREVI / NR (LA-GOLDEN-DSP-PREVI-NR-001) ──────────

  · Contrato único (`lorito_dsp_contract`): bloque validado (forma,
    dtype, canales) y configuración validada (rate/canales) ANTES de
    procesar; tokens/modos desconocidos → `DSPContractError` (NR-03).
  · Snapshot por bloque (DSP-04): toda mutación (select/set_*/
    set_stage_params/reconfigure) y cada `process_chunk()` se serializan
    con un lock NO-RT: los cambios entran en frontera de bloque. La cadena
    activa es una tupla inmutable publicada de una sola vez.
  · `reconfigure()` transaccional (NR-02): construye instancias NUEVAS de
    TODAS las etapas (incluidas Cristhi Cosh, Antipestal, Lucha
    Enloquecida, Versión O Tron y Muscle EQ Samir, preservando sus
    parámetros/bandas); si cualquiera falla, la cadena anterior queda
    intacta. Política de estado: se REINICIA en el cambio de rate/canales
    (registrado como evento).
  · Saneamiento = alarma (DSP-01): cada NaN/Inf genera un
    `IntegrityEvent` (etapa, bloque, frame, cantidad, política) y deja
    `integrity_state = "DEGRADED"` — nunca audio "aparentemente válido"
    sin rastro.
  · Saturación con telemetría (DSP-02): muestras en |x| ≥ 1.0 a la
    salida de cada etapa se cuentan (`saturated_samples`); el recorte
    por etapa queda DECLARADO, no silencioso.
  · Fallo de etapa: excepción o forma inválida → `DSPStageError` con el
    nombre de la etapa (el llamador decide abortar/degradar).
  · Telemetría por etapa (DSP-07): frames, tiempos p50/p95/p99/máx,
    picos, saturación, no-finitos, resets, fallos; `config_hash()` y
    `describe_chain()` para provenance de DERIVED.
"""

import copy
import threading
import time
from collections import deque
from typing import Optional

import numpy as np

from lorito_aldhiro.backend.nr.lorito_nr_profiles import NR_PROFILE_CLASSES, NRProfile
from lorito_aldhiro.backend.nr.lorito_nr_hxpro import HxProProfile
from lorito_aldhiro.backend.nr.lorito_nr_alc import AlcProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_mpx import MpxProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_eq_bias import TapeEqBiasProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_focus import FocusProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite
from lorito_aldhiro.backend.dsp.lorito_dsp_cristhi_cosh import CristhiCoshProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_antipestal_lola_grillo import AntipestalLolaProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import VersionOTronProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida import LuchaEnloquecidaProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida import _CLASS_BY_CODE as _LUCHA_CODES
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import MuscleEqSamirProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import get_preset_bands
from lorito_aldhiro.backend.dsp.lorito_dsp_contract import (
    STAGE_CATALOG, CANONICAL_ORDER, USE_CASES, USE_CAPTURE_LIVE, USE_PLAYBACK,
    FAM_CREATIVE, StageTelemetry, IntegrityEvent, validate_block, validate_config,
    config_hash, stage_params, FixedBlockAdapter,
)
from lorito_aldhiro.backend.errors.lorito_errors_dsp import DSPContractError, DSPStageError

_NR_MODES = ("DECODE", "ENCODE", "BYPASS")
_ANTIPESTAL_MODES = ("BYPASS", "STRIKER", "KARI")
_O_TRON_MODES = ("BYPASS", "AA_MO", "BARRIL", "SIFON")
_EQ_BIAS_TOKENS = None   # validado contra TapeEqBiasProfile al construir


class NRCoordinator:
    def __init__(self, sample_rate: int = 48000, channels: int = 2, mode: str = "DECODE"):
        mode = (mode or "DECODE").upper().strip()
        if mode not in _NR_MODES:
            raise DSPContractError(f"DSP_CONTRACT: modo NR desconocido {mode!r}")
        validate_config(sample_rate, channels)
        self.sample_rate = sample_rate
        self.channels = channels
        self.mode = mode
        self.use_case = USE_CAPTURE_LIVE
        self._lock = threading.RLock()
        self._active_token: Optional[str] = None
        self._active_kwargs: dict = {}
        self._active_profile: Optional[NRProfile] = None
        self._hx_pro: Optional[HxProProfile] = None
        self._alc: Optional[AlcProfile] = None
        self._mpx: Optional[MpxProfile] = None
        self._focus: Optional[FocusProfile] = None
        self._eq_bias: Optional[TapeEqBiasProfile] = None
        self._eq_bias_token: Optional[str] = None
        self._cristhi_cosh: Optional[CristhiCoshProfile] = None
        self._antipestal: Optional[AntipestalLolaProfile] = None
        self._version_o_tron: Optional[VersionOTronProfile] = None
        self._lucha_enloquecida: Optional[LuchaEnloquecidaProfile] = None
        self._muscle_eq: Optional[MuscleEqSamirProfile] = None
        self._nonfinite_counts: dict = {
            "input": 0, "eq_bias": 0, "mpx": 0, "nr": 0,
            "hx_pro": 0, "alc": 0, "focus": 0, "cristhi_cosh": 0,
            "antipestal": 0, "version_o_tron": 0, "lucha_enloquecida": 0,
            "muscle_eq": 0,
        }
        self._telemetry = {label: StageTelemetry() for label in CANONICAL_ORDER}
        self._events: deque = deque(maxlen=512)
        self._events_total = 0
        self._block_index = 0
        self._frame_position = 0
        self._config_version = 0
        self._adapters: dict = {}
        self._publish_chain()

    # ── Publicación de la cadena (snapshot inmutable) ────────────────────
    def _stage_by_label(self, label):
        return {
            "muscle_eq": self._muscle_eq, "cristhi_cosh": self._cristhi_cosh,
            "antipestal": self._antipestal, "lucha_enloquecida": self._lucha_enloquecida,
            "eq_bias": self._eq_bias, "mpx": self._mpx, "nr": self._active_profile,
            "hx_pro": self._hx_pro, "alc": self._alc, "focus": self._focus,
            "version_o_tron": self._version_o_tron,
        }[label]

    def _current_chain(self) -> tuple:
        return tuple((label, st) for label in CANONICAL_ORDER
                     if (st := self._stage_by_label(label)) is not None)

    def _exec_chain(self) -> tuple:
        """Cadena de EJECUCIÓN: las etapas no invariantes al tamaño de
        bloque se envuelven en un `FixedBlockAdapter` persistente (mismo
        objeto de etapa → mismo adaptador y mismo estado)."""
        out = []
        for label, st in self._current_chain():
            if STAGE_CATALOG[label].block_invariant or getattr(st, "_active", True) is False:
                # invariante, o etapa en paso directo (p. ej. FOCUS en mono):
                # sin re-bloqueo ni latencia.
                out.append((label, st))
                continue
            cached = self._adapters.get(label)
            if cached is None or cached.stage is not st or cached.channels != self.channels:
                cached = FixedBlockAdapter(
                    st, self.channels,
                    on_output=(lambda y, _l=label, _s=st: self._sanitize_stage(_l, y, _s)))
                self._adapters[label] = cached
            out.append((label, cached))
        return tuple(out)

    def chain_latency_frames(self) -> int:
        """Latencia algorítmica DECLARADA de la cadena (suma de los
        re-bloqueos fijos), para alinear DERIVED con RAW."""
        return sum(getattr(st, "latency_frames", 0) for _l, st in self._exec_chain())

    @property
    def _chain(self) -> tuple:
        """Snapshot de la cadena: se toma bajo el lock al inicio de cada
        bloque, así que ninguna mutación puede cambiarla a mitad."""
        return self._current_chain()

    def _publish_chain(self) -> None:
        self._config_version += 1

    def _record_event(self, stage, kind, count, policy, detail=""):
        self._events.append(IntegrityEvent(stage, kind, self._block_index,
                                           self._frame_position, count, policy, detail))
        self._events_total += 1

    # ── Selector NR (exclusión estructural — un único perfil activo) ──
    def select(self, token: Optional[str], **profile_kwargs) -> None:
        """token en NR_PROFILE_CLASSES o None para apagar. Un token
        desconocido es un error de contrato (NR-03), nunca un bypass
        silencioso."""
        if token is not None and token not in NR_PROFILE_CLASSES:
            raise DSPContractError(
                f"DSP_CONTRACT: token NR desconocido {token!r} "
                f"(válidos: {sorted(NR_PROFILE_CLASSES)})")
        with self._lock:
            if token == self._active_token and not profile_kwargs:
                return
            if token is None:
                self._active_token, self._active_profile, self._active_kwargs = None, None, {}
            else:
                prof = NR_PROFILE_CLASSES[token](mode=self.mode, sample_rate=self.sample_rate,
                                                 channels=self.channels, **profile_kwargs)
                self._active_token, self._active_profile = token, prof
                self._active_kwargs = dict(profile_kwargs)
            self._publish_chain()

    @property
    def active_token(self) -> Optional[str]:
        return self._active_token

    # ── HX Pro / ALC / MPX / FOCUS ────────────────────────────────────────
    def _set_simple(self, attr, cls, active):
        with self._lock:
            setattr(self, attr, cls(mode="ACTIVE", sample_rate=self.sample_rate,
                                    channels=self.channels) if active else None)
            self._publish_chain()

    def set_hx_pro(self, active: bool) -> None:
        self._set_simple("_hx_pro", HxProProfile, active)

    def set_alc(self, active: bool) -> None:
        self._set_simple("_alc", AlcProfile, active)

    def set_mpx(self, active: bool) -> None:
        self._set_simple("_mpx", MpxProfile, active)

    def set_focus(self, active: bool) -> None:
        self._set_simple("_focus", FocusProfile, active)

    # ── PREVI ─────────────────────────────────────────────────────────────
    def set_cristhi_cosh(self, active: bool, **params) -> None:
        with self._lock:
            self._cristhi_cosh = CristhiCoshProfile(
                mode="ACTIVE", sample_rate=self.sample_rate,
                channels=self.channels, **params) if active else None
            self._publish_chain()

    @property
    def cristhi_cosh_active(self) -> bool:
        return self._cristhi_cosh is not None

    def set_antipestal(self, mode: str) -> None:
        mode = (mode or "BYPASS").upper().strip()
        if mode not in _ANTIPESTAL_MODES:
            raise DSPContractError(f"DSP_CONTRACT: modo Antipestal desconocido {mode!r}")
        with self._lock:
            self._antipestal = AntipestalLolaProfile(
                mode=mode, sample_rate=self.sample_rate,
                channels=self.channels) if mode != "BYPASS" else None
            self._publish_chain()

    @property
    def antipestal_active(self) -> bool:
        return self._antipestal is not None

    @property
    def previ_dsp_active(self) -> bool:
        return self.cristhi_cosh_active or self.antipestal_active or self.lucha_enloquecida_active

    def set_lucha_enloquecida(self, mode: str) -> None:
        mode = (mode or "BYPASS").upper().strip()
        if mode != "BYPASS" and mode not in _LUCHA_CODES:
            raise DSPContractError(f"DSP_CONTRACT: perfil Lucha Enloquecida desconocido {mode!r}")
        with self._lock:
            self._lucha_enloquecida = LuchaEnloquecidaProfile(
                mode=mode, sample_rate=self.sample_rate,
                channels=self.channels) if mode != "BYPASS" else None
            self._publish_chain()

    @property
    def lucha_enloquecida_active(self) -> bool:
        return self._lucha_enloquecida is not None

    def set_stage_params(self, label: str, **params) -> None:
        """Cambio de parámetros de una etapa en FRONTERA DE BLOQUE (la GUI
        nunca muta el objeto DSP directamente mientras procesa)."""
        with self._lock:
            st = self._stage_by_label(label) if label in CANONICAL_ORDER else None
            if st is None or not hasattr(st, "set_params"):
                raise DSPContractError(f"DSP_CONTRACT: etapa {label!r} inactiva o sin parámetros")
            st.set_params(**params)
            self._config_version += 1

    # ── Muscle Eq Samir ───────────────────────────────────────────────────
    def set_muscle_eq_active(self, active: bool, preset_id: str = None) -> None:
        with self._lock:
            if self._muscle_eq is None:
                bands = get_preset_bands(preset_id) if preset_id else []
                self._muscle_eq = MuscleEqSamirProfile(
                    mode="ACTIVE" if active else "BYPASS",
                    sample_rate=self.sample_rate, channels=self.channels,
                    preset_id=preset_id or "FLAT", bands=None)
                if bands:
                    self._muscle_eq.load_preset(preset_id, bands)
            else:
                self._muscle_eq.set_active(active)
            self._publish_chain()

    def set_muscle_eq_preset(self, preset_id: str) -> None:
        with self._lock:
            if self._muscle_eq is None:
                self.set_muscle_eq_active(True, preset_id=preset_id)
                return
            self._muscle_eq.load_preset(preset_id, get_preset_bands(preset_id))
            self._config_version += 1

    def set_muscle_eq_band(self, index: int, **kwargs) -> None:
        with self._lock:
            if self._muscle_eq is not None:
                self._muscle_eq.set_band(index, **kwargs)
                self._config_version += 1

    def reset_muscle_eq(self) -> None:
        with self._lock:
            if self._muscle_eq is not None:
                self._muscle_eq.reset_to_flat()
                self._config_version += 1

    @property
    def muscle_eq_active(self) -> bool:
        return self._muscle_eq is not None and self._muscle_eq.active

    # ── Versión O Tron ────────────────────────────────────────────────────
    def set_version_o_tron(self, mode: str) -> None:
        mode = (mode or "BYPASS").upper().strip()
        if mode not in _O_TRON_MODES:
            raise DSPContractError(f"DSP_CONTRACT: modo Versión O Tron desconocido {mode!r}")
        with self._lock:
            self._version_o_tron = VersionOTronProfile(
                mode=mode, sample_rate=self.sample_rate,
                channels=self.channels) if mode != "BYPASS" else None
            self._publish_chain()

    @property
    def version_o_tron_active(self) -> bool:
        return self._version_o_tron is not None

    @property
    def fnesp_dsp_active(self) -> bool:
        return self.version_o_tron_active

    # ── EQ/BIAS ───────────────────────────────────────────────────────────
    def select_eq_bias(self, token: Optional[str]) -> None:
        with self._lock:
            prof = TapeEqBiasProfile(token, sample_rate=self.sample_rate,
                                     channels=self.channels) if token else None
            self._eq_bias_token, self._eq_bias = token, prof
            self._publish_chain()

    @property
    def eq_bias_active_token(self) -> Optional[str]:
        return self._eq_bias_token

    @property
    def mpx_active(self) -> bool:
        return self._mpx is not None

    @property
    def focus_active(self) -> bool:
        return self._focus is not None

    @property
    def hx_pro_active(self) -> bool:
        return self._hx_pro is not None

    @property
    def alc_active(self) -> bool:
        return self._alc is not None

    @property
    def has_active_processing(self) -> bool:
        """True si alguna etapa transforma la señal (Muscle EQ en BYPASS
        con la rampa ya terminada no cuenta)."""
        for label, st in self._chain:
            if label == "muscle_eq" and not st.active and st._wet_mix == 0.0 \
                    and st._wet_target == 0.0:
                continue
            return True
        return False

    # ── Reconfiguración TRANSACCIONAL (NR-02) ─────────────────────────────
    def reconfigure(self, sample_rate: int, channels: int) -> None:
        """Valida, construye instancias NUEVAS de todas las etapas activas
        con el rate/canales nuevos (preservando sus parámetros) y publica
        todo junto en una frontera de bloque. Si algo falla, nada cambia."""
        validate_config(sample_rate, channels)
        with self._lock:
            sr, ch = int(sample_rate), int(channels)
            new = {}
            if self._active_profile is not None:
                new["_active_profile"] = NR_PROFILE_CLASSES[self._active_token](
                    mode=self.mode, sample_rate=sr, channels=ch, **self._active_kwargs)
            for attr, cls in (("_hx_pro", HxProProfile), ("_alc", AlcProfile),
                              ("_mpx", MpxProfile), ("_focus", FocusProfile)):
                if getattr(self, attr) is not None:
                    new[attr] = cls(mode="ACTIVE", sample_rate=sr, channels=ch)
            if self._eq_bias is not None:
                new["_eq_bias"] = TapeEqBiasProfile(self._eq_bias_token, sample_rate=sr,
                                                    channels=ch)
            if self._cristhi_cosh is not None:
                c = self._cristhi_cosh
                new["_cristhi_cosh"] = CristhiCoshProfile(
                    mode=c.mode, sample_rate=sr, channels=ch,
                    correction_intensity=c.correction_intensity, softness=c.softness,
                    reconstruction_intensity=c.reconstruction_intensity,
                    dnl_strength=c.dnl_strength, target_peak=c.target_peak)
            if self._antipestal is not None:
                a = self._antipestal
                new["_antipestal"] = AntipestalLolaProfile(
                    mode=a.mode, sample_rate=sr, channels=ch, **dict(a.params))
            if self._lucha_enloquecida is not None:
                new["_lucha_enloquecida"] = LuchaEnloquecidaProfile(
                    mode=self._lucha_enloquecida.mode, sample_rate=sr, channels=ch)
            if self._version_o_tron is not None:
                new["_version_o_tron"] = VersionOTronProfile(
                    mode=self._version_o_tron.mode, sample_rate=sr, channels=ch)
            if self._muscle_eq is not None:
                m = self._muscle_eq
                new["_muscle_eq"] = MuscleEqSamirProfile(
                    mode="ACTIVE" if m.active else "BYPASS", sample_rate=sr, channels=ch,
                    preset_id=m.preset_id, bands=copy.deepcopy(m.bands))
            # ── commit (todo o nada) ──
            old_rate, old_ch = self.sample_rate, self.channels
            for attr, inst in new.items():
                setattr(self, attr, inst)
            self.sample_rate, self.channels = sr, ch
            self._adapters.clear()
            self._publish_chain()
            self._record_event("*", "RECONFIGURE", len(new), "STATE_RESET",
                               f"{old_rate}Hz/{old_ch}ch → {sr}Hz/{ch}ch "
                               f"({len(new)} etapa(s) reconstruidas)")
            for label, _st in self._chain:
                t = self._telemetry[label]
                t.resets += 1
                t.last_reset_reason = "RECONFIGURE"

    @staticmethod
    def warm_up(sample_rate: int = 48000, channels: int = 2) -> float:
        """DSP-06: compila los kernels Numba (Muscle EQ) FUERA del camino
        de audio, en una instancia descartable. Devuelve los ms usados
        (arranque en frío) para telemetría. Llamar antes de capturar."""
        t0 = time.perf_counter()
        try:
            scratch = NRCoordinator(sample_rate, channels)
            scratch.set_muscle_eq_active(True, "FLAT")
            shape = (256,) if channels == 1 else (256, channels)
            scratch.process_chunk(np.zeros(shape, dtype=np.float32))
        except Exception:
            pass
        return (time.perf_counter() - t0) * 1000.0

    def reset(self) -> None:
        with self._lock:
            for label, st in self._exec_chain():
                st.reset()
                t = self._telemetry[label]
                t.resets += 1
                t.last_reset_reason = "RESET"

    # ── Integridad / telemetría ──────────────────────────────────────────
    @property
    def nonfinite_counts(self) -> dict:
        return dict(self._nonfinite_counts)

    @property
    def integrity_state(self) -> str:
        """"CLEAN" o "DEGRADED" (algún saneamiento o fallo de etapa)."""
        bad = sum(self._nonfinite_counts.values()) + sum(
            t.failures for t in self._telemetry.values())
        return "DEGRADED" if bad else "CLEAN"

    @property
    def integrity_events(self) -> list:
        return list(self._events)

    def telemetry(self) -> dict:
        return {label: self._telemetry[label].snapshot() for label in CANONICAL_ORDER}

    def describe_chain(self) -> list:
        """Descripción reproducible de la cadena activa (provenance)."""
        out = []
        for label, st in self._chain:
            info = STAGE_CATALOG[label]
            d = {"stage": label, "family": info.family, "fidelity": info.fidelity,
                 "note": info.note, "class": type(st).__name__, "params": stage_params(st),
                 "block_invariant": info.block_invariant,
                 "fixed_block_latency_frames": 0 if info.block_invariant else 256}
            if label == "nr":
                d["token"] = self._active_token
                d["kwargs"] = dict(self._active_kwargs)
            if label == "eq_bias":
                d["token"] = self._eq_bias_token
            if label == "muscle_eq":
                d["bands"] = [b.to_dict() for b in st.bands]
            out.append(d)
        return out

    def config_hash(self) -> str:
        return config_hash([self.sample_rate, self.channels, self.mode, self.describe_chain()])

    def chain_warnings(self, use_case: Optional[str] = None) -> list:
        """Combinaciones dudosas por caso de uso (DSP-03)."""
        uc = use_case or self.use_case
        if uc not in USE_CASES:
            raise DSPContractError(f"DSP_CONTRACT: caso de uso desconocido {uc!r}")
        w = []
        labels = [label for label, _ in self._chain]
        if "hx_pro" in labels and uc in (USE_PLAYBACK,):
            w.append("HX Pro es una técnica de grabación (bias dinámico): no decodifica "
                     "ni reduce ruido en reproducción")
        if self._active_token and self.mode == "ENCODE" and uc in (USE_CAPTURE_LIVE, USE_PLAYBACK):
            w.append("NR en modo ENCODE simula la grabación; para escuchar una cinta "
                     "codificada se usa DECODE")
        creative = [label for label in labels if STAGE_CATALOG[label].family == FAM_CREATIVE]
        if creative and uc != "CREATIVE":
            w.append(f"efectos creativos activos {creative}: la salida es DERIVED creativa, "
                     f"no restauración del RAW")
        if "nr" in labels:
            w.append(f"NR {self._active_token}: emulación APROXIMADA (sin validación "
                     f"contra hardware de referencia)")
        return w

    # ── Cadena de proceso ────────────────────────────────────────────────
    def _sanitize_stage(self, label: str, out: np.ndarray, stage) -> np.ndarray:
        clean, n_bad = sanitize_finite(out)
        if n_bad:
            self._nonfinite_counts[label] += n_bad
            stage.reset()          # (si es un adaptador, reinicia también sus FIFO)
            t = self._telemetry[label]
            t.nonfinite_samples += n_bad
            t.resets += 1
            t.last_reset_reason = "NONFINITE"
            self._record_event(label, "NONFINITE", n_bad, "SANITIZE_RESET_DEGRADE",
                               "NaN→0, ±Inf→±clip; estado de la etapa reiniciado")
        return clean

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        """Procesa un bloque `[frames, channels]` con la cadena publicada.
        Cadena vacía + entrada finita → MISMO array (bypass bit-transparente)."""
        with self._lock:
            validate_block(chunk, self.channels)
            n = chunk.shape[0]
            out, n_bad_in = sanitize_finite(chunk)
            if n_bad_in:
                self._nonfinite_counts["input"] += n_bad_in
                self._record_event("input", "NONFINITE", n_bad_in, "SANITIZE_DEGRADE",
                                   "NaN/Inf a la ENTRADA de la cadena DSP")
            budget_ms = n * 1000.0 / max(self.sample_rate, 1)
            chain = self._exec_chain()             # snapshot en frontera de bloque
            for label, stage in chain:
                t = self._telemetry[label]
                peak_in = float(np.max(np.abs(out))) if out.size else 0.0
                t0 = time.perf_counter()
                try:
                    res = stage.process_chunk(out)
                except Exception as e:
                    t.failures += 1
                    self._record_event(label, "STAGE_FAILURE", n, "ABORT_BLOCK",
                                       f"{type(e).__name__}: {e}")
                    raise DSPStageError(f"DSP_STAGE_FAILURE: etapa {label!r} falló: {e}",
                                        stage=label, cause=e) from e
                dt_ms = (time.perf_counter() - t0) * 1000.0
                if not isinstance(res, np.ndarray) or res.shape != out.shape:
                    t.failures += 1
                    self._record_event(label, "STAGE_FAILURE", n, "ABORT_BLOCK",
                                       f"forma de salida {getattr(res, 'shape', None)}")
                    raise DSPStageError(
                        f"DSP_STAGE_FAILURE: etapa {label!r} devolvió forma "
                        f"{getattr(res, 'shape', None)} != {out.shape}", stage=label)
                res = self._sanitize_stage(label, res, stage)
                a = np.abs(res)
                t.record(n, dt_ms, peak_in, float(a.max()) if a.size else 0.0,
                         int(np.count_nonzero(a >= 1.0)), budget_ms)
                out = res
            self._block_index += 1
            self._frame_position += n
            if chain and out.dtype != np.float32:
                out = out.astype(np.float32)
            return out
