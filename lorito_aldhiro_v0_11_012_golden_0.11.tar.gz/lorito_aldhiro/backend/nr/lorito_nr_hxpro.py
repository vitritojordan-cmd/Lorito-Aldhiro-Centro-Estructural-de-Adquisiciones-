from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Emulación de HX Pro (extensión dinámica de bias) del catálogo NR.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_hxpro.py — Dolby HX Pro (§GAP-011), portado en física desde
`crac_hx_pro.py` (auditado en CRAC): HX Pro no es un sistema de
codificación de doble extremo (no requiere decodificar nada al
reproducir) — es una técnica de extensión de headroom en alta
frecuencia aplicada durante la GRABACIÓN. Aquí se emula su efecto
acústico sobre audio ya capturado (post-ADC), como una única cadena de
proceso (sin modos ENCODE/DECODE separados):

  1. Detector de contenido HF — paso-alto 5kHz + envolvente RMS.
  2. Mapa de Bias Equivalente (BRF, 0..1) — normaliza la energía HF.
  3. Compensación de headroom HF — ganancia adicional en la banda alta,
     hasta `MAX_HF_GAIN_DB` (3.0 dB), proporcional al BRF.
  4. Corrección de saturación armónica — modelo de saturación de cinta
     simplificado (tanh), inversamente proporcional al BRF.
  5. Limitador transparente — evita overshoot del paso 3.
"""

import math

import numpy as np

from lorito_aldhiro.backend.nr.lorito_nr_dsp_core import Biquad, highpass, shelving_high


class HxProProfile:
    display_name = "HX Pro"
    cell_token = ""       # no tiene celda de leyenda dedicada en la fila NR —
                            # se ilumina la celda ALC/HX del panel OPTAPE (§GAP-010)
    overlay_token = "HX_PRO"

    DETECTOR_FC_HZ = 5000.0
    MAX_HF_GAIN_DB = 3.0
    SATURATION_DRIVE = 1.6
    ATTACK_MS, RELEASE_MS = 0.4, 25.0

    def __init__(self, mode: str = "ACTIVE", sample_rate: int = 48000, channels: int = 2):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def _build(self) -> None:
        self._active = self.mode != "BYPASS"
        if not self._active:
            return
        self._detector: Biquad = highpass(self.DETECTOR_FC_HZ, self.fs, self.channels)
        self._hf_boost: Biquad = shelving_high(self.DETECTOR_FC_HZ, self.MAX_HF_GAIN_DB,
                                                self.fs, self.channels)
        self.threshold_sq = (10.0 ** (-30.0 / 20.0)) ** 2
        self.att = math.exp(-1.0 / max(1, int(self.fs * self.ATTACK_MS / 1000.0)))
        self.rel = math.exp(-1.0 / max(1, int(self.fs * self.RELEASE_MS / 1000.0)))
        self.env_sq = np.full(self.channels, self.threshold_sq, dtype=np.float64)

    def reset(self) -> None:
        if not self._active:
            return
        self._detector.reset()
        self._hf_boost.reset()
        self.env_sq[:] = self.threshold_sq

    def reconfigure(self, mode: str, sample_rate: int, channels: int) -> None:
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return chunk if chunk.dtype == np.float32 else chunk.astype(np.float32)

        x = np.ascontiguousarray(chunk, dtype=np.float32)
        mono = x.ndim == 1
        x2 = x[:, np.newaxis] if mono else x
        n_ch = x2.shape[1]
        if self.env_sq.shape[0] != n_ch:
            self.env_sq = np.full(n_ch, self.threshold_sq, dtype=np.float64)

        # 1. Detector de contenido HF (envolvente RMS por bloque)
        hf = self._detector.process(x2)
        hf2 = hf if hf.ndim == 2 else hf[:, np.newaxis]
        block_energy = np.mean(hf2.astype(np.float64) ** 2, axis=0)

        brf = np.zeros(n_ch, dtype=np.float64)
        for ch in range(n_ch):
            e = self.env_sq[ch]
            e = (self.att * e + (1.0 - self.att) * block_energy[ch] if block_energy[ch] > e
                 else self.rel * e + (1.0 - self.rel) * block_energy[ch])
            self.env_sq[ch] = e
            # 2. Mapa BRF: 0 = sin contenido HF, 1 = máxima corrección
            brf[ch] = min(1.0, math.sqrt(e) / 0.15)

        # 3. Compensación de headroom HF (ganancia variable en banda alta)
        # Se aplica la banda del shelving completa y se mezcla según BRF
        # medio de los canales (aproximación: un único BRF global por
        # bloque, suficiente a la tasa de bloque real del pipeline).
        brf_avg = float(np.mean(brf))
        boosted = self._hf_boost.process(x2)
        mixed = x2 * (1.0 - brf_avg) + boosted * brf_avg

        # 4. Corrección de saturación armónica (tanh, inversa al BRF —
        # más BRF → menos saturación aparente, más lineal)
        drive = self.SATURATION_DRIVE * (1.0 - 0.8 * brf_avg)
        saturated = np.tanh(mixed * (1.0 + drive)) / math.tanh(1.0 + drive)

        # 5. Limitador transparente (techo suave, −0.3 dBFS)
        ceiling = 10.0 ** (-0.3 / 20.0)
        out = np.clip(saturated, -ceiling, ceiling)

        return out[:, 0] if mono else out.astype(np.float32)
