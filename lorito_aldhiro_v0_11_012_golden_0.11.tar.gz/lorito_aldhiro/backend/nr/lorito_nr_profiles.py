from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Perfiles seleccionables del sistema de reducción de ruido.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_profiles.py — los 8 sistemas de reducción de ruido pedidos
por el usuario, integrados a Lorito Aldhiro (§GAP-011).

Física y parámetros de cada sistema verificados contra las
implementaciones reales auditadas en CRAC (`crac.nr.*`): mismos Fc/
ganancias/tipo, adaptados al núcleo DSP propio de Lorito Aldhiro
(`lorito_nr_dsp_core.py` — sin SciPy/Numba, bucle Python directo,
suficiente a la tasa de bloque real del pipeline de captura). Se portó
la FÍSICA (coeficientes, topología de bandas, ley de ganancia del
compander), no el código línea por línea — el andamiaje de motores de
calibración/medición/auto-detección que CRAC deja "dormido" (nunca
invocado desde el motor de audio) no se replicó: no tiene sentido
portar infraestructura que ni el propio CRAC usa.

Contrato común — todos los perfiles:
    NRProfile(mode="DECODE"|"ENCODE"|"BYPASS", sample_rate, channels)
        .process_chunk(chunk: np.ndarray) -> np.ndarray
        .reset()

DECODE = reproducción/captura de una cinta grabada con este sistema
(expansión / de-énfasis). ENCODE = simular cómo sonaría al grabar
(compresión / pre-énfasis) — modo de monitorización, no escribe cinta.
"""

from abc import ABC, abstractmethod
from typing import Optional

import numpy as np

from lorito_aldhiro.backend.nr.lorito_nr_dsp_core import (
    Biquad, shelving_high, shelving_low, highpass,
    RmsCompander, VariableLowpass, TwoBandAdaptiveGate,
)


class NRProfile(ABC):
    display_name: str = "NR"
    cell_token: str = ""       # token de celda del contómetro (§GAP-010)
    overlay_token: str = ""    # token de lorito_overlay_registry

    def __init__(self, mode: str = "DECODE", sample_rate: int = 48000, channels: int = 2):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._active = False
        self._build()

    @abstractmethod
    def _build(self) -> None: ...

    @abstractmethod
    def process_chunk(self, chunk: np.ndarray) -> np.ndarray: ...

    def reset(self) -> None:
        pass

    def reconfigure(self, mode: str, sample_rate: int, channels: int) -> None:
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def _sign(self) -> float:
        return +1.0 if self.mode == "ENCODE" else -1.0

    def _bypass_output(self, chunk: np.ndarray) -> np.ndarray:
        return chunk if chunk.dtype == np.float32 else chunk.astype(np.float32)


# ═══════════════════════════════════════════════════════════════════════
#  DOLBY B — una banda, Fc=800Hz, ±10dB (sistema de consumo más simple)
# ═══════════════════════════════════════════════════════════════════════

class DolbyBProfile(NRProfile):
    display_name = "Dolby B"; cell_token = "DOLBY_B"; overlay_token = "NR_DOLBY_B"
    FC_HZ, GAIN_DB = 800.0, 10.0

    def _build(self) -> None:
        self._filter: Optional[Biquad] = None
        self._active = self.mode in ("ENCODE", "DECODE")
        if self._active:
            self._filter = shelving_high(self.FC_HZ, self._sign() * self.GAIN_DB,
                                          self.fs, self.channels)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = self._filter.process(np.ascontiguousarray(chunk, dtype=np.float32))
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        if self._filter is not None:
            self._filter.reset()


# ═══════════════════════════════════════════════════════════════════════
#  DOLBY C — dos bandas en cascada (500Hz + 1200Hz), ±10dB c/u
# ═══════════════════════════════════════════════════════════════════════

class DolbyCProfile(NRProfile):
    display_name = "Dolby C"; cell_token = "DOLBY_C"; overlay_token = "NR_DOLBY_C"
    BANDS = [(500.0, 10.0), (1200.0, 10.0)]

    def _build(self) -> None:
        self._filters: list[Biquad] = []
        self._active = self.mode in ("ENCODE", "DECODE")
        if self._active:
            sign = self._sign()
            self._filters = [shelving_high(fc, sign * g, self.fs, self.channels)
                             for fc, g in self.BANDS]

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = np.ascontiguousarray(chunk, dtype=np.float32)
        for f in self._filters:
            out = f.process(out)
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        for f in self._filters:
            f.reset()


# ═══════════════════════════════════════════════════════════════════════
#  DOLBY S — tres bandas: low-shelf 200Hz/6dB + high-shelf 400Hz/6dB +
#  high-shelf 3000Hz/10dB (topología mixta, el sistema más refinado)
# ═══════════════════════════════════════════════════════════════════════

class DolbySProfile(NRProfile):
    display_name = "Dolby S"; cell_token = "DOLBY_S"; overlay_token = "NR_DOLBY_S"
    BANDS = [("low", 200.0, 6.0), ("high", 400.0, 6.0), ("high", 3000.0, 10.0)]

    def _build(self) -> None:
        self._filters: list[Biquad] = []
        self._active = self.mode in ("ENCODE", "DECODE")
        if self._active:
            sign = self._sign()
            for kind, fc, g in self.BANDS:
                builder = shelving_low if kind == "low" else shelving_high
                self._filters.append(builder(fc, sign * g, self.fs, self.channels))

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = np.ascontiguousarray(chunk, dtype=np.float32)
        for f in self._filters:
            out = f.process(out)
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        for f in self._filters:
            f.reset()


# ═══════════════════════════════════════════════════════════════════════
#  DBX — tres tipos reales (I, II, 224), igual que CRAC: pre/de-énfasis
#  propio de cada tipo + compander RMS 2:1 de banda completa compartido
# ═══════════════════════════════════════════════════════════════════════

class DbxProfile(NRProfile):
    display_name = "Dbx"; cell_token = "DBX"; overlay_token = "NR_DBX"
    THRESHOLD_DB = -80.0

    # Física real de cada tipo, verificada contra crac_dbx_nr.py (§GAP-012):
    #   I:   pre-énfasis 3000Hz/+6dB  — el original de 1971, un solo shelf.
    #   II:  pre-énfasis 1600Hz/+9dB  — el más común en cassette de consumo.
    #   224: pre-énfasis en DOS bandas (400Hz low/+4dB + 2500Hz high/+8dB)
    #        — variante profesional de estudio (dbx 224/224X).
    _TYPES = {
        "I":   {"bands": [("high", 3000.0, 6.0)],
                "attack_ms": 20.0, "release_ms": 500.0},
        "II":  {"bands": [("high", 1600.0, 9.0)],
                "attack_ms": 10.0, "release_ms": 350.0},
        "224": {"bands": [("low", 400.0, 4.0), ("high", 2500.0, 8.0)],
                "attack_ms": 10.0, "release_ms": 400.0},
    }

    def __init__(self, mode: str = "DECODE", sample_rate: int = 48000,
                 channels: int = 2, dbx_type: str = "II"):
        self.dbx_type = dbx_type.upper().strip() if dbx_type.upper().strip() in self._TYPES else "II"
        super().__init__(mode, sample_rate, channels)

    def _build(self) -> None:
        self._preemph: list[Biquad] = []
        self._compander: Optional[RmsCompander] = None
        self._active = self.mode in ("ENCODE", "DECODE")
        if not self._active:
            return
        spec = self._TYPES[self.dbx_type]
        sign = self._sign()
        for kind, fc, g in spec["bands"]:
            builder = shelving_low if kind == "low" else shelving_high
            self._preemph.append(builder(fc, sign * g, self.fs, self.channels))
        ratio = 2.0 if self.mode == "ENCODE" else 0.5
        self._compander = RmsCompander(self.fs, self.channels, self.THRESHOLD_DB,
                                        ratio, spec["attack_ms"], spec["release_ms"])

    def reconfigure(self, mode: str, sample_rate: int, channels: int,
                     dbx_type: Optional[str] = None) -> None:
        if dbx_type is not None and dbx_type.upper().strip() in self._TYPES:
            self.dbx_type = dbx_type.upper().strip()
        super().reconfigure(mode, sample_rate, channels)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = np.ascontiguousarray(chunk, dtype=np.float32)
        if self.mode == "ENCODE":
            for f in self._preemph:
                out = f.process(out)
            out = self._compander.process(out)
        else:
            out = self._compander.process(out)
            for f in self._preemph:
                out = f.process(out)
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        for f in self._preemph:
            f.reset()
        if self._compander is not None:
            self._compander.reset()


# ═══════════════════════════════════════════════════════════════════════
#  ANRS — variante JVC de Dolby B: una banda, Fc=1000Hz, ±10dB
# ═══════════════════════════════════════════════════════════════════════

class AnrsProfile(NRProfile):
    display_name = "Anrs"; cell_token = "ANRS"; overlay_token = "NR_ANRS"
    FC_HZ, GAIN_DB = 1000.0, 10.0

    def _build(self) -> None:
        self._filter: Optional[Biquad] = None
        self._active = self.mode in ("ENCODE", "DECODE")
        if self._active:
            self._filter = shelving_high(self.FC_HZ, self._sign() * self.GAIN_DB,
                                          self.fs, self.channels)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = self._filter.process(np.ascontiguousarray(chunk, dtype=np.float32))
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        if self._filter is not None:
            self._filter.reset()


# ═══════════════════════════════════════════════════════════════════════
#  S-ANRS (Super ANRS) — banda de ANRS + compander wideband (la mejora
#  real de Super ANRS sobre ANRS es agregar compansión de banda ancha)
# ═══════════════════════════════════════════════════════════════════════

class SAnrsProfile(NRProfile):
    display_name = "S Anrs"; cell_token = "S_ANRS"; overlay_token = "NR_S_ANRS"
    FC_HZ, GAIN_DB = 1000.0, 10.0
    THRESHOLD_DB = -76.0
    ATTACK_MS, RELEASE_MS = 8.0, 300.0

    def _build(self) -> None:
        self._filter: Optional[Biquad] = None
        self._compander: Optional[RmsCompander] = None
        self._active = self.mode in ("ENCODE", "DECODE")
        if not self._active:
            return
        sign = self._sign()
        self._filter = shelving_high(self.FC_HZ, sign * self.GAIN_DB, self.fs, self.channels)
        ratio = 2.0 if self.mode == "ENCODE" else 0.5
        self._compander = RmsCompander(self.fs, self.channels, self.THRESHOLD_DB,
                                        ratio, self.ATTACK_MS, self.RELEASE_MS)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = np.ascontiguousarray(chunk, dtype=np.float32)
        if self.mode == "ENCODE":
            out = self._filter.process(out)
            out = self._compander.process(out)
        else:
            out = self._compander.process(out)
            out = self._filter.process(out)
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        if self._filter is not None:
            self._filter.reset()
        if self._compander is not None:
            self._compander.reset()


# ═══════════════════════════════════════════════════════════════════════
#  DNL (Philips, 1971) — un solo extremo: paso-bajo deslizante
# ═══════════════════════════════════════════════════════════════════════

class DnlProfile(NRProfile):
    display_name = "Dnl"; cell_token = "DNL"; overlay_token = "NR_DNL"
    CUTOFF_MIN_HZ, CUTOFF_MAX_HZ = 3500.0, 18000.0
    THRESHOLD_DB = -40.0
    ATTACK_MS, RELEASE_MS = 0.3, 80.0

    def _build(self) -> None:
        self._lowpass: Optional[VariableLowpass] = None
        # Un solo extremo: no hay ENCODE real (nunca "codifica" la cinta),
        # solo BYPASS/ACTIVE — se activa en cualquier modo que no sea
        # explícitamente BYPASS (paridad con el comportamiento real de
        # CRAC, que trata ENCODE como no-op para sistemas single-ended).
        self._active = self.mode != "BYPASS"
        if self._active:
            self._lowpass = VariableLowpass(
                self.fs, self.channels, self.CUTOFF_MIN_HZ, self.CUTOFF_MAX_HZ,
                self.THRESHOLD_DB, self.ATTACK_MS, self.RELEASE_MS)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = self._lowpass.process(np.ascontiguousarray(chunk, dtype=np.float32))
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        if self._lowpass is not None:
            self._lowpass.reset()


# ═══════════════════════════════════════════════════════════════════════
#  DNR (National Semiconductor LM1894, 1981) — un solo extremo, 2 bandas
# ═══════════════════════════════════════════════════════════════════════

class DnrProfile(NRProfile):
    display_name = "Dnr"; cell_token = "DNR"; overlay_token = "NR_DNR"
    CROSSOVER_HZ = 2000.0
    THRESHOLD_DB = -42.0
    MAX_ATTEN_DB = 10.0
    ATTACK_MS, RELEASE_MS = 2.0, 120.0

    def _build(self) -> None:
        self._gate: Optional[TwoBandAdaptiveGate] = None
        self._active = self.mode != "BYPASS"
        if self._active:
            self._gate = TwoBandAdaptiveGate(
                self.fs, self.channels, self.CROSSOVER_HZ, self.THRESHOLD_DB,
                self.MAX_ATTEN_DB, self.ATTACK_MS, self.RELEASE_MS)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active:
            return self._bypass_output(chunk)
        out = self._gate.process(np.ascontiguousarray(chunk, dtype=np.float32))
        return np.clip(out, -1.0, 1.0)

    def reset(self) -> None:
        if self._gate is not None:
            self._gate.reset()


NR_PROFILE_CLASSES: dict[str, type] = {
    "DOLBY_B": DolbyBProfile, "DOLBY_C": DolbyCProfile, "DOLBY_S": DolbySProfile,
    "DBX": DbxProfile, "ANRS": AnrsProfile, "S_ANRS": SAnrsProfile,
    "DNL": DnlProfile, "DNR": DnrProfile,
}
