from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de monitorización en vivo de la señal durante la captura.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_monitor_engine.py — motor de monitorización de señal para la
escucha en tiempo real del audio que pasa por el Pipeline de captura,
pedido explícito del usuario: "Diseña un motor de monitorización de
señal para la escucha a tiempo real del audio pasante por el Pipeline
de captura [...] entrada en la barra de menú con el nombre MONITOR
[...] las selecciones Stereo, Mono L, Mono R y Desactivado."

Arquitectura (nueva, sin precedente en CRAC — Lorito Aldhiro no tiene
panel izquierdo de botones físicos de monitor, de ahí que viva en el
menú, ver GAP de referencia):

  · `_audio_callback` de `CaptureEngine` (backend/lorito_capture_engine.py)
    YA copiaba cada bloque de entrada a `self._monitor_block` (buffer
    prealocado, "Monitor lateral — siempre activo, incluso en pausa")
    pero nunca existía un consumidor real de ese dato — este motor es
    ese consumidor.
  · `MonitorEngine.push_block()` se llama DESDE el mismo callback RT de
    entrada (zero-allocation: solo copia a un ring buffer prealocado,
    misma regla que el resto de `_audio_callback`) — nunca se le pide
    hacer DSP pesado ahí.
  · `MonitorEngine` posee su propio `sd.OutputStream` de salida — SU
    callback (también tiempo real, pero un stream independiente del de
    captura) lee del ring buffer y aplica el downmix seleccionado
    (Numba `njit`, zero-allocation sobre buffers prealocados) antes de
    entregar el bloque a la tarjeta de sonido. Es la arquitectura
    estándar de "passthrough monitoring" de un deck real: la señal que
    se escucha por auriculares/salida de monitor es independiente del
    pipeline de escritura a disco, con su propia latencia mínima.
  · El modo activo (`_mode_flag`, un array NumPy de 1 elemento en vez
    de un int de Python) se lee sin lock desde el callback de salida —
    la escritura desde el hilo de GUI es una asignación atómica de un
    único elemento, mismo criterio de "más simple que un lock por
    lectura constante" ya aceptado en otras partes RT del proyecto.

LÍMITE EXPLÍCITO (documentado, no fingido): este motor no pudo probarse
contra hardware de audio real en esta sesión (sandbox sin dispositivo
de sonido) — se verificó el downmix numéricamente de forma aislada
(ver test en el GAP de referencia), no el `sd.OutputStream` en sí.
"""

import threading
from typing import Optional

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit, NUMBA_OK

try:
    import sounddevice as sd
    _SD_OK = True
except Exception:
    sd = None
    _SD_OK = False


MODE_STEREO   = 0
MODE_MONO_L   = 1
MODE_MONO_R   = 2
MODE_OFF      = 3

MODE_TOKENS = {
    "STEREO":      MODE_STEREO,
    "MONO_L":      MODE_MONO_L,
    "MONO_R":      MODE_MONO_R,
    "OFF":         MODE_OFF,
}


@njit(cache=True)
def _downmix(block: np.ndarray, out: np.ndarray, mode: int) -> None:
    """Downmix in-place sobre `out` (mismo shape que `block`), sin
    allocaciones — apto para el callback RT de salida.
    mode: 0=Stereo (passthrough), 1=Mono L (L en ambos canales),
    2=Mono R (R en ambos canales), 3=Off (silencio)."""
    n = block.shape[0]
    n_ch = block.shape[1] if block.ndim > 1 else 1
    if mode == MODE_OFF:
        for i in range(n):
            for c in range(n_ch):
                out[i, c] = 0.0
        return
    if mode == MODE_STEREO or n_ch < 2:
        for i in range(n):
            for c in range(n_ch):
                out[i, c] = block[i, c]
        return
    src_ch = 0 if mode == MODE_MONO_L else 1
    for i in range(n):
        v = block[i, src_ch]
        for c in range(n_ch):
            out[i, c] = v


class _MonoRingBuffer:
    """Ring SPSC de muestras (no de bloques) entre el callback de ENTRADA
    (productor) y el callback de SALIDA del monitor (consumidor).

    Orden Golden de Captura (CAP-001): antes ambos callbacks compartían un
    `threading.Lock` — un lock CONTENCIOSO dentro del callback de captura.
    Ahora es SPSC sin locks: `_w_total` solo lo escribe el productor y
    `_r_total` solo el consumidor (contadores monotónicos de frames). Los
    datos se copian ANTES de publicar el contador (NumPy puede liberar el
    GIL durante la copia). Si el monitor va atrasado, el productor NO
    sobrescribe: descarta el bloque del monitor y lo cuenta en
    `dropped_frames` (ruta con pérdida permitida y contabilizada; jamás
    afecta al audio archivístico)."""

    def __init__(self, capacity_frames: int, channels: int):
        self.capacity = capacity_frames
        self.channels = channels
        self._buf = np.zeros((capacity_frames, channels), dtype=np.float32)
        self._w_total = 0
        self._r_total = 0
        self.dropped_frames = 0

    def reconfigure(self, capacity_frames: int, channels: int) -> None:
        """Solo con ambos callbacks detenidos (MonitorEngine.reconfigure
        detiene el stream de salida antes)."""
        self.capacity = capacity_frames
        self.channels = channels
        self._buf = np.zeros((capacity_frames, channels), dtype=np.float32)
        self._w_total = 0
        self._r_total = 0

    @property
    def _filled(self) -> int:
        return self._w_total - self._r_total

    def write(self, block: np.ndarray) -> None:
        n = block.shape[0]
        if n <= 0:
            return
        cap = self.capacity
        w = self._w_total
        if n > cap - (w - self._r_total):
            self.dropped_frames += n
            return
        pos = w % cap
        end = pos + n
        if end <= cap:
            self._buf[pos:end] = block
        else:
            first = cap - pos
            self._buf[pos:] = block[:first]
            self._buf[:end - cap] = block[first:]
        self._w_total = w + n          # publicación

    def read(self, n: int, out: np.ndarray) -> int:
        r = self._r_total
        avail = min(n, self._w_total - r)
        if avail <= 0:
            return 0
        cap = self.capacity
        pos = r % cap
        end = pos + avail
        if end <= cap:
            out[:avail] = self._buf[pos:end]
        else:
            first = cap - pos
            out[:first] = self._buf[pos:]
            out[first:avail] = self._buf[:end - cap]
        self._r_total = r + avail      # libera
        return avail


class MonitorEngine:
    """
    Motor de monitorización — entrada en la barra de menú "MONITOR"
    (Stereo/Mono L/Mono R/Desactivado, pedido explícito del usuario,
    ya que Lorito Aldhiro no tiene panel izquierdo de botones físicos).

    Uso desde `lorito_capture_engine.CaptureEngine`:
      · `engine.monitor_engine = MonitorEngine(...)`
      · en `_audio_callback`, tras actualizar `_monitor_block`:
            if self.monitor_engine is not None:
                self.monitor_engine.push_block(indata[:n_mon])

    Uso desde `lorito_main_window.py` (menú "MONITOR"):
      · `self._monitor_engine.set_mode("STEREO"/"MONO_L"/"MONO_R"/"OFF")`
      · `self._monitor_engine.start(rate, channels)` / `.stop()`
    """

    RING_SECONDS = 0.5   # profundidad del ring — suficiente para absorber
                          # jitter entre el callback de entrada y el de
                          # salida sin acumular latencia perceptible.

    def __init__(self, sample_rate: int = 48000, channels: int = 2,
                device: Optional[int] = None, blocksize: int = 1024):
        self.sample_rate = sample_rate
        self.channels = channels
        self.device = device
        self.blocksize = blocksize
        self._mode_flag = np.array([MODE_OFF], dtype=np.int32)   # lectura sin lock en el callback
        self._ring = _MonoRingBuffer(
            capacity_frames=max(1, int(sample_rate * self.RING_SECONDS)),
            channels=channels)
        self._out_prealloc = np.zeros((blocksize, channels), dtype=np.float32)
        self._stream = None
        self._running = False

    # ── API llamada desde el callback RT de entrada (zero-allocation) ──
    def push_block(self, block: np.ndarray) -> None:
        if block.size == 0:
            return
        b = block if block.dtype == np.float32 else block.astype(np.float32)
        if b.ndim == 1:
            b = b[:, np.newaxis]
        self._ring.write(b)

    # ── API llamada desde la GUI (hilo principal, no-RT) ────────────────
    def set_mode(self, token: str) -> None:
        self._mode_flag[0] = MODE_TOKENS.get(token.upper().strip(), MODE_OFF)

    @property
    def mode_token(self) -> str:
        for tok, val in MODE_TOKENS.items():
            if val == int(self._mode_flag[0]):
                return tok
        return "OFF"

    def reconfigure(self, sample_rate: int, channels: int) -> None:
        was_running = self._running
        if was_running:
            self.stop()
        self.sample_rate = sample_rate
        self.channels = channels
        self._ring.reconfigure(
            capacity_frames=max(1, int(sample_rate * self.RING_SECONDS)),
            channels=channels)
        self._out_prealloc = np.zeros((self.blocksize, channels), dtype=np.float32)
        if was_running:
            self.start(sample_rate, channels)

    def start(self, sample_rate: int, channels: int) -> bool:
        """Abre el `OutputStream` de monitor. Degrada con gracia (log +
        `False`) si `sounddevice` o el dispositivo de salida no están
        disponibles — nunca rompe el arranque de la app por esto,
        mismo criterio que el resto del pipeline de audio."""
        if not _SD_OK:
            return False
        self.sample_rate = sample_rate
        self.channels = channels
        self._ring.reconfigure(
            capacity_frames=max(1, int(sample_rate * self.RING_SECONDS)),
            channels=channels)
        self._out_prealloc = np.zeros((self.blocksize, channels), dtype=np.float32)

        def _out_callback(outdata, frames, time_info, status):
            n_read = self._ring.read(frames, self._out_prealloc[:frames])
            if n_read < frames:
                self._out_prealloc[n_read:frames] = 0.0
            _downmix(self._out_prealloc[:frames], outdata, int(self._mode_flag[0]))

        try:
            self._stream = sd.OutputStream(
                samplerate=sample_rate, channels=channels, blocksize=self.blocksize,
                device=self.device, dtype="float32", callback=_out_callback)
            self._stream.start()
            self._running = True
            return True
        except Exception:
            self._stream = None
            self._running = False
            return False

    def stop(self) -> None:
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
        self._stream = None
        self._running = False

    @property
    def running(self) -> bool:
        return self._running
