from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Lógica pura de reproducción extraída del God Object — nombre codificado de zona de velocidad del Scrub Velocista.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_speed_zone_labels.py — GAP-062, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Extracción MECÁNICA de `PlaybackMixin._speed_zone_coded_name()`
(`lorito_mw_playback.py`, antes 1099 líneas) — un `@staticmethod` que
ya era, de hecho, lógica pura (sin ningún widget de Qt ni estado de
instancia involucrado: solo un `float` de entrada, un `str` de
salida), exactamente el mismo patrón de extracción ya usado en GAP-056
(`lorito_export_session_spec.py`) para el God Object de exportación.

`_speed_zone_coded_name()` reproduce el texto y los umbrales EXACTOS
del código que reemplaza — verificado con un test de regresión
exhaustivo (`tests/test_speed_zone_labels.py`) que cubre cada frontera
de zona, no solo "produce algo razonable". El resto de
`PlaybackMixin` (orquestación de `PlaybackEngine`, widgets Qt, señales)
NO se toca aquí.

Hallazgo real de esta extracción (GAP-062), documentado para que una
sesión futura no lo reabra sin verlo: el mismo archivo
`lorito_mw_playback.py` definía además `_resample_full_cubic()`/
`_resample_block_cubic()` (interpolación cúbica Catmull-Rom, calco de
la del propio `PlaybackEngine`) — auditados con una búsqueda
exhaustiva en todo el árbol (`lorito_aldhiro/` + `tests/`) y
confirmados SIN NINGÚN llamador real ni cobertura de test, en ningún
sitio. Eran código muerto: una tercera implementación redundante del
mismo resampleo cúbico que ya viven, activas y en uso real, en
`backend/playback/lorito_playback_engine.py`
(`_resample_stateful`/`resample_stateful_continuous`, GAP-037/062). En
GAP-062 se dejaron sin retirar deliberadamente — la decisión de
retiro se dejó para una sesión futura o para que el usuario la
tomara, no como consecuencia automática de esa extracción.

**Retirados en GAP-070** (FASE 7, continuación de este mismo cierre de
Orden): antes de borrarlos se repitió la auditoría exhaustiva desde
cero (no se asumió el resultado de GAP-062) — mismo resultado, cero
llamadores reales, cero cobertura de test, y además se descartó
explícitamente cualquier llamador DINÁMICO (`grep` de `getattr`/
nombre entre comillas apuntando a esos dos métodos, en todo el árbol,
incluido `tools/modularizar_main_window.py`, que solo los menciona en
una lista estática de un script histórico de un único uso — GAP-046 —
que ya no opera sobre el archivo actual). Con esa confirmación
adicional, se retiraron de `lorito_mw_playback.py` sin reemplazo (el
resampleo real sigue viviendo, sin cambios, en `PlaybackEngine`).
"""


def speed_zone_coded_name(ratio: float) -> str:
    """
    Nombre codificado de la zona de velocidad del Scrub Velocista
    para el overlay del contómetro — calco EXACTO de
    `_carol_speed_label()` (CRAC, `crac_normalization_core.py`) +
    `SPEED_ZONE_DISPLAY_NAMES` (`mega_panel_text_registry.py`),
    auditados en su momento, con la corrección explícita del usuario
    sobre el texto real de la zona Aguilar ("Aguilr", no "Aguilar" —
    el diccionario estático que se encontró en el árbol de CRAC no
    coincide con el overlay real mostrado en pantalla).
    Umbrales idénticos; "" = zona neutra (sin overlay,
    |ratio-1.0|<0.005, mismo umbral que CRAC).
    """
    if abs(ratio - 1.0) < 0.005:
        return ""
    if ratio > 1.0:
        if ratio >= 1.61:
            return "UltrJayaqute"   # Pactorald Plus
        if ratio >= 1.41:
            return "JayaquTe"       # Pactorald
        if ratio >= 1.11:
            return "VerLcha"        # Verilucha
        return "CaLibrt"            # Calibrante (1.005 … 1.10)
    # ratio < 1.0 — rango [0.50, 0.999]
    if ratio >= 0.90:
        return "CaLibrt"            # Calibrante (0.90 … 0.999)
    if ratio >= 0.70:
        return "Aguilr"             # Aguilar — overlay real "Aguilr"
    if ratio >= 0.60:
        return "CromTn"             # Cromantina
    return "SupRpdr"                # Superprador (0.50 … 0.59)
