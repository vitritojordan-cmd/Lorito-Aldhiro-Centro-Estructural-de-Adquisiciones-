from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Modelo físico de la cinta magnética (velocidad, wow/flutter, saturación) para reproducción.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import time
import logging
from enum import Enum, auto
import math as _math
from typing import Optional, List, Callable, Dict, Any

# GAP-054 (§14, FASE 8 de la Orden de Saneamiento, Integración y
# Consolidación): antes había aquí `from lorito_aldhiro.frontend.
# integration.lorito_itl_bridge import _ITL_AVAILABLE` — una
# importación backend→frontend prohibida por §14. Además, esa bandera
# no tenía relación real con lo que de verdad se usa más abajo: sigue
# el estado de `lorito_itl_integration.py` (el motor ITL interno,
# GAP-008), pero el bloque de esta clase intenta importar
# `TapePhysicsEngine`/`PROFILE_C60`/`PROFILE_C90` del plugin EXTERNO
# `aecct2_itl_integration` (nunca incluido en el tarball, opcional —
# ver requirements.txt) — dos módulos de nombre parecido pero
# completamente distintos. Usar la bandera del interno como gate del
# externo podía dar un falso negativo (saltarse el intento del externo
# aunque SÍ estuviera disponible, solo porque el interno no lo
# estaba). Se quita el gate: el bloque de abajo ya tiene su propio
# `try/except` seguro alrededor del import real, que es la única
# comprobación que de verdad importa — mismo comportamiento observable
# hoy (el plugin externo no existe en este tarball, así que el
# resultado sigue siendo `_itl_active = False` en ambos casos), pero
# sin la dependencia cruzada ni el falso negativo.



# ─────────────────────────────────────────────────────────────────────────────
#  TAPE LOG PANEL  — indicador de cassette C-60 / C-90 / OTROS
#  Muestra: hubs con giro diferenciado (carrete lleno→vacío), leyenda de lado,
#           y tape counter estilo deck vintage.
#  Modos de color:
#    "C-60"  → hubs + leyenda crema brillante  (#FFF8DC vivo)
#    "C-90"  → hubs + leyenda turquesa brillante (#00E5CC vivo)
#    "OTROS" → hubs + leyenda ámbar brillante   (#FFB300 vivo), parpadeo 1s
# ─────────────────────────────────────────────────────────────────────────────

# ══════════════════════════════════════════════════════════════════════════════
#  MOTOR DE FÍSICA DE TRANSPORTE DE CINTA — ITL v1.1.0 (aecct2_itl_integration)
#  Reemplazado en v0.22.17: CassetteTransportPhysics (gemini-code, v0.22.06–16)
#  sustituido por el Motor Inteligente de Transporte de Cinta (ITL) completo.
#
#  El motor reside en aecct2_itl_integration.py e implementa:
#    · TapeProfile          — perfil físico determinista C-60 / C-90 (IEC 60581-6)
#    · ReelKinematics       — cinemática exacta de carretes con espiral de Arquímedes
#    · TapeLengthClock      — reloj maestro: cm físicos acumulados (no time.monotonic)
#    · AudioPresenceDetector— silencio con histéresis dual y noise floor adaptativo
#    · TapeTransportFSM     — máquina de estados determinista (7 estados)
#    · TapePhysicsEngine    — integrador en thread daemon (10 Hz, SCHED_BATCH)
#    · IntelligentTapeLogic — orquestación de alto nivel
#    · ITLBridge            — integración aditiva con LoritoAldhiroStudio (sin romper API)
#
#  Shim de compatibilidad: las clases antiguas (_CassetteType_Enum,
#  _TransportMode_Enum, _SideState_Enum, _AutoStopState_Enum, _PhysicsOutputs,
#  CassetteTransportPhysics) se mantienen como wrappers delegados hacia ITL,
#  preservando la interfaz que TapeLogPanel usa internamente (step, flip_side,
#  insert_cassette, outputs.*). TapeLogPanel NO se modifica.
# ══════════════════════════════════════════════════════════════════════════════

# ── Shim: clases de compatibilidad con API anterior de CassetteTransportPhysics ──
# TapeLogPanel sigue usando estas clases; internamente delegan en el ITL.
# Las constantes de clase se preservan para que el código existente que hace
# CassetteTransportPhysics.NOMINAL_SPEED_CM_S (etc.) siga funcionando.

class _CassetteType_Enum(Enum):
    C60 = auto()
    C90 = auto()

class _TransportMode_Enum(Enum):
    STOP = auto()
    PLAY = auto()
    FF   = auto()
    REW  = auto()

class _SideState_Enum(Enum):
    SIDE_A = auto()
    SIDE_B = auto()

class _AutoStopState_Enum(Enum):
    NONE          = auto()
    END_OF_SIDE_A = auto()
    END_OF_TAPE   = auto()

class _PhysicsOutputs:
    """Estructura de salida compatible con la API anterior de CassetteTransportPhysics."""
    def __init__(self):
        self.reel_rpm_left        = 0.0
        self.reel_rpm_right       = 0.0
        self.reel_radius_left_cm  = 0.0
        self.reel_radius_right_cm = 0.0
        self.tape_position_cm     = 0.0
        self.elapsed_time_s       = 0.0
        self.remaining_time_s     = 0.0
        self.side_state           = _SideState_Enum.SIDE_A
        self.counter_value        = 0.0
        self.auto_stop_state      = _AutoStopState_Enum.NONE

class CassetteTransportPhysics:
    """
    Wrapper de compatibilidad sobre el Motor ITL v1.1.0.

    Preserva la interfaz pública exacta de la clase original
    (CassetteTransportPhysics, gemini-code integrado en v0.22.06) para que
    TapeLogPanel funcione sin modificaciones.

    Internamente delega en TapePhysicsEngine (ITL) cuando está disponible;
    si ITL no está disponible, ejecuta la física simplificada embebida (fallback).

    Diferencias de comportamiento respecto a la clase original:
      · El reloj físico usa TapeLengthClock (monotonic_ns, no timer de GUI).
      · Las RPM incluyen suavizado exponencial (inercia mecánica, α=0.18).
      · El grosor de cinta es determinista (no tiene variación aleatoria).
      · El cuentavueltas usa la integral exacta de espiral (no la aproximación lineal).
      · La API outputs.* sigue siendo compatible y se rellena desde el snapshot ITL.
    """

    # ── Constantes de clase (preservadas para referencias externas) ───────────
    # Literales en lugar de referencias a V_TAPE_CM_S / HUB_RADIUS_CM /
    # MAX_REEL_RADIUS_CM del módulo ITL: esas constantes no existen en el
    # espacio de nombres del monolito en tiempo de definición de clase.
    # Valores IEC 60581-6 idénticos a los del módulo aecct2_itl_integration.
    NOMINAL_SPEED_CM_S      = 4.76   # cm/s (IEC 60581-6) — igual a V_TAPE_CM_S
    FF_REW_SPEED_MULTIPLIER = 20.0
    HUB_RADIUS_CM           = 1.10   # cm  — igual a HUB_RADIUS_CM del ITL
    MAX_REEL_RADIUS_CM      = 3.30   # cm  — igual a MAX_REEL_RADIUS_CM del ITL

    def __init__(self):
        self._tape_type         = None
        self._profile: Optional["TapeProfile"] = None  # noqa: F821
        self._engine: Optional["TapePhysicsEngine"] = None  # noqa: F821
        self._itl_active        = False
        self._side              = _SideState_Enum.SIDE_A

        # Fallback (sin ITL): estado interno simplificado
        self._total_duration_s  = 0.0
        self._side_a_duration_s = 0.0
        self._side_b_duration_s = 0.0
        self._total_length_cm   = 0.0
        self._side_a_length_cm  = 0.0
        self._tape_thickness_cm = 0.0
        self._position_cm       = 0.0
        self._counter_revolutions = 0.0

        self.outputs = _PhysicsOutputs()

    def insert_cassette(self, tape_type) -> None:
        """Inserta un cassette e inicializa el motor ITL con el perfil correspondiente."""
        self._tape_type = tape_type
        self._side      = _SideState_Enum.SIDE_A
        self._position_cm = 0.0
        self._counter_revolutions = 0.0

        if tape_type == _CassetteType_Enum.C60:
            self._total_duration_s  = 60 * 60.0
            self._side_a_duration_s = 30 * 60.0
        elif tape_type == _CassetteType_Enum.C90:
            self._total_duration_s  = 90 * 60.0
            self._side_a_duration_s = 45 * 60.0
        else:
            self._total_duration_s  = 60 * 60.0
            self._side_a_duration_s = 30 * 60.0

        self._side_b_duration_s = self._total_duration_s - self._side_a_duration_s
        self._total_length_cm   = self._total_duration_s  * self.NOMINAL_SPEED_CM_S
        self._side_a_length_cm  = self._side_a_duration_s * self.NOMINAL_SPEED_CM_S
        _area = _math.pi * (self.MAX_REEL_RADIUS_CM ** 2 - self.HUB_RADIUS_CM ** 2)
        _max_side = max(self._side_a_length_cm,
                        self._total_length_cm - self._side_a_length_cm)
        self._tape_thickness_cm = _area / _max_side if _max_side > 0 else 1.2e-3

        # Intentar conectar con el motor ITL disponible globalmente
        # (plugin externo opcional `aecct2_itl_integration` — ver nota
        # de GAP-054 en los imports de este módulo sobre por qué ya no
        # hay un gate previo basado en el estado del motor interno)
        try:
            # Importar los perfiles y el motor del módulo ITL
            from aecct2_itl_integration import (
                TapePhysicsEngine as _TPE,
                PROFILE_C60 as _PC60,
                PROFILE_C90 as _PC90,
            )
            _prof = _PC60 if tape_type == _CassetteType_Enum.C60 else _PC90
            self._profile = _prof
            self._engine  = _TPE()
            self._engine.start(_prof, side="A")
            # Sin grabación activa inicial: reloj en pausa hasta step(PLAY)
            self._engine.update_audio(0.0, 0.0, recording=False, paused=False)
            self._itl_active = True
        except Exception as _e:
            _log_placeholder = logging.getLogger("aecct2.shim")
            _log_placeholder.warning("CassetteTransportPhysics shim: ITL no disponible (%s) — fallback.", _e)
            self._itl_active = False

        self._update_outputs(0.0, 0.0)

    def step(self, dt: float, mode) -> None:
        """
        Avanza la física un paso de dt segundos en el modo indicado.
        Delega en el motor ITL si está activo; si no, ejecuta física simplificada.
        """
        if self._tape_type is None or mode == _TransportMode_Enum.STOP:
            self._update_outputs(0.0, 0.0)
            return

        is_play = (mode == _TransportMode_Enum.PLAY)

        if self._itl_active and self._engine is not None:
            # ── Ruta ITL ─────────────────────────────────────────────────────
            # Informar al motor ITL del estado de reproducción.
            # El reloj del ITL avanza solo cuando recording=True y paused=False.
            # En este shim "grabando" equivale al modo PLAY (el motor gira).
            self._engine.update_audio(
                rms_lin=0.05,        # señal de presencia mínima (motor activo)
                peak_lin=0.05,
                recording=is_play,
                paused=not is_play,
            )
            snap = self._engine.get_snapshot()
            # Sincronizar posición local con el snapshot
            if self._side == _SideState_Enum.SIDE_A:
                self._position_cm = snap.current_tape_length_cm
            else:
                self._position_cm = self._side_a_length_cm + snap.current_tape_length_cm
            self._update_outputs_from_snapshot(snap)
        else:
            # ── Ruta fallback (sin ITL) ───────────────────────────────────────
            if mode == _TransportMode_Enum.PLAY:
                speed_cm_s = self.NOMINAL_SPEED_CM_S
            elif mode == _TransportMode_Enum.FF:
                speed_cm_s = self.NOMINAL_SPEED_CM_S * self.FF_REW_SPEED_MULTIPLIER
            elif mode == _TransportMode_Enum.REW:
                speed_cm_s = -self.NOMINAL_SPEED_CM_S * self.FF_REW_SPEED_MULTIPLIER
            else:
                speed_cm_s = 0.0

            dx           = speed_cm_s * dt
            new_position = self._position_cm + dx
            _auto        = _AutoStopState_Enum.NONE

            if speed_cm_s > 0:
                if (self._side == _SideState_Enum.SIDE_A
                        and new_position >= self._side_a_length_cm):
                    new_position = self._side_a_length_cm
                    _auto = _AutoStopState_Enum.END_OF_SIDE_A
                elif (self._side == _SideState_Enum.SIDE_B
                        and new_position >= self._total_length_cm):
                    new_position = self._total_length_cm
                    _auto = _AutoStopState_Enum.END_OF_TAPE
            elif speed_cm_s < 0:
                _limit = 0.0 if self._side == _SideState_Enum.SIDE_A else self._side_a_length_cm
                if new_position <= _limit:
                    new_position = _limit
                    _auto = (_AutoStopState_Enum.END_OF_SIDE_A
                             if self._side == _SideState_Enum.SIDE_B
                             else _AutoStopState_Enum.END_OF_TAPE)

            actual_dx = new_position - self._position_cm
            self._position_cm = new_position
            self._update_outputs(actual_dx, dt)
            self.outputs.auto_stop_state = _auto

    def flip_side(self) -> None:
        """Voltea el cassette al lado contrario."""
        if self._tape_type is None:
            return
        if self._side == _SideState_Enum.SIDE_A:
            self._side        = _SideState_Enum.SIDE_B
            self._position_cm = self._side_a_length_cm
        else:
            self._side        = _SideState_Enum.SIDE_A
            self._position_cm = 0.0

        if self._itl_active and self._engine is not None:
            self._engine.flip_to_side_b()

        self._update_outputs(0.0, 0.0)

    # ── Internos del shim ─────────────────────────────────────────────────────

    def _update_outputs_from_snapshot(self, snap) -> None:
        """Rellena outputs desde un TapeEngineSnapshot del ITL."""
        self.outputs.reel_rpm_left        = snap.reel_rpm_left
        self.outputs.reel_rpm_right       = snap.reel_rpm_right
        self.outputs.reel_radius_left_cm  = snap.reel_radius_left_cm
        self.outputs.reel_radius_right_cm = snap.reel_radius_right_cm
        self.outputs.tape_position_cm     = self._position_cm
        side_len = (self._side_a_length_cm if self._side == _SideState_Enum.SIDE_A
                    else self._total_length_cm - self._side_a_length_cm)
        self.outputs.elapsed_time_s   = snap.current_tape_length_cm  / self.NOMINAL_SPEED_CM_S
        self.outputs.remaining_time_s = snap.remaining_tape_length_cm / self.NOMINAL_SPEED_CM_S
        self.outputs.side_state       = self._side
        self.outputs.counter_value    = snap.counter_value / 999.0  # normalizado 0–1 para shim
        self.outputs.auto_stop_state  = _AutoStopState_Enum.NONE

    def _update_outputs(self, actual_dx: float, dt: float) -> None:
        """Física simplificada (fallback sin ITL). Radio dinámico exacto IEC."""
        if self._tape_type is None:
            return
        if self._side == _SideState_Enum.SIDE_A:
            side_len  = self._side_a_length_cm
            side_pos  = self._position_cm
        else:
            side_len  = self._total_length_cm - self._side_a_length_cm
            side_pos  = self._position_cm - self._side_a_length_cm

        area_consumed  = side_pos             * self._tape_thickness_cm
        area_remaining = (side_len - side_pos) * self._tape_thickness_cm
        r_right_sq = self.HUB_RADIUS_CM ** 2 + area_consumed  / _math.pi
        r_left_sq  = self.HUB_RADIUS_CM ** 2 + area_remaining / _math.pi
        radius_right = _math.sqrt(max(r_right_sq, self.HUB_RADIUS_CM ** 2))
        radius_left  = _math.sqrt(max(r_left_sq,  self.HUB_RADIUS_CM ** 2))

        if radius_right > 0:
            self._counter_revolutions += (abs(actual_dx) / radius_right) / (2 * _math.pi)

        rpm_right = rpm_left = 0.0
        if dt > 0 and abs(actual_dx) > 0:
            v = abs(actual_dx) / dt
            rpm_right = (v / radius_right) * (60.0 / (2 * _math.pi))
            rpm_left  = (v / radius_left)  * (60.0 / (2 * _math.pi))

        self.outputs.reel_radius_left_cm  = radius_left
        self.outputs.reel_radius_right_cm = radius_right
        self.outputs.reel_rpm_left        = rpm_left
        self.outputs.reel_rpm_right       = rpm_right
        self.outputs.tape_position_cm     = self._position_cm
        self.outputs.elapsed_time_s       = side_pos               / self.NOMINAL_SPEED_CM_S
        self.outputs.remaining_time_s     = (side_len - side_pos)  / self.NOMINAL_SPEED_CM_S
        self.outputs.side_state           = self._side
        self.outputs.counter_value        = self._counter_revolutions
        self.outputs.auto_stop_state      = _AutoStopState_Enum.NONE
