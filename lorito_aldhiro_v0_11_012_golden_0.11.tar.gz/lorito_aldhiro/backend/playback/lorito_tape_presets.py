from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Presets de tipo de cinta (Normal/CrO2/Metal) para el motor de física de cinta.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from dataclasses import dataclass, field
from typing import Optional, List, Callable, Dict, Any



# ─────────────────────────────────────────────────────────────────────────────
#  1. PRESETS DE CINTA — TapePreset
# ─────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class TapePreset:
    """
    Preset de normalización especializado por tipo de soporte analógico.

    Parámetros
    ──────────
    name                  — identificador del preset (clave en TAPE_PRESETS)
    display_name          — etiqueta legible para la GUI
    description           — descripción breve del tipo de cinta
    target_rms_db         — objetivo de RMS en dBFS (target para _norm_rms)
    target_lufs           — objetivo LUFS (usado si se activa LUFS normalization)
    hiss_tolerance_db     — umbral de ruido tolerado; si noise_floor > este
                            valor → activar noise-aware automáticamente
    min_crest_factor_db   — CF mínimo preservado (crest guard)
    ceiling_db            — techo máximo de peak en dBFS
    adaptive_block_sensitivity — factor de sensibilidad para normalización
                                 por bloques (1.0 = normal, >1 más agresivo)
    max_gain_db           — ganancia máxima aplicable (protección anti-hiss)
    prefer_rms            — True → priorizar RMS, False → priorizar LUFS
    note                  — notas técnicas para el reporte
    """
    name:                      str
    display_name:              str
    description:               str
    target_rms_db:             float
    target_lufs:               float
    hiss_tolerance_db:         float
    min_crest_factor_db:       float
    ceiling_db:                float
    adaptive_block_sensitivity:float
    max_gain_db:               float
    prefer_rms:                bool
    note:                      str = ""


# ── Catálogo de presets ───────────────────────────────────────────────────────

TAPE_PRESETS: Dict[str, TapePreset] = {

    "TYPE_I_FERRIC": TapePreset(
        name                      = "TYPE_I_FERRIC",
        display_name              = "Preset: Type I Ferric",
        description               = "Cassette Type I (ferric/FeO₂), C-60/C-90. "
                                    "Respuesta en frecuencia suave, ruido moderado.",
        target_rms_db             = -20.0,   # headroom amplio para preservar dinámica
        target_lufs               = -18.0,
        hiss_tolerance_db         = -48.0,   # ferric tiene hiss ~-50 dBFS; tolerancia -48
        min_crest_factor_db       = 10.0,    # preservar dinámica, CF típico ~12-14 dB
        ceiling_db                = -1.0,    # 1 dB headroom para evitar digital clipping
        adaptive_block_sensitivity= 0.8,     # menos agresivo — preservar carácter analógico
        max_gain_db               = 18.0,    # sin amplificación extrema del hiss
        prefer_rms                = True,
        note                      = "Tipo I ferric. Ruido típico -50 a -45 dBFS. "
                                    "Normalización RMS conservadora recomendada.",
    ),

    "TYPE_II_CHROME": TapePreset(
        name                      = "TYPE_II_CHROME",
        display_name              = "Preset: Type II Chrome",
        description               = "Cassette Type II (CrO₂/chrome), alta fidelidad. "
                                    "Mejor respuesta en altas frecuencias.",
        target_rms_db             = -18.0,   # chrome tiene mejor SNR → se puede subir
        target_lufs               = -16.0,
        hiss_tolerance_db         = -52.0,   # chrome tiene mejor SNR que ferric
        min_crest_factor_db       = 12.0,    # Type II preserva mejor los transientes
        ceiling_db                = -0.5,    # más headroom recuperable
        adaptive_block_sensitivity= 1.0,     # sensibilidad normal
        max_gain_db               = 22.0,
        prefer_rms                = True,
        note                      = "Tipo II CrO₂. SNR mejor ~3-6 dB que ferric. "
                                    "CF típico 14-18 dB en material musical.",
    ),

    "TYPE_IV_METAL": TapePreset(
        name                      = "TYPE_IV_METAL",
        display_name              = "Preset: Type IV Metal",
        description               = "Cassette Type IV (metal/metal-PES). "
                                    "Máxima fidelidad, mínimo ruido de cinta.",
        target_rms_db             = -16.0,   # metal admite más nivel sin saturación
        target_lufs               = -14.0,
        hiss_tolerance_db         = -58.0,   # metal tiene hiss muy bajo ~-60 dBFS
        min_crest_factor_db       = 14.0,    # excelente preservación de transientes
        ceiling_db                = -0.3,    # margen mínimo — metal es muy limpio
        adaptive_block_sensitivity= 1.2,     # levemente más agresivo — se puede
        max_gain_db               = 28.0,    # puede subir más sin penalizar hiss
        prefer_rms                = False,   # preferir LUFS para contenido musical
        note                      = "Tipo IV metal. SNR ~10 dB mejor que ferric. "
                                    "Rango dinámico excelente. LUFS preferido.",
    ),

    "VOICE_TAPE": TapePreset(
        name                      = "VOICE_TAPE",
        display_name              = "Preset: Voice/Dictaphone",
        description               = "Grabación de voz, dictáfono, notas. "
                                    "Dinámica limitada, inteligibilidad > fidelidad.",
        target_rms_db             = -14.0,   # voz clara, nivel alto para inteligibilidad
        target_lufs               = -16.0,
        hiss_tolerance_db         = -42.0,   # grabadoras de voz tienen más hiss
        min_crest_factor_db       = 6.0,     # voz tiene CF bajo ~6-10 dB
        ceiling_db                = -1.5,    # más headroom para evitar clips de consonantes
        adaptive_block_sensitivity= 1.5,     # más agresivo — silencio y explosivos alternados
        max_gain_db               = 24.0,
        prefer_rms                = True,
        note                      = "Voz/dictáfono. Silencio dominante entre frases → "
                                    "normalización adaptativa por bloques recomendada.",
    ),

    "RADIO_FM": TapePreset(
        name                      = "RADIO_FM",
        display_name              = "Preset: Radio FM Broadcast",
        description               = "Captura de emisora FM (tuner → cassette/digital). "
                                    "Material ya procesado con limitación y compresión.",
        target_rms_db             = -14.0,   # FM broadcast tiene RMS alto por loudness war
        target_lufs               = -16.0,
        hiss_tolerance_db         = -55.0,   # FM tiene buen SNR (stereo ~65 dB)
        min_crest_factor_db       = 4.0,     # FM ya viene comprimido, CF bajo ~4-8 dB
        ceiling_db                = -0.5,
        adaptive_block_sensitivity= 0.9,     # dinámicas relativamente uniformes
        max_gain_db               = 12.0,    # FM ya está alto → poco margen para subir
        prefer_rms                = False,   # preferir LUFS — material broadcast
        note                      = "FM broadcast. Material ya con loudness processing. "
                                    "Evitar recompresión agresiva. LUFS -16 objetivo.",
    ),

    "MICROCASSETTE": TapePreset(
        name                      = "MICROCASSETTE",
        display_name              = "Preset: Microcassette",
        description               = "Microcassette (MC-60/MC-90), grabadora portátil. "
                                    "Ancho de banda reducido, ruido elevado.",
        target_rms_db             = -16.0,   # compensar nivel bajo típico de microcassettes
        target_lufs               = -18.0,
        hiss_tolerance_db         = -38.0,   # microcassette tiene hiss prominente ~-40 dBFS
        min_crest_factor_db       = 6.0,
        ceiling_db                = -1.5,
        adaptive_block_sensitivity= 1.3,
        max_gain_db               = 20.0,    # limitar amplificación para no elevar hiss
        prefer_rms                = True,
        note                      = "Microcassette. Ancho de banda típico 100-6000 Hz. "
                                    "Hiss prominente — noise-aware activo con tolerancia baja.",
    ),

    "VHS_HIFI": TapePreset(
        name                      = "VHS_HIFI",
        display_name              = "Preset: VHS HiFi Audio",
        description               = "Pista HiFi de VHS (FM multiplex). "
                                    "Excelente fidelidad, ruido muy bajo, posible wow/flutter.",
        target_rms_db             = -18.0,
        target_lufs               = -16.0,
        hiss_tolerance_db         = -62.0,   # VHS HiFi tiene SNR ~90 dB
        min_crest_factor_db       = 14.0,    # VHS HiFi preserva transientes como PCM
        ceiling_db                = -0.3,
        adaptive_block_sensitivity= 1.0,
        max_gain_db               = 30.0,    # puede subir mucho sin penalizar ruido
        prefer_rms                = False,   # LUFS preferido — calidad broadcast
        note                      = "VHS HiFi FM. SNR ≈90 dB, THD bajo. "
                                    "Posible wow/flutter de mecanismo de cinta. "
                                    "Normalización LUFS recomendada.",
    ),

    "REEL_TRANSFER": TapePreset(
        name                      = "REEL_TRANSFER",
        display_name              = "Preset: Reel-to-Reel Transfer",
        description               = "Transferencia de carrete abierto (reel-to-reel). "
                                    "Formato archivístico, dinámica máxima, headroom amplio.",
        target_rms_db             = -22.0,   # headroom amplio para preservar picos originales
        target_lufs               = -20.0,
        hiss_tolerance_db         = -52.0,   # depende de la cinta y velocidad
        min_crest_factor_db       = 16.0,    # reel tiene la mejor dinámica analógica
        ceiling_db                = -2.0,    # headroom generoso — archivístico
        adaptive_block_sensitivity= 0.7,     # muy conservador — preservar todo
        max_gain_db               = 15.0,    # sin amplificación agresiva del archivo
        prefer_rms                = True,
        note                      = "Reel-to-reel. Formato archivístico. "
                                    "Priorizar preservación sobre loudness. "
                                    "Modo preservativo recomendado para masters valiosos.",
    ),
}

# Alias por nombre de display para poblar la GUI
TAPE_PRESET_BY_DISPLAY = {v.display_name: v for v in TAPE_PRESETS.values()}
