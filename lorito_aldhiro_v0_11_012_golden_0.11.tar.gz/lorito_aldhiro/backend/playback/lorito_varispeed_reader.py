from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Lector de velocidad variable con cursor ABSOLUTO (sin fronteras de chunk en la matemática).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

lorito_varispeed_reader.py — Orden Golden Scrubs Morpher / Velocista /
Seek (SMV-07, SMV-10, SMV-13; Fase 3).

Sustituye a `_resample_stateful` / `resample_stateful_continuous` en la
ruta de reproducción. Contrato matemático:

  · El cursor es una posición ABSOLUTA en frames de la fuente (float64),
    no un desplazamiento relativo a un chunk. No existe "frontera de
    chunk" en la interpolación: cada muestra de salida k se toma en
    `p_k`, con vecinos reales `i1-1 … i1+2` leídos del archivo (caché
    de lectura), acotados SOLO en los bordes reales del archivo.
  · Velocidad con signo: ratio > 0 avanza, < 0 retrocede. La reversa es
    continua a través de 0 (sin invertir bloques ni reiniciar fase).
  · Rampa de ratio DENTRO del bloque: de `r0` a `r1` linealmente
    (paso por muestra), de modo que un cambio de velocidad nunca produce
    salto de posición ni de pendiente de cursor (SMV-07).
  · ratio = 1 exacto con cursor entero ⇒ copia bit-exacta de la fuente
    (Catmull-Rom con mu = 0). No hay "zona neutra" que congele el cursor
    (SMV-13): con ratio 0,999 / 1,000 / 1,001 el cursor avanza siempre
    exactamente la suma de los ratios aplicados.

Corre en el hilo de render (no-RT). Buffers de trabajo preasignados
para el tamaño de bloque declarado.
"""

import numpy as np


def _adapt_channels(arr: np.ndarray, target_ch: int) -> np.ndarray:
    """Adapta el número de canales de arr a target_ch (mono↔estéreo)."""
    if arr.shape[1] == target_ch:
        return arr
    if target_ch == 1 and arr.shape[1] > 1:
        return arr[:, :1]
    if target_ch == 2 and arr.shape[1] == 1:
        return np.concatenate([arr, arr], axis=1)
    return arr


class VariableRateReader:
    """`source` expone `frames`, `seek(i)` y `read(n, dtype, always_2d)`
    (soundfile.SoundFile o equivalente)."""

    def __init__(self, source, channels: int, block: int = 512,
                 cache_frames: int = 65536, max_ratio: float = 4.0):
        self.src = source
        self.total = int(source.frames)
        self.channels = int(channels)
        self.block = int(block)
        self.max_ratio = float(max_ratio)
        if cache_frames < int(block * max_ratio) + 16:
            raise ValueError("cache_frames insuficiente para block × max_ratio")
        self.cache_frames = int(cache_frames)
        self._cache = np.zeros((self.cache_frames, self.channels), dtype=np.float32)
        self._c0 = 0
        self._cn = 0
        self.pos = 0.0
        self.disk_reads = 0
        # Buffers de trabajo preasignados (tamaño máximo de bloque).
        self._k = np.arange(1, self.block + 1, dtype=np.float64)
        self._steps = np.empty(self.block, dtype=np.float64)
        self._p = np.empty(self.block, dtype=np.float64)

    # ── Caché de fuente ──────────────────────────────────────────────────────
    def _ensure(self, lo: int, hi: int, forward: bool) -> None:
        lo = max(0, lo)
        hi = min(self.total - 1, hi)
        if self._cn and lo >= self._c0 and hi < self._c0 + self._cn:
            return
        span = self.cache_frames
        start = (lo - 8) if forward else (hi + 8 - span + 1)
        start = max(0, min(start, max(0, self.total - span)))
        self.src.seek(start)
        data = self.src.read(span, dtype="float32", always_2d=True)
        data = _adapt_channels(data, self.channels)
        n = int(data.shape[0])
        self._cache[:n] = data
        self._c0 = start
        self._cn = n
        self.disk_reads += 1

    def seek(self, frame: float) -> None:
        self.pos = float(max(0.0, min(float(max(self.total - 1, 0)), frame)))

    # ── Render ───────────────────────────────────────────────────────────────
    def render(self, out: np.ndarray, n: int, r0: float, r1: float):
        """Llena `out[:n]` muestreando desde `self.pos` con ratio que va de
        `r0` a `r1`. Devuelve `(n_valid, pos_start, pos_end)`; `n_valid < n`
        indica fin de archivo (adelante) o inicio (reversa): `out[n_valid:n]`
        queda en silencio y `self.pos` se detiene en el borde."""
        if n <= 0:
            return 0, self.pos, self.pos
        if n > self.block:
            raise ValueError("n mayor que el bloque declarado")
        pos0 = self.pos
        steps = self._steps[:n]
        np.multiply(self._k[:n], (r1 - r0) / n, out=steps)
        steps += r0
        p = self._p[:n]
        p[0] = pos0
        if n > 1:
            np.cumsum(steps[:-1], out=p[1:])
            p[1:] += pos0
        last = self.total - 1
        if last < 0:
            out[:n] = 0.0
            return 0, pos0, pos0
        invalid = (p < 0.0) | (p > last)
        if invalid.any():
            n_valid = int(np.argmax(invalid))
        else:
            n_valid = n
        if n_valid:
            pv = p[:n_valid]
            i1 = np.floor(pv).astype(np.int64)
            mu = pv - i1
            i0 = np.maximum(i1 - 1, 0)
            i2 = np.minimum(i1 + 1, last)
            i3 = np.minimum(i1 + 2, last)
            lo = int(i0.min())
            hi = int(i3.max())
            self._ensure(lo, hi, forward=(r0 + r1) >= 0)
            c = self._c0
            mu2 = mu * mu
            mu3 = mu2 * mu
            c0 = -0.5 * mu3 + mu2 - 0.5 * mu
            c1 = 1.5 * mu3 - 2.5 * mu2 + 1.0
            c2 = -1.5 * mu3 + 2.0 * mu2 + 0.5 * mu
            c3 = 0.5 * mu3 - 0.5 * mu2
            cache = self._cache
            for ch in range(self.channels):
                col = cache[:, ch]
                v = (c0 * col[i0 - c] + c1 * col[i1 - c]
                     + c2 * col[i2 - c] + c3 * col[i3 - c])
                np.clip(v, -1.0, 1.0, out=v)
                out[:n_valid, ch] = v
        if n_valid < n:
            out[n_valid:n] = 0.0
            self.pos = float(min(max(p[n_valid - 1] if n_valid else pos0, 0.0), last))
        else:
            self.pos = pos0 + float(steps.sum())
        return n_valid, pos0, self.pos
