"""
lorito_aldhiro.backend.rt — infraestructura de tiempo real sin locks.

Rama del árbol de módulos de Lorito Aldhiro (ver GAP-032): a partir de
esta sesión, el código nuevo se organiza en subpaquetes conectados por
`__init__.py`, no en ficheros sueltos dentro de `backend/`. Esta rama
agrupa las primitivas de concurrencia lock-free destinadas al path RT
del motor de captura (`CaptureEngineV2._audio_callback` y su drain
loop) — hoy construidas y verificadas de forma aislada, pendientes de
integración en una sesión con hardware de audio real (ver GAP-031).

Módulos:
  · lorito_ring_buffer_spsc — `LockFreeSPSCRingBuffer` (Fase 3).
"""

from lorito_aldhiro.backend.rt.lorito_ring_buffer_spsc import LockFreeSPSCRingBuffer

__all__ = ["LockFreeSPSCRingBuffer"]
