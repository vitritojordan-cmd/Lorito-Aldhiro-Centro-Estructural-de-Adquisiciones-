from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ring buffer SPSC sin locks (wait-free) — alternativa verificada a RingBufferAbsorcion.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_ring_buffer_spsc.py — Fase 3 de la Orden Maestra de Saneamiento
Pre-Auditoría Aldhira Phonographic: ring buffer RT SIN locks
(`threading.Condition`/`threading.Lock`), reemplazo propuesto para
`RingBufferAbsorcion` (`lorito_capture_engine.py`), que hoy toma un
lock en CADA `write()` desde `_audio_callback` — exactamente lo que la
orden pide eliminar.

Diseño — Single Producer Single Consumer (SPSC) por secuencia de slot:
  · UN SOLO hilo productor (el callback de audio) escribe.
  · UN SOLO hilo consumidor (el drain loop) lee.
  · `_write_seq` lo escribe ÚNICAMENTE el productor.
  · `_read_seq` lo escribe ÚNICAMENTE el consumidor.
  · Cada slot tiene su propio `_slot_seq[i]` — la generación (número de
    secuencia) del dato que contiene actualmente. El productor lo
    actualiza DESPUÉS de copiar los datos al slot (publica el dato
    antes de publicar su disponibilidad). El consumidor lo compara
    ANTES y DESPUÉS de leer los datos del slot (protocolo tipo
    seqlock) para detectar si el productor sobrescribió el slot
    a mitad de la lectura — si el número de secuencia cambió, la
    lectura se descarta como corrupta/obsoleta y se cuenta como
    overrun, nunca se devuelve un dato mezclado.

Diferencia deliberada de diseño frente a `RingBufferAbsorcion`: EN ESE
diseño, quien detecta y cuenta un overrun es el productor (sabe que
está a punto de sacrificar el slot más antiguo al escribir). EN ESTE
diseño, es el CONSUMIDOR quien lo detecta (al notar un salto en la
secuencia) — el productor nunca necesita saber ni coordinar nada sobre
el estado del lector, es completamente wait-free (nunca espera, nunca
toma un lock, nunca reintenta). Esto cumple más estrictamente el
requisito "el callback NUNCA bloquea" que el diseño con lock original
(que sí tomaba un lock, aunque fuera breve).

Verificación: en Python (CPython) el GIL serializa la ejecución de
bytecode entre hilos, así que una asignación simple a una variable de
un tipo inmutable (`self._write_seq = x`) es atómica en el sentido de
que ningún otro hilo puede observar un estado a medio escribir de ESA
asignación — la propiedad que este diseño necesita para ser correcto
sin locks. Verificado con hilos productor/consumidor REALES (no
simulados) en `tests/test_ring_buffer_spsc.py` — no requiere
`sounddevice` ni hardware de audio, es concurrencia genuina de Python.
"""

import threading
import time

import numpy as np


class LockFreeSPSCRingBuffer:
    """
    Uso:
        rb = LockFreeSPSCRingBuffer(n_slots=64, frames_max=4096, channels=2)
        # Hilo productor (p. ej. el callback de audio):
        rb.write(block)
        # Hilo consumidor (p. ej. el drain loop):
        block, n_frames = rb.read()   # o rb.read_batch(max_items=32)
    """

    def __init__(self, n_slots: int, frames_max: int, channels: int,
                 name: str = "RBA_SPSC"):
        self._name = name
        self._n = n_slots
        self._frames_max = frames_max
        self._channels = channels

        self._buf = np.zeros((n_slots, frames_max, channels), dtype=np.float32)
        self._frame_count = np.zeros(n_slots, dtype=np.int32)
        # -1 = slot nunca escrito. El productor escribe generaciones
        # 0, 1, 2, ... en el slot (gen % n_slots) según el índice.
        self._slot_seq = np.full(n_slots, -1, dtype=np.int64)

        self._write_seq = 0   # SOLO el productor lo escribe
        self._read_seq = 0    # SOLO el consumidor lo escribe

        # Contadores — cada uno escrito por UN SOLO lado (ver docstring
        # de cabecera: el consumidor detecta y cuenta los overruns).
        self._overrun_total = 0    # solo el consumidor
        self._underrun_total = 0   # solo el consumidor
        self._retry_total = 0      # solo el consumidor — lecturas que
                                    # se reintentaron por carrera detectada

        # Watermark — lo actualiza el productor en cada write() con una
        # estimación O(1) (no requiere leer read_seq bajo lock, es una
        # lectura de un int simple — atómica en CPython).
        self.watermark_pct = 0.0
        self._wm_hysteresis = 0.05
        self._wm_state = "LOW"

    # ── Escritura (path RT — WAIT-FREE, nunca bloquea, nunca espera) ────────

    def write(self, block: np.ndarray) -> bool:
        """Escribe un bloque en el siguiente slot. SIEMPRE retorna True
        — nunca bloquea, nunca falla; si el consumidor no ha leído lo
        bastante rápido, el dato más antiguo se sobrescribe (detectado
        y contado por el CONSUMIDOR en su próxima lectura, no aquí)."""
        n = block.shape[0]
        if n > self._frames_max:
            n = self._frames_max
            block = block[:n]

        seq = self._write_seq
        idx = seq % self._n

        # Invalidar el slot ANTES de escribir (rompe cualquier lectura
        # en curso de una generación vieja de este slot — el
        # consumidor lo detectará en su recheck y reintentará).
        self._slot_seq[idx] = -1
        self._buf[idx, :n] = block
        self._frame_count[idx] = n
        # Publicar: a partir de aquí el slot es válido para esta
        # generación. Esta asignación es la que "publica" el dato.
        self._slot_seq[idx] = seq

        self._write_seq = seq + 1

        # Watermark aproximado: ocupación = generaciones escritas menos
        # generaciones leídas, acotado a [0, n]. Lectura de _read_seq
        # por el productor es solo lectura (nunca escribe ahí) — segura.
        occ = min(max(self._write_seq - self._read_seq, 0), self._n)
        self.watermark_pct = occ / self._n if self._n else 0.0

        return True

    # ── Lectura (path del drain loop — único consumidor) ────────────────────

    def read(self):
        """Lee el siguiente bloque en orden. Devuelve (array, n_frames)
        o None si no hay dato nuevo todavía (buffer vacío para el
        consumidor, NO es un error)."""
        while True:
            seq = self._read_seq
            idx = seq % self._n

            s1 = self._slot_seq[idx]
            if s1 < seq:
                # El productor todavía no ha llegado a esta generación —
                # no hay dato nuevo (fin de stream momentáneo, normal).
                self._underrun_total += 1
                return None
            if s1 > seq:
                # El productor ya dio la vuelta y sobrescribió este slot
                # con una generación futura — los datos de `seq` se
                # perdieron. Saltar el lector a la generación más
                # antigua que el productor todavía no haya vuelto a
                # sobrescribir, y reintentar desde ahí.
                self._overrun_total += (s1 - seq)
                self._read_seq = s1
                continue

            # s1 == seq: el slot parece tener el dato correcto — copiarlo
            # y re-verificar que el productor no lo haya sobrescrito
            # DURANTE la copia (protocolo seqlock).
            n = int(self._frame_count[idx])
            data = self._buf[idx, :n].copy()
            s2 = self._slot_seq[idx]
            if s2 != s1:
                # Carrera real detectada: el productor completó un giro
                # completo del anillo mientras copiábamos (solo posible
                # con `n_slots` muy pequeño y un productor extremadamente
                # rápido) — descartar y reintentar, nunca devolver un
                # dato mezclado.
                self._retry_total += 1
                continue

            self._read_seq = seq + 1
            return data, n

    def read_batch(self, max_items: int = 64) -> list:
        """Lee hasta max_items bloques disponibles sin bloquear."""
        out = []
        while len(out) < max_items:
            item = self.read()
            if item is None:
                break
            out.append(item)
        return out

    # ── Watermark y estado (mismo esquema de histéresis que RingBufferAbsorcion) ──

    def get_watermark_state(self) -> str:
        wm = self.watermark_pct
        hy = self._wm_hysteresis
        prev = self._wm_state
        if prev == "CRITICAL":
            new = "CRITICAL" if wm > 0.85 - hy else "HIGH"
        elif prev == "HIGH":
            if wm > 0.85:
                new = "CRITICAL"
            elif wm < 0.30 + hy:
                new = "MEDIUM"
            else:
                new = "HIGH"
        elif prev == "MEDIUM":
            if wm > 0.60:
                new = "HIGH"
            elif wm < 0.10 + hy:
                new = "SAFE"
            else:
                new = "MEDIUM"
        else:
            new = "MEDIUM" if wm > 0.30 else "SAFE"
        self._wm_state = new
        return new

    @property
    def overrun_total(self) -> int:
        return self._overrun_total

    @property
    def underrun_total(self) -> int:
        return self._underrun_total

    @property
    def retry_total(self) -> int:
        return self._retry_total

    @property
    def occupancy_pct(self) -> float:
        return self.watermark_pct * 100.0
