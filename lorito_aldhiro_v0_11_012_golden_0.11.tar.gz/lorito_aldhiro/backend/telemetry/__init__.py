"""
lorito_aldhiro.backend.telemetry — Orden Golden de Instrumentación
visual, visor de onda, ITL, logs y duración de cinta
(LA-GOLDEN-UI-ITL-TELEM-001).

Rama del árbol de módulos sin dependencias de Qt: la UI OBSERVA estos
servicios (snapshots inmutables) y nunca es autoridad sobre frames,
duración efectiva ni integridad.

Módulos:
  · lorito_meter             — `CaptureMeter` (peak sample + RMS por canal en
    ventana de frames, dBFS con floor, peak-hold por tiempo, overs, calidad
    VALID/STALE/UNAVAILABLE) y `CaptureTelemetrySnapshot` inmutable.
  · lorito_waveform_envelope — envolventes min/max POR CANAL (en vivo y desde
    archivo), vista absoluta y vista normalizada separadas, memoria acotada.
  · lorito_timeline          — `TapeModel` (nominal / por lado / tolerancia) y
    `TimelineAuthority` (tiempo de audio desde frames, pared monotónica, pausas).
  · lorito_event_log         — `ForensicEventLog`: bitácora estructurada JSONL,
    cola acotada con prioridad no descartable para eventos P0.
"""

from lorito_aldhiro.backend.telemetry.lorito_meter import (
    CaptureMeter, MeterReading, CaptureTelemetrySnapshot, PeakHold,
)
from lorito_aldhiro.backend.telemetry.lorito_waveform_envelope import (
    LiveEnvelopeRing, compute_file_envelope,
)
from lorito_aldhiro.backend.telemetry.lorito_timeline import TapeModel, TimelineAuthority
from lorito_aldhiro.backend.telemetry.lorito_event_log import ForensicEventLog, get_process_event_log

__all__ = [
    "CaptureMeter", "MeterReading", "CaptureTelemetrySnapshot", "PeakHold",
    "LiveEnvelopeRing", "compute_file_envelope",
    "TapeModel", "TimelineAuthority", "ForensicEventLog", "get_process_event_log",
]
