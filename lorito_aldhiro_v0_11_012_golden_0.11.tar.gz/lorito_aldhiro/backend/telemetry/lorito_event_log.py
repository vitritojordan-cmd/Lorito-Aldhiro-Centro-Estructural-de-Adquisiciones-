from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Bitácora forense estructurada (JSONL) con cola acotada y eventos P0 no descartables.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_event_log.py — Orden Golden UI/ITL (LOG-01, LOG-02).

  · Esquema versionado (`lorito.event/1`): ts_utc, t_monotonic_ns,
    session_id, stage, severity, sequence, frame, prev_state, new_state,
    cause, data.
  · `emit()` NUNCA bloquea ni hace I/O: encola. Cola informativa ACOTADA
    (descarta y CUENTA); cola de prioridad para severidad ≥ ERROR / P0
    que no descarta (los fallos patrimoniales son raros; se reserva
    memoria para ellos). Los descartes informativos se registran como un
    evento agregado `LOG_DROPPED`.
  · Hilo escritor de baja prioridad: JSONL, rotación por tamaño, fsync
    tras cada evento P0. Errores de disco (ENOSPC/EIO): visibles en
    `write_errors`/`last_error`, la UI no se bloquea, los P0 se retienen
    en memoria y se reintentan.
  · El widget de estado es una VISTA: este log es el almacenamiento
    primario.
"""

import collections
import datetime
import json
import os
import threading
import time

SCHEMA = "lorito.event/1"
SEVERITIES = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL", "P0")
_PRIORITY = {"ERROR", "CRITICAL", "P0"}


class ForensicEventLog:
    def __init__(self, path: str, max_queue: int = 2048, max_bytes: int = 32 * 1024 * 1024,
                 keep_rotations: int = 3, session_id: str = ""):
        self.path = path
        self.max_queue = int(max_queue)
        self.max_bytes = int(max_bytes)
        self.keep_rotations = int(keep_rotations)
        self.session_id = session_id
        self._q = collections.deque()
        self._pq = collections.deque()
        self._cond = threading.Condition()
        self._seq = 0
        self.dropped_info = 0
        self._dropped_reported = 0
        self.written = 0
        self.write_errors = 0
        self.last_error = ""
        self._stop = False
        self._thread = None

    # ── Productores (cualquier hilo no-RT) ───────────────────────────────────
    def emit(self, stage: str, severity: str, cause: str, *, frame: int | None = None,
             prev_state: str | None = None, new_state: str | None = None,
             data: dict | None = None, session_id: str | None = None) -> int:
        sev = severity if severity in SEVERITIES else "INFO"
        with self._cond:
            self._seq += 1
            ev = {"schema": SCHEMA,
                  "ts_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "t_monotonic_ns": time.monotonic_ns(),
                  "session_id": session_id if session_id is not None else self.session_id,
                  "stage": stage, "severity": sev, "sequence": self._seq,
                  "frame": frame, "prev_state": prev_state, "new_state": new_state,
                  "cause": cause, "data": data or {}}
            if sev in _PRIORITY:
                self._pq.append(ev)
            elif len(self._q) >= self.max_queue:
                self.dropped_info += 1
            else:
                self._q.append(ev)
            self._cond.notify()
            return self._seq

    # ── Escritor ─────────────────────────────────────────────────────────────
    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop = False
        os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)
        self._thread = threading.Thread(target=self._loop, daemon=True, name="lorito-eventlog")
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> bool:
        with self._cond:
            self._stop = True
            self._cond.notify()
        t = self._thread
        if t is not None:
            t.join(timeout)
            return not t.is_alive()
        return True

    def flush(self, timeout: float = 5.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._cond:
                if not self._q and not self._pq:
                    return True
                self._cond.notify()
            time.sleep(0.01)
        return False

    @property
    def pending_priority(self) -> int:
        return len(self._pq)

    def _rotate_if_needed(self):
        try:
            if os.path.exists(self.path) and os.path.getsize(self.path) > self.max_bytes:
                for i in range(self.keep_rotations - 1, 0, -1):
                    a, b = f"{self.path}.{i}", f"{self.path}.{i + 1}"
                    if os.path.exists(a):
                        os.replace(a, b)
                os.replace(self.path, f"{self.path}.1")
        except OSError as e:
            self.write_errors += 1
            self.last_error = f"rotación: {e}"

    def _write(self, events, sync):
        self._rotate_if_needed()
        with open(self.path, "a", encoding="utf-8") as f:
            for ev in events:
                f.write(json.dumps(ev, ensure_ascii=False, default=str) + "\n")
            f.flush()
            if sync:
                os.fsync(f.fileno())

    def _loop(self):
        while True:
            with self._cond:
                while not self._q and not self._pq and not self._stop \
                        and self.dropped_info == self._dropped_reported:
                    self._cond.wait(0.5)
                pri = list(self._pq)
                info = list(self._q)
                self._q.clear()
                stop = self._stop
                drop_delta = self.dropped_info - self._dropped_reported
            if drop_delta:
                info.append({"schema": SCHEMA, "ts_utc": datetime.datetime.now(
                    datetime.timezone.utc).isoformat(), "t_monotonic_ns": time.monotonic_ns(),
                    "session_id": self.session_id, "stage": "eventlog", "severity": "WARNING",
                    "sequence": None, "frame": None, "prev_state": None, "new_state": None,
                    "cause": "LOG_DROPPED", "data": {"dropped_info_events": drop_delta}})
            try:
                if pri:
                    self._write(pri, sync=True)
                    with self._cond:
                        for _ in pri:
                            self._pq.popleft()
                    self.written += len(pri)
                if info:
                    self._write(info, sync=False)
                    self.written += len(info)
                self._dropped_reported += drop_delta
            except OSError as e:
                # Los P0 permanecen en `_pq` y se reintentan; los informativos
                # de este lote se pierden pero se CUENTAN.
                self.write_errors += 1
                self.last_error = f"{type(e).__name__}: {e}"
                self.dropped_info += len(info)
                time.sleep(0.2)
            if stop and not self._pq:
                return
            if stop and self.write_errors and self._pq:
                # Sin disco: no se cuelga el cierre; los P0 quedan en memoria
                # y visibles vía `pending_priority`.
                return


# ── Singleton de proceso (LOG-01) ────────────────────────────────────────────
# Una sola bitácora y un solo hilo escritor por proceso, por muchas ventanas
# que se instancien (p. ej. en la batería de pruebas).
_PROCESS_LOG = None
_PROCESS_LOG_LOCK = threading.Lock()


def get_process_event_log(path: str | None = None) -> ForensicEventLog:
    global _PROCESS_LOG
    with _PROCESS_LOG_LOCK:
        if _PROCESS_LOG is None:
            if path is None:
                from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR
                path = os.environ.get("LORITO_EVENT_LOG_PATH") or os.path.join(
                    ARCHIVE_DIR, "lorito_forensic_events.jsonl")
            _PROCESS_LOG = ForensicEventLog(path)
            _PROCESS_LOG.start()
        return _PROCESS_LOG
