from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Medidor de nivel por canal con ventana de frames y snapshot inmutable de telemetría.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_meter.py — Orden Golden UI/ITL (INST-01, INST-02, THREAD-01).

Contrato de medición declarado (no es un medidor VU/PPM normalizado ni
EBU R128; no se declara true peak):
  · Unidad: dBFS (0 dBFS = escala completa float ±1.0), floor −120 dBFS.
  · Peak: PEAK DE MUESTRA por canal sobre la ventana (no true peak).
  · RMS: raíz de la media cuadrática por canal sobre una ventana
    deslizante de `window_ms` (por defecto 300 ms) medida en FRAMES, no
    en ticks de GUI. La ventana se mantiene con sumas por bloque.
  · Peak-hold: por TIEMPO (monotónico): mantiene `hold_s` y cae a
    `decay_db_per_s` — independiente del jitter del temporizador de UI.
  · Overs: muestras con |x| ≥ `over_threshold` (0.999) contadas por canal.
  · Calidad: VALID si la última lectura tiene ≤ `stale_after_s`;
    STALE si es más vieja; UNAVAILABLE si nunca hubo dato. El cero
    nunca significa a la vez silencio, sensor caído y dato pendiente.

Productor: hilo de drenaje de captura (no-RT). Consumidor: GUI, que solo
lee el último `CaptureTelemetrySnapshot` publicado (referencia atómica a
un objeto inmutable).
"""

import math
import time
from collections import deque
from dataclasses import dataclass, field

import numpy as np

DBFS_FLOOR = -120.0
VALID, STALE, UNAVAILABLE = "VALID", "STALE", "UNAVAILABLE"


def to_dbfs(x: float) -> float:
    return DBFS_FLOOR if x <= 10 ** (DBFS_FLOOR / 20) else max(DBFS_FLOOR, 20 * math.log10(x))


@dataclass(frozen=True)
class MeterReading:
    channel: int
    peak_dbfs: float
    rms_dbfs: float
    peak_hold_dbfs: float
    overs: int
    unit: str = "dBFS"
    peak_kind: str = "SAMPLE_PEAK"
    window_ms: float = 300.0
    source: str = "CAPTURE_RAW"


@dataclass(frozen=True)
class CaptureTelemetrySnapshot:
    session_id: str
    frame_index: int
    sample_rate: int
    channels: int
    frames_committed: int
    elapsed_audio_s: float
    readings: tuple
    measured_at: float            # monotónico
    quality: str = VALID
    xruns: int = 0
    frames_lost: int = 0
    ring_pct: float = 0.0
    disk_pressure_pct: float = 0.0
    archival_hint: str = ""
    extra: dict = field(default_factory=dict)

    def age(self, now: float | None = None) -> float:
        return (time.monotonic() if now is None else now) - self.measured_at

    def quality_at(self, now: float | None = None, stale_after_s: float = 0.5) -> str:
        return STALE if self.age(now) > stale_after_s else self.quality


class PeakHold:
    """Peak-hold por tiempo (no por ticks)."""

    def __init__(self, hold_s: float = 1.5, decay_db_per_s: float = 20.0):
        self.hold_s = hold_s
        self.decay = decay_db_per_s
        self.value = DBFS_FLOOR
        self._peak = DBFS_FLOOR
        self._t = None

    def update(self, level_dbfs: float, now: float) -> float:
        """El valor mostrado es función cerrada de (pico retenido, instante
        de captura, ahora): idéntico con 1 tick o con 1000 entre medias."""
        if self._t is None or level_dbfs >= self._decayed(now):
            self._peak = level_dbfs
            self._t = now
            self.value = level_dbfs
            return self.value
        self.value = max(level_dbfs, self._decayed(now))
        return self.value

    def _decayed(self, now: float) -> float:
        if self._t is None:
            return DBFS_FLOOR
        return self._peak - self.decay * max(0.0, (now - self._t) - self.hold_s)


class CaptureMeter:
    def __init__(self, sample_rate: int = 48000, channels: int = 2, window_ms: float = 300.0,
                 hold_s: float = 1.5, decay_db_per_s: float = 20.0,
                 over_threshold: float = 0.999):
        self.configure(sample_rate, channels, window_ms, hold_s, decay_db_per_s, over_threshold)

    def configure(self, sample_rate, channels, window_ms=300.0, hold_s=1.5,
                  decay_db_per_s=20.0, over_threshold=0.999):
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.window_ms = float(window_ms)
        self.window_frames = max(1, int(self.sample_rate * self.window_ms / 1000.0))
        self.over_threshold = float(over_threshold)
        self._blocks = deque()           # (n, sumsq[ch], peak[ch])
        self._win_n = 0
        self._win_sumsq = np.zeros(self.channels, dtype=np.float64)
        self._holds = [PeakHold(hold_s, decay_db_per_s) for _ in range(self.channels)]
        self.overs = np.zeros(self.channels, dtype=np.int64)
        self.frames = 0
        self.last_snapshot = None

    def push(self, block: np.ndarray, now: float | None = None) -> None:
        """Acumula un bloque `[frames, channels]` (hilo de drenaje)."""
        if block.ndim == 1:
            block = block[:, np.newaxis]
        n = block.shape[0]
        if n == 0:
            return
        x = block.astype(np.float64, copy=False)
        sumsq = np.einsum("ij,ij->j", x, x)
        a = np.abs(block)
        peak = a.max(axis=0).astype(np.float64)
        self.overs += np.count_nonzero(a >= self.over_threshold, axis=0)
        self._blocks.append((n, sumsq, peak))
        self._win_n += n
        self._win_sumsq += sumsq
        while self._blocks and self._win_n - self._blocks[0][0] >= self.window_frames:
            on, osq, _ = self._blocks.popleft()
            self._win_n -= on
            self._win_sumsq -= osq
        self.frames += n

    def readings(self, now: float) -> tuple:
        if not self._blocks:
            return tuple()
        peak = np.max(np.stack([b[2] for b in self._blocks]), axis=0)
        rms = np.sqrt(np.maximum(self._win_sumsq, 0.0) / max(self._win_n, 1))
        out = []
        for ch in range(self.channels):
            pk = to_dbfs(float(peak[ch]))
            out.append(MeterReading(ch, pk, to_dbfs(float(rms[ch])),
                                    self._holds[ch].update(pk, now), int(self.overs[ch]),
                                    window_ms=self.window_ms))
        return tuple(out)
