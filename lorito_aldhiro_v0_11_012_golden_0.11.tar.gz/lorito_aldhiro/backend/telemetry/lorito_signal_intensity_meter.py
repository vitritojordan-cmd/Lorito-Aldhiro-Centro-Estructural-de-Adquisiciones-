from __future__ import annotations

"""
lorito_signal_intensity_meter.py — motor del Medidor de Intensidad de Señal
LCD (Orden de Ingeniería Golden "Medidor de Intensidad de Señal LCD",
0.11.012).

Flujo: fuente de audio → `SignalIntensityMeterEngine` → instantánea
inmutable (telemetría acotada) → `LCDSignalMeterWidget`.

CONTRATO DE MEDICIÓN (fase 1 de la orden)
─────────────────────────────────────────
Unidad y escala
  · dBFS con la convención AES17 / IEC 61606: un seno a escala completa
    lee 0 dBFS. El pico de muestra de ese seno es 1,0 → 0 dBFS; su RMS
    matemático es 1/√2, así que el RMS se informa con +3,01 dB para que
    el mismo seno también lea 0 dBFS en RMS.
  · Escala del medidor: de `DISPLAY_FLOOR_DBFS` (−60 dBFS) a 0 dBFS.
  · Silencio digital (bloque de ceros exactos): estado propio
    `silence=True`; su nivel matemático es −∞ dBFS y se informa como
    `None`, nunca como un número inventado.

Qué representa la altura de las barras
  · La ENVOLVENTE de intensidad por canal (cuasi-pico, estilo PPM), no
    frecuencias: no hay FFT.

Balística (respuesta temporal), en tiempo de AUDIO (frames), no de GUI
  · Ataque: integración de 10 ms al 90 % (`ATTACK_MS`), la cifra de los
    PPM DIN/IEC 60268-10 tipo I.
  · Liberación: 20 dB en 1,7 s (`RELEASE_DB_PER_S` ≈ 11,8 dB/s), la cifra
    del medidor de pico digital IEC 60268-18 (EBU).
  · Sin retención de máximos: no hay peak-hold.

Casos límite
  · Valores no finitos (NaN, ±∞): no se propagan; la muestra cuenta como
    0 y se acumula en `nonfinite_samples`.
  · Saturación: |x| ≥ `OVER_THRESHOLD` (0,999) cuenta como OVER y se
    marca `over` durante `OVER_SHOW_S` de audio. El máximo está definido:
    la envolvente nunca supera 0 dBFS.

Puntos de medición (documentados)
  · REC: bloques CRUDOS aceptados por el anillo de captura, en el hilo de
    drenaje (`CaptureEngine._on_raw_block`): la entrada efectiva del motor
    de captura, ANTES de cualquier DSP (Lorito graba RAW; los DSP no
    alteran lo capturado).
  · PLAY: cada bloque que el callback de salida CONSUME, tal como se
    entrega al driver: lo que se oye (incluye el resampleo del Velocista y
    del Morpher). La reproducción de Lorito no aplica DSP en tiempo real
    (los DSP actúan al exportar), así que activar un DSP no cambia la
    lectura. Las estadísticas (pico y RMS por canal) se calculan en el
    hilo de render al publicar el bloque y el hilo de supervisión de la
    reproducción las entrega al motor en el orden en que el callback las
    consumió.

Hilos y memoria
  · El motor NUNCA corre en el callback de audio: no hay locks, ni Qt, ni
    disco. Lo alimenta un hilo no-RT y publica `snapshot` por asignación
    de referencia (atómica en CPython) a un objeto inmutable: capacidad 1.
    Si la GUI se retrasa, solo se pierden instantáneas visuales; nunca
    muestras de audio.
  · Estado de tamaño fijo por canal: sin colas ni crecimiento de memoria.
"""

import math
import time
from dataclasses import dataclass

import numpy as np

DISPLAY_FLOOR_DBFS = -60.0
ATTACK_MS = 10.0
ATTACK_REACH = 0.90
RELEASE_DB = 20.0
RELEASE_S = 1.7
RELEASE_DB_PER_S = RELEASE_DB / RELEASE_S
OVER_THRESHOLD = 0.999
OVER_SHOW_S = 0.5
AES17_RMS_OFFSET_DB = 20.0 * math.log10(math.sqrt(2.0))   # +3,0103 dB
_TINY = 1e-12

SOURCE_REC = "REC"
SOURCE_PLAY = "PLAY"


def lin_to_dbfs(x: float) -> float | None:
    """Amplitud lineal → dBFS; None para cero exacto (−∞)."""
    if x <= 0.0:
        return None
    return 20.0 * math.log10(x)


@dataclass(frozen=True)
class MeterSnapshot:
    """Instantánea inmutable publicada por el motor (la GUI solo la lee)."""
    source: str
    seq: int                      # número de bloque procesado (monótono)
    channels: int
    envelope_dbfs: tuple          # envolvente por canal (dBFS; DISPLAY_FLOOR_DBFS como piso)
    peak_dbfs: tuple              # pico del último bloque (None = silencio digital)
    rms_dbfs: tuple               # RMS AES17 del último bloque (None = silencio digital)
    silence: tuple                # último bloque de ceros exactos, por canal
    over: tuple                   # saturación en los últimos OVER_SHOW_S de audio
    over_count: tuple             # muestras saturadas acumuladas por canal
    nonfinite_samples: int        # NaN/±∞ neutralizados (total)
    audio_time_s: float           # audio medido desde el último reset
    measured_at: float            # time.monotonic() de la publicación

    def age(self, now: float | None = None) -> float:
        return (time.monotonic() if now is None else now) - self.measured_at

    def level01(self, ch: int) -> float:
        """Altura normalizada 0..1 de la envolvente del canal `ch`."""
        db = self.envelope_dbfs[ch]
        return max(0.0, min(1.0, (db - DISPLAY_FLOOR_DBFS) / -DISPLAY_FLOOR_DBFS))


class SignalIntensityMeterEngine:
    """Envolvente de intensidad por canal con balística declarada."""

    def __init__(self, source: str, channels: int = 2, sample_rate: int = 48000) -> None:
        self.source = source
        self.channels = int(channels)
        self.sample_rate = int(sample_rate)
        self.snapshot: MeterSnapshot | None = None
        self.reset()

    # ── Estado ───────────────────────────────────────────────────────────
    def reset(self) -> None:
        """Nueva sesión (REC/PLAY): no se arrastra nada de la anterior."""
        n = self.channels
        self._env = np.full(n, DISPLAY_FLOOR_DBFS, dtype=np.float64)
        self._over_left = np.zeros(n, dtype=np.float64)
        self._over_count = np.zeros(n, dtype=np.int64)
        self._nonfinite = 0
        self._seq = 0
        self._audio_t = 0.0
        self.snapshot = None

    # ── Balística ────────────────────────────────────────────────────────
    @staticmethod
    def attack_coefficient(block_s: float) -> float:
        """Fracción del salto que la envolvente recorre en `block_s`: con
        τ tal que en ATTACK_MS se alcanza el 90 % del escalón."""
        tau = (ATTACK_MS / 1000.0) / -math.log(1.0 - ATTACK_REACH)
        return 1.0 - math.exp(-block_s / tau)

    def _advance(self, peaks_db: list, frames: int, rate: int) -> None:
        dt = frames / float(rate) if rate > 0 else 0.0
        k = self.attack_coefficient(dt) if dt > 0 else 1.0
        fall = RELEASE_DB_PER_S * dt
        for ch in range(self.channels):
            target = peaks_db[ch]
            target = DISPLAY_FLOOR_DBFS if target is None else max(DISPLAY_FLOOR_DBFS, min(0.0, target))
            env = self._env[ch]
            if target > env:
                env = env + (target - env) * k          # ataque
                if target - env < 1e-6:                 # llegada exacta (sin cola infinita)
                    env = target
            else:
                env = max(target, env - fall)           # liberación lineal en dB
            self._env[ch] = min(0.0, max(DISPLAY_FLOOR_DBFS, env))
            self._over_left[ch] = max(0.0, self._over_left[ch] - dt)
        self._audio_t += dt

    # ── Entradas ─────────────────────────────────────────────────────────
    def process_block(self, block, sample_rate: int | None = None) -> MeterSnapshot:
        """Bloque de muestras (frames × canales, o mono 1-D). Hilo no-RT."""
        rate = int(sample_rate or self.sample_rate)
        a = np.asarray(block)
        if a.ndim == 1:
            a = a.reshape(-1, 1)
        frames = int(a.shape[0])
        if frames == 0:
            return self.snapshot
        a = a.astype(np.float64, copy=False)
        finite = np.isfinite(a)
        if not finite.all():
            self._nonfinite += int(a.size - np.count_nonzero(finite))
            a = np.where(finite, a, 0.0)
        mag = np.abs(a)
        peaks, rmss, silences, overs = [], [], [], []
        for ch in range(self.channels):
            col = mag[:, min(ch, a.shape[1] - 1)]
            pk = float(col.max())
            ms = float(np.mean(col * col))
            n_over = int(np.count_nonzero(col >= OVER_THRESHOLD))
            peaks.append(min(1.0, pk))
            rmss.append(math.sqrt(ms))
            silences.append(pk == 0.0)
            overs.append(n_over)
        return self._commit(peaks, rmss, silences, overs, frames, rate)

    def process_block_stats(self, peaks, rmss, frames: int, sample_rate: int | None = None,
                            overs=None) -> MeterSnapshot:
        """Bloque ya reducido a pico y RMS lineales por canal (ruta PLAY:
        las estadísticas se calcularon en el hilo de render)."""
        rate = int(sample_rate or self.sample_rate)
        pk, rm, sil, ov = [], [], [], []
        for ch in range(self.channels):
            p = float(peaks[min(ch, len(peaks) - 1)])
            r = float(rmss[min(ch, len(rmss) - 1)])
            if not math.isfinite(p) or not math.isfinite(r):
                self._nonfinite += 1
                p = r = 0.0
            p, r = abs(p), abs(r)
            pk.append(min(1.0, p))
            rm.append(r)
            sil.append(p == 0.0)
            ov.append(int(overs[ch]) if overs is not None else int(p >= OVER_THRESHOLD))
        return self._commit(pk, rm, sil, ov, int(frames), rate)

    def _commit(self, peaks, rmss, silences, overs, frames, rate) -> MeterSnapshot:
        peaks_db = [lin_to_dbfs(p) for p in peaks]
        rms_db = [None if r <= 0.0 else min(AES17_RMS_OFFSET_DB, 20.0 * math.log10(max(r, _TINY))
                                            + AES17_RMS_OFFSET_DB) for r in rmss]
        for ch, n_over in enumerate(overs):
            if n_over:
                self._over_count[ch] += n_over
                self._over_left[ch] = OVER_SHOW_S
        self._advance(peaks_db, frames, rate)
        self._seq += 1
        snap = MeterSnapshot(
            source=self.source, seq=self._seq, channels=self.channels,
            envelope_dbfs=tuple(float(x) for x in self._env),
            peak_dbfs=tuple(peaks_db), rms_dbfs=tuple(rms_db),
            silence=tuple(silences),
            over=tuple(bool(x > 0.0) for x in self._over_left),
            over_count=tuple(int(x) for x in self._over_count),
            nonfinite_samples=self._nonfinite,
            audio_time_s=self._audio_t, measured_at=time.monotonic())
        self.snapshot = snap          # publicación: asignación atómica de referencia
        return snap
