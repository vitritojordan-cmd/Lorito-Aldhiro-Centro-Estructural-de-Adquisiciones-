from __future__ import annotations

"""
lorito_signal_meter_adapter.py — adaptador de telemetría del Medidor de
Intensidad de Señal LCD (0.11.012): elige la fuente según el transporte y
convierte la instantánea del motor en un cuadro de pantalla con un estado
definido. Sin Qt.

Estados (sección 5 de la orden)
  · REC     — mide la instantánea del motor de captura.
  · PLAY    — mide la instantánea del motor de reproducción.
  · SILENCE — REC o PLAY activos con silencio digital en todos los canales:
              se distingue de un transporte detenido o en pausa.
  · PAUSE   — grabación en pausa: barras al mínimo, sin lectura vieja.
  · STOP    — inactivo: barras al mínimo.
  · STALE   — la instantánea tiene más de `STALE_AFTER_S`: no se muestra
              una lectura antigua como si fuera actual (barras al mínimo).
  · WAITING — REC/PLAY recién iniciados, todavía sin instantánea.

Al cambiar de fuente (REC ↔ PLAY, o al iniciar una sesión) el cuadro lleva
`reset=True` para que el widget descarte el historial de la fuente
anterior, y solo se aceptan instantáneas de la fuente esperada.
"""

import time
from dataclasses import dataclass

from lorito_aldhiro.backend.telemetry.lorito_signal_intensity_meter import (
    MeterSnapshot, SOURCE_PLAY, SOURCE_REC,
)

STALE_AFTER_S = 0.5

REC, PLAY, SILENCE, PAUSE, STOP, STALE, WAITING = (
    "REC", "PLAY", "SILENCE", "PAUSE", "STOP", "STALE", "WAITING")

TRANSPORT_REC, TRANSPORT_PLAY, TRANSPORT_PAUSE, TRANSPORT_STOP = (
    "REC", "PLAY", "PAUSE", "STOP")


@dataclass(frozen=True)
class MeterDisplayFrame:
    state: str
    source: str | None
    channels: int
    levels: tuple            # 0..1 por canal (altura de las barras)
    over: tuple
    reset: bool = False      # descartar el historial (cambio de fuente/sesión)
    seq: int = 0


class SignalMeterTelemetryAdapter:

    def __init__(self, channels: int = 2) -> None:
        self.channels = channels
        self._source: str | None = None
        self._session_key = None

    def _floor(self, state: str, source, reset: bool) -> MeterDisplayFrame:
        n = self.channels
        return MeterDisplayFrame(state, source, n, (0.0,) * n, (False,) * n, reset)

    def frame(self, transport: str, rec_snap: MeterSnapshot | None,
              play_snap: MeterSnapshot | None, now: float | None = None,
              session_key=None) -> MeterDisplayFrame:
        """`transport`: REC / PLAY / PAUSE / STOP. `session_key` cambia con
        cada sesión nueva (p. ej. id de grabación o generación de
        reproducción) para no arrastrar telemetría de la anterior."""
        now = time.monotonic() if now is None else now
        source = {TRANSPORT_REC: SOURCE_REC, TRANSPORT_PLAY: SOURCE_PLAY}.get(transport)
        reset = (source != self._source) or (session_key != self._session_key)
        self._source, self._session_key = source, session_key
        if transport == TRANSPORT_PAUSE:
            return self._floor(PAUSE, None, reset)
        if source is None:
            return self._floor(STOP, None, reset)
        snap = rec_snap if source == SOURCE_REC else play_snap
        if snap is None or snap.source != source:
            return self._floor(WAITING, source, reset)
        if snap.age(now) > STALE_AFTER_S:
            return self._floor(STALE, source, reset)
        n = snap.channels
        levels = tuple(snap.level01(ch) for ch in range(n))
        state = SILENCE if all(snap.silence) and max(levels) == 0.0 else source
        return MeterDisplayFrame(state, source, n, levels, tuple(snap.over), reset, snap.seq)
