from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Autoridad temporal (frames) y modelo de duración de cinta con magnitudes separadas.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_timeline.py — Orden Golden UI/ITL (ITL-01, TAPE-01).

`TimelineAuthority`: la duración de AUDIO de la sesión sale de los frames
aceptados/confirmados por el motor de captura (FrameLedger). El reloj
monotónico mide tiempo de PARED (watchdog/latencia), nunca inventa
frames. Pausas, reanudaciones y discontinuidades son eventos explícitos.

`TapeModel`: magnitudes SEPARADAS y rotuladas —
  · nominal_total_s / nominal_side_s (C-60 = 2×30 min, C-90 = 2×45 min;
    duración NOMINAL de la etiqueta, no medida),
  · tolerance_s (la longitud física real de cinta varía; se declara la
    incertidumbre en vez de ocultarla),
  · audio_side_s (audio capturado en el lado actual, desde frames),
  · remaining_estimated_s ± tolerance_s (ESTIMADO).
"OTROS" no tiene duración nominal: sin automatismos de volteo/stop.
"""

import time
from dataclasses import dataclass

TAPE_PROFILES = {
    "C-60": 30 * 60.0,
    "C-90": 45 * 60.0,
    "C-120": 60 * 60.0,
}
TAPE_TOLERANCE_FRACTION = 0.03     # ±3 %: incertidumbre declarada de longitud real


@dataclass(frozen=True)
class TapeModel:
    profile: str

    @property
    def nominal_side_s(self):
        return TAPE_PROFILES.get(self.profile)

    @property
    def nominal_total_s(self):
        s = self.nominal_side_s
        return None if s is None else 2 * s

    @property
    def tolerance_s(self):
        s = self.nominal_side_s
        return None if s is None else s * TAPE_TOLERANCE_FRACTION

    @property
    def automatisms_allowed(self) -> bool:
        return self.nominal_side_s is not None

    def remaining_estimated_s(self, audio_side_s: float):
        s = self.nominal_side_s
        return None if s is None else max(0.0, s - audio_side_s)

    def describe(self, audio_side_s: float) -> dict:
        return {
            "profile": self.profile,
            "nominal_side_s": self.nominal_side_s,
            "nominal_total_s": self.nominal_total_s,
            "tolerance_s": self.tolerance_s,
            "audio_side_s": audio_side_s,
            "remaining_estimated_s": self.remaining_estimated_s(audio_side_s),
            "labels": {"nominal": "NOMINAL (etiqueta)", "audio": "AUDIO (frames)",
                       "remaining": "ESTIMADO ± tolerancia"},
        }


class TimelineAuthority:
    """Fuente única de tiempo de audio de la sesión (desde frames)."""

    def __init__(self, sample_rate: int = 48000):
        self.sample_rate = int(sample_rate)
        self._t0 = None
        self._events = []
        self._side_base_frames = 0

    def start(self, now: float | None = None):
        self._t0 = time.monotonic() if now is None else now
        self._events = [("START", 0, self._t0)]
        self._side_base_frames = 0

    def audio_seconds(self, frames_accepted: int) -> float:
        return frames_accepted / max(self.sample_rate, 1)

    def wall_seconds(self, now: float | None = None) -> float:
        if self._t0 is None:
            return 0.0
        return (time.monotonic() if now is None else now) - self._t0

    def mark(self, kind: str, frames: int, now: float | None = None):
        self._events.append((kind, int(frames), time.monotonic() if now is None else now))
        if kind == "FLIP_CONFIRMED":
            self._side_base_frames = int(frames)

    def side_audio_seconds(self, frames_accepted: int) -> float:
        return max(0, frames_accepted - self._side_base_frames) / max(self.sample_rate, 1)

    @property
    def events(self):
        return list(self._events)
