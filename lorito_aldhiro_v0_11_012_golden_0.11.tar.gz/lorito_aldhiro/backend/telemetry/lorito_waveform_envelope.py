from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Envolventes min/max por canal (en vivo y desde archivo) con memoria acotada.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_waveform_envelope.py — Orden Golden UI/ITL (WAVE-01, WAVE-02).

  · TODOS los canales: min/max por canal; la vista combinada usa el
    mínimo de mínimos y el máximo de máximos (ningún canal se omite ni se
    promedia implícitamente).
  · Vista ABSOLUTA (amplitud real, sin autonormalizar) separada de la
    vista NORMALIZADA estética (escala por el pico del conjunto).
  · Memoria acotada: en vivo, un anillo de `capacity` resúmenes por
    bloque (no audio); desde archivo, lectura por bloques con resúmenes
    por píxel (memoria O(ancho), no O(duración)).
  · Nunca es medidor de integridad ni de continuidad: es una vista.
"""

import wave

import numpy as np

ABSOLUTE, NORMALIZED = "ABSOLUTE", "NORMALIZED"


class LiveEnvelopeRing:
    """Productor: hilo de drenaje (`push`). Consumidor: GUI (`snapshot`).
    Memoria fija `capacity × channels × 2` floats."""

    def __init__(self, capacity: int = 2048, channels: int = 2):
        self.capacity = int(capacity)
        self.channels = int(channels)
        self._mn = np.zeros((self.capacity, self.channels), dtype=np.float32)
        self._mx = np.zeros((self.capacity, self.channels), dtype=np.float32)
        self._w = 0            # total de resúmenes publicados (solo productor)

    def push(self, block: np.ndarray) -> None:
        if block.ndim == 1:
            block = block[:, np.newaxis]
        if block.shape[0] == 0:
            return
        i = self._w % self.capacity
        self._mn[i] = block.min(axis=0)[:self.channels]
        self._mx[i] = block.max(axis=0)[:self.channels]
        self._w += 1               # publicación tras escribir

    def snapshot(self, last: int | None = None):
        """`(mn, mx)` con forma `[n, channels]`, orden temporal."""
        w = self._w
        n = min(w, self.capacity if last is None else min(last, self.capacity))
        if n == 0:
            z = np.zeros((0, self.channels), dtype=np.float32)
            return z, z.copy()
        idx = (np.arange(w - n, w) % self.capacity)
        return self._mn[idx].copy(), self._mx[idx].copy()


def reduce_columns(mn: np.ndarray, mx: np.ndarray, width: int):
    """Reduce `[n, ch]` a `[≤width, ch]` conservando extremos (min de mín.,
    max de máx.) — nunca diezmado por muestreo, que perdería transitorios."""
    n = mn.shape[0]
    if n <= width or width <= 0:
        return mn, mx
    step = n // width
    cut = step * width
    return (mn[:cut].reshape(width, step, -1).min(axis=1),
            mx[:cut].reshape(width, step, -1).max(axis=1))


def view(mn: np.ndarray, mx: np.ndarray, mode: str = NORMALIZED):
    """Envolvente combinada de todos los canales para pintar:
    `(mn_c, mx_c, scale, peak_abs)`. ABSOLUTE no reescala (scale=1)."""
    if mn.size == 0:
        z = np.zeros(0, dtype=np.float32)
        return z, z.copy(), 1.0, 0.0
    mn_c = mn.min(axis=1)
    mx_c = mx.max(axis=1)
    peak = float(max(np.max(np.abs(mn_c)), np.max(np.abs(mx_c))))
    scale = 1.0 if mode == ABSOLUTE else (1.0 / peak if peak > 1e-9 else 1.0)
    return (mn_c * scale).astype(np.float32), (mx_c * scale).astype(np.float32), scale, peak


def compute_file_envelope(path: str, width: int):
    """Envolvente por canal de un WAV PCM entero leído por bloques.
    Devuelve `(mn[width', ch], mx[width', ch], peak_abs, n_frames)`."""
    from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
        _pcm_bytes_to_float32,
    )
    with wave.open(path, "rb") as wf:
        total = wf.getnframes()
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        if total == 0:
            z = np.zeros((0, ch), dtype=np.float32)
            return z, z.copy(), 0.0, 0
        fpp = max(1, total // max(width, 1))
        n_cols = -(-total // fpp)
        mn = np.zeros((n_cols, ch), dtype=np.float32)
        mx = np.zeros((n_cols, ch), dtype=np.float32)
        col = 0
        remaining = total
        while remaining > 0:
            take = min(fpp * 256, remaining)
            data = _pcm_bytes_to_float32(wf.readframes(take), sw, ch)
            k = data.shape[0] // fpp
            if k:
                blk = data[:k * fpp].reshape(k, fpp, ch)
                mn[col:col + k] = blk.min(axis=1)
                mx[col:col + k] = blk.max(axis=1)
                col += k
            rem = data[k * fpp:]
            if rem.shape[0]:
                mn[col] = rem.min(axis=0)
                mx[col] = rem.max(axis=0)
                col += 1
            remaining -= take
    mn, mx = mn[:col], mx[:col]
    mn, mx = reduce_columns(mn, mx, width)
    peak = float(max(np.max(np.abs(mn)), np.max(np.abs(mx)))) if mn.size else 0.0
    return mn, mx, peak, total
