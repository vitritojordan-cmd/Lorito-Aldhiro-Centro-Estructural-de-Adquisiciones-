from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Métricas objetivas de discontinuidad (amplitud y pendiente) para señales patrón.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

lorito_discontinuity_metrics.py — Orden Golden Scrubs Morpher / Velocista
/ Seek (§7 Métricas obligatorias).

Para un tono sinusoidal de amplitud `a` y frecuencia `f` reproducido a
|ratio| ≤ `r_max`, la física acota:

    |x[n] − x[n−1]|           ≤ a · 2π f r_max / fs        (1.ª diferencia)
    |x[n] − 2x[n−1] + x[n−2]| ≤ a · (2π f r_max / fs)²    (2.ª diferencia)

Una muestra que supere la cota × `margin` es una DISCONTINUIDAD de
amplitud (salto) o de pendiente (quiebre de derivada). El margen absorbe
las rampas declaradas de las transiciones (p. ej. el DIP de medio coseno
añade a·π/(2·N) a la 1.ª diferencia). Las métricas son deterministas y
sirven igual para salida capturada por loopback real.
"""

import numpy as np


def sine_bounds(amp: float, freq: float, fs: int, r_max: float):
    w = 2 * np.pi * freq * r_max / fs
    return amp * w, amp * w * w


def discontinuity_report(y: np.ndarray, amp: float, freq: float, fs: int,
                         r_max: float, margin1: float = 1.15,
                         margin2: float = 4.0, skip_silence: bool = True,
                         bounds: tuple | None = None) -> dict:
    """`y` mono (o canal 0). Devuelve conteos y picos; con `skip_silence`
    se ignoran tramos de silencio exacto (underrun/fin declarados), que se
    contabilizan aparte."""
    y = np.asarray(y, dtype=np.float64)
    if y.ndim > 1:
        y = y[:, 0]
    b1, b2 = bounds if bounds is not None else sine_bounds(amp, freq, fs, r_max)
    d1 = np.abs(np.diff(y))
    d2 = np.abs(np.diff(y, 2))
    silent = (y == 0.0)
    mask1 = np.ones_like(d1, dtype=bool)
    mask2 = np.ones_like(d2, dtype=bool)
    if skip_silence:
        mask1 = ~(silent[1:] | silent[:-1])
        mask2 = ~(silent[2:] | silent[1:-1] | silent[:-2])
    amp_jumps = int(np.count_nonzero((d1 > b1 * margin1) & mask1))
    slope_jumps = int(np.count_nonzero((d2 > b2 * margin2) & mask2))
    return {
        "samples": int(y.size),
        "bound_d1": b1, "bound_d2": b2,
        "amplitude_discontinuities": amp_jumps,
        "slope_discontinuities": slope_jumps,
        "peak_d1": float(d1[mask1].max()) if mask1.any() else 0.0,
        "peak_d2": float(d2[mask2].max()) if mask2.any() else 0.0,
        "silent_samples": int(np.count_nonzero(silent)),
        "rms": float(np.sqrt(np.mean(y * y))) if y.size else 0.0,
    }


def impulse_clusters(y: np.ndarray, threshold: float = 0.3, min_gap: int = 64) -> int:
    """Cuenta impulsos (grupos de muestras > threshold separados al menos
    `min_gap`): detecta duplicación o desaparición de transitorios."""
    y = np.abs(np.asarray(y, dtype=np.float64))
    if y.ndim > 1:
        y = y[:, 0]
    idx = np.flatnonzero(y > threshold)
    if idx.size == 0:
        return 0
    return int(1 + np.count_nonzero(np.diff(idx) > min_gap))
