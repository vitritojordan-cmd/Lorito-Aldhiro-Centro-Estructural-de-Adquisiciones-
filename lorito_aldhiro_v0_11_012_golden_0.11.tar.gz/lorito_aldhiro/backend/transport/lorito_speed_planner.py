from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Planificador de velocidad de reproducción compartido por Morpher y Velocista.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_speed_planner.py — SpeedPlanner (§7, §11, §12, §13, FASE 1).

Única autoridad de ratio/dirección/aceleración/desaceleración/transición/
commit/retorno, compartida por Morpher y Velocista (§13 — "no deberán
existir dos algoritmos independientes"). Distingue tres magnitudes
(§11):

    desired_ratio  — lo que la UI pide (puede cambiar muchas veces por
                     segundo durante un drag).
    applied_ratio  — lo que el planificador ha decidido aplicar ahora
                     (avanza hacia desired_ratio con un paso acotado —
                     la "curva de transición" de §7, nunca un salto).
    rendered_ratio — lo que el motor de audio realmente ha reproducido
                     hasta el bloque más reciente (se actualiza desde
                     fuera, vía `report_rendered()`, cuando exista un
                     motor real conectado — en esta fase queda como
                     контrato, sin productor real todavía).

`update_desired()` implementa el coalescing de §12: llamadas repetidas
antes del siguiente `step()` simplemente sobreescriben `desired_ratio`,
sin generar trabajo ni comandos de transporte adicionales.
"""

from dataclasses import dataclass


@dataclass
class SpeedPlannerConfig:
    max_step_per_tick: float = 0.05   # §7 — paso máximo por tick (evita saltos)
    min_ratio: float = 0.05
    max_ratio: float = 4.0


class SpeedPlanner:
    def __init__(self, config: SpeedPlannerConfig | None = None,
                 initial_ratio: float = 1.0):
        self.config = config or SpeedPlannerConfig()
        self.desired_ratio: float = initial_ratio
        self.applied_ratio: float = initial_ratio
        self.rendered_ratio: float = initial_ratio

    # ── Entrada de UI (Morpher y Velocista llaman AMBOS a esto) ───────
    def update_desired(self, ratio: float) -> None:
        """§12 — coalescing: sobreescribe sin acumular trabajo. Si llegan
        1.10, 1.11, ..., 1.14 antes del próximo `step()`, solo sobrevive
        1.14."""
        clamped = max(self.config.min_ratio, min(self.config.max_ratio, ratio))
        self.desired_ratio = clamped

    # ── Avance de la curva de transición (§7) ─────────────────────────
    def step(self) -> float:
        """
        Avanza `applied_ratio` hacia `desired_ratio` sin saltos: nunca
        más de `max_step_per_tick` por llamada. Se garantiza continuidad
        entre `speed[n-1]` y `speed[n]` (§7) — para eso basta con que
        cada llamada parta del `applied_ratio` anterior, nunca de
        `desired_ratio` directamente.
        """
        delta = self.desired_ratio - self.applied_ratio
        step = self.config.max_step_per_tick
        if abs(delta) <= step:
            self.applied_ratio = self.desired_ratio
        else:
            self.applied_ratio += step if delta > 0 else -step
        return self.applied_ratio

    def is_settled(self) -> bool:
        return self.applied_ratio == self.desired_ratio

    # ── Realimentación del motor real (sin productor todavía en esta fase) ──
    def report_rendered(self, ratio: float) -> None:
        self.rendered_ratio = ratio

    def reset(self, ratio: float = 1.0) -> None:
        self.desired_ratio = ratio
        self.applied_ratio = ratio
        self.rendered_ratio = ratio
