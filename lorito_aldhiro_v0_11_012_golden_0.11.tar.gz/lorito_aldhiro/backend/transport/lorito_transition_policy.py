from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Política de transición POR OPERACIÓN de transporte, rampas precalculadas fuera del callback.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

lorito_transition_policy.py — Orden Golden Scrubs Morpher / Velocista /
Seek (SMV-02, SMV-03, SMV-04, SMV-09; Fase 4).

Ninguna operación comparte "a ciegas" un único crossfade:

  · SPEED_LIVE / SPEED_COMMIT / MORPHER / REVERSE → CONTINUOUS: no hay
    transición; el cursor absoluto y el estado del interpolador se
    conservan y el ratio se desliza (slew) muestra a muestra. No existe
    discontinuidad que tapar.
  · SEEK (no contiguo) → DIP por defecto: fundido de salida de la
    continuación antigua + fundido de entrada del destino, SIN mezclar
    audio no adyacente (continuidad técnica; preserva el contenido
    exacto a ambos lados). Opcionales y declarados como ARTÍSTICOS:
    XFADE_EQUAL_POWER (solo conserva potencia en señales NO
    correlacionadas) y XFADE_LINEAR (conserva amplitud en señales
    correlacionadas/idénticas). CUT: corte seco (permitido solo si se
    pide explícitamente).
  · EOF → FADE_OUT_END sobre los últimos frames válidos.
  · STOP → FADE_OUT_END de la continuación tras el audio ya encolado.

Rampas de medio coseno (derivada continua en los extremos) calculadas
UNA vez al construir la política; se aplican en el hilo de render, nunca
en el callback. Si no hay muestras suficientes, la transición se declara
DEGRADADA con su causa (nunca se presenta un fundido truncado como
transición completa — SMV-04). Ninguna política garantiza "cero pops":
la evidencia es la medición (POP_DISCONTINUITY_TEST_REPORT.md).
"""

from dataclasses import dataclass

import numpy as np

CONTINUOUS = "CONTINUOUS"
DIP = "DIP"
XFADE_EQUAL_POWER = "XFADE_EQUAL_POWER"
XFADE_LINEAR = "XFADE_LINEAR"
CUT = "CUT"
FADE_OUT_END = "FADE_OUT_END"

SEEK_POLICIES = (DIP, XFADE_EQUAL_POWER, XFADE_LINEAR, CUT)

OPERATION_POLICY = {
    "SPEED_LIVE": CONTINUOUS,
    "SPEED_COMMIT": CONTINUOUS,
    "MORPHER": CONTINUOUS,
    "REVERSE": CONTINUOUS,
    "SEEK": DIP,
    "EOF": FADE_OUT_END,
    "STOP": FADE_OUT_END,
}


@dataclass(frozen=True)
class TransitionRecord:
    operation: str
    kind: str
    frames_planned: int
    frames_applied: int
    degraded: bool
    reason: str = ""
    transport_generation: int = 0


def _half_cos_up(n: int) -> np.ndarray:
    if n <= 0:
        return np.zeros(0, dtype=np.float32)
    t = (np.arange(n, dtype=np.float64) + 0.5) / n
    return (0.5 - 0.5 * np.cos(np.pi * t)).astype(np.float32)


class TransitionPolicy:
    """Rampas preasignadas y aplicación in-place (hilo de render)."""

    def __init__(self, seek_policy: str = DIP, dip_out: int = 128, dip_in: int = 128,
                 xfade: int = 256, eof_fade: int = 64, stop_fade: int = 256):
        if seek_policy not in SEEK_POLICIES:
            raise ValueError(f"política de seek desconocida: {seek_policy}")
        self.seek_policy = seek_policy
        self.dip_out = int(dip_out)
        self.dip_in = int(dip_in)
        self.xfade = int(xfade)
        self.eof_fade = int(eof_fade)
        self.stop_fade = int(stop_fade)
        self._up = {n: _half_cos_up(n) for n in {self.dip_out, self.dip_in, self.xfade,
                                                 self.eof_fade, self.stop_fade}}
        self._down = {n: r[::-1].copy() for n, r in self._up.items()}
        t = (np.arange(self.xfade, dtype=np.float64) + 0.5) / max(self.xfade, 1)
        self._ep_in = np.sin(0.5 * np.pi * t).astype(np.float32)
        self._ep_out = np.cos(0.5 * np.pi * t).astype(np.float32)
        self._lin_in = t.astype(np.float32)
        self._lin_out = (1.0 - t).astype(np.float32)

    def ramp_up(self, n: int) -> np.ndarray:
        return self._up[n]

    def ramp_down(self, n: int) -> np.ndarray:
        return self._down[n]

    def fade_out_tail(self, buf: np.ndarray, n_valid: int, fade: int):
        """Fundido de salida sobre los últimos `fade` frames válidos.
        Devuelve (frames_aplicados, degradado)."""
        if n_valid <= 0:
            return 0, False
        m = min(fade, n_valid)
        ramp = self._down[fade] if m == fade else _half_cos_up(m)[::-1]
        buf[n_valid - m:n_valid] *= ramp[:, None]
        return m, m < fade

    def crossfade(self, old: np.ndarray, new: np.ndarray, n: int, kind: str) -> None:
        """`new[:n] = old[:n]*out + new[:n]*in` (n ≤ xfade), in-place."""
        if kind == XFADE_EQUAL_POWER:
            ri, ro = self._ep_in, self._ep_out
        else:
            ri, ro = self._lin_in, self._lin_out
        if n < self.xfade:
            # Ventana truncada: rampa reescalada y DECLARADA como degradada
            # por el llamador.
            t = (np.arange(n, dtype=np.float64) + 0.5) / max(n, 1)
            if kind == XFADE_EQUAL_POWER:
                ri = np.sin(0.5 * np.pi * t).astype(np.float32)
                ro = np.cos(0.5 * np.pi * t).astype(np.float32)
            else:
                ri = t.astype(np.float32)
                ro = (1.0 - t).astype(np.float32)
        new[:n] *= ri[:n, None]
        new[:n] += old[:n] * ro[:n, None]
