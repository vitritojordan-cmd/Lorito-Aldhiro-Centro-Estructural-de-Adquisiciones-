from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Comandos del transporte (play/seek/stop/velocidad) como datos inmutables.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_transport_commands.py — comandos de transporte (§6, §11, FASE 1).

El Morpher y el Velocista SOLO pueden producir instancias de
`TransportCommand`. Ninguno de los dos puede limpiar buffers, reiniciar
streams, modificar `head_pos`/`src_pos` directamente, insertar muestras,
ni ejecutar flush físico — esas operaciones no existen en esta interfaz
en absoluto, así que un widget que solo conoce `TransportCommand` no
puede violarlas ni por error (§6: "el objetivo no es que el sistema
falle menos, es que ciertas clases de fallo dejen de ser representables
por la arquitectura").
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from lorito_aldhiro.backend.transport.lorito_transport_state import Direction


class CommandKind(Enum):
    PLAY               = auto()
    STOP               = auto()
    SEEK               = auto()
    SET_DIRECTION      = auto()
    SET_TARGET_SPEED   = auto()   # §6, §11 — usado tanto por Velocista como Morpher
    COMMIT_SPEED       = auto()
    BEGIN_MORPH        = auto()
    END_MORPH          = auto()
    CANCEL_MORPH       = auto()
    SEEK_DONE          = auto()   # emitido internamente por el motor, no por UI


@dataclass(frozen=True)
class TransportCommand:
    kind: CommandKind
    frame: Optional[int] = None          # SEEK / SET_POSITION
    direction: Optional[Direction] = None  # SET_DIRECTION / PLAY
    ratio: Optional[float] = None         # SET_TARGET_SPEED

    @staticmethod
    def play(direction: Direction = Direction.FORWARD) -> "TransportCommand":
        return TransportCommand(CommandKind.PLAY, direction=direction)

    @staticmethod
    def stop() -> "TransportCommand":
        return TransportCommand(CommandKind.STOP)

    @staticmethod
    def seek(frame: int) -> "TransportCommand":
        return TransportCommand(CommandKind.SEEK, frame=frame)

    @staticmethod
    def set_direction(direction: Direction) -> "TransportCommand":
        return TransportCommand(CommandKind.SET_DIRECTION, direction=direction)

    @staticmethod
    def set_target_speed(ratio: float) -> "TransportCommand":
        return TransportCommand(CommandKind.SET_TARGET_SPEED, ratio=ratio)

    @staticmethod
    def commit_speed() -> "TransportCommand":
        return TransportCommand(CommandKind.COMMIT_SPEED)

    @staticmethod
    def begin_morph() -> "TransportCommand":
        return TransportCommand(CommandKind.BEGIN_MORPH)

    @staticmethod
    def end_morph() -> "TransportCommand":
        return TransportCommand(CommandKind.END_MORPH)

    @staticmethod
    def cancel_morph() -> "TransportCommand":
        return TransportCommand(CommandKind.CANCEL_MORPH)
