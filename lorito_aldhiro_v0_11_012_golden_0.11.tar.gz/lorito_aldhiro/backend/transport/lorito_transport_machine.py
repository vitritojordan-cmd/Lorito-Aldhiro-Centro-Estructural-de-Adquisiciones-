from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Máquina de estados del transporte — coordina reproducción, scrub y generación de bloques válidos.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_transport_machine.py — máquina de estados de transporte (§4) +
Generational Transport (§5), FASE 1.

Las transiciones están centralizadas en `_TRANSITIONS`: ningún widget
modifica `TransportState` directamente (§4 — "no deberá permitirse que
cada widget modifique directamente variables internas del motor"). Todo
pasa por `TransportMachine.apply(command)`.

Cada cambio ESTRUCTURAL (transición de modo real, no un no-op) incrementa
`transport_generation` (§5). El consumidor real (futuro: el callback RT
de `PlaybackEngine`, en una sesión posterior) debe marcar cada bloque
generado con `transport_generation` y descartar en el callback cualquier
bloque cuya generación no coincida con la actual — este módulo expone
`GenerationGuard` como esa comprobación, ya verificable de forma
aislada sin tocar el callback real todavía.
"""

from dataclasses import dataclass

from lorito_aldhiro.backend.transport.lorito_transport_state import (
    TransportState, TransportMode, Direction,
)
from lorito_aldhiro.backend.transport.lorito_transport_commands import (
    TransportCommand, CommandKind,
)
# GAP-051 (FASE 1 de la Orden de Saneamiento, Integración y
# Consolidación, §15): `InvalidTransitionError` era un `RuntimeError`
# suelto. Se consolida bajo `LoritoError` — mismo nombre, mismo
# constructor de un único string, mismo comportamiento externo (sigue
# siendo un `RuntimeError` capturable por cualquier `except
# RuntimeError` legado). No se reclasifica en ninguna de las 7
# categorías de política (`RecoverableError`/`FatalError`/etc.):
# hoy nada en el proyecto captura ni recupera de este error — decidir
# si un comando inválido debería ser recuperable es una decisión de
# política de UI pendiente, no tomada unilateralmente aquí.
from lorito_aldhiro.backend.errors import LoritoError

M = TransportMode


class InvalidTransitionError(LoritoError):
    """§4: un comando no válido para el modo actual nunca se aplica
    en silencio — se rechaza explícitamente."""
    pass


def _seeking_mode_for(direction: Direction) -> TransportMode:
    return M.SEEKING_FORWARD if direction == Direction.FORWARD else M.SEEKING_REVERSE


def _play_mode_for(direction: Direction) -> TransportMode:
    return M.PLAY_FORWARD if direction == Direction.FORWARD else M.PLAY_REVERSE


# Modos "activos" desde los que Seek/dirección/velocidad/Morpher son válidos.
_ACTIVE_MODES = {
    M.PLAY_FORWARD, M.PLAY_REVERSE,
    M.SEEKING_FORWARD, M.SEEKING_REVERSE,
    M.SPEED_LIVE, M.SPEED_COMMIT,
    M.MORPHER_LIVE, M.MORPHER_RETURN,
}


class TransportMachine:
    def __init__(self, state: TransportState | None = None):
        self.state = state or TransportState()
        # Modo activo antes de entrar a un desvío temporal (Seek/Speed/
        # Morpher) — permite volver a PLAY_FORWARD/PLAY_REVERSE según
        # corresponda en vez de asumir siempre FORWARD.
        self._resume_mode: TransportMode = M.PLAY_FORWARD

    # ── Entrada única de comandos ─────────────────────────────────────
    def apply(self, cmd: TransportCommand) -> TransportState:
        handler = getattr(self, f"_h_{cmd.kind.name.lower()}", None)
        if handler is None:
            raise InvalidTransitionError(f"comando desconocido: {cmd.kind}")
        handler(cmd)
        return self.state.snapshot()

    def _bump_generation(self) -> None:
        self.state.transport_generation += 1

    def _require_mode(self, cmd: TransportCommand, *allowed: TransportMode) -> None:
        if self.state.mode not in allowed:
            raise InvalidTransitionError(
                f"{cmd.kind.name} no es válido en modo {self.state.mode.name} "
                f"(válido en: {[m.name for m in allowed]})")

    # ── Handlers — uno por CommandKind, según el diagrama de §4 ───────
    def _h_play(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, M.IDLE, M.STOPPING, M.EOF)
        direction = cmd.direction or Direction.FORWARD
        self.state.direction = direction
        self.state.mode = _play_mode_for(direction)
        self.state.playback_generation += 1
        self._bump_generation()

    def _h_stop(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, *_ACTIVE_MODES)
        self.state.mode = M.STOPPING
        self._bump_generation()

    def _h_seek(self, cmd: TransportCommand) -> None:
        # §9/§10 — Seek es válido en cualquier modo activo, incluida reversa;
        # la dirección NO cambia solo porque llegue un Seek (§10: "Seek
        # hacia N durante reversa" mantiene direction=REVERSE).
        self._require_mode(cmd, *_ACTIVE_MODES)
        if cmd.frame is None:
            raise InvalidTransitionError("SEEK requiere 'frame'")
        self._resume_mode = _play_mode_for(self.state.direction)
        self.state.requested_frame = cmd.frame
        self.state.source_frame = cmd.frame
        self.state.mode = _seeking_mode_for(self.state.direction)
        self._bump_generation()

    def _h_seek_done(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, M.SEEKING_FORWARD, M.SEEKING_REVERSE)
        self.state.head_frame = self.state.source_frame
        self.state.mode = self._resume_mode
        # SEEK_DONE es una confirmación interna, no un cambio estructural
        # nuevo — no bumpea generación de nuevo (ya se bumpeó en SEEK).

    def _h_set_direction(self, cmd: TransportCommand) -> None:
        # §9 — cambio de dirección como operación de transporte de
        # primera clase, nunca "leer adelante e invertir".
        self._require_mode(cmd, *_ACTIVE_MODES)
        if cmd.direction is None:
            raise InvalidTransitionError("SET_DIRECTION requiere 'direction'")
        self.state.direction = cmd.direction
        self.state.mode = _play_mode_for(cmd.direction)
        self._bump_generation()

    def _h_set_target_speed(self, cmd: TransportCommand) -> None:
        # §11/§13 — usado tanto por Velocista como por Morpher a través
        # del mismo SpeedPlanner (ver lorito_speed_planner.py).
        self._require_mode(cmd, *_ACTIVE_MODES)
        if cmd.ratio is None:
            raise InvalidTransitionError("SET_TARGET_SPEED requiere 'ratio'")
        if self.state.mode not in (M.SPEED_LIVE, M.MORPHER_LIVE):
            self._resume_mode = _play_mode_for(self.state.direction)
            self.state.mode = M.SPEED_LIVE
            self._bump_generation()
        self.state.target_speed = cmd.ratio
        # target_speed en vivo NO bumpea generación por sí solo (§12:
        # coalescing — muchos SET_TARGET_SPEED intermedios deben poder
        # colapsarse sin flush/generación nueva por cada uno).

    def _h_commit_speed(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, M.SPEED_LIVE)
        self.state.speed_ratio = self.state.target_speed
        self.state.mode = M.SPEED_COMMIT
        self._bump_generation()
        self.state.mode = self._resume_mode

    def _h_begin_morph(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, *_ACTIVE_MODES)
        self._resume_mode = _play_mode_for(self.state.direction)
        self.state.mode = M.MORPHER_LIVE
        self._bump_generation()

    def _h_end_morph(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, M.MORPHER_LIVE)
        self.state.mode = M.MORPHER_RETURN
        self._bump_generation()

    def _h_cancel_morph(self, cmd: TransportCommand) -> None:
        self._require_mode(cmd, M.MORPHER_LIVE, M.MORPHER_RETURN)
        self.state.speed_ratio = 1.0
        self.state.target_speed = 1.0
        self.state.mode = self._resume_mode
        self._bump_generation()


@dataclass(frozen=True)
class TaggedBlock:
    """Un bloque de audio con la generación de transporte que le
    corresponde (§5) — el productor (prefetch) lo etiqueta al crearlo."""
    generation: int
    payload: object


class GenerationGuard:
    """
    §5 — descarta silenciosamente cualquier bloque cuya generación no
    coincida con la generación actual del transporte, ANTES de que
    llegue al dispositivo de audio.
    """

    def __init__(self, machine: TransportMachine):
        self._machine = machine

    def accept(self, block: TaggedBlock) -> bool:
        return block.generation == self._machine.state.transport_generation
