from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Estado inmutable del transporte en un instante dado.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_transport_state.py — TransportState (§3 de la Orden Maestra de
Refundación, FASE 1: Contratos).

Sustituye la ambigüedad actual de `PlaybackEngine` (`src_pos` como única
variable de posición, `_SpeedState.head_pos`/`snap_pos` con significados
parcialmente solapados — ver GAP-002 §2/§3) por cuatro magnitudes con
significado inequívoco, tal como exige §3:

    requested_frame — posición solicitada por el usuario (último Seek).
    source_frame    — posición desde la que el motor debe obtener material.
    head_frame      — posición de la cabeza virtual (avanza con la lectura).
    rendered_frame  — última posición cuyo audio fue efectivamente
                       entregado al dispositivo (avanza con el callback RT).

Este módulo NO toca `PlaybackEngine` — es un contrato nuevo, aislado y
verificable, para que Fases 2+ lo adopten en una sesión futura (mismo
criterio de máxima cautela que bloqueó tocar el motor de reproducción
real en esta sesión sin poder ejercitar audio real).
"""

from dataclasses import dataclass, field
from enum import Enum, auto


class Direction(Enum):
    FORWARD = auto()
    REVERSE = auto()


class TransportMode(Enum):
    """§4 — estados mínimos de la máquina de estados de transporte."""
    IDLE              = auto()
    PLAY_FORWARD      = auto()
    PLAY_REVERSE      = auto()
    SEEKING_FORWARD   = auto()
    SEEKING_REVERSE   = auto()
    SPEED_LIVE        = auto()
    SPEED_COMMIT      = auto()
    MORPHER_LIVE      = auto()
    MORPHER_RETURN    = auto()
    STOPPING          = auto()
    EOF               = auto()
    ERROR             = auto()


@dataclass
class TransportState:
    """
    §3 — representación única y formal del estado del transporte.
    Nunca se debe reintroducir una única variable ambigua como sustituto
    de `requested_frame`/`source_frame`/`head_frame`/`rendered_frame`.
    """
    mode: TransportMode = TransportMode.IDLE
    direction: Direction = Direction.FORWARD

    requested_frame: int = 0
    source_frame: int = 0
    head_frame: int = 0
    rendered_frame: int = 0

    speed_ratio: float = 1.0
    target_speed: float = 1.0

    # §5 — Generational Transport
    playback_generation: int = 0     # incrementa en cada play/stop (sesión)
    transport_generation: int = 0    # incrementa en CADA cambio estructural
                                      # (Seek / dirección / velocidad / Morpher)

    def snapshot(self) -> "TransportState":
        """Copia inmutable de conveniencia para pasar a otro hilo sin
        exponer la instancia mutable compartida."""
        return TransportState(
            mode=self.mode, direction=self.direction,
            requested_frame=self.requested_frame,
            source_frame=self.source_frame,
            head_frame=self.head_frame,
            rendered_frame=self.rendered_frame,
            speed_ratio=self.speed_ratio, target_speed=self.target_speed,
            playback_generation=self.playback_generation,
            transport_generation=self.transport_generation,
        )
