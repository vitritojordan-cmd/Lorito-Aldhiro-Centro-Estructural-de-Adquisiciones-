#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Integración del flujo ITL con la ventana principal.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_itl_integration.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Etapa ITL — Unidad Monolítica CLCC integrada en LoritoAldhiroStudio
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Versión : 2.0.0  (CLCC-ITL Monolith — SIVC eliminado)
Integrado en: Lorito Aldhiro (bifurcación de CRAC 0.22.57 — ver GAP-001)
Propietario original: Carola Records Aldhira Capture (C.R.A.C)

PROPÓSITO
─────────
Este módulo reemplaza completamente la arquitectura ITL+SIVC anterior.
ITL es ahora el ÚNICO orquestador responsable de:

  · Control lógico de transporte de cinta (volteo Lado A → Lado B)
  · Control del cuentavueltas físico no-lineal (IEC 60581-6)
  · Pausas automáticas por silencio (SIPA integrado)
  · Pausas forzadas por tope de tolerancia MMCI
  · Auto-stop al final del Lado B
  · Sincronización exclusiva con el reloj maestro de la interfaz (15 Hz)

Los módulos sivc_sensor_c_60.py y sivc_sensor_c_90.py han sido
eliminados del sistema. ITL absorbe toda su funcionalidad.

ARQUITECTURA DE RELOJES (CLCC-ITL)
────────────────────────────────────
  Reloj Maestro  — tiempo real aportado por _gui_tick() a 15 Hz.
                   Es el ÚNICO origen del tiempo. ITL no tiene hilo propio.
                   Avanza solo cuando recording=True AND paused=False.

  elapsed_time   — segundos totales de cinta grabados (Lado A + Lado B
                   de forma acumulada para evaluar umbrales MMCI totales).

  external_clock — segundos grabados desde el inicio de la sesión, solo
                   avanza durante captura activa (no pausa). Alimenta el
                   cuentavueltas físico (counter).

  side_elapsed   — segundos del lado activo para el counter (A = 0..∞,
                   B = external_clock - counter_base).

CONTRATO DE INTERFAZ CON EL STUDIO
────────────────────────────────────
  Atributos leídos por el studio (compatibilidad directa con la API SIVC):
    _sensor.counter   — cuentavueltas int (0..999+)
    _sensor.lock      — threading.Lock para acceso thread-safe
    _sensor.side      — "A" o "B"
    _sensor.profile   — "C-60" o "C-90"

  Métodos públicos del ITLBridge:
    integrate_itl_into_studio(studio)  →  ITLBridge | None
    bridge._gui_tick(rms_lin, peak_lin, recording, paused)
    bridge.on_start_recording(profile)
    bridge.on_stop_recording()
    bridge.on_flip_side_b()   (volteo manual desde GUI)
"""
from __future__ import annotations

import logging
import math
import threading
import time
from typing import Optional, Callable

try:
    from PySide6.QtCore import QTimer
    _QTimer = QTimer
except ImportError:
    try:
        from PyQt6.QtCore import QTimer
        _QTimer = QTimer
    except ImportError:
        _QTimer = None

_log = logging.getLogger("aecct2.itl_integration")

# ── Umbral de silencio CRAC (idéntico a SILENCE_REF_CEILING_DBFS) ──────────
# -61.46 dBFS  →  10^(-61.46/20) ≈ 8.454e-4 lineal  (umbral PEAK del SIPA)
_SILENCE_THRESHOLD_DBFS: float = -61.46

# ── Frecuencia del reloj maestro de la interfaz ─────────────────────────────
_MASTER_HZ:  float = 15.0
_MASTER_DT:  float = 1.0 / _MASTER_HZ   # ≈ 0.06667 s  (≈ 67 ms)

# ── FIX-FORCED-PAUSE-ESCAPE (integración Lorito Aldhiro) ───────────────────
# Bug histórico auditado contra CRAC (ver GAP-007/GAP-008): con un umbral
# fijo de 1.0s, una pausa forzada por tope de tolerancia MMCI solo podía
# conmutar a pausa ordinaria tras un segundo COMPLETO de silencio continuo
# — cualquier ruido breve dentro de esa ventana reiniciaba silence_timer a
# 0.0 y el volteo a Lado B nunca se desbloqueaba ("nunca se podía voltear
# a Lado B"). CRAC resolvió la misma clase de bug bajando su constante
# equivalente, SILENCE_GUARD_ESCAPE_SECS, de 1.0 a 0.0 (FIX-FORCED-PAUSE-
# ESCAPE, ya heredado nativamente en el resto de Lorito Aldhiro — ver
# lorito_constants.py). Este módulo (CLCC-ITL Monolith 2.0.0) es una
# reescritura independiente que NO heredó ese fix: seguía comparando
# silence_timer contra el literal `1.0` en sus tres puntos de conmutación
# forzada. Aquí se usa _MASTER_DT en vez de 0.0 literal porque
# silence_timer se resetea a 0.0 en cada tick NO silencioso (a diferencia
# de CRAC, donde el bloque equivalente solo se evalúa ya dentro de una
# rama confirmada como silenciosa) — con _MASTER_DT, el primer tick
# silencioso real (~67ms) ya satisface la conmutación, igual que el fix
# de CRAC, sin disparar en falso sobre un tick recién reseteado a 0.0.
_FORCED_PAUSE_ESCAPE_SECS: float = _MASTER_DT

# Orden Golden UI/ITL (ITL-03): antigüedad máxima de una lectura del sensor
# de nivel. Una lectura más vieja es STALE: no cuenta como silencio ni como
# señal (el cronómetro se congela), nunca se interpreta como dato actual.
_SENSOR_MAX_AGE_S: float = 0.5

# ── Parámetros físicos IEC 60581-6 del cuentavueltas ────────────────────────
# C-60: a 30 min → counter = 450   (D = 0.0018, target_nominal = 450)
# C-90: a 45 min → counter = 675   (D = 0.0012, target_nominal = 675)
_R_MIN: float = 1.10   # radio mínimo del hub (cm)
_V_TAPE: float = 4.76  # velocidad estándar IEC (cm/s)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  MOTOR CLCC MONOLÍTICO
#  Contiene toda la física de cinta, lógica MMCI, SIPA y estado FSM.
#  Es thread-safe: todas las escrituras ocurren bajo self.lock.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class _CLCCEngine:
    """
    Motor monolítico de control lógico de cassette.
    Reemplaza completamente a SIVCSensorController (SIVC).

    Parámetros de instancia expuestos al studio:
      .lock     — threading.Lock
      .counter  — int  (cuentavueltas, 0..999+)
      .side     — str  "A" | "B"
      .profile  — str  "C-60" | "C-90"
    """

    def __init__(self, profile: str = "C-60") -> None:
        self.profile  = profile
        self.lock     = threading.Lock()

        self.configure_profile(profile)

        # ── Relojes ───────────────────────────────────────────────────────────
        self.elapsed_time    = 0.0   # tiempo total grabado (A+B acumulado)
        self.external_clock  = 0.0   # reloj externo del cuentavueltas
        self.counter_base    = 0.0   # referencia externa al inicio Lado B
        self.counter         = 0     # cuentavueltas int (leído por el studio)

        # ── Estado FSM ────────────────────────────────────────────────────────
        self.side              = "A"
        self.is_recording      = False
        self.is_paused         = False
        self.is_forced_pause   = False      # pausa forzada por tope MMCI
        self.paused_by_silence = False      # pausa automática por silencio
        self.is_stopped        = False

        # ── SIPA integrado ────────────────────────────────────────────────────
        self.silence_timer         = 0.0    # cronómetro continuo de silencio
        self.signal_strength_db    = -50.0  # nivel peak recibido (dBFS)
        self.silence_threshold_db  = _SILENCE_THRESHOLD_DBFS

        # ── Desborde del cuentavueltas ────────────────────────────────────────
        self.tape_overflow_warning = False
        self.overflow_excess_secs  = 0.0

        # ── Callbacks (inyectados por ITLBridge) ──────────────────────────────
        self.on_pause_toggle_callback: Optional[Callable] = None
        self.on_flip_side_b_callback:  Optional[Callable] = None
        self.on_auto_stop_callback:    Optional[Callable] = None

        # Callback de pausa pendiente (disparado FUERA del lock en tick())
        self._pending_pause_cb: Optional[tuple] = None

        # ── Orden Golden UI/ITL (ITL-01/02/03) ───────────────────────────────
        # Autoridad temporal: segundos de AUDIO capturado (frames aceptados
        # por el motor de captura), no ticks de GUI. `_last_audio_s` es la
        # última lectura aplicada; el avance se calcula por diferencia.
        self._last_audio_s: Optional[float] = None
        self.time_source = "TICKS"            # "AUDIO_FRAMES" cuando el bridge lo provee
        # SIPA: cronómetro por timestamps monotónicos reales.
        self._sensor_t: Optional[float] = None
        self._sensor_sample_t: Optional[float] = None
        self.sensor_stale_events = 0
        # Flip/stop exactamente una vez por sesión, comandos idempotentes.
        self.flip_done = False
        self.stop_issued = False
        self.duplicate_flip_requests = 0
        self.duplicate_stop_requests = 0
        # Callbacks diferidos (siempre disparados FUERA del lock).
        self._deferred: list = []

        _log.info("CLCC-ITL: motor inicializado — perfil=%s", profile)

    def configure_profile(self, profile: str) -> None:
        """Orden Golden UI/ITL (TAPE-01): fija umbrales MMCI y cuentavueltas
        según el perfil. Solo C-60/C-90 tienen longitud nominal; cualquier
        otro perfil (OTROS) es modo libre: el reloj avanza pero NO hay
        automatismos (pausa, volteo ni stop)."""
        self.profile = profile
        self.automatisms_enabled = profile in ("C-60", "C-90")
        prof = profile if profile == "C-60" else "C-90"
        # ── Umbrales temporales MMCI (s) ──────────────────────────────────────
        if prof == "C-60":
            self.lado_a_nom_secs  = 30 * 60   # 30:00 min
            self.lado_a_ini_tol   = 28 * 60   # ventana inicio Lado A
            self.lado_a_max_tol   = 33 * 60   # tope máximo Lado A
            self.lado_b_ini_tol   = 58 * 60   # ventana inicio Lado B (acumulado)
            self.lado_b_max_tol   = 63 * 60   # tope máximo Lado B (acumulado)
        else:  # C-90
            self.lado_a_nom_secs  = 45 * 60
            self.lado_a_ini_tol   = 43 * 60
            self.lado_a_max_tol   = 48 * 60
            self.lado_b_ini_tol   = 87 * 60
            self.lado_b_max_tol   = 92 * 60

        # ── Parámetros del cuentavueltas físico ──────────────────────────────
        if prof == "C-60":
            self._ctr_D       = 0.0018
            self._ctr_target  = 450
        else:
            self._ctr_D       = 0.0012
            self._ctr_target  = 675

        self._ctr_R_max = math.sqrt(
            _R_MIN * _R_MIN
            + (_V_TAPE * self._ctr_D / math.pi) * self.lado_a_nom_secs
        )


    # ─────────────────────────────────────────────────────────────────────────
    #  CONTROL DE SESIÓN
    # ─────────────────────────────────────────────────────────────────────────

    def start_recording(self) -> None:
        with self.lock:
            if self.is_recording:
                return
            self.is_recording      = True
            self.is_paused         = False
            self.is_forced_pause   = False
            self.paused_by_silence = False
            self.is_stopped        = False
            self.tape_overflow_warning = False
            self.overflow_excess_secs  = 0.0
            self.flip_done   = False
            self.stop_issued = False
            self._last_audio_s = None
            self._sensor_t = None
            self._sensor_sample_t = None
            _log.info("CLCC-ITL [%s]: captura iniciada — relojes sincronizados con reloj maestro",
                      self.profile)

    def stop_recording(self, reason: str = "manual") -> None:
        with self.lock:
            self.is_recording  = False
            self.is_paused     = False
            self.is_stopped    = True
            _log.info("CLCC-ITL [%s]: captura finalizada. Motivo: %s  elapsed=%.1fs",
                      self.profile, reason, self.elapsed_time)

    # ─────────────────────────────────────────────────────────────────────────
    #  ACTUALIZACIÓN DE AUDIO (llamado desde _gui_tick, GUI thread, 15 Hz)
    # ─────────────────────────────────────────────────────────────────────────

    def update_audio_sensor(self, signal_db: float, now: Optional[float] = None,
                            sample_time: Optional[float] = None) -> None:
        """
        Actualiza el nivel de señal y el cronómetro de silencio (SIPA).

        Orden Golden UI/ITL (ITL-03): el cronómetro avanza por TIEMPO REAL
        transcurrido entre lecturas (`now`, reloj monotónico), no por un
        `_MASTER_DT` fijo por tick. Si la lectura del sensor tiene más de
        `_SENSOR_MAX_AGE_S` (`now - sample_time`), es STALE: el cronómetro
        se congela (ni avanza ni se reinicia) y se cuenta el evento. Sin
        `now` (llamadas heredadas/tests) se conserva el paso fijo anterior.
        """
        with self.lock:
            self.signal_strength_db = signal_db
            is_silent = signal_db <= self.silence_threshold_db
            if now is None:
                step = _MASTER_DT
            else:
                prev = self._sensor_t
                self._sensor_t = now
                step = 0.0 if prev is None else max(0.0, min(now - prev, 1.0))
                if sample_time is not None and (now - sample_time) > _SENSOR_MAX_AGE_S:
                    self.sensor_stale_events += 1
                    return
            if self.is_recording and not self.is_paused:
                self.silence_timer = (self.silence_timer + step) if is_silent else 0.0
            elif self.is_recording and self.is_forced_pause:
                self.silence_timer = (self.silence_timer + step) if is_silent else 0.0

    # ─────────────────────────────────────────────────────────────────────────
    #  TICK — Avance del reloj y evaluación de automatismos
    #  Sincronizado directamente con el reloj maestro (dt = _MASTER_DT)
    # ─────────────────────────────────────────────────────────────────────────

    def tick(self, dt: float = _MASTER_DT, audio_seconds: Optional[float] = None) -> None:
        """
        Avanza los relojes y evalúa todos los automatismos CLCC.
        Llamado a 15 Hz exclusivamente desde ITLBridge._gui_tick().

        El tick SOLO avanza los relojes cuando:
          is_recording = True  AND  is_paused = False

        Garantía de sincronía: el reloj maestro de la interfaz es el ÚNICO
        origen del tiempo — no hay hilo propio, no hay drift acumulado.
        """
        _fire_cb = None
        with self.lock:
            self._pending_pause_cb = None

            if not self.is_recording or self.is_stopped:
                return

            # ── Avanzar relojes ──────────────────────────────────────────────
            # Orden Golden UI/ITL (ITL-01): con `audio_seconds` (segundos de
            # audio realmente capturado según el FrameLedger) el reloj de
            # cinta avanza EXACTAMENTE lo que se grabó: inmune al jitter, a
            # ticks perdidos o a una GUI congelada, y nulo durante pausas
            # (el motor no acepta frames). Sin él, paso fijo heredado.
            if audio_seconds is not None:
                self.time_source = "AUDIO_FRAMES"
                if self._last_audio_s is None or audio_seconds < self._last_audio_s:
                    self._last_audio_s = audio_seconds
                adv = audio_seconds - self._last_audio_s
                self._last_audio_s = audio_seconds
                if adv > 0:
                    self.elapsed_time   += adv
                    self.external_clock += adv
                    self._update_counter_internal()
            elif not self.is_paused:
                self.elapsed_time   += dt
                self.external_clock += dt
                self._update_counter_internal()

            # ── Evaluar automatismos MMCI + SIPA ─────────────────────────────
            # (TAPE-01: un perfil sin longitud nominal —OTROS— nunca dispara
            # pausa, volteo ni stop automáticos.)
            if self.is_recording and self.automatisms_enabled:
                elapsed = self.elapsed_time

                # ── LADO A ───────────────────────────────────────────────────
                if self.side == "A":
                    if self.lado_a_ini_tol <= elapsed < self.lado_a_max_tol:
                        # Zona de tolerancia Lado A
                        if not self.is_paused:
                            if self.silence_timer >= 3.0:
                                self._activate_autopause_silence()
                        else:
                            if self.paused_by_silence and \
                                    self.signal_strength_db > self.silence_threshold_db:
                                self._execute_auto_flip()

                    elif elapsed >= self.lado_a_max_tol:
                        # Tope máximo Lado A
                        if not self.is_paused:
                            self._activate_forced_pause()
                        elif self.is_forced_pause:
                            # FIX-FORCED-PAUSE-ESCAPE: primer tick silencioso
                            # real (_FORCED_PAUSE_ESCAPE_SECS ≈ 67ms) basta
                            # para conmutar — antes exigía 1s completo (bug).
                            if self.silence_timer >= _FORCED_PAUSE_ESCAPE_SECS:
                                self._commute_forced_to_autopause()
                        elif self.paused_by_silence:
                            if self.signal_strength_db > self.silence_threshold_db:
                                self._execute_auto_flip()

                # ── LADO B ───────────────────────────────────────────────────
                elif self.side == "B":
                    if self.lado_b_ini_tol <= elapsed < self.lado_b_max_tol:
                        # Zona de tolerancia Lado B
                        if not self.is_paused:
                            if self.silence_timer >= 3.0:
                                self._execute_auto_stop("silence_threshold_reached")
                        elif self.is_forced_pause:
                            # FIX-FORCED-PAUSE-ESCAPE (ver constante arriba)
                            if self.silence_timer >= _FORCED_PAUSE_ESCAPE_SECS:
                                self._execute_auto_stop("silence_forced_pause_lado_b")
                        elif self.paused_by_silence:
                            if self.signal_strength_db > self.silence_threshold_db:
                                self._execute_auto_stop("silence_cleared_lado_b")

                    elif elapsed >= self.lado_b_max_tol:
                        # Tope absoluto Lado B
                        if not self.is_paused:
                            self._execute_auto_stop("max_tolerance_reached_lado_b")
                        elif self.is_forced_pause:
                            # FIX-FORCED-PAUSE-ESCAPE (ver constante arriba)
                            if self.silence_timer >= _FORCED_PAUSE_ESCAPE_SECS:
                                self._execute_auto_stop("silence_max_tolerance_lado_b")
                        elif self.paused_by_silence:
                            if self.signal_strength_db > self.silence_threshold_db:
                                self._execute_auto_stop("silence_cleared_forced_lado_b")

            _fire_cb = self._pending_pause_cb
            self._pending_pause_cb = None
            _deferred = self._deferred
            self._deferred = []

        # ── Orden Golden UI/ITL (ITL-02): volteo/stop FUERA del lock ─────────
        # (antes el autostop se disparaba con el lock tomado y su callback
        # → stop_all() → on_stop_recording() → stop_recording() volvía a
        # pedir el MISMO threading.Lock: interbloqueo del hilo de GUI).
        for _cb, _args in _deferred:
            try:
                _cb(*_args)
            except Exception as _exc:
                _log.error("CLCC-ITL: callback diferido falló: %s", _exc)

        # ── Disparar callback FUERA del lock ─────────────────────────────────
        if _fire_cb is not None:
            cb, reason = _fire_cb
            if reason == "silence":
                _log.info("CLCC-ITL [%s]: pausa automática activada (3 s silencio)", self.profile)
            elif reason == "forced_limit_lado_a":
                _log.info("CLCC-ITL [%s]: pausa forzada — tope máximo Lado A", self.profile)
            else:
                _log.info("CLCC-ITL [%s]: pausa forzada — %s", self.profile, reason)
            if cb is not None:
                cb(True, reason=reason)

    # ─────────────────────────────────────────────────────────────────────────
    #  CUENTAVUELTAS FÍSICO (Mecánica No-Lineal IEC 60581-6)
    # ─────────────────────────────────────────────────────────────────────────

    def _update_counter_internal(self) -> None:
        """
        Actualiza self.counter basado en external_clock.
        Llamado bajo self.lock desde tick().

        Física:
          R(t) = sqrt(R_min² + (v·D/π)·t)
          counter(t) = target_nominal × (R(t) - R_min) / (R_max - R_min)

        C-60: a 30 min → counter = 450
        C-90: a 45 min → counter = 675

        FIX-COUNTER-NO-WRAP: el contador NO hace % 1000. Si supera el nominal,
        continúa avanzando libremente (el panel TapeLogPanel lo muestra sin truncar).
        """
        side_elapsed = (self.external_clock if self.side == "A"
                        else max(0.0, self.external_clock - self.counter_base))

        R_current = math.sqrt(
            _R_MIN * _R_MIN
            + (_V_TAPE * self._ctr_D / math.pi) * side_elapsed
        )
        raw = self._ctr_target * (R_current - _R_MIN) / max(self._ctr_R_max - _R_MIN, 1e-12)
        self.counter = math.floor(raw) if raw >= 0 else 0

        # ── Desborde de cuentavueltas ─────────────────────────────────────────
        if self.automatisms_enabled and side_elapsed >= self.lado_a_nom_secs:
            self.overflow_excess_secs = side_elapsed - self.lado_a_nom_secs
            if not self.tape_overflow_warning:
                self.tape_overflow_warning = True
                _log.warning("CLCC-ITL [%s]: ⚠️ TU CINTA ES MUY LARGA... UPS!!", self.profile)

    # ─────────────────────────────────────────────────────────────────────────
    #  AUTOMATISMOS INTERNOS (privados, llamados bajo self.lock)
    # ─────────────────────────────────────────────────────────────────────────

    def _activate_autopause_silence(self) -> None:
        """Pausa automática por silencio en zona de tolerancia."""
        self.is_paused         = True
        self.paused_by_silence = True
        self.silence_timer     = 0.0
        self._pending_pause_cb = (self.on_pause_toggle_callback, "silence")

    def _activate_forced_pause(self) -> None:
        """Pausa forzada al alcanzar el tope máximo de tolerancia Lado A."""
        self.is_paused       = True
        self.is_forced_pause = True
        self.silence_timer   = 0.0
        self._pending_pause_cb = (self.on_pause_toggle_callback, "forced_limit_lado_a")

    def _commute_forced_to_autopause(self) -> None:
        """
        Conmuta pausa forzada → pausa por silencio.
        Al regresar señal audible se ejecutará _execute_auto_flip.
        """
        self.is_forced_pause   = False
        self.paused_by_silence = True
        self.silence_timer     = 0.0
        _log.info("CLCC-ITL [%s]: conmutación FORCED_PAUSE → AUTOPAUSE_SILENCE", self.profile)

    def _execute_auto_flip(self) -> None:
        """
        Volteo lógico Lado A → Lado B — EXACTAMENTE UNA VEZ por sesión.
        Registra excedente, resetea el cuentavueltas y notifica al studio
        (notificación diferida: se dispara fuera del lock).
        """
        if self.flip_done or self.side == "B":
            self.duplicate_flip_requests += 1
            return
        self.flip_done = True
        _log.info("[ITL] FLIP REQUEST — iniciando volteo automático [%s]", self.profile)
        _log.info("[ITL] SIDE BEFORE=A  counter=%d  paused=%s", self.counter, self.is_paused)

        # Registrar excedente antes de voltear
        if self.tape_overflow_warning and self.overflow_excess_secs > 0.0:
            exc_m = int(self.overflow_excess_secs // 60)
            exc_s = int(self.overflow_excess_secs % 60)
            _log.info("CLCC-ITL [%s]: ⚠️ VOLTEO — excedente Lado A: %02d:%02d",
                      self.profile, exc_m, exc_s)

        self.is_paused             = False
        self.paused_by_silence     = False
        self.is_forced_pause       = False
        self.silence_timer         = 0.0
        self.side                  = "B"
        self.tape_overflow_warning = False
        self.overflow_excess_secs  = 0.0

        # Anclar reloj de cuentavueltas al inicio del Lado B
        self.counter_base = self.external_clock
        self.counter      = 0

        _log.info("[ITL] SIDE AFTER=B")
        _log.info("[ITL] COUNTER RESET → 000")
        _log.info("CLCC-ITL [%s]: VOLTEO AUTOMÁTICO → Lado B. Cuentavueltas reiniciado a 000.",
                  self.profile)
        if self.on_flip_side_b_callback:
            _log.info("[ITL] encolando on_flip_side_b_callback → GUI (fuera del lock)")
            self._deferred.append((self.on_flip_side_b_callback, ()))
        else:
            _log.warning("[ITL] FLIP: on_flip_side_b_callback es None — GUI no será notificada")

    def _execute_auto_stop(self, reason: str) -> None:
        """Detención automática al fin del Lado B — EXACTAMENTE UNA VEZ; el
        callback se difiere fuera del lock (ver tick())."""
        if self.stop_issued:
            self.duplicate_stop_requests += 1
            return
        self.stop_issued  = True
        self.is_recording = False
        self.is_stopped   = True
        self.is_paused    = False
        _log.info("CLCC-ITL [%s]: autostop — %s", self.profile, reason)
        if self.on_auto_stop_callback:
            self._deferred.append((self.on_auto_stop_callback, (reason,)))

    # ─────────────────────────────────────────────────────────────────────────
    #  HELPERS
    # ─────────────────────────────────────────────────────────────────────────

    def _format_time(self, secs: float) -> str:
        h = int(secs // 3600)
        m = int((secs % 3600) // 60)
        s = int(secs % 60)
        return f"{h:02d}:{m:02d}:{s:02d}"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ITLBridge — puente entre LoritoAldhiroStudio y _CLCCEngine
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class ITLBridge:
    """
    Puente entre LoritoAldhiroStudio y el motor CLCC monolítico.

    Reemplaza íntegramente a la arquitectura ITLBridge + SIVCSensorController.

    Ciclo de vida de una sesión:
      on_start_recording(profile)   →  inicia el motor CLCC
      _gui_tick(...)                →  alimenta audio y avanza el reloj a 15 Hz
      on_stop_recording()           →  detiene el motor

    Compatibilidad con el studio (atributos accedidos directamente):
      bridge._sensor.counter  — cuentavueltas (leído en _tick_cassette)
      bridge._sensor.lock     — lock para lectura thread-safe
      bridge._sensor.profile  — "C-60" | "C-90"
      bridge._sensor.side     — "A" | "B"

    Callbacks que el motor dispara y este bridge re-emite al studio:
      _on_clcc_pause_toggle(paused, reason)  → autopause / forced-pause
      _on_clcc_flip()                        → volteo a Lado B
      _on_clcc_auto_stop(reason)             → detener grabación

    REGLA CRÍTICA DE THREADING:
    _gui_tick() es llamado desde el GUI thread (15 Hz, QTimer).
    Los callbacks se disparan desde dentro de _gui_tick() después de tick(),
    es decir, también en el GUI thread. No se necesita QTimer.singleShot()
    para callbacks disparados por tick(), ya que ocurren en el GUI thread.
    Para callbacks disparados fuera de tick() (si los hubiera), se usa
    _dispatch_to_gui() para garantizar ejecución en el GUI thread.
    """

    def __init__(self, studio, engine: _CLCCEngine) -> None:
        self._studio = studio
        self._engine = engine  # instancia de _CLCCEngine

        # Alias de compatibilidad: el studio accede a bridge._sensor
        # para leer .counter, .lock, .profile, .side
        self._sensor = engine

        # Bandera de pausa en tránsito (mismo mecanismo que SIVC-SYNC-FIX)
        # Evita que _gui_tick sobreescriba is_paused del motor en el intervalo
        # entre que el callback encola la pausa y que el GUI thread la ejecuta.
        # En esta arquitectura los callbacks se ejecutan en el mismo tick del
        # GUI thread, por lo que _pause_dispatch_pending siempre es False
        # al terminar el tick. Se mantiene por compatibilidad de interfaz.
        self._pause_dispatch_pending: bool = False

        # Inyectar callbacks
        self._engine.on_pause_toggle_callback = self._on_clcc_pause_toggle
        self._engine.on_flip_side_b_callback  = self._on_clcc_flip
        self._engine.on_auto_stop_callback    = self._on_clcc_auto_stop

        _log.info("ITLBridge (CLCC-ITL): creado — perfil=%s", engine.profile)

    # ── API pública ───────────────────────────────────────────────────────────

    def on_start_recording(self, profile: str) -> None:
        """
        Llamado por LoritoAldhiroStudio._start_record() al iniciar una sesión.
        Resetea el motor CLCC a estado limpio.
        """
        with self._engine.lock:
            if profile and profile != self._engine.profile:
                self._engine.configure_profile(profile)
            self._engine.elapsed_time          = 0.0
            self._engine.external_clock        = 0.0
            self._engine.counter               = 0
            self._engine.counter_base          = 0.0
            self._engine.side                  = "A"
            self._engine.silence_timer         = 0.0
            self._engine.signal_strength_db    = -50.0
            self._engine.tape_overflow_warning = False
            self._engine.overflow_excess_secs  = 0.0
            self._engine.is_recording          = False
            self._engine.is_paused             = False
            self._engine.is_forced_pause       = False
            self._engine.paused_by_silence     = False
            self._engine.is_stopped            = False
            self._engine.flip_done             = False
            self._engine.stop_issued           = False
            self._engine._last_audio_s         = None

        self._engine.start_recording()
        self._pause_dispatch_pending = False
        _log.info("ITLBridge: sesión iniciada (perfil=%s)", self._engine.profile)

    def on_stop_recording(self) -> None:
        """Llamado por stop_all() del studio."""
        self._engine.stop_recording(reason="studio_stop")
        self._pause_dispatch_pending = False
        _log.info("ITLBridge: sesión detenida")

    def on_flip_side_b(self) -> None:
        """
        Llamado cuando el usuario voltea la cinta manualmente desde la GUI.
        Sincroniza el estado interno del motor CLCC.
        """
        with self._engine.lock:
            if self._engine.side == "B" or self._engine.flip_done:
                # Orden Golden (ITL-02): comando idempotente — un segundo
                # volteo no reancla el contador ni duplica la transición.
                self._engine.duplicate_flip_requests += 1
                return
            self._engine.flip_done             = True
            self._engine.side                  = "B"
            self._engine.counter_base          = self._engine.external_clock
            self._engine.counter               = 0
            self._engine.is_paused             = False
            self._engine.paused_by_silence     = False
            self._engine.is_forced_pause       = False
            self._engine.tape_overflow_warning = False
            self._engine.overflow_excess_secs  = 0.0
        _log.info("ITLBridge: volteo manual → Lado B sincronizado en motor CLCC")

    def _gui_tick(
        self,
        rms_lin:   float,
        peak_lin:  float,
        recording: bool,
        paused:    bool,
        audio_seconds: Optional[float] = None,
        now: Optional[float] = None,
        sample_time: Optional[float] = None,
    ) -> None:
        """
        Llamado por LoritoAldhiroStudio._tick() cada ~67 ms (15 Hz, GUI thread).

        Flujo:
          1. Convierte peak_lin → dBFS y actualiza el sensor de audio del CLCC.
          2. Sincroniza el estado recording/paused del studio con el motor.
          3. Llama a engine.tick(dt) para avanzar los relojes y evaluar automatismos.
             Los callbacks de pausa/volteo/stop se disparan dentro de tick(),
             es decir, en el GUI thread — sin necesidad de despacho asíncrono.

        CALIBRACIÓN DE UMBRAL (idéntica a la implementación SIVC anterior):
          El SIPA global activa silencio cuando peak_lin ≤ SILENCE_REF_CEILING_LIN.
          El motor CLCC compara signal_strength_db con silence_threshold_db = -61.46.
          Se pasa PEAK en dBFS (no RMS) para que el criterio sea idéntico al SIPA global.

        SINCRONÍA CON EL RELOJ MAESTRO:
          engine.tick(_MASTER_DT) avanza elapsed_time y external_clock SOLO cuando
          is_recording=True AND is_paused=False, garantizando que el reloj de
          cinta nunca avanza durante pausas — ni manuales ni automáticas.
        """
        # ── 1. Actualizar nivel de audio ──────────────────────────────────────
        db = 20.0 * math.log10(max(peak_lin, 1e-6)) if peak_lin > 0.0 else -120.0
        try:
            self._engine.update_audio_sensor(db, now=now, sample_time=sample_time)
        except Exception as exc:
            _log.debug("ITLBridge._gui_tick update_audio_sensor: %s", exc)

        # ── 2. Sincronizar estado recording/paused ────────────────────────────
        if self._pause_dispatch_pending:
            # Hay una pausa en tránsito: omitir sincronización de estado
            # para no revertir la pausa que el motor ya tiene comprometida.
            # (Mecanismo SIVC-SYNC-FIX preservado por compatibilidad de interfaz.)
            pass
        else:
            try:
                with self._engine.lock:
                    if paused and not self._engine.is_paused:
                        self._engine.is_paused = True
                    elif not paused and self._engine.is_paused \
                            and not self._engine.paused_by_silence \
                            and not self._engine.is_forced_pause:
                        self._engine.is_paused = False
                    elif not paused and self._engine.is_paused:
                        # FIX-FAILSAFE-DESYNC: si el engine no está pausado
                        # y el studio tampoco activó _silence_autopause_active,
                        # revertir el estado del motor para mantener coherencia.
                        _autopause_active = getattr(
                            self._studio, "_silence_autopause_active", False)
                        if not _autopause_active:
                            self._engine.is_paused         = False
                            self._engine.paused_by_silence = False
                            self._engine.is_forced_pause   = False
            except Exception as exc:
                _log.debug("ITLBridge._gui_tick sync state: %s", exc)

        # ── 3. Tick del motor CLCC (avanza reloj + evalúa automatismos) ───────
        # Los callbacks se disparan aquí, en el GUI thread — directamente.
        if recording:
            try:
                self._engine.tick(dt=_MASTER_DT, audio_seconds=audio_seconds)
            except Exception as exc:
                _log.warning("ITLBridge._gui_tick engine.tick error: %s", exc)

    # ── Callbacks del motor → studio ──────────────────────────────────────────
    #
    # A diferencia de la arquitectura SIVC anterior (hilo daemon sivc-itl-tick),
    # estos callbacks se disparan en el GUI thread (dentro de _gui_tick → tick()).
    # Por lo tanto NO necesitan QTimer.singleShot() para despacho asíncrono.
    # La llamada directa a los métodos del studio es segura en el GUI thread.
    #
    # Se mantiene _dispatch_to_gui() como capa de seguridad defensiva para
    # cualquier caso límite donde un callback se dispare fuera del GUI thread.

    @staticmethod
    def _dispatch_to_gui(fn) -> None:
        """Encola fn() al GUI thread. En el GUI thread ya, llama directamente."""
        if _QTimer is not None:
            _QTimer.singleShot(0, fn)
        else:
            try:
                fn()
            except Exception as exc:
                _log.error("ITLBridge _dispatch_to_gui (fallback) error: %s", exc)

    def _on_clcc_pause_toggle(self, paused: bool, reason: str = "") -> None:
        """
        Disparado por el motor CLCC cuando detecta silencio (pausa automática)
        o cuando el reloj llega al tope de tolerancia (pausa forzada).

        Ejecutado en el GUI thread (dentro de _gui_tick → engine.tick()).
        """
        if not paused:
            return

        studio = self._studio

        if reason == "silence":
            _log.info("CLCC-ITL → studio: activar autopause por silencio (SIPA integrado)")
            self._pause_dispatch_pending = True
            try:
                studio._activate_silence_autopause()
                if not getattr(studio, "_silence_autopause_active", False):
                    _log.warning(
                        "CLCC-ITL FIX-FAILSAFE-BYPASS (silence): CRAC Failsafe "
                        "bloqueó autopause — forzando pausa del engine y "
                        "seteando _flip_pending en panel activo.")
                    studio._silence_autopause_active = True
                    try:
                        studio._engine.pause(True)
                    except Exception as _ep:
                        _log.error("CLCC-ITL force engine.pause: %s", _ep)
                    _active_lbl = studio.cassette_dur_box.currentText()
                    for _tp in (getattr(studio, "tape_c60", None),
                                getattr(studio, "tape_c90", None)):
                        if (_tp is not None
                                and _tp._tape_label == _active_lbl
                                and not getattr(_tp, "_flip_done", False)):
                            _tp._flip_pending = True
                            _log.info(
                                "CLCC-ITL FIX-FAILSAFE-BYPASS: _flip_pending=True "
                                "seteado en panel %s", _active_lbl)
            except Exception as exc:
                _log.error("CLCC-ITL autopause (silence) error: %s", exc)
            finally:
                self._pause_dispatch_pending = False

        elif reason == "forced_limit_lado_a":
            _log.info("CLCC-ITL → studio: pausa forzada por tope Lado A")
            self._pause_dispatch_pending = True
            try:
                if not getattr(studio, "_silence_autopause_active", False):
                    studio._activate_silence_autopause()
                if not getattr(studio, "_silence_autopause_active", False):
                    _log.warning(
                        "CLCC-ITL FIX-FAILSAFE-BYPASS (forced_lado_a): CRAC "
                        "Failsafe bloqueó autopause — forzando pausa del engine.")
                    studio._silence_autopause_active = True
                    try:
                        studio._engine.pause(True)
                    except Exception as _ep:
                        _log.error("CLCC-ITL force engine.pause (forced_a): %s", _ep)
                    _active_lbl = studio.cassette_dur_box.currentText()
                    for _tp in (getattr(studio, "tape_c60", None),
                                getattr(studio, "tape_c90", None)):
                        if (_tp is not None
                                and _tp._tape_label == _active_lbl
                                and not getattr(_tp, "_flip_done", False)):
                            _tp._flip_pending = True
            except Exception as exc:
                _log.error("CLCC-ITL autopause (forced_lado_a) error: %s", exc)
            finally:
                self._pause_dispatch_pending = False

        elif reason == "forced_limit_lado_b":
            _log.info("CLCC-ITL → studio: pausa forzada por tope máximo Lado B")
            self._pause_dispatch_pending = True
            try:
                if not getattr(studio, "_silence_autopause_active", False):
                    studio._activate_silence_autopause()
                if not getattr(studio, "_silence_autopause_active", False):
                    _log.warning(
                        "CLCC-ITL FIX-FAILSAFE-BYPASS (forced_lado_b): CRAC "
                        "Failsafe bloqueó autopause — forzando pausa del engine.")
                    studio._silence_autopause_active = True
                    try:
                        studio._engine.pause(True)
                    except Exception as _ep:
                        _log.error("CLCC-ITL force engine.pause (forced_b): %s", _ep)
            except Exception as exc:
                _log.error("CLCC-ITL autopause (forced_lado_b) error: %s", exc)
            finally:
                self._pause_dispatch_pending = False

    def _on_clcc_flip(self) -> None:
        """
        Disparado cuando el motor confirma el volteo a Lado B.
        Ejecutado en el GUI thread (dentro de _gui_tick → engine.tick()).

        FIX-CLCC-FLIP-GUI (v0.24.01):
        La implementación anterior delegaba en tp.on_flip_side_b() que es el
        callback GUI→ITL del volteo MANUAL. Ese callback llama a
        _activate_silence_autopause() para pausar y luego esperar audio.
        El problema: _activate_silence_autopause tiene failsafes (cooldown 5 s,
        límite de frecuencia) que pueden bloquearlo silenciosamente si el volteo
        automático ocurrió poco después de una pausa anterior. En ese caso:
          - _flip_pending queda True pero _silence_autopause_active no se activa.
          - _deactivate_silence_autopause nunca se llama.
          - La GUI nunca pasa a _phase="B" → no aparece LADO B ni PAUSA.
          - El contador sí muestra 000 porque _tick_cassette lee _sens.counter
            directamente del motor, que ya fue reseteado por _execute_auto_flip.

        SOLUCIÓN: para el volteo AUTOMÁTICO (ITL → GUI), actualizar el
        TapeLogPanel directamente sin pasar por la ruta de pausa/reanudación.
        El motor ya está en marcha (is_paused=False, side="B", counter=0),
        así que la GUI debe reflejar ese estado inmediatamente:
          - Desactivar cualquier auto-pausa previa (sin disparar el flip path).
          - Marcar _flip_done=True, _phase="B" en el panel activo.
          - Resetear _counter_base para que el contador parta de cero.
          - Resetear hubs y estado de animación.
          - NO activar una nueva auto-pausa (el motor ya está grabando).
        """
        _log.info("[ITL] FLIP REQUEST")
        studio = self._studio
        try:
            # ── Registrar estado previo ──────────────────────────────────────
            _log.info("[ITL] SIDE BEFORE=A")

            # ── Desactivar auto-pausa previa si estaba activa ────────────────
            # Se usa el flag directamente para evitar la lógica de volteo de
            # _deactivate_silence_autopause, que requiere _flip_pending=True
            # y que _sivc_flip_confirmed esté activo (ya está fuera de sync).
            if getattr(studio, "_silence_autopause_active", False):
                _log.info("[ITL] deactivando auto-pausa previa antes de flip")
                # Limpiar estado de auto-pausa sin disparar la ruta de flip
                studio._silence_autopause_active = False
                studio._sil_in_silence  = False
                studio._silence_start_t = None
                studio._sil_win_rms_sq  = 0.0
                studio._sil_win_peak    = 0.0
                studio._sil_win_ticks   = 0
                try:
                    studio._carola_waiting_blink_timer.stop()
                except Exception:
                    pass
                # NOTA DE INTEGRACIÓN (Lorito Aldhiro): el módulo original
                # (aecct2_itl_integration.py) intentaba suprimir el log de la
                # GUI vía un módulo `aecct2_config.suppress_gui_log` propio de
                # esa arquitectura. Lorito Aldhiro no tiene un equivalente
                # (`lorito_app_logging.py` no expone una función de
                # supresión) — se omite intencionalmente en vez de fingir un
                # no-op silencioso con un import que nunca puede resolver.
                # Sin impacto funcional: solo evitaba ruido de log durante el
                # flip, no afecta la lógica de transporte/pausa.
                # Reanudar motor de captura (puede estar pausado por auto-pausa)
                studio._rec_start_t = time.monotonic()
                try:
                    studio._engine.pause(False)
                except Exception as _ep:
                    _log.error("[ITL] FLIP: error al reanudar engine: %s", _ep)

            # ── Localizar TapeLogPanel activo ────────────────────────────────
            active_label = studio.cassette_dur_box.currentText()
            tp = None
            if active_label == "C-60":
                tp = getattr(studio, "tape_c60", None)
            elif active_label == "C-90":
                tp = getattr(studio, "tape_c90", None)

            if tp is None:
                _log.warning(
                    "[ITL] FLIP: TapeLogPanel no encontrado para '%s'",
                    active_label)
            else:
                # ── Actualizar estado del panel DIRECTAMENTE ─────────────────
                # Sin pasar por _activate_silence_autopause ni _flip_pending.
                # El motor ya está grabando en Lado B; la GUI debe reflejar
                # ese estado de forma inmediata y sin condiciones.
                _log.info("[ITL] GUI SIDE UPDATE → B")
                tp._flip_pending          = False
                tp._flip_pending_unlocked = False
                tp._flip_done             = True
                tp._phase                 = "B"
                tp._stop_triggered        = False
                tp._counter_overflow      = False
                tp._wobble_phase          = 0.0
                tp._wobble_blink_vis      = True
                tp._forced_pause_active   = False
                # Resetear base del contador al elapsed actual del panel
                tp._counter_base          = getattr(tp, "_elapsed", 0.0)
                # Resetear animación de hubs al inicio de Lado B
                tp._angle1                = 0.0
                tp._angle2                = 0.0
                tp._mech_accum            = 0.0
                tp._mech_spool_ang        = 0.0
                tp._mech_digits           = [0.0, 0.0, 0.0]
                tp._mech_values           = [0, 0, 0]
                tp._mech_prev_cnt         = -1
                # Desactivar modo CAROLA ESPERANDO si estaba activo
                try:
                    tp.deactivate_carola_waiting()
                except Exception:
                    pass
                _log.info("[ITL] COUNTER RESET")
                _log.info("[ITL] GUI PAUSE UPDATE → no pausa (motor en marcha)")
                _log.info("[ITL] GUI TRANSPORT UPDATE → REC Lado B")

            # ── Resetear banderas de handover SIPA ──────────────────────────
            studio._sivc_sipa_handover_active = False
            studio._sivc_tol_entered          = False
            studio._silence_autopause_enabled = True
            _log.info("[ITL] SIDE AFTER=B")
            _log.info(
                "[ITL] FLIP COMPLETE — SIPA global reactivado; "
                "handover proactivo se disparará al entrar en tolerancia B.")

        except Exception as exc:
            _log.error("[ITL] CLCC-ITL flip error: %s", exc)
        finally:
            # _sivc_flip_confirmed se usa solo para el reset de counter_base
            # en la ruta legado (_deactivate). Ya no es necesario aquí, pero
            # lo dejamos en False para no confundir rutas futuras.
            studio._sivc_flip_confirmed = False

    def _on_clcc_auto_stop(self, reason: str) -> None:
        """
        Disparado cuando el motor detecta fin del Lado B.
        Ejecutado en el GUI thread (dentro de _gui_tick → engine.tick()).
        """
        _log.info("CLCC-ITL → studio: autostop (reason=%s)", reason)
        try:
            self._studio.stop_all()
        except Exception as exc:
            _log.error("CLCC-ITL auto_stop error: %s", exc)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  FÁBRICA PÚBLICA
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def integrate_itl_into_studio(studio) -> Optional[ITLBridge]:
    """
    Punto de entrada único. Llamado desde LoritoAldhiroStudio.__init__().

    Lee el perfil actual del combo cassette_dur_box:
      "C-60"  → _CLCCEngine(profile="C-60")
      "C-90"  → _CLCCEngine(profile="C-90")
      "OTROS" → retorna None (sin motor ITL; perfil libre)

    Retorna un ITLBridge listo para usar, o None si el perfil es desconocido.

    NOTA: SIVC eliminado. _CLCCEngine provee directamente todas las
    funcionalidades que antes requerían SIVCSensorController.
    """
    profile = "C-60"  # valor por defecto seguro
    try:
        profile = studio.cassette_dur_box.currentText()
    except Exception:
        pass

    if profile not in ("C-60", "C-90"):
        _log.info(
            "integrate_itl_into_studio: perfil '%s' no reconocido — ITL inactivo",
            profile,
        )
        return None

    engine = _CLCCEngine(profile=profile)
    bridge = ITLBridge(studio=studio, engine=engine)
    _log.info(
        "integrate_itl_into_studio: ITLBridge (CLCC-ITL monolítico) creado — perfil=%s",
        profile,
    )
    return bridge
