"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Auto-pausa por silencio (SIPA): detección, activación, desactivación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb, _status
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_v21 import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, LCDSignalMeterWidget,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




class SilenceAutopauseMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _on_cafe_blink_tick(self):
        """Tick parpadeo pausa física: sincroniza StatusDisplay (BUSYCHAN), paneles de cinta
        y MediaAnimWidget. El parpadeo de la PC se hace esclavo de este tick para que
        el dibujo de la computadora y la leyenda BUSYCHAN parpadeen en perfecta fase.
        """
        self.status_label.setText("__BUSYCHAN_TICK__")
        # Sincronizar MediaAnimWidget con el nuevo estado del StatusDisplay.
        # _cafe_blink_state ya fue alternado por setText("__BUSYCHAN_TICK__");
        # usamos ese mismo valor para que PC y leyenda vayan exactamente al unísono.
        if hasattr(self, "media_anim"):
            self.media_anim.setBlink(self.status_label._cafe_blink_state)
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None),
                    getattr(self, "tape_otros", None)):
            if _tp is not None:
                _tp.tick_pause_blink()
    def set_silence_autopause(self, enabled: bool):
        """
        Habilita o deshabilita la función de auto-pausa por silencio.
        Mantenido por compatibilidad; la función está siempre activa tras
        eliminar el panel de toggle. Solo desactiva si se llama con False
        para limpiar estado (p.ej. al detener la grabación).
        """
        self._silence_autopause_enabled = enabled
        if not enabled:
            self._silence_start_t = None
            self._sil_in_silence  = False
            self._sil_win_rms_sq  = 0.0
            self._sil_win_peak    = 0.0
            self._sil_win_ticks   = 0
            if self._silence_autopause_active:
                self._deactivate_silence_autopause()
    def _crac_classify_profile(self, seg: "np.ndarray", rate: int) -> "str | None":
        """
        Clasifica el perfil espectral de un segmento de audio residual.

        OPT-SCIPY-ELIM (v0.22.38): reemplaza scipy.signal.welch() por
        numpy rfft directo con ventana Hann. Elimina:
          · import from scipy en el GUI thread (hot path 15 Hz)
          · overhead de scipy.signal.welch (interno: ndarray allocs, detrend, etc.)
          · dependencia scipy en el camino RT de la UI

        Compara el contenido espectral del segmento contra los perfiles derivados
        de las muestras de referencia:

          Perfil A — "muestra.wav"  (deck sin cinta / hum eléctrico grave):
            · Sub-bass (0–120 Hz) > CRAC_PROFILE_A_SUBBASS_MIN  (50%)
            · Hiss (>4 kHz)       < CRAC_PROFILE_A_HISS_MAX     (12%)
            · ZCR                 < CRAC_PROFILE_A_ZCR_MAX       (0.12)
            · Flatness            < CRAC_PROFILE_A_FLATNESS_MAX  (0.12)

          Perfil B — "muestra1.wav" (cinta cassette en silencio / hiss HF):
            · Hiss (>4 kHz)       > CRAC_PROFILE_B_HISS_MIN     (20%)
            · ZCR                 > CRAC_PROFILE_B_ZCR_MIN       (0.13)
            · Flatness            > CRAC_PROFILE_B_FLATNESS_MIN  (0.15)

        Retorna "A", "B", o None si el segmento es demasiado corto / ambiguo.
        """
        if len(seg) < 32:
            return None

        # ── ZCR (zero-copy: opera sobre el array recibido) ────────────────────
        zcr = float(np.mean(np.abs(np.diff(np.sign(seg))) * 0.5))

        # ── Espectro de potencia vía numpy rfft + ventana Hann ────────────────
        # OPT-SCIPY-ELIM: numpy rfft equivalente a welch con nperseg=len(seg).
        # Para clasificación de perfil la precisión es idéntica; el overhead
        # es ~4× menor que scipy.signal.welch para bloques < 2048 muestras.
        n = len(seg)
        # Reutilizar ventana Hann si el tamaño no cambió (caché por instancia)
        _hann_n = getattr(self, "_prof_hann_n", 0)
        if _hann_n != n:
            self._prof_hann     = np.hanning(n).astype(np.float32)
            self._prof_hann_n   = n
            self._prof_freqs    = np.fft.rfftfreq(n, d=1.0 / rate).astype(np.float32)
        windowed = seg * self._prof_hann
        psd = (np.abs(np.fft.rfft(windowed)) ** 2).astype(np.float64)
        freqs = self._prof_freqs

        total = float(psd.sum())
        if total < 1e-30:
            return None

        sub_bass = float(psd[freqs < 120.0].sum())   / total
        hiss     = float(psd[freqs >= 4000.0].sum()) / total
        psd_nz   = psd[psd > 0]
        flatness = (float(np.exp(np.mean(np.log(psd_nz))))
                    / float(np.mean(psd_nz))) if len(psd_nz) > 0 else 0.0

        # ── Clasificación ─────────────────────────────────────────────────────
        _is_A = (
            sub_bass >= CRAC_PROFILE_A_SUBBASS_MIN and
            hiss     <= CRAC_PROFILE_A_HISS_MAX    and
            zcr      <= CRAC_PROFILE_A_ZCR_MAX      and
            flatness <= CRAC_PROFILE_A_FLATNESS_MAX
        )
        _is_B = (
            hiss     >= CRAC_PROFILE_B_HISS_MIN    and
            zcr      >= CRAC_PROFILE_B_ZCR_MIN      and
            flatness >= CRAC_PROFILE_B_FLATNESS_MIN
        )

        if _is_A and not _is_B:
            return "A"
        if _is_B and not _is_A:
            return "B"
        return None   # ambiguo
    def _check_silence_autopause(self, rms_linear: float):
        """
        Detector de silencio — CRAC_REFERENCE_ANCHORED v0.20.9.
        Llamado desde _tick() (15 Hz, cada 67 ms) durante grabación activa.

        LÓGICA v0.20.9 — umbral 15.6 dB sobre el pico del audio de referencia:
          · Audio de referencia: aecct2_20260520_202133.wav
              Peak real:  -77.02 dBFS  →  0.00014091 lin
              RMS real:   -88.74 dBFS  →  0.00003656 lin
          · Umbral de ACTIVACIÓN (pausa) — ref_peak × 6  (+15.6 dB):
              Peak: SILENCE_REF_CEILING_LIN = 8.454e-04  (-61.46 dBFS)
              RMS:  SILENCE_REF_RMS_LIN     = 2.193e-04  (-73.18 dBFS)
          · El ruido de referencia queda 15.6 dB bajo el umbral → siempre silencio.
          · Activación: 5 s continuos con señal ≤ umbral → pausa.
          · Release: primer tick con señal > umbral → libera sin hold.
          · τ = 0.5 µs → α ≈ 1.0 → respuesta en 1 tick (67 ms).
          · Sin histéresis: mismo umbral para activación y release.
          · HISS_REJECTION = False, MIDBAND_DETECTOR = False.
          · Spectral flux gate activo para vetar transientes reales.
        """
        if not self._silence_autopause_enabled:
            return
        if not self._engine.recording:
            self._silence_start_t     = None
            self._sil_release_start_t = None
            self._sil_win_rms_sq      = 0.0
            self._sil_win_peak        = 0.0
            self._sil_win_ticks       = 0
            self._sil_in_silence      = False
            self._sil_prev_pow_sc     = None
            self._sil_consec_above    = 0
            return
        if self._engine.paused and not self._silence_autopause_active:
            self._silence_start_t     = None
            self._sil_release_start_t = None
            self._sil_win_rms_sq      = 0.0
            self._sil_win_peak        = 0.0
            self._sil_win_ticks       = 0
            self._sil_in_silence      = False
            self._sil_prev_pow_sc     = None
            self._sil_consec_above    = 0
            return

        # ── Calibración inicial (4 s) — solo para _sil_ceiling_ref ───────────
        # En v0.20.8 la calibración ya no define los umbrales de activación:
        # esos están fijos en SILENCE_REF_CEILING_LIN / SILENCE_REF_RMS_LIN.
        # Calibrar _sil_ceiling_ref sigue siendo útil para logging/display.
        if not self._sil_calib_done:
            self._sil_calib_peak_abs = max(
                getattr(self, "_sil_calib_peak_abs", 0.0), rms_linear)
            self._sil_calib_ticks_total = getattr(self, "_sil_calib_ticks_total", 0) + 1
            _calib_elapsed = self._sil_calib_ticks_total * (SILENCE_ANALYSIS_INTERVAL_MS / 1000.0)
            if _calib_elapsed >= SILENCE_CALIB_SECS:
                _ceiling_abs = max(getattr(self, "_sil_calib_peak_abs", 0.0), 1e-12)
                self._sil_ceiling_ref   = _ceiling_abs   # solo para logging/display
                self._sil_calib_peak_abs = 0.0
                self._sil_calib_done    = True
                # v0.20.9: los umbrales de activación son los de referencia fijos,
                # no el ceiling calibrado. El EMA de _sil_ref_rms_lin se inicializa
                # en SILENCE_REF_RMS_LIN para seguimiento interno (solo display).
                self._sil_ref_rms_lin   = SILENCE_REF_RMS_LIN
                self._sil_ref_peak_lin  = SILENCE_REF_CEILING_LIN
                _log.info(
                    "CRAC v0.20.9 calibración: ceiling_runtime=%.1f dBFS  "
                    "umbral_activación=%.1f dBFS  (ref_peak×6)",
                    20 * _math.log10(max(_ceiling_abs, 1e-12)),
                    SILENCE_REF_CEILING_DBFS,
                )

        # ── Umbrales fijos — anclados al umbral de referencia ────────────────
        # v0.20.9: el umbral de activación es SIEMPRE SILENCE_REF_CEILING_LIN.
        # El ceiling calibrado en runtime NO baja el umbral: si la calibración
        # produce un ceiling más bajo (señal residual menor), el umbral de
        # activación se mantiene en SILENCE_REF_CEILING_LIN para que el ruido
        # del audio de referencia siempre quede DENTRO de la zona de silencio.
        # Esto es correcto: el audio de referencia (-77 dBFS peak) está 15.6 dB
        # por debajo del umbral (-61.46 dBFS) → siempre detectado como silencio.
        _peak_thresh_lin  = SILENCE_REF_CEILING_LIN   # -61.46 dBFS (ref_peak × 6) — activación
        _rms_thresh_lin   = SILENCE_REF_RMS_LIN        # -73.18 dBFS (ref_rms  × 6) — activación
        # Release: solo peak, +6 dB de histéresis sobre el umbral de activación.
        # El RMS queda excluido del release: es demasiado sensible a clics sub-frame.
        _release_peak_lin = SILENCE_RELEASE_PEAK_LIN   # -55.46 dBFS (activación + 6 dB)

        # ── Peak instantáneo del monitor block ───────────────────────────────
        _peak_now = rms_linear  # fallback conservador
        try:
            _mon_n = self._engine._monitor_block_frames
            if _mon_n > 0:
                _mon      = self._engine._monitor_block[:_mon_n]
                _peak_now = float(np.max(np.abs(_mon)))
        except Exception:
            pass

        # ── EMA tracking lento del RMS (solo para logging/display) ───────────
        # En v0.20.8 el EMA no controla los umbrales; solo actualiza
        # _sil_ref_rms_lin para que el display siga mostrando el nivel actual.
        if not self._silence_autopause_active and self._sil_ema_alpha:
            _dt_sil_up  = SILENCE_ANALYSIS_INTERVAL_MS / 1000.0
            _tau_up_s   = max(SILENCE_EMA_UP_TAU_US * 1e-6, 1e-12)
            _alpha_up   = min(1.0, 1.0 - _math.exp(-_dt_sil_up / _tau_up_s))
            _alpha_slow = self._sil_ema_alpha
            _rms_ref = self._sil_ref_rms_lin if self._sil_ref_rms_lin else SILENCE_REF_RMS_LIN
            _alpha_rms = _alpha_up if rms_linear > _rms_ref else _alpha_slow
            self._sil_ref_rms_lin = (
                _alpha_rms * rms_linear + (1.0 - _alpha_rms) * _rms_ref)

        # ── FAST-RELEASE CON HISTÉRESIS Y CONFIRMACIÓN POR TICKS (v0.20.11) ──
        # Criterio de release: SOLO PEAK (no RMS).
        #   · El RMS del bloque de 67 ms se excluye: es demasiado sensible a
        #     clics sub-frame que elevan el RMS puntualmente.
        #   · El umbral de release es +6 dB sobre el de activación (-55.46 dBFS):
        #     histéresis real que ignora ruido de línea, hum, clics de cabezal.
        #   · Se requieren SILENCE_RELEASE_MIN_TICKS ticks consecutivos (~200 ms)
        #     con peak > _release_peak_lin para confirmar el release.
        if self._silence_autopause_active:
            if _peak_now > _release_peak_lin:
                self._sil_consec_above += 1
                if self._sil_consec_above >= SILENCE_RELEASE_MIN_TICKS:
                    self._sil_release_start_t = None
                    self._sil_in_silence      = False
                    self._silence_start_t     = None
                    self._sil_win_rms_sq      = 0.0
                    self._sil_win_peak        = 0.0
                    self._sil_win_ticks       = 0
                    self._sil_consec_above    = 0
                    self._deactivate_silence_autopause()
                    return
                # tick con señal real pero aún sin confirmar: no liberar
                return
            else:
                # señal bajo el umbral de release — resetear contador
                self._sil_consec_above = 0

        # ── Acumular ventana deslizante (800 ms) ─────────────────────────────
        self._sil_win_rms_sq += rms_linear ** 2
        self._sil_win_peak    = max(self._sil_win_peak, _peak_now)
        self._sil_win_ticks  += 1

        _ticks_total = getattr(self, "_sil_win_ticks_total",
                               max(1, round(SILENCE_WINDOW_MS / SILENCE_ANALYSIS_INTERVAL_MS)))
        if self._sil_win_ticks < _ticks_total:
            return  # ventana no cerrada aún

        # Calcular RMS promedio de la ventana cerrada
        _win_rms  = _math.sqrt(self._sil_win_rms_sq / _ticks_total)
        _win_peak = self._sil_win_peak

        # Resetear acumuladores para la próxima ventana
        self._sil_win_rms_sq = 0.0
        self._sil_win_peak   = 0.0
        self._sil_win_ticks  = 0

        # ── Decisión primaria: ¿la señal está por debajo del techo? ──────────
        # v0.20.8: criterio binario. Si peak ≤ ceiling Y rms ≤ rms_ref
        # → el contenido de esta ventana es "silencio" (= ruido de referencia).
        _is_silent_candidate  = (_win_rms <= _rms_thresh_lin) and (_win_peak <= _peak_thresh_lin)
        # v0.20.11: release candidate — solo peak, umbral +6 dB sobre activación.
        # Zona muerta [-61.46, -55.46] dBFS: ni activa ni suelta.
        _is_release_candidate = (_win_peak > _release_peak_lin)

        # ── Confirmación espectral (solo si está habilitada) ─────────────────
        # v0.20.8: HISS_REJECTION y MIDBAND_DETECTOR están desactivados
        # (SILENCE_HISS_REJECTION = False, SILENCE_MIDBAND_DETECTOR = False).
        # Solo se aplica el SPECTRAL_FLUX_GATE para vetar transientes reales.
        if _is_silent_candidate and SILENCE_SPECTRAL_CONFIRM:
            try:
                _rate = max(self._engine.rate, 1)
                _mon_n = self._engine._monitor_block_frames
                if _mon_n > 0:
                    _seg = self._engine._monitor_block[:_mon_n, 0].astype(np.float32)
                else:
                    _buf    = self._engine.buffer
                    _lck    = self._engine.lock
                    _n_blks = max(1, _ticks_total)
                    with _lck:
                        _recent = list(_buf)[-_n_blks:]
                    _seg = (np.concatenate(_recent, axis=0)[:,0].astype(np.float32)
                            if _recent else np.array([], dtype=np.float32))

                if len(_seg) > 0:
                    _fft    = np.fft.rfft(_seg)
                    # OPT-FFT-CACHE: reutilizar rfftfreq y sc_mask si el tamaño del segmento
                    # no cambió entre ticks — elimina la recreación de dos arrays en cada llamada 15Hz.
                    _seg_n = len(_seg)
                    _cached_n = getattr(self, "_sil_fft_cached_n", 0)
                    if _cached_n != _seg_n:
                        _freqs_c = np.fft.rfftfreq(_seg_n, d=1.0 / _rate)
                        self._sil_fft_sc_mask   = ((_freqs_c >= SILENCE_SC_HPF_HZ) &
                                                    (_freqs_c <= SILENCE_SC_LPF_HZ))
                        self._sil_fft_cached_n  = _seg_n
                    _sc_mask = self._sil_fft_sc_mask

                    _fft_sc  = _fft * _sc_mask
                    _pow_sc       = np.abs(_fft_sc) ** 2
                    _total_pow_sc = float(_pow_sc.sum())

                    # Spectral flux gate — veta transientes reales
                    # (no afecta hiss/hum estacionario: flux bajo)
                    if _is_silent_candidate and SILENCE_SPECTRAL_FLUX_GATE:
                        _prev_pow = getattr(self, "_sil_prev_pow_sc", None)
                        if _total_pow_sc > 1e-10:
                            _curr_pow_norm = (_pow_sc / _total_pow_sc).astype(np.float32)
                            if _prev_pow is not None and len(_prev_pow) == len(_curr_pow_norm):
                                _flux = float(np.sum((_curr_pow_norm - _prev_pow) ** 2))
                                if _flux > 0.10:
                                    _is_silent_candidate = False
                            self._sil_prev_pow_sc = _curr_pow_norm
                        else:
                            self._sil_prev_pow_sc = None
                    else:
                        if len(_pow_sc) > 0 and _total_pow_sc > 1e-10:
                            self._sil_prev_pow_sc = (_pow_sc / _total_pow_sc).astype(
                                np.float32)
                        else:
                            self._sil_prev_pow_sc = None

                    # MIDBAND_DETECTOR: desactivado en v0.20.8 (False por defecto)
                    # HISS_REJECTION:   desactivado en v0.20.8 (False por defecto)

            except Exception:
                pass  # error en análisis espectral: mantener candidato sin veto

        # ── CRAC-PROFILE: logging/telemetría (no afecta el timing) ───────────
        # v0.20.8: el clasificador corre para telemetría pero no cambia
        # SILENCE_AUTOPAUSE_SECS (fijo en 5 s para ambos perfiles).
        # OPT-PROFILE-DEBOUNCE (v0.22.38): ejecutar clasificador cada 5 ticks (~333ms)
        # en lugar de cada tick (67ms). La EMA integra suavemente — la convergencia
        # a 333ms es indistinguible de 67ms para el usuario. Reduce FFT CPU en ~80%.
        self._sil_profile_tick_ctr = getattr(self, "_sil_profile_tick_ctr", 0) + 1
        if self._sil_profile_tick_ctr >= 5:
            self._sil_profile_tick_ctr = 0
            try:
                _dt_prof   = SILENCE_ANALYSIS_INTERVAL_MS / 1000.0 * 5  # dt efectivo = 5 ticks
                _tau_up_us = max(SILENCE_EMA_UP_TAU_US * 1e-6, 1e-12)
                _a_up_prof = min(1.0, 1.0 - _math.exp(-_dt_prof / _tau_up_us))
                _a_dn_prof = self._sil_ema_alpha if self._sil_ema_alpha else 1.0 - _math.exp(
                    -_dt_prof / max(SILENCE_NOISE_TRACK_TAU, 0.001))
                _rate_prof  = max(self._engine.rate, 1)
                _mon_n_prof = self._engine._monitor_block_frames
                if _mon_n_prof > 0:
                    _seg_prof = self._engine._monitor_block[:_mon_n_prof, 0].astype(float)
                else:
                    _seg_prof = None
                if _seg_prof is not None and len(_seg_prof) >= 32:
                    _label = self._crac_classify_profile(_seg_prof, _rate_prof)
                    _vote_a = 1.0 if _label == "A" else 0.0
                    _vote_b = 1.0 if _label == "B" else 0.0
                    _ca = getattr(self, "_sil_profile_conf_a", 0.0)
                    _cb = getattr(self, "_sil_profile_conf_b", 0.0)
                    _aa = _a_up_prof if _vote_a > _ca else _a_dn_prof
                    _ab = _a_up_prof if _vote_b > _cb else _a_dn_prof
                    self._sil_profile_conf_a = _aa * _vote_a + (1.0 - _aa) * _ca
                    self._sil_profile_conf_b = _ab * _vote_b + (1.0 - _ab) * _cb
                    if self._sil_profile_conf_a >= self._sil_profile_conf_b and self._sil_profile_conf_a > 0.4:
                        self._sil_profile = "A"
                    elif self._sil_profile_conf_b > self._sil_profile_conf_a and self._sil_profile_conf_b > 0.4:
                        self._sil_profile = "B"
                    else:
                        self._sil_profile = None
            except Exception:
                pass

        # ── Máquina de estados ────────────────────────────────────────────────
        now = time.monotonic()

        if _is_silent_candidate:
            # Señal bajo el techo de activación: acumular tiempo de silencio.
            self._sil_release_start_t = None
            self._sil_consec_above    = 0   # ventana silenciosa: resetear contador
            if not self._sil_in_silence or self._silence_start_t is None:
                # Primer tick silencioso O _silence_start_t fue reseteado
                # externamente mientras _sil_in_silence seguía en True
                # (p.ej. al cancelar la auto-pausa desde toggle_pause/stop_all).
                # Re-anclar siempre el timestamp para evitar "None - float".
                self._sil_in_silence  = True
                self._silence_start_t = now
            else:
                _autopause_secs = SILENCE_AUTOPAUSE_SECS  # 5.0 s por defecto
                # FIX v0.22.30: en zona de tolerancia del Lado A o Lado B,
                # el umbral de silencio sigue siendo SILENCE_AUTOPAUSE_SECS_TOL=5 s.
                # (Comentario anterior decía "60 s" — reliquia de v0.22.20; el valor
                # correcto según spec es siempre 5 s, dentro y fuera de tolerancia.)
                # La detección de tope (flip_max / _b_at_max) la gestiona update_state,
                # no este método: aquí solo se controla el umbral de tiempo de silencio.
                _active_tp = None
                for _tp_chk in (getattr(self, "tape_c60", None),
                                getattr(self, "tape_c90", None)):
                    if (_tp_chk is not None and
                            self.cassette_dur_box.currentText() == _tp_chk._tape_label):
                        _active_tp = _tp_chk
                        break
                if _active_tp is not None:
                    _fl_min, _fl_max = TapeLogPanel._FLIP_INTERVALS.get(
                        _active_tp._tape_label, (None, None))
                    _el = getattr(_active_tp, "_elapsed", 0.0)
                    _ph = getattr(_active_tp, "_phase", "A")
                    _in_tol_a = (_fl_min is not None and _el >= _fl_min
                                 and _ph == "A"
                                 and not getattr(_active_tp, "_flip_done", False))
                    _side_b_dur = _active_tp._total_secs - _active_tp._side_a_secs
                    # FIX v0.22.29: leer ventana de tolerancia del Lado B desde
                    # _STOP_INTERVALS (igual que update_state) para que C-90
                    # use 5 min en Lado B aunque su Lado A use solo 3 min.
                    _stop_entry_chk = TapeLogPanel._STOP_INTERVALS.get(
                        _active_tp._tape_label, None)
                    if _stop_entry_chk is not None:
                        _b_tol_window = _stop_entry_chk[0]
                        _side_b_tol   = max(0.0, _side_b_dur - _b_tol_window)
                    else:
                        _side_b_tol   = _side_b_dur * 0.933
                    _b_elapsed  = _el - _active_tp._side_a_secs
                    _in_tol_b   = (_ph == "B" and _b_elapsed >= _side_b_tol)
                    if _in_tol_a or _in_tol_b:
                        _autopause_secs = SILENCE_AUTOPAUSE_SECS_TOL  # 5 s (igual que fuera de tolerancia; spec unificada)
                if (now - self._silence_start_t) >= _autopause_secs:
                    if not self._silence_autopause_active:
                        self._activate_silence_autopause()
                    else:
                        # Pausa ya activa + silencio real sostenido ≥ 3 s:
                        # FIX v0.22.32: si la pausa fue activada por tope de
                        # tolerancia (PAUSA CON PROTECCIÓN, guarda _has_pending),
                        # un silencio real de 3 s indica que el operario detuvo
                        # el cassette físicamente.
                        #
                        # Comportamiento correcto:
                        #   · NO resetear _flip_pending (la pausa sigue activa).
                        #   · Marcar _flip_pending_unlocked=True → la guarda en
                        #     _is_release_candidate deja de bloquear.
                        #   · La pausa se convierte en PAUSA ORDINARIA.
                        #   · Al regresar la señal (Lado B): _is_release_candidate
                        #     llama _deactivate_silence_autopause() → update_state
                        #     ve not autopause_active + _flip_pending=True → voltea.
                        if (now - self._silence_start_t) >= SILENCE_GUARD_ESCAPE_SECS:
                            _active_txt_esc = self.cassette_dur_box.currentText()
                            for _tp_esc in (getattr(self, "tape_c60", None),
                                            getattr(self, "tape_c90", None)):
                                if (_tp_esc is not None and
                                        _tp_esc._tape_label == _active_txt_esc):
                                    if (getattr(_tp_esc, "_flip_pending", False) and
                                            not getattr(_tp_esc,
                                                        "_flip_pending_unlocked", False)):
                                        _tp_esc._flip_pending_unlocked = True
                                        _log.info(
                                            "TapeLogPanel %s: silencio real ≥ %.0f s "
                                            "con pausa forzada activa — protección "
                                            "desarmada (_flip_pending_unlocked). "
                                            "Pausa convertida a ordinaria; volteo "
                                            "al regresar señal.",
                                            _tp_esc._tape_label,
                                            SILENCE_GUARD_ESCAPE_SECS)
                                    if (getattr(_tp_esc, "_stop_triggered", False)):
                                        _tp_esc._stop_triggered = False
                                        _log.info(
                                            "TapeLogPanel %s: silencio real ≥ %.0f s "
                                            "— _stop_triggered reseteado",
                                            _tp_esc._tape_label,
                                            SILENCE_GUARD_ESCAPE_SECS)
                                    break
        elif _is_release_candidate:
            # Ventana completa sobre el umbral de release (-55.46 dBFS):
            # señal de programa confirmada → liberar pausa.
            # FIX v0.22.30: NO liberar la pausa si algún panel tiene _flip_pending=True
            # o _stop_triggered=True. Esto ocurre cuando update_state activó la pausa
            # por tope de tolerancia (Ruta 2: señal activa llega a flip_max/_b_at_max).
            # Sin esta guarda, _deactivate_silence_autopause cancelaría la pausa de
            # volteo/detención forzada justo cuando la señal regresa a nivel alto,
            # impidiendo el flip/stop requerido por la spec.
            #
            # FIX v0.22.32: si _flip_pending_unlocked=True, la protección fue
            # desarmada (silencio ≥ 3 s con cassette detenido). La pausa es ahora
            # ORDINARIA → sí liberar al detectar señal, para que update_state
            # pueda ejecutar el volteo inmediato (_flip_pending sigue True).
            _active_txt = self.cassette_dur_box.currentText()
            _has_pending = False
            for _tp_guard in (getattr(self, "tape_c60", None),
                              getattr(self, "tape_c90", None)):
                if (_tp_guard is not None and _tp_guard._tape_label == _active_txt):
                    _unlocked = getattr(_tp_guard, "_flip_pending_unlocked", False)
                    if not _unlocked:
                        # Protección activa: bloquear liberación si hay pendiente
                        if (getattr(_tp_guard, "_flip_pending", False) or
                                getattr(_tp_guard, "_stop_triggered", False)):
                            _has_pending = True
                    # else: protección desarmada → tratar como pausa ordinaria → no bloquear
                    break
            if not _has_pending:
                self._sil_consec_above    = 0
                self._sil_release_start_t = None
                self._sil_in_silence      = False
                self._silence_start_t     = None
                if self._silence_autopause_active:
                    self._deactivate_silence_autopause()
    def _activate_silence_autopause(self):
        """
        Activa la auto-pausa por silencio.
        Congela la grabación (misma llamada que la pausa manual) pero
        rastrea el estado por separado.  Los paneles de cassette muestran
        el modo CAROLA TE ESTA ESPERANDO en lugar de BUSYCHAN.

        CRAC Failsafe: verifica cooldown (5 s) y límite de frecuencia (3/min)
        antes de activar. Ignora activación durante XRUN recovery,
        buffer stress, export blocking y callback overload.
        """
        if self._silence_autopause_active:
            return

        # ── CRAC Failsafe: condiciones de inhibición ──────────────────────────
        _now_fs = time.monotonic()

        # 1. Ignorar durante XRUN recovery
        if getattr(_status, "xrun_recovering", False):
            _log.debug("CRAC failsafe: omitiendo auto-pausa durante XRUN recovery")
            return

        # 2. Ignorar durante buffer stress (backpressure alta)
        _q_size  = getattr(_status, "queue_size", 0)
        _q_cap   = getattr(self._engine, "_rb_l1", None)
        if _q_cap is not None:
            try:
                _cap = _q_cap.maxsize if hasattr(_q_cap, "maxsize") else 256
                if _q_size >= int(_cap * 0.80):
                    _log.debug("CRAC failsafe: omitiendo auto-pausa — buffer stress")
                    return
            except Exception:
                pass

        # 3. Cooldown entre pausas (mínimo SILENCE_PAUSE_COOLDOWN_SECS)
        if (_now_fs - getattr(self, "_sil_last_pause_t", 0.0)
                < SILENCE_PAUSE_COOLDOWN_SECS):
            remaining = SILENCE_PAUSE_COOLDOWN_SECS - (_now_fs - self._sil_last_pause_t)
            _log.debug(
                "CRAC failsafe: cooldown activo (%.1f s restantes) — omitiendo auto-pausa",
                remaining)
            return

        # 4. Límite de frecuencia: máx. SILENCE_MAX_PAUSES_PER_MIN por minuto
        _pause_times = getattr(self, "_sil_pause_times", deque(maxlen=SILENCE_MAX_PAUSES_PER_MIN + 2))
        _cutoff      = _now_fs - SILENCE_PAUSE_RATE_WINDOW
        # OPT-PAUSE-DEQUE: deque acotado — solo descartar entradas antiguas del frente
        while _pause_times and _pause_times[0] <= _cutoff:
            _pause_times.popleft()
        if len(_pause_times) >= SILENCE_MAX_PAUSES_PER_MIN:
            _log.warning(
                "CRAC failsafe: límite de frecuencia alcanzado "
                "(%d pausas en los últimos %.0f s) — omitiendo auto-pausa",
                len(_pause_times), SILENCE_PAUSE_RATE_WINDOW)
            self._sil_pause_times = _pause_times
            return

        # ── Registrar pausa en el historial de frecuencia ────────────────────
        _pause_times.append(_now_fs)
        self._sil_pause_times  = _pause_times
        self._sil_last_pause_t = _now_fs
        # ─────────────────────────────────────────────────────────────────────

        self._silence_autopause_active = True
        # Overlay "SIPActiV" en el contómetro — calco exacto de CRAC
        # (GAP-010). Prioridad menor que "FnSide A"/"FnTape Aldh", así
        # que si esta activación es parte de un volteo, ese overlay la
        # tapa automáticamente (mismo árbol de prioridades que CRAC).
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("SIPA", True, "SIPACTIV")

        # FIX v0.22.24: capturar si el engine YA estaba pausado ANTES de pausarlo.
        # Si ya estaba pausado (pausa manual), NO acumular _rec_elapsed:
        # hacerlo acumularía el tiempo de pausa manual en el contometro → salto.
        # _now_fs ya fue capturado al inicio del método; reutilizarlo para que
        # el delta sea coherente y no incluya el tiempo de los failsafes.
        _engine_was_already_paused = self._engine.paused
        # Congelar el motor de captura igual que la pausa manual
        self._engine.pause(True)
        # Actualizar cronómetro SOLO si el engine estaba activo (no pausado).
        # Si ya estaba pausado: _rec_elapsed ya fue acumulado por quien lo pausó.
        if not _engine_was_already_paused:
            self._rec_elapsed += _now_fs - self._rec_start_t

        # Ajustar _drift_t0 para no generar drift cuando se reanude
        # (mismo mecanismo que el PATCH DRIFT-RESUME)
        # FIX v0.22.24: usar _now_fs (ya capturado) en lugar de _now eliminado.
        _frames_now = float(_status.frames_received)
        _rate = max(self._engine.rate, 1)
        self._drift_t0 = _now_fs - _frames_now / _rate
        self._drift_check_t = _now_fs
        _status.drift_ms      = 0.0
        _status.drift_ewma_ms = 0.0
        _status.drift_chronic = False
        _status.last_callback_t = 0.0

        # Activar modo CAROLA ESPERANDO en los paneles de cassette
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None),
                    getattr(self, "tape_otros", None)):
            if _tp is not None:
                _tp.activate_carola_waiting()

        # v0.20.4: notificar al StatusDisplay principal para que entre en el
        # modo carola_waiting con parpadeo gris↔amarillo sincronizado.
        # Sin esta llamada el StatusDisplay nunca recibía __CAROLA_WAITING__
        # y quedaba congelado en el último mensaje de captura.
        self.status_label.setText("__CAROLA_WAITING__")

        # v0.22.14: PC arranca visible (en fase con _cafe_blink_state=True inicial)
        # para que la animación del dibujo y la leyenda CAROLA ESPERANDO
        # parpadeen en sincronía desde el primer tick.
        if hasattr(self, "media_anim"):
            self.media_anim.setState("pause")
            self.media_anim.setBlink(True)

        # Iniciar timer de parpadeo
        self._carola_waiting_blink_timer.start()

        # firma='aiplo_frn_autopause_activated'
        if _AIPLO_FRN_ACTIVE:
            _aiplo_frn_counters["autopause_activated"] += 1
            _frn_emit("AIPLO_AUTOPAUSE_ACTIVATED", {
                "n"      : _aiplo_frn_counters["autopause_activated"],
                "elapsed": getattr(self, "_rec_elapsed", 0.0),
            }, crit=True)

        _log.info("CRAC auto-pausa activada (silencio ≥ %.0f s)",
                  SILENCE_AUTOPAUSE_SECS)
    def _deactivate_silence_autopause(self):
        """
        Desactiva la auto-pausa por silencio y reanuda la grabación.
        Solo se llama si la pausa fue iniciada por el silencio (no por el usuario).
        Si un TapeLogPanel tiene _flip_pending=True, activa lado B ahora.
        """
        if not self._silence_autopause_active:
            return
        self._silence_autopause_active = False
        self._silence_start_t = None
        self._sil_in_silence  = False
        self._sil_win_rms_sq  = 0.0
        self._sil_win_peak    = 0.0
        self._sil_win_ticks   = 0

        # Detener timer de parpadeo
        self._carola_waiting_blink_timer.stop()

        # firma='aiplo_frn_autopause_deactivated'
        if _AIPLO_FRN_ACTIVE:
            _aiplo_frn_counters["autopause_deactivated"] += 1
            _frn_emit("AIPLO_AUTOPAUSE_DEACTIVATED", {
                "n"      : _aiplo_frn_counters["autopause_deactivated"],
                "elapsed": getattr(self, "_rec_elapsed", 0.0),
            }, crit=True)

        # v0.22.14: restaurar PC a siempre-visible al reanudar
        if hasattr(self, "media_anim"):
            self.media_anim.setBlink(True)

        # Desactivar modo CAROLA ESPERANDO en los paneles
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None),
                    getattr(self, "tape_otros", None)):
            if _tp is not None:
                _tp.deactivate_carola_waiting()

        # FIX v0.22.28: reanudar el motor ANTES del bloque de volteo a Lado B.
        # Motivo: update_state() comprueba el bloque de auto-stop del Lado B solo
        # cuando active=True. Si el motor sigue pausado al procesar el volteo, el
        # tick inmediato llega con active=False y el bloque Lado B se saltea,
        # dejando _stop_triggered=False pero sin disparar on_auto_stop nunca.
        # Al reanudar aquí, el tick que sigue a _deactivate ya ve active=True.
        _now_resume = time.monotonic()
        self._rec_start_t = _now_resume
        _frames_now = float(_status.frames_received)
        _rate = max(self._engine.rate, 1)
        self._drift_t0 = _now_resume - _frames_now / _rate
        self._drift_check_t = _now_resume
        _status.drift_ms        = 0.0
        _status.drift_ewma_ms   = 0.0
        _status.drift_chronic   = False
        _status.last_callback_t = 0.0
        self._engine.pause(False)

        # ── Volteo lado B: si algún panel tiene _flip_pending, activar lado B ─
        # FIX v0.22.26: el volteo a Lado B ocurre en update_state() en el
        # mismo tick que detecta not autopause_active + _flip_pending.
        # _deactivate_silence_autopause solo reanuda el motor; update_state
        # verá autopause_active=False en el siguiente tick y ejecutará el
        # volteo (new_phase="B") de forma natural y coherente.
        # Este bloque actualiza únicamente los paneles que NO entren por la
        # ruta de update_state (p.ej. si el panel no está activo en ese tick).
        #
        # FIX-FLIP-B-DEACTIVATE (v0.22.46): cuando la pausa automática fue
        # activada por la RUTA 2 (audio activo llegó a flip_max →
        # _forced_pause_active=True + _flip_pending=True), update_state limpia
        # _forced_pause_active al detectar silencio en la pausa forzada, pero
        # en ese mismo tick autopause_active sigue siendo True, por lo que la
        # condición de confirmación (not autopause_active + not _forced_pause_active)
        # nunca se satisface en update_state. El volteo queda bloqueado y al
        # desactivar la auto-pausa no ocurre el flip.
        # SOLUCIÓN: limpiar _forced_pause_active antes de verificar _flip_pending
        # aquí, de modo que _deactivate sea siempre la ruta definitiva de volteo
        # independientemente de si update_state ya lo limpió o no. El volteo
        # se ejecuta si _flip_pending=True, sin restricción de _forced_pause_active.
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None)):
            if _tp is None:
                continue
            # Limpiar pausa forzada incondicionalmente al desactivar auto-pausa:
            # si el motor arrancó de nuevo es porque el silencio terminó y el
            # sistema decidió reanudar → _forced_pause_active ya no tiene sentido.
            _tp._forced_pause_active = False
            if not getattr(_tp, "_flip_pending", False):
                continue
            _active_txt = self.cassette_dur_box.currentText()
            if _tp._tape_label != _active_txt:
                continue
            # ── CRAC-MOTOR-v3: notificar desactivación de pausa ──────────────
            if getattr(_tp, "_crac_motor", None) is not None:
                _tp._crac_motor.notify_autopause_deactivated(_tp._elapsed)
                # Sincronizar estado del motor → TapeLogPanel
                _tp._flip_pending        = _tp._crac_motor.flip_pending
                _tp._flip_done           = _tp._crac_motor.flip_done
                _tp._forced_pause_active = _tp._crac_motor.forced_pause_active
                _tp._stop_triggered      = _tp._crac_motor.stop_triggered
                if _tp._crac_motor.query_counter_reset():
                    # firma='aiplo_frn_counter_reset'
                    if _AIPLO_FRN_ACTIVE:
                        _aiplo_frn_counters["counter_reset"] += 1
                        _frn_emit("AIPLO_COUNTER_RESET", {
                            "origin" : "_deactivate",
                            "panel"  : getattr(_tp, "_tape_label", "?"),
                            "elapsed": getattr(_tp, "_elapsed", 0.0),
                            "n"      : _aiplo_frn_counters["counter_reset"],
                        })
                    _tp._counter_base        = _tp._elapsed
                    _tp._counter             = 0
                    _tp._counter_final_value = 0
                    _tp._counter_surplus_b   = 0
                    _tp._counter_wrap_b_count = 0
                    _tp._counter_overflow    = False
                    _tp._wobble_phase        = 0.0
                    _tp._wobble_blink_vis    = True
                    _tp._forced_pause_active = False
                    # FIX-HUB-FLIP-RESET (v0.22.49): hubs vuelven a inicio de Lado A
                    _tp._angle1              = 0.0
                    _tp._angle2              = 0.0
                    _tp._mech_accum          = 0.0
                    _tp._mech_spool_ang      = 0.0
                    _tp._mech_digits         = [0.0, 0.0, 0.0]
                    _tp._mech_values         = [0, 0, 0]
                    _tp._mech_prev_cnt       = -1
                    _log.info(
                        "TapeLogPanel %s [v3] _deactivate: cuentavueltas → 000 "
                        "al voltear a Lado B",
                        _tp._tape_label)
                # Propagar fase si el motor ya confirmó el volteo
                if _tp._crac_motor.flip_done and not getattr(_tp, "_flip_pending", False):
                    _tp._phase = "B"
                    _tp._stop_triggered = False
                # FIX-DEACTIVATE-TOL-FLIP (v0.22.49): volteo de emergencia cuando
                # el motor CRACMotorV3 no confirmó el reset tras notify_autopause_deactivated.
                # Ocurre cuando la pausa automática se activó por silencio dentro de la
                # ventana de tolerancia del Lado A ([flip_min … flip_max]) y el motor
                # externo no procesó su tick de volteo antes de _deactivate.
                # Si _flip_pending sigue True aquí, el volteo no ocurrió por la ruta
                # normal → ejecutar volteo directo para garantizar el flip y el reset
                # del cuentavueltas a 000, tal como especifica el monolito C.R.A.C.
                if getattr(_tp, "_flip_pending", False):
                    # firma='aiplo_frn_emergency_flip'
                    if _AIPLO_FRN_ACTIVE:
                        _aiplo_frn_counters["emergency_flip"] += 1
                        _frn_emit("AIPLO_EMERGENCY_FLIP", {
                            "origin" : "TOL-FLIP",
                            "panel"  : getattr(_tp, "_tape_label", "?"),
                            "elapsed": getattr(_tp, "_elapsed", 0.0),
                            "n"      : _aiplo_frn_counters["emergency_flip"],
                            "stack"  : _frn_short_stack(),
                        }, crit=True)
                    _tp._flip_pending     = False
                    _tp._flip_done        = True
                    _tp._phase            = "B"
                    _tp._stop_triggered   = False
                    _tp._forced_pause_active = False
                    _tp._counter_base        = _tp._elapsed
                    _tp._counter             = 0
                    _tp._counter_final_value = 0
                    _tp._counter_surplus_b   = 0
                    _tp._counter_wrap_b_count = 0
                    _tp._counter_overflow    = False
                    _tp._wobble_phase        = 0.0
                    _tp._wobble_blink_vis    = True
                    # FIX-HUB-FLIP-RESET (v0.22.49): hubs vuelven a inicio de Lado A
                    _tp._angle1              = 0.0
                    _tp._angle2              = 0.0
                    _tp._mech_accum          = 0.0
                    _tp._mech_spool_ang      = 0.0
                    _tp._mech_digits         = [0.0, 0.0, 0.0]
                    _tp._mech_values         = [0, 0, 0]
                    _tp._mech_prev_cnt       = -1
                    if hasattr(_tp, "_transport") and _tp._transport is not None:
                        try:
                            _tp._transport.flip_side()
                        except Exception:
                            pass
                    _log.info(
                        "TapeLogPanel %s [v3] _deactivate TOL-FLIP: volteo de emergencia "
                        "a Lado B — cuentavueltas → 000 (motor no confirmó reset; "
                        "pausa desactivada dentro de ventana de tolerancia Lado A)",
                        _tp._tape_label)
            else:
                # Fallback legado para paneles sin CRACMotorV3 (p.ej. OTROS)
                _tp._flip_pending    = False
                _tp._flip_done       = True
                _tp._phase           = "B"
                _tp._stop_triggered  = False
                _tp._counter_overflow = False
                _tp._wobble_phase    = 0.0
                _tp._wobble_blink_vis = True
                _tp._counter_base    = _tp._elapsed
                # FIX-HUB-FLIP-RESET (v0.22.49): hubs vuelven a inicio de Lado A
                _tp._angle1          = 0.0
                _tp._angle2          = 0.0
                _tp._mech_accum      = 0.0
                _tp._mech_spool_ang  = 0.0
                _tp._mech_digits     = [0.0, 0.0, 0.0]
                _tp._mech_values     = [0, 0, 0]
                _tp._mech_prev_cnt   = -1
                _log.info(
                    "TapeLogPanel %s [legado]: volteo a Lado B en _deactivate",
                    _tp._tape_label)

        # ── FIX-DEACTIVATE-STOP-B (v0.22.49): detención de emergencia Lado B ───
        # Si algún panel tiene _stop_triggered=True y fase B, es porque el motor
        # CRACMotorV3 debería haber llamado on_auto_stop() pero no lo hizo antes
        # de que la auto-pausa fuera desactivada (misma desincronía que FIX-DEACTIVATE-
        # TOL-FLIP pero para el fin de Lado B en lugar del volteo Lado A→B).
        # En este caso se llama on_auto_stop() manualmente via QTimer.singleShot(0)
        # para no interrumpir el flujo de _deactivate mientras el motor se reanuda.
        # Aplica a C-60 y C-90 (los únicos con motor CRACMotorV3 y Lado B definido).
        _active_txt_stop = self.cassette_dur_box.currentText()
        for _tp_stop in (getattr(self, "tape_c60", None),
                         getattr(self, "tape_c90", None)):
            if _tp_stop is None:
                continue
            if _tp_stop._tape_label != _active_txt_stop:
                continue
            if (getattr(_tp_stop, "_stop_triggered", False) and
                    getattr(_tp_stop, "_phase", "A") == "B"):
                _cb_stop = getattr(_tp_stop, "on_auto_stop", None)
                if callable(_cb_stop):
                    # firma='aiplo_frn_emergency_stop'
                    if _AIPLO_FRN_ACTIVE:
                        _aiplo_frn_counters["emergency_stop"] += 1
                        _frn_emit("AIPLO_EMERGENCY_STOP", {
                            "origin" : "STOP-B",
                            "panel"  : getattr(_tp_stop, "_tape_label", "?"),
                            "elapsed": getattr(_tp_stop, "_elapsed", 0.0),
                            "n"      : _aiplo_frn_counters["emergency_stop"],
                            "stack"  : _frn_short_stack(),
                        }, crit=True)
                    _log.info(
                        "TapeLogPanel %s [v3] _deactivate STOP-B: detención de "
                        "emergencia Lado B (motor no disparó on_auto_stop; "
                        "_stop_triggered=True en deactivate)",
                        _tp_stop._tape_label)
                    QTimer.singleShot(0, _cb_stop)

        _log.info("CRAC auto-pausa desactivada — grabación reanudada (%d ticks ≈ %.0f ms)",
                  SILENCE_RELEASE_MIN_TICKS,
                  SILENCE_RELEASE_MIN_TICKS * SILENCE_ANALYSIS_INTERVAL_MS)
        # Overlay: se limpia incondicionalmente al desactivar la auto-pausa
        # — cubre tanto el volteo a Lado B recién resuelto (arriba, "FnSide
        # A") como cualquier "FnTape Aldh" que ya no aplique (ver GAP-010).
        # No-op si no había overlay activo.
        if hasattr(self, "clock"):
            self.clock.setOverlay("ITL", False)
            self.clock.setOverlay("FN_TAPE_ALDH", False)
            self.clock.setOverlay("SIPA", False)
            # "Side B" — calco exacto de CRAC: confirmación transitoria (4s)
            # tras completarse un volteo. Se dispara aquí porque es el punto
            # único donde TODAS las rutas de resolución de flip (motor
            # confirmado / emergencia / fallback legado) ya convergieron.
            _active_lbl_side = self.cassette_dur_box.currentText()
            for _tp_side in (getattr(self, "tape_c60", None),
                             getattr(self, "tape_c90", None),
                             getattr(self, "tape_otros", None)):
                if (_tp_side is not None and _tp_side._tape_label == _active_lbl_side
                        and getattr(_tp_side, "_phase", "A") == "B"):
                    self.clock.setOverlayFromRegistry("SIDE_MSG", True, "SIDE_B")
                    QTimer.singleShot(4000, lambda: self.clock.setOverlay("SIDE_MSG", False))
                    break
        # v0.20.4: restaurar StatusDisplay explícitamente al estado de captura.
        # Sin esta línea, el StatusDisplay quedaba en nivel "carola_waiting"
        # mostrando "¡OYE VEN…!" incluso después de reanudar la grabación.
        self.status_label.setText(
            f"LORITO VA GRABANDO - {self._engine.rate} Hz")
    def _on_carola_waiting_blink(self):
        """Tick del timer de parpadeo del modo CAROLA TE ESTA ESPERANDO.
        Avanza la fase de parpadeo en los TapeLogPanels, StatusDisplay y MediaAnimWidget.
        v0.20.4: se añade __PAUSE_CAFE_TICK__ al StatusDisplay para que su
        _cafe_blink_state alterne en cada tick — sin esto el StatusDisplay
        quedaba congelado en _cafe_blink_state=True y no parpadeaba.
        v0.22.14: MediaAnimWidget se sincroniza con el mismo tick para que el
        dibujo de la PC y la leyenda CAROLA ESPERANDO parpadeen en perfecta fase.
        FIX-OVERFLOW-BLINK-SYNC (v0.22.49): tick_overflow_blink() se llama aquí
        para que "TU CINTA ES MUY LARGA... UPS!!" parpadee al mismo ritmo (480 ms)
        que la leyenda de pausa automática del StatusDisplay.
        """
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None),
                    getattr(self, "tape_otros", None)):
            if _tp is not None:
                _tp.tick_carola_blink()
                _tp.tick_overflow_blink()   # FIX-OVERFLOW-BLINK-SYNC (v0.22.49)
        # Tick al StatusDisplay para sincronizar su ciclo gris↔amarillo
        self.status_label.setText("__PAUSE_CAFE_TICK__")
        # Sincronizar MediaAnimWidget: _cafe_blink_state ya fue alternado
        # por setText("__PAUSE_CAFE_TICK__"); aplicamos ese valor a la PC.
        if hasattr(self, "media_anim"):
            self.media_anim.setBlink(self.status_label._cafe_blink_state)
        # FIX-OVERLAY-BLINK-AUTOSUFICIENTE: DigitalClock ya trae su
        # propio QTimer interno de 480ms para el parpadeo de overlay
        # (ver `lorito_indicators.py::DigitalClock.__init__`) — la
        # llamada externa a `tickITLOverlayBlink()` se retiró de aquí
        # para no duplicar el parpadeo (dos timers de 480ms desfasados
        # producirían un parpadeo real de ~240ms mientras la auto-pausa
        # estuviera activa).
    def _on_overflow_blink_tick(self):
        """Tick del timer de parpadeo de desbordamiento (480 ms).
        FIX-OVERFLOW-BLINK-SYNC (v0.22.49): llamado por _overflow_blink_timer cuando
        hay desbordamiento activo pero NO hay auto-pausa (la grabación sigue corriendo).
        Cuando hay auto-pausa + overflow, _carola_waiting_blink_timer ya llama
        tick_overflow_blink() — ambos timers pueden coexistir sin duplicar el parpadeo
        porque tick_overflow_blink() solo actúa si _counter_overflow=True."""
        for _tp in (getattr(self, "tape_c60", None),
                    getattr(self, "tape_c90", None),
                    getattr(self, "tape_otros", None)):
            if _tp is not None:
                _tp.tick_overflow_blink()
        # FIX-OVERLAY-BLINK-AUTOSUFICIENTE: el overlay "OvFlow TP" del
        # contómetro ya parpadea solo, vía el QTimer interno de
        # DigitalClock — ver nota equivalente en
        # `_on_carola_waiting_blink()`.
    def _show_fnc_no_disp(self):
        """
        Muestra "Fnc No Disp" en el contómetro (calco exacto de CRAC,
        prioridad absoluta — GAP-010). Punto único de entrada para
        cualquier control que no tenga una función real todavía (p. ej.
        el botón ACERCA de la barra de menú, o cualquier entrada de menú
        sin backend cableado). Duración y mecanismo de reinicio
        corregidos en esta sesión tras auditar `showFncNoDisp()` en
        CRAC: 4 segundos (no 1.5s) vía un QTimer persistente
        stop()+start() — clics repetidos reinician el cronómetro en vez
        de apilar temporizadores sueltos (mismo criterio ya aplicado al
        overlay del Scrub Velocista, que replica este mecanismo).
        """
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("FNC_NO_DISP", True, "FNC_NO_DISP")
            if not hasattr(self, "_fnc_no_disp_timer"):
                self._fnc_no_disp_timer = QTimer(self)
                self._fnc_no_disp_timer.setSingleShot(True)
                self._fnc_no_disp_timer.timeout.connect(
                    lambda: self.clock.setOverlay("FNC_NO_DISP", False))
            self._fnc_no_disp_timer.stop()
            self._fnc_no_disp_timer.start(4000)
