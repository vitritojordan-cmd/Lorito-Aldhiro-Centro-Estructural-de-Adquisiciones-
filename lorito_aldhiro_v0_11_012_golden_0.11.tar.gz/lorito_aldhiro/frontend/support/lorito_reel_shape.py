from __future__ import annotations

"""
lorito_reel_shape.py — formas vectoriales del LCD Display (0.11.011):
el carrete de cassette de la usuaria y el corazón.

El carrete reproduce la imagen entregada por la usuaria (1600×1600 px,
disco de radio 690 px centrado en (800, 803)), medida y pasada a
coordenadas unitarias (radio exterior = 1, centro en el origen, eje Y hacia
abajo como en Qt):

- aro exterior entre r = 0.739 y r = 1, con 6 ventanas trapezoidales
  (r 0.78…0.90) a 34°, 90°, 146°, 214°, 270° y 326°;
- gancho de la cinta (círculo abierto y su tirante) calado en el aro;
- anillo interior entre r = 0.475 y r = 0.536;
- 6 dientes del hub (r 0.30…0.50) a 30°, 90°, 150°, 210°, 270° y 330°.

Al ser vectorial se dibuja con antialiasing a cualquier tamaño, sin el
escalonado que deja reducir un mapa de bits, y gira limpio.

Las operaciones booleanas de QPainterPath aplanan las curvas con una
tolerancia absoluta: por eso la forma se construye a escala `_BUILD` (radio
1000) y después se reduce a radio 1; construida directamente a radio 1, los
círculos salían octogonales.
"""

import math

from PySide6.QtCore import QPointF, QRectF
from PySide6.QtGui import QPainterPath, QPainterPathStroker, QPolygonF, QTransform

_SLOT_ANGLES = (34.0, 90.0, 146.0, 214.0, 270.0, 326.0)
_TOOTH_ANGLES = (30.0, 90.0, 150.0, 210.0, 270.0, 330.0)

_shape_cache: dict[str, QPainterPath] = {}
_BUILD = 1000.0


def _pt(r: float, deg: float) -> QPointF:
    """Punto en coordenadas polares (ángulo matemático, Y de Qt hacia abajo),
    a la escala de construcción."""
    a = math.radians(deg)
    return QPointF(_BUILD * r * math.cos(a), -_BUILD * r * math.sin(a))


def _disc(r: float) -> QPainterPath:
    p = QPainterPath()
    p.addEllipse(QPointF(0.0, 0.0), _BUILD * r, _BUILD * r)
    return p


def reel_path() -> QPainterPath:
    """Silueta del carrete (radio 1, centrada en el origen)."""
    if "reel" in _shape_cache:
        return _shape_cache["reel"]
    shape = _disc(1.0).subtracted(_disc(0.739))
    # Ventanas del aro exterior: trapecios, más anchos hacia afuera.
    for ang in _SLOT_ANGLES:
        slot = QPainterPath()
        slot.addPolygon(QPolygonF([
            _pt(0.902, ang - 10.6), _pt(0.902, ang + 10.6),
            _pt(0.780, ang + 9.4), _pt(0.780, ang - 9.4)]))
        slot.closeSubpath()
        shape = shape.subtracted(slot)
    # Gancho de la cinta: círculo abierto + tirante hasta el borde del aro.
    hc = _pt(0.869, 61.6)
    hr = 0.055 * _BUILD
    hook = QPainterPath()
    rect = QRectF(hc.x() - hr, hc.y() - hr, 2 * hr, 2 * hr)
    hook.arcMoveTo(rect, -107.0)
    hook.arcTo(rect, -107.0, -311.0)
    attach = QPointF(hc.x() + hr * math.cos(math.radians(-107.0)),
                     hc.y() - hr * math.sin(math.radians(-107.0)))
    hook.moveTo(attach)
    hook.lineTo(_pt(0.735, 63.6))
    stroker = QPainterPathStroker()
    stroker.setWidth(0.026 * _BUILD)
    shape = shape.subtracted(stroker.createStroke(hook))
    # Anillo interior y dientes del hub.
    shape = shape.united(_disc(0.536).subtracted(_disc(0.475)))
    for ang in _TOOTH_ANGLES:
        tooth = QPainterPath()
        tooth.addRect(QRectF(0.300 * _BUILD, -0.0775 * _BUILD, 0.200 * _BUILD, 0.155 * _BUILD))
        t = QTransform()
        t.rotate(-ang)
        shape = shape.united(t.map(tooth))
    shape = QTransform.fromScale(1.0 / _BUILD, 1.0 / _BUILD).map(shape)
    _shape_cache["reel"] = shape
    return shape


def heart_path() -> QPainterPath:
    """Corazón (caja unitaria centrada en el origen: ancho 1, alto ≈ 0.9)."""
    if "heart" in _shape_cache:
        return _shape_cache["heart"]
    p = QPainterPath()
    p.moveTo(0.0, 0.45)
    p.cubicTo(-0.16, 0.30, -0.50, 0.10, -0.50, -0.17)
    p.cubicTo(-0.50, -0.36, -0.36, -0.45, -0.24, -0.45)
    p.cubicTo(-0.11, -0.45, -0.03, -0.37, 0.0, -0.28)
    p.cubicTo(0.03, -0.37, 0.11, -0.45, 0.24, -0.45)
    p.cubicTo(0.36, -0.45, 0.50, -0.36, 0.50, -0.17)
    p.cubicTo(0.50, 0.10, 0.16, 0.30, 0.0, 0.45)
    p.closeSubpath()
    _shape_cache["heart"] = p
    return p
