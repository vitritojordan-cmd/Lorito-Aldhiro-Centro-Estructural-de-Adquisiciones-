from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Pieles SVG del lienzo (madera, Metaloric Panel, LCD Display, Panascrub, vúmetros).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

lorito_svg_skins.py — pieles SVG entregadas por la usuaria (0.11.008).

Cada función devuelve el SVG ORIGINAL de la usuaria adaptado al tamaño
real del widget de Lorito Aldhiro y a sus leyendas (no estirado: las
medidas físicas —tornillos, biseles, ranuras, perillas— se conservan en
píxeles y solo se recalcula la posición). Las partes DINÁMICAS (segmentos
del vúmetro, dígitos y leyendas del LCD, perillas de los scrubs, forma de
onda) se pintan encima con QPainter usando la misma paleta.

Correspondencias (pedido de la usuaria):
  · fondo de madera          → lienzo completo (`svg_wood_canvas`)
  · Metaloric Panel          → Vitreous Panel de CRAC → bloque visor de
                               señal + panel de estado + duración de cinta
  · LCD Display              → VFD de CRAC → contómetro + LED + botones
  · Panascrub                → placa con los 3 Scrubs (Escaneo, Torcedura,
                               Velocista)
  · vúmetros (peak meter)    → REC VU / PLAY VU

Qt renderiza SVG Tiny 1.2 (QtSvg): NO soporta `<filter>` (desenfoque,
sombra). Las sombras y resplandores de los SVG originales se emulan con
capas semitransparentes en el propio SVG o con QPainter; ningún template
contiene `<filter>` (lo verifica `tests/test_svg_skins.py`).

QtSvg se importa de forma diferida: los tests sin PySide6 real (stubs)
pueden importar este módulo y validar los SVG como XML.
"""

from xml.sax.saxutils import escape as _esc

# ── Paletas (tomadas literalmente de los SVG de la usuaria) ─────────────────
CYAN = "#00ffcc"            # LEDs / iconos / perillas
RED = "#ff2200"             # REC / pico
ORANGE = "#ff6600"
AMBER = "#ffb020"
LCD_INK = "#121008"         # tinta del LCD ámbar
LCD_INK_RGB = (0x12, 0x10, 0x08)
META_GREEN = "#00ffaa"      # tinta del Metaloric Panel
META_GREEN_RGB = (0x00, 0xff, 0xaa)
META_BOX = "#001a0d"
PLATE_TEXT = "#a0aec0"      # leyendas grabadas en aluminio
PLATE_TEXT_DIM = "#68727c"
SCALE_TEXT = "#55606c"


def _f(v: float) -> str:
    return f"{v:.2f}".rstrip("0").rstrip(".")


# ── Bloques reutilizables ────────────────────────────────────────────────────
_METAL_DEFS = """
    <linearGradient id="metalPlate" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#1a1c1e"/><stop offset="20%" stop-color="#2c3034"/>
      <stop offset="50%" stop-color="#383d42"/><stop offset="80%" stop-color="#2c3034"/>
      <stop offset="100%" stop-color="#16181a"/>
    </linearGradient>
    <radialGradient id="screwGrad" cx="30%" cy="30%" r="70%">
      <stop offset="0%" stop-color="#dfdfdf"/><stop offset="50%" stop-color="#8c9298"/>
      <stop offset="100%" stop-color="#404448"/>
    </radialGradient>"""


def _metal_plate(w: float, h: float, rx: float = 10) -> str:
    """Placa de aluminio cepillado + bisel (cuerpo de todos los paneles
    metálicos de la usuaria)."""
    return (f'<rect x="1" y="1" width="{_f(w-2)}" height="{_f(h-2)}" rx="{_f(rx)}" '
            f'fill="url(#metalPlate)" stroke="#0d0e10" stroke-width="2"/>'
            f'<rect x="2" y="2" width="{_f(w-4)}" height="{_f(h-4)}" rx="{_f(rx-1)}" '
            f'fill="none" stroke="#ffffff" stroke-width="1" opacity="0.12"/>')


def _screws(points, r: float = 4.5) -> str:
    out = ['<g fill="url(#screwGrad)">']
    for (cx, cy) in points:
        out.append(f'<circle cx="{_f(cx)}" cy="{_f(cy)}" r="{_f(r)}"/>')
    for (cx, cy) in points:
        d = r * 0.45
        out.append(f'<line x1="{_f(cx-d)}" y1="{_f(cy-d)}" x2="{_f(cx+d)}" y2="{_f(cy+d)}" '
                   f'stroke="#222" stroke-width="1.2"/>')
    out.append("</g>")
    return "".join(out)


def _corner_screws(w, h, inset=15.0, r=4.5):
    return _screws([(inset, inset), (w - inset, inset), (inset, h - inset), (w - inset, h - inset)], r)


def _svg(w, h, defs, body) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {_f(w)} {_f(h)}" '
            f'width="{_f(w)}" height="{_f(h)}"><defs>{defs}</defs>{body}</svg>')


# ═════════════════════════════════════════════════════════════════════════════
#  1. Fondo de madera del lienzo
# ═════════════════════════════════════════════════════════════════════════════
def svg_wood_canvas(w: int, h: int) -> str:
    sx, sy = w / 860.0, h / 320.0          # el gabinete original mide 860×320
    defs = """
    <linearGradient id="woodBase" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#3b1c0c"/><stop offset="25%" stop-color="#542813"/>
      <stop offset="50%" stop-color="#2d1508"/><stop offset="75%" stop-color="#4a220f"/>
      <stop offset="100%" stop-color="#261106"/>
    </linearGradient>
    <linearGradient id="woodGrain" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.03"/>
      <stop offset="20%" stop-color="#000000" stop-opacity="0.25"/>
      <stop offset="40%" stop-color="#ffffff" stop-opacity="0.02"/>
      <stop offset="70%" stop-color="#000000" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0.04"/>
    </linearGradient>
    <linearGradient id="woodGloss" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.22"/>
      <stop offset="15%" stop-color="#ffffff" stop-opacity="0.08"/>
      <stop offset="30%" stop-color="#ffffff" stop-opacity="0.0"/>
      <stop offset="85%" stop-color="#000000" stop-opacity="0.0"/>
      <stop offset="100%" stop-color="#000000" stop-opacity="0.45"/>
    </linearGradient>"""

    def X(v):
        return _f((v - 20) * sx)

    def Y(v):
        return _f((v - 20) * sy)

    burl1 = f"M {X(20)} {Y(120)} Q {X(250)} {Y(80)} {X(450)} {Y(140)} T {X(880)} {Y(100)}"
    burl2 = f"M {X(20)} {Y(220)} Q {X(350)} {Y(280)} {X(600)} {Y(200)} T {X(880)} {Y(240)}"
    body = [
        f'<rect x="0" y="0" width="{w}" height="{h}" fill="#120803"/>',
        f'<rect x="0" y="0" width="{w}" height="{h}" rx="14" fill="url(#woodBase)"/>',
        f'<rect x="0" y="0" width="{w}" height="{h}" rx="14" fill="url(#woodGrain)"/>',
        f'<path d="{burl1}" fill="none" stroke="#210c04" stroke-width="{_f(35*sy)}" opacity="0.4"/>',
        f'<path d="{burl2}" fill="none" stroke="#673216" stroke-width="{_f(25*sy)}" opacity="0.25"/>',
        f'<rect x="0" y="0" width="{w}" height="{h}" rx="14" fill="url(#woodGloss)"/>',
        f'<rect x="12" y="12" width="{w-24}" height="{h-24}" rx="10" fill="none" stroke="#180a04" '
        f'stroke-width="4" opacity="0.9"/>',
        f'<rect x="10" y="10" width="{w-20}" height="{h-20}" rx="12" fill="none" stroke="#6c3619" '
        f'stroke-width="2" opacity="0.4"/>',
    ]
    # Escuadras de latón (tamaño físico original: 25 px de ala)
    W, H = w, h
    br = [
        ("M 0 25 L 0 6 C 0 2 2 0 6 0 L 25 0 L 25 12 L 12 12 L 12 25 Z", 7, 7),
        (f"M {W} 25 L {W} 6 C {W} 2 {W-2} 0 {W-6} 0 L {W-25} 0 L {W-25} 12 L {W-12} 12 "
         f"L {W-12} 25 Z", W - 7, 7),
        (f"M 0 {H-25} L 0 {H-6} C 0 {H-2} 2 {H} 6 {H} L 25 {H} L 25 {H-12} L 12 {H-12} "
         f"L 12 {H-25} Z", 7, H - 7),
        (f"M {W} {H-25} L {W} {H-6} C {W} {H-2} {W-2} {H} {W-6} {H} L {W-25} {H} L {W-25} {H-12} "
         f"L {W-12} {H-12} L {W-12} {H-25} Z", W - 7, H - 7),
    ]
    for d, cx, cy in br:
        body.append(f'<path d="{d}" fill="#c29b38"/>'
                    f'<circle cx="{cx}" cy="{cy}" r="2.5" fill="#594314"/>')
    return _svg(w, h, defs, "".join(body))


# ═════════════════════════════════════════════════════════════════════════════
#  2. Vúmetro (peak meter) — REC VU / PLAY VU
# ═════════════════════════════════════════════════════════════════════════════
def peak_meter_geometry(w: int, h: int) -> dict:
    """Geometría compartida entre la placa SVG estática y los segmentos
    dinámicos (QPainter)."""
    win_w = round(w * 0.25)
    gap = max(14, round(w * 0.075))
    lx = (w - gap) / 2 - win_w
    rx = (w + gap) / 2
    win_y = 54
    win_h = h - win_y - 34
    seg_top = win_y + 22
    seg_bot = win_y + win_h - 8
    pitch = 14.0
    n = max(10, int((seg_bot - seg_top) // pitch))
    pitch = (seg_bot - seg_top) / n
    return {"win_w": win_w, "lx": lx, "rx": rx, "win_y": win_y, "win_h": win_h,
            "seg_top": seg_top, "pitch": pitch, "n": n, "seg_h": pitch * 6 / 14,
            "seg_inset": 4, "db_floor": -60.0}


PEAK_SCALE_DB = (0, -6, -12, -18, -24, -30, -40, -50, -60)


def segment_db(i: int, n: int, floor: float = -60.0) -> float:
    """Umbral inferior (dBFS) del segmento i (0 = arriba)."""
    return floor * (i + 1) / n


def segment_color(i: int, n: int, floor: float = -60.0) -> str:
    db = floor * (i + 0.5) / n
    if db > -3:
        return RED
    if db > -6:
        return ORANGE
    if db > -18:
        return AMBER
    return CYAN


def svg_peak_meter(w: int, h: int, title: str, subtitle: str = "dBFS · L / R") -> str:
    g = peak_meter_geometry(w, h)
    defs = _METAL_DEFS + """
    <linearGradient id="glassWindow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#080c10" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#141c24" stop-opacity="0.90"/>
    </linearGradient>"""
    cx = w / 2
    body = [_metal_plate(w, h), _corner_screws(w, h),
            f'<text x="{_f(cx)}" y="26" font-family="monospace" font-size="9" font-weight="bold" '
            f'fill="{PLATE_TEXT}" text-anchor="middle" letter-spacing="2">{_esc(title)}</text>',
            f'<text x="{_f(cx)}" y="39" font-family="monospace" font-size="7" fill="{PLATE_TEXT_DIM}" '
            f'text-anchor="middle" letter-spacing="1">{_esc(subtitle)}</text>']
    for x, ch in ((g["lx"], "L"), (g["rx"], "R")):
        # sombra de encastre (emula insetShadow del original)
        body.append(f'<rect x="{_f(x)}" y="{_f(g["win_y"]+3)}" width="{g["win_w"]}" '
                    f'height="{_f(g["win_h"])}" rx="5" fill="#000000" opacity="0.45"/>')
        body.append(f'<rect x="{_f(x)}" y="{_f(g["win_y"])}" width="{g["win_w"]}" '
                    f'height="{_f(g["win_h"])}" rx="5" fill="url(#glassWindow)" stroke="#1f2832" '
                    f'stroke-width="1.5"/>')
        body.append(f'<text x="{_f(x + g["win_w"]/2)}" y="{_f(g["win_y"]+14)}" font-family="monospace" '
                    f'font-size="8" fill="#88929c" text-anchor="middle">{ch}</text>')
    body.append(f'<g font-family="monospace" font-size="6" fill="{SCALE_TEXT}" text-anchor="middle">')
    span = g["n"] * g["pitch"]
    for db in PEAK_SCALE_DB:
        y = g["seg_top"] + (db / g["db_floor"]) * span
        body.append(f'<text x="{_f(cx)}" y="{_f(y + 2)}">{db}</text>')
    body.append("</g>")
    return _svg(w, h, defs, "".join(body))


# ═════════════════════════════════════════════════════════════════════════════
#  3. LCD Display — placa frontal, LCD ámbar y botones
# ═════════════════════════════════════════════════════════════════════════════
def svg_faceplate(w: int, h: int, title: str = "") -> str:
    """Placa de aluminio que aloja el LED, el LCD y los botones de
    transporte (marco del SVG del LCD Display)."""
    # Tornillos en el filo del bisel (inset 6): la placa aloja los
    # botones casi de borde a borde y un inset mayor los taparía.
    body = [_metal_plate(w, h), _corner_screws(w, h, inset=6, r=3.5)]
    if title:
        body.append(f'<text x="{_f(w/2)}" y="16" font-family="monospace" font-size="9" '
                    f'font-weight="bold" fill="{PLATE_TEXT}" text-anchor="middle" '
                    f'letter-spacing="4">{_esc(title)}</text>')
    return _svg(w, h, _METAL_DEFS, "".join(body))


def svg_lcd_screen(w: int, h: int) -> str:
    """Encastre + pantalla LCD ámbar con textura de matriz (sin tinta:
    las leyendas y dígitos de Lorito se pintan encima)."""
    defs = """
    <linearGradient id="lcdBg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#e2c45b"/><stop offset="50%" stop-color="#d4b242"/>
      <stop offset="100%" stop-color="#c49f32"/>
    </linearGradient>"""
    body = [f'<rect x="1" y="3" width="{w-2}" height="{h-3}" rx="7" fill="#000000" opacity="0.5"/>',
            f'<rect x="1" y="1" width="{w-2}" height="{h-2}" rx="7" fill="#080a0c" stroke="#181c20" '
            f'stroke-width="2"/>',
            f'<rect x="4" y="4" width="{w-8}" height="{h-8}" rx="5" fill="url(#lcdBg)"/>',
            '<g opacity="0.08" stroke="#000000" stroke-width="0.5">']
    y = 4 + 20
    while y < h - 4:
        body.append(f'<line x1="4" y1="{y}" x2="{w-4}" y2="{y}"/>')
        y += 20
    x = 4 + 50
    while x < w - 4:
        body.append(f'<line x1="{x}" y1="4" x2="{x}" y2="{h-4}"/>')
        x += 50
    body.append("</g>")
    return _svg(w, h, defs, "".join(body))


def svg_lcd_glass(w: int, h: int) -> str:
    """Cubierta de vidrio con brillo y reflejo (se pinta POR ENCIMA del
    contenido del LCD)."""
    defs = """
    <linearGradient id="glassGloss" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.45"/>
      <stop offset="25%" stop-color="#ffffff" stop-opacity="0.15"/>
      <stop offset="45%" stop-color="#ffffff" stop-opacity="0.0"/>
      <stop offset="80%" stop-color="#000000" stop-opacity="0.0"/>
      <stop offset="100%" stop-color="#000000" stop-opacity="0.3"/>
    </linearGradient>"""
    body = (f'<rect x="4" y="4" width="{w-8}" height="{h-8}" rx="5" fill="url(#glassGloss)"/>'
            f'<line x1="6" y1="5" x2="{w-6}" y2="5" stroke="#ffffff" stroke-width="1.2" opacity="0.6"/>'
            f'<polygon points="4,4 {_f(4 + (w-8)*0.34)},4 4,{_f(4 + (h-8)*0.79)}" fill="#ffffff" '
            f'opacity="0.12"/>')
    return _svg(w, h, defs, body)


def svg_transport_button(w: int, h: int, pressed: bool = False) -> str:
    defs = """
    <linearGradient id="buttonGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#3a4046"/><stop offset="30%" stop-color="#2c3034"/>
      <stop offset="70%" stop-color="#1e2226"/><stop offset="100%" stop-color="#141618"/>
    </linearGradient>
    <linearGradient id="buttonGradP" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#141618"/><stop offset="40%" stop-color="#1e2226"/>
      <stop offset="100%" stop-color="#2c3034"/>
    </linearGradient>"""
    off = 1 if pressed else 0
    fill = "url(#buttonGradP)" if pressed else "url(#buttonGrad)"
    body = (f'<rect x="1" y="{3 - off}" width="{w-2}" height="{h-4}" rx="6" fill="#000000" '
            f'opacity="{0.35 if pressed else 0.6}"/>'
            f'<rect x="1" y="{1 + off}" width="{w-2}" height="{h-4}" rx="6" fill="{fill}" '
            f'stroke="#111" stroke-width="1.5"/>'
            f'<rect x="3" y="{3 + off}" width="{w-6}" height="{h-8}" rx="5" fill="none" '
            f'stroke="#ffffff" stroke-width="1" opacity="0.08"/>')
    return _svg(w, h, defs, body)


# ═════════════════════════════════════════════════════════════════════════════
#  4. Panascrub — placa con los Scrubs
# ═════════════════════════════════════════════════════════════════════════════
def svg_panascrub_plate(w: int, h: int, legends) -> str:
    """`legends`: lista de (texto, y_baseline) — leyendas de Lorito
    grabadas en la placa (CONTROL DE ESCANEO / TORCEDURA / VELOCISTA)."""
    body = [_metal_plate(w, h), _corner_screws(w, h, inset=14, r=4)]
    for text, y in legends:
        body.append(f'<text x="{_f(w/2)}" y="{_f(y)}" font-family="monospace" font-size="8" '
                    f'font-weight="bold" fill="{PLATE_TEXT}" text-anchor="middle" '
                    f'letter-spacing="2">{_esc(text)}</text>')
    return _svg(w, h, _METAL_DEFS, "".join(body))


def svg_slider_slot(w: int, h: int = 8) -> str:
    return _svg(w, h + 4, "", (
        f'<rect x="1" y="3" width="{w-2}" height="{h}" rx="4" fill="#000000" opacity="0.6"/>'
        f'<rect x="1" y="1" width="{w-2}" height="{h}" rx="4" fill="#090b0d" stroke="#181c20" '
        f'stroke-width="1.5"/>'
        f'<line x1="4" y1="2" x2="{w-4}" y2="2" stroke="#000000" stroke-width="1"/>'))


def svg_slider_knob(w: int, h: int) -> str:
    defs = """
    <linearGradient id="knobGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#4a5056"/><stop offset="25%" stop-color="#32383c"/>
      <stop offset="75%" stop-color="#1e2226"/><stop offset="100%" stop-color="#121416"/>
    </linearGradient>"""
    gx = w / 2 - 1.5
    body = (f'<rect x="1" y="3" width="{w-2}" height="{h-3}" rx="4" fill="#000000" opacity="0.55"/>'
            f'<rect x="1" y="1" width="{w-2}" height="{h-3}" rx="4" fill="url(#knobGrad)" '
            f'stroke="#0a0c0e" stroke-width="1.5"/>'
            f'<rect x="2" y="2" width="{w-4}" height="{_f((h-3)*0.46)}" rx="3" fill="#ffffff" '
            f'opacity="0.08"/>'
            f'<rect x="{_f(gx)}" y="4" width="3" height="{h-10}" rx="1" fill="#121416" '
            f'stroke="#080a0c" stroke-width="0.5"/>')
    return _svg(w, h, defs, body)


# ═════════════════════════════════════════════════════════════════════════════
#  5. Metaloric Panel (Vitreous Panel de CRAC)
# ═════════════════════════════════════════════════════════════════════════════
METALORIC_BEZEL = 10


def svg_metaloric_panel(w: int, h: int) -> str:
    """Biseles metálicos superior/inferior + vidrio oscuro con
    retroiluminación verde de canto (sin el brillo, que va encima)."""
    B = METALORIC_BEZEL
    gy0, gh = B, h - 2 * B
    defs = """
    <linearGradient id="thinMetalBezel" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#16181a"/><stop offset="25%" stop-color="#2c3034"/>
      <stop offset="50%" stop-color="#3c4248"/><stop offset="75%" stop-color="#2c3034"/>
      <stop offset="100%" stop-color="#16181a"/>
    </linearGradient>
    <linearGradient id="glassBody" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#0a120e" stop-opacity="0.85"/>
      <stop offset="100%" stop-color="#050a08" stop-opacity="0.90"/>
    </linearGradient>
    <radialGradient id="greenEdgeGlow" cx="85%" cy="50%" r="65%">
      <stop offset="0%" stop-color="#00ff88" stop-opacity="0.9"/>
      <stop offset="40%" stop-color="#00cc66" stop-opacity="0.5"/>
      <stop offset="80%" stop-color="#004422" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#001108" stop-opacity="0.0"/>
    </radialGradient>"""
    wave = (f"M 0 {_f(gy0 + gh*0.5)} Q {_f(w*0.27)} {_f(gy0 + gh*0.07)} {_f(w*0.59)} "
            f"{_f(gy0 + gh*0.5)} T {_f(w)} {_f(gy0 + gh*0.33)}")
    body = [
        f'<rect x="0" y="4" width="{w}" height="{h-4}" rx="4" fill="#000000" opacity="0.6"/>',
        f'<rect x="0" y="{gy0}" width="{w}" height="{gh}" fill="url(#glassBody)"/>',
        # Retroiluminación verde: se atenúa (0.55) para que el contenido
        # de Lorito (forma de onda, mensajes) siga legible sobre ella.
        f'<rect x="0" y="{gy0}" width="{w}" height="{gh}" fill="url(#greenEdgeGlow)" opacity="0.55"/>',
        # Onda de dispersión interna (el original usa desenfoque: aquí dos
        # trazos anchos de baja opacidad).
        f'<path d="{wave}" fill="none" stroke="#00ffbb" stroke-width="44" opacity="0.05"/>',
        f'<path d="{wave}" fill="none" stroke="#00ffbb" stroke-width="22" opacity="0.05"/>',
        # Bisel superior
        f'<rect x="0" y="0" width="{w}" height="{B}" rx="2" fill="url(#thinMetalBezel)" '
        f'stroke="#0d0e10" stroke-width="1"/>',
        f'<line x1="2" y1="1" x2="{w-2}" y2="1" stroke="#ffffff" stroke-width="1" opacity="0.4"/>',
        f'<circle cx="15" cy="5" r="2" fill="#555"/><circle cx="{w-15}" cy="5" r="2" fill="#555"/>',
        # Bisel inferior
        f'<rect x="0" y="{h-B}" width="{w}" height="{B}" rx="2" fill="url(#thinMetalBezel)" '
        f'stroke="#0d0e10" stroke-width="1"/>',
        f'<line x1="2" y1="{h-1}" x2="{w-2}" y2="{h-1}" stroke="#000000" stroke-width="1.5" opacity="0.8"/>',
        f'<circle cx="15" cy="{h-5}" r="2" fill="#222"/><circle cx="{w-15}" cy="{h-5}" r="2" fill="#222"/>',
    ]
    return _svg(w, h, defs, "".join(body))


def svg_metaloric_glare(w: int, h: int) -> str:
    """Brillo del vidrio + refracción superior + canto derecho verde
    (capa superior, transparente al ratón)."""
    B = METALORIC_BEZEL
    gy0, gh = B, h - 2 * B
    defs = """
    <linearGradient id="glassGlare" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.22"/>
      <stop offset="15%" stop-color="#ffffff" stop-opacity="0.08"/>
      <stop offset="35%" stop-color="#ffffff" stop-opacity="0.0"/>
      <stop offset="80%" stop-color="#00ff88" stop-opacity="0.03"/>
      <stop offset="100%" stop-color="#00ff88" stop-opacity="0.12"/>
    </linearGradient>"""
    body = (f'<rect x="0" y="{gy0}" width="{w}" height="{gh}" fill="url(#glassGlare)"/>'
            f'<line x1="0" y1="{gy0+1}" x2="{w}" y2="{gy0+1}" stroke="#ffffff" stroke-width="1" '
            f'opacity="0.7"/>'
            f'<line x1="{w-1}" y1="{gy0}" x2="{w-1}" y2="{gy0+gh}" stroke="#00ffbb" stroke-width="5" '
            f'opacity="0.2"/>'
            f'<line x1="{w-1}" y1="{gy0}" x2="{w-1}" y2="{gy0+gh}" stroke="#00ffbb" stroke-width="2" '
            f'opacity="0.9"/>')
    return _svg(w, h, defs, body)


ALL_TEMPLATES = {
    "wood_canvas": lambda: svg_wood_canvas(1040, 630),
    "peak_meter": lambda: svg_peak_meter(144, 602, "REC VU"),
    "faceplate": lambda: svg_faceplate(744, 300, "LORITO ALDHIRO"),
    "lcd_screen": lambda: svg_lcd_screen(660, 190),
    "lcd_glass": lambda: svg_lcd_glass(660, 190),
    "transport_button": lambda: svg_transport_button(140, 36),
    "panascrub_plate": lambda: svg_panascrub_plate(744, 130, [("CONTROL DE ESCANEO", 12)]),
    "slider_slot": lambda: svg_slider_slot(700),
    "slider_knob": lambda: svg_slider_knob(27, 24),
    "metaloric_panel": lambda: svg_metaloric_panel(744, 200),
    "metaloric_glare": lambda: svg_metaloric_glare(744, 200),
}


# ═════════════════════════════════════════════════════════════════════════════
#  Render (QtSvg, diferido) con caché
# ═════════════════════════════════════════════════════════════════════════════
_PIXMAP_CACHE: dict = {}
_CACHE_MAX = 96


def svg_pixmap(svg_text: str, w: int, h: int, dpr: float = 1.0):
    """QPixmap del SVG a (w×h) lógicos; `None` si QtSvg no está disponible
    (el llamador pinta su respaldo)."""
    key = (hash(svg_text), int(w), int(h), round(dpr, 2))
    pm = _PIXMAP_CACHE.get(key)
    if pm is not None:
        return pm
    try:
        from PySide6.QtSvg import QSvgRenderer
        from PySide6.QtGui import QPixmap, QPainter
        from PySide6.QtCore import QByteArray, Qt, QRectF
    except Exception:
        return None
    if w <= 0 or h <= 0:
        return None
    renderer = QSvgRenderer(QByteArray(svg_text.encode("utf-8")))
    if not renderer.isValid():
        return None
    pm = QPixmap(max(1, int(w * dpr)), max(1, int(h * dpr)))
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    renderer.render(p, QRectF(0, 0, w, h))
    p.end()
    if len(_PIXMAP_CACHE) >= _CACHE_MAX:
        _PIXMAP_CACHE.pop(next(iter(_PIXMAP_CACHE)))
    _PIXMAP_CACHE[key] = pm
    return pm


def paint_svg(p, svg_text: str, x: float, y: float, w: int, h: int, widget=None) -> bool:
    dpr = 1.0
    if widget is not None:
        try:
            dpr = float(widget.devicePixelRatioF())
        except Exception:
            dpr = 1.0
    pm = svg_pixmap(svg_text, w, h, dpr)
    if pm is None:
        return False
    p.drawPixmap(int(x), int(y), pm)
    return True
