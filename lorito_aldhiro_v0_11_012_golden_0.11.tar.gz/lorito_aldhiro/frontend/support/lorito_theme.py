from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Paleta de colores y estilo visual general de la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import numpy as np
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF



# ─────────────────────────────────────────────────────────────────────────────
#  EXTRACCIÓN AUTOMÁTICA DE PALETA (k-means en miniatura)
# ─────────────────────────────────────────────────────────────────────────────

def _kmeans_colors(qimage, k=5, iterations=12):
    img = qimage.scaled(64, 64, Qt.IgnoreAspectRatio, Qt.FastTransformation)
    img = img.convertToFormat(QImage.Format_RGB888)
    w, h = img.width(), img.height()
    # OPT-KMEANS-NUMPY (v0.22.38): reemplaza el doble bucle Python pixel-por-pixel
    # con extracción vectorizada vía puntero de bytes. El bucle anterior era O(w×h)
    # en Python puro (~4096 iteraciones para imagen 64×64) ejecutándose en el
    # GUI thread al arrancar. La nueva implementación lee los bytes del QImage
    # en un único bloque y los convierte a array en una sola operación numpy.
    ptr = img.bits()
    # In newer PyQt5/Python versions, bits() returns a memoryview which has no
    # setsize(). We convert to bytes using the known buffer size instead.
    if hasattr(ptr, 'setsize'):
        ptr.setsize(h * w * 3)
        buf = ptr
    else:
        buf = bytes(ptr)[: h * w * 3]
    arr = np.frombuffer(buf, dtype=np.uint8).reshape(h * w, 3).astype(np.float32)
    idx = np.linspace(0, len(arr)-1, k, dtype=int)
    centers = arr[idx].copy()
    for _ in range(iterations):
        dists  = np.linalg.norm(arr[:, None] - centers[None], axis=2)
        labels = np.argmin(dists, axis=1)
        new_centers = np.array([
            arr[labels == i].mean(axis=0) if (labels == i).any() else centers[i]
            for i in range(k)
        ])
        if np.allclose(new_centers, centers, atol=1): break
        centers = new_centers
    lum   = 0.299*centers[:,0] + 0.587*centers[:,1] + 0.114*centers[:,2]
    order = np.argsort(lum)
    return centers[order].astype(int)


def build_theme_from_image(pixmap):
    if pixmap is None or pixmap.isNull():
        return None
    img  = pixmap.toImage()
    cols = _kmeans_colors(img, k=6)

    def qc(rgb, a=255):
        return QColor(int(rgb[0]), int(rgb[1]), int(rgb[2]), a)
    def hex3(rgb):
        return f"#{int(rgb[0]):02x}{int(rgb[1]):02x}{int(rgb[2]):02x}"
    def rgba_str(rgb, a):
        return f"rgba({int(rgb[0])},{int(rgb[1])},{int(rgb[2])},{a})"

    dark   = cols[0]; mid = cols[2]; accent = cols[4]; bright = cols[5]

    rec_r = min(255, int(accent[0]*0.6 + 255*0.4))
    rec_g = int(accent[1]*0.15); rec_b = int(accent[2]*0.15)
    rec_hex  = f"#{rec_r:02x}{rec_g:02x}{rec_b:02x}"
    rec_glow = f"#{rec_r:02x}{rec_g:02x}{rec_b:02x}88"
    rec_lcd  = f"#{min(26, rec_r//6):02x}{rec_g//8:02x}{rec_b//8:02x}"

    pau_r = min(255, int(accent[0]*0.7 + 255*0.3))
    pau_g = min(255, int(accent[1]*0.4 + 160*0.6)); pau_b = int(accent[2]*0.1)
    pau_hex  = f"#{pau_r:02x}{pau_g:02x}{pau_b:02x}"
    pau_glow = f"#{pau_r:02x}{pau_g:02x}{pau_b:02x}66"
    pau_lcd  = f"#{min(26, pau_r//6):02x}{min(13, pau_g//8):02x}00"

    pla_r = int(accent[0]*0.1)
    pla_g = min(255, int(accent[1]*0.5 + 180*0.5))
    pla_b = min(255, int(accent[2]*0.3 + 120*0.7))
    pla_hex  = f"#{pla_r:02x}{pla_g:02x}{pla_b:02x}"
    pla_glow = f"#{pla_r:02x}{pla_g:02x}{pla_b:02x}66"
    pla_lcd  = f"#00{min(24, pla_g//8):02x}{min(10, pla_b//12):02x}"

    dark_lcd_hex = f"#{max(4,dark[0]//12):02x}{max(6,dark[1]//10):02x}{max(4,dark[2]//12):02x}"
    ind_off_hex  = f"#{max(22,dark[0]//8):02x}{max(22,dark[1]//8):02x}{max(22,dark[2]//8):02x}"

    states = {
        "standby": dict(ind=ind_off_hex, glow=None,      timer=rgba_str(bright,55),  lcd_bg=dark_lcd_hex, label="STANDBY"),
        "rec":     dict(ind=rec_hex,     glow=rec_glow,  timer=rec_hex,              lcd_bg=rec_lcd,      label="REC"),
        "pause":   dict(ind=pau_hex,     glow=pau_glow,  timer=pau_hex,              lcd_bg=pau_lcd,      label="PAUSA"),
        "play":    dict(ind=pla_hex,     glow=pla_glow,  timer=pla_hex,              lcd_bg=pla_lcd,      label="PLAY"),
        "stop":    dict(ind=ind_off_hex, glow=None,      timer=rgba_str(bright,55),  lcd_bg=dark_lcd_hex, label="STOP"),
    }

    border_rgba  = rgba_str(bright, 218);  hover2_rgba  = rgba_str(bright, 180)
    pressed_rgba = rgba_str(bright, 200);  dis_text     = rgba_str(bright, 90)
    dis_border   = rgba_str(bright, 64);   dis_bg       = rgba_str(bright, 50)
    bg_rgba      = rgba_str(mid, 178);     text_col     = "#b0b0b0"
    sep_rgba     = rgba_str(bright, 20)

    cmb_css = (
        f"QComboBox{{background:{bg_rgba};border:1.5px solid {border_rgba};"
        f"border-radius:7px;color:#b0b0b0;font-size:10px;"
        f"font-family:'Exo 2';"
        f"font-weight:700;padding:1px 6px;letter-spacing:1px;}}"
        f"QComboBox:hover{{background:{hover2_rgba};border-color:{rgba_str(bright,200)};color:#d0d0d0;}}"
        f"QComboBox::drop-down{{border:none;width:12px;}}"
        f"QComboBox QAbstractItemView{{background:#111;color:#b0b0b0;"
        f"border:1px solid {rgba_str(bright,50)};selection-background-color:#2a2a2a;"
        f"font-family:'Exo 2';font-weight:700;}}"
        f"QComboBox:disabled{{color:#707070;background:{dis_bg};border-color:{dis_border};}}"
    )
    btn_base = (
        f"QPushButton{{background:{bg_rgba};border:1.5px solid {border_rgba};"
        f"border-radius:9px;color:#b0b0b0;font-size:10px;"
        f"font-family:'Exo 2';"
        f"font-weight:700;letter-spacing:1px;}}"
        f"QPushButton:hover:!disabled{{background:{hover2_rgba};border-color:{rgba_str(bright,200)};}}"
        f"QPushButton:pressed:!disabled{{background:{pressed_rgba};}}"
        f"QPushButton:disabled{{color:#707070;border-color:{dis_border};background:{dis_bg};}}"
    )
    rec_css = (btn_base
               .replace(border_rgba, rgba_str(np.array([rec_r,rec_g,rec_b]),184))
               .replace(text_col, rec_hex))
    pau_css = (btn_base
               .replace(border_rgba, rgba_str(np.array([pau_r,pau_g,pau_b]),184))
               .replace(text_col, pau_hex))
    pla_css = (btn_base
               .replace(border_rgba, rgba_str(np.array([pla_r,pla_g,pla_b]),184))
               .replace(text_col, pla_hex))

    lbl_css = (
        f"color:{rgba_str(bright,128)};font-size:7px;"
        f"font-family:'Helvetica Neue',Helvetica,Arial,monospace;"
        f"letter-spacing:2px;background:transparent;"
    )
    sep_css   = f"background:{sep_rgba};"
    vu_green  = hex3(np.array([pla_r, pla_g, pla_b]))
    vu_yellow = hex3(np.array([pau_r, pau_g, pau_b]))
    vu_red    = hex3(np.array([rec_r, rec_g, rec_b]))

    _glow_base = (
        "QPushButton{border-radius:9px;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;border-width:2px;border-style:solid;}"
        "QPushButton:disabled{opacity:0.4;}"
    )
    btn_active_rec  = (_glow_base
        + f"QPushButton{{background:rgba({rec_r},{rec_g},{rec_b},0.72);"
          f"border-color:rgba({rec_r},{rec_g},{rec_b},0.95);color:{rec_hex};}}")
    btn_active_pau  = (_glow_base
        + f"QPushButton{{background:rgba({pau_r},{pau_g},{pau_b},0.70);"
          f"border-color:rgba({pau_r},{pau_g},{pau_b},0.95);color:{pau_hex};}}")
    btn_active_stop = (_glow_base
        + "QPushButton{background:rgba(80,80,80,0.72);border-color:rgba(160,160,160,0.90);"
          "color:#cccccc;}")
    btn_active_play = (_glow_base
        + f"QPushButton{{background:rgba({pla_r},{pla_g},{pla_b},0.70);"
          f"border-color:rgba({pla_r},{pla_g},{pla_b},0.95);color:{pla_hex};}}")
    btn_active_exp  = btn_active_stop
    # Vintage translucent idle style — opacidad 70%, texto gris negrita
    vint_r = min(255, int(bright[0]*0.72 + accent[0]*0.28))
    vint_g = min(255, int(bright[1]*0.60 + accent[1]*0.20))
    vint_b = min(255, int(bright[2]*0.45 + accent[2]*0.15))
    btn_idle = (
        "QPushButton{"
        f"background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
        f"stop:0 rgba({vint_r},{vint_g},{vint_b},0.70),"
        f"stop:1 rgba({vint_r//2},{vint_g//2},{vint_b//2},0.75));"
        f"border:1.5px solid rgba({vint_r},{vint_g},{vint_b},0.85);"
        "border-radius:9px;"
        "color:#b0b0b0;"
        "font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;}"
        "QPushButton:hover:!disabled{"
        f"background:{hover2_rgba};"
        f"border-color:{rgba_str(bright,200)};color:#d0d0d0;}}"
        "QPushButton:pressed:!disabled{"
        f"background:rgba({vint_r//2},{vint_g//2},{vint_b//2},0.88);}}"
        "QPushButton:disabled{"
        "color:#707070;"
        f"border-color:rgba({vint_r},{vint_g},{vint_b},0.30);"
        f"background:rgba({vint_r//3},{vint_g//3},{vint_b//3},0.20);}}"
    )

    return {
        "states": states, "cmb_css": cmb_css, "btn_base": btn_base,
        "rec_css": rec_css, "pau_css": pau_css, "pla_css": pla_css,
        "lbl_css": lbl_css, "sep_css": sep_css, "text_col": text_col,
        "bright": bright, "accent": accent, "mid": mid, "dark": dark,
        "vu_green": vu_green, "vu_yellow": vu_yellow, "vu_red": vu_red,
        "border_rgba": border_rgba, "bg_rgba": bg_rgba,
        "btn_active_rec": btn_active_rec, "btn_active_pau": btn_active_pau,
        "btn_active_stop": btn_active_stop, "btn_active_play": btn_active_play,
        "btn_active_exp": btn_active_exp, "btn_idle": btn_idle,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  TEMA POR DEFECTO
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_STATES = {
    "standby": dict(ind="#1c1c1c", glow=None,       timer="rgba(255,255,255,0.22)", lcd_bg="#080c06", label="STANDBY"),
    "rec":     dict(ind="#ff2200", glow="#ff330088", timer="#ff4422",               lcd_bg="#1a0300", label="REC"),
    "pause":   dict(ind="#ff9900", glow="#ff880066", timer="#ffaa00",               lcd_bg="#1a0d00", label="PAUSA"),
    "play":    dict(ind="#00e87a", glow="#00e87a66", timer="#00dd77",               lcd_bg="#00180a", label="PLAY"),
    "stop":    dict(ind="#1c1c1c", glow=None,        timer="rgba(255,255,255,0.22)", lcd_bg="#080c06", label="STOP"),
}
DEFAULT_THEME = {
    "states":  DEFAULT_STATES,
    "cmb_css": (
        "QComboBox{background:rgba(255,255,255,0.70);border:1.5px solid rgba(255,255,255,0.85);"
        "border-radius:7px;color:#b0b0b0;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;padding:1px 6px;letter-spacing:1px;}"
        "QComboBox:hover{background:rgba(255,255,255,0.80);border-color:rgba(255,255,255,0.95);color:#d0d0d0;}"
        "QComboBox::drop-down{border:none;width:12px;}"
        "QComboBox QAbstractItemView{background:#111;color:#b0b0b0;"
        "border:1px solid rgba(255,255,255,0.2);"
        "selection-background-color:#2a2a2a;font-family:'Exo 2';"
        "font-weight:700;}"
        "QComboBox:disabled{color:#707070;background:rgba(255,255,255,0.12);"
        "border-color:rgba(255,255,255,0.25);}"
    ),
    "btn_base": (
        "QPushButton{background:rgba(255,255,255,0.70);border:1.5px solid rgba(255,255,255,0.85);"
        "border-radius:9px;color:#b0b0b0;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;}"
        "QPushButton:hover:!disabled{background:rgba(255,255,255,0.80);border-color:rgba(255,255,255,0.95);}"
        "QPushButton:pressed:!disabled{background:rgba(255,255,255,0.88);}"
        "QPushButton:disabled{color:#707070;border-color:rgba(255,255,255,0.25);"
        "background:rgba(255,255,255,0.12);}"
    ),
    "rec_css": None, "pau_css": None, "pla_css": None,
    "lbl_css": (
        "color:rgba(255,255,255,0.50);font-size:7px;"
        "font-family:'Helvetica Neue',Helvetica,Arial,monospace;"
        "letter-spacing:2px;background:transparent;"
    ),
    "sep_css":     "background:rgba(255,255,255,0.07);",
    "text_col":    "#b0b0b0",
    "bright":      np.array([255, 255, 255]),
    "accent":      np.array([0, 230, 120]),
    "mid":         np.array([80, 80, 80]),
    "dark":        np.array([10, 10, 10]),
    "vu_green":    "#00cc44",
    "vu_yellow":   "#aadd00",
    "vu_red":      "#ff1100",
    "border_rgba": "rgba(255,255,255,0.85)",
    "bg_rgba":     "rgba(255,255,255,0.70)",
}

def _patch_default_theme(t):
    if t["rec_css"] is None:
        b = t["btn_base"]
        t["rec_css"] = (b.replace("rgba(255,255,255,0.85)","rgba(255,70,30,0.90)")
                         .replace("color:#b0b0b0;","color:#ff6644;"))
        t["pau_css"] = (b.replace("rgba(255,255,255,0.85)","rgba(255,160,0,0.90)")
                         .replace("color:#b0b0b0;","color:#ffbb44;"))
        t["pla_css"] = (b.replace("rgba(255,255,255,0.85)","rgba(0,220,110,0.90)")
                         .replace("color:#b0b0b0;","color:#44ffaa;"))

    # ── CSS de estado activo (iluminado) para cada botón ─────────────────────
    _glow_base = (
        "QPushButton{border-radius:9px;font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;border-width:2px;border-style:solid;}"
        "QPushButton:disabled{opacity:0.4;}"
    )
    t["btn_active_rec"]  = (_glow_base
        + "QPushButton{background:rgba(200,20,20,0.75);border-color:rgba(255,60,40,0.95);"
        "color:#ff4433;}")
    t["btn_active_pau"]  = (_glow_base
        + "QPushButton{background:rgba(180,90,0,0.72);border-color:rgba(255,165,0,0.95);"
        "color:#ffb830;}")
    t["btn_active_stop"] = (_glow_base
        + "QPushButton{background:rgba(80,80,80,0.72);border-color:rgba(160,160,160,0.90);"
        "color:#cccccc;}")
    t["btn_active_play"] = (_glow_base
        + "QPushButton{background:rgba(0,140,60,0.72);border-color:rgba(0,230,110,0.95);"
        "color:#44ff99;}")
    t["btn_active_exp"]  = t["btn_active_stop"]
    # CSS base estético vintage translúcido para reposo — opacidad 70%, texto gris negrita
    t["btn_idle"] = (
        "QPushButton{"
        "background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
        "stop:0 rgba(180,155,120,0.70),stop:1 rgba(100,80,60,0.75));"
        "border:1.5px solid rgba(210,185,150,0.85);"
        "border-radius:9px;"
        "color:#b0b0b0;"
        "font-size:10px;"
        "font-family:'Exo 2';"
        "font-weight:700;letter-spacing:1px;}"
        "QPushButton:hover:!disabled{"
        "background:rgba(255,255,255,0.80);"
        "border-color:rgba(255,255,255,0.95);color:#d0d0d0;}"
        "QPushButton:pressed:!disabled{"
        "background:rgba(150,120,90,0.88);}"
        "QPushButton:disabled{"
        "color:#707070;"
        "border-color:rgba(200,175,140,0.30);"
        "background:rgba(120,100,75,0.20);}"
    )
    return t

_patch_default_theme(DEFAULT_THEME)
THEME = DEFAULT_THEME


# ─────────────────────────────────────────────────────────────────────────────
#  VFD DORADO LUMÍNICO — rediseño del panel de contómetro de Lorito Aldhiro
#  (pedido explícito del usuario, mismo acabado que el VFD display de CRAC:
#  scanlines + efecto fosfórico, bordes redondeados, vidrio ahumado negro,
#  leyendas y contómetro en dorado lumínico). A diferencia de CRAC, Lorito
#  Aldhiro NO lleva imagen de fondo dinámica — lienzo crema vintage con
#  aspecto marrón vintage tipo nogal (§VFD_GOLD_PALETTE; lienzo SVG en lorito_svg_skins).
# ─────────────────────────────────────────────────────────────────────────────

# Dorado lumínico — un único tono base para dígitos, leyendas y la línea
# ondulante de la megacelda de señal, con variantes de alpha para el halo
# fosfórico y el estado "apagado" (fósforo residual, entre parpadeos).
VFD_GOLD          = "#ffcc55"
VFD_GOLD_BRIGHT   = "#ffe29a"
VFD_GOLD_DIM      = "rgba(255,204,85,70)"
VFD_GOLD_GLOW     = "rgba(255,204,85,90)"
VFD_GLASS_BG      = "#0b0906"     # vidrio ahumado negro (fondo de la megacelda)
VFD_GLASS_BG_TOP  = "#141008"     # variante más clara para el gradiente superior
VFD_SCANLINE      = "rgba(0,0,0,90)"

# Lienzo: SVG de madera pulida de la usuaria (0.11.008) — ver
# `lorito_svg_skins.svg_wood_canvas` y `lorito_svg_panels.SvgCanvasBackground`.
# El lienzo pintado a mano con Qt (`paint_wood_canvas`) fue retirado, igual
# que los acabados pintados a mano que sustituyen las pieles SVG
# (`paint_vfd_glass`, `paint_vfd_sheen`, `paint_brushed_aluminum`,
# `paint_alu_screw`): el contómetro es ahora el LCD Display ámbar y las
# placas de aluminio salen de los SVG (ver `lorito_svg_skins`). Las
# constantes VFD_* se conservan: el registro de overlays las sigue usando
# como color nominal (el LCD lo dibuja en su propia tinta).


def apply_gold_vfd_accent(theme: dict) -> None:
    """
    Muta `theme` in-place (mismo patrón ya usado por
    `lorito_main_window.py` para `build_theme_from_image`) para que el
    acento/brillo general de la interfaz de Lorito Aldhiro sea dorado
    lumínico en vez del verde/blanco por defecto — pedido explícito del
    usuario de que el contómetro Y sus leyendas usen ese tono; se
    extiende aquí al resto de la interfaz (barra de menú, títulos,
    scrubs) para que el acabado sea consistente en todo el lienzo.
    """
    gold_bright = np.array([255, 226, 154])
    gold_accent = np.array([224, 168, 64])
    theme["bright"] = gold_bright
    theme["accent"] = gold_accent
