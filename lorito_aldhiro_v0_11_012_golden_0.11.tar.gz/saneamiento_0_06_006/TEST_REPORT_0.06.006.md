# TEST_REPORT_0.06.006

Fecha: 2026-09-11
Comando: `python3 -m unittest discover -s tests -p "test_*.py" -v`
Entorno real de ejecución (ver `_env_*.txt` en esta misma carpeta):
  - Python 3.12.3
  - NumPy 2.4.4
  - SciPy 1.17.1
  - PySide6: **NO instalado** en este sandbox (ModuleNotFoundError)
  - sounddevice: instalado, pero **PortAudio no disponible**
    (`OSError: PortAudio library not found`)
  - `uname -a`: Linux vm 6.18.44-fc-v32 #1 SMP PREEMPT_DYNAMIC x86_64

## Resultado

```
Ran 134 tests in 4.825s
OK
```

**134 / 134 tests, 0 fallidos, 0 errores.** Salida completa y verbosa
en `_test_run_full.txt` (mismo directorio).

También se corrió con `-W error::ResourceWarning` (los warnings de
recursos sin cerrar se tratan como fallo) — sigue en `OK`, tras las
dos correcciones de higiene de esta misma sesión (ver GAP-024).

## Estado ANTES de esta sesión (BASELINE_0.06.005)

Al ejecutar la misma batería contra el código tal como llegó al inicio
de esta sesión (0.06.005):

```
Ran 134 tests in 6.520s
FAILED (failures=4)
```

4 fallos — exactamente los 4 tests obsoletos identificados por la
Orden Maestra (Fase 11, ítems 1-4):

1. `test_embedded_fonts.TestEmbeddedFontAssets.
   test_all_four_expected_families_have_a_directory` — esperaba 4
   familias de fuente; el código real ya tiene 6 (Helvetica y Utendo
   se añadieron en sesiones posteriores sin actualizar esta prueba).
2. `test_overlay_system.TestOverlayRegistry.
   test_exact_calco_tokens_present` — esperaba `EXPORT == "Export"`;
   el texto real, auditado contra CRAC, es `"Expn Signal"`.
3. `test_overlay_system.TestDigitalClockOverlayIntegration.
   test_side_cells_start_empty_and_unlit` — esperaba las 8 celdas
   laterales vacías; el contrato vigente (GAP-018) las inicializa con
   valores por defecto reales (LADO A, STEREO, MON 1, etc.).
4. `test_overlay_system.TestDigitalClockOverlayIntegration.
   test_set_side_cell_updates_text_and_lit_state` — mismo motivo que
   el punto 3, sobre la celda L1 usada como control "sin tocar".

Los 4 se corrigieron actualizando la EXPECTATIVA de la prueba al
comportamiento actualmente contratado (nunca se relajó ni se borró
ninguna prueba) — ver diffs en `tests/test_embedded_fonts.py` y
`tests/test_overlay_system.py`, y el detalle de cada corrección en
GAP-024.

## Cobertura real de esta batería — límite explícito

Esta suite (134 tests) cubre: registro de fuentes, sistema de overlays,
parche de estabilidad (auditoría de fixes aplicados), máquina de
transporte (scrub/seek/velocidad/dirección), geometría de layout del
contómetro, decomposición modular, integración ITL, sistemas NR,
réplica del panel de exportación, exportación espectral, y escalado de
memoria de exportación.

**NO cubre** (y por tanto esta batería en verde NO certifica) los
puntos centrales de la Orden Maestra que siguen abiertos:
ring buffer RT sin locks, política de overflow, contadores CED,
estados de recovery del dispositivo, máquina ARCHIVAL_SAFE/DEGRADED/
INVALID, RF64, saneamiento DSP (finite-in/finite-out), pruebas de
larga duración reales, ni pruebas de inyección de fallos. Ver
`ENGINEERING_STATUS_0.06.006.md` para el estado honesto de cada Fase
de la orden.
