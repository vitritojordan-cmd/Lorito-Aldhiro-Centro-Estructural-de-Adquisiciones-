# TEST_REPORT_0.06.007

Fecha: 2026-09-11
Comando: `python3 -m unittest discover -s tests -p "test_*.py" -v`
Entorno real de ejecución (ver `_env_*.txt` en esta misma carpeta):
  - Python 3.12.3
  - NumPy 2.4.4
  - SciPy 1.17.1
  - PySide6: **NO instalado** en este sandbox (`ModuleNotFoundError`)
  - sounddevice: instalado, pero **PortAudio no disponible**
    (`OSError: PortAudio library not found`)
  - Mismo sandbox que la sesión anterior (0.06.006) — sin cambios de
    entorno entre sesiones.

## Resultado

```
Ran 146 tests in 4.164s
OK
```

**146 / 146 tests, 0 fallidos, 0 errores.** 134 preexistentes (sin
cambios) + 12 nuevos de la Fase 10 (`tests/test_dsp_finite_guard.py`).
Salida completa en `_test_run_full.txt`.

También se corrió con `-W error::ResourceWarning` — sigue en `OK`, sin
fugas nuevas introducidas por esta sesión.

## Los 12 tests nuevos (Fase 10 — DSP_NONFINITE_OUTPUT)

- `TestSanitizeFiniteUnit` (5): comportamiento unitario de
  `sanitize_finite` — camino sano sin copia, NaN→0.0, ±Inf→±1.0,
  chunk vacío, dtype preservado.
- `TestRealDefectWithoutGuard` (2): demuestra que el defecto es real
  llamando a `MpxProfile`/`TapeEqBiasProfile` DIRECTAMENTE (sin
  coordinador, sin guard) — un único NaN/Inf puntual envenena el
  estado IIR de forma permanente, confirmado con 5 bloques limpios
  posteriores que siguen saliendo no finitos.
- `TestCoordinatorAppliesGuard` (5): mismo escenario a través de
  `NRCoordinator.process_chunk` — recuperación tras NaN en el bloque
  de entrada (guard finite-in), recuperación tras corrupción directa
  del estado interno de una etapa (guard por etapa + reset reutilizado),
  y una cadena con 4 etapas activas sin ningún NaN/Inf real (todos los
  contadores deben quedar en cero, sin falsos positivos).

## Cobertura real de esta batería — límite explícito (sin cambios
respecto a 0.06.006, salvo lo añadido)

Cubre, además de lo ya cubierto en 0.06.006: el contrato
`DSP_NONFINITE_OUTPUT` en la cadena de `NRCoordinator` (EQ/BIAS, MPX,
NR, HX Pro, ALC, FOCUS).

**Sigue sin cubrir** (ver `ENGINEERING_STATUS_0.06.007.md`): ring
buffer RT sin locks, política de overflow, contadores CED, estados de
recovery del dispositivo, máquina ARCHIVAL_SAFE/DEGRADED/INVALID,
RF64, pruebas de larga duración reales, pruebas de inyección de
fallos.
