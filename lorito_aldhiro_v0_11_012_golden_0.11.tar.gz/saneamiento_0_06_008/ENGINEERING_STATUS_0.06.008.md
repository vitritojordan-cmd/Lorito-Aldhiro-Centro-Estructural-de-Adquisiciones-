# ENGINEERING_STATUS_0.06.008 — Estado real frente a la Orden Maestra de
Ingeniería (Saneamiento Pre-Auditoría Aldhira Phonographic)

Fecha: 2026-09-11
Rama de origen: 0.06.007
Rama objetivo de esta sesión: 0.06.008

## Veredicto honesto de esta sesión

Se avanzó la Fase 1 en el único sentido seguro posible sin PySide6
ejecutable: se auditó la FIDELIDAD del camino de exportación
streaming ya construido (no su integración a la GUI) y se encontró y
corrigió un defecto real. **Gates 3 y 4 siguen sin pasar** — sin
cambios respecto a 0.06.007.

## GATE 1 — BUILD: PASS.
## GATE 2 — TEST: PASS, ampliado — 152/152 (146 + 6 nuevos).
## GATE 3 — ARCHIVAL: sin cambios, sigue NO EVALUADO.
## GATE 4 — RELEASE: sin cambios, sigue PARCIAL. `RELEASE_MANIFEST.txt`
regenerado (incluye el `lorito_wav_encoder.py` corregido).

---

## Fase 1 — Saneamiento del camino de exportación

**AUDITADO MÁS A FONDO, DEFECTO DE FIDELIDAD CORREGIDO EN LA
INFRAESTRUCTURA STREAMING — INTEGRACIÓN A LA GUI SIGUE PENDIENTE.**

Lo nuevo esta sesión: `WavEncoder._float32_to_pcm_bytes` no era
bit-exacto (escala asimétrica + truncación frente al decodificador) —
corregido. PCM_16/PCM_24 ahora bit-exactos extremo a extremo; PCM_32
tiene un límite real de precisión de float32 (documentado, no un
bug). Ver `gaps/GAP-026.md` para el detalle completo, incluida la
explicación de por qué la integración real a `main_window.export()`
sigue sin poder hacerse en este sandbox (normalización con modos no
triviales de streamear + resampleo con artefactos de frontera de
bloque sin medir + archivo de 6000 líneas de GUI no ejecutable aquí).

El defecto original que motivó la Fase 1 (`_build_export_array`
materializa la sesión completa en RAM) **sigue sin corregirse en el
código que la GUI realmente usa** — eso requiere la integración
pendiente arriba.

## Resto de fases — sin cambios

Ver `saneamiento_0_06_007/ENGINEERING_STATUS_0.06.007.md` y
`saneamiento_0_06_006/ENGINEERING_STATUS_0.06.006.md` para el estado
completo de las Fases 2-9, 11-17 (sin auditoría ni cambios esta
sesión).

---

## Recomendación

1. Clasificar modo por modo (`PEAK_SIMPLE`, `RMS_*`, presets de cinta,
   `TWO_PASS`, `SOFT_LIMIT_ONLY`) cuáles de las normalizaciones de
   `lorito_normalization.py`/`lorito_normalization_v21.py` son
   streameables en dos pasadas (medir → aplicar ganancia) sin cambiar
   el resultado — trabajo de auditoría pura, sin tocar código, bajo
   riesgo.
2. Medir (con stubs de `sounddevice`/`soundfile`, mismo patrón que
   `lorito_bootstrap.py` ya usa) si la interpolación Catmull-Rom por
   bloque de `_resample_stateful` introduce diferencia audible/medible
   frente al resampleo de un solo array, antes de decidir si reusarla
   para export streameado.
3. Solo con 1 y 2 resueltos, considerar la integración real a
   `main_window.export()` — y aun así, en una sesión con PySide6
   disponible para verificar con ejecución real.
4. Alternativa de menor riesgo: Fases 3/4/5 (ring buffer/overflow/CED)
   siguen pendientes y son independientes de esta cadena de trabajo.

No entregar a Aldhira Phonographic hasta que este documento pueda
reescribirse con GATE 3 y GATE 4 en PASS real.
