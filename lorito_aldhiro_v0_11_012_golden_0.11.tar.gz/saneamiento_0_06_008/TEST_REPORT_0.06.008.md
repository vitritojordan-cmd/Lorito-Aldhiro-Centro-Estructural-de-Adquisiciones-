# TEST_REPORT_0.06.008

Fecha: 2026-09-11
Comando: `python3 -m unittest discover -s tests -p "test_*.py" -v`
Entorno: idéntico a 0.06.007 (ver `_env_*.txt`) — Python 3.12.3,
NumPy 2.4.4, SciPy 1.17.1, PySide6 no instalado, sounddevice sin
PortAudio.

## Resultado

```
Ran 152 tests in 3.963s
OK
```

**152 / 152 tests, 0 fallidos, 0 errores.** 146 preexistentes (sin
cambios) + 6 nuevos de la auditoría de Fase 1
(`tests/test_export_pcm_roundtrip.py`).

También en verde con `-W error::ResourceWarning`.

## Los 6 tests nuevos (Fase 1 — fidelidad del export streaming)

- Reproducción aislada del defecto viejo (escala asimétrica +
  truncación) con aritmética pura.
- Bit-exactitud de `WavEncoder._float32_to_pcm_bytes` para PCM_16 y
  PCM_24, a nivel unitario y en la cadena completa
  `SegmentProvider→WavEncoder` vía `ExportSession`.
- Verificación explícita de que el límite de PCM_32 (no bit-exacto,
  error relativo ~1.2e-7) es el esperado por la mantisa de 24 bits de
  `float32` — no una regresión de escala.

## Alcance — sin cambios respecto a 0.06.007

Esta sesión audita y corrige la FIDELIDAD del camino streaming ya
construido; NO lo integra a `main_window.export()` (sigue bloqueado
por falta de PySide6/sounddevice ejecutables en este sandbox — ver
`gaps/GAP-026.md`). El Gate 3/4 de la orden siguen exactamente igual
que en `ENGINEERING_STATUS_0.06.007.md`.
