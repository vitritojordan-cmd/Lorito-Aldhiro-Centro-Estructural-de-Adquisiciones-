# ENGINEERING_STATUS_0.06.010

Fecha: 2026-09-11 · Rama: 0.06.009 → 0.06.010

## Fase 1 — avance real, todavía parcial

Prueba de concepto de dos pasadas (GAP-027) implementada y verificada
para PEAK_SIMPLE y RMS_* (3 targets) — ver gaps/GAP-028.md. Memoria
medida acotada (~804 KB vs ~96 MB) en un caso realista de 12M frames.

Sin cambios en Gates 3/4 respecto a 0.06.008/009 — ver
saneamiento_0_06_008/ENGINEERING_STATUS_0.06.008.md para el estado
completo de todas las fases, que sigue vigente salvo lo anotado aquí.

## Pendiente inmediato de Fase 1

- 18 de 20 modos de normalización sin versión streaming todavía
  (mismo patrón measure/compute ya probado, falta extraerlo modo por
  modo — LUFS/INTELLIGENT_PEAK/TRUE_PEAK/PRESERVATIVE/NOISE_AWARE/
  MID_SIDE/CREST_GUARD son Categoría A, mismo patrón exacto que
  PEAK_SIMPLE/RMS; ADAPTIVE_BLOCK y los meta-modos necesitan el patrón
  extendido de curva-por-bloque de GAP-027).
- Resampleo (_resample_stateful) sin medir con ejecución real —
  requiere stubs de sounddevice/soundfile.
- Integración real a main_window.export() sigue bloqueada por falta de
  PySide6 ejecutable en este sandbox.

## Recomendación

Seguir extrayendo measure/compute para el resto de modos de Categoría
A (bajo riesgo, mismo patrón ya verificado), O cambiar de frente hacia
Fases 3/4/5 (ring buffer/overflow/CED), que llevan varias sesiones sin
tocarse.
