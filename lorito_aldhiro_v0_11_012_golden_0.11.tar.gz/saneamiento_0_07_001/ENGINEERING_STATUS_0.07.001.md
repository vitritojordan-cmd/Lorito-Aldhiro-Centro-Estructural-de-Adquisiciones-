# ENGINEERING_STATUS_0.07.001

Fecha: 2026-09-11 · Rama: 0.06.010 → 0.07.001 (salto explícito de MENOR)

## Frente de normalización streaming — prácticamente cerrado

19 de los 20 modos de NormalizationMode/NormalizationModeV21 tienen
ahora una versión streaming verificada (medir/aplicar en dos pasadas,
memoria O(bloque) o O(n_bloques), nunca O(duración)). Único pendiente:
la función de decisión propia de TWO_PASS (su aplicación, una vez
resuelta por cualquier medio, ya es ejecutable vía
`export_resolved_mode`). Ver gaps/GAP-029.md para el detalle completo.

Dos defectos reales del código LEGADO (no solo del camino streaming)
fueron encontrados y corregidos: `_norm_adaptive_block` crasheaba con
audio estéreo real en zonas de crossfade — nunca antes ejercitado.

Sin cambios en Gates 3/4 respecto a sesiones anteriores — ver
saneamiento_0_06_008/ENGINEERING_STATUS_0.06.008.md para el estado
completo de todas las fases de la Orden Maestra original, que sigue
vigente.

## Pendiente inmediato

- resolve_two_pass_mode (decisión propia de TWO_PASS, v21).
- Integración real a main_window.export() — sigue bloqueada por falta
  de PySide6 ejecutable en este sandbox.
- Medir _resample_stateful con stubs de sounddevice/soundfile.

## Recomendación

El frente de normalización está en un punto natural de pausa. Las
Fases 3/4/5 (ring buffer/overflow/CED) de la Orden Maestra original
llevan muchas sesiones sin tocarse y son un frente completamente
independiente — candidato natural para la próxima sesión si se
prefiere cambiar de frente en vez de rematar TWO_PASS.
