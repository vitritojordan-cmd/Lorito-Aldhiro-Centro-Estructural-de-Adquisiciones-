# TEST_REPORT_0.07.001

176/176 tests, 0 fallidos (157 previos + 19 nuevos de
`test_normalization_streaming_full.py`), con y sin
`-W error::ResourceWarning`. Entorno sin cambios (ver `_env_*.txt`).

Sesión GAP-029: cierre del frente de normalización streaming (18
modos restantes + AUTO + presets de cinta), 3 defectos reales
encontrados y corregidos (2 en `_norm_adaptive_block`, uno de ellos
presente en el código legado que la GUI usa hoy; 1 de desalineación de
buffer en `measure_block_rms_streaming`). Salto de versión explícito a
0.07 pedido por el usuario.
