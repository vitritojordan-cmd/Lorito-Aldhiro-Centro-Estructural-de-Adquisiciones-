# ENGINEERING_STATUS_0.07.004

Fecha: 2026-09-11 · Rama: 0.07.003 → 0.07.004

## Convención de árbol adoptada

De ahora en adelante, código nuevo en subpaquetes conectados por
__init__.py — nunca ficheros sueltos en backend/. Aplicado a rt/
(Fase 3), export_streaming/ (poblado retroactivamente), archival/
(Fase 7, nuevo).

## Fases 6/7 — abordadas

- Fase 6: auditada con CaptureEngineV2 real + mocks deterministas de
  tiempo. Sin defectos. 7 tests.
- Fase 7: no existía — construida desde cero (backend/archival/).
  Hallazgo real: integrity_crc32_errors estructuralmente muerto
  (_IntegrityMonitor nunca conectado a DiskWriterV2). 13 tests.

Ver gaps/GAP-032.md para el detalle completo.

## Pendiente

- Conectar _IntegrityMonitor al DiskWriterV2 real (trabajo mayor,
  toca el camino de escritura, necesita un stub de sf.SoundFile mucho
  más elaborado para testear aquí, o hardware real).
- Fase 8 (RF64) — sin abordar, no requiere hardware, buen candidato
  para la próxima sesión (WavEncoder ya lanza NotImplementedError
  sobre ~3.9GB como placeholder).
- classify_session() no está wireada a ningún punto real que la
  invoque al finalizar una sesión.

## Recomendación

Fase 8 (RF64) es el frente más natural para continuar: puramente
formato de archivo, sin dependencia de hardware ni de PySide6,
verificable end-to-end con archivos sintéticos grandes en este
sandbox.
