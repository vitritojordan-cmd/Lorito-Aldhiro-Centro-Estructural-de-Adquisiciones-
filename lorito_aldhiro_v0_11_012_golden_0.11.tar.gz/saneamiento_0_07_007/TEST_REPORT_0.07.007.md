# TEST_REPORT_0.07.007

240/240 tests, 0 fallidos (225 previos + 7 de test_segment_read_errors.py
+ 2 de GenerationGuard + 6 de test_fault_injection.py), con y sin
-W error::ResourceWarning.

GAP-034: Fases 2, 9, 12, 14, 15, 16 cerradas. Única fase de las 7
"sin identificar" que sigue bloqueada por hardware real: Fase 13.
