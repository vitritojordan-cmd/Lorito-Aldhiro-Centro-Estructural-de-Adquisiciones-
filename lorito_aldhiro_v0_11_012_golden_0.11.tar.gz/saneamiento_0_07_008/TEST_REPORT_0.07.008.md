# TEST_REPORT_0.07.008

251/251 tests, 0 fallidos (240 previos + 9 de test_segment_checksum.py
+ 2 end-to-end en test_fault_injection.py), con y sin
-W error::ResourceWarning.

GAP-035: integridad de segmento conectada de verdad (checksum real
releyendo de disco, no el _IntegrityMonitor viejo — descartado por
riesgo de falsos positivos con el redondeo interno de soundfile).
