# TEST_REPORT_0.07.009

254/254 tests, 0 fallidos (251 previos + 3 de
test_main_window_export_exploration.py), con y sin
-W error::ResourceWarning.

GAP-036: confirmado con ejecución real que _build_export_array()
(legado) produce resultado bit-exacto idéntico a SegmentProvider
(streaming) para el caso base. Reduce el riesgo de una futura
integración de Fase 1 a main_window.export(), sin haberla hecho
todavía.
