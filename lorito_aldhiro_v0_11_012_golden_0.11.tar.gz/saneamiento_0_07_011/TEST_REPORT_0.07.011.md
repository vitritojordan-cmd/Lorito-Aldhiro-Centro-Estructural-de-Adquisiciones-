# TEST_REPORT_0.07.011

268/268 tests, 0 fallidos (261 previos + 7 de test_close_protection.py),
con y sin -W error::ResourceWarning.

GAP-038: defecto real de closeEvent corregido (DiskWriterV2 nunca se
detenía en las ramas GUARDAR/DESCARTAR, basado en un comentario falso).
Nuevo CaptureEngineV2.wait_for_background_threads(), equivalente
adaptado de wait_for_pending_stream_close() de CRAC.
