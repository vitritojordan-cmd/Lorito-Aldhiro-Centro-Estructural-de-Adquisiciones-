# TEST_REPORT_0.08.001

327/327 tests, 0 fallidos, con y sin -W error::ResourceWarning.

GAP-041: Antipestal de Lola Grillo (PREVI) y Versión O Tron (FNESP)
completos (backend + UI), con investigación web de especificaciones
reales para ambos. Corrección real encontrada: print-through de
Antipestal estaba 1.5-2 órdenes de magnitud por debajo de la física
real de cassette (corregido de ms a segundos). Anchos de banda de O
Tron confirmados bien fundamentados en la práctica real documentada.

Versión elevada a 0.08.001 según lo pedido por el usuario.

Con esto, de los 5 DSP de CRAC solicitados: Cristhi Cosh, Antipestal
Lola Grillo, y Versión O Tron quedan completos. Autoalineación fue
omitida (FocusProfile ya cubre esa función). Solo queda Lucha
Enloquecida, para una sesión dedicada aparte.
