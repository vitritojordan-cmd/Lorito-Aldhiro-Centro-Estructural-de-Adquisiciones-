# TEST_REPORT_0.09.004

365/365 tests, 0 fallidos, con y sin -W error::ResourceWarning.

GAP-046: lorito_main_window.py modularizado en mixins (6376 -> 706
líneas núcleo + 8 archivos); 31 módulos planos arborizados en 9
subpaquetes nuevos. Tres defectos reales de los scripts propios
encontrados y corregidos (atributo de clase perdido, patrón de import
no cubierto, dos rutas __file__ rotas -- una afectaba el cálculo de
versión). 100/100 módulos con banner de registro.
