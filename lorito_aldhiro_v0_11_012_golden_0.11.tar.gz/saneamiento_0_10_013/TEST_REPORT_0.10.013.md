# TEST_REPORT_0.10.013

461/461 tests, 0 fallidos, con y sin -W error::ResourceWarning.

GAP-060: cobertura end-to-end real de 3 ramas de exportación nunca
antes ejercitadas juntas (resampleo por velocidad, normalización
avanzada con 18 campos de _status, codecs FLAC/OGG vía ffmpeg real) —
sin defectos nuevos en la lógica de negocio. Hallazgo real de
infraestructura de test: el stub de Signal.emit() no replicaba la
aridad flexible de Qt (un slot puede aceptar menos parámetros que los
que la señal emite) — corregido, verificado que no rompe nada más en
toda la suite. lorito_bootstrap.py reverificado explícitamente.

457 tests preexistentes + 4 nuevos.
