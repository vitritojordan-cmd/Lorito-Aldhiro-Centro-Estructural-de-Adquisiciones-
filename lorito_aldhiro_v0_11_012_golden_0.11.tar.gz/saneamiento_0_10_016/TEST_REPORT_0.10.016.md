# TEST_REPORT_0.10.016

492/492 tests, 0 fallidos, con y sin -W error::ResourceWarning (1 skip
preexistente, no relacionado: `test_all_20_profiles_match_crac_source_
exactly` — árbol fuente de CRAC ausente en este sandbox).

Continuación autónoma ("Continuar.") tras 0.10.015 (GAP-062).
`PlaybackEngine` — el motor de reproducción/scrub REAL en producción,
el archivo con más historial de bugs del proyecto — no tenía ningún
test que lo corriera con sus propios hilos (`_prefetch`, `_bridge`,
driver de audio); solo sus funciones de resampleo puras se probaban
en aislamiento. Ver `gaps/GAP-063.md` para el detalle completo.

- Infraestructura nueva: `tests/_functional_sounddevice_output_stub.py`
  (stub funcional de `sounddevice.OutputStream`, hermano del ya
  existente para `InputStream`), tolerancia a WAVE_FORMAT_EXTENSIBLE +
  `.seek()` en `tests/_functional_soundfile_stub.py`.
- `tests/test_playback_engine_integration.py` (6 tests nuevos):
  instancia `PlaybackEngine` real con sus hilos reales contra el
  fixture de audio real del usuario (`sotalomafer1_scrub_5s.wav`,
  GAP-062) — forward, reversa, seek en vivo, cambio de velocidad
  discreto y en vivo, stop limpio.
- **Carrera real encontrada y corregida**: `PlaybackEngine.stop()`
  (hilo llamador) podía poner `self._stream = None` justo cuando el
  bucle monitor de `_play_loop` (su propio hilo) leía
  `self._stream.active` — `AttributeError` no fatal pero real en el
  100% de las llamadas a `stop()` observadas antes del fix. Corregida
  con una copia local del stream, inmune a la reasignación desde otro
  hilo. Verificado: 0 ocurrencias de "OutputStream:" en el log tras el
  fix, en corridas repetidas.
- **Segundo hallazgo, de infraestructura de test**: mismo patrón de
  fragilidad de orden de import entre archivos de test ya documentado
  en GAP-036/037/041 (`<modulo>.sd = sys.modules["sounddevice"]`) —
  reapareció para `PlaybackEngine` porque los 6 tests nuevos pasaban
  aislados pero fallaban en la batería completa. Resuelto con el mismo
  patrón ya establecido.

## Nota sobre flakiness preexistente (no introducida por este GAP)

Durante la verificación de este GAP se observó, en una corrida
aislada, un fallo intermitente de
`test_capture_engine_end_to_end.py::test_real_pipeline_writes_audio_
to_disk` (`frames_written == 0`). Este es el MISMO defecto de timing
real ya documentado en GAP-052 (`ESTADO_MAESTRO_CONSOLIDACION.md`,
"Fragilidad de timing real en `DiskWriterV2`/`ColaElasticaDisco`"):
correr el ciclo completo de `CaptureEngineV2` en este sandbox es
intermitente por timing de hilos, no por ningún cambio de este GAP
(código completamente distinto — `CaptureEngineV2`/captura, no
`PlaybackEngine`/reproducción). Confirmado no relacionado: 3 corridas
adicionales aisladas de ese archivo (2 limpias, 1 con timeout por
lentitud del sandbox, ninguna con el mismo fallo determinista) y 2
corridas limpias completas de la suite entera (las empaquetadas en
`_test_run_full.txt`, ambas 492/492 sin fallos). Sigue siendo, como ya
lo era desde GAP-052, candidata real para Fase 10 (Fault Injection) o
un futuro ajuste de timing — no resuelta aquí.

`lorito_bootstrap.py` reverificado explícitamente (con
`_install_stub_modules()` de `test_stability_patch.py`, el stub
canónico del proyecto para este propósito).

486 tests preexistentes (0.10.015) + 6 integración `PlaybackEngine` =
492.

Versión NO elevada a 0.11 (instrucción explícita del usuario — solo al
completar las 12 fases de la Orden).
