# TEST_REPORT_0.10.017

493/493 tests, 0 fallidos, con y sin -W error::ResourceWarning (1 skip
preexistente, no relacionado: árbol fuente de CRAC ausente en este
sandbox). ~96s por corrida completa (antes de este GAP: ~134s).

Segunda continuación autónoma ("Continuar.") tras 0.10.016 (GAP-063).
Ver `gaps/GAP-064.md` para el detalle completo.

- **Defecto real corregido**: `DiskWriterV2.flush()` esperaba el
  `timeout` completo (30s por defecto) en cada llamada mientras el
  hilo de escritura seguía activo — medido: 35.9s para un test que
  solo captura 0.3s de audio, por esta única llamada. Corregido
  acotando la espera final a `CE_DISK_FLUSH_SETTLE_MAX_S` (2.0s, nueva
  constante), sin tocar el hot path del hilo de escritura. Resultado
  medido: 35.9s → 7.9s en el test afectado; ~134s → ~96s en la suite
  completa. Test de regresión permanente añadido
  (`TestDiskWriterFlushSettleBound`, aislado, ~2s).
- **Investigación real de la flakiness documentada desde GAP-052**
  (`DiskWriterV2`/`ColaElasticaDisco`): se descartó con evidencia real
  (40 corridas del ciclo completo en un proceso, conteo de hilos
  activos tras cada una) la hipótesis de fuga de hilos —
  `active_threads == 1` en las 40 corridas, sin excepción. Se
  reprodujo el mecanismo real: la cola elástica se satura y descarta
  frames POR DISEÑO (`put_nowait()`, GAP-031) bajo ruido de scheduling
  del sandbox combinado con un stub de entrada deliberadamente más
  rápido que tiempo real (`block_interval=0.0`) — no un defecto de
  producción alcanzable con hardware de audio real. No se "corrige"
  (no hay nada que corregir en código de producción); se documenta con
  más precisión que antes.

## Nota sobre flakiness preexistente confirmada de nuevo (no una regresión)

Durante la empaquetación de este GAP, la PRIMERA corrida de la suite
completa (plana, sin `-W error::ResourceWarning`) volvió a mostrar el
MISMO fallo intermitente ya analizado arriba y en `gaps/GAP-064.md`:

```
FAIL: test_real_pipeline_writes_audio_to_disk
AssertionError: 0 not greater than 0   (status.frames_written)
```

Es el síntoma exacto ya visto en GAP-063 y ahora explicado en detalle
en GAP-064 (ruido de scheduling del sandbox sobre un stub de entrada
más rápido que tiempo real — no una regresión introducida por el fix
de `flush()` de este mismo GAP, que de hecho REDUCE la ventana de
exposición total de la suite en ~38 segundos). Dos corridas
adicionales inmediatas de la suite completa (las empaquetadas en
`_test_run_full.txt`) resultaron ambas limpias: 493/493, 0 fallos.

`lorito_bootstrap.py` reverificado explícitamente.

492 tests preexistentes (0.10.016) + 1 nuevo (`TestDiskWriterFlushSettleBound`) = 493.

Versión NO elevada a 0.11 (instrucción explícita del usuario — solo al
completar las 12 fases de la Orden).
