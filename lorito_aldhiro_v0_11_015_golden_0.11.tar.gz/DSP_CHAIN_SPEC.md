# DSP_CHAIN_SPEC.md — Especificación de la cadena DSP PREVI / NR

Orden: LA-GOLDEN-DSP-PREVI-NR-001 (NR-01…NR-03, DSP-01…DSP-07), Lorito
Aldhiro 0.11.001. Código: `backend/dsp/lorito_dsp_contract.py` (contrato
único), `backend/nr/lorito_nr_coordinator.py` (coordinador). Pruebas:
`tests/test_dsp_golden.py` (18 casos), `tests/test_nr_systems.py` y el banco
`tools/bench_nr_fidelity.py` → `NR_FIDELITY_BENCH.md`.

## 1. Principio rector

La cadena DSP **nunca toca el RAW**. En captura, su salida va al hermano
`_DERIVED.wav`, con procedencia JSON (`describe_chain()`, `config_hash()`,
`chain_latency_frames`). En reproducción y exportación, toda salida
procesada se clasifica como DERIVED.

## 2. Orden canónico y familias (DSP-03, DSP-05)

`CANONICAL_ORDER`: muscle_eq → cristhi_cosh → antipestal →
lucha_enloquecida → eq_bias → mpx → nr → hx_pro → alc → focus →
version_o_tron.

| Etapa | Familia | Fidelidad declarada | Invariante al tamaño de bloque |
|---|---|---|---|
| muscle_eq | EQ_CORRECTION | DESIGN (biquads RBJ) | sí |
| cristhi_cosh | RESTORATION_PREVI | APPROXIMATION | no → adaptador |
| antipestal | RESTORATION_PREVI | APPROXIMATION | no → adaptador |
| lucha_enloquecida | CREATIVE_EFFECT | CREATIVE (DERIVED creativo, jamás restauración) | no → adaptador |
| eq_bias | TAPE_EQ_VOICING | APPROXIMATION | sí |
| mpx | PILOT_FILTER | DESIGN | sí |
| nr | NR_DECODE | APPROXIMATION (no certificada con hardware) | sí |
| hx_pro | RECORD_BIAS_SIMULATION | APPROXIMATION (técnica de grabación, no decodificador) | no → adaptador |
| alc | LEVEL_CONTROL | DESIGN | no → adaptador |
| focus | AZIMUTH_SIMULATION | APPROXIMATION | no → adaptador |
| version_o_tron | CREATIVE_EFFECT | CREATIVE | no → adaptador |

`REFERENCE_VALIDATED` existe en el contrato, pero **ninguna etapa lo
cumple hoy**.

Casos de uso: `CAPTURE_LIVE`, `PLAYBACK`, `OFFLINE_RESTORATION`, `CREATIVE`.
`chain_warnings(use_case)` advierte de:

- HX Pro en reproducción (es bias de grabación);
- NR en modo ENCODE al capturar o reproducir;
- efectos creativos fuera del caso CREATIVE (la salida es DERIVED creativa);
- cualquier NR activa (emulación aproximada).

## 3. Contrato único (NR-03)

- `validate_config(sample_rate, channels)`: rates soportados (22,05–192 kHz)
  y canales 1–2.
  Cualquier otro valor lanza `DSPContractError`.
- `validate_block(block, channels)`: forma, dtype y finitud. Con mono se
  aceptan vectores 1D.
- Un token NR o un modo desconocido es un error tipificado
  (`DSPContractError`), nunca un bypass silencioso.
- Un fallo de etapa se convierte en `DSPStageError` con el nombre de la
  etapa (excepción o forma de salida inválida).

## 4. Continuidad de bloque (DSP-04)

El banco de continuidad midió 15 configuraciones cuya salida dependía del
tamaño de bloque del host. Ahora `FixedBlockAdapter(stage, channels,
block=256)` re-bloquea internamente a 256 frames con latencia constante
declarada. Todas las etapas producen el mismo resultado con cualquier
partición del flujo (`BlockContinuity`). Las etapas inactivas no se
envuelven, porque son passthrough exacto.

> **Actualización 0.11.014 (Orden SERVO-016):** el re-bloqueo es ahora ÚNICO
> para toda la cadena (256 frames cuando alguna etapa lo necesita, o siempre
> durante la captura: latencia constante, LATENCY_ALIGNED), y las
> transiciones de etapas son con crossfade lineal de 10 ms. Ver
> `PREVI_NR_SERVO_GOLDEN.md` §2.

## 5. Concurrencia y reconfiguración (NR-02, DSP-04)

- Un `RLock` serializa `process_chunk` y **todas** las mutaciones. La GUI
  no muta coeficientes durante un bloque: los cambios se aplican en
  frontera de bloque (`GuiConcurrency`).
- `set_stage_params()` es la única vía de la GUI para mover parámetros
  (sliders OPTAPE).
- `reconfigure(sample_rate, channels)` es transaccional:
  - valida y construye instancias nuevas de todas las etapas activas,
    incluidas Cristhi Cosh, Antipestal, Lucha Enloquecida, Versión O Tron y
    Muscle EQ, conservando parámetros y bandas;
  - publica todo junto, y si cualquier construcción falla la cadena
    anterior queda intacta;
  - `warm_up()` precalienta (JIT o estado) antes de usar la cadena.

## 6. Integridad numérica y saturación (DSP-01, DSP-02)

- Guarda de finitud por etapa, dentro del adaptador vía `on_output`: un
  NaN/Inf se sanea, la etapa se resetea y se registra un `IntegrityEvent`
  (etapa, bloque/frame, causa, política). `integrity_state` pasa a
  `DEGRADED`. La sesión no puede clasificarse `ARCHIVAL_SAFE`
  (`DSP_NONFINITE_SANITIZED`, ver ARCHIVAL_CONTRACT.md).
- La saturación por etapa se **cuenta** (`saturated_samples`) y nunca queda
  silenciosa.

## 7. Telemetría por etapa (DSP-06, DSP-07)

`StageTelemetry` registra:

- bloques y frames procesados;
- tiempo de ejecución (suma, máximo y ventana reciente para percentiles);
- picos de entrada y salida, muestras saturadas y muestras no finitas;
- resets con su motivo, fallos y excesos de presupuesto de tiempo real.

`telemetry()` devuelve snapshots de solo lectura y `config_hash()` la huella
de la configuración. No hay logging síncrono por bloque.

## 8. Fidelidad NR (NR-01)

`NR_FIDELITY_BENCH.md` (determinista) mide, por perfil, la ganancia DECODE
a −40/−20/−10 dBFS y el error ENCODE→DECODE de 100 Hz a 10 kHz:

- DOLBY_B/C/S, ANRS, DNL y DNR son **filtros estáticos**: la dependencia de
  nivel entre −40 y −10 dBFS es de 0,00 dB. Una NR de consumo real depende
  del nivel, así que estos perfiles **no** emulan compansión.
- DBX I/II/224 y S_ANRS sí son companders dependientes de nivel
  (aproximadamente 19–20 dB).
- Peor error de ida y vuelta: de 1,65 dB (DOLBY_B, ANRS) a 11,54 dB (DNR).
- Todos son deterministas y finitos.

Tolerancias declaradas (`NR_DECLARED_ROUNDTRIP_TOL_DB`, con margen sobre lo
medido; DNL y DNR solo decodifican, sin ida y vuelta) y verificadas por
`NrEncodeDecode`. **Clasificación de todos los perfiles: APROXIMACIÓN.**
Elevarlos exige curvas, niveles de referencia y tiempos de
ataque/liberación medidos sobre hardware Dolby/dbx/ANRS real (hojas de
datos NE545/NE645/LM1112 y manuales de servicio; ver REFERENCIAS §2), algo
que este entorno no tiene.
