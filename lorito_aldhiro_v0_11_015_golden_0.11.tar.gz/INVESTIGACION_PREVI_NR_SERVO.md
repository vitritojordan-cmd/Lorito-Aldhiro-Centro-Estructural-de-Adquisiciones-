# Investigación de referencia: emulaciones NR, HX Pro y servo (Lorito Aldhiro)

Fecha: 2026-10-13. Método: WebSearch (resúmenes de resultados) y lectura directa de fuentes de GitHub (raw.githubusercontent.com). El proxy bloqueó Wikipedia, rossbencina.com, zff.dev y archive.org; los datos de esas páginas proceden de los resúmenes del buscador, que se citan con su URL.
Convención: cada dato lleva su URL. **[NO VERIFICADO]** = no se encontró en ninguna fuente consultada (conocimiento general o inferencia de ingeniería).

---

## 1. Dolby B, C y S (sistemas complementarios de banda deslizante)

### Principio
- B y C son compansores de **banda deslizante**: al codificar realzan los agudos según la amplitud y el contenido de la señal, y al decodificar aplican el corte complementario. C comprime más que B. — https://patents.google.com/patent/US4476502
- Dolby B (1968, de consumo) usa **una sola banda deslizante** dirigida al siseo de altas frecuencias, en lugar de las bandas fijas múltiples de Dolby A. — https://en.wikipedia.org/wiki/Dolby_noise-reduction_system
- La compresión y la expansión suelen actuar sobre componentes **por encima de 200 Hz** (patente de NR de tipo Dolby). — https://patents.google.com/patent/US4476502
- Comportamiento según nivel (B): una señal de bajo nivel se realza **10 dB**; las señales al **nivel Dolby (+3 VU)** no se modifican; entre ambos extremos la acción es progresiva. La de-énfasis en reproducción depende de la componente relativa **por encima de 1 kHz**. — https://en.wikipedia.org/wiki/Dolby_noise-reduction_system (resumen del buscador)
- Característica de transferencia de A y B: "porción lineal de bajo nivel hasta un umbral", seguida de la acción del compansor. — https://www.nctatechnicalpapers.com/Paper/1983/1983-audio-noise-reduction-in-cable-systems/download
- Umbral concreto de B (p. ej. −40 dB) o esquina de 500 Hz: **[NO VERIFICADO]**.

### Magnitud de la reducción
| Sistema | Reducción | Fuente |
|---|---|---|
| B | ≈10 dB a 5 kHz | https://patents.google.com/patent/US4476502 |
| B | ≈10 dB en agudos | https://www.sweetwater.com/insync/dolby-b/ |
| C | ≈20 dB a 5 kHz | https://patents.google.com/patent/US4476502 |
| C | 20 dB con ponderación CCIR, mediante 2 procesadores de banda deslizante en serie | https://www.nctatechnicalpapers.com/Paper/1983/1983-audio-noise-reduction-in-cable-systems/download |
| S | 24 dB en agudos, 10 dB en graves | https://ns2.rapmag.com/a/91/nov91/the-cheat-sheet-r-dat-dcc-md-and-dolby-s |
| SR (profesional) | hasta 25 dB | https://en.wikipedia.org/wiki/Dolby_SR ; https://www.rapmag.com/a/93/feb93/radio-systems-rs2-noise-reduction-phase-correction-review |

### Dolby C: etapas en cascada, *spectral skewing* y antisaturación
- C son **dos compresores y dos expansores en cascada**; las ganancias de cada etapa se suman en dB hasta unos 20 dB. Los umbrales están **escalonados** para aumentar la acción dinámica total sin subir las relaciones máximas de compresión. — https://www.nctatechnicalpapers.com/Paper/1983/1983-audio-noise-reduction-in-cable-systems/download ; https://patents.google.com/patent/US5185806
- *Spectral skewing*: reduce el nivel de **10–20 kHz** antes del compresor para disminuir los errores de codificación/decodificación en esa banda. — https://patents.google.com/patent/US4476502
- *Antisaturación*: actúa a nivel alto para evitar la saturación de la cinta, la pérdida de agudos y el aumento de la distorsión. — https://patents.google.com/patent/US4476502
- Que C use un cruce a 400 Hz: **[NO VERIFICADO]**. Los 400 Hz aparecen en Dolby S (ver abajo).

### Dolby S (derivado de SR)
- Basado en Dolby SR; comparte la combinación de **bandas fijas y deslizantes**, la antisaturación, el *spectral skewing* y el control de modulación. — https://www.sweetwater.com/insync/dolby-s/
- Arquitectura: **una banda fija de graves por debajo de 200 Hz**, y otras **cuatro etapas que actúan desde 400 Hz hacia arriba**. Máximo de **24 dB**. Los filtros deslizantes de agudos tienen el **umbral 25 dB por debajo del nivel Dolby**. — https://www.muzines.co.uk/articles/dolby-s-explained/2897

### Nivel Dolby y calibración
- Existen cintas de nivel Dolby de **400 Hz a 200 nWb/m (ANSI)**, p. ej. A.N.T. L04. — https://ant-audio.co.uk/products/alignment-tapes
- Hay ambigüedad DIN/ANSI: HPR vende cintas de 400 Hz a 200 y a **218 nWb/m**. Es una opinión de foro. — https://stereo2go.com/forums/posts/78716/
- El tono Dolby de 400 Hz (B/C) se modula periódicamente en frecuencia. — https://www.richardhess.com/manuals/Dolby/_____DolbyTone_reference.pdf
- Una norma IEC que fije 200 nWb/m como "nivel Dolby" de casete: **[NO VERIFICADO]**. Ninguna fuente consultada cita la norma.

### Seguimiento (*tracking*) y métodos de prueba
- Requisito ideal: la cadena codificación→decodificación no debe producir cambios globales de dinámica, respuesta en frecuencia, fase ni transitorios. — https://www.richardhess.com/manuals/Dolby/dolby_422.pdf
- El *mistracking* aparece cuando la cadena lateral del decodificador no coincide con la del codificador, por pérdidas de nivel (*dropouts*), por cambios de marca o tipo de cinta y por un error de calibración del nivel de trabajo. — https://patents.google.com/patent/US6556685
- **Barrido por niveles** usado para validar un emulador digital de Dolby B: senoides de **0 dB a −45 dB respecto al nivel Dolby, en pasos de 5 dB**, midiendo la respuesta en frecuencia de cada nivel. — https://patents.google.com/patent/US6934593
- Banco de laboratorio (Dolby C, Tandberg 3014A): tonos mezclados a **+5, 0, −5, −10, −15, −20 y −25 dB**, con referencia de 400 Hz ajustada a 387,5 mV en el punto de prueba. — https://lab2104.tu-plovdiv.bg/?p=626
- Un procedimiento estándar IEC "−20/−30/−40 dB" para B: **[NO VERIFICADO]**.

### Emuladores de software
- **libdolbyb** (Codeberg, grupo sox_ng, GPL-2.0, v1.0.1): emula la electrónica de una unidad Dolby B real. Es una traducción a C de dolbybcsoftwaredecode.sf.net (Pascal). Codifica y decodifica, solo B. Está integrado como efecto en sox_ng. — https://zff.dev/sox_ng/libdolbyb ; https://pkgdex.org/solus/rolling/x86_64/unstable/libdolbyb-1.0.1.rpm.html
- Su parámetro "threshold gain" compensa la falta de una correspondencia fija entre el nivel de la cinta y el digital. Hoy el método recomendado es **ajustarlo de oído**. — https://forum.audacityteam.org/t/adding-dolbyb-encoding-decoding-to-audacity/142185
- DDi Codec (comercial, B/C) incluye herramientas de calibración y azimut. — https://www.waerfa.com/ddi-codec-for-dolby-b-c-nr
- **Consecuencia para el banco de referencia**: sin un tono de nivel Dolby grabado en la propia cinta, el umbral del decodificador es una estimación. Una decodificación sin calibración documentada no debe etiquetarse "fiel" **[NO VERIFICADO: criterio de ingeniería]**.

---

## 2. dbx Tipo I y Tipo II
- Compansión **2:1** en la grabación con pre-énfasis y **1:2** en la reproducción con de-énfasis. Lineal en un rango de **100 dB**, sin tonos piloto ni calibración. — https://en.wikipedia.org/wiki/Dbx_(noise_reduction)
- Detección **RMS verdadera** en la cadena de control. — https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/5091957
- Tipo I: para máquinas de respuesta plana (≥15 ips), con detectores de **≈22 Hz a 21 kHz**. Tipo II: para soportes de agudos irregulares y menos *headroom* (casete), con detectores de **≈30 Hz a 10 kHz** y mayor pre-énfasis en el detector. **Son incompatibles entre sí.** — https://en.wikipedia.org/wiki/Dbx_(noise_reduction)
- Al ser de banda ancha, exige una coincidencia exacta de nivel y respuesta, y el siseo puede oírse bajo material de graves. — https://www.soundonsound.com/techniques/tape-noise-reduction
- Constantes de tiempo RMS y esquinas exactas de pre-énfasis: **[NO VERIFICADO]**. dbx 224: **[NO VERIFICADO]** (sin datos encontrados).

---

## 3. Otros sistemas
- **JVC ANRS**: descrito como compatible con Dolby B sin infringir sus patentes. **Super ANRS** añade compansión de agudos extremos o extensión de *headroom*; las fuentes discrepan sobre su compatibilidad con B. — https://cool.culturalheritage.org/byform/mailing-lists/arsclist/2007/10/msg00409.html ; https://www.vintagedigital.com.au/?p=208104. Cifras de dB: **[NO VERIFICADO]**.
- **Philips DNL** (finales de los 60): **solo en reproducción**, no requiere codificación. Atenúa los agudos únicamente cuando el nivel global es bajo. — https://en.wikipedia.org/wiki/Dynamic_Noise_Limiter. La cifra "hasta 10 dB" procede solo de anuncios de vendedores. — https://beta.usedproducts.nl/p/philips-n2552-topklasse-3-koppen-stereo-cassettedeck-gereviseerd/655902328/
- **National LM1894 (DNR)**: **no complementario, de un solo extremo** (*single-ended*), compatible con cualquier cinta pregrabada y con FM. Logra **≈10 dB** (ponderación CCIR/ARM) mediante enmascaramiento psicoacústico y ancho de banda adaptativo. Alimentación de 4,5 a 18 V; sobrecarga de entrada a 1 Vrms. Notas de aplicación AN-386 y AN-390. — https://www.ti.com/product/LM1894 ; https://www.radiolocman.com/datasheet/data.html?di=296905
- **Telefunken High Com** (desde 1978): compansor de banda ancha **2:1:2**; 15–20 dB(A) para High Com y 20–25 dB(A) para High Com II (dos bandas deslizantes). — https://en.wikipedia.org/wiki/High_Com ; https://ernstschroeder.de/highcom.htm

---

## 4. HX Pro: un efecto de la ruta de grabación, no un decodificador
- HX Pro **varía el bias de grabación** según la energía de agudos de la propia señal, porque los agudos fuertes actúan como bias. Así evita la saturación y el sobre-bias, y permite grabar con mayor flujo. — https://www.soundonsound.com/node/4921749 ; https://www.sweetwater.com/insync/hx-pro/
- **No es reducción de ruido, no requiere decodificación** y solo se aplica al grabar. Las cintas grabadas con HX Pro **se reproducen bien en cualquier platina**. — https://www.sweetwater.com/insync/hx-pro/ ; https://www.nfsa.gov.au/preservation/preservation-glossary/hx
- Historia: Dolby HX (de prealimentación, *feedforward*, 1979) fue rechazado por la industria. **HX Pro**, de realimentación negativa, fue desarrollado por **Bang & Olufsen** y comercializado por Dolby, y se convirtió en el estándar de facto a mediados de los 80. — https://en.wikipedia.org/wiki/Adaptive_biasing
- Ganancia de *headroom*: **≈10 dB**, manteniendo la respuesta IEC. Ojo: la patente corresponde al sistema Dolby HX, no a HX Pro. — https://patents.google.com/patent/US4345281. Una cifra específica de HX Pro en agudos: **[NO VERIFICADO]**.
- **Implicación para el software** (inferencia a partir de las fuentes anteriores): HX Pro no debe aparecer nunca como decodificador de reproducción. Si se modela, es un efecto de la ruta de grabación (saturación de cinta dependiente del bias o de los agudos). Ante una cinta marcada "HX Pro", la reproducción correcta es **sin procesamiento HX**, aplicando solo el NR (B/C/S) que indique la cinta.

---

## 5. NR complementario frente a NR de un solo extremo
- **Complementario**: comprime al grabar y expande al reproducir, con lo que el ruido de la cinta queda por debajo. El decodificador debe igualar al codificador en cadena lateral, nivel y respuesta; si no, aparecen *mistracking* y errores de ganancia. — https://patents.google.com/patent/US6556685
- **Un solo extremo**: actúa solo en la reproducción sobre el ruido presente, sin codificación. Por eso sirve para emisiones o grabaciones antiguas sin codificar. — https://www.electro-tech-online.com/custompdfs/2005/06/AN-384.pdf ; https://www.electro-tech-online.com/custompdfs/2005/06/AN-386.pdf
- Encadenar sistemas (*tandeming*) degrada el resultado tanto en los complementarios como en los no complementarios. — https://www.ioa.org.uk/system/files/publications/JAS%20ANGUS%20TANDEMING%20EFFECTS%20IN%20NOISE%20REDUCTION%20SYSTEMS.pdf
- **Clasificación propuesta para el banco** (criterio derivado, **[NO VERIFICADO]** como norma):
  - *Fiel*: decodificador complementario con calibración de nivel Dolby documentada, validado con un barrido 0…−45 dB contra la referencia.
  - *Aproximación*: decodificador complementario sin calibración (umbral estimado), o un sistema de un solo extremo (DNL/DNR) aplicado a señal sin codificar.
  - *Experimental*: ANRS/Super ANRS, High Com, dbx II y Dolby S sin implementación de referencia validada.

---

## 6. Servo: varispeed, *scrub*, *seek* y suavizado

### Fundidos y desclic
- Vegas: la duración por defecto de "quick fade" es **10 ms**, y 1 ms se reporta inaudible. — https://www.vegascreativesoftware.info/us/forum/autofade-when-cut--85637
- Audition: al dividir un clip crea fundidos de 10 ms; un experto recomienda **5 ms**. — https://community.adobe.com/questions-549/feature-request-automatic-clip-fades-314794
- Sound On Sound recomienda microfundidos de **1–5 ms** en las ediciones. — https://www.soundonsound.com/node/4906063
- Reaper crea fundidos "muy cortos" al dividir; el valor se configura en Media Item Defaults. — https://reaper.blog/2012/06/editing-audio-items-in-reaper/

### Fundido cruzado lineal frente a potencia constante
- Regla práctica: **potencia constante (≈−3 dB en el centro)** para señales no correladas y **lineal (−6 dB)** para señales correladas; la potencia del resultado depende de la correlación. — https://www.hsu-hh.de/ant/wp-content/uploads/sites/699/2017/10/Fink-Holters-Zölzer-2016-Signal-matched-power-complementary-cross-fading-and-dry-wet-mixing.pdf ; https://git.ardour.org/ardour/manual/commit/9ab3009544de388b1e564dab28839462bef96df9
- Implicación: al reanudar tras un *seek* en el mismo material (señales correladas) conviene el lineal; entre posiciones distintas, la potencia constante [inferencia].

### Rango de varispeed en platinas
- TEAC W-1200: pitch **±12 %**, solo en reproducción de TAPE1. — https://teac.jp/int/product/w-1200/spec
- TASCAM 112mkII: aprox. **±12 %**, con interruptor de activación. — https://canonbase.eu/w/images/3/31/Tascam_112mkII-TechDoc.pdf
- TASCAM 202mkV: ±12 % en el Deck 1. — https://vintageking.com/tascam-202-mkv
- ±10 %: **[NO VERIFICADO]**.

### Suavizado de parámetros
- JUCE `SmoothedValue`: por defecto es **Linear** (rampa lineal, no un polo único). `reset(sampleRate, rampLengthInSeconds)` fija los pasos como floor(rampa·fs). `Multiplicative` sirve para dB y Hz y **no puede alcanzar 0**. — https://raw.githubusercontent.com/juce-framework/JUCE/master/modules/juce_audio_basics/utilities/juce_SmoothedValue.h
- Suavizador de un polo: polo = **exp(−1/(τ·fs))** (Faust `tau2pole`). Otras implementaciones usan exp(−2π·fc/fs); las convenciones difieren en un factor 2π. — https://scm.cri.ensmp.fr/git/Faustine.git/blob/043c676f59520b93dfacfa0d8d7e1fdd448cd7dc:/interpretor/faust-0.9.47mr3/architecture/filter.lib ; https://forum.bela.io/d/4162-smooth-the-zippering-noise-on-trill-bar
- Un coeficiente fijo cambia de comportamiento con la frecuencia de muestreo; hay que calcularlo a partir de τ y fs. — https://www.musicdsp.org/en/latest/Filters/257-1-pole-lpf-for-smooth-parameter-changes.html
- Un valor de τ recomendado en ms contra el *zipper noise*: **[NO VERIFICADO]**.

### Invalidación de *seeks* por generación o ticket
- No se encontró referencia publicada. **[NO VERIFICADO]**. Es un patrón de ingeniería: cada petición de *seek* incrementa un contador atómico, y los bloques o lecturas con una generación antigua se descartan en el hilo de audio sin bloquear.

### Reglas de tiempo real (Bencina)
- El artículo "Real-time audio programming 101: time waits for nothing" (rossbencina.com, 2011) es lectura obligada según Paul Davis (LAD). — https://lists.linuxaudio.org/archives/linux-audio-dev/2011-July/030643.html
- Un enlace del artículo (página de ringbuffers del wiki de JACK) apunta a una versión antigua y "al menos medio equivocada". — https://lists.linuxaudio.org/archives/linux-audio-dev/2011-July/030649.html
- Reglas concretas (el proxy bloqueó la lectura directa): no usar locks/mutex, no reservar memoria, no hacer E/S de ficheros ni llamadas al sistema que bloqueen, y no usar algoritmos de tiempo no acotado en el callback; comunicar mediante FIFO sin locks. **[NO VERIFICADO textualmente]**

---

## 7. Denormales (subnormales)
- Cuestan CPU porque suelen procesarse mediante una **asistencia por software o microcódigo**, no directamente en hardware. — https://www.intel.com/content/www/us/en/docs/onemkl/developer-guide-linux/2023-2/operating-on-denormals.html
- En x86, una instrucción con operandos subnormales puede costar **hasta ~100 ciclos extra**, es decir, las instrucciones más rápidas son hasta **6× más lentas**. — https://en.wikipedia.org/wiki/Subnormal_number
- Microbenchmark: una división sobre denormales es **50× más lenta**, con 100 millones de asistencias FP frente a 0. — https://easyperf.net/blog/2018/11/08/Using-denormal-floats-is-slow-how-to-detect-it
- MathWorks: hasta **50×** más lento, típicamente **5×** en CPU de escritorio. — https://www.mathworks.com/help/rtw/ug/subnormal-number-performance.html
- En audio aparecen en colas de envolventes y filtros que decaen. — https://tytel.org/blog/2015/02/10/unexpected-optimization-01/
- **FTZ/DAZ**: FTZ vuelca a cero los resultados y DAZ trata como cero las entradas (bits de MXCSR). Pueden afectar ligeramente a la precisión. — https://gnats.NetBSD.org/50940 ; https://www.intel.com/content/www/us/en/docs/onemkl/developer-guide-linux/2023-2/operating-on-denormals.html
- JUCE `disableDenormalisedNumberSupport()` / `ScopedNoDenormals` activa DAZ y FZ en MXCSR (Intel) y FZ en ARM. — https://raw.githubusercontent.com/juce-framework/JUCE/master/modules/juce_audio_basics/buffers/juce_FloatVectorOperations.h
- Chromium usa la máscara MXCSR **0x8040** (DenormalDisabler). — https://chromium.googlesource.com/chromium/blink/+/HEAD/Source/platform/audio/DenormalDisabler.h
- Alternativa: sumar un valor diminuto redujo la CPU de **~90 % a ~3 %** en un modelo físico. — https://ccrma.stanford.edu/~mwilson/blog/2011-04-17.html
- **NumPy**: usa subnormales entre 0 y `finfo.smallest_normal`; `finfo.smallest_subnormal` es el mínimo positivo, con precisión reducida. — https://numpy.org/doc/2.2/reference/generated/numpy.finfo.html. Para float32, smallest_normal = 2^−126 ≈ 1,175e−38 y smallest_subnormal = 2^−149 ≈ 1,4e−45 (estándar IEEE; se puede verificar con `np.finfo(np.float32)`) **[NO VERIFICADO en la fuente consultada]**.
- **Numba (CPU)**: `fastmath=True` o un conjunto de flags LLVM (`reassoc`, `nsz`, …) solo habilita transformaciones algebraicas inseguras, más SVML si está instalado. La documentación **no menciona FTZ/DAZ** para CPU. — https://raw.githubusercontent.com/numba/numba/main/docs/source/user/performance-tips.rst ; https://raw.githubusercontent.com/numba/numba/main/docs/source/reference/jit-compilation.rst. En **CUDA**, en cambio, `fastmath=True` sí vuelca los denormales a cero. — https://github.com/numba/numba/blob/0.57.0rc1/docs/source/cuda/fastmath.rst
- Detección o conteo recomendado **[NO VERIFICADO como práctica publicada]**: por bloque, contar `np.count_nonzero((x != 0) & (np.abs(x) < np.finfo(x.dtype).smallest_normal))` en los estados de los filtros y en la salida, fuera del hilo de tiempo real o con el resultado ya calculado. Opcionalmente, aplicar un vaciado explícito (estado = 0 si |estado| < umbral). Con perf/VTune se pueden contar las asistencias FP (método Easyperf, https://easyperf.net/blog/2018/11/08/Using-denormal-floats-is-slow-how-to-detect-it).
