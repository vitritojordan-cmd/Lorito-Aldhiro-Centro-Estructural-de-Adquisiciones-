# ORDENES_GOLDEN_0_11_ESTADO.md — Estado de las cinco Órdenes Golden (0.11.001 → 0.11.007)

Cinco órdenes de ingeniería, todas con veredicto inicial **NO-GO**, se
aplicaron al tarball `lorito_aldhiro_v0_11_001_release_candidate_0.11.tar.gz`
(SHA-256 `a18f4a89f56999acd180805fad8140061facec77f6b6fe2f144c53eeae31ce48`).
Objetivo: **sustituir los motores viejos por los nuevos descritos en cada
orden**.

Resultado de la batería: **743 pruebas, 0 fallos** en 0.11.007; **756** en 0.11.008, **760** en 0.11.009, **781** en 0.11.010, **796** en 0.11.011, **831** en 0.11.012, **833** en 0.11.013 y **891** en 0.11.014 (skips
sin relación). En el tarball de partida eran 598. Ver
`saneamiento_0_11_007/TEST_REPORT_0.11.007.md`.

Leyenda:

- **RESUELTO**: implementado en el motor productivo y cubierto por pruebas
  automatizadas.
- **MEDIDO/CLASIFICADO**: el hallazgo no se "arregla" con código; se midió y
  se declaró honestamente.
- **PENDIENTE-HW**: exige hardware, tiempo de reloj real o personas que este
  entorno no tiene.

## 1. Captura (CAP-001…CAP-012) — CAPTURE_ARCHITECTURE_GOLDEN.md

| ID | Hallazgo | Estado | Evidencia |
|---|---|---|---|
| CAP-001 | bloqueo en `write()` con Condition | RESUELTO: `SPSCCaptureRing` sin locks | `test_capture_golden` T-02/T-03 |
| CAP-002 | overwrite-oldest y truncamiento | RESUELTO: rechazo explícito e invalidación | T-01, T-02, T-03 |
| CAP-003 | stop sin barrera de drain | RESUELTO: `request_stop()`/`finalize()` en fases | T-06 |
| CAP-004 | error de disco sin transición | RESUELTO: fail-stop global con razón persistente | T-05 |
| CAP-005 | trabajo en callback | RESUELTO: callback mínimo; telemetría en el drain | T-08 |
| CAP-006 | `starvation_events` contado dos veces | RESUELTO | T-09 |
| CAP-007 | doble conteo de XRun | RESUELTO: contadores por tipo | T-09 |
| CAP-008 | join del writer vence | RESUELTO: `WriterCloseResult` explícito | T-06 |
| CAP-009 | flush sin fsync final | RESUELTO: `flush_barrier(seq)` + fsync de directorio | T-05, T-06 |
| CAP-010 | CED llena descarta | RESUELTO: backpressure + fail-stop | T-03, T-04 |
| CAP-011 | watchdog contra el ciclo de vida | RESUELTO: `CaptureSessionFSM` + generación | T-07, `test_capture_recovery` |
| CAP-012 | clasificación sin ledger | RESUELTO: `FrameLedger` reconciliado + checksums releídos | T-10, `test_archival_reason_codes_golden` |

## 2. DSP PREVI / NR (NR-01…03, DSP-01…07) — DSP_CHAIN_SPEC.md

| ID | Estado | Evidencia |
|---|---|---|
| NR-01 fidelidad histórica | **MEDIDO/CLASIFICADO**: todos los perfiles son APROXIMACIÓN; DOLBY B/C/S, ANRS, DNL y DNR son filtros estáticos (0 dB de dependencia de nivel) · **PENDIENTE-HW** para elevarlos | `NR_FIDELITY_BENCH.md`, `test_dsp_golden` NrEncodeDecode |
| NR-02 reconfiguración incompleta | RESUELTO: transaccional, todas las etapas | Reconfigure (3 casos) |
| NR-03 contratos heterogéneos | RESUELTO: contrato único, errores tipificados | ContractAndTelemetry, `test_nr_systems` |
| DSP-01 saneamiento ≠ preservación | RESUELTO: evento de integridad + DEGRADED + bloqueo de ARCHIVAL_SAFE | FiniteGuard |
| DSP-02 clipping silencioso | RESUELTO: saturación contada por etapa | Saturation |
| DSP-03 orden por caso de uso | RESUELTO: familias, casos de uso y `chain_warnings` | ContractAndTelemetry |
| DSP-04 cambios de parámetros | RESUELTO: lock en frontera de bloque y `FixedBlockAdapter` (15 configuraciones dependientes del bloque → 0) | BlockContinuity, GuiConcurrency |
| DSP-05 creativo mezclado con restauración | RESUELTO: familia CREATIVE y solo DERIVED; el RAW nunca se toca | `test_nr_systems` |
| DSP-06 paridad Numba y tiempo real | PARCIAL: tiempos por etapa (máximo y percentiles) y presupuesto medidos; WCET en hardware de destino **PENDIENTE-HW** | ContractAndTelemetry |
| DSP-07 telemetría | RESUELTO: `StageTelemetry` + `config_hash` | ContractAndTelemetry |

## 3. Exportación (EX-01…EX-14) — EXPORT_CONTRACT.md

| ID | Estado | Evidencia |
|---|---|---|
| EX-01/02/05/06 ruta por array y bandera de migración | RESUELTO: eliminados; `ExportService` es la única ruta | `test_export_golden` EX-T01, EX-T15 |
| EX-03/04/07 preflight y formatos | RESUELTO | EX-T02, T03, T04 |
| EX-08 persistencia | RESUELTO: fsync del parcial, rename, fsync de directorio y sidecar atómico | EX-T08, T10 |
| EX-09 "verified" sin relectura | RESUELTO: SHA-256 releído tras publicar | EX-T13 |
| EX-10 ffmpeg | RESUELTO; además, bloqueo real del decodificador por stdin heredado hallado y corregido | EX-T09 |
| EX-11 normalización | RESUELTO: `NormalizationPlan` de dos pasadas | EX-T06 |
| EX-12 clase de exportación vs archivística | RESUELTO | EX-T13 |
| EX-13 progreso | RESUELTO: por frames | E2E de la GUI |
| EX-14 release limpio | RESUELTO: tarball sin bytecode, manifiesto SHA-256 y lockfile | `saneamiento_0_11_007/` |

## 4. Instrumentación / ITL / Telemetría — ITL_TELEMETRY_GOLDEN.md

| ID | Estado | Evidencia |
|---|---|---|
| INST-01/02 medidor | RESUELTO: dBFS por ventana de frames, peak-hold por tiempo (se corrigió un defecto real de decaimiento acumulativo), calidad VALID/STALE | `test_ui_itl_golden` |
| WAVE-01/02 visor | RESUELTO: envolventes por canal, vista absoluta y normalizada, cálculo fuera de la GUI | ídem |
| ITL-01 reloj por ticks | RESUELTO: reloj desde frames aceptados | TestITLFrameClock |
| ITL-02 autoridades múltiples | RESUELTO: exactamente una vez; **interbloqueo P0 real corregido** | TestITLDeadlockAndExactlyOnce |
| ITL-03 SIPA por ticks | RESUELTO: timestamps + sensor STALE | ídem |
| TAPE-01 duraciones mezcladas | RESUELTO: NOMINAL / AUDIO / ESTIMADO; **OTROS ya no hereda los automatismos de C-90** | TestTapeModelAndTimeline, `test_otros_has_no_automatisms` |
| LOG-01/02 bitácora | RESUELTO: `ForensicEventLog` como singleton de proceso, cola acotada, P0 no descartable | TestForensicEventLog |
| THREAD-01 | RESUELTO: snapshots y señales | — |

## 5. Scrubs Morpher / Velocista / Seek (SMV-01…14) — SCRUBS_TRANSPORT_ARCHITECTURE_GOLDEN.md

| ID | Estado |
|---|---|
| SMV-01, SMV-12 dos autoridades | RESUELTO: TransportMachine + SpeedPlanner como autoridad única del motor |
| SMV-02, SMV-09 crossfade en callback / ventana única | RESUELTO: política por operación, rampas precalculadas y aplicadas en el render |
| SMV-03 equal-power "garantía" | RESUELTO: retirado como defecto; DIP para seek; afirmaciones absolutas eliminadas |
| SMV-04 fade de 16 frames presentado como éxito | RESUELTO: transiciones degradadas declaradas |
| SMV-05, SMV-14 eventos ad hoc / debounce | RESUELTO: transacciones ordenadas, supersesión determinista, sin debounce |
| SMV-06 seek sin generación | RESUELTO: generación por bloque + confirmación |
| SMV-07 ratio y cursor no atómicos | RESUELTO: cursor absoluto + rampa de ratio por muestra |
| SMV-08 estado forense global | RESUELTO: ledger por sesión |
| SMV-10 deque compartido | RESUELTO: ring SPSC preasignado |
| SMV-11 cursores de UI | RESUELTO: la UI emite comandos semánticos y muestra el cursor audible |
| SMV-13 cursor en ratio ≈ 1 | RESUELTO en el lector productivo y en `resample_stateful_continuous` (exportación) |
| SMV-T01…T10 | RESUELTO: 18 pruebas Golden + banco (POP_DISCONTINUITY_TEST_REPORT.md) |
| SMV-T11…T13 | **PENDIENTE-HW** |

## 5b. PREVI · NR · Servosistemas (LA-GOLDEN-PREVI-NR-SERVO-016, 0.11.014) — PREVI_NR_SERVO_GOLDEN.md

| ID | Estado | Evidencia |
|---|---|---|
| DSP-01 contrato por motor | RESUELTO: formato declarado, errores tipados, `get_status()` | `test_previ_nr_golden` DSP01 |
| DSP-02 continuidad | RESUELTO: re-bloqueo único, también en streaming | DSP02 |
| DSP-03 numérico | RESUELTO: NaN/Inf con política explícita, subnormales y sobre-rango contados | DSP03 |
| DSP-04 reconfiguración | RESUELTO: construcción fuera del lock, frontera segura, crossfade de 10 ms, tickets | DSP04 |
| DSP-05 bypass/reset/flush | RESUELTO | DSP05 |
| NR-01 fidelidad | **MEDIDO/CLASIFICADO** por modelo y revisión (EXPERIMENTAL / DOCUMENTED_APPROXIMATION); REFERENCE_FAITHFUL **PENDIENTE-HW** | NR01, `NR_FIDELITY_BENCH.md` |
| NR-02 extremos | RESUELTO + bombeo de S-ANRS medido y declarado | NR02 |
| NR-03 combinaciones | RESUELTO: preflight P1–P5 | NR03 |
| SV-01 generaciones | RESUELTO: la puerta del callback ahora actúa | `test_servo_golden` SV01 |
| SV-02 rampas | RESUELTO: límites declarados, velocidad nula sin DC, entradas fuera de rango | SV02 |
| SV-03 disco lento/EOF/underrun | RESUELTO: STARVED / FAILED | SV03 |
| UI-01 | RESUELTO: estado efectivo, errores tipados, gestos sin efecto en la captura | `test_previ_nr_servo_ui` |
| RAW-01 | RESUELTO: re-hash del RAW tras el DSP en la procedencia | RAW01 |
| END-01 | PARCIAL: 2 min (prueba) + 10 min (banco); 23 h / 50 h **PENDIENTE-HW** | END01, `bench_endurance.json` |

## 6. Defectos reales hallados durante el trabajo

1. **Interbloqueo del hilo de GUI** en el autostop del ITL: el callback se
   ejecutaba con el `threading.Lock` del motor tomado y volvía a pedirlo.
2. **Peak-hold dependiente del número de ticks**: el decaimiento se
   acumulaba sobre el valor ya decaído.
3. **OTROS heredaba los umbrales de C-90**: pausa, volteo y stop
   automáticos en un perfil sin longitud nominal.
4. **Decodificador de validación de exportación bloqueado** por heredar el
   stdin del proceso padre: una exportación podía colgarse para siempre.
   Es la explicación más probable del cuelgue de 600 s sin causa observado
   antes en una corrida.
5. **Zona neutra del resampleador de exportación**: con |ratio−1| < 0,0005
   el cursor no avanzaba.
6. **15 configuraciones DSP dependientes del tamaño de bloque** del host.
7. (0.11.008) **Confirmaciones perdidas en el Transport Core**: los
   comandos aplicados con el ring lleno no llegaban a CONFIRMED. Está
   corregido y tiene prueba de regresión (GAP-082).
8. (0.11.012) **El DiskWriter contaba en un ledger viejo** si se llamaba
   `set_output()` antes de `start()`: `written` quedaba en 0. Producción no
   estaba afectada. Está corregido y tiene prueba de regresión (GAP-086).
9. (0.11.014) **NR y HX Pro más lentos que el presupuesto de captura**
   (bucles Python por muestra: DNR 0,71 y HX Pro 0,67 del tiempo real
   contra 0,5 de presupuesto): apagaban el DERIVED. Núcleo en Numba, bit a
   bit igual (GAP-088, H-01).
10. (0.11.014) **Puerta de generación inerte en reproducción**:
    `min_valid_gen` nunca se asignaba (H-14).
11. (0.11.014) **Gesto de servo que cerraba la captura** (`_scrub_reset_to_start`
    → `stop_all`) (H-19); **velocidad nula = DC sostenida** (H-15); **dbx
    inválido caía en silencio a II** (H-09).

## 7. Puertas pendientes (no ejecutables en este entorno)

| Puerta | Qué falta | Orden |
|---|---|---|
| Soak de 50 h de captura y de 8 h de transporte | tiempo de reloj real | Captura, SMV-T13 |
| Loopback de hardware (captura y reproducción) | interfaz de audio física | Captura, SMV-T11, G6 |
| Comparación con CRAC 0.36 | binario, fuentes y entorno de CRAC 0.36 | SMV-T12, G0 |
| Escucha ciega con dos evaluadores | personas | SMV §7 |
| Referencias Dolby/dbx/ANRS/DNL/DNR | hardware o curvas de servicio medidas | NR-01 |
| WCET y deadline misses con PortAudio real, CPU al 90 % | hardware de destino | DSP-06, SMV-T09 |
| Validación en el build free-threaded de Python | intérprete sin GIL | RT_CONTRACT.md §2 |
| Latencia del medidor LCD con buffer de dispositivo real; *true peak* (BS.1770) si se pidiera | interfaz de audio física | Medidor LCD (GAP-086) |
| Acta firmada por desarrollo, QA de audio y preservación | firmas | todas |

**Clasificación honesta**: ninguna orden se declara GOLDEN. El código
cierra todos los hallazgos P0/P1 que se pueden cerrar en software, con
evidencia automatizada, y queda **listo para la certificación de hardware**
de las puertas anteriores.
