# PREVI_NR_SERVO_GOLDEN.md — Orden Golden PREVI · Reducción de ruido · Servosistemas

**Código:** LA-GOLDEN-PREVI-NR-SERVO-016 · **Implementado en:** Lorito Aldhiro 0.11.014.

**Estado:** refactorización implementada y probada en software. La
certificación queda pendiente de la Fase G: hardware, endurance de 23/50 h
y firma de QA.

**Documentos relacionados:**

| Documento | Contenido |
|---|---|
| `saneamiento_0_11_014/AUDITORIA_PREVI_NR_SERVO.md` | Auditoría por hallazgo |
| `INVESTIGACION_PREVI_NR_SERVO.md` | Investigación con fuentes |
| `NR_FIDELITY_BENCH.md` | Banco de fidelidad NR |
| `gaps/GAP-088.md` | Detalle del cambio |
| `DSP_CHAIN_SPEC.md` y `SCRUBS_TRANSPORT_ARCHITECTURE_GOLDEN.md` | Órdenes anteriores en las que se apoya esta |

---

## 1. Inventario (Fase A)

### 1.1 Procesadores PREVI / DSP

| Etapa | Clase / archivo | Familia | Fidelidad | dtype interno | Re-bloqueo | Bypass | Lado |
|---|---|---|---|---|---|---|---|
| muscle_eq | `MuscleEqSamirProfile` · `dsp/lorito_dsp_muscle_eq_samir.py` | EQ_CORRECTION | DESIGN | float64 (Numba) | no | WET_DRY_RAMP | PLAYBACK |
| cristhi_cosh | `CristhiCoshProfile` · `dsp/lorito_dsp_cristhi_cosh.py` | RESTORATION_PREVI | APPROXIMATION | float32 | sí | CROSSFADE_REMOVE | PLAYBACK |
| antipestal | `AntipestalLolaProfile` · `dsp/lorito_dsp_antipestal_lola_grillo.py` | RESTORATION_PREVI | APPROXIMATION | float64 (Numba) | sí | CROSSFADE_REMOVE | PLAYBACK |
| lucha_enloquecida (A–T) | `LuchaEnloquecidaProfile` · `dsp/lucha_enloquecida/` | CREATIVE_EFFECT | CREATIVE | float32/float64 | sí | CROSSFADE_REMOVE | PLAYBACK |
| eq_bias | `TapeEqBiasProfile` · `dsp/lorito_dsp_eq_bias.py` | TAPE_EQ_VOICING | APPROXIMATION | float64 | no | CROSSFADE_REMOVE | PLAYBACK |
| mpx | `MpxProfile` · `dsp/lorito_dsp_mpx.py` | PILOT_FILTER | DESIGN | float64 (Numba) | no | CROSSFADE_REMOVE | PLAYBACK |
| nr (8 perfiles, ver 1.2) | `nr/lorito_nr_profiles.py` | NR_DECODE | según perfil | float64 (Numba) | no | CROSSFADE_REMOVE | PLAYBACK |
| hx_pro | `HxProProfile` · `nr/lorito_nr_hxpro.py` | RECORD_BIAS_SIMULATION | APPROXIMATION | float64 | sí | CROSSFADE_REMOVE | **RECORD** |
| alc | `AlcProfile` · `nr/lorito_nr_alc.py` | LEVEL_CONTROL | DESIGN | float64 | sí | CROSSFADE_REMOVE | PLAYBACK |
| focus | `FocusProfile` · `dsp/lorito_dsp_focus.py` | AZIMUTH_SIMULATION | APPROXIMATION | float64 (Numba) | sí (en mono, no) | CROSSFADE_REMOVE | PLAYBACK |
| version_o_tron | `VersionOTronProfile` · `dsp/lorito_dsp_version_o_tron.py` | CREATIVE_EFFECT | CREATIVE | float32/float64 | sí | CROSSFADE_REMOVE | PLAYBACK |

**Notas comunes:**

- **Formato:** todas las etapas aceptan los 8 sample rates de `SUPPORTED_RATES`, mono o estéreo, en bloques `[frames, canales]`. Entran en float32 o float64 y salen en float32.
- **Estado:** el estado es por canal. HX Pro calcula su BRF promediando los canales, y eso está declarado.
- **Latencia:** ninguna etapa tiene latencia intrínseca. El re-bloqueo fijo de 256 frames es único para toda la cadena.
- **Dónde corre:** el DSP corre SOLO en el hilo de drenado de la captura, sobre el DERIVED.
  - La reproducción y la exportación no usan el coordinador.
  - El RAW nunca pasa por el DSP.

### 1.2 Perfiles NR (por modelo y revisión)

La fuente es `NR_PROFILE_CATALOG`. Las cifras de error y de dependencia de
nivel salen de `NR_FIDELITY_BENCH.md`.

| Clave | Modelo emulado | Revisión | Sistema | Clase | Dependencia de nivel (dB) | Recuperación tras ráfaga |
|---|---|---|---|---|---|---|
| DOLBY_B | Dolby B (~10 dB en agudos) | lorito-nr/1 | complementario | EXPERIMENTAL | 0,00 | ≤ 0,5 s |
| DOLBY_C | Dolby C (~20 dB CCIR) | lorito-nr/1 | complementario | EXPERIMENTAL | 0,00 | ≤ 0,5 s |
| DOLBY_S | Dolby S (~24 dB agudos / ~10 dB graves) | lorito-nr/1 | complementario | EXPERIMENTAL | 0,00 | ≤ 0,5 s |
| DBX/I | dbx Tipo I (2:1 RMS) | lorito-nr/1 | complementario | DOCUMENTED_APPROXIMATION | 20,23 | ≤ 0,5 s |
| DBX/II | dbx Tipo II | lorito-nr/1 | complementario | DOCUMENTED_APPROXIMATION | 20,22 | ≤ 0,5 s |
| DBX/224 | dbx 224 | lorito-nr/1 | complementario | DOCUMENTED_APPROXIMATION | 19,25 | ≤ 0,5 s |
| ANRS | JVC ANRS | lorito-nr/1 | complementario | EXPERIMENTAL | 0,00 | ≤ 0,5 s |
| S_ANRS | JVC Super ANRS | lorito-nr/1 | complementario | DOCUMENTED_APPROXIMATION | 20,18 | **≤ 4,0 s** (bombeo medido, H-13) |
| DNL | Philips DNL | lorito-nr/1 | un solo extremo | EXPERIMENTAL | 0,00 | ≤ 0,5 s |
| DNR | National LM1894 | lorito-nr/1 | un solo extremo | EXPERIMENTAL | 0,01 | ≤ 0,5 s |

**Criterio de clase:**

- Ningún perfil es REFERENCE_FAITHFUL, porque no hay referencias medidas de hardware.
- **EXPERIMENTAL:** la emulación no depende del nivel. Reproduce la curva, pero no el mecanismo que define al sistema.
- **DOCUMENTED_APPROXIMATION:** compansor dependiente de nivel con tolerancia de ida y vuelta declarada.
- Una prueba verifica que la clase coincide con la dependencia de nivel medida.
- La clasificación alternativa de la investigación (§5) no está verificada como norma. Se eligió este criterio porque es medible.

### 1.3 Servosistemas

| Componente | Archivo | Propietario de |
|---|---|---|
| `PlaybackEngine` / `_Session` | `playback/lorito_playback_engine.py` | Ring SPSC, callback y cursores (requested / read_head / queued_head / audible), telemetría del servo |
| `TransportMachine` | `transport/lorito_transport_machine.py` | Modo, dirección, generaciones (play / stop / seek las incrementan) |
| `SpeedPlanner` | `transport/lorito_speed_planner.py` | Velocidad deseada → aplicada (pendiente acotada) |
| `TransitionPolicy` | `transport/lorito_transition_policy.py` | DIP / crossfade / fundidos de STOP y EOF |
| `VariableRateReader` | `playback/lorito_varispeed_reader.py` | Cursor absoluto, rampa por muestra, caché de lectura |
| `TransportLedger` / `TransportTransaction` | `transport/lorito_transport_ledger.py` | Comandos, estados, contadores, tiempos de envío / aplicación / confirmación / audible |

**Límites declarados (`SERVO_LIMITS`):**

| Límite | Valor |
|---|---|
| Ratio | de −4,0 a +4,0 |
| Pendiente | 8,0 ratio/s; aceleración = desaceleración (0,085 por bloque de 512 a 48 kHz) |
| Dirección | signo del ratio; la reversa cruza 0 de forma continua |
| Velocidad casi nula | por debajo de \|ratio\| 0,05 la salida se atenúa en proporción: una cinta detenida no produce señal |
| Seek | rango [0, total − 1]; fuera de rango se recorta y se declara |
| Ratio no finito | comando rechazado |
| Ratio fuera de rango | recortado y declarado |
| Rangos de los widgets (subconjuntos) | Velocista 0,5–2,0; Morpher −0,7…1,5 |

---

## 2. Contrato común PREVI/NR (Fase B) — `NRCoordinator`

| Orden §4 | Implementación |
|---|---|
| `prepare(config, format)` | `prepare(sample_rate, channels, use_case)`: valida, reconfigura y compila los kernels fuera del audio |
| `process(input_block, output_block)` | `process(entrada, salida)`; también existe `process_chunk(bloque) → bloque` |
| `request_reconfigure(config)` | `select` / `set_*` / `set_stage_params` / `set_mode` / `set_use_case` / `reconfigure`, cada uno devuelve un `ReconfigTicket` |
| `bypass()` | Apagar una etapa la saca de la cadena con crossfade. La semántica de bypass está declarada por etapa y para la cadena vacía (§2.3) |
| `reset(reason)` | `reset(reason)`, con `reason` en `RESET_REASONS` = USER, NEW_SESSION, RECONFIGURE, NONFINITE, FLUSH |
| `flush()` | `flush()`: entrega la cola retenida por el re-bloqueo y reinicia (causa FLUSH) |
| `get_status()` | `get_status()`: cadena efectiva, versión aplicada, latencia, bypass, integridad, sobrecarga, último error tipado, subnormales, sobre-rango y pedidos pendientes |

### 2.1 Estados de un pedido

```
PREPARING ──(construcción + cebado JIT, FUERA del lock)──► preflight
   │                                                      │ violación
   │ excepción de construcción ────────────────────────► FAILED (kind INVALID_CONFIG…)
   ▼
PENDING ──(primer bloque procesado con la cadena nueva)──► APPLIED
   (sin flujo de audio la frontera segura es inmediata: APPLIED al publicar)
```

- `wait_applied(ticket, timeout)` vence con `DSPTimeoutError`.
- La UI muestra FALLÓ con el tipo del error, PENDIENTE y APLICADO (este último confirmado en el tick coalescido).

### 2.2 Transiciones sin clic

- Al cambiar la cadena publicada, la vieja y la nueva procesan el mismo bloque durante 10 ms y se cruzan linealmente.
- Se usa crossfade lineal porque las señales son correladas (Fink/Holters/Zölzer 2016).
- La rama vieja usa copias de las etapas compartidas, así ninguna procesa dos veces.
- Si llega un cambio durante otro crossfade, se registra como `XFADE_SUPERSEDED`.

### 2.3 Latencia y bypass

| Situación | Semántica |
|---|---|
| Fuera de streaming, cadena vacía | BIT_PERFECT: devuelve el mismo array |
| Durante la captura (`begin_stream` / `end_stream`) | Toda la cadena corre en un único re-bloqueo de 256 frames, también con la cadena vacía (LATENCY_ALIGNED) |

La latencia del DERIVED es constante durante la sesión: activar o apagar
etapas no la desplaza en el tiempo.

### 2.4 Numérico

| Caso | Tratamiento |
|---|---|
| NaN / Inf | Política explícita `numeric_policy`: SANITIZE (sanear, contar, reiniciar la etapa y marcar DEGRADED) o FAIL (`DSPNumericalFaultError`) |
| Subnormales | Se vacían a cero y se cuentan por etapa |
| \|x\| > 1 | Se cuenta en `out_of_range_samples` sin recortar en el coordinador |
| Sobrecarga | 8 bloques seguidos fuera de presupuesto ponen `overload` en el estado y generan un evento. No se lanza nada en la ruta de audio |

### 2.5 Errores tipados (§4)

| Error | `kind` | Cuándo |
|---|---|---|
| `DSPInvalidConfigError` | INVALID_CONFIG | Token, modo, parámetro o combinación inválidos (incluye el preflight) |
| `DSPUnsupportedFormatError` | UNSUPPORTED_FORMAT | Sample rate, canales, dtype o forma |
| `DSPNumericalFaultError` | NUMERICAL_FAULT | NaN/Inf con la política FAIL |
| `DSPTimeoutError` | TIMEOUT | El pedido no se aplicó a tiempo |
| `DSPOverloadError` | OVERLOAD | Etapa fuera de presupuesto de forma sostenida (se informa como estado) |
| `DSPSourceError` | SOURCE_ERROR | La fuente entregó algo que no es audio |
| `DSPStageError` | STAGE_FAILURE | Una etapa lanzó una excepción o devolvió una forma inválida |

### 2.6 Preflight NR-03 (reglas explícitas)

Se aplica antes de tocar la cadena activa. Si hay violación, se lanza
`DSPInvalidConfigError` y la cadena no cambia.

| Regla | Contenido |
|---|---|
| P1 | DNL y DNR (un solo extremo) no tienen codificador: se rechazan en ENCODE |
| P2 | HX Pro es control de bias de GRABACIÓN: se rechaza en PLAYBACK y OFFLINE_RESTORATION. En CAPTURE_LIVE convive con el NR (especificación de la usuaria, GAP-011) y se advierte que no participa en la decodificación |
| P3 | ENCODE se rechaza en OFFLINE_RESTORATION |
| P4 | Los efectos creativos se rechazan en OFFLINE_RESTORATION |
| P5 | Un solo NR a la vez (exclusión estructural del selector) |

### 2.7 Precisión y rendimiento

- **Precisión:** los kernels Numba coinciden con su referencia Python (`*_py`) dentro de 1e-5; en NR la coincidencia es bit a bit.
- **Factor de tiempo real con bloques de 1024 (0.11.014):**

| Etapa | Factor |
|---|---|
| NR | 0,011–0,029 |
| HX Pro | 0,027 |
| Cristhi Cosh | 0,10 |
| Versión O Tron | 0,12 |
| Lucha Enloquecida A | 0,09 |
| Resto | ≤ 0,042 |

Medido en streaming, sin otra carga en la máquina; la comparación con 0.11.013 está en `saneamiento_0_11_014/INFORME_RENDIMIENTO_PREVI_NR_SERVO.md`.

- `warm_up_all()` precompila todas las etapas en segundo plano al arrancar.

---

## 3. Servosistemas (Fase E)

- **Reloj autoritativo:** el hilo de render, el único que avanza el lector.
  - Relación del modelo: `audible_frame` = posición fuente del frame que entrega el callback, interpolada dentro del slot.
  - `effective_ratio` = ratio del bloque audible.
  - `applied_ratio` = ratio del planificador; `requested_ratio` = ratio deseado.
- **Generaciones (SV-01):** la puerta del callback es monotónica. `min_valid_gen` sube a la generación vigente consumida; un bloque de una generación anterior no suena, no mueve el cursor y se cuenta (`stale_blocks`).
- **Telemetría en vivo** (`transport_snapshot()`):

| Campo | Contenido |
|---|---|
| `mode`, `transport_generation` | Modo y generación de la sesión |
| `requested_ratio`, `applied_ratio`, `effective_ratio` | Velocidad pedida, aplicada y audible |
| `jitter_ms` | Desviación del intervalo entre callbacks respecto del período nominal |
| `response_ms` | Comando → audible, medido con sellos del callback por época de velocidad y por generación |
| `render_ms` | Tiempos de render, con `slow_reads` y `disk_reads` |
| `stale_blocks` | Bloques obsoletos descartados |
| `sync_state` | PRELOADING, LOCKED, SLEWING, SEEKING, STARVED, STOPPING, EOF, ENDED o FAILED |
| `failed_reason`, `limits` | Causa del fallo y límites declarados |

- **Bordes (SV-03):**

| Situación | Comportamiento |
|---|---|
| EOF | Fundido declarado + fin; también hacia atrás, al llegar al frame 0 |
| Underrun | Silencio declarado y contado |
| 5 underruns seguidos | Estado STARVED (`starved_episodes`) |
| Preload sin datos en 2 s | Estado FAILED (`PRELOAD_TIMEOUT`) |

- **UI:**
  - La GUI informa una vez las transiciones a STARVED y FAILED, leyendo el snapshot a ~6 Hz.
  - Los gestos del servo (doble Space, tecla E, doble clic en el scrub) detienen SOLO la reproducción: nunca la captura ni el ITL.

---

## 4. Matriz de trazabilidad (requisito → código → prueba → evidencia → aprobación)

Evidencia común de todas las filas: la batería completa
(`saneamiento_0_11_014/_test_run_full.txt`), corrida también con
`-W error::ResourceWarning`. La columna "Evidencia" indica la evidencia
adicional de cada fila.

| Requisito (orden) | Cambio de código | Prueba | Evidencia adicional | Aprobación |
|---|---|---|---|---|
| §4 Entrada/salida explícitas · DSP-01 | `validate_config` / `validate_block` (errores tipados) | `DSP01Contract.*` | `bench_endurance.json` | QA C.E.A. (pendiente) |
| §4 Estado entre bloques · DSP-02 | Re-bloqueo único y estado por canal | `DSP02Continuity.*`, `test_dsp_golden.BlockContinuity` | — | QA C.E.A. |
| §4 Sanitización (NaN/Inf/subnormal/rango) · DSP-03 | `_sanitize_stage`, `numeric_policy`, contadores | `DSP03Numeric.*` | — | QA C.E.A. |
| §4 Precisión / paridad de referencia | Kernels `njit` + `*_py` | `NumbaReferenceParity` | Comparación bit a bit con 0.11.013 (GAP-088) | QA C.E.A. |
| §4 Rendimiento | Núcleo NR en Numba; cebado en PREPARING; `warm_up_all` | `END01SustainedDsp` | Factor de tiempo real (§2.7), `bench_endurance.json` | QA C.E.A. |
| §4 / §7 Reconfiguración en frontera, sin clic, sin bloquear · DSP-04 | `_mutate` (fuera del lock), crossfade, tickets | `DSP04Reconfigure.*` | — | QA C.E.A. |
| §4 Bypass / reset / flush · DSP-05 | Semántica de bypass declarada, `reset(reason)`, `flush()` | `DSP05BypassResetFlush.*` | — | QA C.E.A. |
| §4 Errores tipados | `lorito_errors_dsp` (7 tipos con `kind`) | `DSP01Contract.test_typed_errors_are_distinct_and_stable` | — | QA C.E.A. |
| §5 Perfiles por modelo y revisión; no sobre-rotular · NR-01 | `NR_PROFILE_CATALOG`, `describe_chain` | `NR01Fidelity.*` | `NR_FIDELITY_BENCH.md` | QA C.E.A. + referencias (Fase G) |
| §5 Niveles extremos, bombeo · NR-02 | `recovery_s` declarado | `NR02Extremes.*` | Auditoría H-13 | QA C.E.A. |
| §5 HX Pro separado; combinaciones · NR-03 | `flow_side`, `preflight_chain` (P1–P5) | `NR03Preflight.*` | — | QA C.E.A. |
| §6 Generaciones · SV-01 | Puerta monotónica en el callback | `SV01Generations.*` | — | QA C.E.A. |
| §6 Rangos, rampas, dirección, fuera de rango · SV-02 | `SERVO_LIMITS`, `_speed_command`, `seek_to`, atenuación a velocidad casi nula | `SV02Ramps.*` | — | QA C.E.A. |
| §6 EOF, disco lento, underrun · SV-03 | `sync_state`, STARVED / FAILED | `SV03Boundaries.*`, `SV03Starvation.*` | — | QA C.E.A. |
| §6 Telemetría del servo | `_snapshot` ampliado, sellos del callback | `ServoTelemetry.*` | `bench_endurance.json` | QA C.E.A. |
| §7 UI con estado efectivo · UI-01 | `_dsp_request`, `_refresh_dsp_state`, `_refresh_servo_state`, `_stop_playback_only` | `test_previ_nr_servo_ui.*` | — | QA C.E.A. |
| §3 / §11 RAW inmutable, DERIVED trazable · RAW-01 | Provenance/2 con re-hash del RAW | `RAW01Integrity.*` | — | QA C.E.A. |
| §9 Carga sostenida · END-01 | — | `END01SustainedDsp` (2 min) | `tools/servo/bench_endurance.py` (10 min). Pendiente: 23/50 h en hardware | QA C.E.A. (Fase G) |
| Consideración de la usuaria: legado desconectado | `legado/` | `test_legado_desconectado.*` | `legado/README_LEGADO.md` | Usuaria |
