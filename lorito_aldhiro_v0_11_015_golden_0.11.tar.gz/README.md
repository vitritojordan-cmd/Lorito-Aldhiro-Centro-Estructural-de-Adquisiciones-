# Lorito Aldhiro — modularización mecánica

**Lorito Aldhiro Alpha 0.01.002** es la bifurcación de `CRAC 0.22.57`
(*Carola Records Aldhira Capture* / codebase interno `AECCT2`), creada
para resolver los problemas de recontraemergencia que atraviesa el fuero
Finguered, y que deberá usarse mientras `CRAC` y `AECCT2` continúan su
propio desarrollo por separado. Ver `CHANGELOG.md [002]` y
`gaps/GAP-001.md` para el detalle de la bifurcación.

Este proyecto es la **modularización mecánica** del monolito original
`aecct2_v22_55.py` (22.714 líneas, 381 sentencias de nivel superior). El
comportamiento es idéntico al original: es una separación de código en
módulos temáticos, **no** una reescritura funcional.

> **Estado actual (actualizado a la versión que trae este tarball,
> ver `lorito_aldhiro/backend/lorito_version.py`):** desde la
> modularización inicial (0.01.002, descrita en el resto de este
> README) el proyecto pasó por una Orden Maestra de Refundación del
> motor de exportación/transporte, por una Orden Maestra de
> Saneamiento Pre-Auditoría Aldhira Phonographic, y ahora por una
> tercera Orden Maestra de Saneamiento, Integración y Consolidación
> (convertir los subsistemas ya construidos en las autoridades reales
> de la aplicación) —
> **`/ESTADO_MAESTRO_SANEAMIENTO.md`** consolida las dos primeras y
> **`/ESTADO_MAESTRO_CONSOLIDACION.md`** la tercera (qué está
> construido, verificado, pendiente de integrar, y por qué). El árbol
> de directorios de más
> abajo describe fielmente la modularización ORIGINAL (32 módulos);
> desde entonces se agregaron los subpaquetes `export_streaming/`,
> `transport/`, `dsp/`, `nr/`, `rt/`, `archival/` y `errors/` bajo `backend/` — ver
> el documento de estado para el detalle de cada uno.

## Registro de cambios y documentación

- **`CHANGELOG.md`** — registro de cambios del tarball. Cada entrada
  `## [NNN]` representa una revisión de código y **eleva
  automáticamente** el tercer dígito de la versión (no se edita a mano:
  `lorito_aldhiro/backend/lorito_version.py` cuenta las entradas de este
  archivo en tiempo de import).
- **`gaps/`** — "gaps de referencia": documentos `GAP-NNN.md` donde se
  registra, con más detalle del que cabe en una entrada de CHANGELOG, el
  tratamiento técnico de una revisión. Empieza en `gaps/GAP-001.md`.
- **`lorito_aldhiro/backend/lorito_version.py`** — módulo dedicado de
  registro de versión. Única fuente de verdad de `APP_BRAND` ("Lorito
  Aldhiro"), `APP_STAGE` ("Alpha") y del número de versión
  `MAYOR.MENOR.REVISIÓN`, este último calculado programáticamente desde
  `CHANGELOG.md`.

## Convención de nombres

Todos los módulos elaborados durante la modularización (32 archivos +
el módulo raíz de arranque) llevan el prefijo `lorito_`:
`lorito_version.py`, `lorito_capture_engine.py`,
`lorito_main_window.py`, `lorito_bootstrap.py`, etc. Los `__init__.py`
de paquete se mantienen con ese nombre exacto (requisito de Python para
reconocer un directorio como paquete).

## Nombre de la aplicación

El nombre visible de la app (título de ventana, rótulo superior de la
interfaz, texto de especificación exportado) es ahora **"Lorito
Aldhiro"**, tomado de `APP_BRAND` en `lorito_version.py`. Antes decía
`"Carola Records Aldhira Capture"` / `"CAROLA RECORDS · ALDHIRA
CAPTURE"`.

> **Nota de alcance:** el vocabulario interno de mensajes de estado en
> tiempo de ejecución (p. ej. `"CAROLALDHIRA CAPTURANDO"`,
> `"CAROLALDHIRA ACTIVA!"`, usado en comparaciones de texto dentro de
> `lorito_status_display.py` y `lorito_main_window.py`) **no se tocó**
> — solo se reemplazó el nombre/título de la aplicación. Queda anotado
> como pendiente en `gaps/GAP-001.md` por si se desea unificarlo en una
> revisión futura.

Toda referencia de marca `AECCT2` (el codebase interno del monolito
original) se cambió a `Lorito Aldhiro` — la única excepción es el texto
`"AECCT2"` que la animación de la PC dibuja en el panel del contómetro
(`frontend/widgets/lorito_media_anim.py`), tal como se pidió.

## Cómo se hizo (metodología de la modularización)

1. Se parseó el monolito con `ast` y se identificaron los 381 nodos de
   nivel superior (imports, clases, funciones, constantes, bloques
   `if`/`try`).
2. Cada nodo (con su bloque de comentarios/changelog inmediatamente
   anterior) se asignó, en modo mecánico, a un módulo de destino según su
   rol dentro del sistema — sin alterar la lógica interna de ninguna
   clase o función.
3. Se generó automáticamente un grafo de símbolos (`nombre → módulo`) y,
   a partir de él, los `import` necesarios entre módulos (análisis de
   nombres libres vía AST).
4. Se separaron los módulos en dos ramas:
   - **`backend/`** — cero dependencias de Qt.
   - **`frontend/`** — todo lo que toca `PySide6`.
5. Se verificó exhaustivamente: sin huecos ni solapes en los 381 nodos
   originales, sin ciclos de import, `py_compile` limpio, y **ejecución
   real de `lorito_bootstrap.py` de punta a punta** con stubs de
   PySide6/sounddevice/soundfile/aecct2_crac_motor_v4, construyendo la
   ventana principal completa sin `NameError`/`ImportError`.

### Correcciones necesarias para preservar el comportamiento

El monolito original, al vivir en un único archivo ejecutado como
`__main__`, usaba varios patrones `from __main__ import X` dentro de
funciones para acceder a nombres globales definidos "más abajo" en el
mismo archivo. Se corrigieron 7 sitios así (documentados con comentarios
`NOTA MODULARIZACION` en el código), y se cambió la actualización de
`THEME` de reasignación global a mutación in-place para que el cambio de
tema en caliente siga siendo visible en todos los módulos. Detalle
completo en `CHANGELOG.md [001]`.

Un caso se dejó **intencionalmente sin tocar**: `_PSIMonitor._loop`
(en `lorito_ring_buffers.py`) referencia `PSI_WARN_THRESHOLD` y
`PSI_LOG_MIN_INTERVAL`, que **nunca estuvieron definidas en el monolito
original** (bug preexistente y latente). Se preserva tal cual —
corregirlo alteraría el comportamiento original.

## Árbol de directorios

```
.
├── lorito_bootstrap.py                          # módulo raíz — arranca el sistema
├── CHANGELOG.md                                  # registro de cambios (eleva la versión)
├── gaps/
│   └── GAP-001.md                                # detalle de la bifurcación CRAC → Lorito Aldhiro
├── requirements.txt
├── README.md
└── lorito_aldhiro/
    ├── backend/                                  # SIN Qt
    │   ├── lorito_version.py                     # módulo dedicado de registro de versión
    │   ├── lorito_app_logging.py                 # logger raíz + rotating file handler
    │   ├── lorito_constants.py                   # ~125 constantes de configuración
    │   ├── lorito_forensics.py                   # AIPLO — Auditor Integrado de Parámetros Lorito Ordenales
    │   ├── lorito_rt_priorities.py               # SCHED_FIFO, rtkit, afinidad de CPU, ctypes/libc
    │   ├── lorito_timing.py                      # reloj monotónico crudo, CaptureClock
    │   ├── lorito_ring_buffers.py                # ring buffer robusto, XRun forensics, PSI, stress test
    │   ├── lorito_audio_utils.py                 # detección de clipping, ClipLog
    │   ├── lorito_audio_backend.py                # BackendStatus, detección ffmpeg/backend de audio
    │   ├── lorito_snapshot.py                     # snapshots de sesión, CrashGuard
    │   ├── lorito_export_integrity.py             # SHA-256, checksums, validación post-export
    │   ├── lorito_exporters.py                    # WAV / FLAC / OGG / WavPack
    │   ├── lorito_capture_engine.py               # CaptureEngineV2, DiskWriterV2, drain/watchdog loops
    │   ├── lorito_playback_engine.py              # PlaybackEngine, resample, crossfade
    │   ├── lorito_tape_physics.py                 # física del transporte de cinta
    │   ├── lorito_normalization.py                # RMS/LUFS/peak/preservative/noise-aware/mid-side/...
    │   ├── lorito_tape_presets.py                 # TapePreset + 8 perfiles de cinta
    │   ├── lorito_normalization_v21.py            # dispatcher v21, soft limiter, análisis dos pasadas
    │   └── lorito_patches.py                      # parche de BackendStatus, helpers dB↔lineal
    │
    └── frontend/                                 # CON Qt (PySide6)
        ├── lorito_theme.py                        # extracción de paleta desde imagen (k-means)
        ├── lorito_bridge.py                        # _Bridge(QObject) — señales cross-thread
        ├── lorito_itl_bridge.py                    # integración opcional del motor ITL
        ├── lorito_dialogs.py                       # diálogos (bienvenida, guardar, cierre, etc.)
        ├── lorito_main_window.py                   # LoritoAldhiroStudio(QWidget) — ventana principal
        └── widgets/
            ├── lorito_buttons.py                    # DoubleClickButton
            ├── lorito_scrub_bars.py                 # ScrubBarPlay, MorpherScrubBar, SpeedScrubBar
            ├── lorito_indicators.py                 # LuminousIndicator, DigitalClock, VUBar
            ├── lorito_media_anim.py                 # animación de la PC (conserva texto "AECCT2")
            ├── lorito_waveform.py                   # WaveformDisplay
            ├── lorito_status_display.py             # StatusDisplay
            └── lorito_tape_log_panel.py             # TapeLogPanel
```

## Ejecutar

```bash
pip install -r requirements.txt
# coloca aecct2_crac_motor_v4.py (y opcionalmente aecct2_itl_integration.py,
# aecct2_stability_patch.py) junto a lorito_bootstrap.py, igual que en el original
python3 lorito_bootstrap.py
```

Argumentos de línea de comandos idénticos al original: `--analyze`,
`--aiplo-analyze`, `--forensics` (o variable de entorno
`LORITO_ALDHIRO_FORENSICS=1`).

## Correr la batería de tests

```bash
python3 -m unittest discover -s tests -p "test_*.py"
```

No requiere `PySide6`/`sounddevice`/`soundfile` instalados para la
inmensa mayoría de los tests (lógica de backend pura); un subconjunto
usa stubs mínimos de esas dependencias para poder ejercitar módulos que
las importan (ver `tests/test_stability_patch.py::_install_stub_modules`
y el mismo patrón repetido en `tests/test_capture_recovery.py`/
`test_cola_elastica_disco.py`).

## Cómo agregar una revisión nueva de ahora en adelante

1. Agregar una entrada `## [NNN]` nueva (número siguiente) en
   `CHANGELOG.md`, con fecha y descripción del cambio.
2. Si el cambio amerita explicación técnica extensa, crear
   `gaps/GAP-NNN.md` y enlazarlo desde la entrada de CHANGELOG.
3. No hace falta tocar `lorito_version.py` — `APP_VERSION` se recalcula
   solo, la próxima vez que se importe el módulo, contando las entradas
   de `CHANGELOG.md`.
