# Legado desconectado de Lorito Aldhiro

Esta carpeta guarda los módulos **legados ya desconectados** que se
retiraron del árbol activo, para dejar limpio el paquete `lorito_aldhiro/`.

- Está **fuera del paquete**: nada de aquí se puede importar desde la
  aplicación (`lorito_aldhiro.*`), y las pruebas no lo recorren.
- Se conserva la ruta original debajo de `legado/` para que el origen de
  cada archivo sea evidente.
- Ningún archivo de aquí se ejecuta, se prueba ni se mantiene. Es
  referencia histórica.

## Criterio de retiro

Un módulo se retira solo si es **inalcanzable** desde el arranque real de la
aplicación. El arranque real son `lorito_bootstrap.py` y
`lorito_aldhiro/frontend/lorito_main_window.py`.

El análisis es un grafo de imports construido con `ast` sobre los 152
módulos del paquete, las pruebas y las herramientas. Cuenta:

- imports absolutos y relativos;
- `from paquete import submódulo`;
- imports dentro de funciones;
- cadenas pasadas a `importlib` o `__import__`.

Además se buscó cada símbolo público del módulo en todo el árbol.

Lo que la documentación llama "legado" pero sigue en uso real **no** se
retira:

| Módulo | Motivo para quedarse |
|---|---|
| `lorito_normalization`, `lorito_normalization_v21` | Producción usa sus constantes y el enum de modos. Las pruebas de paridad del camino streaming usan sus funciones de arreglo como referencia. |
| `RingBufferAbsorcion` | Es una subclase de compatibilidad de `SPSCCaptureRing` que se instancia de verdad. |

Lo que ya se había eliminado antes no está aquí, porque no quedaba ningún
archivo que mover:

- `lorito_exporters` / `_build_export_array`
- `SignalPulseCell`
- los hubs

## Inventario

| Archivo | Ruta original | Retirado en | Motivo |
|---|---|---|---|
| `lorito_aldhiro/backend/export/lorito_reports.py` (866 líneas) | `lorito_aldhiro/backend/export/lorito_reports.py` | 0.11.014 | `NormalizationReport` y el reporte forense del camino de exportación por arreglo completo, eliminado en la Orden Golden de Exportación. Nadie lo importaba; ninguno de sus 13 símbolos se usaba. |
