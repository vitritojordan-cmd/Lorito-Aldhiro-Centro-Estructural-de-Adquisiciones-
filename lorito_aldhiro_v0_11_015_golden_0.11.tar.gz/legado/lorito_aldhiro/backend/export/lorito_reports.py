from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Generación de reportes de calidad/estado de una sesión de captura.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

RETIRADO en 0.11.014 (LEGADO DESCONECTADO). Ruta original:
`lorito_aldhiro/backend/export/lorito_reports.py`. Lo usaba el camino de
exportación por arreglo completo (`_build_export_array`/`lorito_exporters`),
que se eliminó en la Orden Golden de Exportación. Desde entonces ningún
módulo lo importaba y ninguno de sus 13 símbolos se usaba en el árbol. Se
conserva aquí solo como referencia histórica: NO forma parte del paquete y
no se puede importar desde la aplicación. Ver `legado/README_LEGADO.md`.
"""

import os
import logging
import json
from datetime import datetime
import math as _math
import numpy as np
from dataclasses import dataclass, field
import dataclasses
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.export.lorito_normalization import _apply_normalization_advanced
from lorito_aldhiro.backend.export.lorito_normalization_v21 import _norm_with_tape_preset, _two_pass_analysis
from lorito_aldhiro.backend.core.lorito_patches import _lin_to_db
from lorito_aldhiro.backend.playback.lorito_tape_presets import TAPE_PRESETS



# ─────────────────────────────────────────────────────────────────────────────
#  5. REPORTE DETALLADO — NormalizationReport
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class NormalizationReport:
    """
    Reporte completo de una operación de normalización.

    Compatible con XRLOG, snapshots y JSON export.
    Generado automáticamente por _generate_normalization_report() después
    de cada normalización en export().
    """
    # ── Identificación ────────────────────────────────────────────────────────
    timestamp_iso:          str   = ""
    session_file:           str   = ""
    codec:                  str   = ""
    duration_s:             float = 0.0
    sample_rate:            int   = 0
    n_channels:             int   = 2

    # ── Tipo de normalización ─────────────────────────────────────────────────
    norm_mode:              str   = ""         # etiqueta del NormalizationMode
    norm_mode_internal:     str   = ""         # nombre interno (ej. PRESET_TYPE_II)
    auto_normalization_decision: str = ""      # decisión elegida (ej. "rms", "noise_aware")
    auto_normalization_reason:   str = ""      # razón textual

    # ── Ganancia ─────────────────────────────────────────────────────────────
    gain_applied_db:        float = 0.0
    pre_gain_db:            float = 0.0        # doble norm: etapa 1
    post_gain_db:           float = 0.0        # doble norm: etapa 3

    # ── Niveles de salida ─────────────────────────────────────────────────────
    lufs_final:             float = float("-inf")
    rms_final_db:           float = float("-inf")
    peak_input_db:          float = float("-inf")   # peak antes de normalizar
    true_peak_final_db:     float = float("-inf")
    ceiling_db:             float = -0.2

    # ── Dinámica ──────────────────────────────────────────────────────────────
    crest_factor_db:        float = float("inf")
    dynamic_range_db:       float = 0.0
    crest_guard_triggered:  bool  = False
    crest_guard_reduction_db: float = 0.0

    # ── Ruido ─────────────────────────────────────────────────────────────────
    noise_floor_db:         float = float("-inf")
    snr_estimated_db:       float = float("inf")

    # ── Clipping ─────────────────────────────────────────────────────────────
    clipping_detected_input:  bool  = False
    clip_density_input:       float = 0.0
    n_clipped_output:         int   = 0

    # ── Soft limiter ─────────────────────────────────────────────────────────
    soft_limiter_applied:    bool  = False
    soft_limiter_max_db:     float = 0.0

    # ── Percentiles de bloques RMS ────────────────────────────────────────────
    percentile_05_db:        float = float("-inf")
    percentile_25_db:        float = float("-inf")
    percentile_50_db:        float = float("-inf")
    percentile_75_db:        float = float("-inf")
    percentile_95_db:        float = float("-inf")

    # ── M/S y estéreo ─────────────────────────────────────────────────────────
    mid_rms_db:              float = float("-inf")
    side_rms_db:             float = float("-inf")
    stereo_balance_index:    float = 0.0

    # ── Modo AUTO ────────────────────────────────────────────────────────────
    auto_selected_mode:      str   = ""        # si fue AUTO, qué modo eligió
    auto_clip_density:       float = 0.0
    auto_silence_ratio:      float = 0.0
    auto_dynamic_range:      float = 0.0

    # ── Preset de cinta ───────────────────────────────────────────────────────
    tape_preset_name:        str   = ""
    tape_preset_note:        str   = ""

    # ── Two-pass ─────────────────────────────────────────────────────────────
    two_pass_enabled:        bool  = False
    pass1_duration_s:        float = 0.0
    pass2_duration_s:        float = 0.0
    export_drift_detected:   bool  = False

    # ── Warnings ─────────────────────────────────────────────────────────────
    warnings:                List[str] = field(default_factory=list)

    # ── Validación ───────────────────────────────────────────────────────────
    integrity_ok:            bool  = True
    integrity_notes:         List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convierte el reporte a diccionario serializable."""
        d = dataclasses.asdict(self)
        # Convertir float("inf") y float("-inf") a None para JSON
        def _clean(v):
            if isinstance(v, float):
                if _math.isinf(v) or _math.isnan(v):
                    return None
            if isinstance(v, dict):
                return {k2: _clean(v2) for k2, v2 in v.items()}
            if isinstance(v, list):
                return [_clean(i) for i in v]
            return v
        return {k: _clean(v) for k, v in d.items()}

    def to_json(self, indent: int = 2) -> str:
        """Serializa el reporte a JSON."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def to_xrlog_line(self) -> str:
        """Genera una línea compacta para el XRLOG."""
        ts = self.timestamp_iso
        return (
            f"[NORM] {ts}  mode={self.norm_mode}  "
            f"gain={self.gain_applied_db:+.2f}dB  "
            f"lufs={self.lufs_final:.1f}  "
            f"rms={self.rms_final_db:.1f}dBFS  "
            f"peak_in={self.peak_input_db:.2f}dBFS  "
            f"tp_out={self.true_peak_final_db:.2f}dBFS  "
            f"cf={self.crest_factor_db:.1f}dB  "
            f"noise={self.noise_floor_db:.1f}dBFS  "
            f"clips_in={'Y' if self.clipping_detected_input else 'N'}  "
            f"limiter={'Y' if self.soft_limiter_applied else 'N'}  "
            f"auto_decision={self.auto_normalization_decision}  "
            f"warns={len(self.warnings)}"
        )

    def save(self, directory: str, prefix: str = "crac_norm_report") -> str:
        """
        Guarda el reporte en el directorio indicado como JSON.
        Retorna la ruta del archivo guardado.
        """
        import datetime
        ts_safe = self.timestamp_iso.replace(":", "-").replace("T", "_")[:19]
        filename = f"{prefix}_{ts_safe}.json"
        path = os.path.join(directory, filename)
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.to_json())
            return path
        except Exception as e:
            _log.error("NormalizationReport.save: %s", e)
            return ""


def _generate_normalization_report(norm_stats:    dict,
                                   audio_out:     np.ndarray,
                                   rate:          int,
                                   session_file:  str = "",
                                   codec:         str = "",
                                   norm_mode_label: str = "") -> NormalizationReport:
    """
    Genera un NormalizationReport completo a partir de las stats de normalización
    y del audio resultante.

    Llamar DESPUÉS de aplicar la normalización y el soft limiter.
    """
    import datetime

    # Medir audio de salida
    if len(audio_out) > 0:
        peak_out_lin = float(np.max(np.abs(audio_out)))
        rms_out_lin  = float(np.sqrt(np.mean(audio_out.astype(np.float64) ** 2)))
        peak_out_db  = _lin_to_db(peak_out_lin)
        rms_out_db   = _lin_to_db(rms_out_lin)
        cf_out_db    = peak_out_db - rms_out_db if rms_out_lin > 1e-9 else float("inf")
        n_ch_out     = audio_out.shape[1] if audio_out.ndim > 1 else 1
    else:
        peak_out_db = rms_out_db = cf_out_db = float("-inf")
        n_ch_out    = 2

    dur_s = len(audio_out) / max(rate, 1)

    # True peak estimado de salida
    tp_out_db = norm_stats.get("true_peak_db", peak_out_db)
    if tp_out_db is None or (isinstance(tp_out_db, float) and _math.isinf(tp_out_db)):
        tp_out_db = peak_out_db

    # Warnings consolidados
    warnings = []
    for key in ("warnings", "pass1_warnings", "auto_warnings"):
        w = norm_stats.get(key, [])
        if isinstance(w, list):
            warnings.extend(w)
    # Deduplicate
    seen = set()
    warnings = [x for x in warnings if not (x in seen or seen.add(x))]

    report = NormalizationReport(
        timestamp_iso          = datetime.datetime.now().isoformat(timespec="seconds"),
        session_file           = session_file,
        codec                  = codec,
        duration_s             = round(dur_s, 2),
        sample_rate            = rate,
        n_channels             = n_ch_out,

        norm_mode              = norm_mode_label,
        norm_mode_internal     = norm_stats.get("mode", ""),
        auto_normalization_decision = norm_stats.get("auto_normalization_decision", ""),
        auto_normalization_reason   = norm_stats.get("auto_normalization_reason", ""),

        gain_applied_db        = round(norm_stats.get("gain_db", 0.0), 4),
        pre_gain_db            = round(norm_stats.get("pre_normalization_gain_db", 0.0), 4),
        post_gain_db           = round(norm_stats.get("post_normalization_gain_db", 0.0), 4),

        lufs_final             = norm_stats.get("lufs", float("-inf")) or float("-inf"),
        rms_final_db           = round(rms_out_db, 3),
        peak_input_db          = round(norm_stats.get("peak_db", float("-inf")), 3),
        true_peak_final_db     = round(tp_out_db, 3),
        ceiling_db             = norm_stats.get("ceiling_db", -0.2) or -0.2,

        crest_factor_db        = round(cf_out_db, 2) if cf_out_db != float("inf") else float("inf"),
        dynamic_range_db       = round(norm_stats.get("dynamic_range_estimate",
                                                       norm_stats.get("dynamic_range_db", 0.0)), 2),
        crest_guard_triggered  = norm_stats.get("crest_guard_triggered", False),
        crest_guard_reduction_db = round(norm_stats.get("crest_guard_reduction_db", 0.0), 3),

        noise_floor_db         = round(norm_stats.get("noise_floor_db",
                                                       norm_stats.get("pass1_noise_floor_db",
                                                                       float("-inf"))), 2),
        snr_estimated_db       = round(norm_stats.get("snr_db", float("inf")), 2)
                                  if norm_stats.get("snr_db") is not None else float("inf"),

        clipping_detected_input= norm_stats.get("clip_density", 0.0) > 0.001 or
                                  norm_stats.get("pass1_clip_density", 0.0) > 0.001 or
                                  norm_stats.get("auto_clip_density", 0.0) > 0.001,
        clip_density_input     = round(norm_stats.get("clip_density",
                                                       norm_stats.get("pass1_clip_density", 0.0)), 6),
        n_clipped_output       = norm_stats.get("clipped_samples", 0) or 0,

        soft_limiter_applied   = norm_stats.get("soft_limiter_triggered", False),
        soft_limiter_max_db    = round(norm_stats.get("soft_limiter_reduction_db", 0.0), 3),

        percentile_05_db       = round(norm_stats.get("pass1_p05_rms_db",
                                                       norm_stats.get("p05_rms_db",
                                                                       float("-inf"))), 2),
        percentile_25_db       = round(norm_stats.get("pass1_p25_rms_db", float("-inf")), 2),
        percentile_50_db       = round(norm_stats.get("pass1_p50_rms_db", float("-inf")), 2),
        percentile_75_db       = round(norm_stats.get("pass1_p75_rms_db", float("-inf")), 2),
        percentile_95_db       = round(norm_stats.get("pass1_p95_rms_db",
                                                       norm_stats.get("p95_rms_db",
                                                                       float("-inf"))), 2),

        mid_rms_db             = round(norm_stats.get("mid_rms", float("-inf")), 3),
        side_rms_db            = round(norm_stats.get("side_rms", float("-inf")), 3),
        stereo_balance_index   = round(norm_stats.get("stereo_balance_index", 0.0), 4),

        auto_selected_mode     = norm_stats.get("auto_selected_mode", ""),
        auto_clip_density      = round(norm_stats.get("auto_clip_density", 0.0), 6),
        auto_silence_ratio     = round(norm_stats.get("auto_silence_ratio", 0.0), 4),
        auto_dynamic_range     = round(norm_stats.get("auto_dynamic_range", 0.0), 2),

        tape_preset_name       = norm_stats.get("preset_name", ""),
        tape_preset_note       = norm_stats.get("preset_note", ""),

        two_pass_enabled       = norm_stats.get("mode", "").startswith("TWO_PASS"),
        pass1_duration_s       = round(norm_stats.get("pass1_time_s", 0.0), 3),
        pass2_duration_s       = round(norm_stats.get("pass2_time_s", 0.0), 3),
        export_drift_detected  = norm_stats.get("pass1_export_drift_detected", False),

        warnings               = warnings,
        integrity_ok           = True,
        integrity_notes        = [],
    )

    return report


def _finalize_normalization_report(norm_stats:    dict,
                                   audio_out:     np.ndarray,
                                   rate:          int,
                                   session_file:  str,
                                   codec:         str,
                                   norm_mode_label: str,
                                   report_dir:    str = "") -> NormalizationReport:
    """
    Genera, guarda y loguea el reporte de normalización.
    Actualiza _status con la ruta del reporte.
    Emite una línea al XRLOG.

    Llamar desde export() después de aplicar la normalización.
    Retorna el NormalizationReport generado.
    """

    report = _generate_normalization_report(
        norm_stats       = norm_stats,
        audio_out        = audio_out,
        rate             = rate,
        session_file     = session_file,
        codec            = codec,
        norm_mode_label  = norm_mode_label,
    )

    # Guardar en directorio de sesión si se especificó
    report_path = ""
    if report_dir and os.path.isdir(report_dir):
        report_path = report.save(report_dir)
        if report_path:
            _log.info("NormalizationReport guardado: %s", report_path)

    # Actualizar _status con campos v0.21
    try:
        # NOTA MODULARIZACION: import directo (antes "from __main__ import _status")
        from lorito_aldhiro.backend.audio.lorito_audio_backend import _status as _st
        if hasattr(_st, "auto_normalization_decision"):
            _st.auto_normalization_decision = report.auto_normalization_decision
        if hasattr(_st, "auto_normalization_reason"):
            _st.auto_normalization_reason   = report.auto_normalization_reason
        if hasattr(_st, "normalization_rms_final_db"):
            _st.normalization_rms_final_db  = report.rms_final_db
        if hasattr(_st, "normalization_percentile_5"):
            _st.normalization_percentile_5  = report.percentile_05_db
        if hasattr(_st, "normalization_percentile_95"):
            _st.normalization_percentile_95 = report.percentile_95_db
        if hasattr(_st, "normalization_true_peak_final_db"):
            _st.normalization_true_peak_final_db = report.true_peak_final_db
        if hasattr(_st, "normalization_report_path"):
            _st.normalization_report_path   = report_path
    except ImportError:
        pass

    # Emitir al XRLOG
    try:
        # NOTA MODULARIZACION: import directo (antes "from __main__ import _xrun_forensics")
        from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
        _xrun_forensics.record_xrun(
            report.to_xrlog_line(),
            cb_latency_ms   = 0.0,
            write_latency_ms= 0.0,
            queue_size      = 0,
        )
    except Exception:
        pass  # XRLOG no crítico

    _log.info("NormReport: %s", report.to_xrlog_line())
    return report


# ─────────────────────────────────────────────────────────────────────────────
#  6. FORENSIC NORMALIZATION REPORT — reporte detallado opcional (v0.22)
# ─────────────────────────────────────────────────────────────────────────────

_flog = logging.getLogger("aecct2.norm_forensic")  # [LIMPIEZA v0.22.01 LEGACY-03] logging ya importado globalmente


def _build_forensic_report(norm_stats: dict,
                            report:     "NormalizationReport",
                            audio_out:  np.ndarray,
                            rate:       int) -> dict:
    """
    Construye un diccionario forense extendido a partir del NormalizationReport
    ya generado y de norm_stats en bruto.

    Incluye todos los campos requeridos por la especificación CRAC v0.22:
      · tipo de normalización        · gain aplicada
      · LUFS final                   · RMS final
      · crest factor                 · noise floor
      · clipping detectado           · true peak
      · percentiles (p05/p25/p50/p75/p95)
      · modo auto seleccionado       · warnings
      · snapshot_id                  · compatibilidad XRLOG / JSON

    Retorna un dict serializable listo para JSON export o para adjuntar
    a un snapshot de sesión.
    """
    # ── Percentiles en dict legible ────────────────────────────────────────
    percentiles = {
        "p05_db": report.percentile_05_db,
        "p25_db": report.percentile_25_db,
        "p50_db": report.percentile_50_db,
        "p75_db": report.percentile_75_db,
        "p95_db": report.percentile_95_db,
    }

    # ── Clipping: unificar fuentes ─────────────────────────────────────────
    clipping_sources = {
        "input_detected":  report.clipping_detected_input,
        "clip_density":    report.clip_density_input,
        "clipped_samples_output": report.n_clipped_output,
        "histogram_density": norm_stats.get("normalization_histogram_density",
                              norm_stats.get("histogram_density", 0.0)),
    }

    # ── Modo AUTO ─────────────────────────────────────────────────────────
    auto_info = {
        "auto_selected_mode":  report.auto_selected_mode,
        "auto_decision":       report.auto_normalization_decision,
        "auto_reason":         report.auto_normalization_reason,
        "auto_clip_density":   report.auto_clip_density,
        "auto_silence_ratio":  report.auto_silence_ratio,
        "auto_dynamic_range":  report.auto_dynamic_range,
    }

    forensic = {
        # ── Cabecera ───────────────────────────────────────────────────────
        "forensic_schema":     "crac_norm_forensic_v1",
        "timestamp_iso":       report.timestamp_iso,
        "session_file":        report.session_file,
        "codec":               report.codec,
        "duration_s":          report.duration_s,
        "sample_rate":         report.sample_rate,
        "n_channels":          report.n_channels,

        # ── Tipo de normalización ──────────────────────────────────────────
        "norm_mode":           report.norm_mode,
        "norm_mode_internal":  report.norm_mode_internal,
        "tape_preset_name":    report.tape_preset_name,
        "tape_preset_note":    report.tape_preset_note,
        "two_pass_enabled":    report.two_pass_enabled,

        # ── Ganancia ──────────────────────────────────────────────────────
        "gain_applied_db":     report.gain_applied_db,
        "pre_gain_db":         report.pre_gain_db,
        "post_gain_db":        report.post_gain_db,

        # ── Niveles ───────────────────────────────────────────────────────
        "lufs_final":          report.lufs_final,
        "rms_final_db":        report.rms_final_db,
        "true_peak_final_db":  report.true_peak_final_db,
        "peak_input_db":       report.peak_input_db,
        "ceiling_db":          report.ceiling_db,

        # ── Dinámica ──────────────────────────────────────────────────────
        "crest_factor_db":         report.crest_factor_db,
        "dynamic_range_db":        report.dynamic_range_db,
        "crest_guard_triggered":   report.crest_guard_triggered,
        "crest_guard_reduction_db": report.crest_guard_reduction_db,

        # ── Ruido ─────────────────────────────────────────────────────────
        "noise_floor_db":      report.noise_floor_db,
        "snr_estimated_db":    report.snr_estimated_db,

        # ── Clipping ──────────────────────────────────────────────────────
        "clipping":            clipping_sources,

        # ── Soft limiter ──────────────────────────────────────────────────
        "soft_limiter_applied":  report.soft_limiter_applied,
        "soft_limiter_max_db":   report.soft_limiter_max_db,

        # ── Percentiles ───────────────────────────────────────────────────
        "percentiles":         percentiles,

        # ── Modo AUTO ─────────────────────────────────────────────────────
        "auto":                auto_info,

        # ── M/S y estéreo ─────────────────────────────────────────────────
        "mid_rms_db":          report.mid_rms_db,
        "side_rms_db":         report.side_rms_db,
        "stereo_balance_index": report.stereo_balance_index,

        # ── Two-pass timing ───────────────────────────────────────────────
        "pass1_duration_s":    report.pass1_duration_s,
        "pass2_duration_s":    report.pass2_duration_s,
        "export_drift_detected": report.export_drift_detected,

        # ── Warnings ──────────────────────────────────────────────────────
        "warnings":            report.warnings,
        "warning_count":       len(report.warnings),

        # ── Integridad ────────────────────────────────────────────────────
        "integrity_ok":        report.integrity_ok,
        "integrity_notes":     report.integrity_notes,
    }
    return forensic


def _save_forensic_report(forensic: dict,
                           directory: str,
                           prefix: str = "crac_norm_forensic") -> str:
    """
    Serializa y guarda el reporte forense como JSON en el directorio indicado.
    Emite una línea FORENSIC_NORM_REPORT al logger aecct2.norm_forensic.
    Retorna la ruta del archivo guardado o "" si falla.
    """
    import datetime

    ts_safe = forensic.get("timestamp_iso", datetime.datetime.now().isoformat())
    ts_safe = ts_safe.replace(":", "-").replace("T", "_")[:19]
    filename = f"{prefix}_{ts_safe}.json"
    path = os.path.join(directory, filename)

    # ── Limpiar valores no serializables ──────────────────────────────────
    def _clean(v):
        if isinstance(v, float):
            if _math.isinf(v) or _math.isnan(v):
                return None
        if isinstance(v, dict):
            return {k2: _clean(v2) for k2, v2 in v.items()}
        if isinstance(v, list):
            return [_clean(i) for i in v]
        return v

    clean_forensic = _clean(forensic)

    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(clean_forensic, f, indent=2, ensure_ascii=False)
        _flog.info(
            "FORENSIC_NORM_REPORT saved: %s  mode=%s  gain=%+.2fdB  "
            "lufs=%.1f  rms=%.1f  warns=%d",
            path,
            forensic.get("norm_mode", ""),
            forensic.get("gain_applied_db", 0.0),
            forensic.get("lufs_final") or float("-inf"),
            forensic.get("rms_final_db") or float("-inf"),
            forensic.get("warning_count", 0),
        )
        return path
    except Exception as e:
        _flog.error("FORENSIC_NORM_REPORT save failed: %s", e)
        return ""


def _emit_forensic_to_xrlog(forensic: dict) -> None:
    """
    Emite una línea compacta del reporte forense al XRLOG de sesión.
    No lanza excepciones: fallo silencioso si XRLOG no está disponible.
    """
    try:
        # NOTA MODULARIZACION: import directo (antes "from __main__ import _xrun_forensics")
        from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
        line = (
            f"[FORENSIC_NORM] {forensic.get('timestamp_iso', '')}  "
            f"mode={forensic.get('norm_mode', '')}  "
            f"gain={forensic.get('gain_applied_db', 0.0):+.2f}dB  "
            f"lufs={forensic.get('lufs_final') or float('-inf'):.1f}  "
            f"rms={forensic.get('rms_final_db') or float('-inf'):.1f}dBFS  "
            f"tp={forensic.get('true_peak_final_db') or float('-inf'):.2f}dBFS  "
            f"cf={forensic.get('crest_factor_db') or float('inf'):.1f}dB  "
            f"noise={forensic.get('noise_floor_db') or float('-inf'):.1f}dBFS  "
            f"clips={'Y' if forensic.get('clipping', {}).get('input_detected') else 'N'}  "
            f"auto={forensic.get('auto', {}).get('auto_selected_mode', '')}  "
            f"warns={forensic.get('warning_count', 0)}"
        )
        _xrun_forensics.record_xrun(
            line,
            cb_latency_ms    = 0.0,
            write_latency_ms = 0.0,
            queue_size       = 0,
        )
    except Exception:
        pass  # XRLOG no crítico


def _attach_forensic_to_snapshot(forensic: dict) -> None:
    """
    Adjunta el dict forense al snapshot activo de sesión si está disponible.
    Escribe bajo la clave 'normalization_forensic' del manifest de crash.
    """
    try:
        # NOTA MODULARIZACION: import directo (antes "from __main__ import _crash_guard")
        from lorito_aldhiro.backend.capture.lorito_snapshot import _crash_guard
        _crash_guard.update({"normalization_forensic": forensic})
    except Exception:
        pass  # snapshot no disponible, no crítico


def _finalize_forensic_report(norm_stats: dict,
                               report:     "NormalizationReport",
                               audio_out:  np.ndarray,
                               rate:       int,
                               report_dir: str = "",
                               attach_snapshot: bool = True,
                               emit_xrlog:      bool = True) -> dict:
    """
    Punto de entrada único para el reporte forense de normalización.

    Orquesta:
      1. _build_forensic_report()    — construir dict forense completo
      2. _save_forensic_report()     — persistir JSON (si report_dir está dado)
      3. _emit_forensic_to_xrlog()   — línea FORENSIC_NORM_REPORT al XRLOG
      4. _attach_forensic_to_snapshot() — adjuntar al crash manifest

    Retorna el dict forense completo.
    Compatible con XRLOG, snapshots y JSON export (especificación §16).
    """
    forensic = _build_forensic_report(norm_stats, report, audio_out, rate)

    if report_dir and os.path.isdir(report_dir):
        _save_forensic_report(forensic, report_dir)

    if emit_xrlog:
        _emit_forensic_to_xrlog(forensic)

    if attach_snapshot:
        _attach_forensic_to_snapshot(forensic)

    return forensic


# ─────────────────────────────────────────────────────────────────────────────
#  7. NORMALIZATION FAILURE SAFETY — recuperación robusta (v0.22)
# ─────────────────────────────────────────────────────────────────────────────

# ── Constantes de log para Normalization Failure Safety ───────────────────────
_NORM_LOG_FAILURE  = "NORMALIZATION_FAILURE"
_NORM_LOG_FALLBACK = "NORMALIZATION_FALLBACK"
_NORM_LOG_ABORT    = "NORMALIZATION_ABORT_SAFE"

_slog = logging.getLogger("aecct2.norm_safety")


def _norm_peak_fallback(audio: np.ndarray,
                        ceiling_db: float = -0.2) -> tuple:
    """
    Fallback de último recurso: peak normalization clásica.

    Aplica una ganancia simple para llevar el peak absoluto al ceiling_db
    indicado.  No realiza análisis avanzado.  Nunca genera clipping si
    ceiling_db <= 0.

    Retorna (audio_normalizado, stats_dict).
    """
    peak_lin = float(np.max(np.abs(audio)))
    if peak_lin < 1e-9:
        # Señal vacía / silencio
        stats = {
            "mode":     "PEAK_FALLBACK",
            "gain_db":  0.0,
            "peak_db":  float("-inf"),
            "fallback": True,
        }
        return audio.copy(), stats

    ceiling_lin = 10.0 ** (ceiling_db / 20.0)
    gain_lin    = ceiling_lin / peak_lin
    gain_db     = 20.0 * _math.log10(gain_lin)

    audio_out = np.clip(audio.astype(np.float32) * gain_lin, -1.0, 1.0)

    stats = {
        "mode":          "PEAK_FALLBACK",
        "gain_db":       round(gain_db, 4),
        "peak_db":       round(20.0 * _math.log10(peak_lin), 3),
        "ceiling_db":    ceiling_db,
        "fallback":      True,
        "lufs":          float("-inf"),
        "noise_floor_db": float("-inf"),
        "true_peak_db":  ceiling_db,
    }
    return audio_out, stats


def _safe_normalize(audio:          np.ndarray,
                    norm_fn,
                    norm_args:      tuple  = (),
                    norm_kwargs:    dict   = None,
                    ceiling_db:     float  = -0.2,
                    session_file:   str    = "",
                    export_fn             = None,
                    export_args:    tuple  = (),
                    export_kwargs:  dict   = None) -> tuple:
    """
    Envuelve cualquier función de normalización con recuperación robusta.

    Comportamiento garantizado (especificación §17):
      · Si norm_fn lanza cualquier excepción → rollback al audio original,
        log NORMALIZATION_FAILURE, intento de fallback peak, log
        NORMALIZATION_FALLBACK.
      · Si el fallback también falla → devuelve el audio original sin
        modificar, log NORMALIZATION_ABORT_SAFE.
      · Nunca aborta la captura / export principal: el audio de retorno
        es siempre utilizable.
      · Si export_fn está dado, se ejecuta con el audio resultante después
        de normalizar (o del fallback).  Un fallo en export_fn es logueado
        pero NO propaga la excepción.

    Parámetros
    ----------
    audio          : ndarray float32 original (no se modifica en rollback)
    norm_fn        : callable — función de normalización a intentar
    norm_args      : args posicionales para norm_fn
    norm_kwargs    : kwargs para norm_fn (por defecto {})
    ceiling_db     : ceiling para el fallback peak
    session_file   : ruta de sesión para contexto de log
    export_fn      : callable opcional — se ejecuta con (audio_out, stats)
    export_args    : args adicionales para export_fn
    export_kwargs  : kwargs adicionales para export_fn

    Retorna
    -------
    (audio_out, stats, fallback_used: bool)
    """
    norm_kwargs   = norm_kwargs   or {}
    export_kwargs = export_kwargs or {}

    # ── Guardar copia original para posible rollback ───────────────────────
    audio_original = audio.copy()
    fallback_used  = False

    # ── Intentar normalización principal ─────────────────────────────────
    try:
        audio_out, stats = norm_fn(*norm_args, **norm_kwargs)
        stats["fallback"] = False

    except Exception as exc_norm:
        _slog.error(
            "%s  session=%s  fn=%s  error=%s",
            _NORM_LOG_FAILURE,
            session_file,
            getattr(norm_fn, "__name__", str(norm_fn)),
            exc_norm,
            exc_info=True,
        )

        # ── Rollback limpio ────────────────────────────────────────────────
        audio_out = audio_original.copy()

        # ── Intentar fallback peak ─────────────────────────────────────────
        try:
            audio_out, stats = _norm_peak_fallback(audio_original, ceiling_db)
            fallback_used = True
            _slog.warning(
                "%s  session=%s  fallback=PEAK_CLASSIC  gain_db=%+.2f",
                _NORM_LOG_FALLBACK,
                session_file,
                stats.get("gain_db", 0.0),
            )

        except Exception as exc_fb:
            # ── Abort seguro: devolver audio original intacto ─────────────
            _slog.critical(
                "%s  session=%s  fallback_error=%s — devolviendo audio original",
                _NORM_LOG_ABORT,
                session_file,
                exc_fb,
                exc_info=True,
            )
            audio_out = audio_original.copy()
            stats = {
                "mode":          "ABORT_SAFE",
                "gain_db":       0.0,
                "fallback":      True,
                "abort":         True,
                "error":         str(exc_norm),
                "fallback_error": str(exc_fb),
            }
            fallback_used = True

    # ── Export seguro opcional ────────────────────────────────────────────
    if export_fn is not None:
        try:
            export_fn(audio_out, stats, *export_args, **export_kwargs)
        except Exception as exc_exp:
            _slog.error(
                "NORMALIZATION_EXPORT_ERROR  session=%s  error=%s",
                session_file,
                exc_exp,
                exc_info=True,
            )
            # No propagar: la captura principal nunca debe abortar

    return audio_out, stats, fallback_used


def _safe_normalize_advanced(audio:        np.ndarray,
                              norm_mode,
                              rate:         int,
                              ceiling_db:   float = -0.2,
                              session_file: str   = "") -> tuple:
    """
    Wrapper de _apply_normalization_advanced() con recuperación robusta §17.

    Equivalente directo a llamar _apply_normalization_advanced() pero con
    garantía de no-aborto.  Retorna (audio_out, stats, fallback_used).
    """
    return _safe_normalize(
        audio         = audio,
        norm_fn       = _apply_normalization_advanced,
        norm_args     = (audio, norm_mode, rate),
        ceiling_db    = ceiling_db,
        session_file  = session_file,
    )


def _safe_normalize_two_pass(audio:        np.ndarray,
                              rate:         int,
                              ceiling_db:   float = -0.2,
                              session_file: str   = "") -> tuple:
    """
    Wrapper de _two_pass_analysis() con recuperación robusta §17.

    Retorna (audio_out, stats, fallback_used).
    """
    return _safe_normalize(
        audio         = audio,
        norm_fn       = _two_pass_analysis,
        norm_args     = (audio, rate),
        ceiling_db    = ceiling_db,
        session_file  = session_file,
    )


def _safe_normalize_with_preset(audio:        np.ndarray,
                                 rate:         int,
                                 preset_name:  str,
                                 ceiling_db:   float = -0.2,
                                 session_file: str   = "") -> tuple:
    """
    Wrapper de _norm_with_tape_preset() con recuperación robusta §17.

    Retorna (audio_out, stats, fallback_used).

    FIX-BUG05: resuelve preset_name (str) → TapePreset antes de llamar a
    _norm_with_tape_preset(), que espera un objeto TapePreset, no un str.
    Antes pasaba el string directamente → AttributeError: 'str' has no 'name'.
    Busca primero por clave exacta en TAPE_PRESETS, luego por display_name.
    """
    # ── Resolver nombre → objeto TapePreset ──────────────────────────────────
    preset_obj = TAPE_PRESETS.get(preset_name)
    if preset_obj is None:
        preset_obj = next(
            (v for v in TAPE_PRESETS.values() if v.display_name == preset_name),
            None,
        )
    if preset_obj is None:
        raise ValueError(
            f"Preset de cinta desconocido: {preset_name!r}. "
            f"Disponibles: {list(TAPE_PRESETS.keys())}"
        )
    # ── Delegar al pipeline seguro con el objeto correcto ────────────────────
    return _safe_normalize(
        audio         = audio,
        norm_fn       = _norm_with_tape_preset,
        norm_args     = (audio, rate, preset_obj),   # FIX-BUG05: TapePreset, no str
        ceiling_db    = ceiling_db,
        session_file  = session_file,
    )
