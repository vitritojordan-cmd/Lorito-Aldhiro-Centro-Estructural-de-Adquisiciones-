from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Orquestador de toda la cadena DSP en tiempo real — un solo punto de entrada por bloque.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_coordinator.py — coordinador de selección única de reducción
de ruido (§GAP-011), mismo patrón `_active` de exclusión estructural ya
usado en el proyecto hermano (VitriCarola/PARMOSOC: un único perfil
activo a la vez, nunca cascada).

HX Pro y ALC son independientes entre sí y del selector NR (pueden
convivir con un perfil NR activo y entre ellos — no son parte de la
familia de doble/único extremo, son técnicas de grabación/nivelación
distintas), tal como especificó el usuario (menú OPTAPE separado del
menú NR).

── Orden Golden DSP PREVI / NR (LA-GOLDEN-DSP-PREVI-NR-001) ──────────

  · Contrato único (`lorito_dsp_contract`): bloque validado (forma,
    dtype, canales) y configuración validada (rate/canales) ANTES de
    procesar; tokens/modos desconocidos → `DSPContractError` (NR-03).
  · Snapshot por bloque (DSP-04): toda mutación (select/set_*/
    set_stage_params/reconfigure) y cada `process_chunk()` se serializan
    con un lock NO-RT: los cambios entran en frontera de bloque. La cadena
    activa es una tupla inmutable publicada de una sola vez.
  · `reconfigure()` transaccional (NR-02): construye instancias NUEVAS de
    TODAS las etapas (incluidas Cristhi Cosh, Antipestal, Lucha
    Enloquecida, Versión O Tron y Muscle EQ Samir, preservando sus
    parámetros/bandas); si cualquiera falla, la cadena anterior queda
    intacta. Política de estado: se REINICIA en el cambio de rate/canales
    (registrado como evento).
  · Saneamiento = alarma (DSP-01): cada NaN/Inf genera un
    `IntegrityEvent` (etapa, bloque, frame, cantidad, política) y deja
    `integrity_state = "DEGRADED"` — nunca audio "aparentemente válido"
    sin rastro.
  · Saturación con telemetría (DSP-02): muestras en |x| ≥ 1.0 a la
    salida de cada etapa se cuentan (`saturated_samples`); el recorte
    por etapa queda DECLARADO, no silencioso.
  · Fallo de etapa: excepción o forma inválida → `DSPStageError` con el
    nombre de la etapa (el llamador decide abortar/degradar).
  · Telemetría por etapa (DSP-07): frames, tiempos p50/p95/p99/máx,
    picos, saturación, no-finitos, resets, fallos; `config_hash()` y
    `describe_chain()` para provenance de DERIVED.

── Orden Golden PREVI · NR · Servosistemas (LA-GOLDEN-PREVI-NR-SERVO-016) ──

  · §7 "Cambios de parámetros no pueden pausar captura ni reproducción
    para inicializar un DSP": las instancias nuevas se CONSTRUYEN FUERA del
    lock (estado PREPARING) y solo el intercambio de referencias ocurre
    bajo el lock. Antes la construcción (incluida la compilación JIT)
    ocurría con el lock tomado y el hilo de drenado esperaba.
  · Estados de reconfiguración confirmados por el motor (§7): cada pedido
    devuelve un `ReconfigTicket` PREPARING → PENDING → APPLIED, o FAILED
    con el `kind` del error tipado. Con flujo de audio activo, APPLIED
    llega cuando el primer bloque se procesa con la cadena nueva; sin flujo
    la frontera segura es inmediata.
  · NR-03 preflight: `preflight_chain()` valida la cadena PROPUESTA antes de
    tocar la activa; una violación es `DSPInvalidConfigError` y la cadena
    activa no cambia.
  · DSP-04/DSP-05 sin clics: al activar, apagar o reemplazar una etapa, la
    cadena vieja y la nueva procesan el mismo bloque durante `XFADE_MS`
    (10 ms) y se cruzan linealmente (señales correladas: misma entrada).
    Las etapas compartidas se copian para la rama vieja, así ninguna
    procesa dos veces con el mismo estado.
  · Latencia alineada: con el flujo de captura iniciado (`begin_stream`),
    toda la cadena corre en UN re-bloqueo fijo de `FIXED_BLOCK_FRAMES`
    (latencia constante declarada aunque la cadena quede vacía), así que
    activar o apagar etapas no desplaza el DERIVED en el tiempo. Fuera de
    streaming, la cadena vacía sigue siendo bit-transparente (mismo array).
  · `reset(reason)` solo con causa documentada (`RESET_REASONS`), `flush()`
    entrega la cola retenida por el re-bloqueo, `get_status()` resume el
    estado efectivo, `process(entrada, salida)` escribe en un búfer dado.
  · Numérico (§4, DSP-03): política explícita `numeric_policy` (SANITIZE o
    FAIL); los subnormales se vacían a cero y se cuentan por etapa; los
    valores |x| > 1 se cuentan (`out_of_range_samples`) sin recortar.
  · Sobrecarga: `OVERLOAD_STRIKES` bloques seguidos fuera de presupuesto
    marcan `overload` (kind OVERLOAD) en el estado y un evento; en la ruta
    de audio no se lanza nada.
"""

import copy
import itertools
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from lorito_aldhiro.backend.nr.lorito_nr_profiles import NR_PROFILE_CLASSES, NRProfile
from lorito_aldhiro.backend.nr.lorito_nr_hxpro import HxProProfile
from lorito_aldhiro.backend.nr.lorito_nr_alc import AlcProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_mpx import MpxProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_eq_bias import TapeEqBiasProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_focus import FocusProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_finite_guard import sanitize_finite
from lorito_aldhiro.backend.dsp.lorito_dsp_cristhi_cosh import CristhiCoshProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_antipestal_lola_grillo import AntipestalLolaProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import VersionOTronProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida import LuchaEnloquecidaProfile
from lorito_aldhiro.backend.dsp.lucha_enloquecida import _CLASS_BY_CODE as _LUCHA_CODES
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import MuscleEqSamirProfile
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import get_preset_bands
from lorito_aldhiro.backend.dsp.lorito_dsp_contract import (
    STAGE_CATALOG, CANONICAL_ORDER, USE_CASES, USE_CAPTURE_LIVE, USE_PLAYBACK,
    FAM_CREATIVE, StageTelemetry, IntegrityEvent, validate_block, validate_config,
    config_hash, stage_params, FixedBlockAdapter, FIXED_BLOCK_FRAMES,
    NR_PROFILE_CATALOG, nr_profile_key, preflight_chain, PREFLIGHT_RULES,
    BYPASS_BIT_PERFECT, BYPASS_LATENCY_ALIGNED,
)
from lorito_aldhiro.backend.errors.lorito_errors_dsp import (
    DSPContractError, DSPIntegrityError, DSPInvalidConfigError, DSPStageError,
    DSPNumericalFaultError, DSPTimeoutError, DSPOverloadError,
)

_NR_MODES = ("DECODE", "ENCODE", "BYPASS")
_ANTIPESTAL_MODES = ("BYPASS", "STRIKER", "KARI")
_O_TRON_MODES = ("BYPASS", "AA_MO", "BARRIL", "SIFON")

# Transición sin clic (investigación: 10 ms es el fundido por defecto de
# Vegas; lineal para señales correladas — Fink/Holters/Zölzer 2016).
XFADE_MS = 10.0
# Causas documentadas de reinicio de estado (§4: "reset solo por causa
# documentada").
RESET_REASONS = ("USER", "NEW_SESSION", "RECONFIGURE", "NONFINITE", "FLUSH")
NUMERIC_POLICIES = ("SANITIZE", "FAIL")
OVERLOAD_STRIKES = 8
_SUBNORMAL_LIMIT = float(np.finfo(np.float32).tiny)   # menor normal float32

REQ_PREPARING = "PREPARING"
REQ_PENDING = "PENDING"
REQ_APPLIED = "APPLIED"
REQ_FAILED = "FAILED"


@dataclass
class ReconfigTicket:
    """Pedido de reconfiguración y su estado CONFIRMADO por el motor (§7)."""
    ticket_id: int
    target: str
    action: str
    state: str = REQ_PREPARING
    version: int = 0
    error_kind: str = ""
    error: str = ""
    t_request: float = field(default_factory=time.monotonic)
    t_applied: float = 0.0
    applied_block: int = -1

    def as_dict(self) -> dict:
        return dict(vars(self))


class _ChainExecutor:
    """Etapa única que el `FixedBlockAdapter` del coordinador re-bloquea:
    cada bloque interno pasa por la cadena (y por el crossfade)."""

    def __init__(self, coord):
        self._coord = coord

    def process_chunk(self, block):
        return self._coord._run_block(block)

    def reset(self):
        pass


class NRCoordinator:
    def __init__(self, sample_rate: int = 48000, channels: int = 2, mode: str = "DECODE"):
        mode = (mode or "DECODE").upper().strip()
        if mode not in _NR_MODES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: modo NR desconocido {mode!r}")
        validate_config(sample_rate, channels)
        self.sample_rate = sample_rate
        self.channels = channels
        self.mode = mode
        self.use_case = USE_CAPTURE_LIVE
        self.numeric_policy = "SANITIZE"
        self._lock = threading.RLock()
        self._applied_cv = threading.Condition(self._lock)
        self._active_token: Optional[str] = None
        self._active_kwargs: dict = {}
        self._active_profile: Optional[NRProfile] = None
        self._hx_pro: Optional[HxProProfile] = None
        self._alc: Optional[AlcProfile] = None
        self._mpx: Optional[MpxProfile] = None
        self._focus: Optional[FocusProfile] = None
        self._eq_bias: Optional[TapeEqBiasProfile] = None
        self._eq_bias_token: Optional[str] = None
        self._cristhi_cosh: Optional[CristhiCoshProfile] = None
        self._antipestal: Optional[AntipestalLolaProfile] = None
        self._version_o_tron: Optional[VersionOTronProfile] = None
        self._lucha_enloquecida: Optional[LuchaEnloquecidaProfile] = None
        self._muscle_eq: Optional[MuscleEqSamirProfile] = None
        self._nonfinite_counts: dict = {
            "input": 0, "eq_bias": 0, "mpx": 0, "nr": 0,
            "hx_pro": 0, "alc": 0, "focus": 0, "cristhi_cosh": 0,
            "antipestal": 0, "version_o_tron": 0, "lucha_enloquecida": 0,
            "muscle_eq": 0,
        }
        self._telemetry = {label: StageTelemetry() for label in CANONICAL_ORDER}
        self._events: deque = deque(maxlen=512)
        self._events_total = 0
        self._block_index = 0
        self._frame_position = 0
        self._config_version = 0
        self._applied_version = 0
        # Ejecución
        self._streaming = False
        self._adapter: Optional[FixedBlockAdapter] = None
        self._used_adapter = False
        self._applied_chain: Optional[tuple] = None
        self._applied_key: Optional[tuple] = None
        self._xfade_old: Optional[tuple] = None
        self._xfade_pos = 0
        self._xfade_len = self._xfade_frames()
        self.xfades_completed = 0
        # Estado efectivo
        self._overload = False
        self._overload_strikes = 0
        self._last_error_kind = ""
        self._last_error = ""
        self._tickets: deque = deque(maxlen=64)
        self._ticket_ids = itertools.count(1)
        self._publish_chain()
        self._applied_version = self._config_version

    # ── Publicación de la cadena (snapshot inmutable) ────────────────────
    def _stage_by_label(self, label):
        return {
            "muscle_eq": self._muscle_eq, "cristhi_cosh": self._cristhi_cosh,
            "antipestal": self._antipestal, "lucha_enloquecida": self._lucha_enloquecida,
            "eq_bias": self._eq_bias, "mpx": self._mpx, "nr": self._active_profile,
            "hx_pro": self._hx_pro, "alc": self._alc, "focus": self._focus,
            "version_o_tron": self._version_o_tron,
        }[label]

    def _current_chain(self) -> tuple:
        return tuple((label, st) for label in CANONICAL_ORDER
                     if (st := self._stage_by_label(label)) is not None)

    def _xfade_frames(self) -> int:
        return max(1, int(round(XFADE_MS * self.sample_rate / 1000.0)))

    @staticmethod
    def _needs_rebuffer(chain) -> bool:
        return any(not STAGE_CATALOG[label].block_invariant
                   and getattr(st, "_active", True) is not False for label, st in chain)

    def _uses_adapter(self, chain) -> bool:
        return (self._streaming or self._needs_rebuffer(chain)
                or (self._xfade_old is not None and self._needs_rebuffer(self._xfade_old)))

    def chain_latency_frames(self) -> int:
        """Latencia algorítmica DECLARADA de la cadena: un único re-bloqueo
        de `FIXED_BLOCK_FRAMES` cuando hace falta (o siempre en streaming),
        para alinear DERIVED con RAW."""
        return FIXED_BLOCK_FRAMES if self._uses_adapter(self._current_chain()) else 0

    @property
    def _chain(self) -> tuple:
        return self._current_chain()

    def _publish_chain(self) -> None:
        self._config_version += 1

    def _record_event(self, stage, kind, count, policy, detail=""):
        self._events.append(IntegrityEvent(stage, kind, self._block_index,
                                           self._frame_position, count, policy, detail))
        self._events_total += 1

    # ── Pedidos de reconfiguración (PREPARING → PENDING → APPLIED/FAILED) ─
    def _new_ticket(self, target, action) -> ReconfigTicket:
        t = ReconfigTicket(next(self._ticket_ids), target, action)
        with self._lock:
            self._tickets.append(t)
        return t

    def _fail(self, ticket, err) -> None:
        with self._lock:
            ticket.state = REQ_FAILED
            ticket.error_kind = getattr(err, "kind", type(err).__name__)
            ticket.error = str(err)
            self._last_error_kind, self._last_error = ticket.error_kind, ticket.error
            self._applied_cv.notify_all()

    def _labels_with(self, label, present) -> list:
        labels = [lb for lb, _ in self._current_chain()]
        if present and label not in labels:
            labels.append(label)
        if not present and label in labels:
            labels.remove(label)
        return labels

    def _preflight(self, labels, nr_token, nr_mode=None, use_case=None) -> None:
        violations = preflight_chain(labels, nr_token, nr_mode or self.mode,
                                     use_case or self.use_case)
        if violations:
            detail = "; ".join(f"{r}: {d} — {PREFLIGHT_RULES[r]}" for r, d in violations)
            self._record_event("*", "PREFLIGHT_REJECTED", len(violations), "REJECT", detail)
            raise DSPInvalidConfigError(f"DSP_PREFLIGHT: combinación rechazada ({detail})")

    def _mutate(self, target, action, build, commit, labels_after, nr_after=None,
                nr_mode_after=None, use_case_after=None) -> ReconfigTicket:
        """Construye FUERA del lock, valida en preflight y publica bajo el
        lock (solo intercambio de referencias)."""
        ticket = self._new_ticket(target, action)
        try:
            inst = build()
            self._prime(inst)
        except DSPIntegrityError as e:
            self._fail(ticket, e)
            raise
        except Exception as e:
            err = DSPInvalidConfigError(f"DSP_CONTRACT: {target}: {e}", stage=target, cause=e)
            self._fail(ticket, err)
            raise err from e
        with self._lock:
            try:
                self._preflight(labels_after(), self._active_token if nr_after is None else nr_after[0],
                                nr_mode_after, use_case_after)
            except DSPInvalidConfigError as e:
                self._fail(ticket, e)
                raise
            commit(inst)
            self._publish_chain()
            ticket.version = self._config_version
            if self._streaming:
                ticket.state = REQ_PENDING
            else:
                self._applied_version = self._config_version
                ticket.state, ticket.t_applied = REQ_APPLIED, time.monotonic()
                ticket.applied_block = self._block_index
                self._applied_cv.notify_all()
        return ticket

    def _prime(self, inst) -> None:
        """PREPARING fuera del lock y fuera del audio: un bloque de ceros por
        una COPIA de la etapa nueva fuerza cualquier compilación JIT (o carga
        de caché de Numba) aquí y no en la primera frontera de bloque del
        hilo de drenado. El estado de la instancia real no se toca."""
        if inst is None or not hasattr(inst, "process_chunk"):
            return
        shape = (64,) if self.channels == 1 else (64, self.channels)
        copy.deepcopy(inst).process_chunk(np.zeros(shape, dtype=np.float32))

    def wait_applied(self, ticket: ReconfigTicket, timeout: float = 1.0) -> ReconfigTicket:
        """Espera la confirmación del motor; vence con `DSPTimeoutError`."""
        deadline = time.monotonic() + timeout
        with self._lock:
            while ticket.state in (REQ_PREPARING, REQ_PENDING):
                left = deadline - time.monotonic()
                if left <= 0:
                    raise DSPTimeoutError(
                        f"DSP_TIMEOUT: pedido #{ticket.ticket_id} ({ticket.action}) sin "
                        f"aplicar tras {timeout:.2f} s", stage=ticket.target)
                self._applied_cv.wait(left)
        return ticket

    @property
    def tickets(self) -> list:
        with self._lock:
            return [t.as_dict() for t in self._tickets]

    # ── Selector NR (exclusión estructural — un único perfil activo) ──
    def select(self, token: Optional[str], **profile_kwargs) -> ReconfigTicket:
        """token en NR_PROFILE_CLASSES o None para apagar. Un token
        desconocido es un error de contrato (NR-03), nunca un bypass
        silencioso."""
        if token is not None and token not in NR_PROFILE_CLASSES:
            raise DSPInvalidConfigError(
                f"DSP_CONTRACT: token NR desconocido {token!r} "
                f"(válidos: {sorted(NR_PROFILE_CLASSES)})")
        if token == self._active_token and not profile_kwargs:
            t = self._new_ticket("nr", f"select {token}")
            t.state, t.version, t.t_applied = REQ_APPLIED, self._config_version, time.monotonic()
            return t
        mode, sr, ch = self.mode, self.sample_rate, self.channels

        def build():
            return None if token is None else NR_PROFILE_CLASSES[token](
                mode=mode, sample_rate=sr, channels=ch, **profile_kwargs)

        def commit(prof):
            self._active_token, self._active_profile = token, prof
            self._active_kwargs = {} if token is None else dict(profile_kwargs)

        return self._mutate("nr", f"select {token}", build, commit,
                            lambda: self._labels_with("nr", token is not None),
                            nr_after=(token,))

    @property
    def active_token(self) -> Optional[str]:
        return self._active_token

    def set_mode(self, mode: str) -> ReconfigTicket:
        """Cambia DECODE/ENCODE/BYPASS (preflight incluido)."""
        mode = (mode or "").upper().strip()
        if mode not in _NR_MODES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: modo NR desconocido {mode!r}")
        token, kw, sr, ch = self._active_token, dict(self._active_kwargs), self.sample_rate, self.channels

        def build():
            return None if token is None else NR_PROFILE_CLASSES[token](
                mode=mode, sample_rate=sr, channels=ch, **kw)

        def commit(prof):
            self.mode = mode
            self._active_profile = prof

        return self._mutate("nr", f"mode {mode}", build, commit,
                            lambda: [lb for lb, _ in self._current_chain()],
                            nr_after=(token,), nr_mode_after=mode)

    def set_use_case(self, use_case: str) -> ReconfigTicket:
        if use_case not in USE_CASES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: caso de uso desconocido {use_case!r}")

        def commit(_):
            self.use_case = use_case

        return self._mutate("*", f"use_case {use_case}", lambda: None, commit,
                            lambda: [lb for lb, _ in self._current_chain()],
                            use_case_after=use_case)

    # ── HX Pro / ALC / MPX / FOCUS ────────────────────────────────────────
    def _set_simple(self, attr, label, cls, active) -> ReconfigTicket:
        sr, ch = self.sample_rate, self.channels

        def build():
            return cls(mode="ACTIVE", sample_rate=sr, channels=ch) if active else None

        return self._mutate(label, f"{label} {'on' if active else 'off'}", build,
                            lambda inst: setattr(self, attr, inst),
                            lambda: self._labels_with(label, active))

    def set_hx_pro(self, active: bool) -> ReconfigTicket:
        return self._set_simple("_hx_pro", "hx_pro", HxProProfile, active)

    def set_alc(self, active: bool) -> ReconfigTicket:
        return self._set_simple("_alc", "alc", AlcProfile, active)

    def set_mpx(self, active: bool) -> ReconfigTicket:
        return self._set_simple("_mpx", "mpx", MpxProfile, active)

    def set_focus(self, active: bool) -> ReconfigTicket:
        return self._set_simple("_focus", "focus", FocusProfile, active)

    # ── PREVI ─────────────────────────────────────────────────────────────
    def set_cristhi_cosh(self, active: bool, **params) -> ReconfigTicket:
        sr, ch = self.sample_rate, self.channels

        def build():
            return CristhiCoshProfile(mode="ACTIVE", sample_rate=sr, channels=ch,
                                      **params) if active else None

        return self._mutate("cristhi_cosh", f"cristhi_cosh {'on' if active else 'off'}", build,
                            lambda inst: setattr(self, "_cristhi_cosh", inst),
                            lambda: self._labels_with("cristhi_cosh", active))

    @property
    def cristhi_cosh_active(self) -> bool:
        return self._cristhi_cosh is not None

    def set_antipestal(self, mode: str) -> ReconfigTicket:
        mode = (mode or "BYPASS").upper().strip()
        if mode not in _ANTIPESTAL_MODES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: modo Antipestal desconocido {mode!r}")
        sr, ch, on = self.sample_rate, self.channels, mode != "BYPASS"

        def build():
            return AntipestalLolaProfile(mode=mode, sample_rate=sr, channels=ch) if on else None

        return self._mutate("antipestal", f"antipestal {mode}", build,
                            lambda inst: setattr(self, "_antipestal", inst),
                            lambda: self._labels_with("antipestal", on))

    @property
    def antipestal_active(self) -> bool:
        return self._antipestal is not None

    @property
    def previ_dsp_active(self) -> bool:
        return self.cristhi_cosh_active or self.antipestal_active or self.lucha_enloquecida_active

    def set_lucha_enloquecida(self, mode: str) -> ReconfigTicket:
        mode = (mode or "BYPASS").upper().strip()
        if mode != "BYPASS" and mode not in _LUCHA_CODES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: perfil Lucha Enloquecida desconocido {mode!r}")
        sr, ch, on = self.sample_rate, self.channels, mode != "BYPASS"

        def build():
            return LuchaEnloquecidaProfile(mode=mode, sample_rate=sr, channels=ch) if on else None

        return self._mutate("lucha_enloquecida", f"lucha_enloquecida {mode}", build,
                            lambda inst: setattr(self, "_lucha_enloquecida", inst),
                            lambda: self._labels_with("lucha_enloquecida", on))

    @property
    def lucha_enloquecida_active(self) -> bool:
        return self._lucha_enloquecida is not None

    def set_stage_params(self, label: str, **params) -> ReconfigTicket:
        """Cambio de parámetros SIN clic: se copia la etapa (con su estado),
        la copia recibe los parámetros nuevos y entra con crossfade en la
        frontera de bloque. La GUI nunca muta el objeto que está sonando."""
        ticket = self._new_ticket(label, f"params {label} {sorted(params)}")
        with self._lock:
            st = self._stage_by_label(label) if label in CANONICAL_ORDER else None
            if st is None or not hasattr(st, "set_params"):
                err = DSPInvalidConfigError(f"DSP_CONTRACT: etapa {label!r} inactiva o sin parámetros")
                self._fail(ticket, err)
                raise err
            try:
                new = copy.deepcopy(st)
                new.set_params(**params)
            except DSPIntegrityError as e:
                self._fail(ticket, e)
                raise
            except Exception as e:
                err = DSPInvalidConfigError(f"DSP_CONTRACT: parámetros de {label}: {e}",
                                            stage=label, cause=e)
                self._fail(ticket, err)
                raise err from e
            attr = {"nr": "_active_profile"}.get(label, f"_{label}")
            setattr(self, attr, new)
            self._publish_chain()
            ticket.version = self._config_version
            if self._streaming:
                ticket.state = REQ_PENDING
            else:
                self._applied_version = self._config_version
                ticket.state, ticket.t_applied = REQ_APPLIED, time.monotonic()
                self._applied_cv.notify_all()
        return ticket

    # ── Muscle Eq Samir (rampas propias de coeficientes y húmedo/seco) ────
    def set_muscle_eq_active(self, active: bool, preset_id: str = None) -> None:
        if self._muscle_eq is None:
            bands = get_preset_bands(preset_id) if preset_id else []
            sr, ch = self.sample_rate, self.channels

            def build():
                eq = MuscleEqSamirProfile(mode="ACTIVE" if active else "BYPASS",
                                          sample_rate=sr, channels=ch,
                                          preset_id=preset_id or "FLAT", bands=None)
                if bands:
                    eq.load_preset(preset_id, bands)
                return eq

            self._mutate("muscle_eq", f"muscle_eq {'on' if active else 'off'}", build,
                         lambda inst: setattr(self, "_muscle_eq", inst),
                         lambda: self._labels_with("muscle_eq", True))
            return
        with self._lock:
            self._muscle_eq.set_active(active)
            self._publish_chain()
            self._mark_applied_if_idle()

    def set_muscle_eq_preset(self, preset_id: str) -> None:
        if self._muscle_eq is None:
            self.set_muscle_eq_active(True, preset_id=preset_id)
            return
        with self._lock:
            self._muscle_eq.load_preset(preset_id, get_preset_bands(preset_id))
            self._config_version += 1
            self._mark_applied_if_idle()

    def set_muscle_eq_band(self, index: int, **kwargs) -> None:
        with self._lock:
            if self._muscle_eq is not None:
                self._muscle_eq.set_band(index, **kwargs)
                self._config_version += 1
                self._mark_applied_if_idle()

    def reset_muscle_eq(self) -> None:
        with self._lock:
            if self._muscle_eq is not None:
                self._muscle_eq.reset_to_flat()
                self._config_version += 1
                self._mark_applied_if_idle()

    def _mark_applied_if_idle(self) -> None:
        if not self._streaming:
            self._applied_version = self._config_version

    @property
    def muscle_eq_active(self) -> bool:
        return self._muscle_eq is not None and self._muscle_eq.active

    # ── Versión O Tron ────────────────────────────────────────────────────
    def set_version_o_tron(self, mode: str) -> ReconfigTicket:
        mode = (mode or "BYPASS").upper().strip()
        if mode not in _O_TRON_MODES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: modo Versión O Tron desconocido {mode!r}")
        sr, ch, on = self.sample_rate, self.channels, mode != "BYPASS"

        def build():
            return VersionOTronProfile(mode=mode, sample_rate=sr, channels=ch) if on else None

        return self._mutate("version_o_tron", f"version_o_tron {mode}", build,
                            lambda inst: setattr(self, "_version_o_tron", inst),
                            lambda: self._labels_with("version_o_tron", on))

    @property
    def version_o_tron_active(self) -> bool:
        return self._version_o_tron is not None

    @property
    def fnesp_dsp_active(self) -> bool:
        return self.version_o_tron_active

    # ── EQ/BIAS ───────────────────────────────────────────────────────────
    def select_eq_bias(self, token: Optional[str]) -> ReconfigTicket:
        sr, ch = self.sample_rate, self.channels

        def build():
            return TapeEqBiasProfile(token, sample_rate=sr, channels=ch) if token else None

        def commit(prof):
            self._eq_bias_token, self._eq_bias = token, prof

        return self._mutate("eq_bias", f"eq_bias {token}", build, commit,
                            lambda: self._labels_with("eq_bias", bool(token)))

    @property
    def eq_bias_active_token(self) -> Optional[str]:
        return self._eq_bias_token

    @property
    def mpx_active(self) -> bool:
        return self._mpx is not None

    @property
    def focus_active(self) -> bool:
        return self._focus is not None

    @property
    def hx_pro_active(self) -> bool:
        return self._hx_pro is not None

    @property
    def alc_active(self) -> bool:
        return self._alc is not None

    @property
    def has_active_processing(self) -> bool:
        """True si alguna etapa transforma la señal (Muscle EQ en BYPASS
        con la rampa ya terminada no cuenta) o si hay un crossfade de
        salida en curso (la cola de la etapa que se apaga)."""
        if self._xfade_old is not None:
            return True
        for label, st in self._chain:
            if label == "muscle_eq" and not st.active and st._wet_mix == 0.0 \
                    and st._wet_target == 0.0:
                continue
            return True
        return False

    # ── Reconfiguración TRANSACCIONAL (NR-02) ─────────────────────────────
    def _build_all(self, sr, ch) -> dict:
        new = {}
        if self._active_profile is not None:
            new["_active_profile"] = NR_PROFILE_CLASSES[self._active_token](
                mode=self.mode, sample_rate=sr, channels=ch, **self._active_kwargs)
        for attr, cls in (("_hx_pro", HxProProfile), ("_alc", AlcProfile),
                          ("_mpx", MpxProfile), ("_focus", FocusProfile)):
            if getattr(self, attr) is not None:
                new[attr] = cls(mode="ACTIVE", sample_rate=sr, channels=ch)
        if self._eq_bias is not None:
            new["_eq_bias"] = TapeEqBiasProfile(self._eq_bias_token, sample_rate=sr, channels=ch)
        if self._cristhi_cosh is not None:
            c = self._cristhi_cosh
            new["_cristhi_cosh"] = CristhiCoshProfile(
                mode=c.mode, sample_rate=sr, channels=ch,
                correction_intensity=c.correction_intensity, softness=c.softness,
                reconstruction_intensity=c.reconstruction_intensity,
                dnl_strength=c.dnl_strength, target_peak=c.target_peak)
        if self._antipestal is not None:
            a = self._antipestal
            new["_antipestal"] = AntipestalLolaProfile(
                mode=a.mode, sample_rate=sr, channels=ch, **dict(a.params))
        if self._lucha_enloquecida is not None:
            new["_lucha_enloquecida"] = LuchaEnloquecidaProfile(
                mode=self._lucha_enloquecida.mode, sample_rate=sr, channels=ch)
        if self._version_o_tron is not None:
            new["_version_o_tron"] = VersionOTronProfile(
                mode=self._version_o_tron.mode, sample_rate=sr, channels=ch)
        if self._muscle_eq is not None:
            m = self._muscle_eq
            new["_muscle_eq"] = MuscleEqSamirProfile(
                mode="ACTIVE" if m.active else "BYPASS", sample_rate=sr, channels=ch,
                preset_id=m.preset_id, bands=copy.deepcopy(m.bands))
        return new

    def reconfigure(self, sample_rate: int, channels: int) -> ReconfigTicket:
        """Valida, construye FUERA del lock instancias NUEVAS de todas las
        etapas activas con el rate/canales nuevos (preservando parámetros) y
        publica todo junto. Si algo falla, nada cambia. Es un cambio de
        formato: el estado se reinicia (causa RECONFIGURE) sin crossfade."""
        validate_config(sample_rate, channels)
        sr, ch = int(sample_rate), int(channels)
        ticket = self._new_ticket("*", f"reconfigure {sr}Hz/{ch}ch")
        try:
            with self._lock:
                version = self._config_version
            new = self._build_all(sr, ch)
            with self._lock:
                if self._config_version != version:      # cambió mientras se construía
                    new = self._build_all(sr, ch)
                old_rate, old_ch = self.sample_rate, self.channels
                for attr, inst in new.items():
                    setattr(self, attr, inst)
                self.sample_rate, self.channels = sr, ch
                self._adapter = None
                self._xfade_old = None
                self._xfade_len = self._xfade_frames()
                self._applied_chain, self._applied_key = None, None
                self._publish_chain()
                self._applied_version = self._config_version
                self._record_event("*", "RECONFIGURE", len(new), "STATE_RESET",
                                   f"{old_rate}Hz/{old_ch}ch → {sr}Hz/{ch}ch "
                                   f"({len(new)} etapa(s) reconstruidas)")
                for label, _st in self._chain:
                    t = self._telemetry[label]
                    t.resets += 1
                    t.last_reset_reason = "RECONFIGURE"
                ticket.version = self._config_version
                ticket.state, ticket.t_applied = REQ_APPLIED, time.monotonic()
                self._applied_cv.notify_all()
        except DSPIntegrityError as e:
            self._fail(ticket, e)
            raise
        except Exception as e:
            err = DSPInvalidConfigError(f"DSP_CONTRACT: reconfigure: {e}", cause=e)
            self._fail(ticket, err)
            raise err from e
        return ticket

    def prepare(self, sample_rate: int, channels: int, use_case: str = USE_CAPTURE_LIVE) -> float:
        """§4 `prepare(config, format)`: formato + caso de uso validados y
        kernels JIT compilados FUERA del camino de audio. Devuelve los ms de
        compilación en frío."""
        self.reconfigure(sample_rate, channels)
        if use_case != self.use_case:
            self.set_use_case(use_case)
        return NRCoordinator.warm_up(sample_rate, channels)

    @staticmethod
    def warm_up(sample_rate: int = 48000, channels: int = 2) -> float:
        """DSP-06: compila los kernels Numba (Muscle EQ) FUERA del camino
        de audio, en una instancia descartable. Devuelve los ms usados
        (arranque en frío) para telemetría. Llamar antes de capturar."""
        t0 = time.perf_counter()
        try:
            scratch = NRCoordinator(sample_rate, channels)
            scratch.set_muscle_eq_active(True, "FLAT")
            shape = (256,) if channels == 1 else (256, channels)
            scratch.process_chunk(np.zeros(shape, dtype=np.float32))
        except Exception:
            pass
        return (time.perf_counter() - t0) * 1000.0

    @staticmethod
    def warm_up_all(sample_rate: int = 48000, channels: int = 2) -> float:
        """Precompila (o carga de la caché de Numba) los kernels de TODAS las
        etapas, para que ni la GUI ni el drenado compilen al activar una
        etapa por primera vez. Pensado para un hilo de fondo al arrancar la
        aplicación. Devuelve los ms usados."""
        t0 = time.perf_counter()
        configs = [lambda c, t=t: c.select(t) for t in NR_PROFILE_CLASSES]
        configs += [lambda c: c.set_hx_pro(True), lambda c: c.set_alc(True),
                    lambda c: c.set_mpx(True), lambda c: c.set_focus(True),
                    lambda c: c.select_eq_bias("NORMAL"),
                    lambda c: c.set_cristhi_cosh(True), lambda c: c.set_antipestal("STRIKER"),
                    lambda c: c.set_antipestal("KARI"), lambda c: c.set_version_o_tron("BARRIL"),
                    lambda c: c.set_muscle_eq_active(True, "FLAT")]
        configs += [lambda c, k=k: c.set_lucha_enloquecida(k) for k in sorted(_LUCHA_CODES)]
        shape = (256,) if channels == 1 else (256, channels)
        for cfg in configs:
            try:
                c = NRCoordinator(sample_rate, channels)
                cfg(c)
                c.process_chunk(np.zeros(shape, dtype=np.float32))
            except Exception:
                pass
        return (time.perf_counter() - t0) * 1000.0

    # ── Flujo (latencia alineada) ─────────────────────────────────────────
    def begin_stream(self) -> None:
        """Inicio de un flujo continuo (sesión de captura): estado nuevo
        (causa NEW_SESSION) y re-bloqueo fijo para toda la sesión, así la
        latencia del DERIVED es constante aunque se activen o apaguen
        etapas."""
        with self._lock:
            self.reset("NEW_SESSION")
            self._streaming = True
            self._adapter = None
            self._xfade_old = None
            self._applied_chain, self._applied_key = None, None
            self._record_event("*", "STREAM_START", 0, "LATENCY_ALIGNED",
                               f"latencia fija {FIXED_BLOCK_FRAMES} frames")

    def end_stream(self) -> None:
        with self._lock:
            if self._streaming:
                self._streaming = False
                self._xfade_old = None
                self._record_event("*", "STREAM_END", 0, "")
                self._applied_version = self._config_version
                self._settle_tickets()
                self._applied_cv.notify_all()

    @property
    def streaming(self) -> bool:
        return self._streaming

    def reset(self, reason: str = "USER") -> None:
        """Reinicia el estado de TODAS las etapas activas. Solo por una
        causa documentada (`RESET_REASONS`)."""
        if reason not in RESET_REASONS:
            raise DSPInvalidConfigError(
                f"DSP_CONTRACT: causa de reset no documentada {reason!r} (válidas: {RESET_REASONS})")
        with self._lock:
            for label, st in self._current_chain():
                st.reset()
                t = self._telemetry[label]
                t.resets += 1
                t.last_reset_reason = reason
            if self._adapter is not None:
                self._adapter._prime()
            self._xfade_old = None
            self._record_event("*", "RESET", 0, reason)

    def flush(self) -> np.ndarray:
        """Entrega la cola retenida por el re-bloqueo (latencia declarada) y
        reinicia el estado (causa FLUSH). Sin re-bloqueo en uso, devuelve un
        bloque vacío."""
        with self._lock:
            ch = self.channels
            if self._adapter is None or not self._used_adapter:
                return np.zeros((0, ch), dtype=np.float32)
            tail = self._adapter.process_chunk(
                np.zeros((FIXED_BLOCK_FRAMES, ch), dtype=np.float32))
            self.reset("FLUSH")
            self._record_event("*", "FLUSH", tail.shape[0], "DRAIN_LATENCY")
            return tail

    # ── Integridad / telemetría ──────────────────────────────────────────
    @property
    def nonfinite_counts(self) -> dict:
        return dict(self._nonfinite_counts)

    @property
    def integrity_state(self) -> str:
        """"CLEAN" o "DEGRADED" (algún saneamiento o fallo de etapa)."""
        bad = sum(self._nonfinite_counts.values()) + sum(
            t.failures for t in self._telemetry.values())
        return "DEGRADED" if bad else "CLEAN"

    @property
    def integrity_events(self) -> list:
        return list(self._events)

    def telemetry(self) -> dict:
        return {label: self._telemetry[label].snapshot() for label in CANONICAL_ORDER}

    def get_status(self) -> dict:
        """Estado EFECTIVO del motor (§4 get_status, §7 estado confirmado)."""
        with self._lock:
            chain = self._current_chain()
            pending = [t.as_dict() for t in self._tickets if t.state in (REQ_PREPARING, REQ_PENDING)]
            last = self._tickets[-1].as_dict() if self._tickets else None
            empty_bypass = BYPASS_LATENCY_ALIGNED if self._streaming else BYPASS_BIT_PERFECT
            return {
                "sample_rate": self.sample_rate, "channels": self.channels,
                "mode": self.mode, "use_case": self.use_case,
                "numeric_policy": self.numeric_policy,
                "streaming": self._streaming,
                "config_version": self._config_version,
                "applied_version": self._applied_version,
                "effective_chain": [label for label, _ in chain],
                "nr_token": self._active_token,
                "latency_frames": self.chain_latency_frames(),
                "empty_chain_bypass": empty_bypass,
                "crossfading": self._xfade_old is not None,
                "xfades_completed": self.xfades_completed,
                "integrity_state": self.integrity_state,
                "overload": self._overload,
                "last_error_kind": self._last_error_kind,
                "last_error": self._last_error,
                "subnormal_samples": sum(t.subnormal_samples for t in self._telemetry.values()),
                "out_of_range_samples": sum(t.out_of_range_samples for t in self._telemetry.values()),
                "pending": pending,
                "last_request": last,
                "blocks": self._block_index,
            }

    def describe_chain(self) -> list:
        """Descripción reproducible de la cadena activa (provenance)."""
        out = []
        for label, st in self._chain:
            info = STAGE_CATALOG[label]
            d = {"stage": label, "family": info.family, "fidelity": info.fidelity,
                 "note": info.note, "class": type(st).__name__, "params": stage_params(st),
                 "block_invariant": info.block_invariant,
                 "fixed_block_latency_frames": 0 if info.block_invariant else FIXED_BLOCK_FRAMES,
                 "internal_dtype": info.internal_dtype,
                 "intrinsic_latency_frames": info.intrinsic_latency_frames,
                 "bypass": info.bypass, "flow_side": info.flow_side}
            if label == "nr":
                d["token"] = self._active_token
                d["kwargs"] = dict(self._active_kwargs)
                key = nr_profile_key(self._active_token, getattr(st, "dbx_type", None))
                p = NR_PROFILE_CATALOG.get(key)
                if p is not None:
                    d["nr_profile"] = dict(vars(p)) if hasattr(p, "__dict__") else {
                        k: getattr(p, k) for k in p.__dataclass_fields__}
                    d["fidelity"] = p.fidelity
            if label == "eq_bias":
                d["token"] = self._eq_bias_token
            if label == "muscle_eq":
                d["bands"] = [b.to_dict() for b in st.bands]
            out.append(d)
        return out

    def config_hash(self) -> str:
        return config_hash([self.sample_rate, self.channels, self.mode, self.describe_chain()])

    def chain_warnings(self, use_case: Optional[str] = None) -> list:
        """Combinaciones dudosas por caso de uso (DSP-03). Las incompatibles
        las rechaza el preflight; aquí quedan las advertencias."""
        uc = use_case or self.use_case
        if uc not in USE_CASES:
            raise DSPInvalidConfigError(f"DSP_CONTRACT: caso de uso desconocido {uc!r}")
        w = []
        labels = [label for label, _ in self._chain]
        if "hx_pro" in labels and uc in (USE_PLAYBACK,):
            w.append("HX Pro es una técnica de grabación (bias dinámico): no decodifica "
                     "ni reduce ruido en reproducción")
        if "hx_pro" in labels and self._active_token and self.mode == "DECODE":
            w.append("HX Pro simula el lado de GRABACIÓN; no participa en la decodificación "
                     f"{self._active_token}")
        if self._active_token and self.mode == "ENCODE" and uc in (USE_CAPTURE_LIVE, USE_PLAYBACK):
            w.append("NR en modo ENCODE simula la grabación; para escuchar una cinta "
                     "codificada se usa DECODE")
        creative = [label for label in labels if STAGE_CATALOG[label].family == FAM_CREATIVE]
        if creative and uc != "CREATIVE":
            w.append(f"efectos creativos activos {creative}: la salida es DERIVED creativa, "
                     f"no restauración del RAW")
        if "nr" in labels:
            key = nr_profile_key(self._active_token, getattr(self._active_profile, "dbx_type", None))
            p = NR_PROFILE_CATALOG.get(key)
            cls = p.fidelity if p else "APPROXIMATION"
            w.append(f"NR {self._active_token}: emulación {cls} (sin validación "
                     f"contra hardware de referencia)")
        return w

    # ── Cadena de proceso ────────────────────────────────────────────────
    def _sanitize_stage(self, label: str, out: np.ndarray, stage, record=True) -> np.ndarray:
        clean, n_bad = sanitize_finite(out)
        if n_bad:
            self._nonfinite_counts[label] += n_bad
            if self.numeric_policy == "FAIL":
                self._record_event(label, "NONFINITE", n_bad, "FAIL", "política FAIL: bloque rechazado")
                err = DSPNumericalFaultError(
                    f"DSP_NUMERICAL_FAULT: {n_bad} valores no finitos en {label!r}", stage=label)
                self._last_error_kind, self._last_error = err.kind, str(err)
                raise err
            stage.reset()
            t = self._telemetry[label]
            t.nonfinite_samples += n_bad
            t.resets += 1
            t.last_reset_reason = "NONFINITE"
            self._record_event(label, "NONFINITE", n_bad, "SANITIZE_RESET_DEGRADE",
                               "NaN→0, ±Inf→±clip; estado de la etapa reiniciado")
        a = np.abs(clean)
        sub = int(np.count_nonzero((a < _SUBNORMAL_LIMIT) & (a > 0.0))) if a.size else 0
        if sub:
            clean = np.where(a < _SUBNORMAL_LIMIT, 0.0, clean).astype(clean.dtype, copy=False)
            t = self._telemetry[label]
            first = t.subnormal_samples == 0
            t.subnormal_samples += sub
            if first:
                self._record_event(label, "SUBNORMAL_FLUSH", sub, "FLUSH_TO_ZERO",
                                   "valores subnormales vaciados a cero (se siguen contando)")
        if record:
            oor = int(np.count_nonzero(a > 1.0)) if a.size else 0
            if oor:
                self._telemetry[label].out_of_range_samples += oor
        return clean

    def _run_chain(self, chain, x: np.ndarray, record: bool) -> np.ndarray:
        out = x
        n = x.shape[0]
        budget_ms = n * 1000.0 / max(self.sample_rate, 1)
        for label, stage in chain:
            t = self._telemetry[label]
            peak_in = float(np.max(np.abs(out))) if (record and out.size) else 0.0
            t0 = time.perf_counter()
            try:
                res = stage.process_chunk(out)
            except Exception as e:
                t.failures += 1
                self._record_event(label, "STAGE_FAILURE", n, "ABORT_BLOCK",
                                   f"{type(e).__name__}: {e}")
                err = DSPStageError(f"DSP_STAGE_FAILURE: etapa {label!r} falló: {e}",
                                    stage=label, cause=e)
                self._last_error_kind, self._last_error = err.kind, str(err)
                raise err from e
            dt_ms = (time.perf_counter() - t0) * 1000.0
            if not isinstance(res, np.ndarray) or res.shape != out.shape:
                t.failures += 1
                self._record_event(label, "STAGE_FAILURE", n, "ABORT_BLOCK",
                                   f"forma de salida {getattr(res, 'shape', None)}")
                err = DSPStageError(
                    f"DSP_STAGE_FAILURE: etapa {label!r} devolvió forma "
                    f"{getattr(res, 'shape', None)} != {out.shape}", stage=label)
                self._last_error_kind, self._last_error = err.kind, str(err)
                raise err
            res = self._sanitize_stage(label, res, stage, record)
            if record:
                a = np.abs(res)
                t.record(n, dt_ms, peak_in, float(a.max()) if a.size else 0.0,
                         int(np.count_nonzero(a >= 1.0)), budget_ms)
            out = res
        return out

    def _run_block(self, x: np.ndarray) -> np.ndarray:
        """Un bloque por la cadena aplicada y, si hay transición, por la
        cadena vieja; cruce lineal de `XFADE_MS`."""
        chain = self._applied_chain or ()
        y_new = self._run_chain(chain, x, record=True)
        if self._xfade_old is None:
            return y_new
        try:
            y_old = self._run_chain(self._xfade_old, x, record=False)
        except DSPIntegrityError:
            self._xfade_old = None                   # la rama vieja falló: queda la nueva
            return y_new
        n = x.shape[0]
        L = self._xfade_len
        g = np.clip((np.arange(n, dtype=np.float64) + self._xfade_pos + 1.0) / L, 0.0, 1.0)
        g = g[:, None] if y_new.ndim == 2 else g
        y = (y_old.astype(np.float64) * (1.0 - g) + y_new.astype(np.float64) * g).astype(np.float32)
        self._xfade_pos += n
        if self._xfade_pos >= L:
            self._xfade_old = None
            self.xfades_completed += 1
        return y

    def _sync_chain(self, chain) -> None:
        """Frontera de bloque: detecta el cambio de cadena publicada, arma
        el crossfade y confirma los pedidos pendientes (APPLIED)."""
        key = tuple(id(st) for _l, st in chain)
        if key != self._applied_key:
            old = self._applied_chain
            if old is not None and self._block_index > 0:
                new_ids = {id(st) for _l, st in chain}
                try:
                    branch = tuple((lb, copy.deepcopy(st) if id(st) in new_ids else st)
                                   for lb, st in old)
                    if self._xfade_old is not None:
                        self._record_event("*", "XFADE_SUPERSEDED", 0, "RESTART",
                                           "cambio de cadena durante un crossfade")
                    self._xfade_old, self._xfade_pos = branch, 0
                except Exception as e:
                    self._xfade_old = None
                    self._record_event("*", "XFADE_UNAVAILABLE", 0, "ABRUPT_SWITCH",
                                       f"{type(e).__name__}: {e}")
                old_l = {lb: id(st) for lb, st in old}
                new_l = {lb: id(st) for lb, st in chain}
                for lb in new_l:
                    if lb not in old_l:
                        self._record_event(lb, "STAGE_ADDED", 0, "CROSSFADE_IN")
                    elif old_l[lb] != new_l[lb]:
                        self._record_event(lb, "STAGE_REPLACED", 0, "CROSSFADE")
                for lb in old_l:
                    if lb not in new_l:
                        self._record_event(lb, "STAGE_REMOVED", 0, "CROSSFADE_OUT")
            self._applied_chain, self._applied_key = chain, key
        if self._applied_version != self._config_version:
            self._applied_version = self._config_version
        self._settle_tickets()

    def _settle_tickets(self) -> None:
        now = time.monotonic()
        changed = False
        for t in self._tickets:
            if t.state == REQ_PENDING and t.version <= self._applied_version:
                t.state, t.t_applied, t.applied_block = REQ_APPLIED, now, self._block_index
                changed = True
        if changed:
            self._applied_cv.notify_all()

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        """Procesa un bloque `[frames, channels]` con la cadena publicada.
        Cadena vacía fuera de streaming + entrada finita → MISMO array
        (bypass bit-transparente)."""
        with self._lock:
            validate_block(chunk, self.channels)
            n = chunk.shape[0]
            out, n_bad_in = sanitize_finite(chunk)
            if n_bad_in:
                self._nonfinite_counts["input"] += n_bad_in
                if self.numeric_policy == "FAIL":
                    self._record_event("input", "NONFINITE", n_bad_in, "FAIL",
                                       "política FAIL: bloque de entrada rechazado")
                    err = DSPNumericalFaultError(
                        f"DSP_NUMERICAL_FAULT: {n_bad_in} valores no finitos a la entrada",
                        stage="input")
                    self._last_error_kind, self._last_error = err.kind, str(err)
                    raise err
                self._record_event("input", "NONFINITE", n_bad_in, "SANITIZE_DEGRADE",
                                   "NaN/Inf a la ENTRADA de la cadena DSP")
            chain = self._current_chain()          # snapshot en frontera de bloque
            self._sync_chain(chain)
            use_adapter = self._uses_adapter(chain)
            if use_adapter != self._used_adapter and self._block_index > 0:
                self._record_event("*", "LATENCY_CHANGE", FIXED_BLOCK_FRAMES,
                                   "DECLARED", "re-bloqueo " + ("activado" if use_adapter
                                                                else "desactivado"))
            self._used_adapter = use_adapter
            if not chain and self._xfade_old is None and not use_adapter:
                self._block_index += 1
                self._frame_position += n
                return out                          # bit-transparente
            # Forma declarada intacta: un vector mono llega como vector a las
            # etapas (el re-bloqueo también lo respeta).
            t0 = time.perf_counter()
            if use_adapter:
                if self._adapter is None or self._adapter.channels != self.channels:
                    self._adapter = FixedBlockAdapter(_ChainExecutor(self), self.channels)
                y = self._adapter.process_chunk(np.ascontiguousarray(out, dtype=np.float32))
            else:
                y = self._run_block(out)
            self._check_overload((time.perf_counter() - t0) * 1000.0, n)
            self._block_index += 1
            self._frame_position += n
            if y.dtype != np.float32:
                y = y.astype(np.float32)
            return y

    def process(self, input_block: np.ndarray, output_block: np.ndarray) -> np.ndarray:
        """§4 `process(input_block, output_block)`: escribe el resultado en
        un búfer del llamador (misma forma)."""
        y = self.process_chunk(input_block)
        if output_block.shape != y.shape:
            raise DSPContractError(f"DSP_CONTRACT: búfer de salida {output_block.shape} != {y.shape}")
        output_block[...] = y
        return output_block

    def _check_overload(self, dt_ms: float, n: int) -> None:
        budget_ms = n * 1000.0 / max(self.sample_rate, 1)
        if dt_ms > budget_ms:
            self._overload_strikes += 1
            if self._overload_strikes >= OVERLOAD_STRIKES and not self._overload:
                self._overload = True
                self._last_error_kind = DSPOverloadError.kind
                self._last_error = (f"DSP_OVERLOAD: {self._overload_strikes} bloques seguidos "
                                    f"fuera de presupuesto ({dt_ms:.2f} > {budget_ms:.2f} ms)")
                self._record_event("*", "OVERLOAD", self._overload_strikes, "REPORT",
                                   self._last_error)
        else:
            if self._overload:
                self._record_event("*", "OVERLOAD_CLEARED", self._overload_strikes, "REPORT")
            self._overload_strikes = 0
            self._overload = False
