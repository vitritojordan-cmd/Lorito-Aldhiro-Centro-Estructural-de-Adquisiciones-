from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Cinemática de rotación de los carretes del LCD Display (ω = v/R por bobina, Velocista, Morpher, Seek).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

lorito_reel_kinematics.py — cinemática de rotación de los carretes del LCD
Display (0.11.011).

Los carretes del LCD orquestan ahora el movimiento que antes dibujaban los
hubs de dos paneles, que se retiraron:

- panel de duración de cinta (`TapeLogPanel`): durante la grabación, el
  carrete de suministro y el receptor giran según la física de transporte
  (ω = v / R, con el radio de cada bobina); en OTROS y en SOBRANTE, a radio
  medio. Al voltear a Lado B vuelven a 0°. Con el cuentavueltas desbordado
  tambalean.
- panel de log (`StatusDisplay`): en reproducción, Velocista y Morpher giran
  a 10,4°/tick (4,76 cm/s con hub de 11 mm, timer de ~24 Hz) escalado por el
  ratio; el Morpher en reversa invierte el sentido. Arrastrar el Seek fija el
  ángulo en la posición de la cinta.

Sin Qt: `DigitalClock` solo lee `view()`.

Convención de dibujo (la de los hubs retirados): el carrete izquierdo gira
con +ángulo y el derecho con −ángulo.
"""

import math

from lorito_aldhiro.backend.playback.lorito_tape_physics import CassetteTransportPhysics

# Modos de la animación de cassette (los de `_tick_cassette`).
TAPE_MODES = ("rec", "drift")
TRANSPORT_MODES = ("play", "speed", "morph_fwd", "morph_rev")


class ReelKinematics:
    """Ángulos de los dos carretes del LCD y quién los mueve."""

    # Avance base por tick del timer de cassette (~24 Hz): 4,76 cm/s sobre un
    # hub de r ≈ 11 mm → 41,3 rpm → 360 × 0,689 / 23,8 ≈ 10,4°/tick.
    BASE_DELTA_DEG = 10.4
    TICK_HZ = 24.0
    # Velocidad lineal de la cinta en mm/s (IEC 60581-6).
    TAPE_SPEED_MM_S = CassetteTransportPhysics.NOMINAL_SPEED_CM_S * 10.0
    # Tambaleo por desborde del cuentavueltas: ±2,5 px (como los hubs).
    WOBBLE_AMPLITUDE_PX = 2.5

    def __init__(self) -> None:
        # Una pareja de ángulos por panel de cinta: [suministro, receptor].
        self._tapes: dict[str, list[float]] = {}
        self._wobble: dict[str, tuple[bool, float]] = {}
        self.transport_angle = 0.0
        self.active_tape: str | None = None
        self.mode: str | None = None
        self.reverse = False
        self._last_view = (0.0, 0.0, 0.0)

    # ── Cinta (grabación) ────────────────────────────────────────────────
    def tape_angles(self, label: str) -> list[float]:
        """[ángulo del suministro, ángulo del receptor] de un panel."""
        return self._tapes.setdefault(label, [0.0, 0.0])

    def _deg(self, r_mm: float, dt: float) -> float:
        return math.degrees(self.TAPE_SPEED_MM_S / r_mm * dt)

    def step_tape(self, label: str, r_supply_mm: float, r_receiver_mm: float,
                  dt: float) -> None:
        """Avance de un tick de grabación: cada bobina gira ω = v / R."""
        a = self.tape_angles(label)
        a[0] = (a[0] + self._deg(r_supply_mm, dt)) % 360.0
        a[1] = (a[1] + self._deg(r_receiver_mm, dt)) % 360.0

    def step_tape_uniform(self, label: str, r_mm: float, dt: float) -> None:
        """OTROS y SOBRANTE: ambas bobinas a radio medio."""
        self.step_tape(label, r_mm, r_mm, dt)

    def reset_tape(self, label: str) -> None:
        """Volteo a Lado B o fin de grabación: los carretes vuelven a 0°."""
        a = self.tape_angles(label)
        a[0] = a[1] = 0.0

    def set_tape_wobble(self, label: str, active: bool, phase: float) -> None:
        self._wobble[label] = (bool(active), float(phase))

    # ── Transporte (reproducción y scrubs) ────────────────────────────────
    def transport_delta(self, mode: str | None, speed_ratio: float = 1.0,
                        morpher_ratio: float = 1.0) -> float:
        """Grados por tick según el modo de la animación de cassette."""
        if mode in TAPE_MODES:
            return self.BASE_DELTA_DEG
        if mode in ("play", "speed"):
            return self.BASE_DELTA_DEG * abs(speed_ratio)
        if mode in ("morph_fwd", "morph_rev"):
            return self.BASE_DELTA_DEG * abs(morpher_ratio)
        return 0.0

    def advance_transport(self, mode: str | None, delta_deg: float,
                          reverse: bool = False) -> None:
        """Tick del timer de cassette: fija el modo y avanza el ángulo."""
        self.mode = mode
        self.reverse = bool(reverse)
        if delta_deg > 0:
            self.transport_angle = (self.transport_angle + delta_deg) % 360.0

    def seek_transport(self, pct: float, total_s: float, speed_ratio: float = 1.0,
                       tick_hz: float | None = None) -> float:
        """Scrub Seek: el ángulo corresponde a la posición de la cinta, como si
        se hubiera llegado allí girando a velocidad nominal × ratio."""
        if total_s > 0.0:
            ticks = pct * total_s * (tick_hz or self.TICK_HZ)
            self.transport_angle = (ticks * self.BASE_DELTA_DEG * abs(speed_ratio)) % 360.0
        return self.transport_angle

    # ── Vista ───────────────────────────────────────────────────────────
    def view(self) -> tuple[float, float, float]:
        """(ángulo del carrete izquierdo, ángulo del derecho, tambaleo en px)
        que dibuja el LCD. En grabación manda el panel de cinta activo; en
        reproducción y scrubs, el transporte; en reposo y en pausa los
        carretes quedan quietos donde estaban."""
        if self.mode in TAPE_MODES and self.active_tape in self._tapes:
            a1, a2 = self._tapes[self.active_tape]
            on, phase = self._wobble.get(self.active_tape, (False, 0.0))
            wob = math.sin(phase) * self.WOBBLE_AMPLITUDE_PX if on else 0.0
            self._last_view = (a1, -a2, wob)
        elif self.mode in TRANSPORT_MODES:
            sign = -1.0 if self.reverse else 1.0
            a = self.transport_angle
            self._last_view = (sign * a, -sign * a, 0.0)
        return self._last_view
