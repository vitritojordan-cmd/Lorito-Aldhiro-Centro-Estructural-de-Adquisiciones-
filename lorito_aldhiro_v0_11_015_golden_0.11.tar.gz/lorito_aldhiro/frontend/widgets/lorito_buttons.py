from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Botones estilizados reutilizables de la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, QRectF, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF



# ═════════════════════════════════════════════════════════════════════════════
#  DoubleClickButton  —  QPushButton con callback de doble clic
# ═════════════════════════════════════════════════════════════════════════════

class DoubleClickButton(QPushButton):
    """
    QPushButton que distingue clic simple de doble clic.

    FIX-STOP-DOUBLE-CLICK (v0.22.55):
      El botón ■ STOP utiliza esta subclase para implementar el doble clic
      especificado en C.R.A.C:
        · Un clic  → stop_all()  (detiene; scrub queda en posición actual)
        · Doble clic → _scrub_reset_to_start()  (stop + scrub retorna a 0)

    La detección se basa en mouseDoubleClickEvent de Qt, que se emite
    cuando el segundo clic ocurre dentro del tiempo de doble clic del SO.
    El clicked() estándar no se emite en el segundo clic cuando Qt lo
    reconoce como doble clic — por tanto NO hay doble disparo de stop_all().

    onDoubleClick: Callable opcional invocado en mouseDoubleClickEvent.
    """

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.onDoubleClick: Optional[Callable] = None

    def mouseDoubleClickEvent(self, event):
        # Ignorar si el botón está deshabilitado
        if not self.isEnabled():
            return
        if self.onDoubleClick:
            self.onDoubleClick()


# ═════════════════════════════════════════════════════════════════════════════
#  LoritoTransportButton — botones de control principal, SEGUNDO rediseño
#  (pedido explícito del usuario, nuevo SVG de referencia adjunto: chasis
#  de metal cepillado oscuro + bisel metálico multicapa + LED retroiluminado
#  con resplandor). CORRECCIÓN sobre el rediseño anterior: ya NO llevan
#  ninguna leyenda de texto (ni "REC" ni nada debajo del símbolo) y el
#  bisel completo ahora se pinta 100% desde código (antes venía de QSS
#  externo vía `setStyleSheet`, que queda como no-op inofensivo para no
#  romper los call-sites existentes de `lorito_mw_ui_build.py`, que siguen
#  llamando `setStyleSheet(...)` además de `setIconLit(...)` — solo esta
#  última sigue teniendo efecto visual real). Formato: rectángulo
#  horizontal, mismo tamaño/forma que los botones que reemplaza (nunca el
#  rectángulo vertical del SVG de referencia, que es solo la fuente de
#  estilo de material/iluminación, no de proporción). El botón EJECT del
#  SVG es, en Lorito Aldhiro, el equivalente exacto del botón EXPORTAR
#  (`ICON_EXPORT`, ya existente).
# ═════════════════════════════════════════════════════════════════════════════

class LoritoTransportButton(DoubleClickButton):
    ICON_REC    = "rec"
    ICON_PLAY   = "play"
    ICON_PAUSE  = "pause"
    ICON_STOP   = "stop"
    ICON_EXPORT = "export"
    ICON_REW    = "rew"        # 0.11.015: rebobinado (◀◀)
    ICON_FF     = "ff"         # 0.11.015: avance rápido (▶▶)

    # Colores del SVG del LCD Display de la usuaria (0.11.008): todos los
    # símbolos en cian #00ffcc retroiluminado, salvo REC en rojo #ff2200.
    _ICON_COLOR = {
        ICON_REC:    QColor("#ff2200"),
        ICON_PLAY:   QColor("#00ffcc"),
        ICON_PAUSE:  QColor("#00ffcc"),
        ICON_STOP:   QColor("#00ffcc"),
        ICON_EXPORT: QColor("#00ffcc"),
        ICON_REW:    QColor("#00ffcc"),
        ICON_FF:     QColor("#00ffcc"),
    }
    _GLOW_COLOR = _ICON_COLOR

    def __init__(self, icon: str, text: str, parent=None):
        # FIX-BOTONES-SIN-LEYENDA: el texto ya NO se pinta — se conserva
        # como tooltip (aparece solo al pasar el ratón, no es una leyenda
        # fija en pantalla) para no perder la pista de qué hace cada
        # botón, y la firma del constructor no cambia (todos los
        # call-sites existentes en `lorito_mw_ui_build.py` siguen
        # pasando `text` sin tocar nada).
        super().__init__("", parent)
        if text:
            self.setToolTip(text)
        self._icon = icon
        self._icon_lit = False      # encendido "sostenido" (estado activo real)
        self._icon_pressed = False  # encendido momentáneo (mientras se pulsa)

    def setIconLit(self, lit: bool) -> None:
        self._icon_lit = lit
        self.update()

    def mousePressEvent(self, event):
        self._icon_pressed = True
        self.update()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self._icon_pressed = False
        self.update()
        super().mouseReleaseEvent(event)

    def _draw_symbol(self, p: QPainter, cx: float, cy: float, s: float, lit_color: QColor):
        """Dibuja el símbolo (mismo trazado del SVG de referencia,
        reescalado a `s` px) centrado en (cx, cy) — ahora SIEMPRE
        centrado en el botón entero (antes pegado al borde izquierdo,
        para dejar sitio al texto que ya no existe)."""
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(lit_color))
        if self._icon == self.ICON_REC:
            p.drawEllipse(QPointF(cx, cy), s * 0.42, s * 0.42)
        elif self._icon == self.ICON_PLAY:
            tri = QPolygonF([QPointF(cx - s*0.32, cy - s*0.42),
                             QPointF(cx - s*0.32, cy + s*0.42),
                             QPointF(cx + s*0.40, cy)])
            p.drawPolygon(tri)
        elif self._icon == self.ICON_PAUSE:
            bw = s * 0.20; gap = s * 0.14; bh = s * 0.78
            p.drawRoundedRect(QRect(int(cx - gap - bw), int(cy - bh/2), int(bw), int(bh)), 1.5, 1.5)
            p.drawRoundedRect(QRect(int(cx + gap), int(cy - bh/2), int(bw), int(bh)), 1.5, 1.5)
        elif self._icon == self.ICON_STOP:
            sq = s * 0.70
            p.drawRoundedRect(QRect(int(cx - sq/2), int(cy - sq/2), int(sq), int(sq)), 2, 2)
        elif self._icon in (self.ICON_FF, self.ICON_REW):
            # Dos triángulos que se tocan en el centro, mismo alto que PLAY.
            d = 1.0 if self._icon == self.ICON_FF else -1.0
            hw, hh = s * 0.34, s * 0.40
            for k in (-1.0, 0.0):              # base de cada triángulo
                base = cx + d * k * hw
                tri = QPolygonF([QPointF(base, cy - hh),
                                 QPointF(base, cy + hh),
                                 QPointF(base + d * hw, cy)])
                p.drawPolygon(tri)
        elif self._icon == self.ICON_EXPORT:
            tri = QPolygonF([QPointF(cx, cy - s*0.42),
                             QPointF(cx - s*0.34, cy + s*0.06),
                             QPointF(cx + s*0.34, cy + s*0.06)])
            p.drawPolygon(tri)
            p.drawRoundedRect(QRect(int(cx - s*0.34), int(cy + s*0.20), int(s*0.68), int(s*0.13)), 1, 1)

    def paintEvent(self, event):
        """Tecla del SVG del LCD Display: tapa metálica (`buttonGrad`,
        borde #111, filo interior claro, sombra) con el símbolo
        retroiluminado. Estados: deshabilitado (símbolo apagado), reposo
        (resplandor suave, como en el SVG), activo/pulsado (resplandor
        pleno y filo del color del símbolo). NUNCA se llama a
        `super().paintEvent()`."""
        from lorito_aldhiro.frontend.support import lorito_svg_skins as skins
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        pressed = self._icon_pressed
        if not skins.paint_svg(p, skins.svg_transport_button(w, h, pressed), 0, 0, w, h, self):
            p.fillRect(1, 1, w - 2, h - 2, QColor("#2c3034"))

        enabled = self.isEnabled()
        lit = self._icon_lit or pressed
        col = QColor(self._ICON_COLOR.get(self._icon, QColor("#00ffcc")))
        cx, cy = w / 2.0, h / 2.0 - 1 + (1 if pressed else 0)
        s = min(w, h) * 0.50

        if enabled:
            # Resplandor detrás del símbolo (emula `iconGlow` del SVG).
            glow = QRadialGradient(cx, cy, s * (1.5 if lit else 1.05))
            g0 = QColor(col); g0.setAlpha(150 if lit else 70)
            g1 = QColor(col); g1.setAlpha(0)
            glow.setColorAt(0.0, g0); glow.setColorAt(1.0, g1)
            p.setPen(Qt.NoPen); p.setBrush(QBrush(glow))
            p.drawEllipse(QPointF(cx, cy), s * 1.5, s * 1.5)
            if lit:
                for _lw, _a in ((4.0, 30), (1.6, 120)):
                    gcol = QColor(col); gcol.setAlpha(_a)
                    p.setPen(QPen(gcol, _lw)); p.setBrush(Qt.NoBrush)
                    p.drawRoundedRect(QRectF(2, 2, w - 4, h - 6), 5, 5)
            sym = col.lighter(130) if lit else col
        else:
            sym = QColor(col); sym.setAlpha(55)
        self._draw_symbol(p, cx, cy, s, sym)
        p.end()
