# Normalización y archivo de motores legados — LA-GOLDEN-NORM-ARCH-017 (0.12)

Este documento cubre los entregables del §12 de la orden:

- auditoría;
- contrato y política de medición;
- inventario de legado y manifiesto;
- rendimiento;
- matriz requisito → cambio → prueba → evidencia.

## 1. Investigación (fuentes consultadas)

| Tema | Hallazgo aplicado | Fuente |
|---|---|---|
| Sonoridad | BS.1770 (revisión -5, nov. 2023): ponderación K (estante + paso alto RLB), bloques de 400 ms con 75 % de solapamiento, puerta absoluta −70 LKFS y relativa −10 LU sobre la potencia media | [LUFS (Wikipedia)](https://en.wikipedia.org/wiki/LUFS) · [pyloudnorm `meter.py`](https://raw.githubusercontent.com/csteinmetz1/pyloudnorm/master/pyloudnorm/meter.py) |
| Fórmula integrada | `L = −0,691 + 10·log10(Σ Gᵢ·z̄ᵢ)` con las medias en potencia; G = 1 / 1,41 (envolventes) | pyloudnorm `meter.py` |
| Coeficientes a cualquier tasa | Biquads de estante y de paso alto por transformación bilineal | [pyloudnorm `iirfilter.py`](https://raw.githubusercontent.com/csteinmetz1/pyloudnorm/master/pyloudnorm/iirfilter.py) · [libebur128](https://github.com/martingasser/libebur128) |
| True peak | Sobremuestreo con FIR de interpolación; ×4 es el compromiso habitual; tasa sobremuestreada ≥ 192 kHz (×2 a 96 kHz) | [ARIB TR-B32](https://arib.or.jp/english/std_tr/broadcasting/desc/tr-b32.html) · [cacophony TruePeakDetector](https://cacophony.js.org/classes/TruePeakDetector.html) · [FFmpeg #2545](https://ffmpeg.org/pipermail/ffmpeg-trac/2013-May/014855.html) |
| Dos pasadas | Medir todo el archivo y aplicar una ganancia lineal estática: sin distorsión dinámica | [FFmpeg loudnorm (DEV)](https://dev.to/javidjamae/ffmpeg-loudnorm-filter-ebu-r128-loudness-normalization-guide-15d4) |
| Techo de entrega | EBU R128: máximo −1 dBTP | ídem |

**Verificación propia:** la tabla de coeficientes de BS.1770 a 48 kHz se reproduce con un error de ~1e-15. Un seno de 1 kHz a −23 dBFS en L y R mide −22,99 LUFS a 44,1, 48 y 96 kHz (forma de la referencia de EBU Tech 3341).

## 2. Auditoría (Fase A) — estado en 0.11.015

| # | Archivo / símbolo | Hallazgo | Severidad | Resolución |
|---|---|---|---|---|
| N-01 | `lorito_export_service.run` (limitador final) | Si el pico tras normalizar pasaba de −0,2 dBFS, se aplicaba un **limitador suave oculto** | Alta (§5) | Retirado. Se baja la ganancia (`TARGET_UNREACHABLE`) o, en curvas no escalares, se aplica un ajuste de techo lineal. El limitador solo existe si la usuaria lo elige (Soft-limit o preset), declarado como etapa |
| N-02 | `measure_lufs_streaming` | Promediaba canales (−3 dB en estéreo), aplicaba la puerta relativa sobre la media en dB e integraba promediando dB; coeficientes aproximados fuera de 44,1/48 kHz | Alta (§4) | Los modos LUFS usan `lorito_bs1770_meter` (BS.1770-5). La función antigua se conserva solo por la equivalencia de los modos de catálogo |
| N-03 | `measure_true_peak_streaming` | Interpolación lineal (×2) o cúbica (×4); el propio diagnóstico decía "no medidor BS.1770 Anexo 2" | Media | Los modos True Peak usan el FIR polifásico del medidor nuevo. La etiqueta "x2" ya no rebaja la precisión |
| N-04 | Todos los modos | Sin ganancia máxima común, sin estado final ni informe antes/después | Media | `decide_gain` (+24 dB máx.), `predict_after`, `verify_after`, `NormState` |
| N-05 | Silencio | Comportamiento distinto por modo | Media (NORM-04) | `SILENT_SOURCE`: 0 dB y aviso |
| N-06 | NaN/Inf | No se detectaban antes de normalizar | Alta (NORM-06) | `NONFINITE_INPUT` aborta: no se publica nada |
| N-07 | Errores en la UI | El mensaje no llevaba el código | Baja (§7) | La UI muestra `[CÓDIGO]` y el estado `[NORM …]` |
| N-08 | `lorito_normalization.py` / `_v21.py` | Motores en RAM (O(duración)) dentro del paquete; producción solo usaba sus constantes, el enum y `_carol_speed_label` | Media (§8) | Extracción a `lorito_normalization_common.py` y archivo en `legado/` |

## 3. Contrato (Fase B) — `lorito_normalizer_golden.py`

**Solicitud** (`NormalizationRequest`, inmutable):

| Campo | Valores / por defecto |
|---|---|
| `target_mode` | SAMPLE_PEAK, TRUE_PEAK, RMS, LUFS o NONE (modo de catálogo) |
| `target_value` | — |
| `sample_ceiling_dbfs` | −0,2 |
| `true_peak_ceiling_dbtp` | −1,0 |
| `max_gain_db` | +24 |
| `channel_linking` | LINKED: una ganancia para todos los canales |
| `true_peak_policy` | REDUCE_GAIN o REPORT_ONLY |

La cancelación es el `cancel_event` del `ExportService`.

**Respuesta** (`ExportResult` + `norm_stats["golden"]`):

| Campo | Contenido |
|---|---|
| `engine` | — |
| `request` | Solicitud usada |
| `before` | Pico de muestra, dBTP, RMS, LUFS, bloques con puerta, NaN/Inf, subnormales, muestras recortadas |
| `requested_gain_db` / `gain_db` | Ganancia pedida y aplicada |
| `target_achieved` | — |
| `predicted_after` | Medidas previstas de la salida |
| `measured_after` | Medidas de la salida publicada |
| `warnings` | — |
| `state` | ARCHIVAL_SAFE / DEGRADED / INVALID |

**Errores** (`NormErrorCode`):

- SOURCE_EMPTY, INVALID_FORMAT, INVALID_REQUEST, NONFINITE_INPUT;
- TARGET_UNREACHABLE y TRUE_PEAK_LIMIT (son avisos);
- IO_ERROR, CANCELLED, ENCODER_ERROR, INTEGRITY_FAILURE.

En el `ExportResult` llevan el prefijo `NORM_`.

### Política por etiqueta de la GUI

| Etiqueta | Medición y objetivo | True peak |
|---|---|---|
| LUFS −23 / −16 / −14 | BS.1770-5 integrado → objetivo | REDUCE_GAIN a −1 dBTP |
| True Peak (x2) / (x4) | dBTP del Anexo 2 → −1 dBTP | REDUCE_GAIN |
| Norm −0,2, RMS, Preservativa, Noise-aware, Crest Guard, Peak inteligente, Auto, 2-pass (escalar) | Fórmula de catálogo (equivalente al motor archivado) → ganancia máxima y techo −0,2 dBFS | REPORT_ONLY |
| Adaptativa, Mid/Side (curvas) | Curva de catálogo; si el pico supera el techo, ajuste lineal y aviso | — |
| Presets de cinta, Soft-limit | Limitador **declarado** (etapa separada en metadatos) | — |

### Flujo

1. Pase 1 de medición.
2. Ganancia.
3. Pase de escritura (encoder → temporal → fsync → publicación atómica → hash releído).
4. Post-medición de la salida publicada (WAV/FLAC/OGG). En WAV y FLAC con ganancia escalar, el pico debe coincidir con lo previsto (±0,05 dB); si no, INTEGRITY_FAILURE.
5. Estado final.
6. Manifiesto.

## 4. Archivo de motores legados (§8)

| Paso | Hecho |
|---|---|
| 1. Descubrimiento | Grafo `ast` de imports en `lorito_aldhiro/`, `tests/`, `tools/` y `lorito_bootstrap.py`, más cadenas de `importlib`. Consumidores: 13 mixins y diálogos (`_carol_speed_label`, `NORM_ITEMS_V21`, `NormalizationModeV21`), 3 módulos streaming (dB y constantes) y 4 pruebas de equivalencia |
| 2. Clasificación | Ambos motores: **legado aún requerido** solo por símbolos triviales. Pasan a **legado sin consumidores** tras la extracción |
| 3. Sustitución | `lorito_normalization_common.py` (sin algoritmo duplicado); camino streaming y Golden ya probados |
| 4. Cuarentena | `legado/lorito_aldhiro/backend/export/` (fuera del paquete, sin `__init__`) |
| 5. Manifiesto | `legado/README_LEGADO.md`: rutas, release y commit de origen, SHA-256, dependencias, licencia, motivo y sustituto |
| 6. Prueba negativa | `test_normalizacion_golden.LEG01/02/03` y `test_legado_desconectado` |
| 7. Recuperación | Procedimiento en el README; cargador aislado `tests/_legado_normalizacion.py`, que verifica los hashes |
| 8. Retención | Archivo inmutable: el cargador rechaza un hash distinto |

## 5. Rendimiento y memoria

| Medida | Resultado |
|---|---|
| Memoria del medidor | O(sub-bloque de 16 384 frames + estado de los filtros + un escalar por bloque de 400 ms). STR-01: 16 s frente a 4 s, pico < ×1,5 |
| Exportación (`EXT01Memory`) | El pico de memoria sigue por debajo del 25 % del arreglo de sesión, con el pase de medición añadido |
| Costo | Un pase de lectura extra (medición) y una post-medición de la salida publicada |

## 6. Matriz §9

| ID | Implementación | Prueba (`tests/test_normalizacion_golden.py` salvo indicación) | Evidencia |
|---|---|---|---|
| NORM-01 | `decide_gain` SAMPLE_PEAK | `test_norm01_exact_peak_gain_under_ceiling` | Pico final exacto (1e-6 dB) bajo el techo |
| NORM-02 | `LevelMeter._true_peak` | `test_norm02_…`, `MeterReference.test_true_peak_*` | Seno fs/4 a 45°: dBTP −6,02 frente a pico de muestra −9,03; tolerancia medida |
| NORM-03 | `LevelMeter._loudness/_integrated` | `MeterReference` (5), `test_norm03_…` | −23,0 ± 0,1 LUFS a 44,1/48/96 kHz; puertas; canales en potencia |
| NORM-04 | `SILENT_SOURCE`, ganancia máxima | `test_norm04_…`, `ExportIntegration.test_silent_source_…` | Silencio a 0 dB; ruido limitado a +24 dB con aviso |
| NORM-05 | `ChannelLinking.LINKED` | `test_norm05_…` | Balance L/R exacto; INDEPENDENT → INVALID_REQUEST |
| NORM-06 | `check_source` | `test_norm06_…` | NaN/Inf contados → NONFINITE_INPUT |
| NORM-07 | Ganancia máxima, techos, `target_achieved` | `test_norm07_…`, `test_no_hidden_limiter_…` | Objetivo no alcanzado informado; sin limitador; 0 overs |
| STR-01 | Medidor por sub-bloques | `STR01Streaming`, `test_export_golden.EXT01Memory` | Memoria acotada |
| STR-02 | `NormalizationError(CANCELLED)` | `STR02Cancel` | Nada publicado, estado INVALID, hash del RAW intacto |
| INT-01 | Post-medición + hash | `INT01OutputIntegrity` (2) | Frames, reapertura, SHA-256, mismatch → INVALID |
| LEG-01 | Extracción a `common` | `LEG01NoResidualImports` | Ningún import ni cadena a los motores archivados |
| LEG-02 | `legado/` | `LEG02ProductionPackage`, `test_legado_desconectado` | No importables; no están en el paquete |
| LEG-03 | Manifiesto | `LEG03Traceability` | Hashes del README = hashes reales |
| UI-01 | Worker de exportación ya existente; etapas ANALYSIS/ENCODING/VERIFY/MANIFEST | `test_export_golden.EXT11Cancel` | Progreso coalescido por frames; la GUI no espera |
| END-01 | Estado acotado | `END01Endurance` | 10 min de señal: −23 ± 0,1 LUFS; ventana de 4 subbloques |
| Equivalencia | Camino streaming frente a motor archivado | `test_normalization_streaming*.py`, `test_normalization_stats_bridge.py` | Ganancias y PCM iguales (o dentro de la tolerancia documentada) |

**Limitaciones:**

- El FIR de true peak es un diseño propio (Kaiser, 32 taps por fase), no la tabla de ejemplo del Anexo 2. Se declara en los metadatos (`tp_filter`) con su tolerancia medida.
- Para códecs WV la post-medición no está disponible y se informa.
- No hay LRA (EBU Tech 3342) ni sonoridad momentánea o de corto plazo: la orden no las pide.
