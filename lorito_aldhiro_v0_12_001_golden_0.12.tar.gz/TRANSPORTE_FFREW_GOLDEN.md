# Motores de avance rápido y rebobinado — LA-GOLDEN-TRANSPORT-018 (0.12)

Este documento entrega lo que pide la orden en su §10:

- auditoría del transporte;
- contrato de API y estados, con el diagrama de transiciones;
- tabla de correspondencia entre el estado y las señales de la UI;
- operación, limitaciones y recuperación;
- matriz requisito → implementación → prueba → evidencia.

Código: `lorito_aldhiro/backend/transport/lorito_ffrew_motors.py`, con el cableado de la UI en `lorito_mw_playback.py`.

## 0. Investigación (fuentes consultadas)

| Tema | Hallazgo | Cómo se aplicó | Fuente |
|---|---|---|---|
| Lógica de transporte de los decks | FF, REW, PLAY y STOP los gobierna una lógica que fuerza las órdenes de modo en una secuencia de parada definida; no se pasa de un sentido al otro sin parar | Tabla de transiciones; FF ↔ REW solo tras STOP_CONFIRMED (TR-03) | [US4223855, freno de transporte bobina a bobina](https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4223855) |
| Freno y tensión en el bobinado rápido | Un motor de bobina a velocidad constante y el otro controlado en par por un detector de tensión; frenado dinámico o motores enfrentados | Rampas de aceleración y frenado acotadas (`ramp_s`); frenado cinemático junto a los extremos | [US4411008](https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4411008) · [US4341363](https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4341363) · [US3218529A](https://patents.google.com/patent/US3218529A/en) |
| Servo de velocidad | Lazo cerrado con sensor de velocidad (generador de frecuencia o rodillo) | La velocidad que pintan los carretes es la *confirmada* por el motor, nunca la ordenada | [US4163532](https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/4163532) · [Sony EL-5](https://www.vintagedigital.com.au/?p=208117) |
| Shuttle en editores | Pulsar de nuevo J/L sube la velocidad del shuttle (Audition, Sound Forge); el shuttle es distinto del scrub y del jog | Cada pulsación de ◀◀ o ▶▶ sube el factor (×1 → ×4 → ×1), con su overlay "Rew < X{n}" / "Ff Wd > X{n}" | [Adobe Audition](https://helpx.adobe.com/audition/desktop/importing-recording-and-playing/navigating-time-playing-audio.html) · [Sound Forge](https://cdn.borisfx.com/borisfx/Documentation/soundforge/2026/en/content/scrubcontrol.htm) · [WaveLab Shuttle](https://archive.steinberg.help/wavelab_pro/v12/en/wavelab/topics/playback/playback_shuttle_function_using_t.html) · [Steinberg, jog/shuttle](https://forums.steinberg.net/t/yamaha-cc1-what-is-the-shuttle-button/1033744) |
| Audio durante la búsqueda | El scrub "digital" reproduce en tiempo real y el "analógico" sigue la velocidad del cabezal | Política declarada `MUTED_SCAN`: sin audio a velocidad nominal; PLAY reanuda desde la posición confirmada | [Toon Boom, scrub analógico](https://docs.toonboom.com/help/harmony-24/premium/sound/about-analog-sound-scrub.html) |

## 1. Auditoría (Fase A) — estado en 0.11.015

**Modo real:** el transporte es **lógico**. Lorito no tiene deck ni controlador físico: solo hay un archivo de sesión ya capturado y el Transport Core (servo) de reproducción. Por eso aplica el **Modo A** de la orden; el Modo B se declara no disponible.

| # | Lugar | Hallazgo | Riesgo | Resolución en 0.12 |
|---|---|---|---|---|
| A-01 | `lorito_mw_playback.py` `_cue_press`/`_cue_release` | FF/REW eran "mantener pulsado". Reproduciendo, ponían `set_speed_live(±4)`, es decir, audio audible a ×4 | §1: la salida se presentaba como reproducción a otra velocidad, sin una política declarada | Política `MUTED_SCAN`: se suspende PLAY y se reanuda tras la parada confirmada |
| A-02 | mismo | No había un dueño del estado: la UI decidía con `_playing`, `_engine.recording` y `_ui_state` sueltos | §2/§6: exclusión mutua solo por botones deshabilitados | `TransportCoordinator`: dueño único, lock y razones tipadas |
| A-03 | mismo | El cambio FF ↔ REW reproduciendo pasaba de +4 a −4 en un comando LIVE | §2: inversión instantánea (el servo rampeaba, pero la orden no la confirmaba) | La parada se confirma antes de arrancar el otro motor (TR-03) |
| A-04 | `_wind_step` | Avance en segundos `float` (`WIND_STEP_S = 1.0`) por tick del QTimer: la velocidad dependía del jitter del timer | §3: error acumulado y velocidad no definida | Frames enteros integrados con el reloj monotónico, con el resto acarreado |
| A-05 | `_wind_step` | Se detenía en el extremo, pero sin mensaje de límite | §5: estado no inequívoco | `LIMIT_REACHED` y mensaje "LÍMITE ALCANZADO — INICIO/FIN" |
| A-06 | STOP (`stop_all`) | No conocía el bobinado: el timer seguía hasta soltar el botón | §6: STOP sin cancelación | STOP pide la rampa y espera el ack; el timeout lleva a ERROR |
| A-07 | Exportador (`_open_lorito_exportador`) | Podía abrirse durante un bobinado | §6: expulsión sin estado seguro | `request_eject`: se detiene primero y se expulsa al confirmar (TR-12) |
| A-08 | LCD | Sin overlay de FF/REW, solo el texto del log | §5 | "Ff Wd > X{n}" / "Rew < X{n}", textos de la usuaria |
| A-09 | Carretes | `seek_transport` con ratio fijo `CUE_RATIO` | §5: el giro no seguía la velocidad real | `wind_transport(rate)` con la velocidad confirmada y el sentido del motor |
| A-10 | Cierre de ventana | No había parada del bobinado | §6 | `shutdown()` en `closeEvent` |

**Corazón y LED de captura:** el corazón del LCD es un pictograma fijo. El LED (`LuminousIndicator`) solo pasa a "rec" desde la ruta de captura. FF/REW no tocan ninguno de los dos (TR-10).

## 2. Contrato (Fase B)

**Estados** (`TransportStatus`):

- STOPPED, PLAYING, PAUSED;
- FAST_FORWARDING, REWINDING;
- SEEKING, CAPTURING, EJECTING;
- ERROR, UNAVAILABLE.

**Fases del motor** (`MotorPhase`):

- IDLE, RAMP_UP, RUNNING;
- STOPPING (DETENIENDO), STOPPED (parada confirmada);
- LIMIT (LÍMITE ALCANZADO);
- CANCELLED, FAILED.

**Calidad de posición** (`PositionQuality`):

| Valor | Cuándo |
|---|---|
| `EXACT_FRAMES` | Adaptador lógico |
| `SENSOR_CONFIRMED` | Reservado para un deck con contador calibrado |
| `ESTIMATED` | Tras un error, posición congelada |
| `UNKNOWN` | Sin hardware |

**Razones de rechazo** (`RejectReason`):

- CAPTURE_ACTIVE, NO_SOURCE;
- INHIBITED (Morpher, exportación);
- EJECT_PENDING, ERROR_STATE, UNAVAILABLE;
- BUSY (seek con un motor en marcha), INVALID.

### Transiciones permitidas (`ALLOWED_TRANSITIONS`)

```
STOPPED ──► PLAYING · PAUSED · FAST_FORWARDING · REWINDING · SEEKING · CAPTURING · EJECTING · ERROR · UNAVAILABLE
PLAYING ──► STOPPED · PAUSED · FAST_FORWARDING · REWINDING · SEEKING · CAPTURING · EJECTING · ERROR
FAST_FORWARDING ──► STOPPED · PLAYING · CAPTURING · ERROR      (nunca ──► REWINDING)
REWINDING       ──► STOPPED · PLAYING · CAPTURING · ERROR      (nunca ──► FAST_FORWARDING)
CAPTURING ──► STOPPED · ERROR
EJECTING  ──► STOPPED · ERROR
ERROR     ──► STOPPED (reset_error) · UNAVAILABLE
```

Una transición fuera de la tabla lanza `InvalidTransition`: es un defecto del programa, no un estado.

### API

**Motor** (`WindMotor`), no bloqueante:

- `start(factor)`
- `set_factor(n)`
- `request_stop(now)`
- `cancel()`
- `status()`
- `tick(now)`

**Coordinador:**

| Método | Qué hace |
|---|---|
| `press(dir, playing)` | Pulsación de FF o REW |
| `stop(resume_play=False)` | Pide la rampa de parada |
| `seek(frame)` | Posiciona en reposo; rechaza con un motor en marcha |
| `set_playing` | Informa el estado de reproducción |
| `capture_started` / `capture_stopped` | Prioridad de la captura |
| `request_eject(cb)` / `eject_done` | Expulsión tras estado seguro |
| `reset_error` | Sale de ERROR |
| `shutdown` | Estado seguro al cerrar |
| `set_source` | Fuente nueva o reposicionamiento en reposo |
| `set_inhibitor` | Inhibidores de diseño |
| `tick(now)` | Devuelve la `TransportSnapshot` |
| `snapshot()` | Instantánea sin avanzar |
| `events()` / `drain_events()` | Cola acotada a 256 |

### Perfiles de velocidad (`SpeedProfile`)

| Parámetro | Valor |
|---|---|
| `base_rate` | 8 s de programa por s real (×1) |
| `max_factor_ff` / `max_factor_rew` | 4 / 4 (separados) |
| `ramp_s` | 0,25 s de 0 al máximo |
| `min_brake_rate` | ×1 de tiempo real |
| `stop_timeout_s` | 1 s |

Son objetivos iniciales de ingeniería. En un transporte lógico no hay hardware que los imponga; se validan con las pruebas.

**Factor por pulsaciones:** ×1 → ×2 → ×3 → ×4 → ×1. La dirección contraria arranca en ×1 tras la parada.

**Integración entera:**

```
frames = (v_fps · dt_ns + resto) // 1e9
```

El resto se acarrea, así que no hay deriva: la prueba TR-07 compara con `v·t` exacto durante 1000 ticks, y también con periodos irregulares.

**Frenado junto al extremo:** `v ≤ √(2·a·d)`, con un piso de ×1. El motor termina exactamente en 0 o en el total.

### Políticas explícitas

| Política | Comportamiento |
|---|---|
| Monitor (`MUTED_SCAN`) | Durante el bobinado no hay audio. Si se partió de PLAY, al confirmarse la parada se reanuda desde la posición confirmada. Un STOP explícito no reanuda; PLAY durante el bobinado detiene y reanuda |
| Seek con motor activo | Se rechaza (BUSY). Nunca dos tareas de movimiento |
| Límite + reversa pendiente | Si el destino pendiente está bloqueado por el mismo extremo, no arranca |

## 3. Integración con la UI (Fase E)

| Estado o evento real | LCD | Log (StatusDisplay) | Otras señales |
|---|---|---|---|
| FF ×n | overlay **"Ff Wd > X{n}"** (familia TAU, celda TAU encendida) | LORITO AVANZA RÁPIDO ▶▶ ×n | Carretes hacia delante a la velocidad confirmada |
| REW ×n | overlay **"Rew < X{n}"** | LORITO REBOBINA ◀◀ ×n | Carretes en sentido inverso |
| STOPPING | overlay del motor que frena | LORITO DETIENE LA CINTA… | Los carretes frenan con la velocidad real |
| Parada confirmada | se retira el overlay | LORITO DETUVO LA CINTA | Botones resincronizados |
| Límite | se retira el overlay | LORITO: LÍMITE ALCANZADO — INICIO / FIN DE LA CINTA | — |
| Rechazo por diseño (captura, sin cinta, Morpher, exportación, expulsión) | **Fnc No Disp** | LORITO NO BOBINA: … (razón) | — |
| ERROR técnico | no se usa Fnc No Disp | LORITO: ERROR DE TRANSPORTE — detalle | Posición congelada, calidad ESTIMATED |
| UNAVAILABLE | Fnc No Disp | LORITO: FUNCIÓN NO DISPONIBLE | — |

Además:

- El contador LCD, el scrub, el cursor de la onda y la posición estacionada (la que usará el próximo PLAY) salen de la **misma** `TransportSnapshot` (TR-09).
- La UI no corre bucles: un QTimer de 25 Hz llama a `tick()`, que es O(1), y pinta solo la última instantánea.

## 4. Operación, limitaciones y recuperación

**Operación:**

- ◀◀ / ▶▶ arrancan a ×1; cada pulsación sube el factor.
- STOP detiene con rampa.
- PLAY durante el bobinado detiene y reproduce desde ahí.
- La salida (▲) durante un bobinado espera la parada.

**Limitaciones conocidas:**

- No hay deck físico: el Modo B es `UNAVAILABLE` (`PhysicalDeckAdapter`).
- Los valores del perfil no están validados contra un transporte real.
- La prueba UI-01 "P95 ≤ 16,7 ms a 60 Hz" no se mide aquí (la GUI de Lorito refresca a ~24–25 Hz; ver el banco).

**Recuperación tras ERROR:**

1. La posición queda congelada en el último valor confirmado y FF/REW se rechazan con ERROR_STATE.
2. `reset_error()` vuelve a STOPPED. En la UI hoy lo dispara la próxima carga de fuente; el log pide "PULSA STOP".
3. La captura no depende del transporte lógico: `capture_started()` sale de ERROR y pasa a CAPTURING.

## 5. Rendimiento (§8) — `tools/transporte/bench_ffrew.py 2`

Datos: 2 h simuladas, 180 000 ticks a 25 Hz, comandos aleatorios.

| Medida | Valor |
|---|---|
| `tick()` p50 / p99 / máx. | 5,0 / 20,1 / 929 µs (el máximo es un pico aislado del intérprete) |
| Memoria del módulo por decil | ≈ 40 KB constantes: es la cola de eventos llena (256), sin crecimiento |
| Posición | Siempre dentro de [0, total] (aserción en cada tick) |

Resultado completo en `saneamiento_0_12_001/bench_ffrew.json`.

**Audio e integridad:**

- FF/REW no abren, leen ni escriben audio. El adaptador lógico solo guarda un entero.
- Sin reproducción durante el bobinado (`MUTED_SCAN`), no hay underruns atribuibles a FF/REW.
- El RAW no se toca.

## 6. Matriz requisito → implementación → prueba → evidencia

| ID | Implementación | Prueba | Evidencia |
|---|---|---|---|
| TR-01 | `WindMotor.tick`, dirección +1 | `test_ffrew_golden.TR01_FFFromPause` | Posiciones monótonas dentro de los límites; ≈ 15,75 s en 2 s a ×1 |
| TR-02 | dirección −1, recorte a 0 | `TR02_REWFromPause` | Nunca < 0; LIMIT START |
| TR-03 | `press()` contraria → `_pending` + `request_stop` | `TR03_DirectionChange`; `test_transport_ff_rew.test_rew_overlay_and_reverse_through_stop` | STOP_CONFIRMED antes del START contrario; sin +v → −v en un tick; FF→REW fuera de la tabla |
| TR-04 | frenado cinemático y recorte exacto | `TR04_Limits` | Termina en el total exacto; LIMIT_REACHED END |
| TR-05 | `stop()` + ack en `tick`; timeout → ERROR | `TR05_StopDuringMotion` (2) | STOPPED solo tras el ack; adaptador sin ack → ERROR "timeout" |
| TR-06 | `capture_started`, CAPTURE_ACTIVE | `TR06_CaptureActive` (2); `test_recording_rejects_with_visible_reason` | Rechazo tipado, Fnc No Disp, bobinado cancelado al arrancar la captura |
| TR-07 | adaptador de índice entero; integración entera | `TR07_LongSource` (2) | 6 h a 192 kHz: < 256 KB del módulo; `frames = v·t` exacto, también con dt irregular |
| TR-08 | `_fail()`: cancelar, congelar, diagnosticar | `TR08_IOError` | ERROR con el detalle; posición congelada; ESTIMATED; `reset_error` |
| TR-09 | `TransportSnapshot` única | `TR09_SameConfirmedPosition`; `test_counter_scrub_and_wave_show_the_confirmed_position` | Contador = scrub = onda = posición estacionada |
| TR-10 | `ReelKinematics.wind_transport` | `test_reels_turn_with_direction_and_capture_heart_untouched` | ff/rew con su sentido; LED y estado del LCD sin cambios |
| TR-11 | `tick()` O(1) en un QTimer; sin bucles en la UI | `bench_ffrew.json` | p99 20 µs |
| TR-12 | `request_eject` / `eject_done` | `TR12_Eject` (2); `test_export_waits_for_the_safe_state` | El exportador se abre solo en EJECTING, tras la parada |
| TR-13 | cola acotada, estados consistentes | `TR13_Endurance` (20 000 comandos); `bench_ffrew.py` (2 h) | Sin excepciones; memoria plana |
| TR-14 | `PhysicalDeckAdapter` | `TR14_NoHardware` | UNAVAILABLE, calidad UNKNOWN, velocidad 0 |
| TR-15 | reloj inyectado, aritmética entera | `TR15_Reproducibility` | Misma secuencia → misma posición y mismos eventos |
| Factor | `SpeedProfile.next_factor` | `FactorByPresses` (2); `test_overlay_factor_follows_the_presses` | ×1→×4→×1; límites FF/REW separados; "Ff Wd > X3" en el LCD |
| Reanudar | `resume_play` | `ResumePolicy` (4); `test_play_during_wind_stops_and_resumes` | Reanuda una sola vez; STOP no reanuda; seek BUSY; NO_SOURCE / INHIBITED |

**Veredicto:**

- FF y REW son mutuamente excluyentes y siguen la máquina de estados.
- No se toca el RAW ni se bobina durante la captura.
- La posición es exacta (frames), o se etiqueta como estimada tras un error.
- STOP, los límites y los errores llevan a estados verificables.

Queda pendiente la revisión independiente y la medición de UI-01 a 60 Hz en el hardware de referencia.
