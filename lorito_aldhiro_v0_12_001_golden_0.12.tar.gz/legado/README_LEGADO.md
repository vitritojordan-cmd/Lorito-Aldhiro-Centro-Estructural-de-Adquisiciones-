# Legado desconectado de Lorito Aldhiro

Esta carpeta guarda los módulos **legados ya desconectados** que se
retiraron del árbol activo, para dejar limpio el paquete `lorito_aldhiro/`.

- Está **fuera del paquete**: nada de aquí se puede importar desde la
  aplicación (`lorito_aldhiro.*`), y las pruebas no lo recorren.
- Se conserva la ruta original debajo de `legado/` para que el origen de
  cada archivo sea evidente.
- Ningún archivo de aquí forma parte de la aplicación ni se mantiene. Es
  referencia histórica e inmutable: cualquier cambio exige versión y
  manifiesto nuevos.
- Única excepción de uso, solo en pruebas: los motores de normalización
  archivados en 0.12 se cargan por ruta, con SHA-256 verificado, desde
  `tests/_legado_normalizacion.py`. Así se demuestra la equivalencia del
  camino streaming. Producción nunca los carga.

## Criterio de retiro

Un módulo se retira solo si es **inalcanzable** desde el arranque real de la
aplicación. El arranque real son `lorito_bootstrap.py` y
`lorito_aldhiro/frontend/lorito_main_window.py`.

El análisis es un grafo de imports construido con `ast` sobre los 152
módulos del paquete, las pruebas y las herramientas. Cuenta:

- imports absolutos y relativos;
- `from paquete import submódulo`;
- imports dentro de funciones;
- cadenas pasadas a `importlib` o `__import__`.

Además se buscó cada símbolo público del módulo en todo el árbol.

Lo que la documentación llama "legado" pero sigue en uso real **no** se
retira:

| Módulo | Motivo para quedarse |
|---|---|
| `RingBufferAbsorcion` | Es una subclase de compatibilidad de `SPSCCaptureRing` que se instancia de verdad. |

Lo que ya se había eliminado antes no está aquí, porque no quedaba ningún
archivo que mover:

- `lorito_exporters` / `_build_export_array`
- `SignalPulseCell`
- los hubs

## Inventario

| Archivo | Ruta original | Retirado en | Motivo |
|---|---|---|---|
| `lorito_aldhiro/backend/export/lorito_reports.py` (866 líneas) | `lorito_aldhiro/backend/export/lorito_reports.py` | 0.11.014 | `NormalizationReport` y el reporte forense del camino de exportación por arreglo completo, eliminado en la Orden Golden de Exportación. Nadie lo importaba; ninguno de sus 13 símbolos se usaba. |
| `lorito_aldhiro/backend/export/lorito_normalization.py` (1993 líneas) | `lorito_aldhiro/backend/export/lorito_normalization.py` | 0.12 | Motor de normalización v0.20 sobre el arreglo de la sesión completa en RAM (Orden LA-GOLDEN-NORM-ARCH-017) |
| `lorito_aldhiro/backend/export/lorito_normalization_v21.py` (907 líneas) | `lorito_aldhiro/backend/export/lorito_normalization_v21.py` | 0.12 | Modos v21 en RAM (presets de cinta, 2 pasadas, limitador conservador) |

## Manifiesto de los motores de normalización (0.12)

Orden LA-GOLDEN-NORM-ARCH-017, §8.

| Archivo | SHA-256 | Release de origen |
|---|---|---|
| `lorito_normalization.py` | `a2ff49599ac0f836dfa1365877ef94f302a37485eeec449fea48ea996c61e821` | 0.11.015 (commit `e42095d`) |
| `lorito_normalization_v21.py` | `55a5adf9d8a18e81769b54984176de222054e9c8422a403bb99128d28c31b3eb` | 0.11.015 (commit `e42095d`) |

**Dependencias de los archivados:**

- NumPy;
- `lorito_app_logging._log`;
- `lorito_audio_backend.NormalizationMode`;
- `lorito_patches._db_to_lin` / `_lin_to_db`;
- `lorito_tape_presets.TAPE_PRESETS`;
- entre ellos, el v21 importa `_norm_db_to_linear` del otro.

**Licencia y atribución:** código propio del proyecto. Las fórmulas son las del catálogo de modos de normalización heredado. Sin dependencias de terceros más allá de NumPy y SciPy.

**Motivo de la retirada:**

- Normalizaban la sesión completa en RAM (memoria O(duración)).
- Su true peak era por interpolación lineal o cúbica (sobrestima hasta +0,5 dB cerca de Nyquist).
- Su LUFS promediaba canales y bloques en dB, y aplicaba la puerta relativa en dominio logarítmico, en contra de BS.1770.
- Aplicaban `np.clip` y limitación como parte de la normalización.

**Sustituto Golden:**

- `export_streaming/lorito_normalization_streaming.py`: los mismos modos de catálogo, por bloques;
- `lorito_normalizer_golden.py`: contrato, techo, ganancia máxima, silencio y errores;
- `lorito_bs1770_meter.py`: pico de muestra, true peak (Anexo 2), RMS y LUFS (BS.1770-5);
- `ExportService`: dos pasadas, publicación atómica y post-medición.

**Consumidores retirados:** lo que producción aún usaba se extrajo a `lorito_aldhiro/backend/export/lorito_normalization_common.py`, sin algoritmo duplicado:

- `_carol_speed_label`;
- la conversión dB;
- las constantes;
- `NormalizationModeV21` y `NORM_ITEMS_V21`.

**Prueba negativa:** `tests/test_normalizacion_golden.py`, clases LEG-01/02/03. Verifican que:

- no son importables desde el paquete;
- ningún código activo los importa;
- el paquete de producción no los incluye;
- los hashes del manifiesto coinciden.

### Recuperación (comparación aislada)

1. Crea una rama aparte: `git switch -c comparacion-normalizacion-legada`.
2. Carga los motores con `tests/_legado_normalizacion.py` (`modules()`), que verifica los SHA-256 de arriba. También puedes copiarlos a un directorio temporal fuera del paquete.
3. Compara las salidas con el camino streaming con las pruebas de `tests/test_normalization_streaming*.py`.
4. Prohibido devolverlos a `lorito_aldhiro/`. Una reintroducción exige una orden de trabajo, pruebas de contrato y la retirada de este manifiesto.

