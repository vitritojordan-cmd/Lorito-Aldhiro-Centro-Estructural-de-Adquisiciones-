from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Servicio único de exportación — ExportRequest → ExportSession → ExportResult tipado.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_service.py — Orden Golden del Motor de Exportación
(EX-01, EX-05, EX-06, EX-12, Fases 1-6).

`ExportService` es la ÚNICA autoridad productiva de exportación. La GUI
solo construye un `ExportRequest` inmutable y consume progreso/resultado:

    ExportRequest ─► preflight (segmentos, formato, códec disponible)
                  ─► plan de transformaciones por bloque
                       normalización (2 pasadas: análisis acotado → escritura
                       releyendo la fuente) → limitador (si hace falta,
                       medido sobre la señal YA transformada) → medidor de
                       overs → resampleo por velocidad con estado
                  ─► ExportSession (SegmentProvider → encoder streaming →
                       AtomicFinalizer: fsync, validación independiente,
                       SHA-256 releído, os.replace, fsync dir, sidecar
                       atómico, relectura post-publicación)
                  ─► manifiesto de procedencia (JSON atómico)
                  ─► ExportResult tipado (nunca solo un booleano)

Memoria: O(block_frames + estado de transformación/encoder). Ninguna
reserva proporcional a la duración de la sesión. Si un códec no está
disponible se aborta ANTES de escribir; jamás hay fallback a array RAM.

Clasificación del resultado (EX-12): `ExportResult.ok` (exportación
completa y verificada) es distinto de `archival_class`:
  · "ARCHIVAL_SAFE" — la captura fuente estaba clasificada ARCHIVAL_SAFE,
    sin normalización ni resampleo, códec sin pérdida con profundidad ≥
    la de la fuente, cero overs, hash releído y sidecar coherentes.
  · "DERIVED"       — exportación correcta, pero transformada (ganancia,
    limitador, velocidad, códec con pérdida o reducción de profundidad).
  · "NOT_ELIGIBLE"  — fuente no ARCHIVAL_SAFE o desconocida, o export
    abortado.
"""

import json
import os
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from lorito_aldhiro.backend.errors import (
    ExportError, CodecUnavailableError, FormatMismatchError,
)
from lorito_aldhiro.backend.export.lorito_normalization_common import (
    _norm_db_to_linear, _norm_linear_to_db,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import (
    SegmentProvider, DEFAULT_BLOCK_FRAMES,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_session import (
    ExportSession, ExportSessionReport,
)
from lorito_aldhiro.backend.export_streaming.lorito_wav_encoder import WavEncoder
from lorito_aldhiro.backend.export_streaming.lorito_ffmpeg_stream_encoder import (
    FlacEncoder, OggEncoder, WvEncoder,
)
from lorito_aldhiro.backend.export_streaming.lorito_export_resample_transform import (
    StreamingSpeedResampleTransform, expected_resampled_frames,
)
from lorito_aldhiro.backend.export_streaming import lorito_normalization_streaming as ns
from lorito_aldhiro.backend.export_streaming.lorito_normalization_stats_bridge import (
    _resolve_gain_and_diagnostics, _base_diagnostics,
)
from lorito_aldhiro.backend.export_streaming.lorito_atomic_finalizer import (
    _fsync_dir, cleanup_orphans,
)
from lorito_aldhiro.backend.export_streaming import lorito_normalizer_golden as ng
from lorito_aldhiro.backend.export_streaming.lorito_normalizer_golden import (
    NormalizationRequest, NormalizationError, NormErrorCode, TargetMode, TruePeakPolicy,
)


# ── Etiquetas de la GUI (mismas que `NormalizationMode`/`NormalizationModeV21`) ──
LABEL_NONE = "Sin normalizar"
_LABEL_TO_BASE = {
    "Norm -0.2 dBFS": "PEAK_SIMPLE",
    "RMS -20 dBFS": "RMS_20",
    "RMS -18 dBFS": "RMS_18",
    "RMS -14 dBFS": "RMS_14",
    "LUFS -23 (broadcast)": "LUFS_23",
    "LUFS -16 (streaming)": "LUFS_16",
    "LUFS -14 (podcast)": "LUFS_14",
    "Preservativa": "PRESERVATIVE",
    "Noise-aware": "NOISE_AWARE",
    "Adaptativa por bloques": "ADAPTIVE_BLOCK",
}
LABEL_INTELLIGENT_PEAK = "Peak inteligente"
LABEL_TRUE_PEAK = "True Peak (x2)"
LABEL_TRUE_PEAK_X4 = "True Peak (x4)"
LABEL_MID_SIDE = "Mid/Side"
LABEL_CREST_GUARD = "Crest Guard"
LABEL_AUTO = "Auto (inteligente)"
LABEL_TWO_PASS = "Análisis 2-pass (profundo)"
LABEL_SOFT_LIMIT_ONLY = "Soft-limit (protección overs)"
_PRESET_LABELS = {
    "Preset: Type I Ferric": "TYPE_I_FERRIC",
    "Preset: Type II Chrome": "TYPE_II_CHROME",
    "Preset: Type IV Metal": "TYPE_IV_METAL",
    "Preset: Voice/Dictaphone": "VOICE_TAPE",
    "Preset: Radio FM Broadcast": "RADIO_FM",
    "Preset: Microcassette": "MICROCASSETTE",
    "Preset: VHS HiFi Audio": "VHS_HIFI",
    "Preset: Reel-to-Reel Transfer": "REEL_TRANSFER",
}

SOFT_LIMIT_CEILING_DB = -0.2

CODEC_EXTENSIONS = {"WAV": "wav", "FLAC": "flac", "OGG": "ogg", "WV": "wv"}
_WAV_SUBTYPE = {"16-bit PCM": "PCM_16", "24-bit PCM": "PCM_24",
                "32-bit PCM": "PCM_32", "32-bit Float": "FLOAT"}
_FLAC_DEPTH = {"16-bit PCM": 16, "24-bit PCM": 24}
_FLAC_COMP = {"0 (sin comprimir)": 0, "1": 1, "2": 2, "3": 3, "4 (estandar)": 4,
              "5": 5, "6": 6, "7": 7, "8 (maximo)": 8}
_OGG_QUAL = {"1 (baja)": 1, "2": 2, "3": 3, "4": 4, "5 (estandar)": 5, "6": 6,
             "7": 7, "8": 8, "9": 9, "10 (maxima)": 10}
_WV_LEVEL = {"Rapido": "1", "Estandar": "5", "Alto": "7", "Maximo": "8"}


# ══════════════════════════════════════════════════════════════════════════════
#  Contratos de aplicación (independientes de Qt)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class ExportRequest:
    segment_paths: tuple
    final_path: str
    codec: str = "WAV"
    opt1: str = ""
    opt2: str = ""
    norm_label: str = LABEL_NONE
    speed_ratio: float = 1.0
    block_frames: int = DEFAULT_BLOCK_FRAMES
    source_archival_state: str = ""          # ARCHIVAL_SAFE / DEGRADED / INVALID / ""
    source_session_id: str = ""
    extra_metadata: tuple = ()               # pares (clave, valor) para sidecar/manifiesto


@dataclass
class ExportResult:
    status: str = "ABORTED"                  # SUCCESS / ABORTED / CANCELLED
    ok: bool = False
    output_path: str = ""
    checksum_path: str = ""
    manifest_path: str = ""
    sha256: str = ""
    sha256_reread_ok: bool = False
    sidecar_ok: bool = False
    durability: str = ""
    codec: str = ""
    encoder_kwargs: dict = field(default_factory=dict)
    transforms: list = field(default_factory=list)
    norm_stats: dict = field(default_factory=dict)
    frames_source: int = 0
    frames_expected_out: int = 0
    frames_read: int = 0
    frames_out: int = 0
    segments_read: int = 0
    segments_failed: int = 0
    overs_samples: int = 0
    rate: int = 0
    channels: int = 0
    error: str = ""
    error_code: str = ""
    failed_stage: str = ""
    exception: object = None
    archival_class: str = "NOT_ELIGIBLE"
    archival_reasons: list = field(default_factory=list)
    rss_start_kb: int = 0
    rss_peak_kb: int = 0
    rss_end_kb: int = 0
    duration_seconds: float = 0.0
    orphans_removed: list = field(default_factory=list)
    manifest_error: str = ""
    # Orden NORM-ARCH-017: estado de la tarea de normalización y avisos
    norm_state: str = ""                     # ARCHIVAL_SAFE / DEGRADED / INVALID
    norm_warnings: list = field(default_factory=list)


# ══════════════════════════════════════════════════════════════════════════════
#  Transformaciones por bloque
# ══════════════════════════════════════════════════════════════════════════════

class OversMeter:
    """Cuenta muestras con |x| > 1.0 justo antes del encoder (DSP-02 /
    EX: ninguna saturación sin contador). No modifica la señal."""

    def __init__(self):
        self.overs = 0
        self.peak = 0.0

    def __call__(self, blk: Block) -> Block:
        a = np.abs(blk.data)
        if a.size:
            self.overs += int(np.count_nonzero(a > 1.0))
            m = float(a.max())
            if m > self.peak:
                self.peak = m
        return blk


def _compose(transforms):
    ts = [t for t in transforms if t is not None]
    if not ts:
        return None

    def _run(blk):
        for t in ts:
            blk = t(blk)
        return blk
    return _run


def _probe_rate(path: str) -> int:
    import soundfile as sf
    with sf.SoundFile(path, "r") as f:
        return int(f.samplerate)


def _post_transform_peak(segment_paths, transform_factory, block_frames) -> float:
    """Pase de ANÁLISIS acotado: aplica una instancia nueva de la
    transformación y mide el pico resultante (sin escribir nada)."""
    t = transform_factory()
    peak = 0.0
    for blk in SegmentProvider(segment_paths).iter_blocks(block_frames):
        out = t(blk) if t is not None else blk
        if out.data.size:
            peak = max(peak, float(np.max(np.abs(out.data))))
    return peak


@dataclass
class NormalizationPlan:
    label: str
    transform_factory: Optional[Callable[[], Optional[Callable]]]
    stats: dict
    descriptions: list
    # Orden NORM-ARCH-017: ganancia escalar propuesta por el modo de
    # catálogo (None si la decide el objetivo Golden o la curva no es
    # escalar), solicitud Golden (LUFS / true peak) y limitador declarado
    # por la usuaria (preset o "Soft-limit"): nunca hay limitador oculto.
    scalar_gain: Optional[float] = None
    golden: Optional[NormalizationRequest] = None
    declared_limiter: bool = False


# Objetivos Golden por etiqueta (§4): LUFS según BS.1770-5 / EBU R128 con
# techo −1 dBTP que reduce la ganancia; true peak según BS.1770 Anexo 2.
_GOLDEN_TARGETS = {
    "LUFS_23": NormalizationRequest(TargetMode.LUFS, -23.0,
                                    true_peak_policy=TruePeakPolicy.REDUCE_GAIN),
    "LUFS_16": NormalizationRequest(TargetMode.LUFS, -16.0,
                                    true_peak_policy=TruePeakPolicy.REDUCE_GAIN),
    "LUFS_14": NormalizationRequest(TargetMode.LUFS, -14.0,
                                    true_peak_policy=TruePeakPolicy.REDUCE_GAIN),
    "TRUE_PEAK": NormalizationRequest(TargetMode.TRUE_PEAK, -1.0,
                                      true_peak_policy=TruePeakPolicy.REDUCE_GAIN),
}
# Modos de catálogo (fórmula propia): techo de pico de muestra −0,2 dBFS y
# true peak informado.
_CATALOG_REQUEST = NormalizationRequest(TargetMode.NONE)


def plan_normalization(label: str, segment_paths, rate: int, total_frames: int,
                       block_frames: int = DEFAULT_BLOCK_FRAMES) -> NormalizationPlan:
    """PASE DE ANÁLISIS (memoria acotada) para la etiqueta de la GUI.
    Devuelve una FÁBRICA de transformación (cada pase de escritura o de
    verificación usa una instancia nueva con su propio estado) y el dict
    de diagnósticos con la forma que consume la UI/spec. Etiqueta
    desconocida → error tipado (nunca fallback silencioso)."""
    paths = list(segment_paths)
    if not label or label == LABEL_NONE:
        return NormalizationPlan(LABEL_NONE, None, {"mode": "NONE", "gain_db": 0.0}, [])

    def _scalar_factory(gain):
        return lambda: ns._gain_block_transform(gain)

    def _scalar_plan(mode_name, gain, diag):
        return NormalizationPlan(label, _scalar_factory(gain), diag,
                                 [f"normalizacion:{mode_name} gain={_db(gain):+.3f} dB"],
                                 scalar_gain=gain)

    def _golden_plan(mode_name, req, extra=None):
        diag = _base_diagnostics(mode_name)
        diag.update(extra or {})
        return NormalizationPlan(label, None, diag, [f"normalizacion:{mode_name} "
                                 f"({req.target_mode.value} {req.target_value:+.1f}, "
                                 f"{ng.ENGINE_ID})"], golden=req)

    if label in _LABEL_TO_BASE or label == LABEL_AUTO:
        base = _LABEL_TO_BASE.get(label)
        if label == LABEL_AUTO:
            base = ns.resolve_auto_mode(paths, rate, total_frames)
        if base in _GOLDEN_TARGETS:
            return _golden_plan(base, _GOLDEN_TARGETS[base],
                                {"auto_selected_mode": base} if label == LABEL_AUTO else None)
        encode_info, diag = _resolve_gain_and_diagnostics(paths, base, rate)
        if label == LABEL_AUTO:
            diag["auto_selected_mode"] = base
        if encode_info[0] == "adaptive_block":
            _tag, gains, block_f = encode_info

            def _adaptive():
                return ns._adaptive_block_transform(gains, block_f,
                                                    ns.NORM_BLOCK_XFADE_FRAMES, total_frames)
            return NormalizationPlan(label, _adaptive, diag,
                                     [f"normalizacion:{base} (curva por bloque, "
                                      f"{len(gains)} bloques)"])
        return _scalar_plan(base, encode_info[1], diag)

    if label == LABEL_INTELLIGENT_PEAK:
        eff, tp = ns.measure_intelligent_peak_streaming(paths)
        gain = ns.compute_intelligent_peak_gain(eff)
        diag = _base_diagnostics("INTELLIGENT_PEAK")
        diag.update(peak_db=_db(tp), gain_db=_db(gain),
                    effective_peak_db=_db(eff), approximation="histograma 65536 bins")
        return _scalar_plan("INTELLIGENT_PEAK", gain, diag)

    if label in (LABEL_TRUE_PEAK, LABEL_TRUE_PEAK_X4):
        # Ambas etiquetas miden con el medidor BS.1770 Anexo 2, cuyo factor
        # de sobremuestreo lo fija la tasa (×4 < 96 kHz): la etiqueta
        # histórica "x2" ya no rebaja la precisión.
        return _golden_plan("TRUE_PEAK", _GOLDEN_TARGETS["TRUE_PEAK"],
                            {"label_oversampling": 2 if label == LABEL_TRUE_PEAK else 4})

    if label == LABEL_CREST_GUARD:
        peak, rms = ns.measure_peak_rms_streaming(paths)
        gain = ns.compute_crest_guard_gain(rms, peak)
        diag = _base_diagnostics("CREST_GUARD")
        diag.update(peak_db=_db(peak), gain_db=_db(gain))
        return _scalar_plan("CREST_GUARD", gain, diag)

    if label == LABEL_MID_SIDE:
        mid, side = ns.measure_mid_side_streaming(paths, block_frames)
        mg, sg = ns.compute_mid_side_gains(mid, side, -18.0, 6.0, 0.70)
        diag = _base_diagnostics("MID_SIDE")
        mp, sp = mid * mg, side * sg
        diag.update(mid_rms=_db(mid), side_rms=_db(side), gain_db=_db(mg),
                    stereo_balance_index=(sp / (mp + sp)) if (mp + sp) > 1e-9 else 0.0)
        return NormalizationPlan(label, lambda: ns._mid_side_gain_transform(mg, sg), diag,
                                 [f"normalizacion:MID_SIDE mid={_db(mg):+.3f} dB "
                                  f"side={_db(sg):+.3f} dB"])

    if label == LABEL_TWO_PASS:
        base = ns.resolve_two_pass_mode(paths, rate)
        encode_info, diag = _resolve_gain_and_diagnostics(paths, base, rate)
        diag["two_pass_resolved_mode"] = base
        if encode_info[0] == "adaptive_block":
            _tag, gains, block_f = encode_info
            return NormalizationPlan(
                label, lambda: ns._adaptive_block_transform(
                    gains, block_f, ns.NORM_BLOCK_XFADE_FRAMES, total_frames),
                diag, [f"normalizacion:TWO_PASS→{base}"])
        plan = _scalar_plan(f"TWO_PASS→{base}", encode_info[1], diag)
        return plan

    if label == LABEL_SOFT_LIMIT_ONLY:
        diag = _base_diagnostics("SOFT_LIMIT_ONLY")
        diag["gain_db"] = 0.0
        return NormalizationPlan(label, None, diag, [], declared_limiter=True)

    if label in _PRESET_LABELS:
        from lorito_aldhiro.backend.playback.lorito_tape_presets import TAPE_PRESETS
        preset = TAPE_PRESETS[_PRESET_LABELS[label]]
        gain, decision, preset_ceiling = ns.plan_tape_preset_gain(paths, rate, preset)
        diag = _base_diagnostics(f"PRESET_{_PRESET_LABELS[label]}")
        diag.update(gain_db=_db(gain), preset_decision=decision)
        if decision == "silent":
            return NormalizationPlan(label, None, diag,
                                     [f"normalizacion:PRESET {_PRESET_LABELS[label]} (silencio: sin ganancia)"])

        def _preset_factory():
            return _compose([ns._gain_block_transform(gain),
                             ns.make_soft_limiter_transform(ceiling_db=preset_ceiling)])
        return NormalizationPlan(label, _preset_factory, diag,
                                 [f"normalizacion:PRESET {_PRESET_LABELS[label]} "
                                  f"({decision}) gain={_db(gain):+.3f} dB",
                                  f"limitador_preset (etapa declarada) ceiling={preset_ceiling} dBFS"],
                                 declared_limiter=True)

    raise ExportError(f"EXPORT_ABORT_UNKNOWN_NORMALIZATION: etiqueta {label!r} "
                      f"no reconocida — se rechaza en vez de exportar sin normalizar")


def _db(x: float) -> float:
    return _norm_linear_to_db(x) if x > 1e-12 else float("-inf")


# ══════════════════════════════════════════════════════════════════════════════
#  Códecs (preflight explícito)
# ══════════════════════════════════════════════════════════════════════════════

def resolve_encoder(codec: str, opt1: str, opt2: str, source_width_bytes: int):
    """Devuelve `(encoder_cls, kwargs, lossless, out_bits)` con TODOS los
    parámetros explícitos. Lanza `CodecUnavailableError` si el códec no
    existe o su encoder ffmpeg no está disponible — antes de escribir."""
    codec = (codec or "").upper()
    if codec == "WAV":
        subtype = _WAV_SUBTYPE.get(opt1, "PCM_24")
        bits = {"PCM_16": 16, "PCM_24": 24, "PCM_32": 32, "FLOAT": 32}[subtype]
        return WavEncoder, {"subtype": subtype}, True, bits
    if codec == "FLAC":
        enc, kw = FlacEncoder, {"bit_depth": _FLAC_DEPTH.get(opt1, 24),
                                "compression_level": _FLAC_COMP.get(opt2, 4)}
        lossless, bits = True, kw["bit_depth"]
    elif codec == "OGG":
        enc, kw = OggEncoder, {"quality": float(_OGG_QUAL.get(opt1, 5))}
        lossless, bits = False, 0
    elif codec == "WV":
        enc, kw = WvEncoder, {"compression_level": _WV_LEVEL.get(opt1, "5")}
        lossless, bits = True, 32
    else:
        raise CodecUnavailableError(f"EXPORT_ABORT_CODEC_UNKNOWN: {codec!r}")
    probe = enc.__new__(enc)
    try:
        probe._pick_encoder_name()
    except Exception as e:
        raise CodecUnavailableError(f"EXPORT_ABORT_CODEC_UNAVAILABLE: {e}", cause=e)
    return enc, kw, lossless, bits


# ══════════════════════════════════════════════════════════════════════════════
#  Servicio
# ══════════════════════════════════════════════════════════════════════════════

class ExportService:
    """Autoridad única de exportación (sin Qt)."""

    def run(self, request: ExportRequest,
            progress_cb: Optional[Callable[[str, int, int], None]] = None,
            cancel_event=None) -> ExportResult:
        """`progress_cb(stage, frames_done, frames_total)` — progreso por
        FRAMES procesados y estado del motor (nunca por tamaño de archivo)."""
        res = ExportResult(codec=request.codec, output_path=request.final_path)
        t0 = time.monotonic()
        out_dir = os.path.dirname(os.path.abspath(request.final_path)) or "."
        res.orphans_removed = cleanup_orphans(out_dir)

        def _stage(name, done=0, total=0):
            if progress_cb is not None:
                try:
                    progress_cb(name, done, total)
                except Exception:
                    pass

        try:
            _stage("PREFLIGHT")
            provider = SegmentProvider(request.segment_paths)
            fmt = provider.fmt
            res.rate, res.channels = fmt.rate, fmt.channels
            res.frames_source = provider.total_frames
            enc_cls, enc_kw, lossless, out_bits = resolve_encoder(
                request.codec, request.opt1, request.opt2, fmt.sample_width_bytes)
            res.encoder_kwargs = dict(enc_kw)
            ratio = float(request.speed_ratio or 1.0)
            if not (0.05 <= ratio <= 20.0):
                raise ExportError(f"EXPORT_ABORT_SPEED_RATIO: {ratio}")

            _stage("ANALYSIS")
            plan = plan_normalization(request.norm_label, request.segment_paths,
                                      fmt.rate, provider.total_frames, request.block_frames)
            res.norm_stats = dict(plan.stats)
            res.transforms.extend(plan.descriptions)

            # ── Normalización Golden (Orden NORM-ARCH-017) ─────────────────
            # Pase de medición BS.1770 de la fuente; ganancia estática con
            # ganancia máxima, techo y política de true peak; SIN limitador
            # oculto (solo el declarado por la usuaria: preset o Soft-limit).
            normalized = request.norm_label not in ("", LABEL_NONE)
            limiter_needed = False
            predicted, scalar = None, False
            norm_factory = plan.transform_factory
            gold = {"engine": ng.ENGINE_ID}
            if normalized:
                before = ng.measure_source(
                    ng.as_array_blocks(lambda: SegmentProvider(request.segment_paths)
                                       .iter_blocks(request.block_frames)),
                    fmt.rate, fmt.channels, cancel_event=cancel_event)
                ng.check_source(before)
                gold["before"] = before.as_dict()
                ceiling = _norm_db_to_linear(ng.DEFAULT_SAMPLE_CEILING_DBFS)
                if plan.golden is not None or plan.scalar_gain is not None:
                    req = plan.golden or _CATALOG_REQUEST
                    dec = ng.decide_gain(req, before,
                                         None if plan.golden is not None else plan.scalar_gain)
                    gold.update(request=req.as_dict(), requested_gain_db=_db(dec.requested_gain),
                                gain_db=_db(dec.gain), target_achieved=dec.target_achieved)
                    res.norm_warnings.extend(dec.warnings)
                    norm_factory = ((lambda g=dec.gain: ns._gain_block_transform(g))
                                    if abs(dec.gain - 1.0) > 1e-12 else None)
                    predicted, scalar = ng.predict_after(before, dec.gain), True
                    gold["predicted_after"] = predicted
                    res.norm_stats.update(gain_db=_db(dec.gain), peak_db=before.sample_peak_dbfs,
                                          true_peak_db=before.true_peak_dbtp)
                    if plan.golden is not None and plan.golden.target_mode == TargetMode.LUFS:
                        res.norm_stats.update(lufs_measured=before.integrated_lufs,
                                              lufs_target=plan.golden.target_value)
                    res.transforms = [t for t in res.transforms
                                      if not t.startswith("normalizacion:")]
                    res.transforms.append(f"normalizacion:{plan.stats.get('mode', request.norm_label)} "
                                          f"gain={_db(dec.gain):+.3f} dB ({ng.ENGINE_ID})")
                else:
                    peak_after = _post_transform_peak(request.segment_paths,
                                                      norm_factory or (lambda: None),
                                                      request.block_frames)
                    res.norm_stats["post_transform_peak_db"] = _db(peak_after)
                    gold.update(request={"target_mode": "CURVA_DE_CATALOGO"},
                                post_transform_peak_dbfs=_db(peak_after))
                    if peak_after > ceiling:
                        if plan.declared_limiter:
                            limiter_needed = True
                        else:
                            trim = ceiling / peak_after
                            base_f = norm_factory
                            norm_factory = (lambda b=base_f, t=trim: _compose(
                                [b() if b else None, ns._gain_block_transform(t)]))
                            res.norm_warnings.append(
                                f"{NormErrorCode.TARGET_UNREACHABLE.value}: curva recortada "
                                f"{_db(trim):+.2f} dB por el techo de "
                                f"{ng.DEFAULT_SAMPLE_CEILING_DBFS:+.1f} dBFS (sin limitador)")
                            res.transforms.append(f"ajuste_de_techo {_db(trim):+.3f} dB")
            res.norm_stats["soft_limiter_triggered"] = bool(limiter_needed)
            res.norm_stats["golden"] = gold
            if limiter_needed:
                res.transforms.append(f"limitador_suave (etapa declarada) "
                                      f"ceiling={SOFT_LIMIT_CEILING_DB} dBFS")

            resample = None
            expected_out = provider.total_frames
            if abs(ratio - 1.0) > 0.0005:
                resample = StreamingSpeedResampleTransform(ratio, provider.total_frames)
                expected_out = expected_resampled_frames(provider.total_frames, ratio)
                res.transforms.append(f"velocidad ×{ratio:.4f} (resampleo con estado)")
            res.frames_expected_out = expected_out

            overs = OversMeter()
            norm_t = norm_factory() if norm_factory else None
            limiter_t = (ns.make_soft_limiter_transform(ceiling_db=SOFT_LIMIT_CEILING_DB)
                         if limiter_needed else None)
            transform = _compose([norm_t, limiter_t, resample, overs])

            meta = dict(request.extra_metadata)
            if normalized:
                meta.update({"Normalizacion_motor": ng.ENGINE_ID,
                             "Normalizacion_ganancia_dB": f"{res.norm_stats.get('gain_db', 0.0):+.3f}"})
            meta.update({"Codec": request.codec, "Normalizacion": request.norm_label,
                         "Velocidad": f"{ratio:.4f}",
                         "Transformaciones": "; ".join(res.transforms) or "ninguna"})
            session = ExportSession(
                request.segment_paths, enc_cls, request.final_path,
                encoder_kwargs=enc_kw, block_frames=request.block_frames,
                block_transform=transform, expected_output_frames=expected_out,
                sidecar_metadata=meta)

            def _frames_progress(done, total):
                _stage("ENCODING", done, total)

            _stage("ENCODING", 0, expected_out)
            report = session.run(cancel_event=cancel_event, progress_cb=_frames_progress)
            self._absorb(res, report)
            res.overs_samples = overs.overs
            res.norm_stats["export_overs_samples"] = overs.overs
            if res.ok and normalized:
                _stage("VERIFY")
                after = None
                if request.codec in ("WAV", "FLAC", "OGG"):
                    try:
                        after = ng.measure_source(ng.file_blocks(res.output_path),
                                                  fmt.rate if abs(ratio - 1.0) <= 0.0005 else
                                                  _probe_rate(res.output_path), fmt.channels)
                    except Exception as e:      # lectura de la salida: se informa
                        res.norm_warnings.append(f"post-medición fallida: {e}")
                ok_v, w = ng.verify_after(after, predicted, lossless,
                                          scalar and abs(ratio - 1.0) <= 0.0005)
                res.norm_warnings.extend(w)
                gold["measured_after"] = after.as_dict() if after is not None else None
                state = ng.final_state(ok_v, res.norm_warnings)
                res.norm_state = state.value
                gold.update(state=state.value, warnings=list(res.norm_warnings))
                if not ok_v and after is not None:
                    res.error_code = f"NORM_{NormErrorCode.INTEGRITY_FAILURE.value}"
            elif normalized:
                res.norm_state = ng.NormState.INVALID.value
                gold.update(state=res.norm_state, warnings=list(res.norm_warnings))
            if res.ok:
                _stage("MANIFEST")
                try:
                    res.manifest_path = self._write_manifest(request, res, provider)
                except Exception as e:
                    # El audio ya está publicado y verificado (hash releído +
                    # sidecar): no se "despublica", pero la falta de
                    # procedencia se declara y bloquea ARCHIVAL_SAFE.
                    res.manifest_error = f"{type(e).__name__}: {e}"
            self._classify(request, res, lossless, out_bits, fmt.sample_width_bytes * 8,
                           normalized, limiter_needed, ratio)
        except NormalizationError as e:
            res.status = "CANCELLED" if e.code == NormErrorCode.CANCELLED else "ABORTED"
            res.ok = False
            res.error, res.exception = str(e), e
            res.error_code = f"NORM_{e.code.value}"
            res.failed_stage = res.failed_stage or "ANALYSIS"
            res.norm_state = ng.NormState.INVALID.value
            res.archival_class = "NOT_ELIGIBLE"
            res.archival_reasons = [f"normalización rechazada: {e}"]
        except ExportError as e:
            res.status, res.ok = "ABORTED", False
            res.error, res.exception = str(e), e
            res.error_code = str(e).split(":", 1)[0]
            res.failed_stage = res.failed_stage or "PREFLIGHT"
            res.archival_class = "NOT_ELIGIBLE"
            res.archival_reasons = [f"exportación abortada: {e}"]
        except Exception as e:
            res.status, res.ok = "ABORTED", False
            res.error, res.exception = f"{type(e).__name__}: {e}", e
            res.error_code = "EXPORT_ABORT_UNEXPECTED"
            res.archival_class = "NOT_ELIGIBLE"
            res.archival_reasons = [f"exportación abortada: {e}"]
        res.duration_seconds = time.monotonic() - t0
        _stage("DONE" if res.ok else res.status)
        return res

    @staticmethod
    def _absorb(res: ExportResult, report: ExportSessionReport):
        res.status = report.status
        res.ok = report.ok
        res.sha256 = report.sha256
        res.checksum_path = report.checksum_path
        res.sha256_reread_ok = report.sha256_reread_ok
        res.sidecar_ok = report.sidecar_ok
        res.durability = report.durability
        res.frames_read = report.frames_in
        res.frames_out = report.frames_out
        res.segments_read = report.segments_read
        res.segments_failed = report.segments_failed
        res.error = report.error
        res.exception = report.exception
        res.failed_stage = report.failed_stage
        res.rss_start_kb = report.rss_start_kb
        res.rss_peak_kb = report.rss_peak_kb
        res.rss_end_kb = report.rss_end_kb
        if report.exception is not None and not res.error_code:
            res.error_code = type(report.exception).__name__

    @staticmethod
    def _classify(request, res, lossless, out_bits, src_bits, normalized,
                  limiter, ratio):
        reasons = []
        if not res.ok:
            res.archival_class = "NOT_ELIGIBLE"
            res.archival_reasons = [f"exportación no completada ({res.status}): {res.error}"]
            return
        if request.source_archival_state != "ARCHIVAL_SAFE":
            reasons.append(f"captura fuente no ARCHIVAL_SAFE "
                           f"({request.source_archival_state or 'desconocida'})")
            res.archival_class = "NOT_ELIGIBLE"
            res.archival_reasons = reasons
            return
        if res.norm_state == "INVALID":
            res.archival_class = "NOT_ELIGIBLE"
            res.archival_reasons = ["normalización INVALID: "
                                    + "; ".join(res.norm_warnings or ["verificación fallida"])]
            return
        if normalized:
            reasons.append(f"normalización aplicada ({request.norm_label}, "
                           f"estado {res.norm_state or '?'})")
            reasons.extend(f"aviso: {w}" for w in res.norm_warnings)
        if limiter:
            reasons.append("limitador declarado aplicado")
        if abs(ratio - 1.0) > 0.0005:
            reasons.append(f"velocidad ×{ratio:.4f}")
        if not lossless:
            reasons.append(f"códec con pérdida ({request.codec})")
        elif out_bits and out_bits < src_bits:
            reasons.append(f"profundidad reducida {src_bits}→{out_bits} bits")
        if res.overs_samples:
            reasons.append(f"{res.overs_samples} muestras con |x|>1 (saturadas en PCM)")
        if not (res.sha256_reread_ok and res.sidecar_ok):
            reasons.append("hash/sidecar no verificados tras publicar")
        if res.manifest_error or not res.manifest_path:
            reasons.append(f"manifiesto de procedencia no publicado ({res.manifest_error})")
        res.archival_class = "DERIVED" if reasons else "ARCHIVAL_SAFE"
        res.archival_reasons = reasons

    @staticmethod
    def _write_manifest(request, res, provider) -> str:
        """Manifiesto de procedencia (JSON, publicación atómica): fuente,
        transformaciones, códec, frames y hash del resultado."""
        import hashlib
        sources = []
        for p in request.segment_paths:
            h = hashlib.sha256()
            with open(p, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
            sources.append({"path": os.path.basename(p), "sha256_file": h.hexdigest(),
                            "bytes": os.path.getsize(p)})
        try:
            from lorito_aldhiro.backend.core.lorito_version import APP_VERSION
        except Exception:
            APP_VERSION = "?"
        doc = {
            "schema": "lorito.export.manifest/1",
            "app_version": APP_VERSION,
            "output": os.path.basename(res.output_path),
            "sha256": res.sha256,
            "codec": request.codec,
            "encoder_kwargs": res.encoder_kwargs,
            "rate": res.rate, "channels": res.channels,
            "frames_source": res.frames_source, "frames_out": res.frames_out,
            "transforms": res.transforms,
            "normalization": {k: (v if isinstance(v, (int, float, str, bool)) or v is None
                                  else str(v)) for k, v in res.norm_stats.items()},
            "source_session_id": request.source_session_id,
            "source_archival_state": request.source_archival_state,
            "sources": sources,
            "durability": res.durability,
        }
        doc["extra_metadata"] = {str(k): str(v) for k, v in request.extra_metadata}
        path = res.output_path + ".manifest.json"
        tmp = path + ".tmp"
        try:
            payload = json.dumps(doc, ensure_ascii=False, indent=2, allow_nan=True,
                                 default=str)
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
        except Exception:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
        _fsync_dir(path)
        return path
