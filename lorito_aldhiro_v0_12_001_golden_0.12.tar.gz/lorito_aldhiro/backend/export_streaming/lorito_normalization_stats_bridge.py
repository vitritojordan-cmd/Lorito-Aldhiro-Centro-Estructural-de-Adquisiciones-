from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Puente entre el resultado de una exportación streaming y los campos `_status` (`.normalization_*`) que consume la UI/spec file.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_normalization_stats_bridge.py — GAP-066 (cierre de FASE 3,
hueco (c): "no existe puente entre `ExportSessionReport` y los campos
`_status` (`.normalization_*`) que consume la UI/spec file").

## El hueco exacto

El camino LEGADO (`_apply_normalization_advanced()`,
`backend/export/lorito_normalization.py`) devuelve SIEMPRE
`(audio_out, stats: dict)`, donde `stats` es un dict plano con claves
como `"mode"`/`"gain_db"`/`"peak_db"`/`"lufs"`/`"noise_floor_db"`/
`"true_peak_db"` (+ claves específicas de modo: `"mid_rms"`/
`"side_rms"`/`"stereo_balance_index"` para MID_SIDE, etc.). El
llamador (`lorito_mw_export.py`, líneas ~379-395) copia cada clave de
ese dict a un atributo `_status` (`.normalization_*`) correspondiente, con
`.get(clave, default)` — la UI y el "Aldhira de Especificación de
CRAC" (spec file) leen esos atributos, nunca el dict directamente.

El camino STREAMING (`lorito_normalization_streaming.py`,
`export_resolved_mode()`/`export_with_mid_side_gain()`/etc.) SOLO
devuelve `ExportSessionReport` (frames/ok/checksum/§4) — los valores
intermedios de diagnóstico (peak/rms/lufs/ganancia ya calculados
DENTRO de esas funciones para poder exportar) se descartan en cuanto
se usan. Sin un puente, cablear el camino streaming a producción
dejaría a la UI/spec file sin ninguno de esos ~19 campos.

## La solución — MISMA forma de dict que el legado, origen distinto

`export_resolved_mode_with_stats()`/`export_mid_side_with_stats()`
(nuevas, en este módulo) devuelven `(ExportSessionReport, stats:
dict)` — el MISMO dict plano de claves que `_apply_normalization_
advanced()` ya produce, calculado a partir de los MISMOS valores
`measure_*`/`compute_*` que ya existen en `lorito_normalization_
streaming.py` (nunca reimplementados — se importan y se llaman tal
cual, mismo criterio que el resto de ese módulo). Con esto, el bloque
de asignación YA EXISTENTE en `lorito_mw_export.py` (líneas 379-395,
`_status` (`.normalization_mode = ...`), etc.) funciona SIN CAMBIOS con
`stats` de origen streaming — el puente es de FORMA de dato, no de
lógica de la UI.

`apply_normalization_stats_to_status(status, stats)` empaqueta ese
mismo bloque de asignación como una función reutilizable, para que la
sesión futura que cablee esto a `lorito_mw_export.py` (bloqueada hoy
por la ausencia de PySide6 ejecutable en este sandbox — el bloqueo
real que justifica dejar esto sin cablear, no una limitación de este
módulo) solo necesite UNA llamada.

## Alcance de este cierre (honesto, no exhaustivo)

Cubre el camino de modo ÚNICO resuelto (`export_resolved_mode`, usado
por AUTO vía `resolve_auto_mode()` y por selección directa de un modo
de Categoría A/B) y MID_SIDE. **NO** cubre todavía
`export_tape_preset()` (presets de cinta v21) ni `export_two_pass()`
(TWO_PASS v21) — ambos con su propio árbol de decisión INDEPENDIENTE
de `export_resolved_mode` (ver sus propios docstrings) — mismo patrón
de puente, extensión mecánica para una sesión futura, documentada
aquí en vez de implementada apresuradamente en esta (que además debe
cerrar las 8 fases restantes de esta Orden en la misma sesión).

Orden Golden de Exportación (Fase 6): la bandera de migración
`USE_STREAMING_EXPORT` quedó RETIRADA — el camino streaming
(`ExportService`) es la única ruta productiva y no existe fallback a RAM.
"""

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_export_session import ExportSessionReport
from lorito_aldhiro.backend.export.lorito_normalization_common import (
    _norm_db_to_linear, _norm_linear_to_db,
)
from lorito_aldhiro.backend.export_streaming.lorito_normalization_streaming import (
    DEFAULT_BLOCK_FRAMES,
    measure_peak_streaming, measure_peak_rms_streaming, measure_lufs_streaming,
    measure_block_rms_streaming, measure_adaptive_block_gains, measure_mid_side_streaming,
    measure_soft_limiter_needed,
    compute_peak_simple_gain, compute_preservative_gain, compute_lufs_gain,
    compute_noise_aware_gain, compute_rms_gain, compute_mid_side_gains,
    export_with_scalar_gain, export_with_block_transform, export_adaptive_block,
    export_with_mid_side_gain,
    _gain_block_transform, _adaptive_block_transform, compose_transforms,
    make_soft_limiter_transform,
    _BASE_MODE_LUFS_TARGET, _BASE_MODE_TARGET_RMS,
)
from lorito_aldhiro.backend.export_streaming.lorito_segment_provider import SegmentProvider


# FASE 4/5 (§26 de la Orden) — flag de migración con rollback, MISMO
# patrón que `USE_CONTINUOUS_RESAMPLE`. Ver docstring del módulo para
# el porqué de `False` por defecto (a diferencia de esa flag).


def _base_diagnostics(resolved_mode: str) -> dict:
    """Mismas claves base que TODO modo devuelve en el camino legado
    (`_apply_normalization_advanced`, cualquier rama) — ver docstring
    del módulo."""
    return {
        "mode": resolved_mode,
        "gain_db": 0.0,
        "peak_db": float("-inf"),
        "lufs": float("-inf"),
        "noise_floor_db": float("-inf"),
        "true_peak_db": float("-inf"),
    }


def _resolve_gain_and_diagnostics(segment_paths, resolved_mode: str, rate: int):
    """Réplica EXACTA del árbol de decisión de `export_resolved_mode`
    (`lorito_normalization_streaming.py`) — mismas llamadas
    `measure_*`/`compute_*`, mismo orden, para que el `gain`
    resultante sea IDÉNTICO al que produciría `export_resolved_mode`
    con el mismo `resolved_mode` (verificado en
    `tests/test_normalization_stats_bridge.py` comparando ambos
    reports bit a bit). Además construye el dict de diagnósticos con
    la forma del camino legado.

    Devuelve `(encode_info, diagnostics)`:
      - `encode_info = ("scalar", gain: float)` — Categoría A.
      - `encode_info = ("adaptive_block", block_gains: np.ndarray, block_f: int)`
        — ADAPTIVE_BLOCK (sin un único `gain` escalar; `diagnostics
        ["gain_db"]` es la MEDIA en dB de las ganancias por bloque,
        misma fórmula que `_norm_adaptive_block` legado).
    """
    diag = _base_diagnostics(resolved_mode)

    if resolved_mode == "ADAPTIVE_BLOCK":
        block_gains, block_f = measure_adaptive_block_gains(segment_paths, rate)
        peak = measure_peak_streaming(segment_paths)
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
        if block_gains.size:
            gain_db_mean = float(np.mean(
                np.log10(np.maximum(block_gains, 1e-12)) * 20.0))
            diag["gain_db"] = gain_db_mean
            if diag["peak_db"] != float("-inf"):
                diag["true_peak_db"] = diag["peak_db"] + gain_db_mean
        return ("adaptive_block", block_gains, block_f), diag

    if resolved_mode == "PEAK_SIMPLE":
        peak = measure_peak_streaming(segment_paths)
        gain = compute_peak_simple_gain(peak)
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
    elif resolved_mode == "PRESERVATIVE":
        peak, _rms = measure_peak_rms_streaming(segment_paths)
        gain = compute_preservative_gain(peak)
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
    elif resolved_mode in _BASE_MODE_LUFS_TARGET:
        lufs, peak = measure_lufs_streaming(segment_paths, rate)
        gain = compute_lufs_gain(lufs, peak, _BASE_MODE_LUFS_TARGET[resolved_mode])
        diag["lufs"] = lufs
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
    elif resolved_mode == "NOISE_AWARE":
        peak, rms = measure_peak_rms_streaming(segment_paths)
        block_f = max(1, int(0.100 * rate))
        block_rmss = sorted(measure_block_rms_streaming(segment_paths, block_f, subsample=4))
        gain = compute_noise_aware_gain(rms, peak, block_rmss)
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
        if block_rmss:
            p10_idx = min(max(0, int(len(block_rmss) * 0.10)), len(block_rmss) - 1)
            nf = block_rmss[p10_idx]
            diag["noise_floor_db"] = _norm_linear_to_db(nf) if nf > 1e-9 else float("-inf")
    elif resolved_mode in _BASE_MODE_TARGET_RMS:
        peak, rms = measure_peak_rms_streaming(segment_paths)
        gain = compute_rms_gain(rms, peak, _BASE_MODE_TARGET_RMS[resolved_mode])
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")
    else:
        peak = measure_peak_streaming(segment_paths)
        gain = compute_peak_simple_gain(peak)
        diag["peak_db"] = _norm_linear_to_db(peak) if peak > 1e-9 else float("-inf")

    gain_db = _norm_linear_to_db(gain) if gain > 1e-12 else float("-inf")
    diag["gain_db"] = gain_db
    if diag["peak_db"] != float("-inf") and gain_db != float("-inf"):
        diag["true_peak_db"] = diag["peak_db"] + gain_db
    return ("scalar", gain), diag


def export_resolved_mode_with_stats(segment_paths, encoder_cls, final_path: str,
                                    resolved_mode: str, rate: int,
                                    encoder_kwargs: dict | None = None,
                                    apply_soft_limiter: bool = True,
                                    soft_limiter_ceiling_db: float = -0.2,
                                    block_frames: int = DEFAULT_BLOCK_FRAMES):
    """Variante de `export_resolved_mode()` (`lorito_normalization_
    streaming.py`) que ADEMÁS devuelve el dict de diagnósticos con la
    forma del camino legado — ver docstring del módulo. Mismo
    resultado de exportación que `export_resolved_mode()` con los
    mismos argumentos (verificado con ejecución real: mismo
    `frames_in`/`frames_out`/`sha256`).

    Devuelve `(report: ExportSessionReport, stats: dict)`.
    """
    encode_info, diag = _resolve_gain_and_diagnostics(segment_paths, resolved_mode, rate)

    if encode_info[0] == "adaptive_block":
        _tag, block_gains, block_f = encode_info
        provider_probe = SegmentProvider(segment_paths)
        total_frames = provider_probe.total_frames
        # Mismos defaults de crossfade que `export_adaptive_block()`
        # (importados vía `lorito_normalization_streaming` para no
        # duplicar la constante).
        from lorito_aldhiro.backend.export_streaming.lorito_normalization_streaming import (
            NORM_BLOCK_XFADE_FRAMES,
        )
        transform = _adaptive_block_transform(
            block_gains, block_f, NORM_BLOCK_XFADE_FRAMES, total_frames)
        report = export_with_block_transform(
            segment_paths, encoder_cls, final_path, transform,
            encoder_kwargs, block_frames)
        return report, diag

    _tag, gain = encode_info
    if apply_soft_limiter and measure_soft_limiter_needed(segment_paths, soft_limiter_ceiling_db):
        transform = compose_transforms(
            _gain_block_transform(gain),
            make_soft_limiter_transform(ceiling_db=soft_limiter_ceiling_db),
        )
        report = export_with_block_transform(
            segment_paths, encoder_cls, final_path, transform,
            encoder_kwargs, block_frames)
    else:
        report = export_with_scalar_gain(
            segment_paths, encoder_cls, final_path, gain,
            encoder_kwargs, block_frames)
    return report, diag


def export_mid_side_with_stats(segment_paths, encoder_cls, final_path: str,
                               rate: int, encoder_kwargs: dict | None = None,
                               ms_target_rms_db: float = -18.0,
                               max_side_gain_db: float = 6.0,
                               max_stereo_balance_index: float = 0.70,
                               block_frames: int = DEFAULT_BLOCK_FRAMES):
    """Variante de `export_with_mid_side_gain()` que además devuelve
    el dict de diagnósticos MID_SIDE — mismas claves extra que el
    camino legado (`_norm_mid_side`): `"mid_rms"`/`"side_rms"`
    (dBFS)/`"stereo_balance_index"`.

    Devuelve `(report: ExportSessionReport, stats: dict)`.
    """
    diag = _base_diagnostics("MID_SIDE")
    mid_rms, side_rms = measure_mid_side_streaming(segment_paths, block_frames)
    mid_gain, side_gain = compute_mid_side_gains(
        mid_rms, side_rms, ms_target_rms_db, max_side_gain_db, max_stereo_balance_index)

    diag["mid_rms"] = _norm_linear_to_db(mid_rms) if mid_rms > 1e-9 else float("-inf")
    diag["side_rms"] = _norm_linear_to_db(side_rms) if side_rms > 1e-9 else float("-inf")
    mid_rms_post = mid_rms * mid_gain
    side_rms_post = side_rms * side_gain
    denom_post = mid_rms_post + side_rms_post
    diag["stereo_balance_index"] = (side_rms_post / denom_post) if denom_post > 1e-9 else 0.0
    diag["gain_db"] = _norm_linear_to_db(mid_gain) if mid_gain > 1e-12 else float("-inf")
    diag["peak_db"] = diag["mid_rms"]  # aproximación informativa — MID_SIDE no mide peak global aquí

    report = export_with_mid_side_gain(
        segment_paths, encoder_cls, final_path, mid_gain, side_gain,
        encoder_kwargs, block_frames)
    return report, diag


def apply_normalization_stats_to_status(status, stats: dict) -> None:
    """Copia `stats` (con la forma producida por las funciones de
    este módulo, o por el camino legado `_apply_normalization_
    advanced`) a los atributos `_status` (`.normalization_*`) — MISMO
    bloque de asignación, con los MISMOS defaults por clave ausente,
    que `lorito_mw_export.py` (líneas ~379-395) ya ejecuta hoy con
    `stats` de origen legado. Extraído aquí como función reutilizable
    para que cablear el camino streaming a producción (bloqueado hoy
    solo por la ausencia de PySide6 ejecutable en este sandbox) sea
    una única llamada, sin reescribir ese bloque.

    `status` es cualquier objeto con esos atributos ya inicializados
    (en producción, el singleton `_status`/`BackendStatus` de
    `lorito_audio_backend.py`) — esta función no importa ese módulo
    para no acoplar el backend de exportación a la instancia global.
    """
    status.normalization_mode = stats.get("mode", "")
    status.normalization_gain_db = stats.get("gain_db", 0.0)
    status.normalization_peak_db = stats.get("peak_db", 0.0)
    status.normalization_lufs = stats.get("lufs", float("-inf"))
    status.normalization_noise_floor_db = stats.get("noise_floor_db", float("-inf"))
    status.normalization_true_peak_db = stats.get("true_peak_db", 0.0)
    status.normalization_stats = stats
    status.normalization_pre_gain_db = stats.get("pre_normalization_gain_db", 0.0)
    status.normalization_post_gain_db = stats.get("post_normalization_gain_db", 0.0)
    status.normalization_mid_rms = stats.get("mid_rms", float("-inf"))
    status.normalization_side_rms = stats.get("side_rms", float("-inf"))
    status.normalization_stereo_balance = stats.get("stereo_balance_index", 0.0)
    status.normalization_crest_factor_db = stats.get("crest_factor_db", float("inf"))
    status.normalization_dynamic_range = stats.get("dynamic_range_estimate", 0.0)
    status.normalization_histogram_density = stats.get("histogram_peak_density", 0.0)
    status.normalization_silence_ratio = stats.get("silence_ratio", 0.0)
    status.normalization_auto_mode = stats.get("auto_selected_mode", "")
