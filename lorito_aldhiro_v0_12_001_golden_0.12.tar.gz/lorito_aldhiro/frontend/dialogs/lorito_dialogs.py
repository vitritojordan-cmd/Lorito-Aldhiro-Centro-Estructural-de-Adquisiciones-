from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Diálogos de la aplicación (bienvenida, cierre abrupto, recuperación de crash).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from lorito_aldhiro.backend.core.lorito_version import APP_BRAND
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QGridLayout, QLineEdit, QFileDialog,
                               QFrame)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF



# ─────────────────────────────────────────────────────────────────────────────
#  VENTANA PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

# ── Diálogo de bienvenida — primera apertura limpia ──────────────────────────
class CarolaBienvenidaDialog(QDialog):
    """
    Diálogo de bienvenida que aparece ÚNICAMENTE en el primer arranque limpio:
      · Sin crash recovery pendiente (CrashGuard.is_crash_pending() == False)
      · Sin audio en el búfer de sesión (_has_audio() == False)

    Título de barra : "{APP_BRAND} {versión}"
    Mensaje         : "BIENVENIDO, CAMPEÓN! ¿Hora de transdigitalizar?"  (rosa intenso)
    Botón           : "Claro, como no!"  → cierra el diálogo
    Ni Escape ni la X de la ventana cierran el diálogo; solo el botón.
    """

    def __init__(self, version: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{APP_BRAND} {version}")
        self.setWindowFlags(
            Qt.Dialog
            | Qt.WindowTitleHint
# Tamaño fijo garantizado por setFixedSize() / self.adjustSize().
        )
        self.setModal(True)

        self.setStyleSheet("""
            QDialog {
                background-color: #0e0e0e;
                border: 1px solid #882255;
            }
            QLabel#lbl_msg {
                color: rgb(255, 20, 147);
                font-family:'Exo 2';
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 1px;
                qproperty-alignment: AlignCenter;
            }
            QPushButton#btn_claro {
                background-color: #1a0010;
                color: rgb(255, 20, 147);
                border: 1px solid #882255;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 2px;
                padding: 6px 26px;
                min-width: 130px;
            }
            QPushButton#btn_claro:hover {
                background-color: #330020;
                border-color: rgb(255, 20, 147);
                color: rgb(255, 80, 170);
            }
            QPushButton#btn_claro:pressed {
                background-color: #0a0008;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(40, 28, 40, 22)
        root.setSpacing(0)

        lbl = QLabel("BIENVENIDO, CAMPEÓN! ¿Hora de transdigitalizar?")
        lbl.setObjectName("lbl_msg")
        lbl.setWordWrap(False)
        root.addWidget(lbl)

        root.addSpacerItem(QSpacerItem(0, 20, QSizePolicy.Minimum, QSizePolicy.Fixed))

        fila = QHBoxLayout()
        fila.setSpacing(0)
        fila.addStretch()

        btn = QPushButton("Claro, como no!")
        btn.setObjectName("btn_claro")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(self.accept)
        fila.addWidget(btn)

        fila.addStretch()
        root.addLayout(fila)

        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            return   # Escape no cierra — solo el botón
        super().keyPressEvent(event)

    def closeEvent(self, event):
        event.ignore()   # La X tampoco cierra


# ── Diálogo de cierre con grabación activa ────────────────────────────────────
class CarolaNooDialog(QDialog):
    """
    Diálogo de advertencia que aparece cuando el usuario intenta cerrar la
    ventana mientras el engine está grabando, en pausa (manual o automática)
    o vaciando el búfer al disco.
    Título de barra: "ADVERTENCIA CRAC"
    Mensaje: "LORITO DICE: Nooooooo!!!!!! Eso no se hace!!!!! 😜"
    Botón:   "Ya fue ya"  → cierra el diálogo y devuelve control a la app.
    Ni Escape ni la X de la ventana cierran el diálogo; solo el botón.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ADVERTENCIA CRAC")
        self.setWindowFlags(
            Qt.Dialog
            | Qt.WindowTitleHint
# Tamaño fijo garantizado por setFixedSize() / self.adjustSize().
        )
        self.setModal(True)

        self.setStyleSheet("""
            QDialog {
                background-color: #0e0e0e;
                border: 1px solid #555;
            }
            QLabel#msg {
                color: #ffcc00;
                font-family:'Exo 2';
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 1px;
                qproperty-alignment: AlignCenter;
            }
            QPushButton#btn_yafue {
                background-color: #1a1000;
                color: #ffcc00;
                border: 1px solid #aa8800;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 2px;
                padding: 6px 26px;
                min-width: 90px;
            }
            QPushButton#btn_yafue:hover {
                background-color: #332200;
                border-color: #ffcc00;
                color: #ffe066;
            }
            QPushButton#btn_yafue:pressed {
                background-color: #0a0800;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(36, 24, 36, 20)
        root.setSpacing(0)

        lbl = QLabel("LORITO DICE: Nooooooo!!!!!! Eso no se hace!!!!! 😜")
        lbl.setObjectName("msg")
        lbl.setWordWrap(False)
        root.addWidget(lbl)

        root.addSpacerItem(QSpacerItem(0, 18, QSizePolicy.Minimum, QSizePolicy.Fixed))

        fila = QHBoxLayout()
        fila.setSpacing(0)
        fila.addStretch()

        btn = QPushButton("Ya fue ya")
        btn.setObjectName("btn_yafue")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(self.accept)
        fila.addWidget(btn)

        fila.addStretch()
        root.addLayout(fila)

        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            return   # Escape no cierra — solo el botón
        super().keyPressEvent(event)

    def closeEvent(self, event):
        event.ignore()   # La X tampoco cierra


class CracSaveDialog(QDialog):
    """
    Diálogo modal que aparece mientras se exporta el archivo de audio.
    Muestra:
      · Leyenda del codec con su color canónico (idéntico al StatusDisplay)
      · Línea de normalización en celeste intenso (solo si hay perfil activo)
      · Barra de progreso que avanza de 0 % a 100 %
    Al llegar al 100 % se cierra automáticamente.

    Uso:
        dlg = CracSaveDialog(codec, norm_val, parent)
        dlg.show()               # no bloqueante
        dlg.set_progress(pct)    # 0..100; cierra solo al llegar a 100
    """

    # Tabla codec → (texto leyenda, QColor texto, hex borde)
    _CODEC_INFO = {
        "WAV":  ("LORITO EXPORTANDO ARCHIVO WAV",            QColor(255, 255, 255, 240), "#888888"),
        "FLAC": ("LORITO EXPORTANDO ARCHIVO FLAC",           QColor(  0, 210, 200, 240), "#00cfc8"),
        "OGG":  ("LORITO EXPORTANDO ARCHIVO OGG Vorbis",     QColor(188, 143,  94, 240), "#bc8f5e"),
        "WV":   ("LORITO EXPORTANDO ARCHIVO WavePack",       QColor(210, 215, 220, 240), "#c0c8cc"),
    }

    # Celeste intenso canónico — mismo que export_cyan / carolamotion_rev en StatusDisplay
    _NORM_COLOR = "rgb(0, 210, 235)"

    def __init__(self, codec: str, norm_val: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CRAC Save")
        self.setWindowFlags(
            Qt.Dialog
            | Qt.WindowTitleHint
# Tamaño fijo garantizado por setFixedSize() / self.adjustSize().
        )
        self.setModal(True)

        label_text, txt_color, border_hex = self._CODEC_INFO.get(
            codec,
            (f"LORITO EXPORTANDO ARCHIVO {codec}", QColor(255, 255, 255, 240), "#888888"),
        )

        # Color CSS para texto de codec y barra
        _r, _g, _b = txt_color.red(), txt_color.green(), txt_color.blue()
        _css_color = f"rgb({_r},{_g},{_b})"

        # Determinar si hay normalización activa
        _con_norm = (norm_val and norm_val != "Sin normalizar")

        self.setStyleSheet(f"""
            QDialog {{
                background-color: #0e0e0e;
                border: 1px solid {border_hex};
            }}
            QLabel#lbl_codec {{
                color: {_css_color};
                font-family:'Exo 2';
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 1px;
                qproperty-alignment: AlignCenter;
            }}
            QLabel#lbl_norm {{
                color: {self._NORM_COLOR};
                font-family:'Exo 2';
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 1px;
                qproperty-alignment: AlignCenter;
            }}
            QProgressBar {{
                background-color: #1a1a1a;
                border: 1px solid {border_hex};
                border-radius: 3px;
                text-align: center;
                color: {_css_color};
                font-family:'Exo 2';
                font-size: 9px;
                font-weight: 700;
                min-height: 14px;
            }}
            QProgressBar::chunk {{
                background-color: {_css_color};
                border-radius: 2px;
            }}
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(36, 24, 36, 20)
        root.setSpacing(8)

        # ── Leyenda del codec ─────────────────────────────────────────────────
        lbl_codec = QLabel(label_text)
        lbl_codec.setObjectName("lbl_codec")
        lbl_codec.setWordWrap(False)
        root.addWidget(lbl_codec)

        # ── Leyenda de normalización (solo si hay perfil activo) ──────────────
        if _con_norm:
            lbl_norm = QLabel(f"LORITO COMBINA CON NORMALIZADO {norm_val}")
            lbl_norm.setObjectName("lbl_norm")
            lbl_norm.setWordWrap(False)
            lbl_norm.setStyleSheet("color: #F5F0DC;")   # beige
            root.addWidget(lbl_norm)

        root.addSpacerItem(QSpacerItem(0, 6, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # ── Barra de progreso ─────────────────────────────────────────────────
        self._bar = QProgressBar()
        self._bar.setRange(0, 100)
        self._bar.setValue(0)
        self._bar.setTextVisible(True)
        self._bar.setFormat("%p%")
        self._bar.setFixedWidth(320)
        root.addWidget(self._bar, alignment=Qt.AlignHCenter)

        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    def set_progress(self, pct: int):
        """Actualiza la barra. Si pct >= 100 cierra el diálogo automáticamente."""
        pct = max(0, min(100, pct))
        self._bar.setValue(pct)
        if pct >= 100:
            QTimer.singleShot(120, self.accept)   # breve pausa visual antes de cerrar

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            return   # Escape no cierra durante el export
        super().keyPressEvent(event)

    def closeEvent(self, event):
        # Solo permite el cierre programático (vía accept/done), no manual
        if self._bar.value() < 100:
            event.ignore()
        else:
            super().closeEvent(event)


class CierreAbruptoDialog(QDialog):
    """
    Cuadro de diálogo que aparece al intentar cerrar Lorito Aldhiro cuando hay señal
    capturada en el sistema.  Ofrece dos opciones:
      · Sí  — cerrar sin guardar (descartar la grabación).
      · No  — guardar la grabación en ese instante y luego cerrar.
    """
    # Resultado de la elección del usuario
    DESCARTAR = 0   # "Sí" — cerrar sin guardar
    GUARDAR   = 1   # "No" — guardar y cerrar

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CIERRE ABRUPTO DE CRAC")
        self.setWindowFlags(
            Qt.Dialog
            | Qt.WindowTitleHint
            | Qt.WindowCloseButtonHint
# Tamaño fijo garantizado por setFixedSize() / self.adjustSize().
        )
        self.setModal(True)
        self._resultado = None   # se rellena al pulsar un botón

        # ── Estilo global del diálogo ─────────────────────────────────────────
        self.setStyleSheet("""
            QDialog {
                background-color: #0e0e0e;
                border: 1px solid #333;
            }
            QLabel#titulo {
                color: #ffffff;
                font-family:'Exo 2';
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 3px;
                qproperty-alignment: AlignCenter;
            }
            QLabel#cuerpo {
                color: #cccccc;
                font-family:'Exo 2';
                font-size: 10px;
                qproperty-alignment: AlignCenter;
            }
            QPushButton#btn_si {
                background-color: #2a0000;
                color: #ff4444;
                border: 1px solid #aa2222;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 2px;
                padding: 6px 22px;
                min-width: 80px;
            }
            QPushButton#btn_si:hover {
                background-color: #550000;
                border-color: #ff4444;
                color: #ff6666;
            }
            QPushButton#btn_si:pressed {
                background-color: #110000;
            }
            QPushButton#btn_no {
                background-color: #001a00;
                color: #44cc44;
                border: 1px solid #227722;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 2px;
                padding: 6px 22px;
                min-width: 80px;
            }
            QPushButton#btn_no:hover {
                background-color: #003300;
                border-color: #44cc44;
                color: #66ee66;
            }
            QPushButton#btn_no:pressed {
                background-color: #000a00;
            }
        """)

        # ── Layout principal ──────────────────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 18)
        root.setSpacing(0)

        # Título interior
        lbl_titulo = QLabel("LORITO PREGUNTA")
        lbl_titulo.setObjectName("titulo")
        root.addWidget(lbl_titulo)

        root.addSpacerItem(QSpacerItem(0, 14, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Mensaje
        lbl_cuerpo = QLabel(
            "¿Deseas deshacerte de lo que con esfuerzo\n"
            "y dedicación capturaste?"
        )
        lbl_cuerpo.setObjectName("cuerpo")
        lbl_cuerpo.setWordWrap(False)
        root.addWidget(lbl_cuerpo)

        root.addSpacerItem(QSpacerItem(0, 20, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Fila de botones
        fila = QHBoxLayout()
        fila.setSpacing(12)

        btn_si = QPushButton("SÍ")
        btn_si.setObjectName("btn_si")
        btn_si.setCursor(Qt.PointingHandCursor)
        btn_si.clicked.connect(self._on_si)
        fila.addWidget(btn_si)

        btn_no = QPushButton("NO")
        btn_no.setObjectName("btn_no")
        btn_no.setCursor(Qt.PointingHandCursor)
        btn_no.clicked.connect(self._on_no)
        fila.addWidget(btn_no)

        root.addLayout(fila)
        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _on_si(self):
        """Sí = cerrar sin guardar."""
        self._resultado = self.DESCARTAR
        self.accept()

    def _on_no(self):
        """No = guardar y cerrar."""
        self._resultado = self.GUARDAR
        self.accept()

    def resultado(self):
        """Devuelve DESCARTAR o GUARDAR según la elección del usuario."""
        return self._resultado

    # Impedir cierre accidental con Escape (que equivaldría a cancelar)
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            return   # ignorar Escape — el usuario debe elegir explícitamente
        super().keyPressEvent(event)


# ── Diálogo de bienvenida con información patrimonial ────────────────────────
class CracInformacionPatrimonialDialog(QDialog):
    """
    Cuadro de diálogo que aparece al abrir Lorito Aldhiro cuando se detecta audio
    previamente guardado en el directorio de archivo.
    El usuario solo puede pulsar "Ingresar y Continuar" para proceder.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CRAC CON INFORMACION PATRIMONIAL")
        self.setWindowFlags(
            Qt.Dialog
            | Qt.WindowTitleHint
            | Qt.WindowCloseButtonHint
# Tamaño fijo garantizado por setFixedSize() / self.adjustSize().
        )
        self.setModal(True)

        # ── Estilo global del diálogo ─────────────────────────────────────────
        self.setStyleSheet("""
            QDialog {
                background-color: #0e0e0e;
                border: 1px solid #333;
            }
            QLabel#titulo {
                color: #ffffff;
                font-family:'Exo 2';
                font-size: 12px;
                font-weight: 700;
                letter-spacing: 3px;
                qproperty-alignment: AlignCenter;
            }
            QLabel#cuerpo {
                color: #cccccc;
                font-family:'Exo 2';
                font-size: 10px;
                qproperty-alignment: AlignCenter;
                line-height: 1.5;
            }
            QPushButton#btn_ingresar {
                background-color: #001a08;
                color: #44ee88;
                border: 1px solid #228844;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 2px;
                padding: 7px 28px;
                min-width: 160px;
            }
            QPushButton#btn_ingresar:hover {
                background-color: #003318;
                border-color: #44ee88;
                color: #77ffaa;
            }
            QPushButton#btn_ingresar:pressed {
                background-color: #000d04;
            }
        """)

        # ── Layout principal ──────────────────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(36, 24, 36, 20)
        root.setSpacing(0)

        # Título interior
        lbl_titulo = QLabel("LORITO FELIZ!")
        lbl_titulo.setObjectName("titulo")
        root.addWidget(lbl_titulo)

        root.addSpacerItem(QSpacerItem(0, 14, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Mensaje
        lbl_cuerpo = QLabel(
            "Hurra!!! Tu archivo se encuentra integro,\n"
            "solución inteligente eh?"
        )
        lbl_cuerpo.setObjectName("cuerpo")
        lbl_cuerpo.setWordWrap(False)
        root.addWidget(lbl_cuerpo)

        root.addSpacerItem(QSpacerItem(0, 22, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Botón centrado
        fila = QHBoxLayout()
        fila.setSpacing(0)
        fila.addStretch()

        btn = QPushButton("Ingresar y Continuar")
        btn.setObjectName("btn_ingresar")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(self.accept)
        fila.addWidget(btn)

        fila.addStretch()
        root.addLayout(fila)

        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    # Escape no cierra — el usuario debe pulsar el botón
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            return
        super().keyPressEvent(event)

    # La X de la ventana tampoco cierra — misma lógica
    def closeEvent(self, event):
        event.ignore()


# ── Diálogo de recuperación de crash ─────────────────────────────────────────
class CracRecuperandoDatClamitDialog(QDialog):
    """
    Cuadro de diálogo que aparece al detectar un crash de sesión anterior.
    Muestra la duración del audio recuperable y ofrece dos opciones:
      · NO PASA NADA     — descartar el archivo recuperado
      · ESPERA!! LO QUIERO — mantener / recuperar el archivo
    """
    DESCARTAR = 0
    RECUPERAR = 1

    def __init__(self, dur_hms: str, parent=None):
        """
        dur_hms — cadena de duración formateada, p.ej. "00:31:04",
                  o "desconocida" si no está disponible.
        """
        super().__init__(parent)
        self.setWindowTitle("CRAC RECUPERANDO DAT CLAMIT EN COLA")
        self.setWindowFlags(
            Qt.Dialog
            | Qt.WindowTitleHint
            | Qt.WindowCloseButtonHint
# Tamaño fijo garantizado por setFixedSize() / self.adjustSize().
        )
        self.setModal(True)
        self._resultado = None

        self.setStyleSheet("""
            QDialog {
                background-color: #0e0e0e;
                border: 1px solid #333;
            }
            QLabel#titulo {
                color: #ffffff;
                font-family:'Exo 2';
                font-size: 12px;
                font-weight: 700;
                letter-spacing: 3px;
                qproperty-alignment: AlignCenter;
            }
            QLabel#cuerpo {
                color: #cccccc;
                font-family:'Exo 2';
                font-size: 10px;
                qproperty-alignment: AlignCenter;
            }
            QLabel#duracion {
                color: #ffdd44;
                font-family: 'Courier New', Courier, monospace;
                font-size: 14px;
                font-weight: 700;
                letter-spacing: 2px;
                qproperty-alignment: AlignCenter;
            }
            QPushButton#btn_descartar {
                background-color: #1a0a00;
                color: #ff8844;
                border: 1px solid #994422;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 9px;
                font-weight: 700;
                letter-spacing: 1px;
                padding: 7px 16px;
                min-width: 130px;
            }
            QPushButton#btn_descartar:hover {
                background-color: #331500;
                border-color: #ff8844;
                color: #ffaa66;
            }
            QPushButton#btn_descartar:pressed {
                background-color: #0d0500;
            }
            QPushButton#btn_recuperar {
                background-color: #001a0d;
                color: #44ee88;
                border: 1px solid #228844;
                border-radius: 4px;
                font-family:'Exo 2';
                font-size: 9px;
                font-weight: 700;
                letter-spacing: 1px;
                padding: 7px 16px;
                min-width: 130px;
            }
            QPushButton#btn_recuperar:hover {
                background-color: #003318;
                border-color: #44ee88;
                color: #77ffaa;
            }
            QPushButton#btn_recuperar:pressed {
                background-color: #000d06;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(32, 22, 32, 20)
        root.setSpacing(0)

        # Título interior
        lbl_titulo = QLabel("LORITO TRANQUILIZADO")
        lbl_titulo.setObjectName("titulo")
        root.addWidget(lbl_titulo)

        root.addSpacerItem(QSpacerItem(0, 14, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Mensaje principal
        lbl_cuerpo = QLabel(
            "Ufff!!! Eso estuvo cerca, por poco y pierdes\n"
            "documento valioso, te salvaste de una\n"
            "reprendida de Aldhira y yo\n"
            "¿Que quieres hacer ahora? Mira"
        )
        lbl_cuerpo.setObjectName("cuerpo")
        lbl_cuerpo.setWordWrap(False)
        root.addWidget(lbl_cuerpo)

        root.addSpacerItem(QSpacerItem(0, 10, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Duración — destacada
        lbl_dur = QLabel(dur_hms)
        lbl_dur.setObjectName("duracion")
        root.addWidget(lbl_dur)

        root.addSpacerItem(QSpacerItem(0, 6, QSizePolicy.Minimum, QSizePolicy.Fixed))

        lbl_pie = QLabel("todo lo que hay para salvar")
        lbl_pie.setObjectName("cuerpo")
        root.addWidget(lbl_pie)

        root.addSpacerItem(QSpacerItem(0, 22, QSizePolicy.Minimum, QSizePolicy.Fixed))

        # Fila de botones
        fila = QHBoxLayout()
        fila.setSpacing(12)

        btn_no = QPushButton("NO PASA NADA")
        btn_no.setObjectName("btn_descartar")
        btn_no.setCursor(Qt.PointingHandCursor)
        btn_no.clicked.connect(self._on_descartar)
        fila.addWidget(btn_no)

        btn_si = QPushButton("ESPERA!! LO QUIERO")
        btn_si.setObjectName("btn_recuperar")
        btn_si.setCursor(Qt.PointingHandCursor)
        btn_si.clicked.connect(self._on_recuperar)
        fila.addWidget(btn_si)

        root.addLayout(fila)
        self.adjustSize()
        self.setFixedSize(self.sizeHint())

    def _on_descartar(self):
        self._resultado = self.DESCARTAR
        self.accept()

    def _on_recuperar(self):
        self._resultado = self.RECUPERAR
        self.accept()

    def resultado(self):
        return self._resultado

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            return
        super().keyPressEvent(event)

    def closeEvent(self, event):
        # Permitir cierre con la X solo si ya se tomó una decisión
        if self._resultado is not None:
            event.accept()
        else:
            event.ignore()

# ═══════════════════════════════════════════════════════════════════════════
#  LORITO EXPORTADOR (§GAP-017) — réplica completa del panel de
#  exportación de modo MANUAL de CRAC (CarolaExportadoraDialog /
#  CarolaExportadoraManualDialog, auditado en `_export_dialogs.py`),
#  renombrado. Estructura de dos columnas fiel al original: columna
#  izquierda con las 4 secciones reales (FORMATO DE EXPORTACIÓN,
#  NORMALIZACIÓN básica, NORMALIZACIÓN AVANZADA, PERFIL DE CINTA/
#  PRESET — las tres normalizaciones con exclusión mutua real, igual
#  que CRAC), columna derecha con INFORMACIÓN DEL PERFIL + DIRECTORIO
#  DE SALIDA + INICIAR/ABORTAR. El bloque BACKEND DE AUDIO/FRECUENCIA
#  DE CAPTURA de CRAC es EXCLUSIVO de sus modos AUTO/TTNEADO
#  (`show_auto_extras`, confirmado en el propio código de CRAC,
#  comentario "FIX-MANUAL-SIN-EXTRAS") — Lorito Aldhiro no tiene esos
#  modos, así que nunca aplica aquí; esos parámetros (HOST/MUESTRA/
#  BITDEPH) ya se eligen en la barra de menú principal antes de abrir
#  este diálogo, igual que en CRAC.
#
#  Mismo mecanismo real que CRAC: NO duplica los combos de códec/
#  profundidad — los REPARENTA (Qt reasigna el padre automáticamente al
#  agregarlos a un layout nuevo) desde LoritoAldhiroStudio, así que la
#  lógica ya wireada (`_update_codec_ui`) sigue funcionando sin
#  reimplementarla. Los tres combos de normalización SÍ son nuevos
#  (widgets propios del diálogo, no reparentados) porque CRAC los
#  separa visualmente en 3 secciones mientras Lorito Aldhiro los tenía
#  fusionados en un único `norm_box` — se construyen aquí a partir de
#  los mismos enums reales (`NormalizationMode`/`NormalizationModeV21`)
#  que ya alimentan ese `norm_box`, con la MISMA lógica de exclusión
#  mutua de CRAC (`_on_basic_norm_changed`/`_on_adv_norm_changed`/
#  `_on_tape_norm_changed`), y al confirmar (INICIAR) el resultado se
#  escribe de vuelta en `studio.norm_box` — un único punto de verdad,
#  igual que antes.
#
#  Sin CabeceraWidget (asset PNG propio de CRAC que Lorito Aldhiro no
#  tiene) — título de texto en su lugar. Sin sub-diálogo de "OPCIONES
#  AVANZADAS" por códec (`CracCodecAdvancedDialog` de CRAC) — pendiente,
#  ver GAP-017 §4.
# ═══════════════════════════════════════════════════════════════════════════

from lorito_aldhiro.backend.audio.lorito_audio_backend import NormalizationMode
from lorito_aldhiro.backend.export.lorito_normalization_common import NormalizationModeV21


class LoritoExportadorDialog(QDialog):
    """
    Diálogo modal que se despliega al pulsar el botón "SALIDA" (antes
    "CRACS"/INICIAR de CRAC) en la interfaz principal.

    Título de barra de ventana e interior: "LORITO EXPORTADOR" (antes
    "CRAC Aldhira Exportador"/"Carola Exportadora Manual").
    Dimensiones: 860×560 (CRAC usa 960×672, incluyendo cabecera PNG que
    Lorito Aldhiro no tiene — ver GAP-017 §3).
    """

    DLG_W = 860
    DLG_H = 560
    COL_L = 380

    export_requested = Signal()

    _PLACEHOLDER = "— sin seleccionar —"

    # Modos avanzados (v0.20) — idénticos, por valor, a los últimos 3
    # miembros de NormalizationMode (Mid/Side, Crest Guard, Auto) — la
    # misma separación que hace CRAC (`_ADV_NORM_MODES`), aquí derivada
    # de un enum real en vez de una lista aparte a mano.
    _ADV_NORM_VALUES = {
        NormalizationMode.MID_SIDE.value,
        NormalizationMode.CREST_GUARD.value,
        NormalizationMode.AUTO.value,
    }

    _BG, _BORDER, _ACCENT, _CYAN = "#0d0d0d", "#C9A84C", "#C9A84C", "#B87333"
    _GOLD, _TEXT, _DIM = "#C0C0C0", "#B0B0B0", "#555555"
    _INPUT, _INPUT_BD, _SEP = "#1a1a1a", "#3a3a3a", "#2a2a2a"
    _PANEL, _PANEL_BD = "#141414", "#3a3a3a"
    _OK_BG, _OK_FG, _OK_BD = "#001a08", "#44ee88", "#228844"
    _CAN_BG, _CAN_FG, _CAN_BD = "#1a0010", "rgb(255, 20, 147)", "#882255"

    def __init__(self, studio, parent=None):
        super().__init__(parent)
        self.studio = studio
        self.setWindowTitle("LORITO EXPORTADOR")
        self.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
        self.setModal(True)
        self.setFixedSize(self.DLG_W, self.DLG_H)

        self.setStyleSheet(f"""
            QDialog {{ background-color:{self._BG}; border:1px solid {self._BORDER}; }}
            QLabel#lbl_title {{
                color:{self._ACCENT}; font-family:'Exo 2'; font-size:14px;
                font-weight:700; letter-spacing:4px; qproperty-alignment:AlignCenter;
            }}
            QLabel.sec_hdr {{
                color:{self._CYAN}; font-family:'Exo 2'; font-size:9px;
                font-weight:700; letter-spacing:2px;
            }}
            QLabel.sec_hdr_adv {{ color:{self._GOLD}; }}
            QLabel.sec_hdr_tape {{ color:#D4AF37; }}
            QLabel.col_hdr {{
                color:{self._TEXT}; font-family:'Exo 2'; font-size:8px; font-weight:600;
            }}
            QComboBox, QLineEdit {{
                background-color:{self._INPUT}; color:{self._TEXT};
                border:1px solid {self._INPUT_BD}; border-radius:7px;
                font-family:'Exo 2'; font-size:9px; padding:2px 6px; min-height:22px;
            }}
            QComboBox:hover, QLineEdit:hover {{ border-color:{self._BORDER}; }}
            QFrame#info_panel {{
                background-color:{self._PANEL}; border:1px solid {self._PANEL_BD};
                border-radius:9px;
            }}
            QLabel#info_content {{
                color:#888888; font-family:'Courier New',monospace; font-size:8px;
            }}
            QFrame#hsep {{ background-color:{self._SEP}; max-height:1px; min-height:1px; }}
            QFrame#vsep {{ background-color:{self._BORDER}; max-width:1px; min-width:1px; }}
            QPushButton#btn_lorito_iniciar {{
                background-color:{self._OK_BG}; color:{self._OK_FG}; border:1px solid {self._OK_BD};
                border-radius:10px; font-family:'Exo 2'; font-size:11px;
                font-weight:700; letter-spacing:3px; padding:9px 28px;
            }}
            QPushButton#btn_lorito_abortar {{
                background-color:{self._CAN_BG}; color:{self._CAN_FG}; border:1px solid {self._CAN_BD};
                border-radius:10px; font-family:'Exo 2'; font-size:11px;
                font-weight:700; letter-spacing:3px; padding:9px 24px;
            }}
            QPushButton#btn_lorito_browse {{
                background-color:#111111; color:{self._DIM}; border:1px solid #2a2a2a;
                border-radius:8px; font-family:'Exo 2'; font-size:8px; min-height:22px;
            }}
        """)

        self._reparented = [studio.codec_box, studio.opt1_box, studio.opt2_box,
                            studio.opt1_label, studio.opt2_label]

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 14, 20, 14)
        outer.setSpacing(10)

        title = QLabel("LORITO EXPORTADOR", self)
        title.setObjectName("lbl_title")
        outer.addWidget(title)

        root = QHBoxLayout()
        root.setSpacing(0)
        outer.addLayout(root)

        # ══ COLUMNA IZQUIERDA ═══════════════════════════════════════════
        col_left = QVBoxLayout()
        col_left.setSpacing(6)

        def _sec_hdr(text, css_class="sec_hdr"):
            l = QLabel(text, self)
            l.setProperty("class", css_class)
            color = {"sec_hdr": self._CYAN, "sec_hdr_adv": self._GOLD,
                    "sec_hdr_tape": "#D4AF37"}[css_class]
            l.setStyleSheet(
                f"color:{color};font-family:'Exo 2';font-size:9px;"
                "font-weight:700;letter-spacing:2px;")
            return l

        def _col_hdr(text):
            l = QLabel(text, self)
            l.setStyleSheet(
                f"color:{self._TEXT};font-family:'Exo 2';font-size:8px;font-weight:600;")
            return l

        def _hsep():
            f = QFrame(self); f.setObjectName("hsep"); f.setFixedHeight(1)
            return f

        # ── FORMATO DE EXPORTACIÓN ────────────────────────────────────────
        col_left.addWidget(_sec_hdr("▸  FORMATO DE EXPORTACIÓN"))
        row_hdr = QHBoxLayout()
        row_hdr.addWidget(_col_hdr("CODEC")); row_hdr.addWidget(_col_hdr("PROFUNDIDAD / CALIDAD"))
        col_left.addLayout(row_hdr)
        row_combo = QHBoxLayout()
        row_combo.addWidget(studio.codec_box); row_combo.addWidget(studio.opt1_box)
        col_left.addLayout(row_combo)
        row_opt2 = QHBoxLayout()
        row_opt2.addWidget(studio.opt2_label); row_opt2.addWidget(studio.opt2_box)
        col_left.addLayout(row_opt2)
        col_left.addWidget(_hsep())

        # ── NORMALIZACIÓN (básica) ────────────────────────────────────────
        col_left.addWidget(_sec_hdr("▸  NORMALIZACIÓN"))
        col_left.addWidget(_col_hdr("Modo básico"))
        self._norm_box = QComboBox(self)
        _adv_vals = self._ADV_NORM_VALUES
        _tape_vals = {m.value for m in NormalizationModeV21}
        for m in NormalizationMode:
            if m.value not in _adv_vals:
                self._norm_box.addItem(m.value)
        col_left.addWidget(self._norm_box)
        col_left.addWidget(_hsep())

        # ── NORMALIZACIÓN AVANZADA ────────────────────────────────────────
        col_left.addWidget(_sec_hdr("▸  NORMALIZACIÓN AVANZADA", "sec_hdr_adv"))
        col_left.addWidget(_col_hdr("Modo avanzado"))
        self._norm_adv_box = QComboBox(self)
        self._norm_adv_box.addItem(self._PLACEHOLDER)
        for v in (NormalizationMode.MID_SIDE.value, NormalizationMode.CREST_GUARD.value,
                 NormalizationMode.AUTO.value):
            self._norm_adv_box.addItem(v)
        col_left.addWidget(self._norm_adv_box)
        col_left.addWidget(_hsep())

        # ── PERFIL DE CINTA / PRESET ──────────────────────────────────────
        col_left.addWidget(_sec_hdr("▸  PERFIL DE CINTA / PRESET", "sec_hdr_tape"))
        col_left.addWidget(_col_hdr("Preset de cinta / Two-Pass / Soft-limit"))
        self._norm_tape_box = QComboBox(self)
        self._norm_tape_box.addItem(self._PLACEHOLDER)
        for m in NormalizationModeV21:
            self._norm_tape_box.addItem(m.value)
        col_left.addWidget(self._norm_tape_box)
        col_left.addStretch(1)

        # Preseleccionar según el valor actual de studio.norm_box (única
        # fuente de verdad hasta ahora) en la sección que corresponda.
        _current_norm = studio.norm_box.currentText()
        if _current_norm in _adv_vals:
            self._norm_adv_box.setCurrentText(_current_norm)
        elif _current_norm in _tape_vals:
            self._norm_tape_box.setCurrentText(_current_norm)
        else:
            idx = self._norm_box.findText(_current_norm)
            if idx >= 0:
                self._norm_box.setCurrentIndex(idx)

        # Exclusión mutua real — mismo mecanismo que CRAC.
        self._norm_box.currentTextChanged.connect(self._on_basic_norm_changed)
        self._norm_adv_box.currentTextChanged.connect(self._on_adv_norm_changed)
        self._norm_tape_box.currentTextChanged.connect(self._on_tape_norm_changed)

        left_wrapper = QWidget(self)
        left_wrapper.setFixedWidth(self.COL_L)
        left_wrapper.setLayout(col_left)
        root.addWidget(left_wrapper)

        vsep = QFrame(self); vsep.setObjectName("vsep"); vsep.setFixedWidth(1)
        root.addSpacerItem(QSpacerItem(16, 0, QSizePolicy.Fixed, QSizePolicy.Minimum))
        root.addWidget(vsep)
        root.addSpacerItem(QSpacerItem(16, 0, QSizePolicy.Fixed, QSizePolicy.Minimum))

        # ══ COLUMNA DERECHA ═════════════════════════════════════════════
        col_right = QVBoxLayout()
        col_right.setSpacing(8)

        col_right.addWidget(_sec_hdr("▸  INFORMACIÓN DEL PERFIL", "sec_hdr"))
        panel_frame = QFrame(self); panel_frame.setObjectName("info_panel")
        panel_lay = QVBoxLayout(panel_frame)
        panel_lay.setContentsMargins(12, 10, 12, 10)
        self._info_label = QLabel("—", self)
        self._info_label.setObjectName("info_content")
        self._info_label.setWordWrap(True)
        self._info_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        panel_lay.addWidget(self._info_label)
        col_right.addWidget(panel_frame, 1)

        col_right.addWidget(_hsep())
        col_right.addWidget(_sec_hdr("▸  DIRECTORIO DE SALIDA"))
        row_dir = QHBoxLayout()
        self.dir_edit = QLineEdit(getattr(studio, "_export_output_dir", "") or "", self)
        self.dir_edit.setPlaceholderText("DIRECTORIO DE EXPORTACIÓN…")
        row_dir.addWidget(self.dir_edit, 1)
        btn_browse = QPushButton("EXAMINAR", self)
        btn_browse.setObjectName("btn_lorito_browse")
        btn_browse.setFixedWidth(78)
        btn_browse.clicked.connect(self._browse)
        row_dir.addWidget(btn_browse)
        col_right.addLayout(row_dir)

        # NOTA (§GAP-017 §3): el bloque "BACKEND DE AUDIO"/"FRECUENCIA DE
        # CAPTURA" de CRAC es EXCLUSIVO de sus modos AUTO/TTNEADO
        # (show_auto_extras) — Lorito Aldhiro no los tiene, así que nunca
        # aplica aquí; HOST/MUESTRA/BITDEPH ya se eligen en la barra de
        # menú principal antes de abrir este diálogo, igual que CRAC en
        # modo MANUAL.

        col_right.addStretch(1)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.btn_iniciar = QPushButton("INICIAR", self)
        self.btn_iniciar.setObjectName("btn_lorito_iniciar")
        self.btn_iniciar.clicked.connect(self._on_iniciar)
        self.btn_abortar = QPushButton("ABORTAR", self)
        self.btn_abortar.setObjectName("btn_lorito_abortar")
        self.btn_abortar.clicked.connect(self.reject)
        btn_row.addWidget(self.btn_iniciar)
        btn_row.addWidget(self.btn_abortar)
        col_right.addLayout(btn_row)

        root.addLayout(col_right)

        for w in self._reparented:
            w.setVisible(True)

        self._refresh_info_panel()

    # ── Exclusión mutua de normalización (idéntico mecanismo a CRAC) ──────
    def _on_basic_norm_changed(self, text: str):
        if text and text != "Sin normalizar":
            self._norm_adv_box.blockSignals(True); self._norm_adv_box.setCurrentIndex(0)
            self._norm_adv_box.blockSignals(False)
            self._norm_tape_box.blockSignals(True); self._norm_tape_box.setCurrentIndex(0)
            self._norm_tape_box.blockSignals(False)
        self._refresh_info_panel()

    def _on_adv_norm_changed(self, text: str):
        if text and text != self._PLACEHOLDER:
            self._norm_box.blockSignals(True); self._norm_box.setCurrentIndex(0)
            self._norm_box.blockSignals(False)
            self._norm_tape_box.blockSignals(True); self._norm_tape_box.setCurrentIndex(0)
            self._norm_tape_box.blockSignals(False)
        self._refresh_info_panel()

    def _on_tape_norm_changed(self, text: str):
        if text and text != self._PLACEHOLDER:
            self._norm_box.blockSignals(True); self._norm_box.setCurrentIndex(0)
            self._norm_box.blockSignals(False)
            self._norm_adv_box.blockSignals(True); self._norm_adv_box.setCurrentIndex(0)
            self._norm_adv_box.blockSignals(False)
        self._refresh_info_panel()

    def _active_norm(self) -> str:
        """La normalización activa es la primera de las tres secciones
        que tenga una opción real seleccionada (avanzada > cinta >
        básica) — idéntico criterio que `get_params()` de CRAC."""
        adv_val = self._norm_adv_box.currentText()
        tape_val = self._norm_tape_box.currentText()
        if adv_val and adv_val != self._PLACEHOLDER:
            return adv_val
        if tape_val and tape_val != self._PLACEHOLDER:
            return tape_val
        return self._norm_box.currentText()

    def _refresh_info_panel(self):
        codec = self.studio.codec_box.currentText()
        opt1 = self.studio.opt1_box.currentText()
        self._info_label.setText(
            f"CODEC: {codec}\n"
            f"PROFUNDIDAD/CALIDAD: {opt1}\n"
            f"NORMALIZACIÓN: {self._active_norm()}\n"
            f"DIRECTORIO: {self.dir_edit.text() or '—'}"
        )

    def _browse(self):
        chosen = QFileDialog.getExistingDirectory(
            self, "Seleccionar directorio de exportación", self.dir_edit.text())
        if chosen:
            self.dir_edit.setText(chosen)
            self._refresh_info_panel()

    def _on_iniciar(self):
        """Slot de INICIAR — mismo mecanismo que `_on_vamo()` de CRAC:
        resuelve la normalización activa (avanzada > cinta > básica), la
        escribe de vuelta en `studio.norm_box` (única fuente de verdad),
        confirma el directorio de salida, y dispara el export real."""
        self.studio.norm_box.setCurrentText(self._active_norm())
        chosen_dir = self.dir_edit.text().strip()
        if chosen_dir:
            self.studio._export_output_dir = chosen_dir
        self.export_requested.emit()
        self.accept()

    def _restore_reparented(self):
        for w in self._reparented:
            w.setVisible(False)

    def reject(self):
        self._restore_reparented()
        super().reject()

    def accept(self):
        self._restore_reparented()
        super().accept()
