from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Paneles del lienzo con piel SVG (madera, vúmetros, LCD, Panascrub, Metaloric).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Widgets que pintan las pieles SVG de `lorito_svg_skins.py` (placas
estáticas cacheadas como QPixmap) y, encima, su contenido dinámico con
QPainter en la misma paleta. Ver `lorito_svg_skins.py` para el mapeo
SVG → componente de Lorito Aldhiro.
"""

from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRectF, QPointF
from PySide6.QtGui import (QPainter, QColor, QPen, QBrush, QLinearGradient,
                           QRadialGradient, QFont)

from lorito_aldhiro.frontend.support import lorito_svg_skins as skins
from lorito_aldhiro.frontend.widgets.lorito_indicators import VUBar


def _transparent(widget: QWidget) -> None:
    widget.setAttribute(Qt.WA_OpaquePaintEvent, False)
    widget.setAttribute(Qt.WA_NoSystemBackground, True)
    widget.setAutoFillBackground(False)


# ═════════════════════════════════════════════════════════════════════════════
#  Lienzo
# ═════════════════════════════════════════════════════════════════════════════
class SvgCanvasBackground(QWidget):
    """Fondo del lienzo: SVG de madera pulida de la usuaria. Sustituye a
    `WoodCanvasBackground`/`paint_wood_canvas()` (pintado a mano con Qt),
    retirado: importaba `QPointF` desde `QtGui` (vive en `QtCore`), lo que
    lanzaba ImportError en CADA repintado y dejaba el QPainter abierto
    ("QBackingStore::endPaint() called with active painter")."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        if not skins.paint_svg(p, skins.svg_wood_canvas(w, h), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#3b1c0c"))      # respaldo sin QtSvg
        p.end()


# ═════════════════════════════════════════════════════════════════════════════
#  Vúmetro SVG (REC VU / PLAY VU)
# ═════════════════════════════════════════════════════════════════════════════
class SvgPeakMeter(VUBar):
    """Peak meter estéreo del SVG de la usuaria. Hereda de `VUBar` la
    balística por tiempo, el peak-hold y la calidad (VALID/STALE) — solo
    cambia la vista: segmentos LED de 2 dB (0…−60 dBFS) sobre placa de
    aluminio con ventanas de vidrio. Escala adaptada a dBFS (el original
    marca +3…−20 dB VU, que no aplica a un medidor digital)."""

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self._title = title
        self.setAttribute(Qt.WA_TranslucentBackground, False)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        g = skins.peak_meter_geometry(w, h)
        if not skins.paint_svg(p, skins.svg_peak_meter(w, h, self._title), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#2c3034"))
        stale = self._quality not in ("VALID", None)
        n = g["n"]
        for x, val, pk, pka in ((g["lx"], self._val_l, self._pk_l, self._pk_alpha_l),
                                (g["rx"], self._val_r, self._pk_r, self._pk_alpha_r)):
            self._paint_column(p, g, x, n, val, pk, pka, stale)
        if stale:
            p.setPen(QColor(skins.AMBER))
            f = QFont("monospace"); f.setPixelSize(8); f.setBold(True)
            p.setFont(f)
            p.drawText(QRectF(0, h - 30, w, 12), Qt.AlignCenter, "STALE")
        p.end()

    @staticmethod
    def _level_to_db(v: float) -> float:
        return -60.0 + 60.0 * max(0.0, min(1.0, v))

    def _paint_column(self, p, g, x, n, val, pk, pka, stale):
        db = self._level_to_db(val)
        floor = g["db_floor"]
        # Segmento que contiene el peak-hold (0 = arriba); -1 si no hay pico.
        i_pk = -1
        if pk > 0.02 and pka > 0:
            pk_db = self._level_to_db(pk)
            i_pk = min(n - 1, max(0, int(pk_db / floor * n)))
        sx = x + g["seg_inset"]
        sw = g["win_w"] - 2 * g["seg_inset"]
        for i in range(n):
            y = g["seg_top"] + i * g["pitch"]
            col = QColor(skins.segment_color(i, n, floor))
            lit = db > skins.segment_db(i, n, floor)
            peak_seg = i == i_pk
            rect = QRectF(sx, y, sw, g["seg_h"])
            p.setPen(Qt.NoPen)
            if (lit or peak_seg) and not stale:
                glow = QColor(col); glow.setAlpha(60)
                p.setBrush(glow)
                p.drawRoundedRect(rect.adjusted(-1.5, -1.5, 1.5, 1.5), 2.5, 2.5)
                c = QColor(col)
                if peak_seg and not lit:
                    c.setAlpha(max(80, pka))
                p.setBrush(c)
            else:
                c = QColor(col); c.setAlpha(26 if not stale else 14)
                p.setBrush(c)
            p.drawRoundedRect(rect, 1.5, 1.5)


# ═════════════════════════════════════════════════════════════════════════════
#  LCD Display — placa frontal (LED + LCD + botones)
# ═════════════════════════════════════════════════════════════════════════════
class LcdFaceplate(QWidget):
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        _transparent(self)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._title = title

    def setTitle(self, t: str) -> None:
        self._title = t
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        if not skins.paint_svg(p, skins.svg_faceplate(w, h, self._title), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#2c3034"))
        p.end()


def paint_svg_led(p: QPainter, cx: float, cy: float, radius: float, color: QColor,
                  lit: bool = True) -> None:
    """LED circular del SVG del LCD Display (zócalo rebajado + halo +
    lente + punto especular), escalado a `radius` (10 en el original)."""
    k = radius / 10.0
    bez = QRadialGradient(cx, cy, 10 * k)
    bez.setColorAt(0.0, QColor("#0a0c0e")); bez.setColorAt(0.7, QColor("#161a1e"))
    bez.setColorAt(1.0, QColor("#383d42"))
    p.setPen(QPen(QColor("#080a0c"), 1.5 * k)); p.setBrush(QBrush(bez))
    p.drawEllipse(QPointF(cx, cy), 10 * k, 10 * k)
    p.setPen(QPen(QColor(255, 255, 255, 38), 0.8 * k)); p.setBrush(Qt.NoBrush)
    p.drawEllipse(QPointF(cx, cy), 8.5 * k, 8.5 * k)
    if lit:
        halo = QRadialGradient(cx, cy, 11 * k)
        c0 = QColor(color); c0.setAlpha(110)
        c1 = QColor(color); c1.setAlpha(0)
        halo.setColorAt(0.0, c0); halo.setColorAt(1.0, c1)
        p.setPen(Qt.NoPen); p.setBrush(QBrush(halo))
        p.drawEllipse(QPointF(cx, cy), 11 * k, 11 * k)
    lens = QRadialGradient(cx - 2 * k, cy - 2 * k, 6.5 * k)
    if lit:
        lens.setColorAt(0.0, QColor("#ffffff")); lens.setColorAt(0.3, color)
        lens.setColorAt(1.0, color.darker(190))
    else:
        dim = QColor(color).darker(260)
        lens.setColorAt(0.0, dim.lighter(170)); lens.setColorAt(1.0, dim)
    p.setPen(Qt.NoPen); p.setBrush(QBrush(lens))
    p.drawEllipse(QPointF(cx, cy), 6 * k, 6 * k)
    p.setBrush(QColor(255, 255, 255, 204 if lit else 90))
    p.drawEllipse(QPointF(cx - 2 * k, cy - 2 * k), 1.5 * k, 1.5 * k)


# ═════════════════════════════════════════════════════════════════════════════
#  Panascrub
# ═════════════════════════════════════════════════════════════════════════════
class PanascrubPlate(QWidget):
    """Placa del Panascrub con las leyendas de Lorito grabadas. Las
    leyendas se dan como (texto, y_baseline) en coordenadas del widget."""

    def __init__(self, parent=None):
        super().__init__(parent)
        _transparent(self)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._legends: list = []

    def setLegends(self, legends) -> None:
        self._legends = list(legends)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        if not skins.paint_svg(p, skins.svg_panascrub_plate(w, h, self._legends), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#2c3034"))
        p.end()


PANASCRUB_KNOB_W = 32     # medidas físicas del SVG original
PANASCRUB_KNOB_H = 28
PANASCRUB_SLOT_H = 8


def paint_panascrub_slider(p: QPainter, widget: QWidget, knob_x: float, *,
                           ticks=(), center_x=None, fill=None, accent=QColor(skins.CYAN),
                           dimmed: bool = False, drag: bool = False, pad: int = 12) -> None:
    """Ranura + marcas + relleno funcional + perilla del Panascrub.

    `fill` = (x0, x1, QColor) — tramo de la ranura iluminado (posición,
    desviación bipolar o velocidad), conservado de los scrubs anteriores
    porque comunica estado; `accent` tiñe la línea de la perilla."""
    w, h = widget.width(), widget.height()
    cy = h / 2.0
    slot_w = w - 2 * pad
    slot_y = cy - PANASCRUB_SLOT_H / 2
    p.setRenderHint(QPainter.Antialiasing, True)
    p.save()
    if dimmed:
        p.setOpacity(0.45)
    skins.paint_svg(p, skins.svg_slider_slot(int(slot_w), PANASCRUB_SLOT_H), pad, slot_y - 1,
                    int(slot_w), PANASCRUB_SLOT_H + 4, widget)
    # Marcas de graduación (color de escala del SVG)
    p.setPen(QPen(QColor(skins.SCALE_TEXT), 1))
    for tx, major in ticks:
        th = 4 if major else 2
        p.drawLine(QPointF(tx, slot_y - 2 - th), QPointF(tx, slot_y - 2))
    if center_x is not None:
        p.setPen(QPen(QColor(skins.PLATE_TEXT), 1.2))
        p.drawLine(QPointF(center_x, slot_y - 3), QPointF(center_x, slot_y + PANASCRUB_SLOT_H + 3))
    if fill is not None and not dimmed:
        x0, x1, col = fill
        if x1 - x0 > 0.5:
            c = QColor(col); c.setAlpha(200)
            p.setPen(Qt.NoPen); p.setBrush(c)
            p.drawRoundedRect(QRectF(x0, slot_y + 2, x1 - x0, PANASCRUB_SLOT_H - 4), 2, 2)
    # Perilla (alto adaptado al widget, proporción del original)
    kh = int(min(PANASCRUB_KNOB_H, h - 1))
    kw = int(round(PANASCRUB_KNOB_W * kh / PANASCRUB_KNOB_H))
    kx = knob_x - kw / 2
    ky = cy - kh / 2
    if drag and not dimmed:
        glow = QColor(accent); glow.setAlpha(70)
        p.setPen(Qt.NoPen); p.setBrush(glow)
        p.drawRoundedRect(QRectF(kx - 3, ky - 2, kw + 6, kh + 4), 6, 6)
    skins.paint_svg(p, skins.svg_slider_knob(kw, kh), kx, ky, kw, kh, widget)
    line = QColor(accent); line.setAlpha(255 if drag else (150 if not dimmed else 70))
    p.setPen(QPen(line, 1))
    p.drawLine(QPointF(knob_x, ky + 6), QPointF(knob_x, ky + kh - 7))
    p.restore()


# ═════════════════════════════════════════════════════════════════════════════
#  Metaloric Panel
# ═════════════════════════════════════════════════════════════════════════════
class MetaloricPanel(QWidget):
    """Fondo del Metaloric Panel (0.12: panel vítreo flotante del SVG de la
    usuaria): vidrio oscuro redondeado con retroiluminación verde de canto,
    detrás del visor de señal, la duración de cinta y el log fusionados."""

    def __init__(self, parent=None):
        super().__init__(parent)
        _transparent(self)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        if not skins.paint_svg(p, skins.svg_metaloric_panel(w, h), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#050a08"))
        p.end()


class MetaloricGlare(QWidget):
    """Capa superior del Metaloric Panel: brillo del vidrio, refracción y
    canto verde, más las leyendas HUD de Lorito en tinta verde (p. ej.
    "• VISOR DE SEÑAL INTERACTIVO" sobre el visor). Transparente al ratón:
    no interfiere con el scrub sobre la forma de onda."""

    def __init__(self, parent=None):
        super().__init__(parent)
        _transparent(self)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self._legends: list = []
        self._separators: tuple = ()

    def setSeparators(self, ys) -> None:
        """Líneas finas entre las franjas del panel fusionado (y en px de
        este widget): visor | duración de cinta | log."""
        self._separators = tuple(int(y) for y in ys)
        self.update()

    def setLegends(self, legends) -> None:
        """(texto, x, y_baseline[, "left"|"right"]) en coordenadas de este
        widget; con "right", `x` es el borde derecho del texto."""
        self._legends = list(legends)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        skins.paint_svg(p, skins.svg_metaloric_glare(w, h, self._separators), 0, 0, w, h, self)
        f = QFont("monospace"); f.setPixelSize(8); f.setBold(True)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 1)
        p.setFont(f)
        fm = p.fontMetrics()
        for leg in self._legends:
            text, x, y = leg[0], leg[1], leg[2]
            if len(leg) > 3 and leg[3] == "right":
                x = x - fm.horizontalAdvance(text)
            p.setPen(QColor(*skins.META_GREEN_RGB, 60))
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                p.drawText(QPointF(x + dx, y + dy), text)
            p.setPen(QColor(*skins.META_GREEN_RGB, 235))
            p.drawText(QPointF(x, y), text)
        p.end()


def paint_metaloric_window(p: QPainter, w: int, h: int, radius: float = 3.0,
                           fused: bool = False) -> None:
    """Ventana HUD del Metaloric Panel (calco del recuadro del analizador
    del SVG: fondo #001a0d, borde #00ffaa a 0.6) — fondo común del visor
    de señal, del panel de estado y del panel de duración de cinta.

    0.12: con `fused=True` (los tres dentro del panel fusionado) no se
    dibuja nada: el vidrio único del Metaloric Panel hace de fondo y las
    líneas finas de `MetaloricGlare.setSeparators` separan las franjas."""
    if fused:
        return
    p.setPen(QPen(QColor(*skins.META_GREEN_RGB, 150), 1))
    p.setBrush(QColor(0x00, 0x1a, 0x0d, 200))
    p.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), radius, radius)
