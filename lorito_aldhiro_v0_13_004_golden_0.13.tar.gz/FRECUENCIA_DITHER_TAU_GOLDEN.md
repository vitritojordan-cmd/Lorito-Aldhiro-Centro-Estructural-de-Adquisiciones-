# Frecuencia de captura, motor Dither y TAU — 0.13.002 a 0.13.004

Tres cambios pedidos por la usuaria, en este orden:

1. **Frecuencia de muestreo** en el motor de captura y en el menú MUESTRA (0.13.002).
2. **Motor Dither**, Orden **LA-DTH-OI-001**, con entrada directa desde el menú DSP (0.13.003).
3. **TAU**, Orden **LA-TAU-OI-001**: pitidos de confirmación y leyenda en el LCD (0.13.004).

## 0. Investigación (fuentes consultadas)

| Tema | Hallazgo | Cómo se aplicó | Fuente |
|---|---|---|---|
| Dither TPDF | Triangular de 2 pasos de cuantización de amplitud. Es el dither ideal de menor potencia: no introduce modulación de ruido y elimina la distorsión armónica de la cuantización | Amplitud de ±1 LSB de destino (2 LSB pico a pico) | [Wikipedia, Dither](https://en.wikipedia.org/wiki/Dither) |
| Momentos del error | Con TPDF, la media y la varianza del error total son constantes e independientes de la entrada; a cambio se suma una potencia de LSB²/6 | Pruebas DTH-02 (momentos por fracción de LSB) y DTH-03 (varianza 1/6) | [Lipshitz, Wannamaker y Vanderkooy 1992](https://hajim.rochester.edu/ece/sites/zduan/teaching/ece472/reading/Lipshitz_1992.pdf) · [AES e-library](https://aes2.org/publications/elibrary-page/?id=6799) |
| Varianza total | Con TPDF, la varianza del error total es 0,25 Δ² | DTH-04: 0,4998 LSB RMS medidos | [Patente "Discrete dither"](https://patents.justia.com/patent/11095304) |
| Construcción | La suma de dos ruidos uniformes no correlacionados da la densidad triangular; tres o más no mejoran y suben el ruido | `d = (u1 − u2) · q` | [US5903482](https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/5903482) · [comp.dsp (rbj)](https://www.dsprelated.com/showthread/comp.dsp/220242-1.php) |
| Cuándo aplicar dither | SoX aplica dither automáticamente al reducir la profundidad de bits, y el dither implícito suele ser TPDF | Solo actúa cuando hay reducción real | [Hydrogenaudio](https://hydrogenaudio.org/index.php/topic,87045.0.html) |
| Verificar una frecuencia | `check_input_settings` llama a `Pa_IsFormatSupported`. La información del dispositivo no basta: hay rangos, listas y combinaciones | Verificación previa en MUESTRA y en REC | [sounddevice](https://python-sounddevice.readthedocs.io/api/checking-hardware.html) · [PortAudio](https://portaudio.com/docs/v19-doxydocs/querying_devices.html) |
| Conversión oculta | `plughw` acepta frecuencias que la placa no soporta y las convierte por software. PipeWire remuestrea los streams a `clock.rate` / `clock.allowed-rates` | Límite declarado: Lorito verifica la frecuencia del stream, no la del conversor A/D | [GNU Radio](https://wiki.gnuradio.org/index.php/Audio_Sink) · [ffmpeg-user](https://ffmpeg.org/pipermail/ffmpeg-user/2020-July/049259.html) · [pipewire(1)](https://man.archlinux.org/man/pipewire.1.en) · [issue 2883](https://gitlab.freedesktop.org/pipewire/pipewire/-/issues/2883) |
| Pitido sin clic | El corte brusco produce un clic; conviene una rampa, y la de coseno alzado reduce el salpicado espectral. En pitidos de menos de 50 ms, el clic domina | Rampas de coseno alzado de 5 ms; tono de 80 ms | [Apple Developer Forums](https://developer.apple.com/forums/thread/50907) · [B4X](https://www.b4x.com/android/forum/threads/beeper-function-distorts.112621/) |

## 1. Frecuencia de muestreo (0.13.002)

### Qué admite cada capa

| Capa | Frecuencias | Evidencia |
|---|---|---|
| Motor de captura (`CaptureEngineV2`) | Cualquier entero; probado de 8 kHz a 384 kHz de punta a punta | Sondeo de 12 frecuencias; RATE-01 |
| Cadena DSP (`lorito_dsp_contract.SUPPORTED_RATES`) | 22,05 kHz a 192 kHz | Contrato existente |
| Lorito, menú MUESTRA (`CAPTURE_RATES`) | **44,1 · 48 · 88,2 · 96 · 176,4 · 192 kHz** | RATE-02, RATE-05 |

### Cambios

- **Menú MUESTRA** (`lorito_mw_ui_build.py`) y selector interno: las seis frecuencias. Antes eran 44100 y 192000, y 192000 mostraba "Fnc No Disp".
- **Verificación previa** (`lorito_rate_support.check_capture_rate`): sigue el orden lista de Lorito → contrato DSP → `check_input_settings` del dispositivo.
  - Al elegir en MUESTRA: si no se admite, o si hay una sesión en curso, muestra "Fnc No Disp" y la frecuencia no cambia.
  - Al pulsar REC: si no se admite, no se toca el estado y no se arma nada. Antes, una frecuencia fuera del contrato hacía que `start_record` lanzara la excepción sin atraparla.
- **Frecuencia efectiva** (`_open_stream`): si el stream abre a otra frecuencia, se cierra y se rechaza. Lorito no convierte frecuencias en la captura.
- **Buffers en segundos** (`buffer_plan`): los valores históricos son el piso, así que a ≤ 48 kHz no cambia nada.

| Frecuencia | Ring (perfil balanced) | Cola de disco | Antes |
|---|---|---|---|
| 44,1 kHz | 512 slots = 23,8 s (16 MiB) | 11,6 s | igual |
| 48 kHz | 512 = 21,8 s (16 MiB) | 10,7 s | igual |
| 96 kHz | 938 = 20,0 s (29 MiB) | 10,0 s | 10,9 s / 5,3 s |
| 192 kHz | 1875 = 20,0 s (59 MiB) | 10,0 s | 5,5 s / 2,7 s |

  - El ring crece **en el mismo objeto** (`SPSCCaptureRing.resize`), con productor y consumidor quiescentes.
  - El ring y la cola que inyectan las pruebas de saturación se respetan.
- El comentario de la cola decía "~10 min" y eran 10,7 s; quedó corregido.

### Defecto preexistente encontrado y corregido

**El síntoma.** Al dimensionar el ring en segundos falló, de forma intermitente, `test_writer_follows_the_session_ledger`. Fallaba 15 de 20 veces con el cambio y 0 de 20 sin él.

**La causa** no estaba en el ring. `DiskWriterV2._writer_loop` leía `led = self._ledger` **antes** de esperar el lote. Si `start()` adjuntaba el ledger de la sesión durante esa espera, el primer lote se acreditaba al ledger anterior. El audio sí llegaba al disco (los frames del segmento cuadraban), pero `written` quedaba un lote corto. El nuevo tamaño del ring solo cambió la temporización que lo dejaba ver.

**La corrección.** El ledger se vuelve a leer después de la espera. Quedó en 0 de 20 con y sin el cambio, y RATE-06 lo reproduce de forma determinista: falla sin la corrección y pasa con ella.

## 2. Motor Dither — LA-DTH-OI-001 (0.13.003)

### Punto de inserción (§3.1) y cuantizador que controla

- **Dónde va:** `ExportService.run` lo pone como **última** transformación (normalización → limitador declarado → resampleo → medidor de overs → **dither**), inmediatamente antes del cuantizador del encoder.
- **Cuándo actúa:** solo si la profundidad entera de destino es **menor** que la del RAW (24 bits), es decir, WAV 16 y FLAC 16.
  - Con WAV 24/32, WAV float, WavPack (float) u OGG (con pérdida), queda en **bypass** sin añadir ruido, aunque TPDF esté elegido.
  - La captura nunca pasa por él.
- **Cuantizador de referencia:** `round(clip(x,−1,1)·2^(b−1))` recortado a `[−2^(b−1), 2^(b−1)−1]`. Es el de `WavEncoder`.
  - El de ffmpeg (`flt → s16`) es **idéntico**: la prueba DTH-10 decodifica un FLAC 16 sin dither y lo compara muestra a muestra con el WAV 16.
  - LSB de destino en el dominio float: `q = 2^−(b−1)`.

### Fórmula, PRNG y semilla (§3.2)

- **TPDF:** `d = (u1 − u2) · q`, con `u1` y `u2` ~ U[0,1) independientes. Es triangular en (−q, +q), varianza q²/6.
- **Error total esperado:** q²/4, es decir 0,5 LSB RMS, que a 16 bits son −96,3 dBFS.
- **PRNG:** `numpy.random.Generator(PCG64)`, uno por instancia.
  - Se extrae en orden (frame, canal, par), así que la salida no depende del tamaño de bloque y los canales son independientes.
  - Nunca se reinicia por bloque; solo con `reset()` explícito.
- **Semilla:**
  - configurable (`ExportRequest.dither_seed`);
  - sin semilla, se toma entropía del sistema y **se registra** en el resultado, el manifiesto y el sidecar, así que cualquier exportación es reproducible.
- **Límites:**
  - la salida se recorta a los límites del cuantizador, sin wraparound, y se cuentan las muestras recortadas;
  - NaN/Inf se sanean a 0,0, se cuentan y quedan como aviso.
- **Fuera de alcance (§3.3):** noise shaping, dither rectangular, perfiles múltiples y cualquier cambio de ganancia, EQ o balance.

### Menú y celdas

- **DSP → DITHER:** **TPDF (TRIANGULAR)** y **APAGAR DITHER**. Se retiraron RECTANGULAR y SHAPED: la orden los excluye en esta versión y antes no hacían nada.
- **Celda DITHER:** parpadea mientras TPDF está elegido.
- **MASTER:** con TPDF elegido y una exportación que reduce bits, el dither cuenta como tratamiento DSP y MASTER no se enciende. El resultado lo confirma con `dither:TPDF 24→16 bits` en `transforms`.

### Rendimiento e integridad (§8)

- **Velocidad:** 10 min estéreo a 48 kHz en 0,71 s (**850× tiempo real**), 0,1 ms por bloque de 4096.
- **Memoria:** sin crecer en 10 min de bloques.
- **Ruido con entrada cero:** 0,4998 LSB RMS = **−96,33 dBFS**, pico de 1 LSB, espectro plano.
- **Integridad:** frames de entrada = frames de salida, y cada muestra queda a ±1 LSB de la cuantización sin dither (DTH-08).

### Archivos

| Archivo | Cambio |
|---|---|
| `lorito_aldhiro/backend/dsp/lorito_dither.py` | nuevo |
| `lorito_aldhiro/backend/export_streaming/lorito_export_service.py` | `dither_mode`/`dither_seed`, `_plan_dither`, `target_int_bits`, `planned_target_bits`, `res.dither`, manifiesto |
| `lorito_aldhiro/frontend/main_window/lorito_mw_ui_build.py` | menú DSP → DITHER |
| `lorito_aldhiro/frontend/main_window/lorito_mw_optape_menu.py` | `_on_dsp_dither_menu`, `_dither_mode` |
| `lorito_aldhiro/frontend/main_window/lorito_mw_export.py` | modo de dither en la solicitud; MASTER con dither |

## 3. TAU — LA-TAU-OI-001 (0.13.004)

### Mecanismo de audio

- **Las capas:**
  - `TauSequencer`: puro, con la línea de tiempo exacta a la muestra;
  - `TauService`: un único stream de salida de sounddevice/PortAudio, la misma librería y el mismo dispositivo por defecto que el resto de Lorito;
  - `TauMixin` en la ventana.
- **Ciclo de vida del stream:**
  - se abre a demanda en **un** hilo de servicio, que se crea con el primer pitido;
  - se **reutiliza** entre clics;
  - se cierra tras 3 s de inactividad.
  - Nunca hay un hilo ni un stream por clic.
- **Por qué no se mezcla en los callbacks de reproducción o monitor.** Están certificados (ledger, generaciones, temporización), y la orden pide que TAU no altere la reproducción principal (TAU-T05).
- **Con PipeWire o PulseAudio,** el servidor mezcla los streams.
- **Con un dispositivo ALSA `hw` exclusivo,** TAU puede no abrir mientras se reproduce. En ese caso falla de forma segura: sin pitido y sin leyenda.

### Patrones y parámetros (centralizados en `TauParams`)

| Parámetro | Valor | Orden |
|---|---|---|
| Tono | 1500 Hz, −18 dBFS | — |
| Duración | 80 ms | 60–100 ms |
| Pausa entre los dos tonos | 95 ms | 70–120 ms |
| Rampas | 5 ms, coseno alzado | sin clic |
| Activación / desactivación | 1 pitido (80 ms) / 2 pitidos (255 ms) | §2 |

### Leyenda TAU en el LCD

- **Cuándo se enciende:** con el evento `start` que emite el **callback de audio** cuando el tono empieza efectivamente a sonar (§4.2), entregado por la señal Qt encolada `tau_events`.
- **Cuándo se apaga:** con `end`, al entregarse la última muestra. Durante la pausa entre los dos pitidos no se apaga.
- **Patrón encolado:** si arranca al terminar el actual, llega `[end, start]` en el mismo ciclo y la leyenda no parpadea.
- **Limpieza garantizada:**
  - fallo de audio → `tau_failed`;
  - temporizador de seguridad (duración del patrón + 0,75 s);
  - cierre de la ventana.
- **Quién puede encenderla:** la celda TAU es una *celda de servicio*. Ni `set_cell_lit` ni las familias de overlays pueden encenderla. COSANI sigue siendo un placeholder apagado.

### Política de solicitudes (§4.1 y §4.3)

- **Pendientes:** como máximo una; la nueva reemplaza a la pendiente.
- **Rebote:** una solicitud igual dentro de 120 ms se ignora (doble clic).
- **Sin bloqueo:** el callback nunca espera el lock del GUI; si está tomado, entrega silencio ese ciclo.
- **Costo:** `render` de 256 frames, p50 de 3 µs y p99 de 7 µs, con un presupuesto de 5333 µs.

### Botones (§5): el botón decide y TAU confirma el resultado real

| Control | 1 pitido | 2 pitidos |
|---|---|---|
| REC | el motor confirmó la apertura | — |
| PAUSA | quedó en pausa | se reanudó |
| PLAY | la reproducción arrancó | — |
| ◀◀ / ▶▶ | el coordinador aceptó la pulsación | — |
| STOP (y Space) | — | se detuvo algo que estaba activo |
| OPTAPE: ALC, MPX, FOCUS, HX PRO | quedó encendido | quedó apagado |
| DSP → DITHER | TPDF elegido | apagado |

- **Sin pitido:** una acción rechazada o sin efecto no suena (FF sin cinta, STOP sin nada activo, PAUSA sin grabar, REC fallido).
- **Fuera del alcance inicial** (controles no binarios, §5): CINTA, HOST, MUESTRA, BITDEPH, los perfiles NR, EQ/BIAS, ACERCA y EXPULSAR.

## 4. Matriz requisito → prueba → evidencia

| ID | Requisito | Prueba | Evidencia |
|---|---|---|---|
| RATE-01 | Captura de punta a punta a 44,1–192 kHz | `RATE01EndToEnd` | Ledger reconciliado (deltas en 0); WAV con la frecuencia y los frames correctos |
| RATE-02 | Verificación lista → DSP → dispositivo | `RATE02PreCheck` (4) | El dispositivo decide; fuera de la lista no se le consulta |
| RATE-03 | Buffers en segundos | `RATE03Buffers` (2) | ≥ 20 s / 10 s; piso histórico; buffers inyectados respetados |
| RATE-04 | Stream a otra frecuencia | `RATE04StreamRateMismatch` | Rechazado sin arrancar |
| RATE-05 | Menú y REC | `RATE05Menu` (5, Qt real) | Seis frecuencias; "Fnc No Disp" sin cambiar el estado |
| RATE-06 | Ledger del escritor | `RATE06WriterLedgerRace` | Falla sin la corrección y pasa con ella |
| DTH-01 | Bypass | `DTH01Bypass` (2) | OFF = cuantizador de referencia; sin reducción, bytes idénticos |
| DTH-02 | Reducción de bits | `DTH02Reduction` (2) | Media del error < 0,02 LSB y varianza 0,25 ± 0,02 en cualquier entrada; un tono de 0,4 LSB sobrevive (0,4 ± 0,03), sin dither desaparece |
| DTH-03 | Distribución | `DTH03Distribution` | Triangular en (−1, 1) LSB, varianza 1/6 |
| DTH-04 | Nivel de ruido | `DTH04NoiseLevel` | 0,5 LSB RMS = −96,33 dBFS, pico de 1 LSB, espectro blanco |
| DTH-05 | Extremos | `DTH05Extremes` (2) | Sin wraparound; NaN/Inf contados; configuración inválida rechazada |
| DTH-06 | Continuidad | `DTH06Continuity` | Idéntico con bloques de 1 a 4096 frames; sin reinicios |
| DTH-07 | Multicanal | `DTH07Multichannel` | Correlación < 0,01; orden de canales conservado |
| DTH-08 | Integridad | `DTH08Integrity` | Frames iguales; ±1 LSB; semilla en el manifiesto; reproducible |
| DTH-09 | Rendimiento | `DTH09Performance` | > 20× tiempo real (medido: 850×); memoria sin crecer |
| DTH-10 | Regresión | `DTH10Regression` (2) + suite completa | FLAC 16 con el mismo cuantizador que WAV; modo inválido abortado sin archivo |
| TAU-T01/T02 | 1 y 2 pitidos | `TAUT01T02Patterns` (4), `TAUQt` | Una sola ventana de leyenda (≈ 80 ms / ≈ 255 ms); sin clic; independiente del bloque |
| TAU-T03 | Limpieza del LCD | `TAUQt` | Apagada al terminar y al cerrar |
| TAU-T04 | Sin bloqueo | `ServiceLifecycle` | `activate()` < 20 ms con un dispositivo que tarda 400 ms en abrir |
| TAU-T05 | Captura intacta | `TAUT05CaptureUntouched` | Captura reconciliada mientras TAU suena |
| TAU-T06 | Ráfagas | `TAUT06Bursts` (3) | Rebote; como máximo 1 pendiente; el callback no espera |
| TAU-T07 | Fallo de audio | `ServiceLifecycle`, `TAUQt` | Sin pitido no hay leyenda; el temporizador limpia un `start` huérfano |
| TAU-T08 | Regresión | Suites completas | Ver abajo |

**Resultados:**

- suite completa (stubs): **1053/1053 OK**, 0 ResourceWarning;
- Qt real, 19 módulos: **254/254 OK**.

## 5. Limitaciones declaradas

- **Sin hardware de audio en este entorno.** No pude escuchar TAU ni medir la latencia real de la leyenda contra el sonido en el dispositivo objetivo. Los tiempos se midieron con un stream simulado en tiempo real. LA-TAU-OI-001 §6 y LA-DTH-OI-001 §9 piden validar en el entorno real: falta esa verificación.
- **Frecuencia del hardware.** Con `plughw` o PipeWire, el dispositivo "default" puede convertir la frecuencia sin avisar. Lorito verifica la del stream, no la del conversor A/D.
- **ALSA `hw` exclusivo.** TAU puede no sonar mientras reproduce otro stream. Lo hace de forma segura: sin leyenda.
- **Exportación a 16 bits sin dither.** Sigue contando como "cruda" para MASTER, igual que antes. Es una decisión pendiente de la usuaria.
