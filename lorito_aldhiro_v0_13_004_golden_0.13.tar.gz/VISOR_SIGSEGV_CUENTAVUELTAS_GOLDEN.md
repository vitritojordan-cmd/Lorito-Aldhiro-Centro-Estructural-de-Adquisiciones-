# Visor de onda, protección SIGSEGV y cuentavueltas — LA-GOLDEN-VIEW-SIGSEGV-019 (0.13)

Este documento entrega lo que pide la orden en su §10:

- informe de auditoría con archivo, símbolo, línea y severidad;
- diagrama de propiedad y ciclo de vida;
- informe SIGSEGV con trazas de antes y después;
- contrato del cuentavueltas;
- resultados de pruebas y bancos;
- matriz requisito → implementación → prueba → evidencia → responsable.

Código principal:

- `lorito_aldhiro/backend/telemetry/lorito_waveform_snapshot.py`: solicitud, snapshot y worker.
- `lorito_aldhiro/backend/telemetry/lorito_waveform_envelope.py`: envolvente y ring en vivo.
- `lorito_aldhiro/frontend/widgets/lorito_waveform.py`: widget.
- `lorito_aldhiro/backend/core/lorito_crash_diagnostics.py`: Capa C.
- `lorito_aldhiro/backend/playback/lorito_tape_counter_model.py` y `lorito_aldhiro/frontend/widgets/lorito_tape_counter.py`: cuentavueltas.

Pruebas en `tests/test_view_sigsegv_golden.py` y `tests/test_tape_counter_drums.py`. Banco en `tools/visor/bench_waveform_snapshot.py`.

## 0. Fuentes técnicas consultadas

| Tema | Lo que dice la fuente | Cómo se aplicó | Fuente |
|---|---|---|---|
| Afinidad de hilo en Qt | Un QWidget solo se usa desde el hilo GUI. Entre hilos se habla con señales encoladas: el slot corre en el hilo del receptor | El worker no toca el widget. Entrega por `_bridge.waveform_snapshot`, una señal encolada | [Qt 6, Threads and QObjects](https://doc.qt.io/qt-6/threads-qobject.html) |
| Vida del objeto C++ bajo PySide6 | `shiboken6.isValid(obj)` dice si el objeto C++ detrás del envoltorio Python sigue vivo | El slot descarta snapshots para widgets ya destruidos | [Shiboken6 module](https://doc.qt.io/qtforpython-6/shiboken6/shibokenmodule.html) |
| QPainter | Un widget solo se pinta dentro de `paintEvent`, y el painter debe terminar (`end`) | Un único painter por evento, con `end` garantizado en `finally` | [QPainter](https://doc.qt.io/qt-6/qpainter.html) |
| Diagnóstico de fallos nativos | `faulthandler` vuelca el stack Python de todos los hilos ante SIGSEGV, SIGFPE, SIGABRT y SIGBUS, sin asignar memoria | `crash_faulthandler.log` con encabezado de versión, plataforma y pid | [faulthandler](https://docs.python.org/3/library/faulthandler.html) |
| Excepciones en hilos | `threading.excepthook` recibe las excepciones no atrapadas de cualquier hilo | Se registran en el mismo log, con el nombre del hilo | [threading.excepthook](https://docs.python.org/3/library/threading.html#threading.excepthook) |
| Lectura sin lock de un productor | Seqlock: el lector lee el contador antes y después; si cambió, la lectura no es coherente y se repite | `LiveEnvelopeRing.snapshot` descarta las filas alcanzadas por el productor y, si hace falta, reintenta | [Linux, Sequence counters and sequential locks](https://www.kernel.org/doc/html/latest/locking/seqlock.html) |
| Min/max por ventana sin bucle Python | `ufunc.reduceat` reduce tramos contiguos dados por índices | Envolvente min/max por columna en bloques fijos | [numpy.ufunc.reduceat](https://numpy.org/doc/stable/reference/generated/numpy.ufunc.reduceat.html) |

## 1. Auditoría (Fase A) — estado en 0.12.001

Se comparó contra el código del tarball `lorito_aldhiro_v0_12_001_golden_0.12.tar.gz`. Las líneas citadas en la columna "Lugar en 0.12" son las de ese tarball.

| # | Lugar en 0.12 | Hallazgo | Clase | Severidad | Resolución en 0.13 (archivo:línea actual) |
|---|---|---|---|---|---|
| V-01 | `lorito_waveform_envelope.py` `compute_file_envelope` l.95–125 | Leía bloques de `fpp × 256` frames. Con 1024 columnas, cada lectura era ¼ del archivo, así que la memoria crecía con la duración: **494 MB con 20 min** estéreo de 48 kHz y unos 1,5 GB por hora | Agotamiento de memoria (no es SIGSEGV) | **Alta**: en sesiones largas el `MemoryError` o el OOM-killer tumba el proceso entero, captura incluida | Lecturas fijas de `READ_FRAMES = 65536` con `reduceat` por columna (`lorito_waveform_envelope.py:111-114`). Ahora son **2,3 MB, planos de 1 a 60 min** |
| V-02 | `lorito_waveform.py` `_WaveformUpdateWorker._loop` l.609–623 y `_waveform_compute` | El worker leía atributos del widget (`_cached_width`, `amplitude_view`) desde su hilo | Carrera; uso de un objeto Qt fuera del hilo GUI | Media: si el widget se destruye, se accede a un envoltorio cuyo objeto C++ ya no existe | La solicitud inmutable `WaveformRequest` se arma en el hilo GUI (`lorito_waveform.py:378`, `make_request`). El worker solo ve la solicitud. `_waveform_compute` se retiró |
| V-03 | `lorito_mw_telemetry.py` `_on_waveform_ready` l.205–220 | El slot escribía en el widget sin verificar que siguiera vivo ni de qué fuente venían los datos | Uso tras liberar; datos obsoletos | Media: al cerrar o cambiar de fuente, un resultado en vuelo podía pintar la fuente vieja o tocar un widget destruido | Slot `_on_waveform_snapshot` con `shiboken6.isValid` (`lorito_mw_telemetry.py:205`). `apply_snapshot` rechaza las generaciones viejas y los widgets cerrados (`lorito_waveform.py:385`) |
| V-04 | `lorito_waveform.py` `_WaveformUpdateWorker` | Hilo daemon sin parada: podía emitir durante la finalización del intérprete, con Qt ya desmontado | Cierre desordenado | Media: es una ruta conocida de SIGSEGV al salir en PySide6 | `WaveformWorker.stop()` pone un centinela, hace `join` y no emite después (`lorito_waveform_snapshot.py:191`). Lo registra `atexit` (`lorito_waveform.py:653`), y `closeEvent` marca el widget cerrado (`lorito_main_window.py:521`) |
| V-05 | `lorito_waveform.py` `paintEvent` l.363 | Una excepción a mitad de la pintura dejaba el `QPainter` activo y se propagaba al lazo de Qt | Excepción Python; painter activo | Media: un painter sin `end` sobre el backing store precede a fallos en Wayland (`QWaylandShmBackingStore`) | Un único painter con `try/except/finally` y `end` garantizado. Ante un fallo, degrada a **VISOR NO DISPONIBLE** (`lorito_waveform.py:428`) |
| V-06 | `lorito_waveform_envelope.py` `LiveEnvelopeRing.snapshot` l.59–67 | Copiaba filas del ring sin detectar que el productor las sobrescribiera durante la copia | Carrera de datos (sin corrupción de memoria: NumPy copia, pero la mezcla de filas es incoherente) | Baja | Lectura al estilo seqlock: lee `_w` antes y después, descarta las filas alcanzadas y reintenta con un tope (`lorito_waveform_envelope.py:59`) |
| V-07 | Arranque (`lorito_bootstrap.py`) | No había `faulthandler`: un SIGSEGV no dejaba rastro del primer punto de fallo | Diagnóstico | Media | `lorito_crash_diagnostics.enable(ARCHIVE_DIR)` antes de crear `QApplication` (`lorito_bootstrap.py:265`) |
| V-08 | `_waveform_compute` y `_on_waveform_ready` | Ante un fallo de cálculo se pintaban ceros (256 columnas planas): un visor "vacío" que parecía silencio real | Estado falseado | Media: §1 y §SIG-04 piden no presentar datos incompletos como válidos | Snapshot `ok=False` con su error y visor degradado explícito. `failed_snapshot` no reserva memoria y sirve también bajo `MemoryError` |
| V-09 | `_update_from_file` (síncrono) | Duplicaba la lógica del worker por otro camino | Mantenimiento | Baja | Pasa por el mismo camino: `make_request → compute_snapshot → apply_snapshot` (`lorito_waveform.py:338`) |
| V-10 | Cuentavueltas | Solo lo movía la captura. En PLAY y FF/REW quedaba quieto, sin fuente declarada | Contrato (§5) | Media | `TapeCounterModel` con posición confirmada y calidad declarada. `_publish_transport_counter` (`lorito_mw_playback.py:112`) |

**Defectos nativos.** No se encontró en el código de Lorito un acceso nativo directo a memoria: no hay ctypes ni cffi en el visor. Las causas de SIGSEGV posibles son de **vida útil e hilos de Qt** (V-02, V-03, V-04, V-05), no de punteros propios. Esas causas se corrigieron. V-01 no es un SIGSEGV, pero con el OOM-killer termina igual: con la muerte del proceso.

## 2. Arquitectura y propiedad (Fases B y C)

```
 HILO GUI                                   HILO lorito-waveform              HILO GUI
 ─────────                                  ────────────────────              ─────────
 WaveformDisplay.make_request()
   ├─ begin_source(): generación += 1
   └─ WaveformRequest(gen, ruta, tasa,
        ancho, modo)  ── inmutable ──►  WaveformWorker.submit()
                                         (descarta pendientes: solo la última)
                                              │
                                              ▼
                                         compute_snapshot(req)
                                           lector por bloques (65536 frames)
                                           min/max por columna (reduceat)
                                           WaveformSnapshot (arrays de solo
                                           lectura, gen, frames, tasa, canales,
                                           columnas, ok/error)
                                              │
                                              ▼ _bridge.waveform_snapshot (encolada)
                                                                    _on_waveform_snapshot()
                                                                      shiboken6.isValid?
                                                                      apply_snapshot():
                                                                        cerrado → rechaza
                                                                        gen ≠ vigente → rechaza
                                                                        ok=False → VISOR NO DISPONIBLE
                                                                        ok → update()
```

| Objeto | Dueño | Vida | Cómo termina |
|---|---|---|---|
| `WaveformRequest` | Hilo GUI, que la crea; el worker solo la lee | Inmutable (`frozen`) | Lo recoge el GC |
| `WaveformSnapshot` | Lo crea el worker y lo pasa al GUI | Arrays con `write=False`; nadie los muta | Lo reemplaza el siguiente snapshot |
| `WaveformWorker` | Módulo `lorito_waveform` (único) | Proceso | `stop()` vía `atexit`: centinela + `join(1 s)`; después no emite |
| `WaveformDisplay` | Ventana principal | Ventana | `closeEvent → mark_closed()`: nueva generación + `_closed`; lo que esté en vuelo se rechaza |
| `LiveEnvelopeRing` | Telemetría de captura (productor único) | Sesión | `snapshot()` devuelve copias propias del consumidor, nunca vistas |
| `TapeCounterDrums` | Ventana principal (hermano del panel, sobre el vidrio) | Ventana | Solo pinta la `CounterSnapshot` vigente (inmutable) |

**Orden de cierre (§4).** `closeEvent` sigue este orden:

1. apaga el transporte;
2. llama a `waveform.mark_closed()`;
3. al terminar el intérprete, `atexit` detiene el worker (`stop`).

Entre el paso 2 y el 3 puede llegar un snapshot. Si llega, se rechaza por estar cerrado, o el slot lo descarta porque el objeto C++ ya no es válido.

**Presión de memoria (§4).**

- La envolvente es O(columnas): como mucho `MAX_COLUMNS = 4096`.
- Un `MemoryError` da un snapshot degradado, no una excepción.
- La captura no se entera.

## 3. Informe SIGSEGV (Fase D)

**Causa raíz.** Hay un antecedente histórico documentado en `lorito_bootstrap.py`: `QWaylandShmBackingStore::finalizeBackBuffer` (señal 11) por hilos que no eran el GUI y que tocaban Qt. En 0.12 seguían abiertas cuatro rutas de ese tipo:

- V-02: el worker leía el widget;
- V-03: el slot no verificaba que el objeto viviera;
- V-04: el worker podía emitir durante el cierre;
- V-05: el painter quedaba activo tras una excepción.

Además, V-01 (O(duración)) mataba el proceso por memoria en sesiones largas.

**Arreglo.** Ver la tabla del §1: el worker queda aislado, hay generaciones, se verifica la validez del objeto, hay parada ordenada, la pintura es transaccional y la envolvente es O(ancho).

**Herramientas instrumentadas.**

- **faulthandler** con todos los hilos, más `sys.excepthook` y `threading.excepthook`, al archivo `crash_faulthandler.log` del directorio de archivo. Cada sesión abre un encabezado.
- **SIG-01** produce un SIGSEGV *real* (lectura de la dirección 0 con ctypes) en un subproceso y verifica que el log tiene el primer punto de fallo.

Traza real de 0.13.001 (`ctypes.string_at(0)` dentro de `primer_punto_de_fallo`):

```
===== Lorito Aldhiro 0.13.001 · sesión iniciada (faulthandler activo) · pid 6747 · 2026-10-13T18:15:13 · Linux-6.18.44-fc-v114-x86_64-with-glibc2.39 · Python 3.13.16 =====
Fatal Python error: Segmentation fault

Current thread 0x00007f9118892080 (most recent call first):
  File "/usr/lib/python3.13/ctypes/__init__.py", line 551 in string_at
  File "<string>", line 6 in primer_punto_de_fallo
  File "<string>", line 7 in <module>

Extension modules: numpy._core._multiarray_umath, numpy.linalg._umath_linalg (total: 2)
```

En 0.12 la misma falla no dejaba ningún log: solo el código de salida 139.

**Antes y después (memoria de la envolvente, mismo WAV PCM16 estéreo de 48 kHz y 1024 columnas):**

| Duración | 0.12 tiempo | 0.12 pico | 0.13 tiempo | 0.13 pico |
|---|---|---|---|---|
| 5 min | 1,648 s | 123,6 MB | 0,112 s | 2,3 MB |
| 20 min | 7,250 s | 494,4 MB | 0,464 s | 2,3 MB |

**Recuperación (Capa D).**

- No se intenta seguir dentro del proceso tras un SIGSEGV: `faulthandler` vuelca el stack y deja que el proceso muera.
- Al reiniciar, `CrashGuard` encuentra el heartbeat sin limpiar y abre el diálogo de recuperación con el manifiesto validado (`_check_crash_recovery`).
- Lo capturado está en segmentos RAW en disco, independientes del visor.

**Sin sanitizadores.** ASan, UBSan y TSan **no se pueden ejecutar** sobre PySide6 y NumPy de la distribución: hacen falta builds instrumentados de CPython, Qt y NumPy. Ver §8.

## 4. Visor degradado y aislamiento de la captura (SIG-04, INT-01)

- Un fallo de cálculo o de pintura pone `view_state = UNAVAILABLE` y pinta "VISOR NO DISPONIBLE" en ámbar, dentro del visor.
- No usa el overlay del LCD "Fnc No Disp", que significa *función inhibida por diseño* y no un fallo técnico (`lorito_mw_playback.py:188`).
- Una fuente nueva (`begin_source`) recupera el visor.
- El visor solo **lee** el archivo de sesión. INT-01 verifica que el SHA-256 del RAW no cambia ante un fallo inducido ni ante `MemoryError`.

## 5. Contrato del cuentavueltas (Fase E, §5)

| Aspecto | Contrato |
|---|---|
| Fuente de verdad | Posición confirmada en frames enteros. En PLAY: `src_pos` del reproductor, la misma que alimenta el reloj del LCD (`lorito_mw_ui_build.py:1414-1420`). En FF/REW: la posición del `TransportCoordinator`. En captura: el panel de duración de cinta. No hay sensor físico de vueltas |
| Calidad | `ESTIMATED` siempre que hay fuente. `UNKNOWN` sin fuente o con una posición no finita o negativa: los tambores se apagan y no se inventa un valor |
| Unidades | frames → segundos → lado (A, B, SOBRANTE o LIBRE) → lectura 000–999 → tambores (dígito, rodado). Cada paso es una función separada (`reading_for_frames`, `reading` y `drums`) |
| Modelo | C-60 y C-90: cada lado recorre 000→999 linealmente con el tiempo del lado. Es el mismo modelo del panel durante la captura, así que la lectura es la misma grabando que reproduciendo. OTROS: segundos mod 1000 |
| Tolerancia | El volteo real ocurre dentro de la ventana de tolerancia del panel, no exactamente en `side_a`. Por eso la lectura del Lado B en reproducción es una estimación de ± esa ventana. El cálculo no tiene deriva: se hace desde la posición en cada lectura, sin acumular |
| Límites | Por encima del total satura en 999 con `overflow=True`. Por debajo de 0 da `UNKNOWN`. Los tambores siempre quedan en 0–9 y el rodado en 0–1 |
| Estados | Captura: activo, pausa (atenuado 0,45), espera o desborde (alterna con el color de aviso). Transporte en movimiento: `transport`. Transporte detenido: `held`, el último valor congelado con luz 0,6, sin avance por temporizador |
| Prioridad | Captura activa > transporte > reposo. Al grabar se borra la fuente de transporte |
| Rodado | Regla del cuentakilómetros: las unidades ruedan de forma continua y cada rodillo superior rueda solo mientras el inferior pasa de 9 a 0 |
| Calibración | Versión del modelo: 0.13 (`lorito_tape_counter_model.py`). Los parámetros son las duraciones del tipo de cinta elegido (`side_a`, total). No hay calibración contra un deck físico porque Lorito no tiene uno |

## 6. Integración visual (§6)

- El cuentavueltas y el reloj del LCD usan la misma posición en el mismo tick.
- Los carretes y el corazón no cambian: el corazón late solo con captura confirmada. FF/REW no lo toca (`test_transport_ff_rew.py:191`).
- El visor degradado no se confunde con "Fnc No Disp" (§4).
- Contraste:
  - activo: ámbar pleno;
  - pausa: 0,45;
  - congelado: 0,6;
  - desborde: color de aviso;
  - sin fuente: apagado;
  - visor degradado: texto ámbar.

## 7. Bancos (§8)

Corrida de `python3 tools/visor/bench_waveform_snapshot.py 1,5,20,60` en el contenedor de CI, sin hardware de referencia:

| Duración | Archivo | Tiempo | Pico de memoria | Transitorio de 1 muestra |
|---|---|---|---|---|
| 1 min | 11 MB | 0,025 s | 2,27 MB | conservado |
| 5 min | 55 MB | 0,133 s | 2,27 MB | conservado |
| 20 min | 220 MB | 0,445 s | 2,27 MB | conservado |
| 60 min | 659 MB | 1,384 s | 2,27 MB | conservado |

- **Ráfaga al worker:** 200 solicitudes dan 1 calculada y 199 descartadas, y la última generación entregada es la 200. Tras `stop()`, el hilo terminó.
- **Pintura offscreen** (300 cuadros, tamaño real del lienzo):
  - visor 732×58: p50 4,6 ms, **p95 6,2 ms**, máx. 9,1 ms;
  - cuentavueltas: p50 0,66 ms, **p95 1,15 ms**.

  Las dos quedan por debajo de 16,7 ms. Es un render por software sin compositor, así que no sustituye la medición a 60 Hz en hardware de referencia (§8).

## 8. Limitaciones declaradas

- **SIG-01 (ASan/UBSan) y la parte TSan de SIG-02:** no se pueden ejecutar aquí. Requieren CPython, Qt y NumPy compilados con sanitizadores, y PySide6 de la distribución no los trae. En su lugar:
  - SIG-01 verifica la Capa C con un SIGSEGV real;
  - SIG-02, una carrera real productor/consumidor sobre el ring.
- **UI-01 y §8 (P95 a 60 Hz en hardware de referencia):** no medido. Solo hay tiempos de pintura offscreen (§7).
- **END-01:** cubre el worker (2000 solicitudes, sin crecer en hilos) y la envolvente plana hasta 60 min. No se corrió una sesión real de horas con audio en vivo.
- **Lado B en reproducción:** el cuentavueltas es una estimación (§5), por diseño y declarado.

## 9. Matriz requisito → implementación → prueba → evidencia → responsable

| ID | Requisito | Implementación | Prueba | Evidencia | Responsable |
|---|---|---|---|---|---|
| WAV-01 | Transitorios preservados; sin recorrer la sesión por cuadro | `compute_file_envelope` (min/max por columna) | `WAV01Envelope` (2) | Pico de 1 muestra conservado; igual al cálculo por fuerza bruta | Telemetría / visor |
| WAV-02 | Memoria acotada, proporcional al ancho | `READ_FRAMES`, `MAX_COLUMNS` | `WAV02LongSource` | Banco: 2,27 MB de 1 a 60 min (antes 494 MB a 20 min) | Telemetría / visor |
| WAV-03 | Generaciones antiguas descartadas | `begin_source`, `apply_snapshot` | `WidgetGolden.test_wav03_*` | Contador `_stale_rejected` | Frontend |
| WAV-04 | Resize continuo sin crecimiento | Ancho acotado y snapshot inmutable | `WidgetGolden.test_wav04_*` | 300 resizes con render: objetos del GC acotados (< 2000) y visor OK | Frontend |
| SIG-01 | Diagnóstico de fallos nativos | `lorito_crash_diagnostics` | `SIG01NativeDiagnostics` (2) | Traza del §3 | Núcleo |
| SIG-02 | Concurrencia sin lecturas incoherentes | `LiveEnvelopeRing.snapshot` (seqlock) | `SIG02Concurrency` | Productor en carrera, 0 filas incoherentes | Telemetría |
| SIG-03 | Cierre: workers parados, cero callbacks a objetos muertos | `WaveformWorker.stop`, `mark_closed`, `shiboken6.isValid` | `SIG03ShutdownAndUI01`, `test_bridge_slot_ignores_deleted_widgets` | `emitted_after_stop = 0` | Frontend / telemetría |
| SIG-04 | Fallo inducido → degradado sin falsear | `_degrade`, `paintEvent` transaccional | `test_sig04_*` (2) | `view_state = UNAVAILABLE`; painter terminado | Frontend |
| CTR-01 | Monotonía con la fuente | `TapeCounterModel.reading` | `test_ctr01_*` | 500 lecturas ordenadas | Reproducción |
| CTR-02 | FF/REW/STOP y límites | `_publish_transport_counter`; saturación en 999 | `test_ctr02_*` (2) | Sube con FF, baja con REW, se congela en STOP | Reproducción / transporte |
| CTR-03 | Pausa, fin de lado y congelado | Estados `held` y `paused`; lado A→B explícito | `test_ctr03_end_of_side_is_explicit`, `test_ctr02_ff_rew_direction_stop_freezes` | Sin avance tras STOP | Reproducción |
| CTR-04 | Sin fuente → desconocido | Calidad `UNKNOWN` y tambores apagados | `test_ctr04_*`, `CounterDrumsUnit.test_unlit_when_inactive` | — | Reproducción / frontend |
| UI-01 | La captura no espera al visor | Worker de solo la última solicitud y entrega encolada | `test_only_the_latest_request_is_computed` | 200 → 1 calculada | Telemetría |
| INT-01 | RAW intacto ante un fallo del visor | El visor solo lee | `INT01RawUntouched` | SHA-256 igual | Captura |
| END-01 | Endurance sin fugas ni hilos colgados | `WorkerStats` y parada | `END01Endurance` | Hilos sin crecer | Telemetría |

Resultados de 0.13.001:

- suite completa (stubs): 1005 pruebas en OK y 0 ResourceWarning (70 skips: 68 necesitan Qt real y corren en la otra suite; 2 dependen del entorno);
- suite con Qt real: 206 en OK.

Ver `saneamiento_0_13_001/TEST_REPORT_0.13.001.md`.
