"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — núcleo (constructor + eventos Qt de alto nivel); el resto de la clase vive en frontend/main_window/ (mixins por responsabilidad).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization_common import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_common import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, LCDSignalMeterWidget,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




from lorito_aldhiro.frontend.main_window.lorito_mw_session_startup import SessionStartupMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_telemetry import TelemetryMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_optape_menu import OptapeMenuMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_ui_build import UiBuildMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_recording import RecordingMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_silence_autopause import SilenceAutopauseMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_playback import PlaybackMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_export import ExportMixin
from lorito_aldhiro.frontend.main_window.lorito_mw_tau import TauMixin
from lorito_aldhiro.backend.playback.lorito_reel_kinematics import ReelKinematics


class LoritoAldhiroStudio(SessionStartupMixin, TelemetryMixin, OptapeMenuMixin, UiBuildMixin, RecordingMixin, SilenceAutopauseMixin, PlaybackMixin, ExportMixin, TauMixin, QWidget):
    # FIX-CANVAS-HEIGHT (pedido explícito del usuario): H bajó de 710 a
    # 630 — la altura anterior se había ampliado específicamente para
    # que la vieja megacelda de señal (la onda, misma altura
    # que el contómetro) cupiera como bloque hermano independiente. El
    # panel fusionado (`CounterMegapanel`) reparte ahora ese mismo
    # espacio con una megacelda inferior de solo 1/4 de la altura
    # superior, así que el excedente se retira del lienzo en vez de
    # dejarlo como espacio muerto.
    #
    # 0.12 (pedido de la usuaria): el cuerpo de madera es el contenedor de
    # todos los elementos. Un marco de madera de 16 px rodea los widgets y
    # deja ver las escuadras de latón de las cuatro esquinas, también las
    # superiores, que la barra de menús cubría. La barra pasa a ser una
    # placa flotante (SVG de la usuaria) y el lienzo crece ligeramente
    # (1040×630 → 1072×674) para conservar la altura del LCD.
    W = 1072; H = 674

    # ── Carretes del LCD (0.11.011) ───────────────────────────────────────
    # `_cassette_angle` (ángulo del transporte: reproducción, Velocista,
    # Morpher, Seek) vive en la cinemática de los carretes, que es quien
    # orquesta el giro; se conserva el nombre por los arrastres del Seek.
    @property
    def _cassette_angle(self) -> float:
        return self.reels.transport_angle

    @_cassette_angle.setter
    def _cassette_angle(self, value: float) -> None:
        self.reels.transport_angle = float(value) % 360.0

    def __init__(self):
        super().__init__()
        self.setFixedSize(self.W, self.H)
        self.setWindowTitle(f"{APP_BRAND} {_version_label()}")

        # ── Engine de captura ──────────────────────────────────────────────
        self._engine = CaptureEngineV2()
        # Bitácora forense de proceso (Orden UI/ITL LOG-01): almacenamiento
        # primario de eventos; el widget de estado es solo una vista.
        from lorito_aldhiro.backend.telemetry import get_process_event_log
        self._event_log = get_process_event_log()
        self._engine.event_log = self._event_log
        # Coordinador NR (§GAP-011/GAP-012): selección de perfil expuesta al
        # menú NR/OPTAPE, conectado al drain loop real de CaptureEngineV2
        # (fuera del hilo RT del callback de audio — ver GAP-012 §2).
        self._nr_coordinator = NRCoordinator(sample_rate=48000, channels=2, mode="DECODE")
        # Orden SERVO-016 §7: kernels JIT de todas las etapas precompilados en
        # segundo plano (ni la GUI ni el hilo de drenado compilan al activar).
        threading.Thread(target=NRCoordinator.warm_up_all, daemon=True,
                         name="dsp-warmup").start()
        # Conectar el coordinador al motor de captura real (§GAP-012) — el
        # drain loop (fuera del hilo RT, ver _drain_loop_fn) lo consulta en
        # cada batch. Reasignar la MISMA instancia tras cada _build() de
        # self._nr_coordinator no es necesario: es el mismo objeto, sus
        # cambios internos (select/set_hx_pro/set_alc) ya son visibles.
        self._engine.nr_coordinator = self._nr_coordinator

        # ── Motor de monitorización de señal en tiempo real
        # (§lorito_monitor_engine, pedido explícito del usuario) — Lorito
        # Aldhiro no tiene panel izquierdo de botones físicos de monitor,
        # así que vive en la barra de menú ("MONITOR": Stereo/Mono L/
        # Mono R/Desactivado). Conectado al mismo callback RT de entrada
        # que ya copiaba a `_monitor_block` sin consumidor real.
        self._monitor_engine = MonitorEngine(sample_rate=48000, channels=2)
        self._engine.monitor_engine = self._monitor_engine
        self._monitor_mode_cycle = ["STEREO", "MONO_L", "MONO_R"]  # MON 1/2/3
        global _status
        _status = self._engine.get_status()  # v0.22.00: status redirected to new engine

        # ── Streaming player (v0.07: reemplaza raw_cache gigante) ─────────
        self._player = PlaybackEngine()

        # Propiedades de estado
        # _raw_cache ELIMINADO en v0.07 — el audio vive siempre en disco
        self._cache_rate     = 48000
        self._blink_state    = False
        self._rec_start_t    = 0.0
        self._rec_elapsed    = 0.0
        self._playing        = False
        self._play_start_wall= 0.0
        self._play_offset    = 0.0
        self._play_lock      = threading.Lock()
        self._play_generation= 0
        self._scrub_pending  = None
        self._scrub_parked_offset = None   # FIX-SCRUB-PLAY-POS: offset en segundos guardado al mover el scrub sin reproducción activa
        self._ui_state       = "standby"
        self._play_vu_l      = 0.0
        self._play_vu_r      = 0.0
        # VU suavizado de grabación — calculado en _tick() (15Hz), leído en
        # _tick_cassette() (24Hz) para repaint fluido sin duplicar cálculo de audio.
        self._rec_vu_l       = 0.0
        self._rec_vu_r       = 0.0
        self._rec_vu_active  = False   # True cuando hay señal de grabación
        self._speed_ratio    = 1.0
        self._morpher_ratio  = 1.0
        self._morpher_reverse= False
        self._morpher_active  = False  # True cuando el scrub morpher está siendo movido
        self._speed_scrub_active = False  # True cuando el scrub de velocidad está siendo movido
        self._play_src_pos   = 0.0
        self._disk_tmp_path  = None
        self._pending_close_after_export = False   # True durante cierre diferido post-export
        self._crash_recovery_ran         = False   # True si este arranque procesó un crash
        self._seek_params    = None   # (tmp, sr, ch, start_frame, total_secs, frac)

        # ── Auto-pausa por silencio — detector multi-criterio (v0.20.2) ─────
        # Estado COMPLETAMENTE INDEPENDIENTE de la pausa manual (_engine.paused).
        # La auto-pausa llama a _engine.pause(True) igual que toggle_pause, pero
        # se rastrea por separado para poder desactivarla sin confundirla con la
        # pausa manual del usuario.
        self._silence_autopause_enabled = True   # siempre habilitada (panel toggle eliminado)
        self._silence_start_t           = None   # monotonic del primer bloque silencioso
        self._silence_autopause_active  = False  # True = auto-pausa en curso
        # Ventana deslizante para análisis de 800 ms @ 15 Hz
        self._sil_win_rms_sq            = 0.0    # suma acumulada de RMS² en la ventana
        self._sil_win_peak              = 0.0    # peak máximo en la ventana actual
        self._sil_win_ticks             = 0      # ticks acumulados en la ventana
        self._sil_win_ticks_total       = 0      # ticks totales por ventana (calculado en start)
        # Histéresis de salida: umbral de release = RMS_THRESH + HYST
        self._sil_in_silence            = False  # True = detector considera silencio activo

        # ── CRAC: Reference noise floor adaptativo ───────────────────────────
        # Calibración inicial (primeros SILENCE_CALIB_SECS de grabación):
        #   acumular RMS y peak para calcular reference_rms / reference_peak.
        # Noise tracking lento (EMA τ = SILENCE_NOISE_TRACK_TAU):
        #   actualizar reference_rms/peak gradualmente mientras se graba.
        self._sil_calib_rms_sq     = 0.0    # suma RMS² durante calibración
        self._sil_calib_peak       = 0.0    # peak máximo durante calibración
        self._sil_calib_ticks      = 0      # ticks válidos acumulados en calibración
        self._sil_calib_ticks_total = 0     # ticks totales (incluyendo señal activa)
        self._sil_calib_done       = False  # True cuando calibración completó
        self._sil_ref_rms_lin      = None   # reference_rms en lineal (None = fallback)
        self._sil_ref_peak_lin     = None   # reference_peak en lineal (None = fallback)
        self._sil_ceiling_ref      = None   # techo de silencio capturado al primer REC
                                            # = peak máximo observado durante calibración
                                            # (todos los ticks, sin filtro de techo fijo)
                                            # coincide con el techo visible en el visualizador
        self._sil_ema_alpha        = None   # coeficiente EMA (calculado al init rate)

        # ── CRAC-PROFILE: clasificador de perfil espectral (v0.20.7) ─────────
        # Determina el tiempo de silencio antes de activar la pausa automática:
        #   "A" → 10 s  (hum grave / deck sin cinta — muestra.wav)
        #   "B" → 60 s  (hiss cassette / cinta en silencio — muestra1.wav)
        #   None → sin clasificar, usa SILENCE_AUTOPAUSE_SECS_B (conservador = 60 s)
        self._sil_profile          = None   # perfil actual: "A", "B" o None
        self._sil_profile_conf_a   = 0.0    # confianza EMA del perfil A (0.0–1.0)
        self._sil_profile_conf_b   = 0.0    # confianza EMA del perfil B (0.0–1.0)
        self._sil_profile_tick_ctr = 0      # OPT-PROFILE-DEBOUNCE: contador de ticks para clasificación espectral
        # OPT-FFT-CACHE: caché del rfftfreq y sc_mask del spectral gate (evita recreación en cada tick 15Hz)
        self._sil_fft_cached_n  = 0
        self._sil_fft_sc_mask   = None
        # OPT-SCIPY-ELIM: caché de ventana Hann para _crac_classify_profile
        self._prof_hann_n       = 0
        self._prof_hann         = None
        self._prof_freqs        = None

        # ── CRAC Failsafe: cooldown y límite de frecuencia de pausa ──────────
        self._sil_last_pause_t     = 0.0    # monotonic de la última auto-pausa
        self._sil_pause_times      = deque(maxlen=SILENCE_MAX_PAUSES_PER_MIN + 2)  # OPT-PAUSE-DEQUE: deque acotado elimina list comprehension en hot path 15Hz

        # v0.07: speed cache ELIMINADA — resampleo siempre chunked en StreamingPlayer
        self._speed_cache       = None
        self._speed_cache_ratio = None
        self._speed_cache_lock  = threading.Lock()
        self._speed_cache_gen   = 0

        # Duración total del archivo temporal (en frames y segundos)
        self._disk_total_frames = 0
        self._disk_total_secs   = 0.0

        # ── v0.08 estado ──────────────────────────────────────────────────
        self._archival_safe   = False          # modo Archival Safe activo
        self._drift_t0        = 0.0            # monotonic al inicio de grabación
        self._drift_check_t   = 0.0            # último chequeo de drift
        self._snapshot_t      = 0.0            # último snapshot guardado
        self._preroll_secs    = PREROLL_SECS   # segundos de pre-roll
        self._session_codec   = "WAV"          # codec actual para snapshot

        # Advertencias de scheduler Linux (mostradas una vez al inicio)
        _sched_warns = _check_scheduler_warnings()
        for w in _sched_warns:
            _log.warning("Scheduler: %s", w)

        # Timers Qt
        self._speed_cache_timer = QTimer(self)
        self._speed_cache_timer.setSingleShot(True)
        self._speed_cache_timer.timeout.connect(self._trigger_speed_cache)

        self._scrub_timer = QTimer(self)
        self._scrub_timer.setSingleShot(True)
        self._scrub_timer.timeout.connect(self._scrub_commit)

        # Timer de parpadeo para leyenda de normalización (250ms)
        self._norm_blink_timer = QTimer(self)
        self._norm_blink_timer.setInterval(250)
        self._norm_blink_timer.timeout.connect(
            lambda: self.status_label.setText("__NORM_BLINK_TICK__")
        )

        self._cafe_blink_timer = QTimer(self)
        self._cafe_blink_timer.setInterval(250)
        self._cafe_blink_timer.timeout.connect(self._on_cafe_blink_tick)

        # Timer de parpadeo CAROLA DELICADA (drift frames) — 400 ms por fase
        # Alterna verde brillante ↔ color original del error a 400 ms para que
        # el parpadeo sea claramente visible sin resultar agresivo.
        self._drift_frames_blink_timer = QTimer(self)
        self._drift_frames_blink_timer.setInterval(400)
        self._drift_frames_blink_timer.timeout.connect(
            lambda: self.status_label.setText("__DRIFT_FRAMES_TICK__")
        )

        # ── Timer de parpadeo para modo CAROLA TE ESTA ESPERANDO ─────────────
        # Completamente independiente del _cafe_blink_timer (pausa manual).
        self._carola_waiting_blink_timer = QTimer(self)
        self._carola_waiting_blink_timer.setInterval(SILENCE_BLINK_INTERVAL_MS)
        self._carola_waiting_blink_timer.timeout.connect(self._on_carola_waiting_blink)

        # Timer de parpadeo de desbordamiento "TU CINTA ES MUY LARGA... UPS!!"
        # FIX-OVERFLOW-BLINK-SYNC (v0.22.49): intervalo idéntico a SILENCE_BLINK_INTERVAL_MS
        # (480 ms) para que el ritmo sea exactamente igual al de la leyenda de autopause.
        # Independiente de _carola_waiting_blink_timer — el overflow puede ocurrir
        # durante grabación activa (sin autopause), cuando ese timer no corre.
        self._overflow_blink_timer = QTimer(self)
        self._overflow_blink_timer.setInterval(SILENCE_BLINK_INTERVAL_MS)
        self._overflow_blink_timer.timeout.connect(self._on_overflow_blink_tick)

        # ── Timer de animación de cassette (~24 fps = 42ms)
        # Cinemática de los carretes del LCD: la comparten los paneles de
        # cinta, el timer de cassette, el Seek y el LCD (0.11.011).
        self.reels = ReelKinematics()
        self._cassette_angle      = 0.0    # grados acumulados
        self._cassette_blink_st   = False  # estado de parpadeo para drift
        self._cassette_blink_ctr  = 0      # contador de ticks para parpadeo
        self._cassette_prev_mode  = None   # OPT-CASSETTE-DIRTY: modo previo
        # _timer_cassette: QTimer ejecutado en el main/GUI thread.
        # Todos los update() disparados desde _tick_cassette() son seguros
        # en Wayland nativo porque ocurren en el mismo thread del event loop.
        self._timer_cassette = QTimer(self)
        self._timer_cassette.setInterval(42)
        self._timer_cassette.timeout.connect(self._tick_cassette)
        self._timer_cassette.start()

        # Timer de parpadeo CAROLACAPTURE SE DURMIÓ (stream_sleep) — 400 ms
        # Alterna rosa intenso (#FF1493) ↔ rojo intenso (#FF0020)
        self._stream_sleep_blink_timer = QTimer(self)
        self._stream_sleep_blink_timer.setInterval(400)
        self._stream_sleep_blink_timer.timeout.connect(
            lambda: self.status_label.setText("__STREAM_SLEEP_TICK__")
        )

        # ── Variables de seguimiento del RBA (anti-skip buffer) ──────────────
        # Se usan en _update_internal_status para detectar tendencia llenando/
        # vaciando y emitir CAROLA LLEVA EL VASITO / CAROLA SE LE ACABA EL VASITO.
        # _rba_prev_wm   : watermark anterior (0.0–1.0) para calcular tendencia
        # _rba_vasito    : estado actual del vasito ("none"|"llena"|"vacia")
        # _rba_tick_count: contador de ticks consecutivos en la misma tendencia
        #                  (histéresis: se necesitan ≥3 ticks para cambiar estado)
        self._rba_prev_wm    = -1.0   # -1 = sin lectura previa
        self._rba_vasito     = "none"
        self._rba_tick_count = 0

        # Timer de parpadeo CAROLA ESTÁ APROBANDO (export_validating) — 350 ms
        # FIX-VALIDATING-TIMER (v0.22.09): el timer ahora vive en StatusDisplay.
        # Aquí solo mantenemos un alias para que _on_backend_status lo pueda
        # controlar sin cambiar su código (start/stop pasan directamente al widget).
        # self._export_validating_blink_timer → status_label._export_validating_blink_timer

        # ── Señales del backend ────────────────────────────────────────────
        _bridge.status_msg.connect(self._on_backend_status)
        _bridge.recovery_msg.connect(self._on_recovery_msg)
        _bridge.stream_died.connect(self._on_stream_died)
        _bridge.stop_ready.connect(self._on_stop_ready)
        _bridge.seek_ready.connect(self._on_seek_ready)
        _bridge.play_done.connect(self._on_play_done_signal)   # v0.19: thread-safe play cleanup
        _bridge.rec_engine_ready.connect(self._on_rec_engine_ready)  # v0.20.24: apertura sin freeze
        _bridge.export_progress.connect(self._on_export_progress)
        _bridge.master_cell.connect(lambda on: self.clock.set_cell_lit("MASTER", bool(on)))    # v0.22.10: diálogo CracSave
        _bridge.waveform_snapshot.connect(self._on_waveform_snapshot)  # VIEW-SIGSEGV-019
        self._tau_init()                                              # LA-TAU-OI-001
        _bridge.vu_ready.connect(self._on_vu_ready)                  # WAYLAND-NATIVE: VU en main thread
        _bridge.tape_update.connect(self._on_tape_update)            # WAYLAND-NATIVE: TapeLog en main thread

        self._crac_save_dlg: Optional[CracSaveDialog] = None   # diálogo activo de export
        # Directorio de salida configurable (§GAP-016 — LORITO EXPORTADOR).
        # Antes de esto Lorito Aldhiro exportaba siempre a ARCHIVE_DIR sin
        # poder elegirlo; CRAC sí tenía este selector en su panel MANUAL.
        self._export_output_dir = ARCHIVE_DIR

        # ── Fondo ──────────────────────────────────────────────────────────
        # Lienzo crema vintage con aspecto de madera pulida (§FONDO DEL
        # LIENZO, pedido explícito del usuario): a diferencia de CRAC,
        # Lorito Aldhiro NO lleva imagen de fondo dinámica ni el tema
        # derivado por k-means — se pinta un fondo estático y se aplica
        # el acento dorado lumínico fijo a THEME (mismo patrón de mutar
        # el dict in-place que usaba `build_theme_from_image`, para que
        # el cambio sea visible en todos los módulos que ya importan
        # `THEME`).
        from lorito_aldhiro.frontend.support.lorito_theme import apply_gold_vfd_accent
        from lorito_aldhiro.frontend.widgets.lorito_svg_panels import SvgCanvasBackground
        self.bg = SvgCanvasBackground(self)
        self.bg.setGeometry(0, 0, self.W, self.H)
        self.bg.lower()
        apply_gold_vfd_accent(THEME)

        self._build_ui()


        # ── Apertura inicial: TODOS los scrubs inhabilitados ──────────────────
        # Se habilitan progresivamente solo cuando el estado lo permite
        # (_sync_buttons los gestiona; aquí forzamos el estado inicial correcto).
        self.speed_scrub.setEnabled(False)
        self.morpher_scrub.setEnabled(False)
        self.scrub.setEnabled(False)

        # ── Timers GUI — CRAC: 15 Hz (67 ms) ────────────────────────────────────
        self._timer_vu = QTimer(self)
        self._timer_vu.timeout.connect(self._tick)
        self._timer_vu.start(SILENCE_ANALYSIS_INTERVAL_MS)   # 15 Hz — CRAC_UNIVERSAL_THRESHOLD_PROFILE

        self._timer_blink = QTimer(self)
        self._timer_blink.timeout.connect(self._blink)
        self._timer_blink.start(480)

        # ── Timer de redibujado de widgets visuales (15 Hz, sincronizado con _tick)
        # Centraliza update() de waveform/VU pendientes en el main thread.
        self._timer_vu_redraw = QTimer(self)
        self._timer_vu_redraw.timeout.connect(self._tick_vu_redraw)
        self._timer_vu_redraw.start(67)   # 15 Hz — mismo intervalo que _timer_vu

        # ── Timer de estado interno (1 Hz) ────────────────────────────────
        self._timer_status = QTimer(self)
        self._timer_status.timeout.connect(self._update_internal_status)
        self._timer_status.start(1000)

        # ── Timer de snapshots / drift (5 Hz chequeo, acción a intervalos) ─
        self._timer_archival = QTimer(self)
        self._timer_archival.timeout.connect(self._archival_tick)
        self._timer_archival.start(5000)   # cada 5 s

        self._update_codec_ui()
        self._sync_buttons()

        # ── Atajos de teclado globales (QShortcut) ────────────────────────────
        # FIX-KEY-R (v0.22.18): keyPressEvent en QWidget solo se dispara si la
        # ventana tiene el foco del teclado. Como QPushButton y QComboBox hijos
        # tienen StrongFocus por defecto, el foco nunca llega al widget raíz y
        # la tecla R (y el resto) quedaban sordos al 100%.
        #
        # QShortcut con Qt.WindowShortcut (default) se activa siempre que la
        # VENTANA esté activa, independientemente de qué widget hijo tenga el
        # foco. Es la forma correcta de implementar atajos globales en Qt.
        #
        # El keyPressEvent original se conserva como respaldo para el caso en
        # que la ventana misma tenga el foco (e.g. tras hacer clic en el fondo).
        def _sc(seq, slot):
            s = QShortcut(QKeySequence(seq), self)
            s.setContext(Qt.WindowShortcut)   # activo mientras la ventana esté activa
            s.activated.connect(slot)
            return s

        self._sc_rec    = _sc("R", lambda: self.start_record()   if self.btn_record.isEnabled() else None)
        self._sc_pause  = _sc("P", lambda: self._tau_click_pause() if self.btn_pause.isEnabled() else None)
        self._sc_stop   = _sc("Space", lambda: self._toggle_play_stop())
        self._sc_export = _sc("S", lambda: self.export()         if self.btn_export.isEnabled() else None)
        # FIX-KEY-E (v0.22.54): tecla E/e actúa como doble clic en STOP —
        # detiene la reproducción si está activa y retorna el scrub al inicio.
        # Equivalente a mouseDoubleClickEvent de ScrubBarPlay o doble Space.
        # Uso: E mientras está reproduciendo → stop + scrub a 0.
        #      E estando detenido → scrub a 0 (listo para Play desde inicio).
        self._sc_eject  = _sc("E", lambda: self._scrub_reset_to_start())
        # ─────────────────────────────────────────────────────────────────────

        # ── CrashGuard: verificar si hubo un crash en la sesión anterior ──
        # Se lanza diferido (100 ms) para que la ventana esté completamente
        # visible antes de mostrar el diálogo de recuperación.
        if CrashGuard.is_crash_pending():
            QTimer.singleShot(100, self._check_crash_recovery)

        # ── Bienvenida: primer arranque limpio (sin crash, sin búfer) ────────
        # Se lanza diferido (150 ms). Solo se muestra si no hay crash pendiente
        # ni audio en el búfer; en esos casos _check_informacion_patrimonial o
        # _check_crash_recovery toman el control y la bienvenida se suprime.
        if not CrashGuard.is_crash_pending():
            QTimer.singleShot(150, self._check_bienvenida)

        # ── Información patrimonial: verificar si hay audio guardado ─────────
        # Se lanza diferido (200 ms) para que la ventana esté visible y,
        # si hay crash recovery, se ejecuta después (150 ms de margen).
        QTimer.singleShot(200, self._check_informacion_patrimonial)
    def closeEvent(self, event):
        # ── Guardia 1: bloqueo total durante estados activos ──────────────────
        # Cuando se está grabando, en pausa (manual o auto), vaciando el búfer,
        # reproduciendo la señal del búfer o exportando el archivo, el cierre
        # de la ventana está completamente inhibido.
        # En su lugar se muestra CarolaNooDialog y se devuelve el foco a la app.
        _esta_grabando      = self._engine.recording
        _esta_pausado       = self._engine.paused
        _esta_autopausado   = getattr(self, "_silence_autopause_active", False)
        _esta_vaciando      = (self._ui_state == "stop")
        _esta_reproduciendo = getattr(self, "_playing", False)          # [FIX-CLOSE-PLAY]
        _esta_exportando    = (self._ui_state == "export")              # [FIX-CLOSE-EXPORT]

        if (_esta_grabando or _esta_pausado or _esta_autopausado
                or _esta_vaciando or _esta_reproduciendo or _esta_exportando):
            event.ignore()
            CarolaNooDialog(self).exec()
            return

        # ── FF/REW (Orden TRANSPORT-018 §6): al cerrar, el motor pasa a estado
        # seguro (cancelado) y se detiene su temporizador.
        _tc = vars(self).get("_transport")
        if _tc is not None:
            _tc.shutdown()
            self._wind_timer.stop()

        # Orden VIEW-SIGSEGV-019 (SIG-03): cierre ordenado del visor — los
        # snapshots en vuelo quedan invalidados y no se aplican a un widget
        # que se destruye.
        if hasattr(self, "waveform") and hasattr(self.waveform, "mark_closed"):
            self.waveform.mark_closed()
        # LA-TAU-OI-001: TAU se apaga y la leyenda queda limpia al cerrar.
        self._tau_shutdown()

        # ── Guardia 2: solo mostrar el diálogo si hay señal capturada ─────────
        # Condición: existe archivo temporal con contenido de audio válido.
        # FIX-CLOSE-RECOVERY (v0.22.54): antes se usaba _status.frames_written > 0,
        # que es 0 en sesiones recuperadas de crash o guardado limpio (porque no se
        # grabó nada nuevo). Al abrir con recovery y cerrar sin grabar, el diálogo
        # CierreAbruptoDialog nunca aparecía y el archivo se descartaba en silencio.
        # La condición correcta es _has_audio(), que verifica que el archivo tmp
        # exista en disco y tenga contenido (>512 bytes), cubriendo tanto sesiones
        # grabadas en esta sesión como archivos restaurados desde crash/guardado limpio.
        _hay_grabacion = self._has_audio()

        if _hay_grabacion:
            dlg = CierreAbruptoDialog(self)
            dlg.exec()
            res = dlg.resultado()

            if res == CierreAbruptoDialog.GUARDAR:
                # "No" — PRESERVAR el búfer para procesarlo en el próximo arranque.
                # FIX-PRESERVE-TMP (v0.22.09): en lugar de exportar ahora, dejamos
                # el archivo temporal intacto en disco y escribimos un manifest de
                # crash-recovery para que al volver a abrir la interfaz lo encuentre
                # cargado y listo para exportar, idéntico al flujo de crash recovery.
                if self._engine.recording:
                    # Orden Golden de Captura: cierre en fases completo
                    # (drain → flush_barrier/fsync → verificación → clasificación).
                    self._engine.finalize()
                # GAP-038 — defecto real corregido: esta rama NUNCA detenía
                # `_disk_writer` (el comentario de la rama DESCARTAR, más
                # abajo, afirmaba falsamente que `engine.stop()` ya lo hacía
                # internamente — no es así, `CaptureEngineV2.stop()` nunca
                # llamó a `_disk_writer.stop()`). Sin este fix, el hilo de
                # escritura seguía vivo (daemon) al cerrar la app — la
                # misma clase de condición de carrera al cerrar con
                # "motores corriendo" que CRAC saneó (ver
                # `wait_for_pending_stream_close`/`FIX-CIERRE-FATAL-
                # DEFERRED-CLOSE`) — y, más grave todavía: la duración leída
                # más abajo podía quedar TRUNCADA si aún había frames sin
                # volcar a disco en el momento de escribir el manifest de
                # recovery. `DiskWriterV2.stop()` ya es seguro ante doble
                # llamada (FIX-STOP-RACE) — se llama aquí sin condición.
                self._engine._disk_writer.stop()
                # Escribir manifest de recovery apuntando al tmp actual
                _tmp  = self._disk_tmp_path
                _rate = getattr(self, "_cache_rate", 48000)
                _secs = getattr(self, "_disk_total_secs", 0.0)
                try:
                    _dur = _secs
                    if _dur <= 0 and _tmp and os.path.exists(_tmp):
                        with sf.SoundFile(_tmp, "r") as _sf:
                            _dur = _sf.frames / max(_sf.samplerate, 1)
                    _manifest_data = {
                        "tmp_file":       _tmp or "",
                        "samplerate":     _rate,
                        "duration_secs":  round(_dur, 3),
                        "codec_hint":     "WAV",
                        "opt1":           "",
                        "opt2":           "",
                        "norm":           "Sin normalizar",
                        "heartbeat_iso":  datetime.now().isoformat(),
                        "preserve_reason":"usuario eligio No en CierreAbruptoDialog",
                    }
                    _tmp_manifest = _MANIFEST_PATH + ".tmp"
                    with open(_tmp_manifest, "w", encoding="utf-8") as _mf:
                        json.dump(_manifest_data, _mf, ensure_ascii=False, indent=2)
                    os.replace(_tmp_manifest, _MANIFEST_PATH)
                    # Escribir heartbeat vacío para que CrashGuard.is_crash_pending() == True
                    with open(_HEARTBEAT_PATH, "w", encoding="utf-8") as _hf:
                        _hf.write(datetime.now().isoformat() + "\n")
                    _log.info(
                        "CierreAbruptoCRAC: búfer preservado para próximo arranque — %s", _tmp)
                except Exception as _me:
                    _log.error("CierreAbruptoCRAC: no se pudo escribir manifest: %s", _me)
                # NO limpiar _disk_tmp_path; NO llamar _crash_guard.stop()
                # El cierre continúa al bloque de cleanup final, que
                # salta el borrado del tmp (ver validación abajo).
                self._preserve_tmp_on_close = True   # señal para no borrar el tmp

            elif res == CierreAbruptoDialog.DESCARTAR:
                # "Sí" — cerrar sin guardar.
                if self._engine.recording:
                    self._engine.finalize()
                # GAP-038 — corregido: el comentario original (FIX-STOP-
                # DOUBLE, v0.22.04) afirmaba que `engine.stop()` ya llama
                # internamente a `_disk_writer.stop()` — confirmado FALSO
                # al auditar `CaptureEngineV2.stop()` (nunca lo hizo). Sin
                # esta llamada, el hilo de escritura de disco quedaba vivo
                # (daemon) mientras la app cerraba, y encima se intentaba
                # `os.remove()` el archivo temporal más abajo mientras ese
                # hilo podía seguir teniéndolo abierto. `DiskWriterV2.
                # stop()` ya es seguro ante doble llamada (guarda local
                # FIX-STOP-RACE) — no hay riesgo de reintroducir la
                # condición de carrera que ese fix buscaba evitar.
                self._engine._disk_writer.stop()
                # Eliminar archivo temporal para no dejar residuos
                _tmp = self._disk_tmp_path
                if _tmp:
                    try:
                        if os.path.exists(_tmp):
                            os.remove(_tmp)
                            _log.info("CierreAbruptoCRAC: grabación descartada (%s)", _tmp)
                    except Exception:
                        pass
                # Continuar con el cierre normal (cae al bloque de cleanup abajo)

            else:
                # El diálogo se cerró sin elección (no debería ocurrir)
                event.ignore()
                return

        else:
            # ── Segunda pasada post-export (GUARDAR) o cierre limpio sin grabación ──
            if getattr(self, "_pending_close_after_export", False):
                # El export terminó; limpiar flag y continuar cierre normal.
                self._pending_close_after_export = False
            # Detener limpiamente si el engine sigue activo
            if self._engine.recording:
                self._engine.stop()
            self._engine._disk_writer.stop()

        # Detener StreamingPlayer si está activo
        if self._playing:
            self._player.stop()
            self._playing = False

        # Log resumen de sesión
        _log.info("CIERRE — frames_received=%d frames_written=%d xruns=%d recoveries=%d  RAM=%.0f MB"
                  "  drift_ms=%.2f  drift_warns=%d  clips_L=%d clips_R=%d"
                  "  jitter_max=%.1f ms  jitter_avg=%.1f ms  disk_write_max=%.1f ms  disk_mbps=%.2f"
                  "  starvation_events=%d  rb_l1_max=%.0f%%  segments=%d  crc32_errors=%d"
                  "  psi_cpu=%.1f%%  psi_io=%.1f%%  psi_mem=%.1f%%",
                  _status.frames_received, _status.frames_written,
                  _status.xrun_count, _status.recovery_count, _status.ram_mb_approx,
                  _status.drift_ms, _status.drift_warn_count,
                  _status.clip_count_l, _status.clip_count_r,
                  _status.callback_jitter_ms, _status.callback_latency_avg_ms,
                  _status.disk_write_ms_max, _status.disk_mbps,
                  _status.starvation_events, _status.rb_l1_occupancy_pct,
                  _status.segment_count, _status.integrity_crc32_errors,
                  _status.psi_cpu_pct, _status.psi_io_pct, _status.psi_mem_pct)

        # Validación integridad post-cierre
        fr = _status.frames_received; fw = _status.frames_written
        if fr > 0 and fw > 0:
            diff = abs(fr - fw); pct = diff / max(fr, 1) * 100
            if pct > 0.5:
                _log.warning("Integridad post-cierre: recibidos=%d escritos=%d diff=%.2f%%",
                             fr, fw, pct)
            else:
                _log.info("Integridad post-cierre OK: diff=%.4f%%", pct)

        # Validar tamaño archivo temporal
        _preserve = getattr(self, "_preserve_tmp_on_close", False)
        if _preserve:
            # FIX-PRESERVE-TMP (v0.22.09): el usuario eligió "No" → el tmp se
            # conserva en disco con su manifest para el próximo arranque.
            # Solo registramos el path en el log; no tocamos ni borramos nada.
            _log.info("CierreAbruptoCRAC: archivo temporal preservado para recovery — %s",
                      self._disk_tmp_path)
        elif self._disk_tmp_path and os.path.exists(self._disk_tmp_path):
            sz = os.path.getsize(self._disk_tmp_path)
            expected_bytes = _status.frames_written * 2 * 4  # 2ch float32
            _log.info("Archivo tmp: %d bytes  esperado≈%d bytes  (%.2f s)",
                      sz, expected_bytes, self._disk_total_secs)
            # Limpiar archivo temporal si está vacío / residual
            try:
                if sz < 1024:
                    os.remove(self._disk_tmp_path)
                    _log.info("Archivo temporal residual eliminado")
            except Exception:
                pass

        # ── CrashGuard: limpiar heartbeat al cerrar limpiamente ──────────
        # Si el tmp fue preservado, el heartbeat ya fue escrito manualmente
        # en la rama GUARDAR y NO debe limpiarse aquí — de lo contrario
        # is_crash_pending() devolvería False en el próximo arranque.
        if not _preserve:
            _crash_guard.stop()

        # Liberación final de memoria
        with self._speed_cache_lock:
            self._speed_cache = None
        # OPT-06: gc.collect() eliminado — Python libera al exit sin costo RT

        # ── GAP-038 — última línea de defensa, incondicional ────────────
        # Igual que `wait_for_pending_stream_close()` en CRAC (llamado al
        # final de `handle_close_event`, en las TRES ramas): esperar aquí,
        # sin condición, a que los hilos de fondo del motor de captura
        # hayan terminado de verdad — por si algún camino de arriba
        # detuvo el motor sin pasar por `stop()`, o por robustez futura
        # si esta función cambia. Nunca bloquea indefinidamente (timeout
        # acotado); solo registra una advertencia si algún hilo sigue vivo.
        self._engine.wait_for_background_threads(timeout=5.0)

        event.accept()
    def keyPressEvent(self, event) -> None:
        """
        Atajos de teclado — respaldo cuando la ventana raíz tiene el foco.

        El mecanismo primario son los QShortcut declarados en __init__ con
        Qt.WindowShortcut. keyPressEvent solo se activa si ningún widget hijo
        (QPushButton, QComboBox, etc.) tiene el foco — lo cual es infrecuente
        en uso normal. Se conserva como capa de seguridad adicional.

        R     → Iniciar grabación  (equivale a btn_record)
        P     → Pausar / Reanudar grabación manual  (equivale a btn_pause)
        Space → Play / Stop toggle  (reproduce si hay audio; detiene si está reproduciendo)
        S     → Exportar archivo  (equivale a btn_export)

        FIX-KEY-R (v0.22.18): bug original — QWidget sin FocusPolicy nunca
        recibía keyPressEvent cuando algún widget hijo tenía el foco (siempre).
        Solución principal: QShortcut con Qt.WindowShortcut en __init__.
        """
        key = event.key()

        if key == Qt.Key_R:
            if self.btn_record.isEnabled():
                self.start_record()
            return

        if key == Qt.Key_P:
            if self.btn_pause.isEnabled():
                self.toggle_pause()
            return

        if key == Qt.Key_Space:
            self._toggle_play_stop()
            return

        if key == Qt.Key_S:
            if self.btn_export.isEnabled():
                self.export()
            return

        if key == Qt.Key_E:
            # FIX-KEY-E (v0.22.54): E → reset scrub al inicio (igual que doble clic)
            self._scrub_reset_to_start()
            return

        # Delegar el resto de teclas al comportamiento por defecto
        super().keyPressEvent(event)
