"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Reproducción: velocidad variable, scrub, Morpher, resampleo cúbico, caché de audio.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, CRAC_PROFILE_A_FLATNESS_MAX, CRAC_PROFILE_A_HISS_MAX, CRAC_PROFILE_A_SUBBASS_MIN, CRAC_PROFILE_A_ZCR_MAX, CRAC_PROFILE_B_FLATNESS_MIN, CRAC_PROFILE_B_HISS_MIN, CRAC_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization_common import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_common import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine, PE_MAX_RATIO
from lorito_aldhiro.backend.playback.lorito_speed_zone_labels import speed_zone_coded_name
from lorito_aldhiro.backend.playback.lorito_playback_scrub_sync import clamp_position_fraction, speed_status_text
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, CracInformacionPatrimonialDialog, CracRecuperandoDatClamitDialog, CracSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, LCDSignalMeterWidget,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_crac_motor_v4 import make_motor




class PlaybackMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    # ── Avance rápido / rebobinado (Orden LA-GOLDEN-TRANSPORT-018, 0.12) ──
    # Los botones ◀◀ y ▶▶ son comandos al TransportCoordinator
    # (`lorito_ffrew_motors`), dueño único del estado de transporte. Cada
    # pulsación sube el factor (×1 → ×2 → … → máximo → ×1). La dirección
    # contraria pasa por una parada confirmada. STOP pide la rampa de parada.
    # La UI solo pinta las instantáneas confirmadas: LCD ("Ff Wd > X{n}" /
    # "Rew < X{n}"), contador, scrub, onda y carretes. Monitor: MUTED_SCAN.
    # Si se partió de PLAY, la reproducción se suspende y se reanuda al
    # confirmarse la parada. Nunca durante la captura.
    WIND_INTERVAL_MS = 40

    # ── Cuentavueltas desde la posición confirmada (Orden VIEW-SIGSEGV-019 §5) ─
    def _publish_transport_counter(self, pos_s, moving: bool) -> None:
        """Lectura ESTIMADA del cuentavueltas desde la posición confirmada
        (reproductor o TransportCoordinator) con el modelo de la cinta
        seleccionada. Detenido: el valor queda congelado ("held")."""
        cv = vars(self).get("tape_counter")
        if cv is None or not hasattr(cv, "set_snapshot"):
            return
        from lorito_aldhiro.backend.playback.lorito_tape_counter_model import (
            TapeCounterModel, drums)
        from lorito_aldhiro.frontend.widgets.lorito_tape_counter import CounterSnapshot
        label = self.cassette_dur_box.currentText() if hasattr(self, "cassette_dur_box") else "C-60"
        panel = {"C-60": vars(self).get("tape_c60"), "C-90": vars(self).get("tape_c90")}.get(label)
        side_a = float(getattr(panel, "_side_a_secs", 0.0) or 0.0) if panel is not None else 0.0
        total = float(getattr(panel, "_total_secs", 0.0) or 0.0) if panel is not None else 0.0
        reading = TapeCounterModel(label, side_a, total).reading(pos_s)
        vals, rolls = drums(reading.value)
        cv.set_snapshot(CounterSnapshot(values=vals, roll=rolls,
                                        state="transport" if moving else "held",
                                        overflow=reading.overflow, label=label,
                                        quality=reading.quality, source="transport"),
                        "transport")

    def _ffrew(self):
        tc = vars(self).get("_transport")
        if tc is None:
            from lorito_aldhiro.backend.transport.lorito_ffrew_motors import (
                TransportCoordinator, LogicalFileAdapter)
            tc = TransportCoordinator(LogicalFileAdapter())
            self._transport = tc
        return tc

    def _ffrew_position_s(self) -> float:
        total = float(self._disk_total_secs or 0.0)
        if self._playing and self._player.is_active():
            return min(total, self._player.src_pos / max(self._cache_rate, 1))
        parked = vars(self).get("_scrub_parked_offset")
        return float(parked) if parked is not None else self.scrub._value * total

    def _ffrew_press(self, direction: int) -> bool:
        from lorito_aldhiro.backend.transport.lorito_ffrew_motors import TransportStatus as TS
        tc = self._ffrew()
        if self._engine.recording:
            tc.capture_started()
        elif tc.state == TS.CAPTURING:
            tc.capture_stopped()
        tc.set_inhibitor("morpher", bool(vars(self).get("_morpher_active", False)))
        tc.set_inhibitor("export", vars(self).get("_ui_state") == "export")
        was_playing = False
        if not tc.is_moving():
            sr = int(vars(self).get("_cache_rate") or 48000)
            total = float(self._disk_total_secs or 0.0) if self._has_audio() else 0.0
            tc.set_source(int(round(total * sr)), sr, int(round(self._ffrew_position_s() * sr)))
            was_playing = bool(self._playing and self._player.is_active())
            tc.set_playing(was_playing)
        res = tc.press(direction, playing=was_playing)
        if not res.accepted:
            self._ffrew_rejected(res)
            return False
        if was_playing:
            self._stop_playback_only()         # MUTED_SCAN: sin audio a velocidad nominal
        self._ffrew_last_ns = time.monotonic_ns()
        self.btn_stop.setEnabled(True)
        self._wind_timer.start()
        self._ffrew_apply(tc.tick())
        return True

    def _ffrew_rejected(self, res) -> None:
        from lorito_aldhiro.backend.transport.lorito_ffrew_motors import RejectReason as R
        texts = {
            R.CAPTURE_ACTIVE: "LORITO NO BOBINA: ESTÁ GRABANDO",
            R.NO_SOURCE: "LORITO NO BOBINA: NO HAY CINTA GRABADA",
            R.INHIBITED: "LORITO NO BOBINA: EL TRANSPORTE ESTÁ OCUPADO",
            R.EJECT_PENDING: "LORITO NO BOBINA: EXPULSIÓN EN CURSO",
            R.UNAVAILABLE: "LORITO: FUNCIÓN NO DISPONIBLE",
            R.ERROR_STATE: "LORITO: TRANSPORTE EN ERROR — PULSA STOP",
        }
        self.status_label.setText(texts.get(res.reason, "LORITO NO BOBINA"))
        # Inhibido por diseño → Fnc No Disp. Un fallo técnico NO usa ese overlay.
        if res.reason != R.ERROR_STATE and hasattr(self, "clock"):
            self.clock.showLcdOverlay("LCD_FNC_NO_DISP")

    def _wind_step(self) -> None:
        """Tick del bobinado (QTimer, 25 Hz): avanza el coordinador y pinta
        la instantánea confirmada (coalescida: solo la última)."""
        tc = vars(self).get("_transport")
        if tc is None:
            self._wind_timer.stop()
            return
        self._ffrew_apply(tc.tick())

    def _ffrew_apply(self, snap) -> None:
        from lorito_aldhiro.backend.transport.lorito_ffrew_motors import (
            TransportStatus as TS, MotorPhase as MP, LimitKind)
        if snap.total_frames:
            frac, pos_s = snap.fraction, snap.position_s
            self._publish_transport_counter(
                pos_s, snap.state in (TS.FAST_FORWARDING, TS.REWINDING))
            self._scrub_parked_offset = pos_s
            self.scrub.setValue(frac)
            self.waveform.setPlayPos(frac)
            if hasattr(self, "clock"):
                h, r = divmod(int(pos_s), 3600); m, sec = divmod(r, 60)
                self.clock.setText(f"{h:02d}:{m:02d}:{sec:02d}")
        moving = snap.state in (TS.FAST_FORWARDING, TS.REWINDING)
        key_prev = vars(self).get("_ffrew_overlay_key")
        if moving:
            now = time.monotonic_ns()
            dt = (now - vars(self).get("_ffrew_last_ns", now)) / 1e9
            self._ffrew_last_ns = now
            if hasattr(self, "reels"):
                self.reels.wind_transport(snap.rate, dt)
                if hasattr(self, "clock"):
                    self.clock.setReelView(*self.reels.view())
            key = (snap.direction, snap.factor)
            if key != key_prev and hasattr(self, "clock"):
                token = "LCD_FF_WD_X" if snap.direction > 0 else "LCD_REW_X"
                if key_prev is not None and key_prev[0] != snap.direction:
                    self.clock.showLcdOverlay("LCD_REW_X" if snap.direction > 0 else "LCD_FF_WD_X",
                                              active=False)
                self.clock.showLcdOverlay(token, factor=snap.factor)
            self._ffrew_overlay_key = key
            if snap.phase == MP.STOPPING:
                self.status_label.setText("LORITO DETIENE LA CINTA…")
            elif key != key_prev:
                self.status_label.setText(
                    f"LORITO {'AVANZA RÁPIDO ▶▶' if snap.direction > 0 else 'REBOBINA ◀◀'}"
                    f" ×{snap.factor}")
            return
        # Parada confirmada (o error): fin del bobinado.
        self._wind_timer.stop()
        if key_prev is not None and hasattr(self, "clock"):
            self.clock.showLcdOverlay("LCD_FF_WD_X" if key_prev[0] > 0 else "LCD_REW_X",
                                      active=False)
            self._ffrew_overlay_key = None
            if snap.state == TS.ERROR:
                self.status_label.setText(f"LORITO: ERROR DE TRANSPORTE — {snap.error}")
            elif snap.limit == LimitKind.END:
                self.status_label.setText("LORITO: LÍMITE ALCANZADO — FIN DE LA CINTA")
            elif snap.limit == LimitKind.START:
                self.status_label.setText("LORITO: LÍMITE ALCANZADO — INICIO DE LA CINTA")
            else:
                self.status_label.setText("LORITO DETUVO LA CINTA")
            if hasattr(self, "reels"):
                self.reels.advance_transport(None, 0.0)
            self._sync_buttons()
        if snap.resume_play:
            self.play_audio(offset=snap.position_s)

    def _toggle_play_stop(self) -> None:
        """
        Toggle Space: Play si hay audio disponible y no se está reproduciendo;
        Stop si se está reproduciendo o grabando.

        FIX-SPACE-PLAY (v0.22.19): Space antes solo llamaba a stop_all().
        Ahora actúa como toggle:
          · Si _playing=True  → stop_all() (igual que antes)
          · Si _playing=False → play_audio() si btn_play está habilitado
          · Durante grabación → stop_all() (comportamiento original preservado)

        FIX-SCRUB-DOUBLE-RESET (v0.22.43): doble Space (dos pulsaciones dentro
        de 300 ms) retorna el scrub al inicio automáticamente, igual que doble
        clic. Si estaba reproduciendo, detiene y posiciona en 0; si estaba
        detenido, solo posiciona el scrub en 0 sin arrancar Play.
        """
        now = time.monotonic()
        _last = getattr(self, "_last_space_t", 0.0)
        self._last_space_t = now

        # Doble Space: dos pulsaciones dentro de 300 ms → retorno al inicio
        if now - _last <= 0.30 and self._has_audio():
            self._scrub_reset_to_start()
            return

        # Pulsación simple: comportamiento normal
        # LA-TAU-OI-001: Space pasa por los mismos envoltorios que los botones.
        _stop = getattr(self, "_tau_click_stop", self.stop_all)
        _play = getattr(self, "_tau_click_play", self.play_audio)
        if self._playing:
            if self.btn_stop.isEnabled():
                _stop()
        else:
            if self.btn_play.isEnabled():
                _play()
            elif self.btn_stop.isEnabled():
                _stop()
    def _scrub_reset_to_start(self) -> None:
        """
        Retorna el scrub de reproducción al inicio (posición 0.0).
        Detiene la reproducción si estaba activa.
        Equivalente a doble clic en el ScrubBarPlay o doble Space.

        FIX-KEY-E (v0.22.54): este método centraliza la lógica de reset-a-inicio
        para que sea idéntica desde tres puntos de entrada:
          · Tecla E/e  (QShortcut + keyPressEvent respaldo)
          · Doble Space (_toggle_play_stop)
          · Doble clic en ScrubBarPlay (mouseDoubleClickEvent → onRelease(0.0)
            → _scrub_released(0.0))

        Comportamiento:
          · Si está reproduciendo → detiene SOLO la reproducción + scrub a 0.
          · Si está detenido      → solo scrub a 0 (sin iniciar Play).
          · En ambos casos: _scrub_parked_offset = None (próximo Play desde 0).
        """
        if not self._has_audio():
            return
        if self._playing:
            # Orden SERVO-016 §7: un gesto del servo detiene SOLO la
            # reproducción; jamás la captura (antes llamaba a stop_all()).
            self._stop_playback_only()
            self._sync_buttons()
        # Resetear scrub a inicio en cualquier caso
        self._scrub_parked_offset = None
        self.scrub.setValue(0.0)
        self.waveform.setPlayPos(0.0)
    # NOTA (GAP-070, FASE 7): `_resample_full_cubic()`/`_resample_block_
    # cubic()` (interpolación cúbica Catmull-Rom, calco de la del propio
    # `PlaybackEngine`) fueron retirados de aquí — código muerto sin
    # ningún llamador real ni cobertura de test, confirmado con dos
    # auditorías independientes (GAP-062 y GAP-070, ambas con búsqueda
    # exhaustiva en todo el árbol). Ver el docstring de
    # `backend/playback/lorito_speed_zone_labels.py` para el detalle
    # completo del hallazgo y la decisión de retiro.
    # NOTA (Orden Golden de Exportación, Fase 6): `_get_audio()` y
    # `_apply_normalization()` — lectura de la sesión COMPLETA a RAM +
    # normalización sobre el array global — retirados: código muerto sin
    # llamadores y prohibido por el escaneo estático de retiro legado.
    def _invalidate_speed_cache(self):
        """v0.07: La 'cache' es solo el ratio actual del StreamingPlayer."""
        with self._speed_cache_lock:
            self._speed_cache       = None
            self._speed_cache_ratio = None
            self._speed_cache_gen  += 1
    def _trigger_speed_cache(self):
        """
        v0.07: No pre-genera ningún array.
        Si hay reproducción activa, actualiza el ratio del StreamingPlayer.
        El resampleo ocurre chunked en tiempo real en StreamingPlayer.
        """
        ratio = self._speed_ratio
        with self._speed_cache_lock:
            self._speed_cache_ratio = ratio
        # Si está reproduciendo, actualizar speed en vivo
        if self._playing:
            self._player.set_speed(ratio)
            _log.debug("Speed ratio actualizado en vivo: ×%.3f", ratio)
        else:
            _bridge.status_msg.emit(
                f"__CAROLAMOTION_SPEED__LORITO PICOTEA EL CASSETTE ×{ratio:.2f} — {_carol_speed_label(ratio)}")
    def _get_cached_audio(self):
        """v0.07: No hay cache de array. Siempre devuelve (None, rate, False)."""
        return None, self._cache_rate, False
    def _on_speed_changed(self, ratio):
        """
        Handler único del velocista (SpeedScrubBar.onChanged).

        Arquitectura live/commit basada en el flag _drag del widget:
          · Durante drag (_drag=True)  → set_speed_live(): escribe ratio en
            _live_speed sin vaciar la cola → cero gaps, cero pops.
          · Al soltar   (_drag=False)  → set_speed(): flush limpio, restaura
            continuidad con el nuevo ratio permanente.

        Equivalente exacto al ScrubBar de Play:
          mouseMoveEvent → seek_to()    (sin reiniciar stream, sin pop)
          mouseRelease   → play_audio() (flush limpio de consolidación)
        """
        self._speed_ratio = ratio
        if not self.speed_scrub._enabled:
            return

        # FIX-HUB-GHOST (v0.22.41): unificar umbral neutro. Antes is_moving usaba
        # 0.005 y at_center usaba 0.002 → banda muerta [0.002, 0.005) donde
        # at_center=True pero is_moving=True → _speed_scrub_active quedaba True
        # con el scrub en neutro visual → hub del cassette pintado permanentemente.
        _NEUTRAL_THRESH = 0.003
        is_moving = abs(ratio - 1.0) >= _NEUTRAL_THRESH
        if is_moving != self._speed_scrub_active:
            self._speed_scrub_active = is_moving
            self._sync_buttons()

        dragging = self.speed_scrub._drag   # True durante press+move, False en release

        # Overlay del contómetro — texto REAL de CRAC (corregido en esta
        # sesión: CRAC no muestra "x{ratio:.2f}" en el contómetro
        # principal para el Scrub Velocista — ese formato pertenece a
        # otra celda distinta, ver GAP-021. El overlay REAL del
        # contómetro es el nombre codificado de la zona de velocidad
        # (`_carol_speed_label()` + `SPEED_ZONE_DISPLAY_NAMES`,
        # auditado en esta sesión): CaLibrt/Aguilar/CromTn/SupRpdr/
        # VerLcha/JayaquTe/UltrJayaqute según el rango exacto de
        # `ratio`. Ciclo de vida (instrucción explícita del usuario):
        # mientras se arrastra, se actualiza en vivo; al soltar, el
        # overlay queda posicionado 4s (mismo mecanismo de timer
        # persistente stop()+start() que "Fnc No Disp" en CRAC — ver
        # `showFncNoDisp()`) y si se vuelve a tocar el control dentro
        # de esos 4s, el cronómetro se reinicia.
        if hasattr(self, "clock"):
            if is_moving:
                _coded = speed_zone_coded_name(ratio)
                if _coded:
                    self.clock.setOverlayFromRegistry("SCRUBS", True, _coded)
                if not hasattr(self, "_velocista_overlay_timer"):
                    self._velocista_overlay_timer = QTimer(self)
                    self._velocista_overlay_timer.setSingleShot(True)
                    self._velocista_overlay_timer.timeout.connect(
                        lambda: self.clock.setOverlay("SCRUBS", False))
                if dragging:
                    # Sigue arrastrando: cancelar cualquier cuenta atrás
                    # pendiente de una suelta anterior — el overlay se
                    # mantiene en vivo mientras dure el arrastre.
                    self._velocista_overlay_timer.stop()
                elif not self._velocista_overlay_timer.isActive():
                    # Acaba de soltarse (o el timer ya había expirado y
                    # se re-tocó): arrancar/reiniciar el margen de 4s.
                    self._velocista_overlay_timer.start(4000)
            elif not (hasattr(self, "_velocista_overlay_timer")
                      and self._velocista_overlay_timer.isActive()):
                # Vuelta a neutro sin cuenta atrás pendiente: apagar ya.
                self.clock.setOverlay("SCRUBS", False)

        at_center = not is_moving   # mismo umbral garantiza coherencia total

        # ── FORENSICS ────────────────────────────────────────────────────────
        _frn_emit("HANDLER_SPEED_CHANGED", {
            "ratio"    : round(ratio, 5),
            "dragging" : dragging,
            "at_center": at_center,
            "playing"  : self._playing,
            "will_call": "set_speed_live" if (dragging and self._playing) else
                         "set_speed"      if (not dragging and self._playing) else "none",
        })
        # ─────────────────────────────────────────────────────────────────────

        # Orden Golden SMV-11: la UI solo emite comandos semánticos; el
        # Transport Core es la única autoridad de cursor/ratio (se retiraron
        # las escrituras directas a `_ss.snap_pos`/`last_head_snap`).
        self._speed_drag_active = bool(dragging)

        if self._playing:
            # MIN_SPEED = 0.50: el ratio siempre es positivo (rango 0.50..2.00).
            # No se necesita abs() — el deslizador nunca emite valores negativos.
            target_ratio = 1.0 if at_center else ratio
            if dragging:
                # Drag continuo → SPEED_LIVE (coalescing explícito en el motor)
                self._player.set_speed_live(target_ratio)
            else:
                # Soltar → SPEED_COMMIT (transacción confirmada por el motor;
                # transición CONTINUA por slew, sin flush ni salto de cursor).
                self._player.set_speed(target_ratio)

            # FIX-MORPH-SPEED-SYNC (v0.22.41): sincronizar scrub de posición y
            # vista de onda con la posición real del player durante drag del velocista.
            # _tick_cassette ya lo hace a 24Hz, pero con drag activo el cambio de
            # velocidad puede desfasar el scrub visual; actualizamos aquí también.
            if not self.scrub._drag:
                try:
                    _total_f = self._disk_total_frames
                    _total_s = self._disk_total_secs
                    _cur_frac = clamp_position_fraction(
                        self._player.src_pos, _total_f, _total_s)
                    if _cur_frac is not None:
                        self.scrub.setValue(_cur_frac)
                        self.waveform.setPlayPos(_cur_frac)
                except Exception:
                    pass

            if at_center:
                self.status_label.setText("LORITO EN AURICULARES 🎧")
            else:
                self.status_label.setText(speed_status_text(ratio))
        else:
            # FIX-SCRUB-POP-GUARD (v0.22.41): sin reproducción activa, NO llamar a
            # ninguna función de audio del player — evita flushes sobre streams no
            # inicializados que producen pops al arrancar la siguiente reproducción.
            if not at_center:
                self.status_label.setText(speed_status_text(ratio))
    def _on_morpher_changed(self, ratio: float, reverse: bool, pos: float):
        """
        Handler único del morpher (MorpherScrubBar.onChanged).

        v0.20.21 — ARQUITECTURA DIRECTA:
          · Durante drag (_drag=True, pos≠0)  → set_speed_live(±ratio): live,
            sin flush. El prefetch lee _live_speed en el próximo ciclo.
          · Al soltar (_drag=False, pos=0.0)  → set_speed(speed_ratio): UN flush
            limpio de consolidación.

        FIX-ELASTIC-LIVE (v0.21.02):
          · Durante retorno elástico (_elastic_returning=True, pos≠0) →
            set_speed_live_noflush(±ratio): escribe live_ratio sin vaciar la cola.
            El prefetch lee el nuevo ratio en su ciclo natural (≤85ms latencia).
            Cero flushes durante el retorno → cero gaps → cero pops.
          · Al converger (_elastic_returning=False, pos=0.0, _drag=False) →
            set_speed() discreto: UN flush limpio.
        """
        if not self.morpher_scrub._enabled:
            return
        self._morpher_ratio   = ratio
        self._morpher_reverse = reverse

        dragging          = self.morpher_scrub._drag
        elastic_returning = getattr(self.morpher_scrub, '_elastic_returning', False)

        # Overlay del contómetro — texto REAL de CRAC (corregido en esta
        # sesión tras la indicación explícita del usuario, auditado
        # contra `mega_panel_controller.py`): "ScCue" en arrastre hacia
        # adelante, "ScRew" en reversa — NO el formato "x{ratio:.2f}"
        # (ese es un mecanismo distinto de CRAC, la "leyenda de factor
        # de arrastre" de una celda que Lorito Aldhiro no tiene, ver
        # GAP-021). Ciclo de vida: termina EXACTAMENTE al soltar el
        # control (`dragging=False`), no se extiende durante el retorno
        # elástico — instrucción explícita del usuario, a diferencia
        # del Scrub Velocista (que sí tiene un margen de 4s).
        _morpher_active = dragging
        self._morpher_scrub_active = dragging or elastic_returning
        if hasattr(self, "clock"):
            if _morpher_active:
                _token = "SC_REW" if reverse else "SC_CUE"
                self.clock.setOverlayFromRegistry("SCRUBS", True, _token)
            else:
                self.clock.setOverlay("SCRUBS", False)

        # Orden Golden SMV-05/SMV-11: retirados los parches de sincronía de
        # `snap_pos`/`_speed_change_evt` (FIX-ELASTIC-STALE-FLUSH,
        # FIX-MORPHER-SNAP, FIX-DIRECTION-CHANGE-SNAP). Con cursor absoluto
        # y comandos ordenados no existe un snap que pueda quedar viejo; la
        # inversión de dirección es continua a través de ratio 0.
        self._morpher_drag_active = bool(dragging)

        # ── FORENSICS ────────────────────────────────────────────────────────
        _frn_emit("HANDLER_MORPHER_CHANGED", {
            "pos"              : round(pos, 4),
            "ratio"            : round(ratio, 5),
            "reverse"          : reverse,
            "dragging"         : dragging,
            "elastic_returning": elastic_returning,
            "playing"          : self._playing,
        })
        # ─────────────────────────────────────────────────────────────────────

        if pos > 0.015:
            # Forward: aceleración
            if not self._morpher_active:
                self._morpher_active = True
                self._sync_buttons()
            if self._playing:
                if elastic_returning:
                    # Retorno elástico: NO flush, solo actualizar live_ratio
                    self._player.set_speed_live_noflush(ratio)
                else:
                    self._player.set_speed_live(ratio)
                # FIX-MORPH-SPEED-SYNC (v0.22.41): actualizar scrub de posición
                if not self.scrub._drag:
                    try:
                        _cf = clamp_position_fraction(
                            self._player.src_pos, self._disk_total_frames)
                        if _cf is not None:
                            self.scrub.setValue(_cf)
                            self.waveform.setPlayPos(_cf)
                    except Exception:
                        pass
            self.status_label.setText(f"__CAROLAMOTION_SCANNING__×{ratio:.3f}")

        elif pos < -0.015:
            # Reverse
            if not self._morpher_active:
                self._morpher_active = True
                self._sync_buttons()
            if self._playing:
                if elastic_returning:
                    self._player.set_speed_live_noflush(-ratio)
                else:
                    self._player.set_speed_live(-ratio)
                # FIX-MORPH-SPEED-SYNC (v0.22.41): actualizar scrub de posición
                if not self.scrub._drag:
                    try:
                        _cf = clamp_position_fraction(
                            self._player.src_pos, self._disk_total_frames)
                        if _cf is not None:
                            self.scrub.setValue(_cf)
                            self.waveform.setPlayPos(_cf)
                    except Exception:
                        pass
            self.status_label.setText(f"__CAROLAMOTION_SCANNING_REV__REV ×{ratio:.3f}")

        elif dragging:
            # Cruce de zona central durante drag activo: neutralizar SIN flush.
            # FIX-DEADZONE-NOFLUSH (v0.21.05): usar set_speed_live_noflush(1.0)
            # en lugar de set_speed_live(1.0).  set_speed_live dispara un flush
            # cada 80ms → gap audible al cruzar el centro durante drag continuo.
            # set_speed_live_noflush escribe live_ratio directamente sin vaciar
            # la cola → el prefetch recoge el nuevo ratio en su ciclo natural
            # (≤85ms) → cero gaps → cero pops en el cruce.
            # El path de noflush ya está probado y es el mismo que usa el retorno
            # elástico del morpher desde v0.21.02.
            _frn_emit("MORPHER_DEADZONE_DRAG", {
                "pos"    : round(pos, 5),
                "ratio"  : round(ratio, 5),
                "note"   : "cruce zona muerta → set_speed_live_noflush(1.0) — sin flush",
            })
            # ─────────────────────────────────────────────────────────────────
            if self._playing:
                # Cruce de zona central: SPEED_LIVE hacia ×1 (continuo).
                self._player.set_speed_live_noflush(1.0)

        else:
            # pos≈0 Y _drag=False Y elastic_returning=False:
            # snap/convergencia al centro — el ÚNICO momento de flush.
            # FIX-DOUBLE-COMMIT: los ticks elásticos con 0.012 ≤ |pos| < 0.015
            # caen aquí pero aún están retornando.  Solo ejecutar el flush
            # cuando el retorno terminó de verdad (elastic_returning=False).
            if elastic_returning:
                return
            # ── FORENSICS: flush de consolidación final ────────────────────
            _frn_emit("MORPHER_CONSOLIDATION_FLUSH", {
                "speed_ratio": round(self._speed_ratio, 5),
                "note"       : "retorno completo → set_speed(speed_ratio) — UN flush limpio",
            }, crit=True)
            # ─────────────────────────────────────────────────────────────────
            # FIX-HUB-GHOST (v0.22.41): limpiar _morpher_active incondicionalmente
            # (no solo si ya era True) para garantizar que el hub no quede pintado
            # aunque el flag haya llegado aquí en estado inconsistente.
            self._morpher_active  = False
            self._morpher_ratio   = 1.0
            self._morpher_reverse = False
            self._sync_buttons()
            if self._playing:
                # Convergencia final → SPEED_COMMIT al ratio del Velocista.
                self._player.set_speed(self._speed_ratio)
                # FIX-MORPH-SPEED-SYNC (v0.22.41): sincronizar scrub de posición
                # al consolidar el retorno del morpher.
                if not self.scrub._drag:
                    try:
                        _total_f = self._disk_total_frames
                        _total_s = self._disk_total_secs
                        _cur_frac = clamp_position_fraction(
                            self._player.src_pos, _total_f, _total_s)
                        if _cur_frac is not None:
                            self.scrub.setValue(_cur_frac)
                            self.waveform.setPlayPos(_cur_frac)
                    except Exception:
                        pass
                if abs(self._speed_ratio - 1.0) >= 0.005:
                    self.status_label.setText(speed_status_text(self._speed_ratio))
                else:
                    self.status_label.setText("LORITO EN AURICULARES 🎧")
    def play_audio(self, offset=None):
        """
        Inicia o hace seek en la reproducción streaming.
        NUNCA bloquea el GUI thread:
          · Si hay un player activo, lo señala para detenerse y delega
            el join() a un worker thread que emite seek_ready cuando termina.
          · Si no hay player activo, inicia directamente.
        offset: posición en segundos. None = usar scrub bar actual.
        """
        _tc = vars(self).get("_transport")
        if offset is None and _tc is not None and _tc.is_moving():
            _tc.stop(resume_play=True)     # PLAY durante el bobinado: parar y reanudar
            return

        tmp = self._disk_tmp_path
        if not tmp or not os.path.exists(tmp) or os.path.getsize(tmp) < 512:
            return

        total_secs   = self._disk_total_secs
        total_frames = self._disk_total_frames
        sr           = self._cache_rate

        if total_secs <= 0:
            self._probe_disk_file()
            total_secs   = self._disk_total_secs
            total_frames = self._disk_total_frames
            sr           = self._cache_rate
            if total_secs <= 0:
                return

        # Calcular posición de inicio
        if offset is None:
            # FIX-SCRUB-PLAY-POS (v0.22.41): si hay un offset guardado por el scrub
            # (usuario movió el scrub estando detenido), usarlo y consumirlo.
            # Así Play arranca desde donde el scrub fue posicionado, no desde 0.
            if not self._playing and self._scrub_parked_offset is not None:
                frac = max(0.0, min(1.0, self._scrub_parked_offset / total_secs))
                self._scrub_parked_offset = None   # consumir: un solo uso
            else:
                frac = self.scrub._value
        else:
            frac = max(0.0, min(1.0, offset / total_secs))
        start_frame = int(frac * total_frames)

        # Detectar canales del archivo (operación rápida: solo header)
        try:
            with sf.SoundFile(tmp, "r") as f:
                channels = f.channels
        except Exception:
            channels = 2

        # Guardar params del seek pendiente
        self._seek_params = (tmp, sr, channels, start_frame, total_secs, frac)

        if self._playing and self._player.is_active():
            # ── Orden Golden SMV-05/06: con player activo, el reposicionamiento
            # es un SEEK transaccional del Transport Core (supersede al
            # anterior, generación nueva, transición DIP declarada) — ya no se
            # mata el stream con `_muted`/`_stop_evt` ni se crea otro motor.
            self._seek_params = None
            self._player.seek_to(start_frame)
            self._play_offset = frac * total_secs
            if hasattr(self, "scrub"):
                self.scrub.setValue(frac)
            if hasattr(self, "waveform"):
                self.waveform.setPlayPos(frac)
        else:
            # ── Sin player activo: lanzar directamente ────────────────────────
            self._playing = False
            self._on_seek_ready()
    def _on_seek_ready(self):
        """
        Slot Qt — llamado en el GUI thread cuando el player anterior terminó.
        Lanza el nuevo StreamingPlayer con los parámetros del seek pendiente.
        """
        if not hasattr(self, '_seek_params') or self._seek_params is None:
            return
        # No lanzar reproducción si entretanto empezó una grabación
        if self._engine.recording:
            self._seek_params = None
            return
        tmp, sr, channels, start_frame, total_secs, frac = self._seek_params
        self._seek_params = None

        # Verificar que el archivo sigue disponible
        if not tmp or not os.path.exists(tmp) or os.path.getsize(tmp) < 512:
            return

        self._playing         = True
        self._play_generation += 1
        self._play_src_pos    = float(start_frame)
        self._play_offset     = frac * total_secs

        # FIX-SCRUB-PLAY-FROM-POS A (v0.22.50): anclar scrub y waveform en
        # la posición de inicio ANTES de que el primer tick de 24 Hz lea
        # player.src_pos. Sin esto, src_pos = 0 en el primer tick porque el
        # player aún no procesó el primer chunk de audio (~5-20 ms) → el tick
        # hace scrub.setValue(~0) → el scrub "parpadea" en 0 o arranca
        # visualmente desde 0 durante uno o dos frames, aunque el audio
        # arranca correctamente desde `frac`.
        # Se aplica tanto al CAROLALDHIRA ESCANEADOR (ScrubBarPlay) como a
        # la línea de posición del panel de forma de onda (WaveformWidget).
        if hasattr(self, "scrub"):
            self.scrub.setValue(frac)
        if hasattr(self, "waveform"):
            self.waveform.setPlayPos(frac)

        # Log al arrancar: leyenda púrpura si el velocista no está en neutro,
        # "CAROLALDHIRA PROBANDO" solo cuando la velocidad es exactamente ×1.00.
        if abs(self._speed_ratio - 1.0) >= 0.005:
            self.status_label.setText(
                f"__CAROLAMOTION_SPEED__LORITO PICOTEA EL CASSETTE ×{self._speed_ratio:.2f}"
                f" — {_carol_speed_label(self._speed_ratio)}")
        else:
            self.status_label.setText("LORITO EN AURICULARES 🎧")
        self.waveform.setMode("playback")
        self._sync_buttons()

        # Waveform en background (no bloquea)
        # OPT-07: worker persistente en lugar de Thread() efímero con lambda closure
        _waveform_worker.submit(self.waveform, tmp, sr)

        my_gen = self._play_generation

        def _on_play_done():
            # v0.19: _on_play_done es llamado desde el _play_loop thread.
            # NUNCA modificar _playing ni GUI directamente desde aquí.
            # Usar _bridge.stop_ready equiv para serializar al GUI thread.
            if my_gen == self._play_generation and self._playing:
                # Emitir señal para que el GUI thread haga el cleanup
                _bridge.play_done.emit(my_gen)

        self._player.start(
            path        = tmp,
            rate        = sr,
            channels    = channels,
            start_frame = start_frame,
            speed_ratio = self._speed_ratio,
            on_done     = _on_play_done,
        )
    def _on_play_done_signal(self, generation: int):
        """
        Slot Qt — llamado en el GUI thread cuando StreamingPlayer termina.
        v0.19: reemplaza la modificación directa de _playing desde _play_loop
        (que era una race condition). Toda escritura a _playing y GUI ocurre aquí,
        garantizado en el Qt event loop.

        FIX-SCRUB-DONE-POS: al terminar la reproducción naturalmente (fin de
        pista), preservar la posición final del scrub y guardarla como
        _scrub_parked_offset para que el siguiente Play retome desde ahí, igual
        que el Stop manual (stop_all). Solo se resetea a 0 si el archivo llegó
        a su último frame (pos >= 99.5% del total), indicando fin real de pista.
        """
        if generation != self._play_generation or not self._playing:
            return  # generación obsoleta o ya parado por otro path
        self._playing      = False
        self._play_src_pos = 0.0

        # FIX-SCRUB-DONE-POS: determinar si la reproducción llegó al final real
        # o si fue interrumpida en un punto intermedio (p.ej. el usuario pulsó
        # Stop durante la reproducción y luego el thread terminó con lag).
        _done_frac = 0.0
        _total_f   = self._disk_total_frames
        _total_s   = self._disk_total_secs
        if _total_f > 0 and _total_s > 0.0:
            _done_pos  = self._player.src_pos
            _done_frac = max(0.0, min(1.0, _done_pos / _total_f))

        # Si llegó al final del archivo (≥ 99.5%), retornar el scrub al inicio
        # y limpiar _scrub_parked_offset (siguiente Play arranca desde 0).
        if _done_frac >= 0.995:
            self.scrub.setValue(0.0)
            self.waveform.setPlayPos(0.0)
            self._scrub_parked_offset = None
        else:
            # Fin prematuro (stop externo con lag): preservar posición exacta.
            # El scrub ya fue posicionado por stop_all(); solo aseguramos
            # que _scrub_parked_offset esté sincronizado con el scrub actual.
            _cur_frac = self.scrub._value
            self._scrub_parked_offset = _cur_frac * _total_s if _total_s > 0.0 else 0.0
            # No mover el scrub — ya está en la posición correcta.

        self.clock.setText("00:00:00")
        self.status_label.setText("__CAROLALDHIRA_ACTIVA__")
        self.waveform.setMode("idle")
        self._sync_buttons()
    def _scrub_seek_realtime(self, pct):
        """
        Llamado en cada mouseMoveEvent del scrub durante drag.
        v0.20.3: usa seek_to() interno del StreamingPlayer para reposicionar
        sin matar y relanzar el stream — elimina pops/glitches y el
        comportamiento inconsistente causado por múltiples workers concurrentes.

        Durante el drag: seek interno (sin overhead de stop/start).
        En mouseUp: _scrub_released hace play_audio() completo (reinicio limpio).

        FIX-SCRUB-HUB-SYNC (v0.22.21):
        El hub animado del StatusDisplay (contometro lateral) ahora se mueve
        sincrónicamente con el scrub de posición durante el drag.

        CAUSA DEL BUG:
          _tick_cassette() acumula _cassette_angle solo por tiempo real (delta
          fijo por tick). Durante un drag del scrub, el seek de audio avanza o
          retrocede instantáneamente, pero el hub seguía girando a su ritmo propio
          sin reflejar el salto de posición → desincronización visual total.

        SOLUCIÓN:
          Al hacer seek, calcular el ángulo que corresponde a la posición absoluta
          `pct` dentro de la duración total del archivo. El ángulo se mapea de
          forma lineal: 0.0 → 0°, 1.0 → un número entero de vueltas completas
          calibrado al mismo BASE_DELTA / tick-rate que usa _tick_cassette.

          Fórmula:
            ticks_totales = total_secs * TICK_HZ          (24 Hz)
            ticks_en_pct  = pct * ticks_totales
            BASE_DELTA    = 10.4°/tick  (calibración IEC 4.76 cm/s, hub r≈11mm)
            angle_target  = (ticks_en_pct * BASE_DELTA * speed_ratio) % 360

          Se asigna directamente a _cassette_angle; _tick_cassette continúa
          acumulando desde allí. El hub retoma su giro natural en el siguiente
          tick, sin salto perceptible.

          En modo sin player activo (scrub sobre audio pausado) se aplica
          la misma lógica con speed_ratio = 1.0.
        """
        if not self._has_audio(): return
        # Overlay "SeekYng" en el contómetro — calco exacto de CRAC
        # (`crac_scrub_seek.py`, auditado en esta sesión): activo
        # mientras se arrastra el Scrub Seek, se apaga exactamente al
        # soltar (ver `_scrub_released`), sin temporizador de 4s (a
        # diferencia del Scrub Velocista).
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("SCRUBS", True, "SEEK_YNG")
        self.waveform.setPlayPos(pct)
        # FIX-SCRUB-CRAC-PARK (v0.22.47): cuando no hay reproducción activa,
        # el waveform entra en "idle_scrub" (línea punteada de parking) en lugar
        # de "playback". Así el modo visual es coherente con el estado real del
        # player. Cuando hay player activo, "playback" es correcto.
        if self._playing and self._player.is_active():
            self.waveform.setMode("playback")
        else:
            # FIX-SCRUB-PLAY-FROM-POS B (v0.22.50): activar idle_scrub tanto
            # si el waveform estaba en "idle" como si ya estaba en "idle_scrub"
            # (segundo drag del ESCANEADOR). Antes solo se activaba desde "idle",
            # por lo que en el segundo drag waveform._mode no cambiaba y paintEvent
            # no dibujaba la línea de posición → línea congelada en el drag anterior.
            if self.waveform._mode in ("idle", "idle_scrub"):
                self.waveform._mode  = "idle_scrub"
                self.waveform._play_pos = pct      # forzar actualización de posición
                self.waveform._dirty = True
                self.waveform.update()
        self._scrub_pending = pct

        # ── FIX-SCRUB-HUB-SYNC: el ángulo de los carretes del LCD (antes, del
        # hub) sigue la posición del Seek. 0.11.011: lo calcula la cinemática
        # de los carretes (`seek_transport`, a _TICK_HZ del timer cassette);
        # `_cassette_angle` la refleja.
        _TICK_HZ   = 24.0          # frecuencia del timer cassette
        _total_s   = self._disk_total_secs
        if _total_s > 0.0:
            self.reels.seek_transport(pct, _total_s, getattr(self, "_speed_ratio", 1.0),
                                      tick_hz=_TICK_HZ)
            self.reels.advance_transport("play", 0.0)
            if hasattr(self, "clock"):
                self.clock.setReelView(*self.reels.view())
            # Propagar inmediatamente al StatusDisplay sin esperar el próximo tick
            self.status_label.tickCassette(
                self._cassette_angle,
                "play",                          # modo play durante scrub
                True,                            # blink_state siempre visible
                reverse=False,
            )

        # Si hay player activo, seek interno inmediato sin reiniciar el stream
        if self._playing and self._player.is_active():
            total_frames = self._disk_total_frames
            if total_frames > 0:
                frame = int(pct * total_frames)
                self._player.seek_to(frame)
        else:
            # C.R.A.C (FIX-SCRUB-CRAC-PARK v0.22.47): sin player activo,
            # solo guardar la posición de parking — NO arrancar reproducción.
            # Play la consumirá cuando el usuario pulse el botón.
            self._scrub_parked_offset = pct * self._disk_total_secs
            self.scrub.setValue(pct)
    def _scrub_commit(self):
        # FIX-SCRUB-CRAC-PARK (v0.22.47): _scrub_commit ya no lanza play_audio().
        # El timer _scrub_timer solo se dispara cuando hay player activo y la posición
        # cambia significativamente. Sin player activo, _scrub_seek_realtime guarda
        # _scrub_parked_offset directamente; este método queda como guarda de seguridad.
        self._scrub_pending = None
    def _scrub_released(self, pct):
        """
        mouseUp del scrub: consolida la posición final.
        FIX-5: si hay un player activo con seek interno funcionando y la posición
        pedida es la misma que ya está reproduciendo (diferencia < 0.5% del total),
        NO mata el stream con play_audio() — evita el pop/clic audible en cada
        mouseRelease cuando el seek interno ya es suficientemente preciso.
        Solo llama play_audio() si hay un salto real (posición distinta) o si
        no había player activo.

        FIX-SCRUB-HUB-SYNC (v0.22.21): al soltar el scrub, el ángulo del hub
        se consolida en la posición final antes de que _tick_cassette retome
        la acumulación. Esto evita que el hub "salte" al ángulo acumulado anterior
        cuando play_audio() reinicia la reproducción desde la nueva posición.

        FIX-SCRUB-CRAC-PARK (v0.22.47): C.R.A.C especifica que mover el scrub
        estando detenido (sin Play activo) solo marca el punto de inicio; la
        reproducción NO arranca automáticamente. Play consume la posición al
        pulsarse. Reemplaza el comportamiento anterior (v0.22.42) que llamaba
        play_audio() en el release estando parado.
        """
        self._scrub_timer.stop()
        self._scrub_pending = None
        # Apagar overlay "SeekYng" exactamente al soltar (calco de CRAC).
        if hasattr(self, "clock"):
            self.clock.setOverlay("SCRUBS", False)
        if not self._has_audio():
            return

        # FIX-SCRUB-HUB-SYNC: fijar el ángulo final de los carretes del LCD en
        # la posición del release (cinemática de los carretes, 0.11.011).
        _total_s  = self._disk_total_secs
        if _total_s > 0.0:
            self.reels.seek_transport(pct, _total_s, getattr(self, "_speed_ratio", 1.0))

        # ── Sin player activo: solo guardar posición de parking ───────────────
        # C.R.A.C: mover el scrub estando detenido posiciona el marcador de
        # inicio. Play arrancará desde aquí. NO llamar play_audio().
        if not (self._playing and self._player.is_active()):
            self._scrub_parked_offset = pct * _total_s if _total_s > 0.0 else 0.0
            self.scrub.setValue(pct)
            self.waveform.setPlayPos(pct)
            return

        # ── Con player activo: seek/reinicio según delta ───────────────────────
        total_frames = self._disk_total_frames
        if total_frames > 0:
            target_frame  = int(pct * total_frames)
            current_frame = int(self._player.src_pos)
            # Si la diferencia es < 0.5% del total (≤ ~1 s en C-60), el seek
            # interno ya está en la posición correcta: no reiniciar el stream.
            threshold = max(1, int(total_frames * 0.005))
            if abs(target_frame - current_frame) <= threshold:
                return   # seek interno suficientemente preciso → sin pop
        # Hay diferencia real: reinicio limpio desde la nueva posición
        self.play_audio(pct * self._disk_total_secs)
