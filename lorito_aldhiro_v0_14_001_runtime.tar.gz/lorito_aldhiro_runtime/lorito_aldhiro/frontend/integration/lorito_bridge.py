from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Puente entre el motor de captura/reproducción backend y la interfaz Qt.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF



# ─────────────────────────────────────────────────────────────────────────────
#  BRIDGE GUI←→THREADS (señales Qt sin dependencias de hilo)
# ─────────────────────────────────────────────────────────────────────────────

class _Bridge(QObject):
    """Señales emitidas desde threads de audio hacia el GUI thread."""
    status_msg   = Signal(str)   # mensaje para status_label
    recovery_msg = Signal(str)   # mensaje de auto-recovery
    stream_died  = Signal()      # stream falló → GUI debe indicar
    # ── v0.09 UI-latency fixes ─────────────────────────────────────────────
    stop_ready   = Signal(float, int, int, float)
    # ^ (dur_secs, frames_received, frames_written, diff_pct)
    #   emitida cuando flush+probe terminan → GUI actualiza sin bloquear
    seek_ready   = Signal()
    # ^ emitida cuando el player anterior terminó de detenerse → GUI puede
    #   iniciar el nuevo StreamingPlayer sin join() en el GUI thread
    # ── v0.19: play_done ──────────────────────────────────────────────────
    play_done    = Signal(int)
    # ^ (generation: int) emitida desde _play_loop al terminar reproducción
    #   serializa el cleanup de _playing y GUI al Qt event loop,
    #   eliminando la race condition de _on_play_done() modificando
    #   flags Qt desde un thread no-GUI.
    # ── v0.20.24: rec_engine_ready ────────────────────────────────────────
    rec_engine_ready = Signal(bool)
    # ^ (ok: bool) emitida por el worker de apertura del stream de grabación
    #   cuando engine.start() + disk_writer.start() terminan (bien o mal).
    #   Devuelve control al GUI thread sin bloquearlo durante la apertura.
    # ── v0.22.10: export_progress ─────────────────────────────────────────
    export_progress  = Signal(str, str, int)
    # 0.13: celda MASTER del LCD — exportación cruda (sin tratamiento y con
    # códec sin pérdida). Emitida desde el worker de exportación.
    master_cell      = Signal(bool)
    # ^ (codec: str, norm_val: str, pct: int) emitida desde el hilo de export.
    #   codec    ∈ {"WAV","FLAC","OGG","WV"}
    #   norm_val = etiqueta del perfil de normalización (o "Sin normalizar")
    #   pct      0..100; pct == -1 → cierre forzado (error o finally).
    # Orden VIEW-SIGSEGV-019: snapshot inmutable y versionado (widget, snap).
    # Reemplaza a `waveform_ready` (arrays sueltos sin generación).
    waveform_snapshot = Signal(object, object)
    # LA-TAU-OI-001: eventos del secuenciador TAU, (id del servicio, lista de
    # ("start"|"end", patrón)), emitidos desde el callback de audio, y fallos
    # del servicio ("id|motivo"). Cada ventana atiende solo su servicio.
    tau_events = Signal(object)
    tau_failed = Signal(str)
    #   Calculado en _WaveformUpdateWorker; GUI thread aplica y repinta.

    # ── WAYLAND-NATIVE: vu_ready ──────────────────────────────────────────
    vu_ready         = Signal(float, float)
    # ^ (rms_l, rms_r) emitida desde threads de captura/playback.
    #   VUBar.setValues() SOLO se llama al recibir esta señal en el GUI thread.
    #   Garantiza que QWaylandShmBackingStore::flush nunca se invoca desde
    #   hilos no-GUI — elimina el crash class de toda sesión de grabación.

    # ── WAYLAND-NATIVE: tape_update ───────────────────────────────────────
    tape_update      = Signal()
    # ^ pulso de animación enviado desde _tick_cassette() para que
    #   TapeLogPanel.update() se ejecute siempre en el GUI thread.

_bridge = _Bridge()
