"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Manejadores del menú OPTAPE: DSP de PREVI/FNESP, NR, ecualización, monitor.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, SPECTRAL_PROFILE_A_FLATNESS_MAX, SPECTRAL_PROFILE_A_HISS_MAX, SPECTRAL_PROFILE_A_SUBBASS_MIN, SPECTRAL_PROFILE_A_ZCR_MAX, SPECTRAL_PROFILE_B_FLATNESS_MIN, SPECTRAL_PROFILE_B_HISS_MIN, SPECTRAL_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization_common import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_common import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.errors.lorito_errors_dsp import DSPIntegrityError
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, InformacionPatrimonialDialog, RecuperandoDatClamitDialog, ExportSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, LCDSignalMeterWidget,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_cassette_motor_v4 import make_motor




class OptapeMenuMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    # ── Orden SERVO-016 §7: pedidos DSP con estado confirmado por el motor ──
    def _dsp_request(self, label: str, fn, *args, **kwargs) -> bool:
        """Único punto por el que la UI pide un cambio DSP. El motor valida
        (preflight incluido) y confirma; un error se muestra con su TIPO
        (INVALID_CONFIG, UNSUPPORTED_FORMAT…), nunca como un genérico «DSP no
        disponible», y la UI no enciende nada que el motor no aplicó.
        Devuelve True si el motor aceptó el pedido."""
        try:
            ticket = fn(*args, **kwargs)
        except DSPIntegrityError as e:
            kind = getattr(e, "kind", type(e).__name__)
            _log.warning("DSP %s rechazado por el motor: %s — %s", label, kind, e)
            self._dsp_show(f"DSP {label.upper()}: FALLÓ — {kind}")
            return False
        state = getattr(ticket, "state", "")
        if state == "PENDING":
            self._dsp_show(f"DSP {label.upper()}: PENDIENTE")
        return True

    def _dsp_show(self, text: str) -> None:
        if hasattr(self, "status_label"):
            self.status_label.setText(text)

    def _refresh_dsp_state(self) -> None:
        """Tick de la GUI (coalescido, ~24 Hz): muestra UNA vez la
        confirmación del último pedido (APLICADO / FALLÓ — tipo). Lee el
        estado efectivo del motor; nunca lo infiere de la UI."""
        coord = getattr(self, "_nr_coordinator", None)
        if coord is None or not hasattr(coord, "get_status"):
            return
        last = coord.get_status().get("last_request")
        if not last or last["ticket_id"] == vars(self).get("_dsp_shown_ticket", 0):
            return
        if last["state"] == "APPLIED" and last["applied_block"] >= 0 and coord.streaming:
            self._dsp_shown_ticket = last["ticket_id"]
            self._dsp_show(f"DSP {last['target'].upper()}: APLICADO")
        elif last["state"] == "FAILED":
            self._dsp_shown_ticket = last["ticket_id"]

    def _on_dsp_dither_menu(self, mode: str | None) -> bool:
        """DSP → DITHER (LA-DTH-OI-001): "TPDF" o None (apagado). Solo
        guarda la elección: el motor actúa en la exportación, y solo si
        esta reduce la profundidad de bits. Devuelve True si el estado
        cambió."""
        from lorito_aldhiro.backend.dsp.lorito_dither import DITHER_TPDF
        if mode not in (None, DITHER_TPDF):
            self._show_fnc_no_disp()
            return False
        before = vars(self).get("_dither_mode_sel")
        self._dither_mode_sel = mode
        if hasattr(self, "clock"):
            self.clock.set_dither_active(mode is not None)
        if before != mode and hasattr(self, "_tau"):
            self._tau(mode is not None)              # LA-TAU-OI-001
        return before != mode

    def _dither_mode(self) -> str:
        from lorito_aldhiro.backend.dsp.lorito_dither import DITHER_OFF
        return vars(self).get("_dither_mode_sel") or DITHER_OFF
    def _on_host_menu(self, backend: str) -> None:
        self._host_backend = backend
        if hasattr(self, "clock"):
            self.clock.set_host_cell(backend)
    def _on_muestra_menu(self, value: str) -> None:
        """MUESTRA (0.13.002): la frecuencia elegida se verifica contra el
        dispositivo de entrada (`check_capture_rate`) antes de aplicarse.
        Si el dispositivo la rechaza, o hay una sesión en curso, se muestra
        "Fnc No Disp" y la frecuencia vigente no cambia."""
        from lorito_aldhiro.backend.capture.lorito_rate_support import check_capture_rate
        if not hasattr(self, "rate_box") or not self.rate_box.isEnabled():
            self._show_fnc_no_disp()
            return False
        chk = check_capture_rate(int(value), sd_module=self._capture_sd_module())
        self._rate_check = chk
        if not chk.ok:
            _log.warning("MUESTRA: %s", chk.reason)
            self._show_fnc_no_disp()
            return False
        self.rate_box.setCurrentText(f"{chk.rate} Hz")
        return self.rate_box.currentText() == f"{chk.rate} Hz"

    def _capture_sd_module(self):
        """El módulo de audio que usa el motor de captura (el real o el
        stub de pruebas)."""
        try:
            from lorito_aldhiro.backend.capture import lorito_capture_engine as _ce
            return _ce.sd
        except Exception:
            return None

    def _on_bitdeph_menu(self, bits: str) -> None:
        # §GAP-016: intento real contra opt1_box (profundidad de
        # EXPORTACIÓN — sigue siendo el único control de profundidad que
        # existe; no hay uno de captura separado). Busca cualquier ítem
        # del códec actualmente seleccionado que contenga el número de
        # bits pedido (p. ej. "24-BIT PCM", "24-bit"); si no hay
        # coincidencia (algunos códecs, como OGG, no tienen ítems de
        # profundidad en absoluto), degrada con gracia — honesto, no
        # fingido.
        for i in range(self.opt1_box.count()):
            item = self.opt1_box.itemText(i)
            if bits in item:
                self.opt1_box.setCurrentIndex(i)
                return
        self._show_fnc_no_disp()
    def _on_nr_menu(self, cell_token: str | None, registry_token: str | None, **profile_kwargs) -> None:
        # Coordinador NR real (§GAP-011/GAP-012) — selección estructural
        # única, igual que la celda/overlay de abajo. `profile_kwargs`
        # (p. ej. dbx_type="224") se pasa al constructor del perfil.
        if not self._dsp_request("nr", self._nr_coordinator.select, cell_token, **profile_kwargs):
            return
        if not hasattr(self, "clock"):
            return
        effective = self._nr_coordinator.active_token      # estado EFECTIVO del motor
        for _tok in ("DOLBY_B", "DOLBY_C", "DOLBY_S", "ANRS", "S_ANRS", "DBX", "DNL", "DNR"):
            self.clock.set_cell_lit(_tok, _tok == effective)
        for _reg in ("NR_DOLBY_B", "NR_DOLBY_C", "NR_DOLBY_S", "NR_ANRS",
                     "NR_S_ANRS", "NR_DBX", "NR_DNL", "NR_DNR"):
            self.clock.setOverlay("NR", False)
        if cell_token is not None and registry_token is not None:
            self.clock.setOverlayFromRegistry("NR", True, registry_token)
            QTimer.singleShot(1500, lambda: self.clock.setOverlay("NR", False))
    def _on_optape_menu(self, which: str) -> None:
        # LA-TAU-OI-001: el interruptor decide; TAU confirma el cambio real.
        if hasattr(self, "_tau_optape"):
            self._tau_optape(which, self._on_optape_menu_impl)
        else:
            self._on_optape_menu_impl(which)

    def _on_optape_menu_impl(self, which: str) -> None:
        if not hasattr(self, "clock"):
            return
        if which == "ALC":
            active = not self._nr_coordinator.alc_active
            if not self._dsp_request("alc", self._nr_coordinator.set_alc, active):
                return
            self.clock.set_cell_lit("ALC", self._nr_coordinator.alc_active)
            if active:
                self.clock.setOverlayFromRegistry("HX_PRO", True, "ALC")
                QTimer.singleShot(1500, lambda: self.clock.setOverlay("HX_PRO", False))
        elif which == "MPX":
            # R1 del contómetro (§set_mpx_lit, pedido explícito del
            # usuario) — DSP real de filtro de piloto 19/38kHz, ver
            # `lorito_dsp_mpx.MpxProfile` y `NRCoordinator.set_mpx`.
            # Overlay "MPX FI" 4s, calcado del monolito de origen (auditado contra
            # `_state_mixin.py::update_mpx_active()` en esta sesión —
            # antes tenía 1500ms/"MPX", ambos incorrectos).
            new_state = not self._nr_coordinator.mpx_active
            if not self._dsp_request("mpx", self._nr_coordinator.set_mpx, new_state):
                return
            self.clock.set_mpx_lit(self._nr_coordinator.mpx_active)
            if new_state:
                self.clock.setOverlayFromRegistry("HX_PRO", True, "MPX")
                QTimer.singleShot(4000, lambda: self.clock.setOverlay("HX_PRO", False))
        elif which == "FOCUS":
            # R4 del contómetro (§set_focus_lit) — DSP real de
            # corrección de azimuth/fase L-R, ver
            # `lorito_dsp_focus.FocusProfile`. Overlay "Focus" 4s SOLO
            # al activar (pedido explícito del usuario).
            new_state = not self._nr_coordinator.focus_active
            if not self._dsp_request("focus", self._nr_coordinator.set_focus, new_state):
                return
            self.clock.set_focus_lit(self._nr_coordinator.focus_active)
            if new_state:
                self.clock.setOverlayFromRegistry("HX_PRO", True, "FOCUS")
                QTimer.singleShot(4000, lambda: self.clock.setOverlay("HX_PRO", False))
        else:  # HX_PRO
            new_state = not self._nr_coordinator.hx_pro_active
            if not self._dsp_request("hx_pro", self._nr_coordinator.set_hx_pro, new_state):
                return
            if new_state:
                self.clock.setOverlayFromRegistry("HX_PRO", True, "HX_PRO")
                QTimer.singleShot(1500, lambda: self.clock.setOverlay("HX_PRO", False))
            else:
                self.clock.setOverlay("HX_PRO", False)
    def _on_cristhi_cosh_toggle(self) -> None:
        """FLORECEDOR CRISTHI COSH (PREVI) — GAP-039/040. Toggle on/off
        + leyenda "PREVI DSP" en la celda "DOLBY B" + overlay simple de
        encendido de 4s (pedido explícito: "sin indicador TMI... solo
        un mensaje overlay de encendido", mismo criterio que el resto
        de DSP de PREVI de esta sesión)."""
        if not hasattr(self, "clock"):
            return
        new_state = not self._nr_coordinator.cristhi_cosh_active
        if not self._dsp_request("cristhi_cosh", self._nr_coordinator.set_cristhi_cosh, new_state):
            return
        # GAP-041 — la leyenda "PREVI DSP" es COMPARTIDA por todos los
        # DSP de PREVI (Cristhi Cosh + Antipestal) — se refleja el
        # agregado, no solo este DSP en particular.
        self.clock.set_previ_dsp_active(self._nr_coordinator.previ_dsp_active)
        # Overlay del LCD "( ChristCOSH )", familia PREVI.
        if new_state:
            self.clock.showLcdOverlay("LCD_CHRISTCOSH")
            QTimer.singleShot(4000, lambda: self.clock.showLcdOverlay("LCD_CHRISTCOSH", False))
        else:
            self.clock.showLcdOverlay("LCD_CHRISTCOSH", False)
    def _open_cristhi_cosh_panel(self) -> None:
        """Panel de configuración de Cristhi Cosh — "sencillo... solo
        con deslizadores tradicionales" (pedido explícito del usuario,
        sin perillas). Cuatro parámetros ajustables en vivo si el DSP
        está armado (`target_peak` queda en su valor por defecto —
        detalle interno de estabilización, no expuesto al usuario)."""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QSlider, QHBoxLayout
        from PySide6.QtCore import Qt as _Qt

        dsp = self._nr_coordinator._cristhi_cosh
        params = [
            ("Corrección (Nicole)", "correction_intensity",
             dsp.correction_intensity if dsp else 0.60),
            ("Suavizado (Daniela)", "softness",
             dsp.softness if dsp else 0.50),
            ("Reconstrucción (Pocha/SIRF)", "reconstruction_intensity",
             dsp.reconstruction_intensity if dsp else 0.50),
            ("Reducción de ruido (Rommy/DNL)", "dnl_strength",
             dsp.dnl_strength if dsp else 0.50),
        ]

        dlg = QDialog(self)
        dlg.setWindowTitle("Florecedor de Cristhi Cosh (PREVI) — Ajustes")
        layout = QVBoxLayout(dlg)

        def _make_slider(label_text, attr_name, initial):
            row = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setMinimumWidth(220)
            slider = QSlider(_Qt.Horizontal)
            slider.setMinimum(0)
            slider.setMaximum(100)
            slider.setValue(int(round(initial * 100)))
            value_lbl = QLabel(f"{int(round(initial * 100))}%")
            value_lbl.setMinimumWidth(40)

            def _on_change(v):
                value_lbl.setText(f"{v}%")
                # Orden Golden DSP (DSP-04): cambio aplicado en frontera
                # de bloque por el coordinador, nunca mutando el objeto DSP
                # directamente desde el hilo de GUI.
                if self._nr_coordinator.cristhi_cosh_active:
                    self._dsp_request("cristhi_cosh", self._nr_coordinator.set_stage_params,
                                      "cristhi_cosh", **{attr_name: v / 100.0})

            slider.valueChanged.connect(_on_change)
            row.addWidget(lbl)
            row.addWidget(slider)
            row.addWidget(value_lbl)
            layout.addLayout(row)

        for label_text, attr_name, initial in params:
            _make_slider(label_text, attr_name, initial)

        dlg.setLayout(layout)
        dlg.setFixedSize(dlg.sizeHint())  # sin redimensionado, mismo criterio que el monolito de origen
        dlg.exec()
    def _on_antipestal_menu(self, sub_mode: str) -> None:
        """ANTIPESTAL DE LOLA GRILLO (PREVI) — GAP-041, adaptado del
        monolito de origen. `sub_mode` en {"STRIKER", "KARI"} — seleccionar el modo
        ya activo lo apaga (toggle), seleccionar el otro modo cambia
        directamente de rama sin pasar por BYPASS."""
        current = getattr(self._nr_coordinator._antipestal, "mode", "BYPASS")
        new_mode = "BYPASS" if current == sub_mode else sub_mode
        if not self._dsp_request("antipestal", self._nr_coordinator.set_antipestal, new_mode):
            return
        self.clock.set_previ_dsp_active(self._nr_coordinator.previ_dsp_active)
        # Overlay del LCD "LolGanchFin", familia PREVI.
        if new_mode != "BYPASS":
            self.clock.showLcdOverlay("LCD_LOLGANCHFIN", frame="LolGanchFin")
            QTimer.singleShot(4000, lambda: self.clock.showLcdOverlay("LCD_LOLGANCHFIN", False))
        else:
            self.clock.showLcdOverlay("LCD_LOLGANCHFIN", False)
    def _open_antipestal_panel(self) -> None:
        """Panel de ajustes de Antipestal — deslizadores tradicionales,
        sin perillas. Los parámetros dependen de la rama activa
        (STRIKER/KARI comparten algunos nombres, difieren en otros)."""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QSlider, QHBoxLayout
        from PySide6.QtCore import Qt as _Qt

        dsp = self._nr_coordinator._antipestal
        if dsp is None:
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Antipestal Lola Grillo (PREVI) — {dsp.mode} — Ajustes")
        layout = QVBoxLayout(dlg)

        def _make_slider(label_text, attr_name, initial):
            row = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setMinimumWidth(220)
            slider = QSlider(_Qt.Horizontal)
            slider.setMinimum(0)
            slider.setMaximum(100)
            slider.setValue(int(round(initial * 100)))
            value_lbl = QLabel(f"{int(round(initial * 100))}%")
            value_lbl.setMinimumWidth(40)

            def _on_change(v):
                value_lbl.setText(f"{v}%")
                if self._nr_coordinator.antipestal_active:
                    self._dsp_request("antipestal", self._nr_coordinator.set_stage_params,
                                      "antipestal", **{attr_name: v / 100.0})

            slider.valueChanged.connect(_on_change)
            row.addWidget(lbl)
            row.addWidget(slider)
            row.addWidget(value_lbl)
            layout.addLayout(row)

        for name, value in dsp.params.items():
            _make_slider(name.replace("_", " ").capitalize(), name, value)

        dlg.setLayout(layout)
        dlg.setFixedSize(dlg.sizeHint())  # sin redimensionado, mismo criterio que el monolito de origen
        dlg.exec()
    def _on_lucha_menu(self, code: str) -> None:
        """LUCHA ENLOQUECIDA (PREVI) — GAP-042, 20 sub-perfiles A-T.
        Seleccionar el perfil ya activo lo apaga (toggle); seleccionar
        otro cambia directamente sin pasar por BYPASS."""
        current = getattr(self._nr_coordinator._lucha_enloquecida, "mode", "BYPASS")
        new_mode = "BYPASS" if current == code else code
        if not self._dsp_request("lucha_enloquecida", self._nr_coordinator.set_lucha_enloquecida,
                                 new_mode):
            return
        self.clock.set_previ_dsp_active(self._nr_coordinator.previ_dsp_active)
        # Overlay del LCD "LuchEnloqD - {letra} )" (letra A..T = perfil),
        # familia PREVI.
        if new_mode != "BYPASS":
            self.clock.showLcdOverlay("LCD_LUCHENLOQD", letter=new_mode, track=")")
            QTimer.singleShot(4000, lambda: self.clock.showLcdOverlay("LCD_LUCHENLOQD", False))
        else:
            self.clock.showLcdOverlay("LCD_LUCHENLOQD", False)
    def _on_muscle_eq_reset(self) -> None:
        """RESTABLECER (orden §17) — desactiva, vuelve a FLAT, retira
        el indicador MUSC EQ."""
        self._nr_coordinator.reset_muscle_eq()
        self.clock.set_muscle_eq_active(False)
    def _open_muscle_eq_panel(self) -> None:
        """Panel de MUSCLE EQ SAMIR (VITRITO) — orden §10-11: título +
        "Powered by Jordan Vitrito Cornuero", selector de preset
        agrupado por categoría, selector de banda con controles que se
        adaptan al tipo de filtro. "HECHO" (orden §16) es EXCLUSIVAMENTE
        cerrar el panel — no toca activo/preset/bandas."""
        from PySide6.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QSlider,
            QCheckBox, QPushButton,
        )
        from PySide6.QtCore import Qt as _Qt
        from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import (
            MUSCLE_EQ_PRESET_CATEGORIES, get_preset_bands,
        )
        from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import EqBandType

        if self._nr_coordinator._muscle_eq is None:
            self._nr_coordinator.set_muscle_eq_active(False, preset_id="FLAT")
        eq = self._nr_coordinator._muscle_eq

        dlg = QDialog(self)
        dlg.setWindowTitle("MUSCLE EQ SAMIR — Powered by Jordan Vitrito Cornuero")
        layout = QVBoxLayout(dlg)

        title = QLabel("MUSCLE EQ SAMIR\nPowered by Jordan Vitrito Cornuero")
        title.setAlignment(_Qt.AlignCenter)
        layout.addWidget(title)

        # ── Estado ACTIVE/OFF (orden §18 — nunca "ganancia=0dB") ─────
        active_row = QHBoxLayout()
        active_check = QCheckBox("ACTIVE")
        active_check.setChecked(eq.active)

        def _on_active_toggle(checked):
            self._nr_coordinator.set_muscle_eq_active(bool(checked))
            self.clock.set_muscle_eq_active(self._nr_coordinator.muscle_eq_active)

        active_check.toggled.connect(_on_active_toggle)
        active_row.addWidget(active_check)
        layout.addLayout(active_row)

        # ── Selector de preset agrupado por categoría (orden §8-9) ───
        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("PREAJUSTE:"))
        preset_combo = QComboBox()
        for category, presets in MUSCLE_EQ_PRESET_CATEGORIES.items():
            for preset_id in presets:
                preset_combo.addItem(f"{category} — {preset_id}", preset_id)
        idx = preset_combo.findData(eq.preset_id)
        if idx >= 0:
            preset_combo.setCurrentIndex(idx)

        def _on_preset_change(index):
            preset_id = preset_combo.itemData(index)
            self._nr_coordinator.set_muscle_eq_preset(preset_id)

        preset_combo.currentIndexChanged.connect(_on_preset_change)
        preset_row.addWidget(preset_combo)
        layout.addLayout(preset_row)

        # ── Selector de banda + controles (orden §11.B) ──────────────
        band_row = QHBoxLayout()
        band_row.addWidget(QLabel("BANDA:"))
        band_combo = QComboBox()
        for i in range(len(eq.bands)):
            band_combo.addItem(f"Banda {i + 1}")
        band_row.addWidget(band_combo)
        layout.addLayout(band_row)

        type_row = QHBoxLayout()
        type_row.addWidget(QLabel("TIPO:"))
        type_combo = QComboBox()
        for ftype in EqBandType:
            type_combo.addItem(ftype.value)
        type_row.addWidget(type_combo)
        enabled_check = QCheckBox("ON")
        type_row.addWidget(enabled_check)
        layout.addLayout(type_row)

        def _make_param_slider(label_text, lo, hi, initial, on_change):
            row = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setMinimumWidth(90)
            slider = QSlider(_Qt.Horizontal)
            slider.setMinimum(0)
            slider.setMaximum(1000)
            frac = (initial - lo) / (hi - lo) if hi != lo else 0.0
            slider.setValue(int(np.clip(frac, 0.0, 1.0) * 1000))
            value_lbl = QLabel(f"{initial:.1f}")
            value_lbl.setMinimumWidth(60)

            def _on_slider(v):
                value = lo + (v / 1000.0) * (hi - lo)
                value_lbl.setText(f"{value:.1f}")
                on_change(value)

            slider.valueChanged.connect(_on_slider)
            row.addWidget(lbl)
            row.addWidget(slider)
            row.addWidget(value_lbl)
            layout.addLayout(row)
            return slider

        state = {"band_idx": 0, "updating": False}

        def _apply_band_field(**kwargs):
            if state["updating"]:
                return
            self._nr_coordinator.set_muscle_eq_band(state["band_idx"], **kwargs)

        freq_slider = _make_param_slider(
            "FRECUENCIA", 20.0, 20000.0, eq.bands[0].freq_hz,
            lambda v: _apply_band_field(freq_hz=v))
        gain_slider = _make_param_slider(
            "GANANCIA", -24.0, 24.0, eq.bands[0].gain_db,
            lambda v: _apply_band_field(gain_db=v))
        q_slider = _make_param_slider(
            "Q", 0.1, 10.0, eq.bands[0].q,
            lambda v: _apply_band_field(q=v))

        def _refresh_band_controls(index):
            state["updating"] = True
            band = eq.bands[index]
            type_combo.setCurrentText(band.type.value)
            enabled_check.setChecked(band.enabled)
            state["updating"] = False

        def _on_band_change(index):
            state["band_idx"] = index
            _refresh_band_controls(index)

        def _on_type_change(text):
            _apply_band_field(type=text)

        def _on_enabled_change(checked):
            _apply_band_field(enabled=bool(checked))

        band_combo.currentIndexChanged.connect(_on_band_change)
        type_combo.currentTextChanged.connect(_on_type_change)
        enabled_check.toggled.connect(_on_enabled_change)

        # ── HECHO (orden §16 — exclusivamente cerrar, nunca resetea) ─
        hecho_btn = QPushButton("HECHO")
        hecho_btn.clicked.connect(dlg.accept)
        layout.addWidget(hecho_btn)

        dlg.setLayout(layout)
        dlg.setFixedSize(dlg.sizeHint())  # sin redimensionado, mismo criterio que el monolito de origen
        dlg.exec()
    def _on_o_tron_menu(self, sub_mode: str) -> None:
        """VERSIÓN O TRON (Funciones Especiales) — GAP-041, adaptado del
        monolito de origen. `sub_mode` en {"AA_MO", "BARRIL", "SIFON"}."""
        current = getattr(self._nr_coordinator._version_o_tron, "mode", "BYPASS")
        new_mode = "BYPASS" if current == sub_mode else sub_mode
        if not self._dsp_request("version_o_tron", self._nr_coordinator.set_version_o_tron,
                                 new_mode):
            return
        self.clock.set_fnesp_dsp_active(self._nr_coordinator.fnesp_dsp_active)
        if new_mode != "BYPASS":
            from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import VOT_CONFIGS
            label = VOT_CONFIGS[new_mode]["label"]
            self.clock.setOverlay("HX_PRO", True, f"FNESP DSP — {label}", color="#55ccff")
            QTimer.singleShot(4000, lambda: self.clock.setOverlay("HX_PRO", False))
        else:
            self.clock.setOverlay("HX_PRO", False)
    def _on_monitor_menu(self, token: str) -> None:
        """Menú MONITOR (§lorito_monitor_engine, pedido explícito del
        usuario) — Stereo/Mono L/Mono R/Desactivado. MON 1/2/3 avanza
        cíclicamente con cada selección de un modo activo (nunca con
        Desactivado); overlay y color EXACTOS calcados del monolito de origen —
        auditados contra el árbol fuente real en esta sesión
        ("Monitoring ST"/"Monitoring Ls"/"Monitoring Rs"/"Monitoring
        OFF", verde esmeralda, 4s — ver `lorito_overlay_registry.py` y
        el GAP de referencia de esta sesión)."""
        self._monitor_engine.set_mode(token)
        if not hasattr(self, "clock"):
            return
        if token == "OFF":
            self.clock.set_side_cell("L4", "MON 1", False)
            self.clock.setOverlayFromRegistry("MONITOR", True, "MONITOR_OFF")
            QTimer.singleShot(4000, lambda: self.clock.setOverlay("MONITOR", False))
            return
        # Ciclo MON 1→2→3→1 — el índice del modo elegido en
        # `_monitor_mode_cycle` (["STEREO","MONO_L","MONO_R"]) define
        # directamente el número (1/2/3), coherente con la semántica ya
        # fijada en `set_monitor_mode` (1=estéreo, 2=mono izq, 3=mono der).
        mode_num = self._monitor_mode_cycle.index(token) + 1
        self.clock.set_monitor_mode(mode_num)
        _overlay_token = {"STEREO": "MONITOR_STEREO", "MONO_L": "MONITOR_MONO_L",
                          "MONO_R": "MONITOR_MONO_R"}[token]
        self.clock.setOverlayFromRegistry("MONITOR", True, _overlay_token)
        QTimer.singleShot(1500, lambda: self.clock.setOverlay("MONITOR", False))
    def _on_eqbias_menu(self, token: str | None) -> None:
        """Menú EQ/BIAS (§lorito_dsp_eq_bias, pedido explícito del
        usuario) — selección única NORMAL/CrO2/FeCr/Metal. Overlay con
        la fórmula (constante de tiempo) del tipo elegido, 4 segundos,
        luego vuelve al contómetro principal."""
        if not self._dsp_request("eq_bias", self._nr_coordinator.select_eq_bias, token):
            return
        if not hasattr(self, "clock"):
            return
        if token is None:
            self.clock.set_tape_type("NORMAL")
            self.clock.setOverlay("EQBIAS", False)
            return
        self.clock.set_tape_type({"NORMAL": "NORMAL", "CRO2": "CrO2",
                                  "FECR": "FeCr", "METAL": "METAL"}[token])
        self.clock.setOverlayFromRegistry("EQBIAS", True, f"EQ_{token}")
        QTimer.singleShot(4000, lambda: self.clock.setOverlay("EQBIAS", False))
