"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ciclo de vida de la grabación: iniciar, pausar, detener motor de captura.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import subprocess
import threading
import time
import gc
import json
from collections import deque
from datetime import datetime
import math as _math
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar, QFrame, QToolButton, QMenu)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_identity import TEMP_CAPTURE_PREFIX, thread_name
from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR, _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode, _sample_ram_mb, _status
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.capture.lorito_capture_engine import CaptureEngineV2
from lorito_aldhiro.backend.core.lorito_constants import ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG, CE_PREROLL_SECS_DEFAULT, SPECTRAL_PROFILE_A_FLATNESS_MAX, SPECTRAL_PROFILE_A_HISS_MAX, SPECTRAL_PROFILE_A_SUBBASS_MIN, SPECTRAL_PROFILE_A_ZCR_MAX, SPECTRAL_PROFILE_B_FLATNESS_MIN, SPECTRAL_PROFILE_B_HISS_MIN, SPECTRAL_PROFILE_B_ZCR_MIN, DEFAULT_PROFILE, DRIFT_WARN_MS, FLAC_COMPS, FLAC_DEPTHS, LATENCY_PROFILES, OGG_QUALS, PREROLL_SECS, RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB, RT_PRIORITY_DRAIN, SILENCE_ANALYSIS_INTERVAL_MS, SILENCE_AUTOPAUSE_SECS, SILENCE_AUTOPAUSE_SECS_TOL, SILENCE_BLINK_INTERVAL_MS, SILENCE_CALIB_SECS, SILENCE_EMA_UP_TAU_US, SILENCE_GUARD_ESCAPE_SECS, SILENCE_MAX_PAUSES_PER_MIN, SILENCE_NOISE_TRACK_TAU, SILENCE_PAUSE_COOLDOWN_SECS, SILENCE_PAUSE_RATE_WINDOW, SILENCE_REF_CEILING_DBFS, SILENCE_REF_CEILING_LIN, SILENCE_REF_RMS_LIN, SILENCE_RELEASE_MIN_TICKS, SILENCE_RELEASE_PEAK_LIN, SILENCE_SC_HPF_HZ, SILENCE_SC_LPF_HZ, SILENCE_SPECTRAL_CONFIRM, SILENCE_SPECTRAL_FLUX_GATE, SILENCE_WINDOW_MS, SNAPSHOT_INTERVAL_SECS, WAV_DEPTHS, WV_MODES
from lorito_aldhiro.backend.capture.lorito_forensics import _AIPLO_FRN_ACTIVE, _frn_emit, _frn_short_stack, _frn_state, _frn_sync_snap, _aiplo_frn_counters
from lorito_aldhiro.backend.export.lorito_normalization_common import _carol_speed_label
from lorito_aldhiro.backend.export.lorito_normalization_common import NORM_ITEMS_V21
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings, _set_rt_priority
from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard, _HEARTBEAT_PATH, _MANIFEST_PATH, _crash_guard, _snapshot_worker, _validate_crash_manifest
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND, _version_label
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import CarolaBienvenidaDialog, CarolaNooDialog, CierreAbruptoDialog, InformacionPatrimonialDialog, RecuperandoDatClamitDialog, ExportSaveDialog, LoritoExportadorDialog
from lorito_aldhiro.frontend.integration.lorito_itl_bridge import _ITL_AVAILABLE, integrate_itl_into_studio
from lorito_aldhiro.frontend.support.lorito_theme import (
    THEME, build_theme_from_image,
    VFD_GOLD, VFD_GOLD_BRIGHT,
)
from lorito_aldhiro.frontend.widgets.lorito_buttons import DoubleClickButton, LoritoTransportButton
from lorito_aldhiro.frontend.widgets.lorito_indicators import (
    DigitalClock, LuminousIndicator, VUBar, LCDSignalMeterWidget,
)
from lorito_aldhiro.frontend.widgets.lorito_media_anim import MediaAnimWidget
from lorito_aldhiro.frontend.widgets.lorito_scrub_bars import MorpherScrubBar, ScrubBar, SpeedScrubBar
from lorito_aldhiro.frontend.widgets.lorito_status_display import StatusDisplay
from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
from lorito_aldhiro.frontend.widgets.lorito_waveform import WaveformDisplay, _waveform_worker

from lorito_aldhiro.frontend.widgets.lorito_cassette_motor_v4 import make_motor




class RecordingMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def start_record(self):
        # 0.13.002: frecuencia verificada ANTES de tocar el estado. Si el
        # dispositivo o la cadena DSP no la admiten, no se arma nada.
        from lorito_aldhiro.backend.capture.lorito_rate_support import check_capture_rate
        _chk = check_capture_rate(int(self.rate_box.currentText().split()[0]),
                                  sd_module=self._capture_sd_module())
        self._rate_check = _chk
        if not _chk.ok:
            _log.error("REC rechazado: %s", _chk.reason)
            self._show_fnc_no_disp()
            return False
        # Orden TRANSPORT-018 §6: la captura tiene prioridad sobre FF/REW.
        _tc = vars(self).get("_transport")
        if _tc is not None:
            _tc.capture_started()
            self._wind_timer.stop()
        self._disk_total_frames = 0
        self._disk_total_secs   = 0.0
        # 0.13: una captura nueva no tiene aún master exportado (celda MASTER),
        # y el cuentavueltas vuelve a la fuente de la captura.
        if hasattr(self, "clock"):
            self.clock.set_cell_lit("MASTER", False)
        _cv = vars(self).get("tape_counter")
        if _cv is not None and hasattr(_cv, "clear_source"):
            _cv.clear_source("transport")
        self.waveform.clearWave(); self.waveform.setMode("rec")
        if hasattr(self, "clock"):
            self.clock.set_tape_side("A")   # nueva sesión: siempre arranca en Lado A
        rate      = int(self.rate_box.currentText().split()[0])
        self.waveform.setSampleRate(rate)   # informa tasa para análisis espectral
        blocksize = LATENCY_PROFILES[DEFAULT_PROFILE]
        self._cache_rate = rate
        self._nr_coordinator.reconfigure(rate, 2)
        # Orden Golden DSP (DSP-06): compilación JIT en frío fuera del
        # camino de audio, antes de abrir el stream.
        self._dsp_warmup_ms = NRCoordinator.warm_up(rate, 2)
        # Motor de monitorización — arranca (o reconfigura si ya estaba
        # activo) con la misma tasa real de captura. `start()` degrada
        # con gracia (False) si no hay dispositivo de salida disponible;
        # el pipeline de captura sigue funcionando igual sin monitor.
        if self._monitor_engine.running:
            self._monitor_engine.reconfigure(rate, 2)
        else:
            self._monitor_engine.start(rate, 2)

        # Resetear contadores de integridad para la nueva sesión
        _status.frames_received    = 0
        _status.frames_written     = 0
        _status.frames_dropped     = 0
        _status.xrun_count         = 0
        _status.disk_bytes_written = 0
        _status.backpressure_state = "SAFE"
        _status.ram_state          = "OK"
        # v0.08: resetear telemetría extendida
        _status.callback_jitter_ms  = 0.0
        _status.disk_write_ms_last  = 0.0
        _status.disk_write_ms_max   = 0.0
        _status.disk_mbps           = 0.0
        _status.drift_ms            = 0.0
        _status.drift_warn_count    = 0
        _status.expected_frames     = 0
        _status.clip_count_l        = 0
        _status.clip_count_r        = 0
        _status.last_callback_t     = 0.0
        _clip_log.reset()

        # Capturar codec elegido para metadatos de snapshot
        self._session_codec = self.codec_box.currentText()

        # Configurar pre-roll con el rate actual
        self._engine._preroll.configure(CE_PREROLL_SECS_DEFAULT, rate)

        # Preparar ruta del archivo temporal (sin abrir el driver aún)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._disk_tmp_path = os.path.join(ARCHIVE_DIR, f"{TEMP_CAPTURE_PREFIX}{ts}.wav")
        _log.info("Nueva sesión: %s  %d Hz  blocksize=%d", self._disk_tmp_path, rate, blocksize)

        # ── CrashGuard: activar protección contra crashes ─────────────────
        _crash_guard.start({
            "version":        f"{APP_VERSION}-crashguard",  # FIX-BUG08: versión dinámica (antes hardcodeada como 0.20.13-crashguard)
            "session_start":  datetime.now().isoformat(),
            "samplerate":     rate,
            "tmp_file":       self._disk_tmp_path,
            "segment_paths":  [],
            "frames_written": 0,
            "duration_secs":  0.0,
            "codec_hint":     self.codec_box.currentText(),
            "opt1":           self.opt1_box.currentText(),
            "opt2":           self.opt2_box.currentText(),
            "norm":           self.norm_box.currentText(),
        })

        # Resetear ventana del detector de silencio multi-criterio
        self._sil_win_rms_sq      = 0.0
        self._sil_win_peak        = 0.0
        self._sil_win_ticks       = 0
        self._sil_in_silence      = False
        self._silence_start_t     = None
        self._sil_prev_pow_sc     = None
        self._sil_release_start_t = None
        self._sil_consec_above    = 0
        self._sil_win_ticks_total = max(1, round(SILENCE_WINDOW_MS / SILENCE_ANALYSIS_INTERVAL_MS))

        # ── Origen: resetear calibración adaptativa al iniciar nueva grabación ─
        self._sil_calib_rms_sq  = 0.0
        self._sil_calib_peak    = 0.0
        self._sil_calib_ticks   = 0
        self._sil_calib_ticks_total = 0
        self._sil_calib_done    = False
        self._sil_ref_rms_lin   = None
        self._sil_ref_peak_lin  = None
        self._sil_ceiling_ref   = None
        _dt_sil = SILENCE_ANALYSIS_INTERVAL_MS / 1000.0
        self._sil_ema_alpha = 1.0 - _math.exp(
            -_dt_sil / max(SILENCE_NOISE_TRACK_TAU, 0.001))
        self._sil_last_pause_t = 0.0
        self._sil_pause_times  = deque(maxlen=SILENCE_MAX_PAUSES_PER_MIN + 2)
        self._sil_profile        = None
        self._sil_profile_conf_a = 0.0
        self._sil_profile_conf_b = 0.0
        self._sil_profile_tick_ctr = 0   # OPT-PROFILE-DEBOUNCE reset
        self._sil_fft_cached_n     = 0   # OPT-FFT-CACHE reset
        self._sil_prev_pow_sc      = None
        self._prof_hann_n          = 0   # OPT-SCIPY-ELIM reset

        self._rec_start_t = time.monotonic(); self._rec_elapsed = 0.0

        # ── Activar motor ITL ─────────────────────────────────────────────────
        if self._itl_bridge is not None:
            _itl_profile = self.cassette_dur_box.currentText()
            self._itl_bridge.on_start_recording(_itl_profile)

        # PATCH v0.20.13 — FIX: pre-activar engine.recording=True ANTES de llamar
        # _sync_buttons(), para que éste evalúe correctamente el bloque "GRABANDO"
        # (btn_pause habilitado, btn_stop habilitado, rate_box/cassette_dur_box
        # bloqueados). Sin esta pre-activación, _sync_buttons ve recording=False y
        # aplica el bloque "REPOSO", habilitando controles que deben estar bloqueados.
        # El engine.start() real (apertura del driver) se hace en _start_record_engine();
        # esta escritura adelantada es consistente porque engine.start() hace lo mismo
        # como primer paso bajo self.lock.
        with self._engine.lock:
            self._engine.recording = True
            self._engine.paused    = False

        # Actualizar estado de botones e indicadores ANTES de abrir el driver.
        # Esto permite que el event loop procese el repaint completo (estado REC)
        # antes de que engine.start() bloquee el GUI thread durante la apertura
        # del dispositivo de audio (100-500 ms en ALSA/PipeWire).
        self.status_label.setText(
            f"LORITO VA GRABANDO - {rate} Hz  [{AUDIO_BACKEND.upper()}]")
        if hasattr(self, "media_anim"):
            self.media_anim.setState("rec")
        if hasattr(self, "tape_c60"):
            self.tape_c60._elapsed = 0.0
            self.tape_c60._phase   = "A"
            self.tape_c60._counter = 0
            self.tape_c60._counter_base = 0.0
            self.tape_c60._angle1  = 0.0
            self.tape_c60._angle2  = 0.0
            self.tape_c60._flip_pending   = False
            self.tape_c60._flip_done      = False
            self.tape_c60._stop_triggered = False
            self.tape_c60._mech_accum     = 0.0
            self.tape_c60._mech_spool_ang = 0.0
            self.tape_c60._mech_digits    = [0.0, 0.0, 0.0]
            self.tape_c60._mech_values    = [0, 0, 0]
            self.tape_c60._mech_prev_cnt  = -1
            if getattr(self.tape_c60, "_cassette_motor", None) is not None:
                self.tape_c60._cassette_motor.reset()
        if hasattr(self, "tape_c90"):
            self.tape_c90._elapsed = 0.0
            self.tape_c90._phase   = "A"
            self.tape_c90._counter = 0
            self.tape_c90._counter_base = 0.0
            self.tape_c90._angle1  = 0.0
            self.tape_c90._angle2  = 0.0
            self.tape_c90._flip_pending   = False
            self.tape_c90._flip_done      = False
            self.tape_c90._stop_triggered = False
            self.tape_c90._mech_accum     = 0.0
            self.tape_c90._mech_spool_ang = 0.0
            self.tape_c90._mech_digits    = [0.0, 0.0, 0.0]
            self.tape_c90._mech_values    = [0, 0, 0]
            self.tape_c90._mech_prev_cnt  = -1
            if getattr(self.tape_c90, "_cassette_motor", None) is not None:
                self.tape_c90._cassette_motor.reset()
        self._sync_buttons()

        # Overlay "Side A" en el contómetro — calco exacto del monolito de origen:
        # confirmación transitoria (4s) al iniciar una sesión nueva,
        # siempre en Lado A (GAP-010).
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("SIDE_MSG", True, "SIDE_A")
            QTimer.singleShot(4000, lambda: self.clock.setOverlay("SIDE_MSG", False))

        # Diferir apertura del driver al siguiente ciclo del event loop.
        # Garantiza que el repaint de botones/indicadores ya se procesó.
        QTimer.singleShot(0, lambda: self._start_record_engine(rate, blocksize))
    def _start_record_engine(self, rate: int, blocksize: int):
        """
        PATCH v0.20.24 — Apertura completamente fuera del GUI thread.

        PROBLEMA RAÍZ del congelamiento (v0.20.13–v0.20.23):
          QTimer.singleShot(0) solo difiere la ejecución un ciclo del event loop,
          pero engine.start() → _open_stream() → sd.InputStream() sigue ejecutándose
          SÍNCRONAMENTE en el GUI thread. En ALSA/PipeWire, la apertura del driver
          puede bloquear el GUI thread entre 200ms y varios segundos dependiendo del
          hardware y el estado del servidor de audio, congelando la interfaz.
          Adicionalmente, _disk_writer.start() abre el archivo WAV en disco, otra
          operación bloqueante que puede tardar decenas de ms en HDD lentos.

        SOLUCIÓN v0.20.24:
          Todo el trabajo bloqueante (engine.start + disk_writer.start + pre-roll)
          se ejecuta en un worker thread daemon. El resultado se devuelve al GUI
          thread via _bridge.rec_engine_ready (nueva señal booleana) conectada a
          _on_rec_engine_ready(), manteniendo el patrón establecido por stop_worker.
          El GUI thread solo ejecuta _sync_buttons() al terminar, garantizando que
          la interfaz nunca se congele durante la apertura del driver.

        NOTA: engine.recording ya fue pre-activado en start_record() para que
        _sync_buttons() aplicara correctamente el bloque "GRABANDO". Si la
        apertura falla, _on_rec_engine_ready recibe ok=False y revierte el flag.
        """
        # Capturar referencias locales para el worker (evita acceso a self desde
        # otro thread para atributos que no sean thread-safe)
        engine      = self._engine
        disk_writer = engine._disk_writer
        disk_path   = self._disk_tmp_path

        def _open_worker():
            # ── 1. Abrir stream de audio (operación bloqueante, puede tardar >500ms) ──
            ok = engine.start(rate, blocksize)
            if not ok:
                _bridge.rec_engine_ready.emit(False)
                return

            # ── 2. Iniciar DiskWriter (abre archivo WAV — bloqueante en HDD lento) ────
            engine.set_output(disk_path, rate, 2)

            # ── 3. Prioridad RT para el drain thread (también bloqueante: sleep 200ms) ─
            if sys.platform == "linux":
                time.sleep(0.2)
                if engine._drain_t and engine._drain_t.is_alive():
                    _set_rt_priority(RT_PRIORITY_DRAIN)

            # ── 4. Pre-roll: encolar audio acumulado antes de la grabación ────────────
            preroll_data = engine._preroll.drain()
            preroll_dur  = 0.0
            if preroll_data is not None and len(preroll_data) > 0:
                preroll_dur = len(preroll_data) / max(rate, 1)
                _log.info("Pre-roll: %.2f s (%d frames) añadidos al inicio",
                          preroll_dur, len(preroll_data))
                # Orden Golden: el pre-roll solo se antepone si aún no hay
                # audio en vivo encolado (nunca fuera de orden temporal) y
                # queda contabilizado en el FrameLedger (preroll_frames).
                if not engine.ingest_preroll(preroll_data):
                    preroll_dur = 0.0

            # Emitir señal de éxito al GUI thread con la duración del pre-roll
            # codificada como argumento extra via atributo thread-safe
            engine._preroll_dur_for_gui = preroll_dur
            _bridge.rec_engine_ready.emit(True)

        threading.Thread(target=_open_worker, daemon=True,
                         name=thread_name("rec-open")).start()
    def _on_rec_engine_ready(self, ok: bool):
        """
        Slot Qt — resultado del worker de apertura del stream de grabación.
        Llamado en el GUI thread una vez que engine.start() terminó (bien o mal).
        """
        if not ok:
            # Revertir el flag pre-activado en start_record() y volver al reposo
            with self._engine.lock:
                self._engine.recording = False
                self._engine.paused    = False
            _crash_guard.stop()
            self._set_ui_state("standby")
            self._sync_buttons()
            QMessageBox.critical(self, "Error de audio",
                                 "No se pudo abrir el stream de audio.")
            return
        # LA-TAU-OI-001: REC confirmado por el motor → 1 pitido.
        if hasattr(self, "_tau_rec_confirmed"):
            self._tau_rec_confirmed(True)

        # Recuperar duración del pre-roll (guardada por el worker)
        preroll_dur = getattr(self._engine, "_preroll_dur_for_gui", 0.0)

        # Inicializar marcadores de drift y snapshot
        _now = time.monotonic()
        self._drift_t0      = _now - preroll_dur
        self._drift_check_t = _now
        self._snapshot_t    = 0.0   # forzar primer snapshot pronto

        # Re-sincronizar botones con el estado real del engine tras apertura exitosa.
        # engine.start() reescribió recording=True bajo su propio lock; esta llamada
        # confirma que btn_pause y btn_stop siguen habilitados y los controles
        # bloqueados permanecen bloqueados.
        self._sync_buttons()

        # ── AUTO-PAUSA INICIAL (v0.22.09) ────────────────────────────────────
        # Al activar la grabación por primera vez, entrar inmediatamente en
        # auto-pausa para que el usuario confirme el inicio con el botón de pausa.
        # Se activa directamente (sin failsafes de cooldown/frecuencia/buffer)
        # porque es una pausa programática de arranque, no una detección de silencio.
        # El flujo es idéntico al cuerpo de _activate_silence_autopause() pero
        # sin las guardas Failsafe que sí aplican durante la grabación en curso.
        if not self._silence_autopause_active:
            self._silence_autopause_active = True
            # Congelar el motor de captura
            self._engine.pause(True)
            # Resincronizar _rec_start_t al momento exacto de apertura del driver,
            # para que el tiempo de espera de apertura no se contabilice como grabado.
            _now_ap = time.monotonic()
            self._rec_start_t = _now_ap   # resetear al instante de pausa real
            # _rec_elapsed ya se inicializó a 0.0 en start_record(), sin cambio.
            # Sincronizar drift
            _rate_ap = max(self._engine.rate, 1)
            self._drift_t0      = _now_ap - float(_status.frames_received) / _rate_ap
            self._drift_check_t = _now_ap
            _status.drift_ms      = 0.0
            _status.drift_ewma_ms = 0.0 if hasattr(_status, "drift_ewma_ms") else 0.0
            # Registrar en historial de pausas (cooldown contabiliza esta pausa inicial)
            _pause_times = getattr(self, "_sil_pause_times", deque(maxlen=SILENCE_MAX_PAUSES_PER_MIN + 2))
            _pause_times.append(_now_ap)
            self._sil_pause_times  = _pause_times
            self._sil_last_pause_t = _now_ap
            # Actualizar UI
            self._sync_buttons()
            _log.info("AUTO-PAUSA INICIAL: grabación en espera al arrancar")
    def toggle_pause(self):
        if not self._engine.recording: return
        # Bloquear reanudación manual mientras la auto-pausa por silencio está
        # activa: solo _deactivate_silence_autopause() debe reanudar en ese caso.
        # Permitir pausar manualmente (paused=True) sigue siendo válido.
        paused = not self._engine.paused
        if not paused and self._silence_autopause_active:
            return
        self._engine.pause(paused)
        if paused:
            _now_pause = time.monotonic()
            self._rec_elapsed += _now_pause - self._rec_start_t
            # Guardar momento de pausa para que el drain loop de _archival_tick
            # no emita drift falso mientras la grabación está suspendida.
            self._pause_t0 = _now_pause
            self.btn_pause.setText("▶ REANUDAR")
            self.status_label.setText("__BUSYCHAN_PAUSE__")
            # Overlay "Pause" en el contómetro — calco exacto del monolito de origen
            # (pausa FÍSICA/manual, distinta de "SIPActiV" — GAP-010).
            if hasattr(self, "clock"):
                self.clock.setOverlayFromRegistry("PAUSE_PHYSICAL", True, "PAUSE")
            # PC arranca visible (en fase con _cafe_blink_state=True inicial)
            if hasattr(self, "media_anim"):
                self.media_anim.setState("pause")
                self.media_anim.setBlink(True)
            self._cafe_blink_timer.start()
            for _tp in (getattr(self, "tape_c60", None),
                        getattr(self, "tape_c90", None),
                        getattr(self, "tape_otros", None)):
                if _tp is not None:
                    _tp.set_paused(True)
        else:
            self._cafe_blink_timer.stop()
            # Limpiar overlay "Pause" del contómetro al reanudar (GAP-010).
            if hasattr(self, "clock"):
                self.clock.setOverlay("PAUSE_PHYSICAL", False)

            # v0.22.14: restaurar PC a siempre-visible al reanudar desde pausa manual
            if hasattr(self, "media_anim"):
                self.media_anim.setBlink(True)

            # Si había auto-pausa silencio activa, limpiarla silenciosamente:
            # el usuario decidió reanudar manualmente, así que cancelamos el
            # estado de CAROLA ESPERANDO sin llamar a _deactivate (que también
            # llamaría a _engine.pause(False) de nuevo y ya lo hicimos arriba).
            if self._silence_autopause_active:
                self._carola_waiting_blink_timer.stop()
                self._silence_autopause_active = False
                self._silence_start_t = None
                for _tp in (getattr(self, "tape_c60", None),
                            getattr(self, "tape_c90", None),
                            getattr(self, "tape_otros", None)):
                    if _tp is not None:
                        _tp.deactivate_carola_waiting()

            _now_resume = time.monotonic()
            self._rec_start_t = _now_resume

            # ── PATCH DRIFT-RESUME ──────────────────────────────────────────
            # Al reanudar, _drift_t0 lleva N segundos de pausa acumulados
            # en "elapsed_wall" pero frames_received se congeló durante la
            # pausa.  Si no ajustamos, expected_f = (now-_drift_t0)*rate
            # supera al actual_f real por los frames que "deberían" haber
            # llegado durante la pausa → drift masivo inmediato →
            # CAROLALDHIRA DRIFT CUIDADO! / CAROLA CRONICA / CAROLA DELICADA.
            #
            # Solución: recalcular _drift_t0 como el instante virtual en que
            # la grabación "habría empezado" para que expected_f coincida con
            # frames_received en el momento exacto de la reanudación.
            #   expected_f(now) = (now - _drift_t0_nuevo) * rate
            #                   = frames_received_actual
            # ⇒  _drift_t0_nuevo = now - frames_received / rate
            _frames_now = float(_status.frames_received)
            _rate = max(self._engine.rate, 1)
            self._drift_t0 = _now_resume - _frames_now / _rate
            # También resetear drift_check_t para que el siguiente chequeo
            # de _archival_tick compare desde una base limpia.
            self._drift_check_t = _now_resume
            # Limpiar drift acumulado para que la GUI no muestre el pico falso.
            _status.drift_ms        = 0.0
            _status.drift_ewma_ms   = 0.0
            _status.drift_chronic   = False
            # Resetear last_callback_t: el primer callback post-pausa tendría
            # un gap enorme (duración de la pausa) que dispararía jitter falso.
            _status.last_callback_t = 0.0
            # ── FIN PATCH DRIFT-RESUME ──────────────────────────────────────

            self.btn_pause.setText("|| PAUSA")
            self.status_label.setText(f"LORITO VA GRABANDO - {self._engine.rate} Hz")
            for _tp in (getattr(self, "tape_c60", None),
                        getattr(self, "tape_c90", None),
                        getattr(self, "tape_otros", None)):
                if _tp is not None:
                    _tp.set_paused(False)
    def _stop_playback_only(self):
        """Detiene SOLO la reproducción (Orden SERVO-016 §7: los gestos del
        servo —doble Space, tecla E, doble clic en el scrub— nunca cierran
        ni reinician la captura como efecto colateral). `stop_all()` lo usa
        y además detiene la grabación cuando es una orden explícita."""
        if self._playing:
            # STOP no bloqueante (Transport Core: fundido declarado + fin)
            self._player.request_stop()
            self._playing = False
            # FIX-SCRUB-PLAY-POS (v0.22.41): al detener manualmente, preservar la
            # posición actual del scrub y guardarla como _scrub_parked_offset para
            # que el siguiente Play retome desde aquí. NO resetear scrub a 0 ni
            # waveform a 0.0 — el usuario espera que Play retome donde paró.
            _stop_pos = self._player.src_pos
            _stop_frac = 0.0
            if self._disk_total_frames > 0:
                _stop_frac = max(0.0, min(1.0, _stop_pos / self._disk_total_frames))
            self._scrub_parked_offset = _stop_frac * self._disk_total_secs
            # Parada: el cuentavueltas congela la última lectura confirmada.
            self._publish_transport_counter(self._scrub_parked_offset, False)
            self.scrub.setValue(_stop_frac)
            self.waveform.setPlayPos(_stop_frac)
            self._play_src_pos = 0.0
            self._seek_params  = None   # cancelar cualquier seek pendiente
            self._play_offset = 0
            self.clock.setText("00:00:00")
            self.waveform.setMode("idle")
            self.status_label.setText("__CAROLALDHIRA_ACTIVA__")
            # OPT-06: gc.collect() eliminado del path stop-play (stop-the-world)

    def stop_all(self):
        # ── FF/REW: STOP pide la rampa de parada; la confirma el coordinador ──
        _tc = vars(self).get("_transport")
        self._last_wind_stop = None
        if _tc is not None and _tc.is_moving():
            self._last_wind_stop = _tc.stop()

        # ── Detener motor ITL ─────────────────────────────────────────────────
        if self._itl_bridge is not None:
            self._itl_bridge.on_stop_recording()

        # ── Limpiar auto-pausa silencio si estaba activa ──────────────────────
        if self._silence_autopause_active:
            self._carola_waiting_blink_timer.stop()
            self._silence_autopause_active = False
            self._silence_start_t = None
            for _tp in (getattr(self, "tape_c60", None),
                        getattr(self, "tape_c90", None),
                        getattr(self, "tape_otros", None)):
                if _tp is not None:
                    _tp.deactivate_carola_waiting()

        # ── Detener reproducción si está activa ───────────────────────────────
        self._stop_playback_only()

        # ── Detener grabación ─────────────────────────────────────────────────
        if not self._engine.recording:
            self._sync_buttons()
            return

        # Señalar stop al engine inmediatamente (callback deja de grabar)
        self._engine.stop()
        self.btn_pause.setText("|| PAUSA")

        # Deshabilitar botones durante la transición para evitar doble-click
        self.btn_stop.setEnabled(False)
        self.btn_record.setEnabled(False)
        self.status_label.setText("LORITO EXTRAE LA CINTA Y VUELCA TODO...")
        # Iluminar botón STOP durante el vaciado
        self._set_ui_state("stop")
        # v0.20.24 FIX-STOP: llamar _sync_buttons() inmediatamente tras entrar en
        # estado "stop" para que btn_pause (y todos los demás controles) queden
        # deshabilitados. Sin esta llamada, btn_pause permanecía habilitado porque
        # stop_record() solo hacía setEnabled(False) explícitamente para btn_stop y
        # btn_record, dejando btn_pause en estado "falso activo" hasta el siguiente
        # tick del timer _blink (que tiene guardia para estado "stop" y no lo corrige).
        self._sync_buttons()
        if hasattr(self, "media_anim"):
            self.media_anim.setState("flushing")

        # ── Todo el trabajo pesado en un worker thread ────────────────────────
        # El GUI thread NUNCA espera: recibe el resultado vía señal stop_ready.
        disk_writer = self._engine._disk_writer
        tmp_path    = self._disk_tmp_path
        cache_rate  = self._cache_rate

        def _stop_worker():
            # 1. Flush: espera que la cola de disco quede vacía
            #    progress_cb corre aquí (worker thread) y emite señal Qt al GUI
            def _progress(pending, total):
                pct = max(0, int(100 * (1 - pending / max(total, 1))))
                _bridge.status_msg.emit(
                    f"LORITO EXTRAE LA CINTA Y VUELCA TODO... {pct}% ({pending} bloques)")

            # Orden Golden de Captura (CAP-003/CAP-008/CAP-009): cierre en
            # fases autoritativo del motor — drain confirmado, flush_barrier
            # (flush + fsync), cierre del writer con resultado explícito,
            # verificación del archivo cerrado, reconciliación del
            # FrameLedger y clasificación. Un timeout NUNCA se presenta
            # como éxito: queda FINALIZATION_INCOMPLETE y bloquea
            # ARCHIVAL_SAFE.
            _progress(self._engine._ced.frame_count, max(self._engine._ced.frame_count, 1))
            try:
                self._last_finalization = self._engine.finalize()
                self._last_archival_classification = self._last_finalization.classification
                if not self._last_finalization.complete:
                    _log.error("Cierre de captura INCOMPLETO: %s",
                               "; ".join(self._last_finalization.reasons))
            except Exception as e:
                _log.error("finalize() falló al cerrar sesión: %s", e)
                self._last_finalization = None
                self._last_archival_classification = None

            # 2. Leer el path efectivo del DiskWriter: puede haber cambiado al
            #    primer segmento durante el cierre (sin copia física).
            effective_path = disk_writer.get_path() or tmp_path

            # 3. Probe: leer solo metadatos del archivo (no el audio)
            dur_secs = 0.0
            total_frames = 0
            rate = cache_rate
            try:
                if effective_path and os.path.exists(effective_path) \
                        and os.path.getsize(effective_path) > 512:
                    with sf.SoundFile(effective_path, "r") as f:
                        total_frames = f.frames
                        rate         = f.samplerate
                    dur_secs = total_frames / max(rate, 1)
            except Exception as e:
                _log.error("stop_worker probe error: %s", e)

            fr = _status.frames_received
            fw = _status.frames_written
            diff_pct = abs(fr - fw) / max(fr, 1) * 100 if fr > 0 else 0.0

            # 4. Emitir señal al GUI thread con los metadatos y el path efectivo
            _bridge.stop_ready.emit(dur_secs, fr, fw, diff_pct)

        threading.Thread(target=_stop_worker, daemon=True,
                         name=thread_name("stop")).start()
    def _on_stop_ready(self, dur_secs: float, fr: int, fw: int, diff_pct: float):
        """
        Slot Qt — llamado en el GUI thread cuando el flush de disco terminó.
        CAROLALDHIRA ACTIVA! aparece AQUÍ, no antes — es la señal real de reposo.
        """
        # Sincronizar _disk_tmp_path con el path efectivo del DiskWriter:
        # si hubo segmentación, _path_tmp fue reasignado al primer segmento
        # (sin copia física) y debemos reflejarlo aquí para probe/waveform/export.
        effective = self._engine._disk_writer.get_path()
        if effective and os.path.exists(effective) and os.path.getsize(effective) > 512:
            self._disk_tmp_path = effective

        # Actualizar estado interno
        self._disk_total_secs   = dur_secs
        self._disk_total_frames = int(dur_secs * self._cache_rate)

        if dur_secs > 0:
            _log.info("STOP: dur=%.2fs  fr=%d fw=%d diff=%.3f%%",
                      dur_secs, fr, fw, diff_pct)
            self.clock.setText("00:00:00")
            # Waveform en background — OPT-07: worker persistente en lugar de Thread() efímero
            _waveform_worker.submit(self.waveform, self._disk_tmp_path, self._cache_rate)
            self.waveform.setMode("idle")

        # Liberar memoria y re-habilitar botones
        self._engine.buffer.clear()
        # OPT-06: gc.collect() eliminado del path stop-recording
        self._invalidate_speed_cache()

        # ── Activar interfaz inmediatamente al terminar el vaciado ────────────
        # Forzar salida del estado "stop" ANTES de que _blink o cualquier otro
        # timer pueda interferir. _ui_state="" garantiza que _set_ui_state
        # aplique aunque el estado anterior ya fuera "standby" por race condition.
        self._ui_state = ""
        self._set_ui_state("standby")
        # Primera sincronización inmediata
        self._sync_buttons()
        # Segunda sincronización diferida: garantiza que el event loop haya
        # procesado todos los eventos pendientes (señales Qt en cola, timers)
        # antes de re-evaluar el estado. Elimina la race condition entre
        # _blink/_tick y _on_stop_ready cuando coinciden en el mismo ciclo.
        QTimer.singleShot(0, self._sync_buttons)
        # Animación lateral: estado "stopped" (PC + cassette + disco + checkmark)
        if hasattr(self, "media_anim"):
            self.media_anim.setState("stopped")
        # ── CAROLALDHIRA ACTIVA! aparece recién aquí: vaciado completo ──────────
        self.status_label.setText("__CAROLALDHIRA_ACTIVA__")
    def _probe_disk_file(self):
        """
        v0.07: Lee SOLO los metadatos del archivo temporal (frames, rate).
        NUNCA carga el audio completo en RAM.
        Actualiza _disk_total_frames y _disk_total_secs.
        """
        tmp_path = self._disk_tmp_path
        if not tmp_path or not os.path.exists(tmp_path):
            self._disk_total_frames = 0
            self._disk_total_secs   = 0.0
            return
        try:
            sz = os.path.getsize(tmp_path)
            if sz < 512:
                _log.warning("Archivo temporal muy pequeño (%d bytes)", sz)
                self._disk_total_frames = 0
                self._disk_total_secs   = 0.0
                return
            with sf.SoundFile(tmp_path, "r") as f:
                self._disk_total_frames = f.frames
                self._cache_rate        = f.samplerate
            self._disk_total_secs = self._disk_total_frames / max(self._cache_rate, 1)
            _log.info("Archivo temporal: %.2f s  %d frames  %d Hz  %d bytes",
                      self._disk_total_secs, self._disk_total_frames,
                      self._cache_rate, sz)
            # Validar contra contador de frames escritos
            self._engine._disk_writer.validate_duration(self._disk_total_secs)
        except Exception as e:
            _log.error("_probe_disk_file error: %s", e)
            self._disk_total_frames = 0
            self._disk_total_secs   = 0.0
