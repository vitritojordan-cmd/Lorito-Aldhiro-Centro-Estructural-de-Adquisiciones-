from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Renderizado visual del análisis espectral en la interfaz de exportación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_spectral_render.py — frontend (Qt) de la imagen espectral
post-export (§GAP-016), portado desde `export_spectral_render.py`
(auditado en el monolito de origen). Responsabilidad única: recibir el buffer RGBA ya
calculado por `lorito_export_spectral_engine.compute_spectrogram_rgba()`
y pintar la cabecera/pie (nombre de archivo, códec, marca de
plataforma, marcas de frecuencia) con QPainter, guardando el PNG.

Cambio explícito pedido por el usuario respecto del monolito de origen: la marca de
plataforma en la esquina superior derecha pasa del nombre del producto
de origen (rosa) a **"Lorito Aldhiro" en amarillo**.
"""

from typing import Optional, Sequence, Tuple

import numpy as np

from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen

from lorito_aldhiro.backend.export.lorito_export_spectral_engine import (
    SpectralImageLayout, DEFAULT_LAYOUT,
)

__all__ = ["render_spectral_png"]

# Pedido explícito del usuario (§GAP-016): "Carola Records Aldhira
# Capture" → "Lorito Aldhiro", en amarillo (antes rgba(255,20,147) rosa).
_PLATFORM = "Lorito Aldhiro"
_PLATFORM_COLOR = QColor(255, 220, 0)   # amarillo

#: Color por códec de la etiqueta de cabecera — mismos valores que el monolito de origen.
_CODEC_COLORS = {
    "WAV":  (255, 255, 255),
    "FLAC": (0, 210, 200),
    "OGG":  (188, 143, 94),
    "WV":   (210, 215, 220),
}
_CODEC_COLOR_DEFAULT = (255, 20, 147)

#: Marcas de frecuencia del eje inferior — (etiqueta, fracción horizontal).
_FREQ_LABELS: Tuple[Tuple[str, float], ...] = (
    ("20 Hz", 0.00), ("50 Hz", 0.10), ("100 Hz", 0.18),
    ("200 Hz", 0.27), ("500 Hz", 0.38), ("1 kHz", 0.50),
    ("2 kHz", 0.60), ("5 kHz", 0.68), ("10 kHz", 0.80),
    ("20 kHz", 1.00),
)


def render_spectral_png(
    rgba: np.ndarray,
    out_path: str,
    filename: str = "",
    codec_name: str = "",
    layout: SpectralImageLayout = DEFAULT_LAYOUT,
    freq_labels: Optional[Sequence[Tuple[str, float]]] = None,
) -> None:
    """Pinta cabecera/pie sobre `rgba` (buffer ya calculado por el
    backend) y guarda el PNG resultante en `out_path`. Lanza
    `RuntimeError` si `QImage.save()` falla."""
    freq_labels = freq_labels if freq_labels is not None else _FREQ_LABELS
    img_w, img_h = layout.img_w, layout.img_h
    hdr_h, spec_h = layout.hdr_h, layout.spec_h

    rgba_bytes = np.ascontiguousarray(rgba).tobytes()
    img = QImage(rgba_bytes, img_w, img_h, img_w * 4,
                 QImage.Format.Format_RGBA8888)

    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    p.setPen(QPen(QColor(60, 60, 60), 1))
    p.drawLine(0, hdr_h - 1, img_w, hdr_h - 1)

    p.setFont(QFont("Arial", 18, QFont.Weight.Normal))
    p.setPen(QColor(230, 230, 230))
    p.drawText(QRect(28, 10, img_w // 2 - 40, 30),
               Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
               filename or "—")

    _cc = QColor(*_CODEC_COLORS.get((codec_name or "").upper(), _CODEC_COLOR_DEFAULT))
    p.setFont(QFont("Arial", 13, QFont.Weight.Normal))
    p.setPen(_cc)
    p.drawText(QRect(28, 42, 320, 22),
               Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
               f"CODEC: {codec_name or '—'}")

    p.setFont(QFont("Arial", 14, QFont.Weight.Normal))
    p.setPen(_PLATFORM_COLOR)
    p.drawText(QRect(img_w // 2, 10, img_w // 2 - 28, hdr_h - 12),
               Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
               _PLATFORM)

    sep_y = hdr_h + spec_h
    p.setPen(QPen(QColor(50, 50, 50), 1))
    p.drawLine(0, sep_y, img_w, sep_y)

    p.setFont(QFont("Courier New", 9))
    p.setPen(QColor(90, 90, 90))
    margin_x = 24
    usable_w = img_w - margin_x * 2
    for label, frac in freq_labels:
        xl = int(margin_x + frac * usable_w) - 18
        p.drawText(xl, sep_y + 22, label)

    p.end()

    if not img.save(out_path, "PNG"):
        raise RuntimeError(f"QImage.save falló al escribir PNG: {out_path}")
