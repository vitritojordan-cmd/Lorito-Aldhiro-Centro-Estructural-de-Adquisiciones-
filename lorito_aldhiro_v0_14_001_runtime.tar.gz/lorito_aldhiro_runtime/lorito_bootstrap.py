from __future__ import annotations

import sys
import os
import json
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QComboBox, QLabel,
                               QMessageBox, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem,
                               QSizePolicy, QProgressBar)
from PySide6.QtCore    import Qt, QTimer, QRect, Signal, QObject
from PySide6.QtGui     import (QPixmap, QColor, QPainter, QPen, QLinearGradient,
                                QBrush, QPalette, QFont, QRadialGradient, QImage,
                                QPolygon, QPolygonF, QKeySequence, QShortcut,
                                QPainterPath)
from PySide6.QtCore    import QPoint, QPointF

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.capture.lorito_forensics import _FORENSICS_ACTIVE, _FRN_ARCHIVE_DIR, _FRN_LOG_PATH, _frn_flush_disk_async
from lorito_aldhiro.backend.core.lorito_patches import _patch_backend_status
from lorito_aldhiro.backend.audio.lorito_rt_priorities import ZEN_AFFINITY_GUI, _RT_STATUS, _init_rt_privileges, _set_cpu_affinity, _set_sched_batch
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.support.lorito_fonts import register_embedded_fonts, font_ui
from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio



# ─────────────────────────────────────────────────────────────────────────────
#  INICIALIZACIÓN DEL PARCHE
# ─────────────────────────────────────────────────────────────────────────────

# Aplicar parche de BackendStatus al importar
_patch_backend_status()

#  STABILITY PATCH — auditoría en vivo (GAP-009)
#  A diferencia del monolito de origen (donde este parche fue retirado y archivado desde
#  v0.34 — ver GAP-008 §3), en Lorito Aldhiro sigue siendo un módulo vivo
#  del sistema: se ejecuta en cada arranque, audita el estado real del
#  código contra los ~25 parches históricos de la línea del monolito de origen 0.22.x,
#  y dos de ellos (D-4, E-3) ya quedaron aplicados directamente al código
#  fuente en esta sesión — ver lorito_stability_patch.py para el detalle
#  completo de qué se confirmó, qué se aplicó y qué se difirió.
# ══════════════════════════════════════════════════════════════════════════════
try:
    from lorito_aldhiro.frontend.support.lorito_stability_patch import apply_stability_patch
    apply_stability_patch()
except Exception as _patch_exc:
    _log.error("Error al aplicar stability patch: %s", _patch_exc)

if __name__ == "__main__":

    # ── --version: nombre, versión y atribución histórica, sin GUI ───────────
    if "--version" in sys.argv:
        from lorito_aldhiro.backend.core.lorito_version import about_text
        print(about_text())
        sys.exit(0)

    # ── MODO --analyze: reporte post-sesión sin arrancar GUI ─────────────────
    if "--analyze" in sys.argv:
        import statistics as _stats
        print(f"\n{'═'*72}")
        print(f"  Lorito Aldhiro POP FORENSICS — ANÁLISIS POST-SESIÓN")
        print(f"  Log: {_FRN_LOG_PATH}")
        print(f"{'═'*72}\n")
        events = []
        try:
            with open(_FRN_LOG_PATH, encoding="utf-8") as _fh:
                for _line in _fh:
                    _line = _line.strip()
                    if _line:
                        try:   events.append(json.loads(_line))
                        except json.JSONDecodeError: pass
        except FileNotFoundError:
            print(f"  Log no encontrado: {_FRN_LOG_PATH}")
            sys.exit(1)
        if not events:
            print("  Log vacío."); sys.exit(0)
        print(f"  Total eventos: {len(events)}\n")
        # Agrupar
        by_type: dict = {}
        for _ev in events:
            by_type.setdefault(_ev["ev"], []).append(_ev)
        print("EVENTOS POR TIPO:")
        for _k, _vs in sorted(by_type.items(), key=lambda x: -len(x[1])):
            _m = "*** " if "POP_RISK" in _k else "    "
            print(f"  {_m}{_k:<52} {len(_vs):>5}x")
        # Causalidad
        pop_risks = [e for e in events if "POP_RISK" in e["ev"]]
        if pop_risks:
            print(f"\n⚠  {len(pop_risks)} EVENTOS POP_RISK — ANÁLISIS CAUSAL:")
            for _pr in pop_risks:
                _t = _pr["t"]
                print(f"\n  [{_t:.1f}ms] {_pr['ev']}")
                print(f"    thread={_pr['thr']}  Δ={_pr['dms']:.2f}ms")
                print(f"    {_pr['d']}")
                _pre = [e for e in events
                        if e["t"] < _t and (_t - e["t"]) <= 300
                        and ("FLUSH" in e["ev"] or "SET_SPEED" in e["ev"])]
                if _pre:
                    print(f"    Flushes previos (300ms):")
                    for _p in _pre[-4:]:
                        print(f"      -{_t-_p['t']:.1f}ms  {_p['ev']}  {_p['d']}")
        else:
            print("\n✓ Sin eventos POP_RISK.")
        # Timing de flushes
        _fl = [e for e in events if "FLUSH" in e["ev"]]
        if len(_fl) >= 2:
            _ivs = [_fl[i+1]["t"] - _fl[i]["t"] for i in range(len(_fl)-1)]
            print(f"\nFLUSHES: {len(_fl)} total  "
                  f"min={min(_ivs):.1f}ms  med={_stats.median(_ivs):.1f}ms  "
                  f"max={max(_ivs):.1f}ms  "
                  f"dobles(<10ms)={sum(1 for x in _ivs if x < 10)}")
        print(f"\n{'═'*72}\n")
        sys.exit(0)

    # ── MODO --aiplo-analyze: reporte AIPLO post-sesión ───────────────────────
    # (renombrado desde --sipa-analyze — SIPA queda reservado al Sistema
    #  Inteligente de Pausa Automática real, en Silence Controller. Mismo
    #  renombre ya aplicado en el monolito de origen 0.24.)
    # firma='--aiplo-analyze'
    if "--aiplo-analyze" in sys.argv:
        import statistics as _aiplo_stats
        _aiplo_log = _FRN_LOG_PATH
        print(f"\n{'═'*72}")
        print(f"  Lorito Aldhiro AIPLO FORENSICS — AUDITOR INTEGRADO DE PARÁMETROS LORITO ORDENALES")
        print(f"  Log: {_aiplo_log}")
        print(f"{'═'*72}\n")
        _aiplo_events: list = []
        try:
            with open(_aiplo_log, encoding="utf-8") as _sfh:
                for _sl in _sfh:
                    _sl = _sl.strip()
                    if _sl:
                        try:
                            _aiplo_events.append(json.loads(_sl))
                        except json.JSONDecodeError:
                            pass
        except FileNotFoundError:
            print(f"  Log no encontrado: {_aiplo_log}\n")
            sys.exit(1)
        # Filtrar eventos AIPLO
        _aiplo_tags = {
            "AIPLO_TICK", "AIPLO_COUNTER_RESET",
            "AIPLO_AUTOPAUSE_ACTIVATED", "AIPLO_AUTOPAUSE_DEACTIVATED",
            "AIPLO_EMERGENCY_FLIP", "AIPLO_EMERGENCY_STOP",
        }
        _aiplo_ev = [e for e in _aiplo_events if e.get("ev", "").startswith("AIPLO_")]
        if not _aiplo_ev:
            print("  Sin eventos AIPLO registrados en este log.\n")
            sys.exit(0)
        # Resumen por categoría
        _aiplo_by_cat: dict = {}
        for _e in _aiplo_ev:
            _aiplo_by_cat.setdefault(_e["ev"], []).append(_e)
        print("EVENTOS AIPLO POR CATEGORÍA:")
        for _cat, _evs in sorted(_aiplo_by_cat.items()):
            print(f"  {_cat:<52} {len(_evs):>5}x")
        # Estadísticas de tick
        _aiplo_ticks = _aiplo_by_cat.get("AIPLO_TICK", [])
        if len(_aiplo_ticks) >= 2:
            _aiplo_dms = [_t["dms"] for _t in _aiplo_ticks]
            print(f"\nAIPLO_TICK: {len(_aiplo_ticks)} total  "
                  f"min={min(_aiplo_dms):.1f}ms  "
                  f"med={_aiplo_stats.median(_aiplo_dms):.1f}ms  "
                  f"max={max(_aiplo_dms):.1f}ms")
        # Eventos de riesgo
        _aiplo_risk = [e for e in _aiplo_ev
                      if e["ev"] in ("AIPLO_EMERGENCY_FLIP", "AIPLO_EMERGENCY_STOP")]
        if _aiplo_risk:
            print(f"\n⚠  {len(_aiplo_risk)} EVENTO(S) DE EMERGENCIA AIPLO:")
            for _r in _aiplo_risk:
                print(f"  [{_r['t']:.1f}ms] {_r['ev']}  thr={_r['thr']}  {_r['d']}")
        else:
            print("\n✓ Sin eventos de emergencia AIPLO.")
        print(f"\n{'═'*72}\n")
        sys.exit(0)

    # ── Migración de persistencia (LA-GOLDEN-CORE-020 §6, CFG-01) ─────────────
    # Antes de que CrashGuard busque una sesión destruida: los archivos de
    # control con nombres anteriores a 0.14 pasan a los del catálogo, con
    # respaldo. Un fallo no detiene el arranque pero queda en el log.
    from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR as _ARCHIVE_DIR
    from lorito_aldhiro.backend.core import lorito_config_migration as _cfgmig
    _mig = _cfgmig.migrate_persistence(_ARCHIVE_DIR)
    _mig_line = _cfgmig.describe(_mig)
    if _mig_line:
        (_log.error if not _mig.ok else _log.info)(_mig_line)
        if not _mig.ok:
            print(f"[MIGRACIÓN] {_mig_line}", file=sys.stderr)

    # ── FORENSICS: activar antes de crear LoritoAldhiroStudio ───────────────────────
    if _FORENSICS_ACTIVE:
        os.makedirs(_FRN_ARCHIVE_DIR, exist_ok=True)
        try:
            with open(_FRN_LOG_PATH, "a", encoding="utf-8") as _fh:
                _fh.write(json.dumps({
                    "t": 0, "ev": "SESSION_START", "thr": "main",
                    "dms": 0.0,
                    "d": {"time": __import__('time').strftime("%Y-%m-%dT%H:%M:%S"),
                          "file": __file__},
                }) + "\n")
        except Exception:
            pass
        import atexit as _atexit
        _atexit.register(_frn_flush_disk_async)
        _atexit.register(lambda: print(
            f"\n[FRN] Sesión terminada. Log → {_FRN_LOG_PATH}\n"
            f"[FRN] Analizar: python3 {os.path.basename(__file__)} --analyze",
            file=sys.stderr))
        print(
            f"\n\033[92m[FRN] ═══ FORENSICS ACTIVO ═══\033[0m\n"
            f"[FRN] Log en tiempo real → stderr  |  Disco → {_FRN_LOG_PATH}\n"
            f"[FRN] Activado con: {'--forensics' if '--forensics' in sys.argv else 'LORITO_ALDHIRO_FORENSICS=1'}\n",
            file=sys.stderr, flush=True)

    # ── 1. Diagnóstico de RT privileges (realtime-privileges + grupo audio) ───
    # Se ejecuta antes de crear la QApplication para que _RT_STATUS esté
    # disponible cuando los threads de audio llamen a _set_rt_priority().
    _init_rt_privileges()

    if _RT_STATUS is not None:
        if _RT_STATUS.rt_fully_ready:
            _log.info("RT privileges: configuración completa y operativa")
        else:
            _log.warning(
                "RT privileges: %d advertencia(s) de configuración — "
                "audio puede funcionar con latencia subóptima",
                len(_RT_STATUS.warnings)
            )

    # ── 2. Optimización Zen: GUI thread con SCHED_BATCH ──────────────────────
    # Libera núcleos RT para los threads de audio; el GUI cede voluntariamente.
    _set_sched_batch()
    _set_cpu_affinity(ZEN_AFFINITY_GUI)

    # ── 3. Configuración Wayland / Qt6 ANTES de crear QApplication ───────────
    # Debe establecerse antes de instanciar QApplication; después es ignorado.
    if sys.platform == "linux":
        # ── Wayland nativo Qt6 ────────────────────────────────────────────────
        # Desde v0.23.00 el monolito de origen corre sobre el backend Wayland puro de Qt6.
        # El SIGSEGV en QWaylandShmBackingStore quedó eliminado al garantizar
        # que NINGÚN hilo no-GUI toca atributos Qt ni llama update()/repaint().
        # Todo pintado pasa por señales queued (_bridge.vu_ready,
        # _bridge.waveform_snapshot) que se despachan en el main thread.
        _xdg_session    = os.environ.get("XDG_SESSION_TYPE", "").lower()
        _wayland_display = os.environ.get("WAYLAND_DISPLAY", "")
        _is_wayland     = (_xdg_session == "wayland" or bool(_wayland_display))

        if _is_wayland:
            # Usar backend Wayland nativo — nunca XCB/XWayland
            if "QT_QPA_PLATFORM" not in os.environ:
                os.environ["QT_QPA_PLATFORM"] = "wayland"
            # Decoración server-side (SSD): evita doble borde en KDE/GNOME/wlroots
            os.environ.setdefault("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1")
            # Buffer Wayland: dejar que Qt detecte automáticamente la integracion
            # disponible (wayland-egl o shm). Forzar "shm" causaba el error
            # "Failed to load client buffer integration: shm" en sistemas con
            # libwayland-egl presente (KDE Plasma, GNOME, Weston con EGL).
            # FIX-EGL-DETECT (v0.22.53): eliminada la linea setdefault("shm")
            # para permitir que Qt use wayland-egl cuando este disponible.

        # HiDPI fraccionario: PassThrough pasa el factor exacto del compositor
        # al painter. Los widgets calculan sus métricas en device-independent
        # pixels y escalan internamente con devicePixelRatio().
        # (Round produce bordes borrosos a 125%/150% con Wayland fractional scaling.)
        # Debe aplicarse ANTES de crear QApplication — válido en X11 y Wayland.
        try:
            from PySide6.QtCore import Qt as _Qt6
            _rp = getattr(_Qt6, "HighDpiScaleFactorRoundingPolicy", None)
            if _rp is not None:
                _pt = getattr(_rp, "PassThrough", None) or getattr(_rp, "Round", None)
                if _pt is not None:
                    QApplication.setHighDpiScaleFactorRoundingPolicy(_pt)
        except Exception:
            pass

        # Desactivar AT-SPI/D-Bus: IPC extra bloquea el scheduler RT (~5-20 ms).
        # Aplica en Wayland y X11.
        os.environ.setdefault("QT_ACCESSIBILITY", "0")
        os.environ.setdefault("NO_AT_BRIDGE", "1")

    # Orden LA-GOLDEN-VIEW-SIGSEGV-019 (Capa C): stack de todos los hilos
    # ante un fallo nativo y registro de excepciones no capturadas.
    try:
        from lorito_aldhiro.backend.core.lorito_app_logging import ARCHIVE_DIR as _CRASH_DIR
        from lorito_aldhiro.backend.core import lorito_crash_diagnostics as _crashdiag
        _crashdiag.enable(_CRASH_DIR)
    except Exception as _cd_exc:
        _log.error("No se pudo activar el diagnóstico de fallos: %s", _cd_exc)
    app = QApplication(sys.argv)
    # setDesktopSettingsAware(False): desactiva lectura de temas GTK que en
    # Wayland puede disparar IPC adicional con gnome-settings-daemon.
    # HighDpi rounding se aplica ANTES de crear QApplication (P01).
    # Aquí solo desactivamos la lectura de temas del entorno (GTK IPC).
    app.setDesktopSettingsAware(False)
    app.setStyle("Fusion")
    pal = QPalette()
    pal.setColor(QPalette.Window,          QColor("#0a0a0a"))
    pal.setColor(QPalette.WindowText,      QColor("#aaaaaa"))
    pal.setColor(QPalette.Base,            QColor("#0d0d0d"))
    pal.setColor(QPalette.AlternateBase,   QColor("#111111"))
    pal.setColor(QPalette.Text,            QColor("#cccccc"))
    pal.setColor(QPalette.Button,          QColor("#141414"))
    pal.setColor(QPalette.ButtonText,      QColor("#cccccc"))
    pal.setColor(QPalette.Highlight,       QColor("#303030"))
    pal.setColor(QPalette.HighlightedText, QColor("#ffffff"))
    app.setPalette(pal)

    # ── Fuentes embebidas — no depender de fuentes del sistema operativo
    # anfitrión (mismo criterio ya aplicado en el monolito de origen). Debe ejecutarse
    # DESPUÉS de crear QApplication (requisito de QFontDatabase) y ANTES
    # de construir LoritoAldhiroStudio, que ya usa estas fuentes en sus
    # widgets (contómetro, cuentavueltas, leyendas, texto general).
    _font_status = register_embedded_fonts()
    _fonts_failed = [fam for fam, ok in _font_status.items() if not ok]
    if _fonts_failed:
        _log.error("Fuentes embebidas no registradas: %s — se usará el "
                  "fallback de emergencia de Qt (nunca una fuente del "
                  "sistema operativo nombrada a mano)", _fonts_failed)
    app.setFont(font_ui())   # fuente por defecto de la aplicación

    w = LoritoAldhiroStudio()
    w.show()

    # ── Mostrar estado de RT privileges en la GUI al arrancar ─────────────────
    if _RT_STATUS is not None:
        if _RT_STATUS.rt_fully_ready:
            _rt_tag = "[rtkit]" if _RT_STATUS.rtkit_elevated else "[directo]"
            rt_msg = f"__CAROLA_VELOZ_OK__CAROLA VELOZ PERFECTA! {_rt_tag}"
        else:
            n_warns = len(_RT_STATUS.warnings)
            first_w = _RT_STATUS.warnings[0][:80] if _RT_STATUS.warnings else ""
            rt_msg = f"__CAROLA_VELOZ_WARN__⚠️ CAROLA VELOZ INUTIL {n_warns} aviso(s) — {first_w}"
        # Emitir vía bridge para que llegue al GUI thread de forma segura
        _bridge.status_msg.emit(rt_msg)

    sys.exit(app.exec())
