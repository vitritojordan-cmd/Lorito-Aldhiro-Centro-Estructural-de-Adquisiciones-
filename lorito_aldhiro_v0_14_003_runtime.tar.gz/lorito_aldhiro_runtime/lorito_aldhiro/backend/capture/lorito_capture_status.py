from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Estructura de estado de una sesión de captura (contadores del motor y telemetría de sesión), sin dependencias del motor.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_capture_status.py — la estructura de estado que comparte la sesión
de captura: contadores del motor y del escritor de disco, y la telemetría de
sesión que calcula la interfaz. Separada de `lorito_capture_engine` en
0.14.002 (LA-GOLDEN-CORE-020) para que `lorito_session_status`, el snapshot
de sesión y el archivo .sha256 la usen sin importar el motor ni PortAudio.
Quién escribe cada campo: `lorito_session_status.FIELD_OWNERS`.
"""

import threading


class CaptureEngineStatus:
    """
    Estructura de telemetría compartida entre todos los componentes.
    Todos los campos son atómicos en CPython (escritura de float/int/bool
    bajo GIL es indivisible). Sin locks en el hot path de lectura.
    """
    __slots__ = (
        # Stream
        "stream_alive", "recording", "paused",
        # Callbacks
        "callback_tick", "last_callback_ns",
        "frames_received", "frames_written", "frames_dropped",
        # Jitter
        "jitter_ewma_ms", "jitter_peak_ms", "jitter_p95_ms", "jitter_p99_ms",
        # Drift
        "drift_ms", "drift_ppm",
        # Buffers
        "rba_watermark_pct", "rba_overrun_total",
        "ced_pressure_pct", "ced_dropped_frames",
        # Disco
        "disk_alive", "disk_bytes_written", "disk_write_ms_last",
        # Watchdog
        "wd_phase", "recovery_count", "recovery_last_t",
        # XRuns
        "xrun_count", "starvation_events",
        # RT
        "estimated_latency_ms",
        # PSI
        "psi_cpu_pct", "psi_io_pct", "psi_mem_pct",
        # ── Campos heredados de BackendStatus (v0.22.00: _status redirigido al motor) ──
        "queue_size", "dsp_load", "frames_exported", "disk_write_secs",
        "backpressure_state",
        "ram_mb_approx", "ram_state",
        "callback_jitter_ms", "disk_write_ms_max", "disk_mbps",
        "drift_warn_count", "expected_frames",
        "clip_count_l", "clip_count_r",
        "archival_safe_mode", "last_callback_t",
        "callback_latency_sum", "callback_latency_count", "callback_latency_avg_ms",
        "rb_l1_occupancy_pct", "rb_l2_occupancy_pct",
        "segment_count", "current_segment_frames", "integrity_crc32_errors",
        "stress_test_active",
        "_xrlog_last_msg", "_xrlog_last_t", "_xrlog_repeat_count",
        "rb_l1_overrun_count", "rb_l2_expanded_count",
        "drift_ewma_ms", "drift_chronic", "drift_frames_pct",
        "disk_slow_count", "disk_io_protected",
        "normalization_mode", "normalization_gain_db", "normalization_peak_db",
        "normalization_lufs", "normalization_noise_floor_db", "normalization_true_peak_db",
        "normalization_stats",
        "normalization_pre_gain_db", "normalization_post_gain_db",
        "normalization_mid_rms", "normalization_side_rms", "normalization_stereo_balance",
        "normalization_crest_factor_db", "normalization_dynamic_range",
        "normalization_histogram_density", "normalization_silence_ratio",
        "normalization_auto_mode",
        "auto_normalization_decision", "auto_normalization_reason",
        "normalization_rms_final_db", "normalization_percentile_5",
        "normalization_percentile_95", "normalization_true_peak_final_db",
        "normalization_report_path",
        # ── Orden Golden de Captura (contadores separados por tipo, CAP-006/007) ──
        "capture_state", "failure_reason", "session_generation",
        "status_flag_callbacks", "input_overflow_count", "input_underflow_count",
        "ring_rejected_frames", "ring_rejected_blocks",
        "frames_persisted", "frames_verified", "finalization_incomplete",
        "visual_dropped_blocks", "derived_dropped_frames", "dsp_capture_disabled",
        "lock_free_verified", "writer_failed", "discontinuity_count",
        "_lock",
    )

    def __init__(self):
        self.stream_alive        = False
        self.recording           = False
        self.paused              = False
        self.callback_tick       = 0
        self.last_callback_ns    = 0
        self.frames_received     = 0
        self.frames_written      = 0
        self.frames_dropped      = 0
        self.jitter_ewma_ms      = 0.0
        self.jitter_peak_ms      = 0.0
        self.jitter_p95_ms       = 0.0
        self.jitter_p99_ms       = 0.0
        self.drift_ms            = 0.0
        self.drift_ppm           = 0.0
        self.rba_watermark_pct   = 0.0
        self.rba_overrun_total   = 0
        self.ced_pressure_pct    = 0.0
        self.ced_dropped_frames  = 0
        self.disk_alive          = False
        self.disk_bytes_written  = 0
        self.disk_write_ms_last  = 0.0
        self.wd_phase            = "OK"
        self.recovery_count      = 0
        self.recovery_last_t     = 0.0
        self.xrun_count          = 0
        self.starvation_events   = 0
        self.estimated_latency_ms= 0.0
        self.psi_cpu_pct         = 0.0
        self.psi_io_pct          = 0.0
        self.psi_mem_pct         = 0.0
        # ── Campos heredados de BackendStatus ────────────────────────────────
        self._lock                       = threading.Lock()
        self.queue_size                  = 0
        self.dsp_load                    = 0.0
        self.frames_exported             = 0
        self.disk_write_secs             = 0.0
        self.backpressure_state          = "SAFE"
        self.ram_mb_approx               = 0.0
        self.ram_state                   = "OK"
        self.callback_jitter_ms          = 0.0
        self.disk_write_ms_max           = 0.0
        self.disk_mbps                   = 0.0
        self.drift_warn_count            = 0
        self.expected_frames             = 0
        self.clip_count_l                = 0
        self.clip_count_r                = 0
        self.archival_safe_mode          = False
        self.last_callback_t             = 0.0
        self.callback_latency_sum        = 0.0
        self.callback_latency_count      = 0
        self.callback_latency_avg_ms     = 0.0
        self.rb_l1_occupancy_pct         = 0.0
        self.rb_l2_occupancy_pct         = 0.0
        self.segment_count               = 0
        self.current_segment_frames      = 0
        self.integrity_crc32_errors      = 0
        self.stress_test_active          = False
        self._xrlog_last_msg             = ""
        self._xrlog_last_t               = 0.0
        self._xrlog_repeat_count         = 0
        self.rb_l1_overrun_count         = 0
        self.rb_l2_expanded_count        = 0
        self.drift_ewma_ms               = 0.0
        self.drift_chronic               = False
        self.drift_frames_pct            = 0.0
        self.disk_slow_count             = 0
        self.disk_io_protected           = False
        self.normalization_mode          = ""
        self.normalization_gain_db       = 0.0
        self.normalization_peak_db       = 0.0
        self.normalization_lufs          = float("-inf")
        self.normalization_noise_floor_db= 0.0
        self.normalization_true_peak_db  = 0.0
        self.normalization_stats         = {}
        self.normalization_pre_gain_db   = 0.0
        self.normalization_post_gain_db  = 0.0
        self.normalization_mid_rms       = 0.0
        self.normalization_side_rms      = 0.0
        self.normalization_stereo_balance= 0.0
        self.normalization_crest_factor_db = 0.0
        self.normalization_dynamic_range = 0.0
        self.normalization_histogram_density = 0.0
        self.normalization_silence_ratio = 0.0
        self.normalization_auto_mode     = ""
        self.auto_normalization_decision = ""
        self.auto_normalization_reason   = ""
        self.normalization_rms_final_db  = 0.0
        self.normalization_percentile_5  = 0.0
        self.normalization_percentile_95 = 0.0
        self.normalization_true_peak_final_db = 0.0
        self.normalization_report_path   = ""
        # ── Orden Golden de Captura ─────────────────────────────────────────
        self.capture_state               = "IDLE"
        self.failure_reason              = ""
        self.session_generation          = 0
        self.status_flag_callbacks       = 0
        self.input_overflow_count        = 0
        self.input_underflow_count       = 0
        self.ring_rejected_frames        = 0
        self.ring_rejected_blocks        = 0
        self.frames_persisted            = 0
        self.frames_verified             = 0
        self.finalization_incomplete     = False
        self.visual_dropped_blocks       = 0
        self.derived_dropped_frames      = 0
        self.dsp_capture_disabled        = False
        self.lock_free_verified          = True
        self.writer_failed               = False
        self.discontinuity_count         = 0

