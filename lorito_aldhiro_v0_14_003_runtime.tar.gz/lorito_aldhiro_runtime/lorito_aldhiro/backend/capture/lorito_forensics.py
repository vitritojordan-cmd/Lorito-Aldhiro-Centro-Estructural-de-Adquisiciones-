from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Registro forense de eventos de la sesión de captura para auditoría posterior.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import sys
import os
import threading
import time
import queue
import traceback
import json
from collections import deque

from lorito_aldhiro.backend.core.lorito_constants import PLAYBACK_CHUNK_FRAMES



#  Detecta en tiempo real el origen exacto de pops al manipular scrub/morpher
#  y velocidad de reproducción.  Cero dependencias externas.
#  Activar: ejecutar con --forensics  o  fijar _FORENSICS_ACTIVE = True abajo.
#
#  Salida:
#    · stderr  : eventos críticos coloreados en tiempo real
#    · ~/AUX/fonogramas/pop_forensics.jsonl : log estructurado por sesión
#
#  Para analizar post-sesión:
#    python3 monolito v21.05 --analyze
#
#  CORRECCIONES v0.21.05 (forense aplicado):
#    FIX-XFADE-TRUNC        (POP-C5): crossfade truncado en bloques cortos;
#                            antes devolvía new_blk crudo → clic físico en
#                            near-EOF y ratio alto (ej. Morpher ×1.5).
#    FIX-DEADZONE-NOFLUSH   (POP-M3): zona muerta del Morpher usa
#                            set_speed_live_noflush en lugar de
#                            set_speed_live → elimina flush espurio al cruzar
#                            el centro durante drag continuo.
#    FIX-ELASTIC-CANCEL-RACE(POP-M2): _elastic_flush_cancelled se escribe
#                            ANTES de clear(evt) y snap_pos se sincroniza en ss
#                            directamente; elimina la race entre GUI y prefetch.
#    FIX-PHASE-FLAG-RACE    (POP-C4): el prefetch captura live_flush_flag
#                            ANTES de llamar a _speed_change_evt.clear(),
#                            eliminando la race de visibilidad del flag bajo GIL.
#    FIX-BRIDGE-TIMEOUT     (POP-C6): timeout del bridge 120→200ms; fallback
#                            de fade-out cuando el prefetch no entrega datos,
#                            en lugar de dejar fluir el deque viejo vacío.
# ══════════════════════════════════════════════════════════════════════════════

_FORENSICS_ACTIVE: bool = "--forensics" in sys.argv or os.environ.get("LORITO_ALDHIRO_FORENSICS") == "1"

# ── AIPLO Forensics — Auditor Integrado de Parámetros Lorito Ordenales ────────
# (renombrado desde "SIPA — Sistema Integrado de Parámetros de Auditoría":
#  SIPA son las iniciales reservadas al Sistema Inteligente de Pausa
#  Automática real, la función que activa la pausa por silencio durante la
#  grabación — vive en Silence Controller (`set_silence_autopause`/
#  `_check_silence_autopause`/`_activate_silence_autopause`/
#  `_deactivate_silence_autopause` en lorito_main_window.py), no este
#  subsistema de auditoría forense. Mismo renombre ya aplicado en el monolito de origen 0.24.)
# firma='aiplo_frn_init'
_AIPLO_FRN_ACTIVE:   bool  = _FORENSICS_ACTIVE
_aiplo_frn_tick_seq: int   = 0          # contador de ticks auditados
_aiplo_frn_counters: dict  = {          # contadores persistentes por categoría
    "autopause_activated"  : 0,
    "autopause_deactivated": 0,
    "counter_reset"        : 0,
    "emergency_flip"       : 0,
    "emergency_stop"       : 0,
    "tick_total"           : 0,
}
_aiplo_frn_t0_ns: int = time.monotonic_ns()   # referencia de tiempo AIPLO independiente

# ── Destino del log ───────────────────────────────────────────────────────────
_FRN_ARCHIVE_DIR  = os.path.expanduser("~/AUX/fonogramas")
_FRN_LOG_PATH     = os.path.join(_FRN_ARCHIVE_DIR, "pop_forensics.jsonl")

# ── Buffer en memoria (evita I/O en el hot path RT) ───────────────────────────
_frn_evt_queue: deque = deque(maxlen=100_000)
_frn_t0_ns     = time.monotonic_ns()
_frn_last_disk = 0.0   # monotonic del último vaciado a disco

# ── Estado de sesión ──────────────────────────────────────────────────────────
_frn_state: dict = {
    "prev_ns"         : _frn_t0_ns,
    "last_flush_ns"   : 0,
    "last_flush_type" : None,
    "underrun_total"  : 0,
    "xfade_short"     : 0,
    "double_flush"    : 0,
    "last_snap_pos"   : None,
    "last_snap_time"  : None,    # monotonic() en el último snap registrado
    "last_snap_ratio" : 1.0,     # |ratio| activo en ese momento
    "last_live_ratio" : None,
    "phase_prev_cursor": None,   # para detectar discontinuidades entre chunks
}


def _frn_emit(label: str, data: dict, *, crit: bool = False) -> None:
    """Emite evento al buffer. Imprime en stderr si activo."""
    if not _FORENSICS_ACTIVE:
        return
    now_ns = time.monotonic_ns()
    ms_d   = (now_ns - _frn_state["prev_ns"]) / 1_000_000.0
    _frn_state["prev_ns"] = now_ns
    rel_ms = (now_ns - _frn_t0_ns) / 1_000_000.0
    ev = {
        "t"   : round(rel_ms, 3),
        "ev"  : label,
        "thr" : threading.current_thread().name,
        "dms" : round(ms_d, 3),
        "d"   : data,
    }
    _frn_evt_queue.append(ev)
    color = "\033[91m" if crit else "\033[33m"
    tag   = "***" if crit else "   "
    # OPT-10: flush=True solo en eventos críticos; los normales usan buffer stdio
    print(f"{color}[FRN +{rel_ms:9.1f}ms] {tag} {label:<46}  Δ={ms_d:7.2f}ms  {data}\033[0m",
          file=sys.stderr, flush=crit)
    # Volcado asíncrono cada 2 s
    global _frn_last_disk
    if time.monotonic() - _frn_last_disk > 2.0:
        _frn_flush_disk_async()


class _FrnWriterWorker:
    """
    OPT-02: Worker persistente para escritura asíncrona del log forense.
    Reemplaza el patrón de threading.Thread() efímero en _frn_flush_disk_async.
    Hilo creado UNA sola vez; recibe batches via _queue.put_nowait().
    Cero overhead de creación de hilos en hot paths.
    """
    def __init__(self):
        self._queue: queue.Queue = queue.Queue(maxsize=4096)
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="frn-writer"
        )
        self._thread.start()

    def submit(self, batch: list) -> None:
        """Encola batch de eventos. Non-blocking. Descarta si cola llena."""
        try:
            self._queue.put_nowait(batch)
        except queue.Full:
            pass  # bajo presión extrema: sacrificar eventos forenses, nunca bloquear

    # FIX-LOG-SATURATION: límite de tamaño del log forense y guarda mínima de disco.
    _FRN_LOG_MAX_BYTES   = 32 * 1024 * 1024   # 32 MB máximo por archivo de log
    _FRN_DISK_MIN_BYTES  = 200 * 1024 * 1024  # no escribir si quedan < 200 MB libres

    def _loop(self) -> None:
        while True:
            batch = self._queue.get()
            if not batch:
                continue
            try:
                os.makedirs(_FRN_ARCHIVE_DIR, exist_ok=True)

                # FIX-LOG-SATURATION: verificar espacio libre antes de escribir.
                try:
                    st = os.statvfs(_FRN_ARCHIVE_DIR)
                    free_bytes = st.f_bavail * st.f_frsize
                    if free_bytes < self._FRN_DISK_MIN_BYTES:
                        print(f"[FRN] Disco casi lleno ({free_bytes//1024//1024} MB libres) "
                              f"— log forense suspendido.", file=sys.stderr)
                        continue
                except Exception:
                    pass  # si falla statvfs, intentar escribir igual

                # FIX-LOG-ROTATION: rotar si el log supera el límite.
                try:
                    if (os.path.exists(_FRN_LOG_PATH)
                            and os.path.getsize(_FRN_LOG_PATH) > self._FRN_LOG_MAX_BYTES):
                        rotated = _FRN_LOG_PATH + ".1"
                        if os.path.exists(rotated):
                            os.remove(rotated)
                        os.rename(_FRN_LOG_PATH, rotated)
                except Exception as rot_exc:
                    print(f"[FRN] Rotación de log falló: {rot_exc}", file=sys.stderr)

                with open(_FRN_LOG_PATH, "a", encoding="utf-8") as fh:
                    for ev in batch:
                        fh.write(json.dumps(ev) + "\n")
            except Exception as exc:
                print(f"[FRN] Error log disk: {exc}", file=sys.stderr)

_frn_writer_worker = _FrnWriterWorker()


def _frn_flush_disk_async() -> None:
    global _frn_last_disk
    _frn_last_disk = time.monotonic()
    batch = []
    while _frn_evt_queue:
        try:    batch.append(_frn_evt_queue.popleft())
        except IndexError: break
    if not batch:
        return
    # OPT-02: worker persistente en lugar de Thread() efímero
    _frn_writer_worker.submit(batch)


def _frn_short_stack(skip: int = 3) -> str:
    frames = traceback.extract_stack()[:-skip]
    return " → ".join(
        f"{os.path.basename(fr.filename)}:{fr.lineno}" for fr in frames[-3:]
    )


def _frn_check_double_flush(label: str) -> None:
    now_ns   = time.monotonic_ns()
    delta_ms = (now_ns - _frn_state["last_flush_ns"]) / 1_000_000.0
    if _frn_state["last_flush_ns"] > 0 and delta_ms < 10.0:
        _frn_state["double_flush"] += 1
        _frn_emit("POP_RISK_DOUBLE_FLUSH", {
            "flush_a" : _frn_state["last_flush_type"],
            "flush_b" : label,
            "delta_ms": round(delta_ms, 3),
            "n"       : _frn_state["double_flush"],
            "stack"   : _frn_short_stack(),
        }, crit=True)
    _frn_state["last_flush_ns"]   = now_ns
    _frn_state["last_flush_type"] = label


def _frn_check_snap_jump(new_snap: float, ratio: float = 1.0) -> None:
    prev       = _frn_state["last_snap_pos"]
    prev_time  = _frn_state["last_snap_time"]
    prev_ratio = _frn_state["last_snap_ratio"]

    if prev is not None:
        raw_delta = abs(new_snap - prev)

        # FIX-DYNAMIC-THRESHOLD (v0.21.04): umbral adaptado al tiempo transcurrido
        # y al ratio activo.  Un umbral fijo de 16000 frames (~333ms a 48kHz y 1x)
        # disparaba falsos positivos durante drag a ratio > 1.0 porque el playhead
        # avanza más rápido: a 1.5x ya supera 16000 en 222ms (debounce normal = 80ms).
        #
        # Nuevo criterio: el delta es sospechoso solo si excede lo que el playhead
        # PODRÍA haber derivado legítimamente al ratio máximo posible durante el
        # tiempo transcurrido desde el último snap registrado, con un margen de 20%.
        # Ratio máximo absoluto del sistema = MAX_FORWARD_MORPHER (1.5) o MAX_SPEED (2.0);
        # usamos 2.0 como cota conservadora.
        #
        #   umbral_dinamico = elapsed_s * ABS_MAX_RATIO * SR * MARGIN
        #
        # Si no hay timestamp previo (primera llamada tras arranque) usamos el
        # umbral estático de 16000 como fallback seguro.
        ABS_MAX_RATIO = 2.0      # MAX_SPEED / MAX_FORWARD del sistema
        SR            = 48000.0
        MARGIN        = 1.20     # 20 % de holgura sobre la deriva máxima teórica

        if prev_time is not None:
            elapsed_s      = time.monotonic() - prev_time
            dynamic_thresh = elapsed_s * ABS_MAX_RATIO * SR * MARGIN
            # FIX-RING-LOOKAHEAD (v0.22.13): tras cada flush live, el prefetch reinicia
            # desde snap_pos (=head_pos) y rellena el ring buffer íntegramente en el
            # siguiente ciclo.  head_pos avanza entonces por
            #   PLAYBACK_RING_CHUNKS * PLAYBACK_CHUNK_FRAMES  (= 4 * 4096 = 16384 frames)
            # adicionales de golpe, independientemente del tiempo transcurrido.
            # Si no se suma esta holgura al umbral, _frn_check_snap_jump dispara un
            # POP_RISK_SNAP_JUMP falso en *cada* flush live durante drag continuo.
            #
            # FIX-RING-LOOKAHEAD-RATIO (v0.22.14): el cálculo anterior usaba
            # PLAYBACK_RING_CHUNKS * PLAYBACK_CHUNK_FRAMES (= 4 * 4096 = 16384 frames)
            # como holgura fija, asumiendo que head_pos solo avanza por el llenado del
            # chunk_q (4 slots).  En la práctica head_pos también avanza por el vaciado
            # y rellenado del deque del bridge (otros 4 slots de PE_RING_CHUNKS), y cada
            # lectura de fuente consume PE_CHUNK_FRAMES * abs_ratio muestras (no fijas).
            # Resultado: entre dos flushes consecutivos a ~83ms, head_pos sube en
            # ≈ 8 * PE_CHUNK_FRAMES * abs_ratio frames, casi el doble de lo esperado
            # a ratio > 1.0 → 173 falsos POP_RISK_SNAP_JUMP documentados en el log
            # (pop_forensics.jsonl: 116 + 40 + 8 + 8 + 1 disparos, todos durante drag
            # continuo con ratio entre 1.0 y 2.0, delta/threshold ≈ 1.7x medio).
            #
            # Nuevo RING_LOOKAHEAD = 10 * PLAYBACK_CHUNK_FRAMES * max(abs_ratio, 1.0)
            # El factor 10 = 8 slots efectivos (chunk_q×4 + deque×4) + 20 % de margen,
            # validado sobre todos los 173 eventos del log: suprime el 100 % de los
            # falsos positivos sin enmascarar ningún salto real fuera del rango esperado.
            abs_ratio      = max(abs(ratio), 1.0)
            RING_LOOKAHEAD = 10 * PLAYBACK_CHUNK_FRAMES * abs_ratio
            threshold      = max(dynamic_thresh + RING_LOOKAHEAD, 16000.0)
        else:
            abs_ratio      = max(abs(ratio), 1.0)
            threshold      = 16000.0 + 10 * PLAYBACK_CHUNK_FRAMES * abs_ratio

        if raw_delta > threshold:
            _frn_emit("POP_RISK_SNAP_JUMP", {
                "prev"         : round(prev, 1),
                "new"          : round(new_snap, 1),
                "delta_frames" : round(raw_delta, 1),
                "threshold"    : round(threshold, 1),
                "stack"        : _frn_short_stack(),
            }, crit=True)

    now = time.monotonic()
    _frn_state["last_snap_pos"]   = new_snap
    _frn_state["last_snap_time"]  = now
    _frn_state["last_snap_ratio"] = abs(ratio)


def _frn_sync_snap(new_snap: float, ratio: float = 1.0) -> None:
    """Sincroniza last_snap_pos en el detector forense sin emitir POP_RISK.

    Llamar ANTES de toda sincronización manual de snap_pos = src_pos que
    precede a un flush discreto (FIX-RELEASE-SNAP, FIX-MOTOR-SNAP, etc.).
    Registra también el ratio activo para que el umbral dinámico sea preciso.
    """
    now = time.monotonic()
    _frn_state["last_snap_pos"]   = new_snap
    _frn_state["last_snap_time"]  = now
    _frn_state["last_snap_ratio"] = abs(ratio)
