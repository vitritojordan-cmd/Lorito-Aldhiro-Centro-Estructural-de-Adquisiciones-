from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Frecuencias de captura admitidas, verificación previa contra el dispositivo y dimensionado de buffers en segundos.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Soporte de frecuencia de muestreo de la captura (0.13.002).

**Qué admite cada capa:**

- **Motor de captura** (`CaptureEngineV2`): cualquier frecuencia entera. Se
  probó de punta a punta de 8 kHz a 384 kHz. No convierte frecuencias: pasa
  la pedida al driver (`sd.InputStream(samplerate=…)`).
- **Cadena DSP:** `lorito_dsp_contract.SUPPORTED_RATES`, de 22,05 kHz a
  192 kHz.
- **Lorito** (menú MUESTRA): `CAPTURE_RATES`, de 44,1 kHz a 192 kHz, las
  frecuencias de archivo de audio.

**Verificación previa.** `check_capture_rate` consulta al dispositivo con
`sounddevice.check_input_settings`, que llama a `Pa_IsFormatSupported` de
PortAudio. Lo hace antes de armar la sesión: una frecuencia que el
dispositivo rechaza no deja una sesión a medio armar. Si el módulo de audio
no ofrece la consulta (stubs de prueba), el resultado queda como "no
verificado" y decide la apertura real del stream.

**Límite honesto.** Con ALSA `plughw` o con PipeWire, el dispositivo
"default" puede aceptar la frecuencia y convertirla por software. PortAudio
informa la frecuencia del *stream*, no la del conversor A/D. Lorito verifica
la del stream, pero no puede ver la del hardware.

**Buffers en segundos.** El ring de absorción y la cola elástica de disco
tenían un tamaño fijo en frames. Eso daba 21,8 s y 10,7 s a 48 kHz, pero
solo 5,5 s y 2,7 s a 192 kHz. `buffer_plan` los dimensiona en segundos. Los
valores históricos quedan como piso, así que a ≤ 48 kHz nada cambia.
"""

import math
from dataclasses import dataclass

from lorito_aldhiro.backend.core.lorito_constants import (
    CE_RBA_SLOTS, CE_RBA_FRAMES_MAX, CE_CED_CAPACITY, CE_CHANNELS,
)

CAPTURE_RATES = (44100, 48000, 88200, 96000, 176400, 192000)

# Margen en segundos que se conserva a cualquier frecuencia: el que tenían
# los buffers a 48 kHz con el perfil "balanced" (2048 frames por bloque).
RBA_TARGET_SECS = 20.0
CED_TARGET_SECS = 10.0
RBA_SLOTS_MAX = 2048            # tope de memoria: 2048 × 4096 × 2 × 4 B = 64 MiB


@dataclass(frozen=True)
class RateCheck:
    rate: int
    ok: bool
    verified: bool                # True si el dispositivo lo confirmó
    reason: str = ""


def check_capture_rate(rate: int, channels: int = CE_CHANNELS, sd_module=None,
                       device=None) -> RateCheck:
    """¿Se puede capturar a `rate`? Lista de Lorito → contrato DSP →
    dispositivo. Nunca lanza."""
    try:
        rate = int(rate)
    except (TypeError, ValueError):
        return RateCheck(0, False, False, "frecuencia inválida")
    if rate not in CAPTURE_RATES:
        return RateCheck(rate, False, False, f"{rate} Hz fuera de las frecuencias de captura {CAPTURE_RATES}")
    try:
        from lorito_aldhiro.backend.dsp.lorito_dsp_contract import SUPPORTED_RATES
    except Exception:
        SUPPORTED_RATES = CAPTURE_RATES
    if rate not in SUPPORTED_RATES:
        return RateCheck(rate, False, False, f"{rate} Hz no admitida por la cadena DSP")
    if sd_module is None:
        try:
            import sounddevice as sd_module          # noqa: F811
        except Exception:
            sd_module = None
    check = getattr(sd_module, "check_input_settings", None)
    if check is None:
        return RateCheck(rate, True, False, "dispositivo no consultable: decide la apertura del stream")
    try:
        check(device=device, channels=channels, dtype="float32", samplerate=rate)
    except Exception as e:
        return RateCheck(rate, False, True, f"el dispositivo rechaza {rate} Hz: {e}")
    return RateCheck(rate, True, True, "")


@dataclass(frozen=True)
class BufferPlan:
    rba_slots: int
    ced_frames: int

    def rba_secs(self, rate: int, blocksize: int) -> float:
        return self.rba_slots * blocksize / float(rate)

    def ced_secs(self, rate: int) -> float:
        return self.ced_frames / float(rate)


def buffer_plan(rate: int, blocksize: int) -> BufferPlan:
    """Slots del ring y capacidad de la cola para conservar el margen en
    segundos. Piso: los valores históricos (sin cambios a ≤ 48 kHz)."""
    rate = max(int(rate), 1)
    bs = max(1, min(int(blocksize), CE_RBA_FRAMES_MAX))
    slots = max(CE_RBA_SLOTS, min(RBA_SLOTS_MAX, math.ceil(RBA_TARGET_SECS * rate / bs)))
    ced = max(CE_CED_CAPACITY, math.ceil(CED_TARGET_SECS * rate))
    return BufferPlan(slots, ced)
