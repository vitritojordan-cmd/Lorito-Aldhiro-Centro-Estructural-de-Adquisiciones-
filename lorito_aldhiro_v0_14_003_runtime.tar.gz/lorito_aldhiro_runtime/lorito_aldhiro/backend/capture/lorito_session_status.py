from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Propietario único del estado de sesión: el estado del motor de captura, enlazado por la ventana (LA-GOLDEN-CORE-020 §4).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Hasta 0.14.001 había dos objetos de estado de sesión:

- el `CaptureEngineStatus` del motor, que cuenta frames, escrituras a
  disco, xruns, etc.;
- un `BackendStatus` global, que la interfaz ponía a cero y leía sin que
  nadie lo actualizara.

En el monolito original, la ventana redirigía el global al estado del motor
con `global _status`. Al partirse en mixins, la redirección quedó en un solo
módulo y el resto siguió leyendo el global. Consecuencias: el snapshot
periódico de sesión no se guardaba nunca, la deriva se calculaba contra 0
(aviso falso durante cada grabación) y el chequeo de integridad de la
exportación comparaba 0 con 0.

Desde 0.14.002 hay un único objeto: el estado del motor. La raíz de
composición (`services.lorito_app_services.build_app_services`, que llama la
ventana) lo enlaza una vez con `bind()` al crear el motor, y la ventana lo
guarda en `self._session_status`. Los módulos del núcleo que lo necesitan fuera de la
ventana (snapshot de sesión, archivo .sha256) lo piden con `current()` en el
momento de usarlo.

Cada campo tiene un único escritor. `FIELD_OWNERS` lo documenta y
`tests/test_core_servicios.py` comprueba que la interfaz no escribe campos
del motor.
"""

from typing import Optional

from lorito_aldhiro.backend.capture.lorito_capture_status import CaptureEngineStatus

# Escritor único por grupo de campos.
FIELD_OWNERS: dict[str, frozenset] = {
    # Motor de captura y escritor de disco (lorito_capture_engine).
    "motor": frozenset({
        "stream_alive", "recording", "paused", "callback_tick", "last_callback_ns",
        "frames_received", "frames_written", "frames_dropped", "frames_persisted",
        "frames_verified", "xrun_count", "starvation_events", "recovery_count",
        "recovery_last_t", "wd_phase", "disk_alive", "disk_bytes_written",
        "disk_write_ms_last", "jitter_ewma_ms", "jitter_peak_ms", "capture_state",
        "failure_reason", "session_generation", "writer_failed",
        "finalization_incomplete", "lock_free_verified", "estimated_latency_ms",
    }),
    # Telemetría de sesión que calcula la interfaz (mixins de grabación,
    # telemetría y auto-pausa).
    "telemetria_ui": frozenset({
        "drift_ms", "drift_ewma_ms", "drift_chronic", "drift_warn_count",
        "expected_frames", "last_callback_t", "ram_mb_approx", "ram_state",
        "backpressure_state", "callback_jitter_ms", "disk_write_ms_max", "disk_mbps",
        "clip_count_l", "clip_count_r", "archival_safe_mode",
    }),
    # Resultado de la exportación (mixin de exportación, desde ExportResult).
    "exportacion": frozenset({"frames_exported", "normalization_mode"}),
}

_bound: Optional[CaptureEngineStatus] = None
_idle: CaptureEngineStatus = CaptureEngineStatus()


def bind(status: CaptureEngineStatus) -> CaptureEngineStatus:
    """Enlaza el estado del motor como estado de la sesión. Lo llama solo la
    raíz de composición al crear el motor; devuelve el mismo objeto."""
    global _bound
    if not isinstance(status, CaptureEngineStatus):
        raise TypeError(f"se esperaba CaptureEngineStatus, llegó {type(status).__name__}")
    _bound = status
    return status


def current() -> CaptureEngineStatus:
    """Estado de la sesión en curso. Sin ventana (herramientas, pruebas del
    núcleo) es un estado en reposo, con todos los contadores en cero."""
    return _bound if _bound is not None else _idle


def is_bound() -> bool:
    return _bound is not None
