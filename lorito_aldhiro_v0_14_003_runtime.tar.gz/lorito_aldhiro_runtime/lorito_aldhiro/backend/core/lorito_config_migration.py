from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Migración versionada, idempotente y reversible de los archivos de control de sesión a los nombres propios de Lorito (LA-GOLDEN-CORE-020 §6, CFG-01).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Qué migra: solo los archivos de CONTROL que Lorito deja en el archivo de
capturas (`ARCHIVE_DIR`) entre una sesión y la siguiente, es decir el
latido de sesión activa y el manifiesto de recuperación de crash. Con
nombres heredados, una sesión destruida antes de actualizar no se
detectaría al arrancar la versión nueva.

Qué NO toca (§6 y principio "RAW intacto"):
- capturas RAW, temporales `.wav` y segmentos (el manifiesto los sigue
  señalando por su ruta original, que no cambia);
- exportaciones ya hechas y sus archivos de especificación;
- logs antiguos: quedan donde están como historial; los nuevos se
  escriben con el nombre del catálogo.

Contrato:
- Validación previa: el manifiesto heredado debe ser JSON legible; si no
  lo es, no se migra, se informa el error y el original queda intacto.
- Respaldo: antes de mover nada se copia cada archivo a
  `MIGRATION_BACKUP_DIR` con su SHA-256.
- Idempotencia: el estado queda en `MIGRATION_STATE_FILE`; con el esquema
  ya al día, `migrate_persistence` no hace nada.
- Reversibilidad: `rollback_persistence` restaura los nombres anteriores
  desde el respaldo y borra el estado.
- Nunca falla en silencio: devuelve un `MigrationReport` tipado con lo
  hecho y los errores, y el llamador lo registra.
"""

import hashlib
import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from lorito_aldhiro.backend.core import lorito_identity as ident

# Nombres que usaban las versiones hasta 0.13.009 → nombre del catálogo.
# Es el único lugar del código que conoce los nombres anteriores; el
# escáner de referencias admite este literal por archivo y constante.
LEGACY_PERSISTENCE_NAMES: dict[str, str] = {
    ".aecct2_session_active": ident.CRASH_HEARTBEAT_FILE,
    ".aecct2_crash_manifest.json": ident.CRASH_MANIFEST_FILE,
}
_JSON_FILES = frozenset({ident.CRASH_MANIFEST_FILE})


class MigrationError(Exception):
    """Fallo tipado de la migración de persistencia."""


@dataclass
class MigrationReport:
    archive_dir: str
    from_version: int
    to_version: int
    migrated: list[tuple[str, str]] = field(default_factory=list)
    backed_up: list[tuple[str, str]] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    @property
    def changed(self) -> bool:
        return bool(self.migrated)


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _state_path(archive_dir: str) -> str:
    return os.path.join(archive_dir, ident.MIGRATION_STATE_FILE)


def read_schema_version(archive_dir: str) -> int:
    """Versión de esquema registrada (1 = sin registro, nombres heredados)."""
    try:
        with open(_state_path(archive_dir), encoding="utf-8") as fh:
            return int(json.load(fh).get("schema_version", 1))
    except FileNotFoundError:
        return 1
    except (ValueError, OSError, AttributeError) as e:
        raise MigrationError(f"estado de migración ilegible: {e}") from e


def _write_state(archive_dir: str, report: MigrationReport) -> None:
    tmp = _state_path(archive_dir) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({
            "schema_version": report.to_version,
            "migrated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "migrated": report.migrated,
            "backup": report.backed_up,
        }, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, _state_path(archive_dir))


def migrate_persistence(archive_dir: str) -> MigrationReport:
    """Lleva los archivos de control de `archive_dir` al esquema actual."""
    target = ident.PERSISTENCE_SCHEMA_VERSION
    try:
        current = read_schema_version(archive_dir)
    except MigrationError as e:
        rep = MigrationReport(archive_dir, 0, target)
        rep.errors.append(str(e))
        return rep
    rep = MigrationReport(archive_dir, current, target)
    if current >= target:
        return rep
    backup_dir = os.path.join(archive_dir, ident.MIGRATION_BACKUP_DIR)
    for old_name, new_name in LEGACY_PERSISTENCE_NAMES.items():
        old = os.path.join(archive_dir, old_name)
        new = os.path.join(archive_dir, new_name)
        if not os.path.exists(old):
            rep.skipped.append(old_name)
            continue
        if new_name in _JSON_FILES:
            try:
                with open(old, encoding="utf-8") as fh:
                    json.load(fh)
            except (ValueError, OSError) as e:
                rep.errors.append(f"{old_name}: no es JSON válido ({e}); se deja intacto")
                continue
        try:
            os.makedirs(backup_dir, exist_ok=True)
            bak = os.path.join(backup_dir, old_name)
            shutil.copy2(old, bak)
            if _sha256(bak) != _sha256(old):
                raise MigrationError("el respaldo no coincide con el original")
            rep.backed_up.append((old_name, _sha256(bak)))
            if os.path.exists(new):
                # Ya hay uno con el nombre nuevo (más reciente): gana el
                # nuevo; el heredado queda solo en el respaldo.
                os.remove(old)
            else:
                os.replace(old, new)
            rep.migrated.append((old_name, new_name))
        except (OSError, MigrationError) as e:
            rep.errors.append(f"{old_name}: {e}")
    if rep.ok:
        try:
            _write_state(archive_dir, rep)
        except OSError as e:
            rep.errors.append(f"no se pudo registrar el estado: {e}")
    return rep


def rollback_persistence(archive_dir: str) -> MigrationReport:
    """Deshace la migración: restaura los nombres anteriores desde el respaldo."""
    try:
        current = read_schema_version(archive_dir)
    except MigrationError as e:
        rep = MigrationReport(archive_dir, 0, 1)
        rep.errors.append(str(e))
        return rep
    rep = MigrationReport(archive_dir, current, 1)
    backup_dir = os.path.join(archive_dir, ident.MIGRATION_BACKUP_DIR)
    for old_name, new_name in LEGACY_PERSISTENCE_NAMES.items():
        bak = os.path.join(backup_dir, old_name)
        new = os.path.join(archive_dir, new_name)
        if not os.path.exists(bak):
            rep.skipped.append(old_name)
            continue
        try:
            shutil.copy2(bak, os.path.join(archive_dir, old_name))
            if os.path.exists(new):
                os.remove(new)
            rep.migrated.append((new_name, old_name))
        except OSError as e:
            rep.errors.append(f"{old_name}: {e}")
    if rep.ok:
        try:
            os.remove(_state_path(archive_dir))
        except FileNotFoundError:
            pass
    return rep


def describe(report: MigrationReport) -> Optional[str]:
    """Línea de log para el arranque; None si no hubo nada que contar."""
    if report.errors:
        return (f"Migración de persistencia v{report.from_version}→v{report.to_version} "
                f"con errores: {'; '.join(report.errors)}")
    if report.changed:
        pairs = ", ".join(f"{a} → {b}" for a, b in report.migrated)
        return f"Migración de persistencia v{report.from_version}→v{report.to_version}: {pairs}"
    return None
