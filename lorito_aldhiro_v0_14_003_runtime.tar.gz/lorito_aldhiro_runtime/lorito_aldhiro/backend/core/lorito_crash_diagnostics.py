from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Diagnóstico de fallos nativos (faulthandler) y de excepciones no capturadas, con versión y estado (LA-GOLDEN-VIEW-SIGSEGV-019).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Capa C de la Orden LA-GOLDEN-VIEW-SIGSEGV-019. Un SIGSEGV no se "corrige"
con try/except. Lo que se puede hacer es dejar registrado el **primer**
punto de fallo para corregir la causa raíz:

- `faulthandler` escribe el stack de **todos** los hilos en
  `crash_faulthandler.log` ante SIGSEGV, SIGFPE, SIGABRT, SIGBUS o SIGILL.
  Antes deja un encabezado con versión, pid, hora y plataforma.
- `sys.excepthook` y `threading.excepthook` registran las excepciones no
  capturadas con el mismo encabezado. Antes, un hilo podía morir en
  silencio.

**Protocolo (Capa D).** Tras un fallo nativo no se intenta seguir dentro del
mismo proceso: la memoria puede estar corrupta. El proceso termina. En el
siguiente arranque, el `CrashGuard` y el manifiesto de sesión (ya
existentes) recuperan el último estado seguro y verifican los archivos. La
captura RAW la escribe el hilo de disco, independiente del visor.
"""

import datetime
import faulthandler
import os
import platform
import sys
import threading
import traceback

_STATE = {"file": None, "path": ""}


def _header(kind: str) -> str:
    try:
        from lorito_aldhiro.backend.core.lorito_version import APP_VERSION
    except Exception:
        APP_VERSION = "?"
    return (f"\n===== Lorito Aldhiro {APP_VERSION} · {kind} · pid {os.getpid()} · "
            f"{datetime.datetime.now().isoformat(timespec='seconds')} · "
            f"{platform.platform()} · Python {platform.python_version()} =====\n")


def enable(log_dir: str) -> str:
    """Activa el diagnóstico. Devuelve la ruta del log. Idempotente."""
    if _STATE["file"] is not None:
        return _STATE["path"]
    os.makedirs(log_dir, exist_ok=True)
    path = os.path.join(log_dir, "crash_faulthandler.log")
    f = open(path, "a", encoding="utf-8", buffering=1)
    f.write(_header("sesión iniciada (faulthandler activo)"))
    faulthandler.enable(file=f, all_threads=True)
    _STATE.update(file=f, path=path)

    prev_sys = sys.excepthook

    def _sys_hook(exc_type, exc, tb):
        try:
            f.write(_header("excepción no capturada (hilo principal)"))
            traceback.print_exception(exc_type, exc, tb, file=f)
        except Exception:
            pass
        prev_sys(exc_type, exc, tb)

    def _thread_hook(args):
        try:
            f.write(_header(f"excepción no capturada (hilo {args.thread.name if args.thread else '?'})"))
            traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback, file=f)
        except Exception:
            pass

    sys.excepthook = _sys_hook
    threading.excepthook = _thread_hook
    return path


def disable() -> None:
    f = _STATE["file"]
    if f is None:
        return
    try:
        faulthandler.disable()
        f.write(_header("sesión cerrada en orden"))
        f.close()
    except Exception:
        pass
    _STATE.update(file=None, path="")


def is_enabled() -> bool:
    return _STATE["file"] is not None and faulthandler.is_enabled()
