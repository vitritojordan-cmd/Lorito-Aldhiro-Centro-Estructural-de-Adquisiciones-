from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Catálogo único de nombres propios de Lorito Aldhiro: aplicación, loggers, hilos, archivos de sesión y de exportación (LA-GOLDEN-CORE-020 §3).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Única fuente de los nombres que Lorito Aldhiro escribe fuera de su
código: nombres de logger y de hilo, archivos de control de sesión en el
archivo de capturas, prefijos de temporales y de exportaciones, y el
archivo de especificación que acompaña a cada exportación. Ningún otro
módulo debe escribir estos literales a mano; se piden aquí.

Los nombres anteriores a la Orden LA-GOLDEN-CORE-020 los conoce solo
`lorito_config_migration`, que migra lo que haya en disco a los nombres
de este catálogo.
"""

from typing import Final

# ── Identidad de la aplicación ─────────────────────────────────────────
APP_ID: Final[str] = "lorito_aldhiro"
APP_DISPLAY_NAME: Final[str] = "Lorito Aldhiro"

# ── Registro de eventos ────────────────────────────────────────────────
# Dos espacios de logger, con propósito distinto:
# - LOGGER_ROOT: aplicación (GUI, integración, exportación). Tiene el
#   manejador rotativo del log interno en ARCHIVE_DIR.
# - ENGINE_LOGGER_ROOT: motores de captura y DSP. Sin manejador propio:
#   no escriben a disco de forma síncrona desde sus hilos (§8); los avisos
#   graves salen por el manejador de último recurso de `logging`.
LOGGER_ROOT: Final[str] = "lorito_aldhiro"
ENGINE_LOGGER_ROOT: Final[str] = "lorito"
INTERNAL_LOG_FILE: Final[str] = "lorito_internal.log"

# ── Hilos ──────────────────────────────────────────────────────────────
THREAD_PREFIX: Final[str] = "lorito-"

# ── Archivos de control de sesión (relativos a ARCHIVE_DIR) ────────────
CRASH_HEARTBEAT_FILE: Final[str] = ".lorito_session_active"
CRASH_MANIFEST_FILE: Final[str] = ".lorito_crash_manifest.json"
TEMP_CAPTURE_PREFIX: Final[str] = ".tmp_lorito_"
# Versión del esquema de nombres y archivos de control; la migración la
# deja escrita en MIGRATION_STATE_FILE.
PERSISTENCE_SCHEMA_VERSION: Final[int] = 2
MIGRATION_STATE_FILE: Final[str] = ".lorito_schema.json"
MIGRATION_BACKUP_DIR: Final[str] = ".lorito_migracion_respaldo"

# ── Exportación ────────────────────────────────────────────────────────
EXPORT_FILE_PREFIX: Final[str] = "lorito_"
SESSION_SPEC_SUFFIX: Final[str] = "_lorito_spec.txt"
SESSION_SPEC_TITLE: Final[str] = "Aldhira de Especificación de Lorito"
TAPE_COUNTER_LABEL: Final[str] = "Lorito Tape Counter"


def logger_name(component: str = "") -> str:
    """Logger de aplicación ("lorito_aldhiro" o "lorito_aldhiro.<componente>")."""
    return f"{LOGGER_ROOT}.{component}" if component else LOGGER_ROOT


def engine_logger_name(component: str) -> str:
    """Nombre de logger de motor ("lorito.<componente>"), sin log a disco."""
    return f"{ENGINE_LOGGER_ROOT}.{component}"


def thread_name(component: str) -> str:
    """Nombre de hilo con el prefijo de Lorito ("lorito-<componente>")."""
    return f"{THREAD_PREFIX}{component}"
