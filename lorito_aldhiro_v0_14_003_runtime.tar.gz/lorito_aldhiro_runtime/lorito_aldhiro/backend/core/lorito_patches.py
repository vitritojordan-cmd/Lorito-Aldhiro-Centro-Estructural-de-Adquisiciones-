from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Parches de compatibilidad aplicados al arrancar la aplicación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import math as _math


# [LIMPIEZA v0.22.01 BUG10] Imports redundantes eliminados (json, os, time, math,
# threading, enum, typing, numpy ya importados globalmente en líneas 3-22).
# Dict, Any migrados al import global de typing.

# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS — reutiliza los del módulo principal si están disponibles
# ─────────────────────────────────────────────────────────────────────────────

def _db_to_lin(db: float) -> float:
    return 10.0 ** (db / 20.0)

def _lin_to_db(lin: float) -> float:
    if lin < 1e-12:
        return float("-inf")
    return 20.0 * _math.log10(lin)
