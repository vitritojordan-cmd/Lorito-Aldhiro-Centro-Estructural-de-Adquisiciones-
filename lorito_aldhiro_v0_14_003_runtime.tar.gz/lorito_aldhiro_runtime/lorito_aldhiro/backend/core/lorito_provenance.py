from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Atribución histórica de Lorito Aldhiro y ruta de su archivo de procedencia (LA-GOLDEN-CORE-020 §3, referencia histórica).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Lorito Aldhiro nació como bifurcación de un producto anterior de Carola
Records (versión 0.22.57, 2026). Por pedido de la usuaria, esa procedencia
queda como referencia histórica: una sola línea de atribución, visible en
el diálogo de información de la aplicación, y el archivo documental
segregado en `legado/procedencia/` (fuera del paquete importable).

Esta constante es la única aparición permitida del nombre del producto de
origen en el código de la aplicación; el escáner de referencias
(`tools/refs/lorito_ref_scanner.py`) la admite por archivo, nombre y valor
exactos. No es un nombre de producto, ruta, logger ni condición de
ejecución: solo texto de atribución.
"""

from typing import Final

HISTORICAL_ATTRIBUTION: Final[str] = "Lorito Aldhiro. Powered by Carola Records Aldhira Capture CRAC"

# Bifurcación: versión del producto de origen y primera revisión de Lorito.
FORK_ORIGIN_VERSION: Final[str] = "0.22.57"
FORK_FIRST_REVISION: Final[str] = "0.01.002"

# Archivo documental (relativo a la raíz del árbol de fuentes; no se
# distribuye en el paquete de producción).
HISTORICAL_ARCHIVE_DIR: Final[str] = "legado/procedencia"
