from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Cálculo de la versión de la aplicación a partir del historial de CHANGELOG.md.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import re
from collections import deque
import random
import numpy as np


# ══════════════════════════════════════════════════════════════════════════════
#  MÓDULO DEDICADO DE REGISTRO DE VERSIÓN — LORITO ALDHIRO
#
#  Única fuente de verdad para el nombre y el número de versión de la app.
#  Esquema:      <MARCA> <ETAPA> <MAYOR>.<MENOR>.<REVISIÓN>
#  Ejemplo:      "Lorito Aldhiro Alpha 0.01.002"
#
#  · MAYOR / MENOR (APP_MAJOR / APP_MINOR más abajo) se fijan a mano.
#  · REVISIÓN (los 3 dígitos finales) NO se edita a mano: se calcula
#    programáticamente contando las entradas registradas en /CHANGELOG.md
#    (una entrada == una tanda de cambios incorporada al tarball). Cada
#    entrada de CHANGELOG puede enlazar a un "gap de referencia" en
#    /gaps/GAP-NNN.md, donde se documenta en detalle el tratamiento técnico
#    de esa revisión. Agregar una entrada nueva a CHANGELOG.md eleva este
#    número automáticamente la próxima vez que se importe este módulo —
#    no requiere tocar código.
# ══════════════════════════════════════════════════════════════════════════════

#  ── AVISO DE BIFURCACIÓN (revisión 002) ───────────────────────────────────
#  A partir de esta revisión, el monolito de origen (versión 0.22.57) se
#  bifurca en LORITO ALDHIRO 0.01.002. Es una bifurcación creada para
#  resolver los problemas de recontraemergencia que atraviesa el fuero
#  Finguered, y deberá usarse mientras el producto de origen continúa su
#  propio desarrollo por separado. Ver /CHANGELOG.md [002] y
#  /gaps/GAP-001.md. Desde 0.14 (Orden LA-GOLDEN-CORE-020) la procedencia
#  queda como referencia histórica: atribución en lorito_provenance y
#  archivo documental en /legado/procedencia/.
#  ───────────────────────────────────────────────────────────────────────────

APP_BRAND = "Lorito Aldhiro"
APP_STAGE = "Alpha"
APP_MAJOR = 0
APP_MINOR = 14

#  ── AVISO DE SALTO DE VERSIÓN (revisión 078) ──────────────────────────────
#  Cierre formal de la "Orden Maestra de Ingeniería: Saneamiento,
#  integración y consolidación de Lorito Aldhiro" — las 12 fases quedan
#  completas/cerradas (ver /ESTADO_MAESTRO_CONSOLIDACION.md, veredicto
#  final, y /gaps/GAP-075.md, FASE 12/Release Candidate). Instrucción
#  explícita del usuario: la versión permanece en la línea 0.10.x hasta
#  que las 12 fases se cierren por completo, y solo entonces se eleva a
#  0.11. Esa condición se cumple con este mismo commit de CHANGELOG.md
#  ([078]). APP_MINOR pasa de 10 a 11 a mano. _MINOR_REVISION_BASE se
#  actualiza a 77 (la última cuenta de entradas bajo MENOR=10, ver
#  CHANGELOG.md [077]) para que la REVISIÓN vuelva a 001 bajo este MENOR
#  nuevo sin reescribir el historial de CHANGELOG.md — mismo patrón ya
#  usado en los saltos 0.05→0.06 (revisión 021), 0.06→0.07 (revisión
#  031), 0.07→0.08 (revisión 043), 0.08→0.09 (revisión 045) y 0.09→0.10
#  (revisión 051).
#
#  A partir de esta versión, la próxima auditoría profunda declarada por
#  el usuario ("descontaminación de la tubería de audio y DSP de hilos
#  GUI y otras optimizaciones") queda como el siguiente frente de trabajo
#  — explícitamente FUERA de alcance de esta Orden ya cerrada.
#  ───────────────────────────────────────────────────────────────────────────
#  ── AVISO DE SALTO DE VERSIÓN (revisión 093) ──────────────────────────────
#  Instrucción explícita de la usuaria: "Una vez finalizado todos los
#  tratamientos, elevas versión a 0.12". Los tratamientos son:
#  - panel fusionado onda · cinta · log;
#  - barra de menús y persianas de 4 ítems con scroll;
#  - marco de madera;
#  - Orden LA-GOLDEN-TRANSPORT-018 (FF/REW);
#  - Orden LA-GOLDEN-NORM-ARCH-017 (normalización y archivo de legado).
#  Todos cierran con CHANGELOG.md [093]. APP_MINOR pasa de 11 a 12 a mano y
#  _MINOR_REVISION_BASE a 92 (la última entrada bajo MENOR=11, [092]), así
#  que [093] es 0.12.001: el mismo patrón que el salto 0.10 → 0.11
#  (revisión 078).
#  ───────────────────────────────────────────────────────────────────────────
#  ── AVISO DE SALTO DE VERSIÓN (revisión 094) ──────────────────────────────
#  Instrucción explícita de la usuaria: al finalizar la Orden
#  LA-GOLDEN-VIEW-SIGSEGV-019, elevar a 0.13 "no sin antes, concluir por
#  completo con 0.12". La 0.12 quedó cerrada con [093]. Entran en 0.13:
#  - las celdas nuevas del LCD (DSP, MASTER, C-90, OTROS) con sus reglas;
#  - el cuentavueltas de tambores ámbar (SVG de la usuaria);
#  - la Orden VIEW-SIGSEGV-019.
#  Todo cierra con CHANGELOG.md [094]. APP_MINOR pasa de 12 a 13 a mano y
#  _MINOR_REVISION_BASE a 93 (la última entrada bajo MENOR=12, [093]), así
#  que [094] es 0.13.001.
#  ───────────────────────────────────────────────────────────────────────────
#  ── AVISO DE SALTO DE VERSIÓN (revisión 103) ──────────────────────────────
#  Orden LA-GOLDEN-CORE-020 (modernización integral del núcleo): la 0.13
#  quedó cerrada con [102] (0.13.009). La orden abre 0.14, como estaba
#  previsto en la hoja de ruta. Cierra con CHANGELOG.md [103]. APP_MINOR
#  pasa de 13 a 14 a mano y _MINOR_REVISION_BASE a 102 (la última entrada
#  bajo MENOR=13, [102]), así que [103] es 0.14.001.
#  ───────────────────────────────────────────────────────────────────────────
_MINOR_REVISION_BASE = 102

_PROJECT_ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
_CHANGELOG_PATH = os.path.join(_PROJECT_ROOT, "CHANGELOG.md")
_CHANGELOG_ENTRY_RE = re.compile(r"^## \[(\d{3})\]", re.MULTILINE)

# Revisión de respaldo — se usa solo si CHANGELOG.md no pudo leerse (por
# ejemplo, si este módulo se importa de forma aislada, sin el resto del
# tarball junto a él).
_FALLBACK_REVISION = 2


def _count_changelog_revisions() -> int:
    """Cuenta las entradas de revisión registradas en /CHANGELOG.md.

    P2-HIGIENE (Orden Maestra de Saneamiento 0.06.005→0.06.006, Fase
    15): `open(...).read()` sin `with` dejaba el descriptor de archivo
    sin cerrar (detectado como `ResourceWarning` real al correr la
    batería de tests completa — no era solo teórico). Corregido con
    context manager.
    """
    try:
        with open(_CHANGELOG_PATH, "r", encoding="utf-8") as _f:
            content = _f.read()
    except OSError:
        return _FALLBACK_REVISION
    matches = _CHANGELOG_ENTRY_RE.findall(content)
    if not matches:
        return _FALLBACK_REVISION
    return max(int(m) for m in matches)


def get_revision() -> int:
    """Tercer bloque del número de versión (revisión), leído de
    CHANGELOG.md — contado en relación a `_MINOR_REVISION_BASE` (ver
    aviso de salto de versión arriba) para que reinicie en 001 bajo el
    MENOR actual sin reescribir el historial de CHANGELOG.md."""
    return max(1, _count_changelog_revisions() - _MINOR_REVISION_BASE)


def get_version_string() -> str:
    """Ej.: '0.01.002'"""
    return f"{APP_MAJOR}.{APP_MINOR:02d}.{get_revision():03d}"


def get_full_label() -> str:
    """Ej.: 'Lorito Aldhiro Alpha 0.01.002'"""
    return f"{APP_BRAND} {APP_STAGE} {get_version_string()}"


# Compatibilidad con el resto de los módulos modularizados (todos siguen
# usando APP_VERSION tal como en el monolito original, ahora calculado).
APP_VERSION = get_version_string()
# ── Historial del monolito de origen pre-bifurcación ─────────────────────
# El changelog completo del monolito de origen anterior a la bifurcación (946
# líneas de comentarios inertes) se movió a un documento histórico —
# GAP-034, Fase 15 (higiene del release); desde 0.14 vive en
# /legado/procedencia/. Nunca tuvo efecto funcional:
# _count_changelog_revisions() siempre leyó de /CHANGELOG.md, no de aquí.



def _version_label(v: str = APP_VERSION) -> str:
    """
    Devuelve la etiqueta de versión completa con marca y etapa.

    Antes (esquema heredado del monolito de origen): "v{MAYOR.MENOR.PARCHE}{sufijo}"
    Ahora (esquema Lorito Aldhiro):               "{MARCA} {ETAPA} {MAYOR.MENOR.REVISIÓN}"

    Se conserva la firma original _version_label(v: str = APP_VERSION) para
    no romper a los módulos que ya llaman _version_label() o
    _version_label(APP_VERSION) en el resto del código modularizado.
    """
    return f"{APP_BRAND} {APP_STAGE} {v}"


def about_text() -> str:
    """Nombre, versión y atribución histórica (LA-GOLDEN-CORE-020).

    Lo imprime `lorito_bootstrap.py --version`; es el texto que mostrará
    ACERCA cuando ese menú deje de caer en "Fnc No Disp"."""
    from lorito_aldhiro.backend.core.lorito_provenance import HISTORICAL_ATTRIBUTION
    return f"{_version_label()}\n{HISTORICAL_ATTRIBUTION}"
