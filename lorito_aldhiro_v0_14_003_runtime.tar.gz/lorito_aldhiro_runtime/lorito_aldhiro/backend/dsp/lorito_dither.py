from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de dither TPDF aplicado justo antes de la cuantización final que reduce la profundidad de bits (LA-DTH-OI-001).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Motor Dither de Lorito Aldhiro (Orden LA-DTH-OI-001, 0.13.003).

**Punto de inserción (§3.1).** Es la ÚLTIMA transformación de la cadena de
exportación, después de la normalización, el limitador declarado, el
resampleo y el medidor de overs. Va inmediatamente antes del cuantizador
del encoder. Solo se inserta cuando la exportación **reduce la profundidad
de bits**, es decir, cuando la profundidad entera de destino es menor que la
de la fuente RAW (hoy 24 bits). Esto pasa con WAV 16 y FLAC 16. Con salida
float (WAV 32 float, WavPack), con profundidad igual o mayor, o con salida
con pérdida (OGG), queda en bypass: no añade ruido. La captura nunca pasa
por aquí.

**Cuantizador de referencia** (el que controla este motor):

- WAV: `round(clip(x, -1, 1) · 2^(b−1))`, recortado a `[−2^(b−1), 2^(b−1)−1]`
  (`lorito_wav_encoder`);
- FLAC 16: ffmpeg `flt → s16`, `lrintf(x · 2^15)` con recorte.

Los dos redondean al entero más cercano (empates al par) con la misma
escala, así que el LSB de destino en el dominio float es `q = 2^−(b−1)`.

**TPDF (§3.2).** `d = (u1 − u2) · q`, con `u1` y `u2` uniformes
independientes en [0, 1). Es triangular en (−q, +q): 2 LSB pico a pico, que
es el mínimo que independiza de la señal la media y la varianza del error
total (Lipshitz, Wannamaker y Vanderkooy). La varianza del dither es q²/6;
la del error total con el cuantizador, q²/4, es decir **0,5 LSB RMS**: con
entrada cero, −96,3 dBFS a 16 bits.

**PRNG.** `numpy.random.Generator(PCG64)`, uno por instancia. Las muestras
se extraen en orden (frame, canal, par), así que el resultado no depende
del tamaño de bloque (DTH-06), y los canales reciben valores independientes
(DTH-07). La semilla es configurable. Sin semilla se toma entropía del
sistema y se REGISTRA, para poder reproducir la exportación.

**Límites (§5).**

- La salida se recorta a los límites exactos del cuantizador, así que no
  hay wraparound; las muestras recortadas se cuentan.
- Una entrada no finita (NaN/Inf) se sanea a 0,0 y se cuenta. Nunca se
  propaga al encoder.

**Fuera de alcance (§3.3).** Sin noise shaping, sin perfiles múltiples y sin
dither rectangular. Sin cambios de ganancia, EQ ni balance.
"""

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

ENGINE_ID = "lorito-dither-tpdf-1"
DITHER_OFF = "OFF"
DITHER_TPDF = "TPDF"
MODES = (DITHER_OFF, DITHER_TPDF)
TARGET_BITS = (8, 16, 24)


def needs_dither(source_bits: int, target_int_bits: int) -> bool:
    """¿Hay reducción de profundidad? `target_int_bits = 0` significa salida
    float o con pérdida: no hay cuantizador entero que controlar."""
    return bool(target_int_bits) and int(target_int_bits) < int(source_bits)


def lsb(target_bits: int) -> float:
    return 2.0 ** -(int(target_bits) - 1)


def quantizer_limits(target_bits: int) -> tuple:
    """(mín, máx) representables en el dominio float del cuantizador."""
    q = lsb(target_bits)
    full = 2 ** (int(target_bits) - 1)
    return -full * q, (full - 1) * q


def quantize(x: np.ndarray, target_bits: int) -> np.ndarray:
    """Cuantizador de referencia (idéntico al de `WavEncoder`), en enteros."""
    full = 2 ** (int(target_bits) - 1)
    return np.clip(np.round(np.clip(x, -1.0, 1.0) * float(full)), -full, full - 1).astype(np.int64)


@dataclass
class DitherStats:
    mode: str = DITHER_OFF
    engine: str = ENGINE_ID
    source_bits: int = 0
    target_bits: int = 0
    applied: bool = False
    reason: str = ""
    seed: Optional[int] = None
    frames: int = 0
    clipped: int = 0
    nonfinite: int = 0

    def as_dict(self) -> dict:
        return dict(self.__dict__)


class TPDFDither:
    """Dither TPDF calibrado al LSB de destino. Estado propio por instancia."""

    def __init__(self, target_bits: int, channels: int, seed: Optional[int] = None):
        if int(target_bits) not in TARGET_BITS:
            raise ValueError(f"DITHER: profundidad de destino no soportada: {target_bits}")
        if int(channels) < 1:
            raise ValueError("DITHER: canales >= 1")
        self.target_bits = int(target_bits)
        self.channels = int(channels)
        self.q = lsb(self.target_bits)
        self.lo, self.hi = quantizer_limits(self.target_bits)
        self.stats = DitherStats(mode=DITHER_TPDF, target_bits=self.target_bits, applied=True)
        self.reset(seed)

    def reset(self, seed: Optional[int] = None) -> None:
        """Reinicio EXPLÍCITO (nunca por bloque)."""
        if seed is None:
            seed = int(np.random.SeedSequence().entropy % (2 ** 63))
        self.seed = int(seed)
        self.stats.seed = self.seed
        self._rng = np.random.Generator(np.random.PCG64(self.seed))

    def noise(self, n: int) -> np.ndarray:
        """`n × canales` muestras TPDF en unidades del dominio float."""
        u = self._rng.random((int(n), self.channels, 2))
        return (u[:, :, 0] - u[:, :, 1]) * self.q

    def process(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x)
        if x.ndim != 2 or x.shape[1] != self.channels:
            raise ValueError(f"DITHER: forma {x.shape} no coincide con {self.channels} canales")
        n = x.shape[0]
        if n == 0:
            return x.astype(np.float32, copy=False)
        y = x.astype(np.float64)
        bad = ~np.isfinite(y)
        if bad.any():
            self.stats.nonfinite += int(bad.sum())
            y[bad] = 0.0
        y += self.noise(n)
        over = (y > self.hi) | (y < self.lo)
        if over.any():
            self.stats.clipped += int(over.sum())
            np.clip(y, self.lo, self.hi, out=y)
        self.stats.frames += n
        return y.astype(np.float32)


def make_block_transform(dither: TPDFDither):
    """Transformación de bloque para `ExportSession` (contrato `Block`)."""
    from lorito_aldhiro.backend.export_streaming.lorito_export_blocks import Block

    def _t(blk):
        return Block(dither.process(blk.data), blk.frame_offset, blk.is_last)
    return _t
