from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Restauración de artefactos de distorsión de Bias del fonograma crudo (PREVI).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_cristhi_cosh.py — GAP-039, DSP "Florecedor de Cristhi Cosh
(PREVI)" — adaptado desde el monolito de origen (tarball
v0_37_416_quad_previ_chain_derived_export, subido por el usuario,
modulo original cristhi_bands.py/cristhi_controller.py,
"Powered by Jordan Vitrito Cornuero") al catalogo de Lorito Aldhiro.

Cadena secuencial de 5 bandas, identica en su matematica al original:

    AZUCENA (analisis, no modifica) -> NICOLE (correccion de Bias) ->
    DANIELA (suavizado) -> POCHA/SIRF (reconstruccion frecuencial) ->
    ROMMY (DNL embebido + refinamiento final)

## Que se "recorto" respecto al original (pedido explicito del usuario:
"sin indicador TMI, sin metricas en PreviAnalyzer, sin reductores de
ruido no incorporados en Lorito Aldhiro, solo un mensaje overlay de
encendido")

- `PREVIDSPBlockGuard`/`SafeBlockRecovery`/`PREVIContext` (infra propia
  del monolito de origen para detectar NaN/Inf y recuperar el ultimo bloque valido) -
  NO se porto. Lorito ya tiene su propio contrato para exactamente
  este problema: DSP_NONFINITE_OUTPUT (backend/dsp/lorito_dsp_finite_
  guard.py, GAP-025/Fase 10) - de hecho, el propio comentario del
  controlador original del monolito de origen confirma el MISMO defecto que motivo
  GAP-025 en Lorito: "un solo NaN en un bloque envenena PERMANENTEMENTE
  el estado interno de la cadena de 5 bandas". Este modulo se integra
  al patron ya existente de NRCoordinator._sanitize_stage() (saneamiento
  + reset() de la etapa) en vez de reimplementar una guarda propia.
- Modos de captura (MANUAL/AUTO/TTNEADO/C-45.../CHDUBB) y el
  CristhiCompatibilityManager (inhibicion mutua con otros DSP de
  PREVI/CHDUBB) - NO se portaron. No fueron pedidos, y anaden una capa
  de coordinacion entre-DSP que no tiene sentido todavia con un solo
  DSP de PREVI en Lorito.
- PreviAnalyzer/TMI/telemetria de bandas activas - no existen en
  Lorito y no se portan. El unico indicador es el que la UI conecte
  (overlay simple de encendido + leyenda "PREVI DSP").
- Calentamiento JIT (warmup()) - no portado; Numba (si esta disponible)
  compila en la primera llamada real, mismo criterio que el resto de
  backend/dsp/ en Lorito.

## Que se conservo exactamente igual (matematica del DSP)

Los 5 bandas y sus parametros estan portados con la MISMA matematica
que el original (mismos coeficientes de ataque/release, mismos cortes
de crossover, misma formula de deficit espectral, mismo waveshaper
tanh). Verificado con tests dedicados que reproducen exactamente los
valores del original para las mismas entradas
(tests/test_dsp_cristhi_cosh.py).
"""

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit, NUMBA_OK


def _attack_release_coefs(attack_ms: float, release_ms: float, fs: float):
    a_att = 1.0 - np.exp(-1.0 / (max(attack_ms, 0.01) * 0.001 * fs))
    a_rel = 1.0 - np.exp(-1.0 / (max(release_ms, 0.01) * 0.001 * fs))
    return float(a_att), float(a_rel)


def _one_pole_lowpass_py(x, coef, prev):
    n = x.shape[0]
    out = np.empty(n, dtype=np.float32)
    y = prev
    for i in range(n):
        y = y + coef * (x[i] - y)
        out[i] = y
    return out, float(y)


def _envelope_follower_py(x, a_att, a_rel, prev):
    n = x.shape[0]
    out = np.empty(n, dtype=np.float32)
    y = prev
    for i in range(n):
        target = abs(x[i])
        coef = a_att if target > y else a_rel
        y = y + coef * (target - y)
        out[i] = y
    return out, float(y)


_one_pole_lowpass_kernel = njit(cache=True)(_one_pole_lowpass_py)
_envelope_follower_kernel = njit(cache=True)(_envelope_follower_py)


def _lowpass_coef(cutoff_hz: float, fs: float) -> float:
    return float(1.0 - np.exp(-2.0 * np.pi * max(cutoff_hz, 1.0) / fs))


class AzucenaMap:
    __slots__ = ("crackle_level", "squeal_level", "saturation_level",
                "spectral_energy", "reference_level", "artifact_ratio")

    def __init__(self, crackle_level=0.0, squeal_level=0.0, saturation_level=0.0,
                spectral_energy=0.0, reference_level=1e-4, artifact_ratio=0.0):
        self.crackle_level = crackle_level
        self.squeal_level = squeal_level
        self.saturation_level = saturation_level
        self.spectral_energy = spectral_energy
        self.reference_level = reference_level
        self.artifact_ratio = artifact_ratio


class AzucenaAnalyzer:
    """BANDA AZUCENA - detecta crepitacion/chirrido/saturacion de Bias.
    Solo lectura: analyze() nunca modifica el bloque de entrada."""

    _REF_ALPHA = 0.01

    def __init__(self, sample_rate: float = 44100.0, n_channels: int = 2):
        self.sample_rate = float(sample_rate)
        self.n_channels = int(n_channels)
        self._ref_level = np.full(self.n_channels, 1e-4, dtype=np.float64)
        self._crackle_env_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._squeal_lp_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._squeal_env_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._squeal_cutoff_hz = 6000.0
        self._a_att, self._a_rel = _attack_release_coefs(8.0, 220.0, self.sample_rate)

    def reset(self):
        self._ref_level[:] = 1e-4
        self._crackle_env_prev[:] = 0.0
        self._squeal_lp_prev[:] = 0.0
        self._squeal_env_prev[:] = 0.0

    def analyze(self, block: np.ndarray) -> AzucenaMap:
        mono_in = block.ndim == 1
        x = block if not mono_in else block[:, np.newaxis]
        if x.dtype != np.float32:
            x = x.astype(np.float32)

        crackle_vals, squeal_vals, sat_vals, energy_vals = [], [], [], []
        for ch in range(x.shape[1]):
            xc = x[:, ch]
            rms = float(np.sqrt(np.mean(np.square(xc)) + 1e-12))
            self._ref_level[ch] += self._REF_ALPHA * (rms - self._ref_level[ch])
            self._ref_level[ch] = max(self._ref_level[ch], 1e-6)
            energy_vals.append(rms)

            diff = np.empty_like(xc)
            diff[0] = 0.0
            diff[1:] = xc[1:] - xc[:-1]
            crackle_env, self._crackle_env_prev[ch] = _envelope_follower_kernel(
                np.abs(diff), self._a_att, self._a_rel, float(self._crackle_env_prev[ch]))
            crackle_peak = float(np.max(crackle_env)) if crackle_env.size else 0.0
            crackle_vals.append(np.clip(crackle_peak / (self._ref_level[ch] * 6.0 + 1e-6), 0.0, 1.0))

            coef = _lowpass_coef(self._squeal_cutoff_hz, self.sample_rate)
            lp, self._squeal_lp_prev[ch] = _one_pole_lowpass_kernel(
                xc, coef, float(self._squeal_lp_prev[ch]))
            hi = xc - lp
            squeal_env, self._squeal_env_prev[ch] = _envelope_follower_kernel(
                hi, self._a_att * 0.3, self._a_rel * 0.3, float(self._squeal_env_prev[ch]))
            squeal_rms = float(np.sqrt(np.mean(np.square(squeal_env)) + 1e-12))
            squeal_vals.append(np.clip(squeal_rms / (self._ref_level[ch] * 1.5 + 1e-6), 0.0, 1.0))

            near_clip = float(np.mean(np.abs(xc) > 0.92))
            sat_vals.append(np.clip(near_clip * 8.0, 0.0, 1.0))

        crackle_level = float(np.mean(crackle_vals)) if crackle_vals else 0.0
        squeal_level = float(np.mean(squeal_vals)) if squeal_vals else 0.0
        saturation_level = float(np.mean(sat_vals)) if sat_vals else 0.0
        spectral_energy = float(np.mean(energy_vals)) if energy_vals else 0.0
        reference_level = float(np.mean(self._ref_level))
        artifact_ratio = float(np.clip(
            0.4 * crackle_level + 0.35 * squeal_level + 0.25 * saturation_level, 0.0, 1.0))

        return AzucenaMap(
            crackle_level=round(crackle_level, 4), squeal_level=round(squeal_level, 4),
            saturation_level=round(saturation_level, 4), spectral_energy=round(spectral_energy, 6),
            reference_level=round(reference_level, 6), artifact_ratio=round(artifact_ratio, 4))


class NicoleCorrectionEngine:
    """BANDA NICOLE - atenuacion adaptativa + waveshaper tanh segun el
    AzucenaMap."""

    def __init__(self, sample_rate: float = 44100.0, n_channels: int = 2,
                correction_intensity: float = 0.6):
        self.sample_rate = float(sample_rate)
        self.n_channels = int(n_channels)
        self.correction_intensity = float(np.clip(correction_intensity, 0.0, 1.0))
        self._a_att, self._a_rel = _attack_release_coefs(2.0, 60.0, self.sample_rate)
        self._gain_env_prev = np.ones(self.n_channels, dtype=np.float32)

    def set_intensity(self, value: float):
        self.correction_intensity = float(np.clip(value, 0.0, 1.0))

    def reset(self):
        self._gain_env_prev[:] = 1.0

    def process(self, block: np.ndarray, azucena_map: AzucenaMap) -> np.ndarray:
        mono_in = block.ndim == 1
        x = block if not mono_in else block[:, np.newaxis]
        if x.dtype != np.float32:
            x = x.astype(np.float32)
        out = x.copy()

        target_gain = 1.0 - (azucena_map.artifact_ratio * self.correction_intensity * 0.7)
        target_gain = float(np.clip(target_gain, 0.25, 1.0))

        for ch in range(x.shape[1]):
            xc = x[:, ch]
            gain_env, self._gain_env_prev[ch] = _envelope_follower_kernel(
                np.full(xc.shape[0], 1.0 - target_gain, dtype=np.float32),
                self._a_att, self._a_rel, float(1.0 - self._gain_env_prev[ch]))
            applied_gain = 1.0 - gain_env
            self._gain_env_prev[ch] = applied_gain[-1] if applied_gain.size else self._gain_env_prev[ch]

            sat_amount = azucena_map.saturation_level * self.correction_intensity
            if sat_amount > 1e-4:
                drive = 1.0 + sat_amount * 3.0
                shaped = np.tanh(xc * drive) / np.tanh(drive)
                xc = xc * (1.0 - sat_amount) + shaped * sat_amount

            out[:, ch] = xc * applied_gain

        return out[:, 0] if mono_in else out


class DanielaSoftLimiter:
    """BANDA DANIELA - suavizado dinamico + limitador soft-knee sutil."""

    def __init__(self, sample_rate: float = 44100.0, n_channels: int = 2,
                softness: float = 0.5, ceiling: float = 0.98):
        self.sample_rate = float(sample_rate)
        self.n_channels = int(n_channels)
        self.softness = float(np.clip(softness, 0.0, 1.0))
        self.ceiling = float(np.clip(ceiling, 0.5, 1.0))
        self._smooth_cutoff_hz = 9000.0
        self._lp_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._a_att, self._a_rel = _attack_release_coefs(3.0, 80.0, self.sample_rate)
        self._limiter_env_prev = np.zeros(self.n_channels, dtype=np.float32)

    def set_softness(self, value: float):
        self.softness = float(np.clip(value, 0.0, 1.0))

    def reset(self):
        self._lp_prev[:] = 0.0
        self._limiter_env_prev[:] = 0.0

    def process(self, block: np.ndarray) -> np.ndarray:
        mono_in = block.ndim == 1
        x = block if not mono_in else block[:, np.newaxis]
        if x.dtype != np.float32:
            x = x.astype(np.float32)
        out = x.copy()

        coef = _lowpass_coef(self._smooth_cutoff_hz, self.sample_rate)
        for ch in range(x.shape[1]):
            xc = x[:, ch]
            smoothed, self._lp_prev[ch] = _one_pole_lowpass_kernel(
                xc, coef, float(self._lp_prev[ch]))
            mix = self.softness * 0.35
            xc = xc * (1.0 - mix) + smoothed * mix

            over = np.maximum(np.abs(xc) - self.ceiling, 0.0)
            env, self._limiter_env_prev[ch] = _envelope_follower_kernel(
                over, self._a_att, self._a_rel, float(self._limiter_env_prev[ch]))
            reduction = env / (np.abs(xc) + 1e-9)
            xc = xc * (1.0 - np.clip(reduction, 0.0, 1.0))

            out[:, ch] = xc

        np.clip(out, -1.0, 1.0, out=out)
        return out[:, 0] if mono_in else out


class PochaSIRFEngine:
    """BANDA POCHA - SIRF: reconstruccion adaptativa de graves/medios/
    agudos, solo sobre deficit detectado (nunca una curva fija)."""

    def __init__(self, sample_rate: float = 44100.0, n_channels: int = 2,
                crossover_lo_hz: float = 300.0, crossover_hi_hz: float = 4000.0,
                reconstruction_intensity: float = 0.5):
        self.sample_rate = float(sample_rate)
        self.n_channels = int(n_channels)
        self.crossover_lo_hz = float(crossover_lo_hz)
        self.crossover_hi_hz = float(crossover_hi_hz)
        self.reconstruction_intensity = float(np.clip(reconstruction_intensity, 0.0, 1.0))
        self._lp_lo_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._lp_hi_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._ref_lo = np.full(self.n_channels, 1e-4, dtype=np.float64)
        self._ref_mid = np.full(self.n_channels, 1e-4, dtype=np.float64)
        self._ref_hi = np.full(self.n_channels, 1e-4, dtype=np.float64)
        self._REF_ALPHA = 0.008
        self._a_att, self._a_rel = _attack_release_coefs(15.0, 400.0, self.sample_rate)
        self._recon_env_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._last_recon_ratio = 0.0

    def set_intensity(self, value: float):
        self.reconstruction_intensity = float(np.clip(value, 0.0, 1.0))

    def reset(self):
        self._lp_lo_prev[:] = 0.0
        self._lp_hi_prev[:] = 0.0
        self._ref_lo[:] = 1e-4
        self._ref_mid[:] = 1e-4
        self._ref_hi[:] = 1e-4
        self._recon_env_prev[:] = 0.0
        self._last_recon_ratio = 0.0

    @property
    def last_reconstruction_ratio(self) -> float:
        return self._last_recon_ratio

    def process(self, block: np.ndarray, azucena_map: AzucenaMap) -> np.ndarray:
        mono_in = block.ndim == 1
        x = block if not mono_in else block[:, np.newaxis]
        if x.dtype != np.float32:
            x = x.astype(np.float32)
        out = x.copy()

        coef_lo = _lowpass_coef(self.crossover_lo_hz, self.sample_rate)
        coef_hi = _lowpass_coef(self.crossover_hi_hz, self.sample_rate)
        max_ratio = 0.0

        for ch in range(x.shape[1]):
            xc = x[:, ch]
            lo, self._lp_lo_prev[ch] = _one_pole_lowpass_kernel(xc, coef_lo, float(self._lp_lo_prev[ch]))
            rest = xc - lo
            mid, self._lp_hi_prev[ch] = _one_pole_lowpass_kernel(rest, coef_hi, float(self._lp_hi_prev[ch]))
            hi = rest - mid

            rms_lo = float(np.sqrt(np.mean(np.square(lo)) + 1e-12))
            rms_mid = float(np.sqrt(np.mean(np.square(mid)) + 1e-12))
            rms_hi = float(np.sqrt(np.mean(np.square(hi)) + 1e-12))
            self._ref_lo[ch] += self._REF_ALPHA * (rms_lo - self._ref_lo[ch])
            self._ref_mid[ch] += self._REF_ALPHA * (rms_mid - self._ref_mid[ch])
            self._ref_hi[ch] += self._REF_ALPHA * (rms_hi - self._ref_hi[ch])
            for arr in (self._ref_lo, self._ref_mid, self._ref_hi):
                arr[ch] = max(arr[ch], 1e-6)

            def _deficit(now, ref):
                if ref <= 1e-6 or now >= ref:
                    return 0.0
                return float(np.clip((ref - now) / ref, 0.0, 1.0))

            gate = azucena_map.artifact_ratio
            deficit_lo = _deficit(rms_lo, self._ref_lo[ch]) * gate
            deficit_mid = _deficit(rms_mid, self._ref_mid[ch]) * gate
            deficit_hi = _deficit(rms_hi, self._ref_hi[ch]) * gate

            gain_lo = 1.0 + deficit_lo * self.reconstruction_intensity * 0.6
            gain_mid = 1.0 + deficit_mid * self.reconstruction_intensity * 0.8
            gain_hi = 1.0 + deficit_hi * self.reconstruction_intensity * 1.0

            recon_inst = float(np.mean([deficit_lo, deficit_mid, deficit_hi]))
            recon_env, self._recon_env_prev[ch] = _envelope_follower_kernel(
                np.full(xc.shape[0], recon_inst, dtype=np.float32),
                self._a_att, self._a_rel, float(self._recon_env_prev[ch]))
            max_ratio = max(max_ratio, float(np.mean(recon_env)))

            out[:, ch] = lo * gain_lo + mid * gain_mid + hi * gain_hi

        np.clip(out, -1.0, 1.0, out=out)
        self._last_recon_ratio = round(max_ratio, 4)
        return out[:, 0] if mono_in else out


class CristhiDNL:
    """Expansor descendente suave (DNL embebido) - interno de Rommy, no
    seleccionable por el usuario (no es un NR general)."""

    def __init__(self, sample_rate: float = 44100.0, n_channels: int = 2,
                threshold: float = 0.02, strength: float = 0.5):
        self.sample_rate = float(sample_rate)
        self.n_channels = int(n_channels)
        self.threshold = float(threshold)
        self.strength = float(np.clip(strength, 0.0, 1.0))
        self._env_prev = np.zeros(self.n_channels, dtype=np.float32)
        self._a_att, self._a_rel = _attack_release_coefs(5.0, 120.0, self.sample_rate)

    def reset(self):
        self._env_prev[:] = 0.0

    def process(self, block: np.ndarray) -> np.ndarray:
        mono_in = block.ndim == 1
        x = block if not mono_in else block[:, np.newaxis]
        if x.dtype != np.float32:
            x = x.astype(np.float32)
        out = x.copy()

        for ch in range(x.shape[1]):
            xc = x[:, ch]
            env, self._env_prev[ch] = _envelope_follower_kernel(
                xc, self._a_att, self._a_rel, float(self._env_prev[ch]))
            below = np.clip((self.threshold - env) / max(self.threshold, 1e-6), 0.0, 1.0)
            gain = 1.0 - below * self.strength
            out[:, ch] = xc * gain

        return out[:, 0] if mono_in else out


class RommyFinalStage:
    """BANDA ROMMY - DNL embebido + normalizacion interna automatica +
    estabilizacion final."""

    def __init__(self, sample_rate: float = 44100.0, n_channels: int = 2,
                target_peak: float = 0.95):
        self.sample_rate = float(sample_rate)
        self.n_channels = int(n_channels)
        self.target_peak = float(np.clip(target_peak, 0.5, 1.0))
        self.dnl = CristhiDNL(sample_rate=sample_rate, n_channels=n_channels)
        self._peak_env = 1e-4
        self._PEAK_ALPHA = 0.02

    def reset(self):
        self.dnl.reset()
        self._peak_env = 1e-4

    def process(self, block: np.ndarray) -> np.ndarray:
        stage = self.dnl.process(block)

        peak_now = float(np.max(np.abs(stage))) if stage.size else 0.0
        self._peak_env += self._PEAK_ALPHA * (peak_now - self._peak_env)
        self._peak_env = max(self._peak_env, 1e-4)

        if self._peak_env > 1e-4:
            gain = float(np.clip(self.target_peak / self._peak_env, 0.5, 1.5))
        else:
            gain = 1.0

        stabilized = stage * gain
        np.clip(stabilized, -1.0, 1.0, out=stabilized)
        return stabilized


class CristhiCoshProfile:
    """DSP FLORECEDOR DE CRISTHI COSH (PREVI) - vive en el menu OPTAPE
    (pedido explicito del usuario). Sigue la misma convencion de perfil
    que MpxProfile/TapeEqBiasProfile/FocusProfile: mode "ACTIVE"/
    "BYPASS", process_chunk(), reset().

    Orquesta la cadena de 5 bandas - ver docstring de cabecera del
    modulo para que se conservo y que se recorto respecto al original
    del monolito de origen."""

    display_name = "FLORECEDOR CRISTHI COSH (PREVI)"
    cell_token = "PREVI_CRISTHI"
    overlay_token = "PREVI_DSP"
    legend_label = "PREVI DSP"

    def __init__(self, mode: str = "BYPASS", sample_rate: int = 48000,
                channels: int = 2,
                correction_intensity: float = 0.60,
                softness: float = 0.50,
                reconstruction_intensity: float = 0.50,
                dnl_strength: float = 0.50,
                target_peak: float = 0.95):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self.correction_intensity = float(np.clip(correction_intensity, 0.0, 1.0))
        self.softness = float(np.clip(softness, 0.0, 1.0))
        self.reconstruction_intensity = float(np.clip(reconstruction_intensity, 0.0, 1.0))
        self.dnl_strength = float(np.clip(dnl_strength, 0.0, 1.0))
        self.target_peak = float(np.clip(target_peak, 0.5, 1.0))
        self._active = self.mode != "BYPASS"
        self._build()

    def _build(self):
        self.azucena = AzucenaAnalyzer(sample_rate=self.fs, n_channels=self.channels)
        self.nicole = NicoleCorrectionEngine(
            sample_rate=self.fs, n_channels=self.channels,
            correction_intensity=self.correction_intensity)
        self.daniela = DanielaSoftLimiter(
            sample_rate=self.fs, n_channels=self.channels, softness=self.softness)
        self.pocha = PochaSIRFEngine(
            sample_rate=self.fs, n_channels=self.channels,
            reconstruction_intensity=self.reconstruction_intensity)
        self.rommy = RommyFinalStage(
            sample_rate=self.fs, n_channels=self.channels, target_peak=self.target_peak)
        self.rommy.dnl.strength = self.dnl_strength
        self._last_correction_ratio = 0.0
        self._last_reconstruction_ratio = 0.0

    def set_params(self, **kwargs):
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, k, v)
        self.correction_intensity = float(np.clip(self.correction_intensity, 0.0, 1.0))
        self.softness = float(np.clip(self.softness, 0.0, 1.0))
        self.reconstruction_intensity = float(np.clip(self.reconstruction_intensity, 0.0, 1.0))
        self.dnl_strength = float(np.clip(self.dnl_strength, 0.0, 1.0))
        self.target_peak = float(np.clip(self.target_peak, 0.5, 1.0))
        self.nicole.set_intensity(self.correction_intensity)
        self.daniela.set_softness(self.softness)
        self.pocha.set_intensity(self.reconstruction_intensity)
        self.rommy.dnl.strength = self.dnl_strength
        self.rommy.target_peak = self.target_peak

    def reset(self):
        self.azucena.reset()
        self.nicole.reset()
        self.daniela.reset()
        self.pocha.reset()
        self.rommy.reset()
        self._last_correction_ratio = 0.0
        self._last_reconstruction_ratio = 0.0

    @property
    def processing(self) -> bool:
        """True si el DSP esta tratando artefactos reales en este
        instante (para el overlay simple de "encendido" - nunca
        metricas detalladas tipo PreviAnalyzer, ver docstring de
        cabecera)."""
        return (self._last_correction_ratio > 1e-3
                or self._last_reconstruction_ratio > 1e-3)

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active or chunk.size == 0:
            return chunk

        azucena_map = self.azucena.analyze(chunk)
        stage = self.nicole.process(chunk, azucena_map)
        stage = self.daniela.process(stage)
        stage = self.pocha.process(stage, azucena_map)
        stage = self.rommy.process(stage)

        self._last_correction_ratio = azucena_map.artifact_ratio
        self._last_reconstruction_ratio = self.pocha.last_reconstruction_ratio
        return stage
