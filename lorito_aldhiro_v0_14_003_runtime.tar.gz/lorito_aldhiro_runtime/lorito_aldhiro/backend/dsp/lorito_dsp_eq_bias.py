from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Perfil de voicing y headroom según el tipo de cinta (Normal/CrO2/Metal).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_eq_bias.py — DSP EQ/BIAS: emulador de las curvas reales de
ecualización de reproducción y del carácter de bias de los 4 tipos de
cinta de casete IEC 60094 (NORMAL/Tipo I, CrO2/Tipo II, FeCr/Tipo III,
Metal/Tipo IV). Pedido explícito del usuario, con investigación previa
de los esquemas técnicos reales (ver GAP de referencia para fuentes).

Referencia técnica investigada para esta sesión:
  · Las 4 curvas comparten un mismo shelf de graves con constante de
    tiempo 3180µS (≈50Hz, -6dB/octava por debajo).
  · Donde difieren es en la constante de tiempo de agudos ("turnover"):
      NORMAL (Tipo I)            → 120µS ≈ 1326 Hz
      CrO2 / FeCr / Metal        → 70µS  ≈ 2274 Hz  (IEC 60094; FeCr
                                    históricamente compartió el EQ de
                                    Tipo II, no tiene un turnover propio
                                    documentado por separado)
    La diferencia de turnover (120µS vs 70µS) produce un boost de
    agudos de referencia de ~4.5dB en 70µS respecto a 120µS a la misma
    frecuencia, cifra explícitamente documentada en las fuentes
    consultadas — se usa aquí como el "voicing" característico de cada
    tipo, no como un intento de replicar el circuito analógico exacto.
  · El BIAS (corriente HF de grabación) no es audible como EQ, pero
    determina el headroom antes de saturación: a mayor bias (Metal >
    CrO2/FeCr > Normal), la cinta admite niveles más altos sin
    comprimir. Se emula con una no-linealidad blanda (soft-clip) cuyo
    umbral sube con el tipo de cinta — el mismo eje que en la vida real
    se ajusta con el trim de bias de un deck de gama alta.

Diseño (nuevo, sin precedente directo en el monolito de origen):
  · Shelf de graves (3180µS, común a los 4 tipos) + shelf de agudos
    (120µS o 70µS según tipo) — dos filtros IIR de un polo en cascada,
    coeficientes derivados directamente de la constante de tiempo RC
    (t = 1/(2π·f_turnover)) vía transformación bilineal.
  · Soft-clip (tanh) con umbral dependiente del tipo — emula el
    headroom asociado al bias real de cada formulación.
  · Selección ÚNICA (como el selector NR) — un tipo de cinta activo a
    la vez, nunca cascada; "APAGAR EQ/BIAS" dentro del mismo menú
    desactiva el efecto por completo.
  · Numba (`njit`) en el bucle de aplicación del shelf, con la misma
    degradación con gracia que el resto de DSP nuevos de esta sesión.
"""

import math

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit, NUMBA_OK


# Constantes de tiempo IEC 60094 (µS) y ganancia de headroom (bias) por tipo.
# `formula_label` es el texto EXACTO que se muestra en el overlay del
# contómetro durante 4 segundos al seleccionar (pedido explícito del
# usuario: "deberá aparecer el overlay respectivo a la fórmula").
TAPE_EQ_PARAMS = {
    "NORMAL": {"turnover_us": 120.0, "hf_gain_db": 0.0,  "bias_headroom_db": 0.0,
              "formula_label": "120µS"},
    "CRO2":   {"turnover_us": 70.0,  "hf_gain_db": 4.5,  "bias_headroom_db": 2.0,
              "formula_label": "70µS"},
    "FECR":   {"turnover_us": 70.0,  "hf_gain_db": 4.5,  "bias_headroom_db": 1.0,
              "formula_label": "70µS FeCr"},
    "METAL":  {"turnover_us": 70.0,  "hf_gain_db": 4.5,  "bias_headroom_db": 4.0,
              "formula_label": "70µS Metal"},
}
BASS_SHELF_US = 3180.0   # común a los 4 tipos (~50Hz)


def _one_pole_shelf_coeffs(turnover_us: float, fs: float, gain_db: float, is_bass: bool):
    """
    Shelf de un polo derivado de la constante de tiempo RC del circuito
    real (t = turnover_us * 1e-6), vía transformación bilineal
    (t = 1/(2π·f) → f_turnover, luego coeficientes de un shelf de
    primer orden). `is_bass=True` → low-shelf (boost/realce por debajo
    del turnover); `is_bass=False` → high-shelf (boost por encima).
    gain_db=0.0 → coeficientes de paso directo (bypass), evita rama
    especial en el llamador.
    """
    if gain_db == 0.0:
        return (1.0, 0.0, 0.0)   # b0, b1, a1 — y[n] = x[n] (paso directo)

    f_turnover = 1.0 / (2.0 * math.pi * (turnover_us * 1e-6))
    f_turnover = min(f_turnover, fs * 0.45)   # margen de guarda ante Nyquist
    w0 = 2.0 * math.pi * f_turnover / fs
    k = math.tan(w0 / 2.0)
    g = 10.0 ** (gain_db / 20.0)

    if is_bass:
        # Low-shelf de un polo: realza por debajo del turnover.
        a1 = (k - g) / (k + g) if (k + g) != 0 else 0.0
        b0 = (k * g + g * g) / (k + g) if (k + g) != 0 else g
        b1 = (k * g - g * g) / (k + g) if (k + g) != 0 else 0.0
    else:
        # High-shelf de un polo: realza por encima del turnover.
        a1 = (k - 1.0) / (k + 1.0)
        b0 = (1.0 + g * k) / (1.0 + k)
        b1 = (g * k - 1.0) / (1.0 + k) * -1.0
    return (b0, b1, a1)


@njit(cache=True)
def _one_pole_apply(x: np.ndarray, b0: float, b1: float, a1: float,
                    x1: float, y1: float):
    n = x.shape[0]
    y = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x[i]
        yi = b0 * xi + b1 * x1 - a1 * y1
        y[i] = yi
        x1 = xi; y1 = yi
    return y, x1, y1


@njit(cache=True)
def _soft_clip_apply(x: np.ndarray, headroom_lin: float):
    """tanh soft-clip — `headroom_lin` es el nivel lineal a partir del
    cual empieza a comprimir suavemente (mayor bias → mayor headroom →
    satura más tarde, mismo eje que el trim de bias real)."""
    n = x.shape[0]
    y = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x[i]
        y[i] = headroom_lin * math.tanh(xi / headroom_lin)
    return y


class TapeEqBiasProfile:
    """DSP EQ/BIAS — menú "EQ/BIAS" propio (pedido explícito del
    usuario), selección única entre NORMAL/CrO2/FeCr/Metal, igual
    patrón de exclusión estructural que el selector NR."""

    display_name = "EQ/BIAS"
    cell_token = "R2"

    def __init__(self, tape_type: str, sample_rate: int = 48000, channels: int = 2):
        self.tape_type = tape_type.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def _build(self) -> None:
        params = TAPE_EQ_PARAMS.get(self.tape_type, TAPE_EQ_PARAMS["NORMAL"])
        self.formula_label = params["formula_label"]
        self._bass_c = _one_pole_shelf_coeffs(BASS_SHELF_US, self.fs, 1.5, is_bass=True)
        self._hf_c   = _one_pole_shelf_coeffs(params["turnover_us"], self.fs,
                                              params["hf_gain_db"], is_bass=False)
        headroom_db = 6.0 + params["bias_headroom_db"]   # NORMAL=6dB .. METAL=10dB
        self._headroom_lin = 10.0 ** (headroom_db / 20.0)
        self._state_bass = np.zeros((self.channels, 2), dtype=np.float64)  # [x1,y1]
        self._state_hf   = np.zeros((self.channels, 2), dtype=np.float64)

    def reset(self) -> None:
        self._state_bass[:] = 0.0
        self._state_hf[:] = 0.0

    def reconfigure(self, tape_type: str, sample_rate: int, channels: int) -> None:
        self.tape_type = tape_type.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        x = np.ascontiguousarray(chunk, dtype=np.float64)
        mono = x.ndim == 1
        x2 = x[:, np.newaxis] if mono else x
        n_samples, n_ch = x2.shape
        if self._state_bass.shape[0] != n_ch:
            self._state_bass = np.zeros((n_ch, 2), dtype=np.float64)
            self._state_hf   = np.zeros((n_ch, 2), dtype=np.float64)

        out = np.empty_like(x2)
        b0b, b1b, a1b = self._bass_c
        b0h, b1h, a1h = self._hf_c
        for ch in range(n_ch):
            col = x2[:, ch]
            stb = self._state_bass[ch]
            col, stb[0], stb[1] = _one_pole_apply(col, b0b, b1b, a1b, stb[0], stb[1])
            sth = self._state_hf[ch]
            col, sth[0], sth[1] = _one_pole_apply(col, b0h, b1h, a1h, sth[0], sth[1])
            out[:, ch] = _soft_clip_apply(col, self._headroom_lin)

        result = np.clip(out, -1.0, 1.0).astype(np.float32)
        return result[:, 0] if mono else result
