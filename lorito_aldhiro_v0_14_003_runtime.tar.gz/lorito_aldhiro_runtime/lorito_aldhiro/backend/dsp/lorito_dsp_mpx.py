from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Filtro de piloto FM (19kHz) para fuentes con sintonizador MPX integrado.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_mpx.py — DSP MPX (filtro de piloto estéreo FM), pedido
explícito del usuario: "Diseña el DSP llamado MPX, con aceleración
Numba y NumPy, con tratamiento a tiempo real en la señal."

Referencia técnica (investigada para esta sesión — ver GAP de
referencia para las fuentes): un filtro MPX de calidad en un cassette
deck es, como mínimo, un filtro NOTCH que atenúa el tono piloto de
19kHz de las emisiones FM estéreo, y en los diseños más cuidados
también ataca el subportador DSB-SC centrado en 38kHz (2× el piloto,
donde vive la información L-R). Su función real es proteger las
reducciones de ruido tipo Dolby B/C de un "mistracking" del compansor
al recibir ese tono, que se sitúa justo en el borde del rango audible
pero puede confundir al detector de nivel de HF del NR.

Diseño (nuevo, sin precedente directo en el monolito de origen):
  · Dos biquads NOTCH en cascada (Audio EQ Cookbook / RBJ), diseñados
    directamente en el dominio digital a partir de f0/fs — sin
    pre-warping adicional, válido mientras f0 < fs/2.
  · f0 = 19000 Hz (piloto) siempre que fs/2 > 19000 Hz con margen de
    guarda; f0 = 38000 Hz (subportador L-R) solo si fs/2 > 38000 Hz
    con margen (en la práctica, solo a 96000 Hz — a 44100/48000 Hz el
    segundo notch queda fuera de rango y se omite con gracia, igual
    que un MPX real de un deck que no puede grabar por encima de su
    propio Nyquist).
  · Q=8 en ambos notches — atenuación profunda (~-30 a -40dB) pero
    banda angosta, para no comerse el rango audible alto (15-16kHz)
    tal como documentan los esquemas reales investigados ("A 4th
    order low pass filter is going to add a lot of high frequency
    attenuation on the 15kHz passband" — de ahí preferir un notch
    angosto sobre un pasabajos ancho).
  · Bucle de aplicación del biquad (Direct Form I, muestra a muestra,
    por canal) acelerado con Numba (`njit`) vía
    `lorito_dsp_numba_utils` — degrada con gracia a Python/NumPy puro
    si Numba no está disponible en el entorno (nunca falla el
    arranque por eso).
"""

import math

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit, NUMBA_OK


def _design_notch(f0: float, fs: float, q: float):
    """Biquad NOTCH (Audio EQ Cookbook, sección 'Notch'). Devuelve
    coeficientes normalizados (b0,b1,b2,a1,a2), con a0 ya dividido."""
    w0 = 2.0 * math.pi * f0 / fs
    alpha = math.sin(w0) / (2.0 * q)
    cos_w0 = math.cos(w0)
    b0, b1, b2 = 1.0, -2.0 * cos_w0, 1.0
    a0, a1, a2 = 1.0 + alpha, -2.0 * cos_w0, 1.0 - alpha
    return (b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)


@njit(cache=True)
def _biquad_apply(x: np.ndarray, b0: float, b1: float, b2: float,
                  a1: float, a2: float,
                  x1: float, x2: float, y1: float, y2: float):
    """Direct Form I, muestra a muestra — mantiene el estado (x1,x2,y1,y2)
    entre llamadas (bloques consecutivos del pipeline de captura) para
    que el filtro no "clickee" en cada frontera de bloque."""
    n = x.shape[0]
    y = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x[i]
        yi = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        y[i] = yi
        x2 = x1; x1 = xi
        y2 = y1; y1 = yi
    return y, x1, x2, y1, y2


class MpxProfile:
    """DSP MPX — vive en el menú OPTAPE (mismo menú que HX Pro/ALC,
    pedido explícito del usuario). Independiente del selector NR y de
    ALC/HX Pro/FOCUS — puede convivir con cualquiera de ellos, mismo
    patrón `_active` de AlcProfile/HxProProfile."""

    display_name = "MPX"
    cell_token = "MPX"
    overlay_token = "MPX"

    PILOT_HZ = 19000.0
    SUBCARRIER_HZ = 38000.0
    Q = 8.0
    _GUARD_HZ = 500.0   # margen de guarda contra el propio Nyquist

    def __init__(self, mode: str = "ACTIVE", sample_rate: int = 48000, channels: int = 2):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def _build(self) -> None:
        self._active = self.mode != "BYPASS"
        nyquist = self.fs / 2.0
        self._use_pilot = nyquist > (self.PILOT_HZ + self._GUARD_HZ)
        self._use_sub   = nyquist > (self.SUBCARRIER_HZ + self._GUARD_HZ)
        self._c_pilot = _design_notch(self.PILOT_HZ, self.fs, self.Q) if self._use_pilot else None
        self._c_sub   = _design_notch(self.SUBCARRIER_HZ, self.fs, self.Q) if self._use_sub else None
        # Estado del filtro por canal, por etapa (pilot, sub): [x1,x2,y1,y2]
        self._state_pilot = np.zeros((self.channels, 4), dtype=np.float64)
        self._state_sub   = np.zeros((self.channels, 4), dtype=np.float64)

    def reset(self) -> None:
        self._state_pilot[:] = 0.0
        self._state_sub[:] = 0.0

    def reconfigure(self, mode: str, sample_rate: int, channels: int) -> None:
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._build()

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active or (not self._use_pilot and not self._use_sub):
            return chunk if chunk.dtype == np.float32 else chunk.astype(np.float32)

        x = np.ascontiguousarray(chunk, dtype=np.float64)
        mono = x.ndim == 1
        x2 = x[:, np.newaxis] if mono else x
        n_samples, n_ch = x2.shape
        if self._state_pilot.shape[0] != n_ch:
            self._state_pilot = np.zeros((n_ch, 4), dtype=np.float64)
            self._state_sub   = np.zeros((n_ch, 4), dtype=np.float64)

        out = np.empty_like(x2)
        for ch in range(n_ch):
            col = x2[:, ch]
            if self._use_pilot:
                b0, b1, b2, a1, a2 = self._c_pilot
                st = self._state_pilot[ch]
                col, st[0], st[1], st[2], st[3] = _biquad_apply(
                    col, b0, b1, b2, a1, a2, st[0], st[1], st[2], st[3])
            if self._use_sub:
                b0, b1, b2, a1, a2 = self._c_sub
                st = self._state_sub[ch]
                col, st[0], st[1], st[2], st[3] = _biquad_apply(
                    col, b0, b1, b2, a1, a2, st[0], st[1], st[2], st[3])
            out[:, ch] = col

        result = np.clip(out, -1.0, 1.0).astype(np.float32)
        return result[:, 0] if mono else result
