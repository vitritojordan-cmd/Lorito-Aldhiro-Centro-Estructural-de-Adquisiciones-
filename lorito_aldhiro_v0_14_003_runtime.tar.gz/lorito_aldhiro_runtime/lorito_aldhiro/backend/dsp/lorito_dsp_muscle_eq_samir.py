from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ecualización en caliente con bandas manuales, presets y curvas técnicas (Vitrito).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_muscle_eq_samir.py -- GAP-043, "MUSCLE EQ SAMIR (VITRITO)"
-- Powered by Jordan Vitrito Cornuero.

Procesador de ecualizacion en caliente / tiempo real para el menu
OPTAPE, construido a pedido explicito del usuario (Orden de Ingenieria
"MUSCLE EQ SAMIR") -- diseno nuevo para Lorito Aldhiro (no adaptado del
monolito de origen como los DSP de PREVI/FNESP anteriores, GAP-039/041/042),
siguiendo la arquitectura DSP ya compartida del proyecto (NumPy +
Numba, Biquad Direct Form II Transposed, estados persistentes por
canal, sanitize_finite).

## Principio fundamental (orden, S2-3)

IN-LINE / HOT PROCESSING por bloques, nunca captura completa +
procesamiento posterior. Modificable en caliente (banda, frecuencia,
ganancia, Q, preset) sin detener el transporte -- todo cambio de
parametro entra en vigor mediante una TRANSICION SUAVE (S13), nunca un
salto abrupto de coeficientes.

## Motor de bandas (orden, S6-7)

6 tipos de filtro (RBJ Audio EQ Cookbook, Direct Form II Transposed):
LOW_SHELF, HIGH_SHELF, PEAKING, HPF, LPF, NOTCH. Hasta MAX_BANDS (8)
bandas simultaneas, cada una con su propio banco de biquads por canal
(nunca compartido entre canales).

## Transicion suave de coeficientes (orden, S13-14)

Se implementa por RAMPA LINEAL de los propios coeficientes
(b0/b1/b2/a1/a2) a lo largo de TRANSITION_SAMPLES (~10ms) cada vez que
una banda cambia de parametros -- tecnica simple y causal, sin
necesidad de correr dos cadenas de filtro en paralelo. Para cambios
moderados (los que produce el uso normal del panel) esto es
indistinguible al oido de una transicion mas sofisticada, y evita la
complejidad/costo de mantener un segundo banco de filtros "viejo"
corriendo en paralelo solo para crossfade. Activacion/desactivacion/
bypass usan la MISMA rampa aplicada a una ganancia de mezcla
seca/humeda (dry/wet), nunca "ganancia=0dB" como sustituto de bypass
(orden, S18).

## Sanitizacion (orden, S15)

Input y output pasan por sanitize_finite (ya existente en Lorito,
GAP-025/Fase 10) -- un NaN nunca contamina silenciosamente el resto de
la cadena. La integracion real con NRCoordinator._sanitize_stage()
(reset() de la etapa completa al detectar corrupcion) se hace en el
punto de conexion, igual que el resto de DSP de OPTAPE.

## Que NO se implemento (fuera de alcance explicito de la orden, o ya
cubierto por otra parte de Lorito)

- Curvas RIAA/NAB con precision de decodificador de fono dedicado --
  Muscle Eq Samir es un ecualizador general de tono (S27:
  "zero-additional-latency/causal... sin FFT, sin convolucion larga"),
  no un decodificador de correccion RIAA/NAB de precision. Se
  aproximan con las frecuencias de esquina REALES documentadas (RIAA:
  50Hz/500Hz/2122Hz; NAB: 50Hz/3183Hz a 7.5ips) usando el mismo motor
  de bandas shelf/peaking -- identificadas explicitamente como
  aproximacion, no como decodificador de precision.
- Perfiles TAPE aqui son compensacion tonal (S9.5: "no sustituiran la
  correcta calibracion electromagnetica del deck") -- no duplican
  TapeEqBiasProfile (que si modela voicing/headroom real de tipo de
  cinta, ya existente en Lorito).
"""

from enum import Enum

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit
# GAP-051 (FASE 1 de la Orden de Saneamiento, Integración y
# Consolidación, §15): `MuscleEqError` era un `RuntimeError` suelto.
# Se consolida bajo `LoritoError` — mismo nombre, mismo constructor
# (code, message), mismo comportamiento externo.
from lorito_aldhiro.backend.errors import LoritoError

MAX_BANDS = 8
TRANSITION_SAMPLES = 480  # ~10ms a 48kHz -- rampa de coeficientes/dry-wet


class EqBandType(str, Enum):
    LOW_SHELF = "LOW_SHELF"
    HIGH_SHELF = "HIGH_SHELF"
    PEAKING = "PEAKING"
    HPF = "HPF"
    LPF = "LPF"
    NOTCH = "NOTCH"


class MuscleEqError(LoritoError):
    """Errores especificos de Muscle Eq Samir -- orden S30. Se usa un
    unico tipo con `code` (MUSCLE_EQ_INVALID_*) en vez de 12 subclases
    -- el contrato pedido (codigo + mensaje) no requiere jerarquia de
    excepciones separada; simplifica el manejo sin perder trazabilidad.
    Consolidada bajo `LoritoError` en GAP-051 (§15) -- antes heredaba
    de `RuntimeError` directamente; mismo comportamiento externo."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


def _validate_band_params(freq_hz: float, gain_db: float, q: float,
                          sample_rate: float) -> None:
    if not np.isfinite(freq_hz) or freq_hz <= 0 or freq_hz >= sample_rate / 2.0:
        raise MuscleEqError("MUSCLE_EQ_INVALID_FREQUENCY",
                            f"frecuencia fuera de rango: {freq_hz}")
    if not np.isfinite(gain_db) or abs(gain_db) > 24.0:
        raise MuscleEqError("MUSCLE_EQ_INVALID_GAIN",
                            f"ganancia fuera de rango: {gain_db}")
    if not np.isfinite(q) or q <= 0.05 or q > 20.0:
        raise MuscleEqError("MUSCLE_EQ_INVALID_Q", f"Q fuera de rango: {q}")


def _coefs_low_shelf(freq_hz, gain_db, q, fs):
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / 2.0 * np.sqrt((A + 1.0 / A) * (1.0 / max(q, 1e-3) - 1.0) + 2.0)
    two_sqrtA_alpha = 2.0 * np.sqrt(A) * alpha
    b0 = A * ((A + 1.0) - (A - 1.0) * cw0 + two_sqrtA_alpha)
    b1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * cw0)
    b2 = A * ((A + 1.0) - (A - 1.0) * cw0 - two_sqrtA_alpha)
    a0 = (A + 1.0) + (A - 1.0) * cw0 + two_sqrtA_alpha
    a1 = -2.0 * ((A - 1.0) + (A + 1.0) * cw0)
    a2 = (A + 1.0) + (A - 1.0) * cw0 - two_sqrtA_alpha
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


def _coefs_high_shelf(freq_hz, gain_db, q, fs):
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / 2.0 * np.sqrt((A + 1.0 / A) * (1.0 / max(q, 1e-3) - 1.0) + 2.0)
    two_sqrtA_alpha = 2.0 * np.sqrt(A) * alpha
    b0 = A * ((A + 1.0) + (A - 1.0) * cw0 + two_sqrtA_alpha)
    b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cw0)
    b2 = A * ((A + 1.0) + (A - 1.0) * cw0 - two_sqrtA_alpha)
    a0 = (A + 1.0) - (A - 1.0) * cw0 + two_sqrtA_alpha
    a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cw0)
    a2 = (A + 1.0) - (A - 1.0) * cw0 - two_sqrtA_alpha
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


def _coefs_peaking(freq_hz, gain_db, q, fs):
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / (2.0 * max(q, 1e-3))
    b0 = 1.0 + alpha * A
    b1 = -2.0 * cw0
    b2 = 1.0 - alpha * A
    a0 = 1.0 + alpha / A
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha / A
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


def _coefs_hpf(freq_hz, gain_db, q, fs):
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / (2.0 * max(q, 1e-3))
    b0 = (1.0 + cw0) / 2.0
    b1 = -(1.0 + cw0)
    b2 = (1.0 + cw0) / 2.0
    a0 = 1.0 + alpha
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


def _coefs_lpf(freq_hz, gain_db, q, fs):
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / (2.0 * max(q, 1e-3))
    b0 = (1.0 - cw0) / 2.0
    b1 = 1.0 - cw0
    b2 = (1.0 - cw0) / 2.0
    a0 = 1.0 + alpha
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


def _coefs_notch(freq_hz, gain_db, q, fs):
    w0 = 2.0 * np.pi * freq_hz / fs
    cw0, sw0 = np.cos(w0), np.sin(w0)
    alpha = sw0 / (2.0 * max(q, 1e-3))
    b0 = 1.0
    b1 = -2.0 * cw0
    b2 = 1.0
    a0 = 1.0 + alpha
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


_COEF_FUNCS = {
    EqBandType.LOW_SHELF: _coefs_low_shelf,
    EqBandType.HIGH_SHELF: _coefs_high_shelf,
    EqBandType.PEAKING: _coefs_peaking,
    EqBandType.HPF: _coefs_hpf,
    EqBandType.LPF: _coefs_lpf,
    EqBandType.NOTCH: _coefs_notch,
}


def _biquad_ramped_kernel_py(x, b0_a, b1_a, b2_a, a1_a, a2_a,
                             b0_b, b1_b, b2_b, a1_b, a2_b,
                             z1, z2, ramp_pos, ramp_len):
    n = x.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        if ramp_pos < ramp_len:
            t = ramp_pos / ramp_len
            b0 = b0_a + (b0_b - b0_a) * t
            b1 = b1_a + (b1_b - b1_a) * t
            b2 = b2_a + (b2_b - b2_a) * t
            a1 = a1_a + (a1_b - a1_a) * t
            a2 = a2_a + (a2_b - a2_a) * t
            ramp_pos += 1
        else:
            b0, b1, b2, a1, a2 = b0_b, b1_b, b2_b, a1_b, a2_b
        xi = x[i]
        yi = b0 * xi + z1
        z1 = b1 * xi - a1 * yi + z2
        z2 = b2 * xi - a2 * yi
        out[i] = yi
    return out, z1, z2, ramp_pos


_biquad_ramped_kernel = njit(cache=True)(_biquad_ramped_kernel_py)


class _RampedBiquadChannel:
    """Un biquad DF2T por canal, con rampa lineal de coeficientes al
    cambiar de parametros (orden S13-14 -- transicion suave, nunca
    salto abrupto)."""

    def __init__(self, fs: float):
        self.fs = float(fs)
        self._b = (1.0, 0.0, 0.0, 0.0, 0.0)  # paso directo (banda OFF)
        self._target = self._b
        self._ramp_pos = TRANSITION_SAMPLES  # sin rampa pendiente al crear
        self._z1 = 0.0
        self._z2 = 0.0

    def set_target(self, coefs: tuple) -> None:
        current = self._current_coefs()
        self._b = current
        self._target = coefs
        self._ramp_pos = 0

    def _current_coefs(self) -> tuple:
        if self._ramp_pos >= TRANSITION_SAMPLES:
            return self._target
        t = self._ramp_pos / TRANSITION_SAMPLES
        return tuple(a + (b - a) * t for a, b in zip(self._b, self._target))

    def process(self, x: np.ndarray) -> np.ndarray:
        out, self._z1, self._z2, ramp_pos_f = _biquad_ramped_kernel(
            np.ascontiguousarray(x, dtype=np.float64),
            *self._b, *self._target, self._z1, self._z2,
            float(self._ramp_pos), float(TRANSITION_SAMPLES))
        self._ramp_pos = int(ramp_pos_f)
        return out

    def reset(self) -> None:
        self._z1 = 0.0
        self._z2 = 0.0
        self._b = self._target
        self._ramp_pos = TRANSITION_SAMPLES


class EqBand:
    """Una banda de Muscle Eq Samir -- orden S7/S25. `coefficients`/
    `filter_state` viven en _RampedBiquadChannel (uno por canal), no
    aca -- este objeto es solo la config declarada por el usuario."""

    __slots__ = ("type", "freq_hz", "gain_db", "q", "enabled")

    def __init__(self, type: EqBandType = EqBandType.PEAKING,
                freq_hz: float = 1000.0, gain_db: float = 0.0,
                q: float = 0.707, enabled: bool = False):
        self.type = EqBandType(type)
        self.freq_hz = float(freq_hz)
        self.gain_db = float(gain_db)
        self.q = float(q)
        self.enabled = bool(enabled)

    def to_dict(self) -> dict:
        return dict(type=self.type.value, freq_hz=self.freq_hz,
                   gain_db=self.gain_db, q=self.q, enabled=self.enabled)


class MuscleEqSamirProfile:
    """MUSCLE EQ SAMIR (VITRITO) -- motor de ecualizacion en caliente.
    Vive en el menu OPTAPE. Estados: OFF, ACTIVE, BYPASS (orden S18 --
    nunca "ganancia=0dB" como sustituto de bypass)."""

    display_name = "MUSCLE EQ SAMIR (VITRITO)"
    legend_label = "MUSC EQ"

    def __init__(self, mode: str = "BYPASS", sample_rate: int = 48000,
                channels: int = 2, preset_id: str = "FLAT", bands=None):
        self.mode = (mode or "BYPASS").upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self._active = self.mode == "ACTIVE"
        self.preset_id = preset_id
        self.bands = bands if bands is not None else [EqBand() for _ in range(MAX_BANDS)]
        self._wet_mix = 1.0 if self._active else 0.0
        self._wet_target = self._wet_mix
        self._wet_ramp_pos = TRANSITION_SAMPLES
        self._channels_state = [
            [_RampedBiquadChannel(self.fs) for _ in range(MAX_BANDS)]
            for _ in range(self.channels)
        ]
        self._rebuild_all_targets()

    def _band_coefs(self, band: EqBand) -> tuple:
        if not band.enabled:
            return (1.0, 0.0, 0.0, 0.0, 0.0)
        try:
            _validate_band_params(band.freq_hz, band.gain_db, band.q, self.fs)
        except MuscleEqError:
            return (1.0, 0.0, 0.0, 0.0, 0.0)
        func = _COEF_FUNCS[band.type]
        return func(band.freq_hz, band.gain_db, band.q, self.fs)

    def _rebuild_all_targets(self) -> None:
        for ch_state in self._channels_state:
            for i, band in enumerate(self.bands):
                ch_state[i].set_target(self._band_coefs(band))

    def set_active(self, active: bool) -> None:
        self._active = bool(active)
        self.mode = "ACTIVE" if self._active else "BYPASS"
        self._wet_target = 1.0 if self._active else 0.0

    @property
    def active(self) -> bool:
        return self._active

    def set_band(self, index: int, **kwargs) -> None:
        if not (0 <= index < len(self.bands)):
            raise MuscleEqError("MUSCLE_EQ_INVALID_BAND", f"indice de banda invalido: {index}")
        band = self.bands[index]
        if "type" in kwargs:
            band.type = EqBandType(kwargs["type"])
        if "freq_hz" in kwargs:
            band.freq_hz = float(kwargs["freq_hz"])
        if "gain_db" in kwargs:
            band.gain_db = float(kwargs["gain_db"])
        if "q" in kwargs:
            band.q = float(kwargs["q"])
        if "enabled" in kwargs:
            band.enabled = bool(kwargs["enabled"])
        coefs = self._band_coefs(band)
        for ch_state in self._channels_state:
            ch_state[index].set_target(coefs)

    def load_preset(self, preset_id: str, bands: list) -> None:
        n = min(len(bands), MAX_BANDS)
        new_bands = [EqBand(**bands[i]) if isinstance(bands[i], dict) else bands[i]
                    for i in range(n)]
        while len(new_bands) < MAX_BANDS:
            new_bands.append(EqBand())
        self.bands = new_bands
        self.preset_id = preset_id
        self._rebuild_all_targets()

    def reset_to_flat(self) -> None:
        self.load_preset("FLAT", [EqBand() for _ in range(MAX_BANDS)])
        self.set_active(False)

    def reset(self) -> None:
        for ch_state in self._channels_state:
            for rb in ch_state:
                rb.reset()
        self._wet_ramp_pos = TRANSITION_SAMPLES
        self._wet_mix = self._wet_target

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if chunk.size == 0:
            return chunk
        mono_in = chunk.ndim == 1
        x = chunk if not mono_in else chunk[:, np.newaxis]
        x64 = x.astype(np.float64) if x.dtype != np.float64 else x.copy()
        n = x64.shape[0]
        wet = np.empty_like(x64)

        for ch in range(min(x64.shape[1], len(self._channels_state))):
            stage = x64[:, ch]
            for band_idx, band in enumerate(self.bands):
                stage = self._channels_state[ch][band_idx].process(stage)
            wet[:, ch] = stage

        if self._wet_ramp_pos < TRANSITION_SAMPLES or self._wet_mix != self._wet_target:
            ramp = np.arange(n, dtype=np.float64) + self._wet_ramp_pos
            frac = np.clip(ramp / TRANSITION_SAMPLES, 0.0, 1.0)
            mix = self._wet_mix + (self._wet_target - self._wet_mix) * frac
            self._wet_ramp_pos = min(TRANSITION_SAMPLES, self._wet_ramp_pos + n)
            if self._wet_ramp_pos >= TRANSITION_SAMPLES:
                self._wet_mix = self._wet_target
            mix = mix[:, np.newaxis]
        else:
            mix = self._wet_target

        out = x64 * (1.0 - mix) + wet * mix
        np.clip(out, -1.0, 1.0, out=out)
        out = out.astype(np.float32)
        return out[:, 0] if mono_in else out
