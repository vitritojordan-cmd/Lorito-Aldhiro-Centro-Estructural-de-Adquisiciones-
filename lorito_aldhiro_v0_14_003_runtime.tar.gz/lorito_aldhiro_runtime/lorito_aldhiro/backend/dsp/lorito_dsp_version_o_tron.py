from __future__ import annotations



"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Color de sonido de radiograbadora doméstica, AM y onda corta (Funciones Especiales).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_dsp_version_o_tron.py -- GAP-041, DSP "Versión O Tron (FNESP)"
-- adaptado desde el monolito de origen (tarball v0_37_416_quad_previ_chain_
derived_export, modulo original nr.version_o_tron) al
catalogo de Lorito Aldhiro.

Simula el color de sonido de 3 fuentes de reproduccion domesticas:

  · AA-MO  -- radiograbadora domestica con microfono de electreto.
  · BARRIL -- receptor de Amplitud Modulada (AM).
  · SIFON  -- receptor de onda corta (voz, tipo SSB).

## Investigacion web pedida explicitamente por el usuario

- BARRIL (AM): el monolito de origen usa 250-5000 Hz. Verificado contra literatura
  real de radiodifusion: varias cadenas de AM en EE.UU. redujeron
  voluntariamente el ancho de banda de audio transmitido a EXACTAMENTE
  5 kHz para estaciones de musica (citado en Radio World) -- casi
  ningun receptor de consumo reproduce mas alla de 4.5-6 kHz en la
  practica. El valor del monolito de origen (5000 Hz) coincide con la practica real
  documentada -- no se corrigio.

- SIFON (onda corta/SSB): el monolito de origen usa 300-3800 Hz. Verificado contra el
  estandar real de radioaficionados: el ancho de banda "de facto" para
  SSB es 300 Hz a 3 kHz, con un modo extendido (ESSB) hasta 3.8-4 kHz.
  El rango del monolito de origen coincide con el extremo extendido real -- no se
  corrigio.

- AA-MO (electreto): el monolito de origen usa 160-7000 Hz atribuido a la "aspereza"
  del microfono de electreto. Hallazgo real: las capsulas de electreto
  reales, incluso las baratas, tienen respuesta AMPLIA (20Hz-12/20kHz
  tipico, confirmado con hojas de datos reales) -- el electreto en si
  NO limita agudos. La limitacion real viene del CONJUNTO (preamp
  barato, altavoz pequeno, AGC simple, cinta ferrica economica) -- se
  conservan los mismos numeros (aproximacion razonable del conjunto)
  pero se corrige la atribucion/documentacion, no el numero.

## Cambio arquitectonico -- de funcion offline a perfil streaming

El original del monolito de origen es una funcion OFFLINE (recibe el array completo,
LFO desde t=0 en cada llamada, envelope de compresion con convolucion
NO CAUSAL `fftconvolve mode='same'`). Adaptado a streaming real:
biquads con estado zi/zf de scipy.signal.lfilter persistente entre
bloques (identico matematicamente a una sola llamada, GAP-029), sigue
de envolvente causal ataque/release en vez del boxcar simetrico, LFO
de fluctuacion con fase persistente.
"""

import math

import numpy as np
from scipy.signal import lfilter


def _norm_db_to_linear(db: float) -> float:
    return 10.0 ** (db / 20.0)


def _design_butterworth_hp_2nd(fc, fs):
    fc = min(max(fc, 1.0), fs * 0.49)
    omega = 2.0 * math.pi * fc / fs
    k = math.tan(omega / 2.0)
    k2 = k * k
    sqrt2 = math.sqrt(2.0)
    norm = 1.0 + sqrt2 * k + k2
    b = np.array([1.0 / norm, -2.0 / norm, 1.0 / norm])
    a = np.array([1.0, (2.0 * (k2 - 1.0)) / norm, (1.0 - sqrt2 * k + k2) / norm])
    return b, a


def _design_butterworth_lp_2nd(fc, fs):
    fc = min(max(fc, 1.0), fs * 0.49)
    omega = 2.0 * math.pi * fc / fs
    k = math.tan(omega / 2.0)
    k2 = k * k
    sqrt2 = math.sqrt(2.0)
    norm = 1.0 + sqrt2 * k + k2
    b = np.array([k2 / norm, 2.0 * k2 / norm, k2 / norm])
    a = np.array([1.0, (2.0 * (k2 - 1.0)) / norm, (1.0 - sqrt2 * k + k2) / norm])
    return b, a


def _design_shelf_biquad(fc, fs, gain_db, is_high_shelf, shelf_slope=1.0):
    if abs(gain_db) < 1e-6:
        return np.array([1.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0])
    fc = min(max(fc, 1.0), fs * 0.49)
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * math.pi * fc / fs
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / 2.0 * math.sqrt((A + 1.0 / A) * (1.0 / shelf_slope - 1.0) + 2.0)
    sqrt_a_2alpha = 2.0 * math.sqrt(A) * alpha
    if is_high_shelf:
        b0 = A * ((A + 1.0) + (A - 1.0) * cos_w0 + sqrt_a_2alpha)
        b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cos_w0)
        b2 = A * ((A + 1.0) + (A - 1.0) * cos_w0 - sqrt_a_2alpha)
        a0 = (A + 1.0) - (A - 1.0) * cos_w0 + sqrt_a_2alpha
        a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cos_w0)
        a2 = (A + 1.0) - (A - 1.0) * cos_w0 - sqrt_a_2alpha
    else:
        b0 = A * ((A + 1.0) - (A - 1.0) * cos_w0 + sqrt_a_2alpha)
        b1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * cos_w0)
        b2 = A * ((A + 1.0) - (A - 1.0) * cos_w0 - sqrt_a_2alpha)
        a0 = (A + 1.0) + (A - 1.0) * cos_w0 + sqrt_a_2alpha
        a1 = -2.0 * ((A - 1.0) + (A + 1.0) * cos_w0)
        a2 = (A + 1.0) + (A - 1.0) * cos_w0 - sqrt_a_2alpha
    b = np.array([b0, b1, b2]) / a0
    a = np.array([1.0, a1 / a0, a2 / a0])
    return b, a


class _StatefulBiquad:
    """Biquad generico con estado (zi/zf de scipy.signal.lfilter)
    persistente entre bloques -- MATEMATICAMENTE identico a una sola
    llamada sobre el array completo (ver GAP-029)."""

    def __init__(self, b, a):
        self.b = np.asarray(b, dtype=np.float64)
        self.a = np.asarray(a, dtype=np.float64)
        self._zi = np.zeros(max(len(self.a), len(self.b)) - 1)

    def process(self, x: np.ndarray) -> np.ndarray:
        out, self._zi = lfilter(self.b, self.a, x, zi=self._zi)
        return out

    def reset(self):
        self._zi[:] = 0.0


def _asymmetric_envelope_py(x_sq, alpha_atk, alpha_rel, state):
    n = x_sq.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x_sq[i]
        if xi > state:
            state = alpha_atk * state + (1.0 - alpha_atk) * xi
        else:
            state = alpha_rel * state + (1.0 - alpha_rel) * xi
        out[i] = state
    return out, state


VOT_CONFIGS = {
    "AA_MO": dict(
        band_lo_hz=160.0, band_hi_hz=7000.0, bass_shelf_db=-1.5, treble_shelf_db=-3.0,
        saturation_drive=1.4, saturation_wet=0.20, comp_threshold_db=-24.0,
        comp_ratio=2.0, comp_attack_s=0.006, comp_release_s=0.150,
        fluct_depth=0.015, fluct_rate_hz=0.35, ceiling_db=-0.8,
        label="AA-MO -- Radiograbadora (conjunto domestico completo)"),
    "BARRIL": dict(
        band_lo_hz=250.0, band_hi_hz=5000.0, bass_shelf_db=1.5, treble_shelf_db=-4.0,
        saturation_drive=2.0, saturation_wet=0.30, comp_threshold_db=-20.0,
        comp_ratio=3.5, comp_attack_s=0.003, comp_release_s=0.220,
        fluct_depth=0.05, fluct_rate_hz=0.7, ceiling_db=-0.6,
        label="Barril -- Amplitud Modulada (verificado: 5kHz real, Radio World)"),
    "SIFON": dict(
        band_lo_hz=300.0, band_hi_hz=3800.0, bass_shelf_db=-2.0, treble_shelf_db=-2.0,
        saturation_drive=2.3, saturation_wet=0.28, comp_threshold_db=-18.0,
        comp_ratio=3.0, comp_attack_s=0.003, comp_release_s=0.260,
        fluct_depth=0.08, fluct_rate_hz=1.1, ceiling_db=-0.6,
        label="Sifon -- Onda Corta (verificado: 300-3.8kHz real, rango SSB/ESSB)"),
}


class VersionOTronProfile:
    """DSP VERSION O TRON (Funciones Especiales) -- vive en el menu
    OPTAPE. mode en {"BYPASS", "AA_MO", "BARRIL", "SIFON"}."""

    display_name = "VERSIÓN O TRON (FNESP)"
    legend_label = "FNESP DSP"

    def __init__(self, mode: str = "BYPASS", sample_rate: int = 48000,
                channels: int = 2, wet: float = 0.85):
        self.mode = mode.upper().strip()
        self.fs = sample_rate
        self.channels = channels
        self.wet = float(np.clip(wet, 0.0, 1.0))
        self._active = self.mode in VOT_CONFIGS
        self._channel_states = []
        if self._active:
            self.config = VOT_CONFIGS[self.mode]
            self._build_channels()

    def _build_channels(self):
        cfg = self.config
        fs = self.fs
        self._channel_states = []
        for ch in range(self.channels):
            st = {}
            st["hp"] = _StatefulBiquad(*_design_butterworth_hp_2nd(cfg["band_lo_hz"], fs))
            st["lp"] = _StatefulBiquad(*_design_butterworth_lp_2nd(cfg["band_hi_hz"], fs))
            bass_fc = max(60.0, cfg["band_lo_hz"] * 2.0)
            treble_fc = max(1000.0, cfg["band_hi_hz"] * 0.6)
            st["bass"] = _StatefulBiquad(*_design_shelf_biquad(
                bass_fc, fs, cfg["bass_shelf_db"], is_high_shelf=False))
            st["treble"] = _StatefulBiquad(*_design_shelf_biquad(
                treble_fc, fs, cfg["treble_shelf_db"], is_high_shelf=True))
            st["comp_env_state"] = 0.0
            st["fluct_phase"] = 0.0
            st["fluct_noise_lp"] = _StatefulBiquad(
                *_design_butterworth_lp_2nd(max(0.5, cfg["fluct_rate_hz"] * 0.5), fs))
            st["rng"] = np.random.default_rng(300 + ch * 23)
            self._channel_states.append(st)

    def reset(self):
        for st in self._channel_states:
            st["hp"].reset()
            st["lp"].reset()
            st["bass"].reset()
            st["treble"].reset()
            st["comp_env_state"] = 0.0
            st["fluct_phase"] = 0.0
            st["fluct_noise_lp"].reset()

    def _process_channel(self, xc: np.ndarray, st: dict) -> np.ndarray:
        cfg = self.config
        x = xc.astype(np.float64)

        x = st["hp"].process(x)
        x = st["lp"].process(x)
        x = st["bass"].process(x)
        x = st["treble"].process(x)

        drive = max(cfg["saturation_drive"], 1e-3)
        sat = np.tanh(x * drive) / math.tanh(drive)
        x = x * (1.0 - cfg["saturation_wet"]) + sat * cfg["saturation_wet"]

        if cfg["comp_ratio"] > 1.0:
            alpha_atk = math.exp(-1.0 / max(1, int(cfg["comp_attack_s"] * self.fs)))
            alpha_rel = math.exp(-1.0 / max(1, int(cfg["comp_release_s"] * self.fs)))
            env_sq, st["comp_env_state"] = _asymmetric_envelope_py(
                x * x, alpha_atk, alpha_rel, st["comp_env_state"])
            envelope = np.sqrt(np.maximum(env_sq, 0.0))
            env_db = 20.0 * np.log10(np.maximum(envelope, 1e-9))
            over_db = np.maximum(env_db - cfg["comp_threshold_db"], 0.0)
            gain_reduction_db = over_db * (1.0 - 1.0 / cfg["comp_ratio"])
            gain_lin = np.power(10.0, -gain_reduction_db / 20.0)
            x = x * gain_lin

        if cfg["fluct_depth"] > 0.0:
            n = len(x)
            t = (st["fluct_phase"] + np.arange(n, dtype=np.float64)) / self.fs
            lfo = np.sin(2.0 * math.pi * cfg["fluct_rate_hz"] * t)
            st["fluct_phase"] += n
            noise = st["rng"].standard_normal(n)
            noise_lp = st["fluct_noise_lp"].process(noise)
            peak = float(np.max(np.abs(noise_lp))) if n else 0.0
            if peak > 1e-9:
                noise_lp = noise_lp / peak
            modulation = 1.0 + cfg["fluct_depth"] * (0.6 * lfo + 0.4 * noise_lp)
            x = x * modulation

        ceiling_lin = _norm_db_to_linear(cfg["ceiling_db"])
        peak_now = float(np.max(np.abs(x))) if x.size else 0.0
        if peak_now > ceiling_lin:
            x = x * (ceiling_lin / peak_now)

        return x

    def process_chunk(self, chunk: np.ndarray) -> np.ndarray:
        if not self._active or chunk.size == 0:
            return chunk
        mono_in = chunk.ndim == 1
        x = chunk if not mono_in else chunk[:, np.newaxis]
        x64 = x.astype(np.float64) if x.dtype != np.float64 else x.copy()
        wet_out = np.empty_like(x64)
        for ch in range(min(x64.shape[1], len(self._channel_states))):
            wet_out[:, ch] = self._process_channel(x64[:, ch], self._channel_states[ch])
        blended = x64 * (1.0 - self.wet) + wet_out * self.wet
        out = np.clip(blended, -1.0, 1.0).astype(np.float32)
        return out[:, 0] if mono_in else out
