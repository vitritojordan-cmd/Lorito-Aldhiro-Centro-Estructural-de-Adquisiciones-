from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Filtro biquad Direct Form II Transposed compartido por los 20 emuladores Lucha Enloquecida.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


biquad.py -- lucha_enloquecida (GAP-042)

Portado desde el monolito de origen (dsp_previ.lucha_enloquecida.biquad) sin
cambios de matematica -- Direct Form II Transposed, variantes peaking
y bandpass (RBJ Audio EQ Cookbook). Import de numba adaptado al patron
compartido de Lorito (lorito_dsp_numba_utils) en vez del try/except
propio del monolito de origen.
"""

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit

__all__ = ["biquad_peaking_coefs", "biquad_bandpass_coefs", "BiquadDF2T", "BiquadBandpassDF2T"]


def biquad_peaking_coefs(freq_hz, q, gain_db, fs):
    nyquist = fs / 2.0
    freq_hz = min(max(freq_hz, 1.0), nyquist * 0.999)
    w0 = 2.0 * np.pi * freq_hz / fs
    alpha = np.sin(w0) / (2.0 * max(q, 1e-3))
    a_gain = 10.0 ** (gain_db / 40.0)
    cw0 = np.cos(w0)
    b0 = 1.0 + alpha * a_gain
    b1 = -2.0 * cw0
    b2 = 1.0 - alpha * a_gain
    a0 = 1.0 + alpha / a_gain
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha / a_gain
    return (float(b0 / a0), float(b1 / a0), float(b2 / a0), float(a1 / a0), float(a2 / a0))


def biquad_bandpass_coefs(freq_hz, q, fs):
    nyquist = fs / 2.0
    freq_hz = min(max(freq_hz, 1.0), nyquist * 0.999)
    w0 = 2.0 * np.pi * freq_hz / fs
    alpha = np.sin(w0) / (2.0 * max(q, 1e-3))
    cw0 = np.cos(w0)
    b0 = alpha
    b1 = 0.0
    b2 = -alpha
    a0 = 1.0 + alpha
    a1 = -2.0 * cw0
    a2 = 1.0 - alpha
    return (float(b0 / a0), float(b1 / a0), float(b2 / a0), float(a1 / a0), float(a2 / a0))


def _df2t_process_kernel_py(x, b0, b1, b2, a1, a2, z1, z2):
    n = x.shape[0]
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        xi = x[i]
        yi = b0 * xi + z1
        z1 = b1 * xi - a1 * yi + z2
        z2 = b2 * xi - a2 * yi
        out[i] = yi
    return out, z1, z2


_df2t_process_kernel = njit(cache=True)(_df2t_process_kernel_py)


class BiquadDF2T:
    """Filtro Biquad Direct Form II Transposed (peaking), un canal,
    estado persistente entre bloques."""

    def __init__(self, freq_hz, q, gain_db, fs):
        self.fs = float(fs)
        self.freq_hz = float(freq_hz)
        self.q = float(q)
        self.gain_db = float(gain_db)
        self._z1 = 0.0
        self._z2 = 0.0
        self._recompute()

    def _recompute(self):
        self._b0, self._b1, self._b2, self._a1, self._a2 = biquad_peaking_coefs(
            self.freq_hz, self.q, self.gain_db, self.fs)

    def set_params(self, freq_hz=None, q=None, gain_db=None):
        if freq_hz is not None:
            self.freq_hz = float(freq_hz)
        if q is not None:
            self.q = float(q)
        if gain_db is not None:
            self.gain_db = float(gain_db)
        self._recompute()

    def process(self, x):
        out, self._z1, self._z2 = _df2t_process_kernel(
            np.ascontiguousarray(x, dtype=np.float64),
            self._b0, self._b1, self._b2, self._a1, self._a2, self._z1, self._z2)
        return out

    def reset(self):
        self._z1 = 0.0
        self._z2 = 0.0


class BiquadBandpassDF2T:
    """Filtro Biquad pasa-banda Direct Form II Transposed, un canal,
    estado persistente entre bloques."""

    def __init__(self, freq_hz, q, fs):
        self.fs = float(fs)
        self.freq_hz = float(freq_hz)
        self.q = float(q)
        self._z1 = 0.0
        self._z2 = 0.0
        self._recompute()

    def _recompute(self):
        self._b0, self._b1, self._b2, self._a1, self._a2 = biquad_bandpass_coefs(
            self.freq_hz, self.q, self.fs)

    def set_params(self, freq_hz=None, q=None):
        if freq_hz is not None:
            self.freq_hz = float(freq_hz)
        if q is not None:
            self.q = float(q)
        self._recompute()

    def process(self, x):
        out, self._z1, self._z2 = _df2t_process_kernel(
            np.ascontiguousarray(x, dtype=np.float64),
            self._b0, self._b1, self._b2, self._a1, self._a2, self._z1, self._z2)
        return out

    def reset(self):
        self._z1 = 0.0
        self._z2 = 0.0
