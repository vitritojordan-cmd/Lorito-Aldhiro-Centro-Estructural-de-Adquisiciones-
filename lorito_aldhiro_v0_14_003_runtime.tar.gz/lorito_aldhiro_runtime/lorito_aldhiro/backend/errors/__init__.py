"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Taxonomía formal de excepciones de Lorito Aldhiro — raíz común (§15) + familia de exportación (§11) + integridad DSP (§16).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Rama nueva del árbol de módulos de Lorito Aldhiro (subpaquete
conectado por este `__init__.py`, convención vigente desde GAP-032),
creada en FASE 1 ("Contratos + errores") de la Orden Maestra de
Saneamiento, Integración y Consolidación (GAP-051).

Módulos:
  · lorito_errors_base   — `LoritoError` y las 7 categorías de política
    de recuperación (§15): `RecoverableError`, `DegradedError`,
    `FatalError`, `IntegrityError`, `CorruptionError`,
    `LoritoEnvironmentError` (renombrada — ver docstring del módulo),
    `UserAbortError`.
  · lorito_errors_export — `ExportError` y sus 6 subclases con campos
    estructurados obligatorios (§11): `segment_id`, `frame_start`,
    `frame_count`, `path`, `cause`, `recoverable`.
  · lorito_errors_dsp    — `DSPIntegrityError` y los errores tipados de la
    cadena DSP/NR (configuración, formato, falla numérica, timeout,
    sobrecarga, fuente y etapa; Orden SERVO-016 §4).

Ver `gaps/GAP-051.md` para el detalle completo de esta fase, incluidas
las 5 excepciones ad-hoc preexistentes (`FormatMismatchError`,
`ExportAbortError`, `SegmentReadError`, `InvalidTransitionError`,
`MuscleEqError`) retroadaptadas para heredar de esta taxonomía sin
cambiar su comportamiento externo.
"""

from lorito_aldhiro.backend.errors.lorito_errors_base import (
    LoritoError, RecoverableError, DegradedError, FatalError,
    IntegrityError, CorruptionError, LoritoEnvironmentError, UserAbortError,
)
from lorito_aldhiro.backend.errors.lorito_errors_export import (
    ExportError, FormatMismatchError, ExportAbortError, SegmentReadError,
    SegmentIntegrityError, FrameAccountingError, ChecksumMismatchError,
    ExportFinalizeError, ExportCancelledError, CodecUnavailableError,
)
from lorito_aldhiro.backend.errors.lorito_errors_dsp import (
    DSPIntegrityError, DSPContractError, DSPStageError, DSPInvalidConfigError,
    DSPUnsupportedFormatError, DSPNumericalFaultError, DSPTimeoutError,
    DSPOverloadError, DSPSourceError,
)

__all__ = [
    "LoritoError", "RecoverableError", "DegradedError", "FatalError",
    "IntegrityError", "CorruptionError", "LoritoEnvironmentError", "UserAbortError",
    "ExportError", "FormatMismatchError", "ExportAbortError", "SegmentReadError",
    "SegmentIntegrityError", "FrameAccountingError", "ChecksumMismatchError",
    "ExportFinalizeError", "ExportCancelledError", "CodecUnavailableError",
    "DSPIntegrityError", "DSPContractError", "DSPStageError", "DSPInvalidConfigError",
    "DSPUnsupportedFormatError", "DSPNumericalFaultError", "DSPTimeoutError",
    "DSPOverloadError", "DSPSourceError",
]
