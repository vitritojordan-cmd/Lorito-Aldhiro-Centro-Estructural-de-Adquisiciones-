from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Errores tipados de la cadena DSP/NR — configuración, formato, falla numérica, timeout, sobrecarga, fuente y etapa.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_errors_dsp.py — errores tipados de la cadena DSP/NR.

Historia: §16 de la Orden Maestra creó `DSPIntegrityError` sin conectarla
(la política ante NaN/Inf quedaba pendiente de decisión). La Orden Golden
DSP (LA-GOLDEN-DSP-PREVI-NR-001) la conectó como raíz de
`DSPContractError`/`DSPStageError`.

Orden Golden PREVI · NR · Servosistemas (LA-GOLDEN-PREVI-NR-SERVO-016,
§4 "Errores"): el motor devuelve estados TIPADOS — configuración inválida,
formato no soportado, falla numérica, timeout, sobrecarga, error de fuente —
y nunca un genérico «DSP no disponible». Cada clase lleva `kind` (cadena
estable para telemetría, eventos y UI). La política ante valores no
finitos es ahora EXPLÍCITA y elegible en `NRCoordinator.numeric_policy`:
`SANITIZE` (por defecto en vivo: sanear, contar, reiniciar la etapa y
marcar DEGRADED) o `FAIL` (lanzar `DSPNumericalFaultError`).

Jerarquía (todas son `DSPIntegrityError` → `IntegrityError` → `LoritoError`):

  DSPContractError            CONTRACT            (base de los dos siguientes)
    DSPInvalidConfigError     INVALID_CONFIG      token/modo/parámetro/combinación inválidos
    DSPUnsupportedFormatError UNSUPPORTED_FORMAT  sample rate, canales, dtype o forma
  DSPNumericalFaultError      NUMERICAL_FAULT     NaN/Inf con política FAIL
  DSPTimeoutError             TIMEOUT             reconfiguración sin aplicar a tiempo
  DSPOverloadError            OVERLOAD            etapa fuera de presupuesto de forma sostenida
  DSPSourceError              SOURCE_ERROR        la fuente entregó algo que no es audio
  DSPStageError               STAGE_FAILURE       una etapa lanzó o devolvió forma inválida
"""

from lorito_aldhiro.backend.errors.lorito_errors_base import IntegrityError


class DSPIntegrityError(IntegrityError):
    """Raíz de los errores de la cadena DSP/NR (ver jerarquía arriba).

    Atributo adicional sobre `IntegrityError`:
        stage: nombre de la etapa DSP donde se detectó el valor no
            finito (p. ej. ``"input"`` o el nombre de la etapa de
            `NRCoordinator._nonfinite_counts`), o ``None``.
    """

    def __init__(self, message: str, *, stage: str | None = None,
                 cause: Exception | None = None):
        super().__init__(message, cause=cause)
        self.stage = stage

    kind = "DSP_INTEGRITY"


class DSPContractError(DSPIntegrityError):
    """Orden Golden DSP (NR-03): configuración o bloque que viola el
    contrato `DSPBlockContract` (modo/token desconocido, sample rate o
    cardinalidad no soportados, forma/dtype inválidos). Se rechaza ANTES
    de procesar — nunca un bypass silencioso."""
    kind = "CONTRACT"


class DSPInvalidConfigError(DSPContractError):
    """Token, modo, parámetro o combinación de etapas inválidos (incluye el
    rechazo en preflight de combinaciones NR incompatibles, NR-03)."""
    kind = "INVALID_CONFIG"


class DSPUnsupportedFormatError(DSPContractError):
    """Sample rate, cantidad de canales, dtype o forma del bloque fuera del
    contrato."""
    kind = "UNSUPPORTED_FORMAT"


class DSPNumericalFaultError(DSPIntegrityError):
    """Valores no finitos con `numeric_policy == "FAIL"`: el bloque se
    rechaza en vez de sanearse."""
    kind = "NUMERICAL_FAULT"


class DSPTimeoutError(DSPIntegrityError):
    """Una reconfiguración pedida no llegó a aplicarse en la frontera de
    bloque dentro del plazo."""
    kind = "TIMEOUT"


class DSPOverloadError(DSPIntegrityError):
    """Una etapa superó su presupuesto de tiempo de forma sostenida. En la
    ruta de audio NO se lanza: se registra como estado y evento."""
    kind = "OVERLOAD"


class DSPSourceError(DSPIntegrityError):
    """La fuente entregó algo que no es un bloque de audio (no ndarray,
    None)."""
    kind = "SOURCE_ERROR"


class DSPStageError(DSPIntegrityError):
    """Orden Golden DSP (fallos de etapa): una etapa lanzó una excepción
    o devolvió una salida con forma inválida. El coordinador NO entrega
    un bloque "aparentemente válido": propaga este error tipado con el
    nombre de la etapa para que el llamador aborte/degrade según su
    política (en captura: el bloque DERIVED se descarta y se cuenta; el
    RAW nunca se ve afectado)."""
    kind = "STAGE_FAILURE"
