"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Exportación — integridad, normalización (constantes y referencias), overlays del LCD y motor espectral.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Rama del árbol de módulos de Lorito Aldhiro. Este `__init__.py` estaba
vacío desde su creación — violación de la convención "nunca se deja un
`__init__.py` vacío como simple marcador de paquete" (vigente desde
GAP-032) que pasó desapercibida hasta esta sesión (GAP-051, FASE 1 de
la Orden de Saneamiento, Integración y Consolidación).

Módulos:
  · (RETIRADO) lorito_exporters — los exportadores basados en un
    `np.ndarray` de sesión completa (`_EXPORTERS`) se eliminaron en la
    Orden Golden de Exportación (Fase 6). La única ruta productiva es
    `backend/export_streaming/lorito_export_service.ExportService`.
  · lorito_export_integrity   — `_sha256_file`/`_validate_export`/
    `_write_checksum_file` (reutilizados por `AtomicFinalizer`).
  · lorito_normalization_common — símbolos vigentes de la normalización
    (leyendas de velocidad, dB, constantes, etiquetas v21). Extraído en
    0.12 (Orden NORM-ARCH-017).
  · (RETIRADOS, 0.12) lorito_normalization / lorito_normalization_v21 —
    motores de normalización en RAM; archivados en
    `legado/lorito_aldhiro/backend/export/` con manifiesto SHA-256. La
    normalización productiva es streaming (`backend/export_streaming/`).
  · lorito_overlay_registry   — mensajes de overlay del contómetro/log.
  · (RETIRADO, 0.11.014) lorito_reports — legado desconectado; movido a
    `legado/lorito_aldhiro/backend/export/lorito_reports.py`, fuera del
    paquete (ver `legado/README_LEGADO.md`).
  · lorito_export_spectral_engine — cómputo de espectrograma para el
    Visor de Señal.

NOTA DE DISEÑO (por qué este `__init__.py`, a diferencia de
`export_streaming/__init__.py`/`archival/__init__.py`, NO reexporta
sus símbolos de forma anticipada): `lorito_export_integrity.py` tiene `import soundfile as sf` a nivel
de módulo — una dependencia dura no instalada en este sandbox (solo
disponible vía stubs instalados explícitamente por cada test que la
necesita). El paquete `__init__.py` de un subpaquete se ejecuta
SIEMPRE que se importa cualquiera de sus submódulos, incluso uno sin
relación (p. ej. `from lorito_aldhiro.backend.export.lorito_
normalization_common import X`, que varios módulos hacen a nivel de
módulo SIN stubear `soundfile` primero, porque ese módulo no lo
necesita). Reexportar aquí `lorito_exporters`/`lorito_export_integrity`
de forma incondicional habría roto esos imports con un
`ModuleNotFoundError: soundfile` en cuanto se tocara CUALQUIER
submódulo del paquete — un efecto colateral real, no hipotético,
verificado al escribir este archivo. Ningún código existente importa
hoy desde `lorito_aldhiro.backend.export` a nivel de paquete (solo
desde sus submódulos directamente), así que la ausencia de reexportes
aquí no cambia nada del comportamiento actual.
"""
