from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Verificación de integridad del archivo exportado contra la sesión capturada.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import shutil
import subprocess
import hashlib
import json
from datetime import datetime
import soundfile as sf

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.audio.lorito_audio_backend import FFMPEG_CAPS
from lorito_aldhiro.backend.capture.lorito_session_status import current as current_session_status
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, _version_label



# ── Integridad archivística: SHA-256 ─────────────────────────────────────────

def _sha256_file(path: str, chunk_size: int = 1 << 20) -> str:
    """
    Calcula SHA-256 de un archivo en chunks (sin cargar completo en RAM).
    Devuelve hex digest o "" si falla.
    """
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                blk = f.read(chunk_size)
                if not blk:
                    break
                h.update(blk)
        return h.hexdigest()
    except Exception as e:
        _log.warning("SHA-256 falló para %s: %s", path, e)
        return ""


def _write_checksum_file(audio_path: str, sha256: str,
                         duration_secs: float, frames: int) -> str:
    """
    Escribe archivo .sha256 junto al export final.
    Formato: <hash>  <nombre>\n + metadatos.
    Devuelve la ruta del archivo .sha256.
    """
    chk_path = audio_path + ".sha256"
    try:
        name     = os.path.basename(audio_path)
        size_b   = os.path.getsize(audio_path)
        ts_iso   = datetime.now().isoformat()
        st       = current_session_status()
        lines    = [
            f"{sha256}  {name}",
            f"# Generado por Lorito Aldhiro {_version_label(APP_VERSION)} — {ts_iso}",  # FIX-BUG07: versión dinámica (antes hardcodeada como v0.09)
            f"# Tamaño: {size_b} bytes",
            f"# Duración: {duration_secs:.3f} s",
            f"# Frames: {frames}",
            f"# Clips L:{st.clip_count_l} R:{st.clip_count_r}",
            f"# XRuns: {st.xrun_count}",
            f"# Drift: {st.drift_ms:.2f} ms",
        ]
        with open(chk_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
            # PATCH D-4 (auditado desde stability_patch.py — ver
            # GAP-009): fsync explícito del .sha256. Sin esto, en un corte
            # de energía justo tras el export, el archivo de checksum podía
            # quedar en el buffer del SO y nunca llegar a disco, dejando un
            # export "verificado" sin su prueba de integridad real.
            f.flush()
            os.fsync(f.fileno())
        _log.info("Checksum escrito (fsync OK): %s  sha256=%s...", chk_path, sha256[:16])
    except Exception as e:
        _log.warning("No se pudo escribir checksum: %s", e)
        chk_path = ""
    return chk_path


# ── Validación post-export avanzada ──────────────────────────────────────────

def _validate_export(path: str, expected_dur_secs: float,
                     expected_rate: int) -> dict:
    """
    Reabre el archivo exportado y valida: decodificación, duración,
    samplerate y tamaño. Devuelve dict con resultado.
    """
    result = {
        "ok":            False,
        "path":          path,
        "actual_dur":    0.0,
        "actual_rate":   0,
        "actual_frames": 0,
        "actual_size":   0,
        "error":         "",
    }
    try:
        if not os.path.exists(path):
            result["error"] = "archivo no existe"
            return result
        result["actual_size"] = os.path.getsize(path)
        if result["actual_size"] < 512:
            result["error"] = f"tamaño sospechoso ({result['actual_size']} bytes)"
            return result

        # Intentar con soundfile primero.
        # NOTA: libsndfile puede NO tener soporte WavPack compilado (depende del
        # sistema). En ese caso lanza una excepción aunque el archivo esté íntegro,
        # lo que producía el falso "error de exportación" visible en los logs.
        # Se captura la excepción de soundfile y se reintenta con ffprobe.
        _sf_ok = False
        try:
            with sf.SoundFile(path, "r") as f:
                result["actual_frames"] = f.frames
                result["actual_rate"]   = f.samplerate
                result["actual_dur"]    = f.frames / max(f.samplerate, 1)
            _sf_ok = True
        except Exception as _sf_err:
            _log.debug("_validate_export: soundfile no pudo leer '%s' (%s) — "
                       "reintentando con ffprobe", path, _sf_err)

        if not _sf_ok:
            # Fallback ffprobe: disponible en cualquier sistema que tenga ffmpeg.
            # Se extrae samplerate, nb_samples y duration con -show_streams -v quiet.
            ffprobe_path = shutil.which("ffprobe")
            if not ffprobe_path and FFMPEG_CAPS.get("path"):
                # ffprobe suele estar junto a ffmpeg
                ffprobe_path = shutil.which(
                    "ffprobe",
                    path=os.path.dirname(FFMPEG_CAPS["path"]) + os.pathsep + os.environ.get("PATH", "")
                )
            if not ffprobe_path:
                result["error"] = (
                    "soundfile no soporta este formato y ffprobe no está disponible "
                    "para validar el archivo exportado."
                )
                return result
            try:
                probe_cmd = [
                    ffprobe_path, "-v", "quiet",
                    "-select_streams", "a:0",
                    "-show_entries", "stream=sample_rate,nb_samples,duration",
                    "-of", "json",
                    path,
                ]
                probe_proc = subprocess.run(
                    probe_cmd, capture_output=True, timeout=30
                )
                probe_data = json.loads(probe_proc.stdout.decode(errors="replace"))
                streams = probe_data.get("streams", [])
                if not streams:
                    result["error"] = "ffprobe: ningún stream de audio encontrado"
                    return result
                st = streams[0]
                actual_rate = int(st.get("sample_rate", 0))
                # nb_samples puede estar ausente en algunos contenedores WavPack
                nb_samples = st.get("nb_samples")
                duration   = st.get("duration")
                if nb_samples and int(nb_samples) > 0:
                    actual_frames = int(nb_samples)
                    actual_dur    = actual_frames / max(actual_rate, 1)
                elif duration:
                    actual_dur    = float(duration)
                    actual_frames = int(actual_dur * actual_rate)
                else:
                    result["error"] = "ffprobe: no se pudo determinar duración del stream"
                    return result
                result["actual_frames"] = actual_frames
                result["actual_rate"]   = actual_rate
                result["actual_dur"]    = actual_dur
                _log.debug("_validate_export ffprobe: frames=%d rate=%d dur=%.2fs",
                           actual_frames, actual_rate, actual_dur)
            except Exception as _fp_err:
                result["error"] = f"ffprobe falló al validar: {_fp_err}"
                return result

        # Validar duración
        dur_diff = abs(result["actual_dur"] - expected_dur_secs)
        if expected_dur_secs > 0 and dur_diff > max(1.0, expected_dur_secs * 0.01):
            result["error"] = (f"duración incorrecta: esperado {expected_dur_secs:.2f}s "
                               f"obtenido {result['actual_dur']:.2f}s "
                               f"(diff {dur_diff:.2f}s)")
            return result
        # Validar samplerate
        if result["actual_rate"] != expected_rate:
            result["error"] = (f"samplerate incorrecto: esperado {expected_rate} "
                               f"obtenido {result['actual_rate']}")
            return result
        result["ok"] = True
    except Exception as e:
        result["error"] = str(e)
    if result["ok"]:
        _log.info("Validación export OK: %s  %.2fs  %d Hz  %d bytes",
                  path, result["actual_dur"], result["actual_rate"], result["actual_size"])
    else:
        _log.error("Validación export FALLÓ: %s — %s", path, result["error"])
    return result
