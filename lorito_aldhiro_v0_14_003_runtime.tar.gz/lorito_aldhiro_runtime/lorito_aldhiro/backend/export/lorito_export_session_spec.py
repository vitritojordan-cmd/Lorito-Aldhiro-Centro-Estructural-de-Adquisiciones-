from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Lógica pura de exportación extraída del God Object — verificación de integridad end-to-end y construcción del texto del spec de sesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_export_session_spec.py — GAP-056, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Primer corte real de extracción de `lorito_mw_export.py` (`export()`/
`_do_export()`, antes 725 líneas, la pieza más grande del God Object
que describe §13). Extrae las DOS piezas que ya eran, de hecho, lógica
pura (sin ningún widget de Qt involucrado, solo lectura de valores ya
calculados) pero vivían inline dentro del cierre `_do_export()`:

  1. `compute_integrity_check()` — el chequeo end-to-end
     captura→disco→export (§3g del flujo original).
  2. `build_session_spec_text()` — el texto completo del "Aldhira de
     Especificación de Lorito" (§3j del flujo original), incluida la
     lógica de 3 casos del cuentavueltas C-60/C-90 vs OTROS.

Extracción MECÁNICA, no un rediseño: cada función reproduce el texto y
la lógica EXACTOS del código que reemplaza — verificado con un test de
regresión de texto carácter a carácter
(`tests/test_export_session_spec.py`), no solo "produce algo
razonable". `lorito_mw_export.py` sigue siendo responsable de leer el
estado de los widgets Qt (`self.cassette_dur_box`, `self.tape_c60`,
etc.) y de la orquestación de hilos/señales — eso NO se extrae aquí,
exactamente como pide la Orden ("Integrar primero, verificar después,
retirar legado finalmente"): esto es la integración inicial de una
pieza acotada y de bajo riesgo, no el God Object completo resuelto de
una sesión.
"""

from dataclasses import dataclass, field
from lorito_aldhiro.backend.core.lorito_identity import SESSION_SPEC_TITLE, TAPE_COUNTER_LABEL


@dataclass
class IntegrityCheckResult:
    """§3g del flujo de exportación — resultado del chequeo end-to-end
    captura→disco→export. `ok=False` no aborta la exportación (el
    archivo ya se escribió) — es un diagnóstico que se registra."""
    ok: bool
    messages: list = field(default_factory=list)

    @property
    def summary(self) -> str:
        """Mismo formato que el `warn = " | ".join(_integ_msg)`
        original."""
        return " | ".join(self.messages)


def compute_integrity_check(frames_received: int, frames_written: int,
                            frames_exported: int) -> IntegrityCheckResult:
    """Reproduce exactamente la lógica de `_do_export()` §3g: compara
    frames recibidos de captura, escritos a disco, y exportados al
    archivo final, marcando `ok=False` si la pérdida en cualquiera de
    los dos saltos supera el 1%."""
    ok = True
    messages: list = []
    fr, fw, fe = frames_received, frames_written, frames_exported

    if fr > 0:
        loss_wr_pct = abs(fr - fw) / fr * 100.0
        if loss_wr_pct > 1.0:
            ok = False
            messages.append(f"pérdida captura→disco: {loss_wr_pct:.2f}%")
    if fw > 0 and fe > 0:
        loss_ex_pct = abs(fw - fe) / fw * 100.0
        if loss_ex_pct > 1.0:
            ok = False
            messages.append(f"pérdida disco→export: {loss_ex_pct:.2f}%")

    return IntegrityCheckResult(ok=ok, messages=messages)


def _build_tape_counter_lines(is_otros: bool, spec_data: dict) -> list:
    """§3j, bloque "CUENTAVUELTAS" — reproduce exactamente los 3 casos
    de C-60/C-90 (truncamiento en lado A, lado B, o ambos completos) y
    el caso OTROS, tal como vivían inline en `_do_export()`."""
    lines: list = []

    if not is_otros:
        _sur_a      = spec_data.get("surplus_a", 0)
        _sur_b      = spec_data.get("surplus_b", 0)
        _wrap_a     = spec_data.get("wrap_a_count", 0)
        _wrap_b     = spec_data.get("wrap_b_count", 0)
        _final_val  = spec_data.get("final_value", 0)
        _flip_done  = spec_data.get("flip_done", False)
        _phase      = spec_data.get("phase", "A")

        if not _flip_done:
            lines.append(
                f"  {TAPE_COUNTER_LABEL} - Punto de Truncamiento: ({_final_val:03d})")
        elif _flip_done and _sur_b == 0 and _phase == "B":
            lines.append(f"  {TAPE_COUNTER_LABEL}: {_sur_a:03d} (LADO A)")
            if _wrap_a > 0:
                lines.append(
                    f"  [Nota] Contador pasó por 000 en Lado A: {_wrap_a} vez/veces")
            lines.append("")
            lines.append(
                f"  {TAPE_COUNTER_LABEL} - Punto de Truncamiento: ({_final_val:03d}) EN EL LADO B")
        else:
            lines.append(f"  {TAPE_COUNTER_LABEL}: {_sur_a:03d} (LADO A)")
            lines.append("")
            lines.append(f"  {TAPE_COUNTER_LABEL}: {_sur_b:03d} (LADO B)")
            if _wrap_a > 0:
                lines.append(
                    f"  [Nota] Contador pasó por 000 en Lado A: {_wrap_a} vez/veces")
            if _wrap_b > 0:
                lines.append(
                    f"  [Nota] Contador pasó por 000 en Lado B: {_wrap_b} vez/veces")
    else:
        _wrap_n = spec_data.get("wrap_count", 0)
        _final  = spec_data.get("final_value", 0)
        lines.append(f"  {TAPE_COUNTER_LABEL} - Reinicios: {_wrap_n}")
        lines.append(f"  {TAPE_COUNTER_LABEL} - Posición Quedada: {_final:03d}")

    return lines


def build_session_spec_text(
    *,
    app_brand: str, app_version: str,
    out_filename: str, timestamp_str: str, tape_label: str, sha256: str,
    codec: str, rate: int, duration_s: float, size_bytes: int,
    total_frames: int, speed_ratio: float,
    codec_opt1: str = "", codec_opt2: str = "",
    norm_mode_label: str = "Sin normalizar",
    norm_gain_db: float = 0.0, norm_peak_db: float = 0.0,
    norm_lufs: float = float("-inf"),
    frames_received: int = 0, frames_written: int = 0, frames_exported: int = 0,
    clip_l: int = 0, clip_r: int = 0,
    is_otros: bool = True, tape_counter_data: dict | None = None,
) -> str:
    """Reproduce exactamente el texto del "Aldhira de Especificación de Lorito" (§3j de `_do_export()`) — mismas cabeceras, mismo orden,
    mismo formato de cada línea. `timestamp_str` se pasa ya formateado
    por el llamador (en vez de que esta función llame a
    `datetime.now()` internamente) para que sea determinista y
    verificable con un test de texto exacto."""
    spec_data = tape_counter_data or {}
    lines: list = []
    sep = "═" * 60

    lines.append(sep)
    lines.append(f"  {SESSION_SPEC_TITLE}")
    lines.append(f"  {app_brand} v{app_version}")
    lines.append(sep)
    lines.append("")
    lines.append("── IDENTIFICACIÓN DE SESIÓN ──────────────────────────────")
    lines.append(f"  Archivo exportado : {out_filename}")
    lines.append(f"  Fecha/hora        : {timestamp_str}")
    lines.append(f"  Tipo de cassette  : {tape_label}")
    lines.append(f"  SHA-256           : {sha256 if sha256 else 'no disponible'}")
    lines.append("")
    lines.append("── ESPECIFICACIONES DE AUDIO ─────────────────────────────")
    lines.append(f"  Codec             : {codec}")
    lines.append(f"  Sample rate       : {rate} Hz")
    lines.append(f"  Duración          : {duration_s:.2f} s  ({duration_s/60:.2f} min)")
    lines.append(f"  Tamaño            : {size_bytes} bytes  ({size_bytes//1024} KB)")
    lines.append(f"  Frames totales    : {total_frames}")
    if abs(speed_ratio - 1.0) > 0.005:
        lines.append(f"  Velocidad ratio   : ×{speed_ratio:.4f}")
    if codec_opt1:
        lines.append(f"  Opción codec 1    : {codec_opt1}")
    if codec_opt2:
        lines.append(f"  Opción codec 2    : {codec_opt2}")
    lines.append("")
    lines.append("── NORMALIZACIÓN ─────────────────────────────────────────")
    lines.append(f"  Modo              : {norm_mode_label}")
    if norm_mode_label != "Sin normalizar":
        lines.append(f"  Ganancia aplicada : {norm_gain_db:.2f} dB")
        lines.append(f"  Peak resultante   : {norm_peak_db:.2f} dBFS")
        if norm_lufs != float("-inf"):
            lines.append(f"  LUFS integrado    : {norm_lufs:.2f} LUFS")
    lines.append("")
    lines.append("── INTEGRIDAD ────────────────────────────────────────────")
    lines.append(f"  Frames recibidos  : {frames_received}")
    lines.append(f"  Frames escritos   : {frames_written}")
    lines.append(f"  Frames exportados : {frames_exported}")
    lines.append(f"  Clips detectados  : L={clip_l}  R={clip_r}")
    lines.append("")
    lines.append("── CUENTAVUELTAS ─────────────────────────────────────────")
    lines.extend(_build_tape_counter_lines(is_otros, spec_data))
    lines.append("")
    lines.append(sep)
    lines.append("  Fin del informe")
    lines.append(sep)

    return "\n".join(lines) + "\n"
