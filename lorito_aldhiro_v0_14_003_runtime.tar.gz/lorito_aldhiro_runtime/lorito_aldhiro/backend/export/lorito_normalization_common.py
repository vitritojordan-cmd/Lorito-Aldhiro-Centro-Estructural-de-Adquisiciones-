from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Símbolos comunes vigentes de la normalización (leyendas de velocidad, dB, constantes y etiquetas del catálogo).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Orden LA-GOLDEN-NORM-ARCH-017 (§8): extraído en 0.12 de los motores legados
`lorito_normalization.py` y `lorito_normalization_v21.py`, que normalizaban
la sesión entera en RAM. Esos motores salen del paquete importable y quedan
archivados en `legado/` (manifiesto SHA-256 en `legado/README_LEGADO.md`).
Aquí queda solo lo que la aplicación sigue usando, sin algoritmo duplicado:

- la leyenda de velocidad del Velocista (`_carol_speed_label`);
- la conversión dB ↔ lineal;
- las constantes del motor streaming;
- las etiquetas del catálogo v21 (presets de cinta, 2 pasadas, Soft-limit).

La normalización productiva vive en `export_streaming/`
(`lorito_normalization_streaming`, `lorito_normalizer_golden`,
`lorito_bs1770_meter`).
"""

from enum import Enum
from typing import Optional

import numpy as np

# ── Leyendas de velocidad ──────────────────────────────────────────────────
def _carol_speed_label(ratio: float) -> str:
    """
    Devuelve la leyenda de velocidad/tempo según el factor de reproducción.
    Rangos sincronizados con SpeedScrubBar.SPEED_LEGENDS (v0.21.06).

    Rango neutro:
      ~1.00              → Sin

    Rango acelerado (ratio > 1.00):
      1.01 … 1.10        → Calibrante
      1.11 … 1.40        → Verilucha
      1.41 … 1.60        → Pactorald
      1.61 … 2.00        → Pactorald Plus

    Rango desacelerado (0.50 ≤ ratio < 1.00):
      0.90 … 0.99        → Calibrante
      0.70 … 0.89        → Aguilar
      0.60 … 0.69        → Cromantina
      0.50 … 0.59        → Superprador
    """
    if abs(ratio - 1.0) < 0.005:
        return "Sin"
    if ratio > 1.0:
        if ratio >= 1.61:
            return "Pactorald Plus"
        if ratio >= 1.41:
            return "Pactorald"
        if ratio >= 1.11:
            return "Verilucha"
        return "Calibrante"   # 1.01 … 1.10
    # ratio < 1.0 — rango [0.50, 0.99]
    if ratio >= 0.90:
        return "Calibrante"   # 0.90 … 0.99
    if ratio >= 0.70:
        return "Aguilar"      # 0.70 … 0.89
    if ratio >= 0.60:
        return "Cromantina"   # 0.60 … 0.69
    return "Superprador"      # 0.50 … 0.59


# ── Conversión y constantes del motor streaming ────────────────────────────
# Tamaño de chunk de análisis: 65536 frames ≈ 1,36 s a 48 kHz.
NORM_ANALYSIS_CHUNK = 65_536
# Techo por defecto de pico de muestra (evita recorte tras la ganancia).
NORM_DEFAULT_CEILING_DBFS = -0.2
# Bloques de la normalización adaptativa (s) y su fundido (frames).
NORM_BLOCK_SECS = 10.0
NORM_BLOCK_XFADE_FRAMES = 4_096
# Análisis AUTO / 2 pasadas: bloque, umbral de silencio y factor de cresta mínimo.
NORM_ANALYSIS_BLOCK = 65536
NORM_SILENCE_THR_DBFS = -60.0
NORM_MIN_CREST_FACTOR_DB = 8.0


def _norm_db_to_linear(db: float) -> float:
    """Conversión dB → lineal. Segura ante −inf."""
    try:
        return 10.0 ** (db / 20.0)
    except Exception:
        return 0.0


def _norm_linear_to_db(lin: float) -> float:
    """Conversión lineal → dBFS. Segura ante 0."""
    if lin < 1e-12:
        return float("-inf")
    return 20.0 * float(np.log10(lin))


# ── Etiquetas del catálogo v21 ─────────────────────────────────────────────
class NormalizationModeV21(Enum):
    """Modos adicionales del catálogo de normalización (presets de cinta,
    análisis en dos pasadas y Soft-limit como etapa declarada)."""
    # Presets de cinta
    PRESET_TYPE_I      = "Preset: Type I Ferric"
    PRESET_TYPE_II     = "Preset: Type II Chrome"
    PRESET_TYPE_IV     = "Preset: Type IV Metal"
    PRESET_VOICE       = "Preset: Voice/Dictaphone"
    PRESET_FM          = "Preset: Radio FM Broadcast"
    PRESET_MICRO       = "Preset: Microcassette"
    PRESET_VHS_HIFI    = "Preset: VHS HiFi Audio"
    PRESET_REEL        = "Preset: Reel-to-Reel Transfer"
    # Análisis en dos pasadas
    TWO_PASS           = "Análisis 2-pass (profundo)"
    # Soft limiter como modo standalone (protección de exportación)
    SOFT_LIMIT_ONLY    = "Soft-limit (protección overs)"

    @classmethod
    def from_label(cls, label: str) -> Optional["NormalizationModeV21"]:
        for m in cls:
            if m.value == label:
                return m
        return None


# Etiquetas a añadir al QComboBox norm_box
NORM_ITEMS_V21 = [m.value for m in NormalizationModeV21]
