from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Registro de mensajes overlay disponibles para mostrar sobre la pantalla principal.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_overlay_registry.py — vocabulario de mensajes overlay del panel de
contómetro, en paridad con el Vitreous Panel del monolito de origen
(`mega_panel_text_registry.py`), pero limitado a lo que Lorito Aldhiro
tiene realmente: sin Vitreous Subeventos, sin logos SVG — solo leyendas
de texto sobre el contómetro (`DigitalClock`, ver `lorito_indicators.py`).

Categorías calcadas del monolito de origen — texto EXACTO idéntico al sistema VFD
terso vigente en el monolito de origen (`_painting_mixin.py`/`_overlays_mixin.py`, no
el más antiguo/descriptivo de `mega_panel_text_registry.py`).
Aclaración explícita del usuario: el calco debe ser idéntico ("OvFlow
TP", "Side A", "FnSide A", "FnTape Aldh", "Fnc No Disp", etc.),
cubriendo SOLO las funciones que Lorito Aldhiro realmente tiene — sin
Vitreous Subeventos, sin logos SVG, solo leyendas de texto sobre el
contómetro (`DigitalClock`, ver `lorito_indicators.py`).

COLOR — pedido explícito del usuario (sesión de auditoría de overlays):
"Lorito Aldhiro deberá usar el mismo color dorado en sus leyendas de
manera general". A diferencia del monolito de origen (donde cada categoría tiene su
propio color: NR en tonos por sistema, ALC en verde-agua, HX Pro en
ámbar, Monitor en verde esmeralda, etc.), en Lorito Aldhiro TODOS los
overlays de este registro comparten el mismo dorado lumínico
(`VFD_GOLD`, ver `lorito_theme.py`) — mismo criterio ya aplicado desde
GAP-018 a las leyendas fijas del contómetro (arriba/abajo/columnas
laterales). El texto sigue calcado literalmente del monolito de origen donde el monolito de origen
tiene el overlay real (ver auditoría en GAP-020/GAP-021); solo el
color se unifica.
"""

_GOLD = "rgba(255,204,85,225)"   # VFD_GOLD (#ffcc55) en formato rgba con alpha

OVERLAY_MESSAGES: dict[str, tuple[str, str]] = {
    # ── Vocabulario CALCADO del monolito de origen — texto EXACTO idéntico al de
    # `_painting_mixin.py`/`_overlays_mixin.py` (el sistema VFD terso
    # vigente en el monolito de origen, no el más antiguo/descriptivo de
    # `mega_panel_text_registry.py::MEGAPANEL_ONLY_MAP`). Aclaración
    # explícita del usuario: el calco debe ser idéntico, cubriendo SOLO
    # las funciones que Lorito Aldhiro realmente tiene. Color: dorado
    # uniforme (ver docstring del módulo), no el color propio del monolito de origen.

    # "FnSide A"/"FnSide B" — overlay ITL Flip (espera de volteo). Lorito
    # Aldhiro solo voltea A→B (sin autoreversa), así que el único caso
    # real es "FnSide A" (se está dejando el Lado A, en espera de señal).
    "FN_SIDE_A":          ("FnSide A", _GOLD),

    # "FnTape Aldh" — fin de Lado B, deteniendo la grabación.
    "FN_TAPE_ALDH":       ("FnTape Aldh", _GOLD),

    # "OvFlow TP" — cuentavueltas desbordado (cinta más larga que su
    # perfil nominal). Parpadea alternando con el contómetro, igual que
    # en el monolito de origen (ver DigitalClock.tickITLOverlayBlink).
    "OVFLOW_TP":          ("OvFlow TP", _GOLD),

    # "Side A"/"Side B" — confirmación transitoria (4 s) del lado activo,
    # al iniciar grabación (Side A) o al completarse un volteo (Side B).
    "SIDE_A":             ("Side A", _GOLD),
    "SIDE_B":             ("Side B", _GOLD),

    # "SIPActiV" — auto-pausa por silencio (el SIPA real, Sistema
    # Inteligente de Pausa Automática — no confundir con AIPLO, el
    # auditor forense renombrado en GAP-004).
    "SIPACTIV":           ("SIPActiV", _GOLD),

    # "Pause" — pausa manual (física, botón PAUSA).
    "PAUSE":              ("Pause", _GOLD),

    # "Expn Signal" — exportación en curso. Corregido en esta sesión
    # tras auditar `export_controller.py`/`_overlays_mixin.py::
    # setOverlayExpnSignal()`: el texto real del monolito de origen para el overlay
    # del contómetro durante la exportación es "Expn Signal" (parpadea
    # a 480ms — mismo ritmo que el resto de overlays de Lorito Aldhiro,
    # que ya parpadean globalmente vía `tickITLOverlayBlink`), NO
    # "Export" (ese es un overlay del monolito de origen distinto, más genérico/
    # permanente, de menor prioridad — no usado aquí).
    "EXPORT":             ("Expn Signal", _GOLD),

    # "Fnc No Disp" — función no disponible (placeholder con gracia).
    "FNC_NO_DISP":        ("Fnc No Disp", _GOLD),

    # NOTA — Scrubs Seek/Velocista/Morpher (auditoría de esta sesión,
    # corregida tras indicación explícita del usuario): el monolito de origen SÍ muestra
    # overlays reales en el contómetro para los 3 scrubs — la pasada
    # anterior (GAP-021) no los había localizado del todo bien. Texto
    # EXACTO auditado contra el código fuente real del monolito de origen:
    #   · Seek   (`scrub_seek.py::setOverlaySeekYng`):    "SeekYng"
    #     — activo durante el arrastre, se apaga exactamente al soltar.
    #   · Morpher (`mega_panel_controller.py`, rama
    #     `__CAROLAMOTION_SCANNING__`/`__CAROLAMOTION_SCANNING_REV__`):
    #     "ScCue" (adelante) / "ScRew" (atrás) — mismo ciclo de vida
    #     que Seek, termina al soltar (no se extiende durante el
    #     retorno elástico).
    #   · Velocista (`_carol_speed_label()` en
    #     `normalization_core.py` + `SPEED_ZONE_DISPLAY_NAMES` en
    #     `mega_panel_text_registry.py`): nombre codificado de zona
    #     según el ratio — CaLibrt/Aguilr/CromTn/SupRpdr/VerLcha/
    #     JayaquTe/UltrJayaqute. Único de los 3 con margen de 4s tras
    #     soltar (temporizador persistente stop()+start(), mismo
    #     mecanismo que "Fnc No Disp" — ver `showFncNoDisp()`), con
    #     reinicio del cronómetro si se vuelve a tocar el control
    #     dentro de esos 4s. Construido dinámicamente en
    #     `backend/playback/lorito_speed_zone_labels.py::
    #     speed_zone_coded_name()` (extraído del God Object en GAP-062,
    #     antes vivía como `PlaybackMixin._speed_zone_coded_name()` en
    #     `lorito_mw_playback.py`), pero los 7 nombres en sí SÍ están en
    #     este registro (texto fijo).
    "SEEK_YNG":           ("SeekYng", _GOLD),
    "SC_CUE":             ("ScCue", _GOLD),
    "SC_REW":             ("ScRew", _GOLD),
    "CaLibrt":            ("CaLibrt", _GOLD),
    "Aguilr":             ("Aguilr", _GOLD),
    "CromTn":             ("CromTn", _GOLD),
    "SupRpdr":            ("SupRpdr", _GOLD),
    "VerLcha":            ("VerLcha", _GOLD),
    "JayaquTe":           ("JayaquTe", _GOLD),
    "UltrJayaqute":       ("UltrJayaqute", _GOLD),

    # ── Reducción de ruido — PROGRAMADOS (sin motor real todavía, ver
    # GAP-010 §pendiente) ──────────────────────────────────────────────
    "NR_DOLBY_B":         ("Dolby B", _GOLD),
    "NR_DOLBY_C":         ("Dolby C", _GOLD),
    "NR_DOLBY_S":         ("Dolby S", _GOLD),
    "NR_DBX":             ("Dbx", _GOLD),
    "NR_ANRS":            ("Anrs", _GOLD),
    "NR_S_ANRS":          ("S Anrs", _GOLD),
    "NR_DNL":             ("Dnl", _GOLD),
    "NR_DNR":             ("Dnr", _GOLD),
    "HX_PRO":             ("HX Pro", _GOLD),
    "ALC":                ("ALC", _GOLD),

    "CAPTURE_MONITOR":    ("Monitor", _GOLD),

    # ── MONITOR — Stereo/Mono L/Mono R/Desactivado (§lorito_monitor_engine,
    # pedido explícito del usuario). Texto EXACTO calcado del monolito de origen —
    # auditado contra el árbol fuente real en la sesión anterior
    # (`src/studio/_ui_events_mixin.py::_MONITOR_CYCLE_OVERLAY` +
    # `showMonitorCycleOverlay()` en `_overlays_mixin.py`, §1.22 de la
    # auditoría del monolito de origen 0.37→0.38): ciclo real "Monitoring ST"/"Monitoring
    # Ls"/"Monitoring Rs"/"Monitoring OFF", 4 segundos de duración.
    # Color: dorado uniforme (el monolito de origen usa verde esmeralda propio, pero el
    # usuario pidió explícitamente un único dorado para Lorito Aldhiro).
    # Mapeo directo Stereo→ST, Mono L→Ls, Mono R→Rs.
    "MONITOR_STEREO":     ("Monitoring ST", _GOLD),
    "MONITOR_MONO_L":     ("Monitoring Ls", _GOLD),
    "MONITOR_MONO_R":     ("Monitoring Rs", _GOLD),
    "MONITOR_OFF":        ("Monitoring OFF", _GOLD),

    # ── EQ/BIAS — emulador de ecualización/bias por tipo de cinta
    # (§lorito_dsp_eq_bias, pedido explícito del usuario). Texto = la
    # fórmula/constante de tiempo real de cada tipo (IEC 60094),
    # investigada en la sesión anterior. Sin precedente en el monolito de origen
    # (confirmado en la auditoría de esta sesión — diseño propio).
    "EQ_NORMAL":          ("120µS", _GOLD),
    "EQ_CRO2":            ("70µS", _GOLD),
    "EQ_FECR":            ("70µS FeCr", _GOLD),
    "EQ_METAL":           ("70µS Metal", _GOLD),

    # ── MPX / FOCUS — DSP nuevos de la sesión anterior (§lorito_dsp_mpx,
    # §lorito_dsp_focus), mismo menú OPTAPE que HX Pro/ALC. Texto de MPX
    # auditado contra el monolito de origen (`_state_mixin.py::update_mpx_active()`):
    # overlay real "MPX FI" (Filtro MPX), 4s, solo al ACTIVAR (nunca al
    # desactivar). FOCUS sin precedente en el monolito de origen (confirmado — no
    # aparece en ningún overlay del árbol auditado): función nueva de
    # Lorito Aldhiro, sin calco. Color: dorado uniforme en ambos (el monolito de origen
    # usa verde señal propio para MPX, pero el usuario pidió
    # explícitamente un único dorado para Lorito Aldhiro).
    "MPX":                ("MPX FI", _GOLD),
    "FOCUS":              ("Focus", _GOLD),
}


def message_for(token: str) -> tuple[str, str]:
    """Devuelve (texto, color) para un token del registro. Si el token no
    existe, devuelve un mensaje de función no disponible genérico en vez
    de lanzar — nunca debe romper el arranque por un token mal escrito."""
    return OVERLAY_MESSAGES.get(token, OVERLAY_MESSAGES["FNC_NO_DISP"])


# ── Familias funcionales del LCD Display (0.11.010) ──────────────────────
# Cada categoría de overlay de `DigitalClock` pertenece a una familia; las
# celdas PREVI/TAU/COSANI/EXPORT se encienden mientras haya armado un
# overlay de su familia.
#   PREVI  — preescucha y motores DSP PREVI
#   TAU    — tiempo y transporte: contómetro, lados, volteo, seek, scrubs
#   COSANI — salud y saneamiento de la señal: niveles, overflow, pausa
#            automática por silencio, monitor, NR, EQ/BIAS
#   EXPORT — exportación, archivo y transferencia
FAMILY_OF_CATEGORY: dict[str, str] = {
    "PREVI": "PREVI",
    "TAU": "TAU", "SCRUBS": "TAU", "FN_TAPE_ALDH": "TAU", "ITL": "TAU",
    "PAUSE_PHYSICAL": "TAU", "SIDE_MSG": "TAU",
    "OVFLOW_TP": "TAU",
    "COSANI": "COSANI", "SIPA": "COSANI",
    "NR": "COSANI", "EQBIAS": "COSANI", "HX_PRO": "COSANI",
    "MONITOR": "COSANI", "CAPTURE_MONITOR": "COSANI",
    "EXPORT": "EXPORT",
}


def family_of_category(category: str) -> str | None:
    """Familia funcional (PREVI/TAU/COSANI/EXPORT) de una categoría de
    overlay; None para las que no pertenecen a ninguna (FNC_NO_DISP)."""
    return FAMILY_OF_CATEGORY.get(category)


# ── Overlays del LCD Display de Lorito (0.11.011) ─────────────────────────
from lorito_aldhiro.backend.export.lorito_lcd_overlays import LCD_OVERLAYS  # noqa: E402

LCD_OVERLAYS_BY_TOKEN: dict[str, dict] = {e["token"]: e for e in LCD_OVERLAYS}
LCD_FAMILIES = ("PREVI", "TAU", "COSANI", "EXPORT")


def lcd_overlay(token: str) -> dict | None:
    """Entrada del registro del LCD (texto, familia, categoría, duración,
    función de Lorito) o None si el token no existe."""
    return LCD_OVERLAYS_BY_TOKEN.get(token)


def lcd_overlay_text(token: str, **fields) -> str:
    """Texto del overlay; las plantillas reciben sus campos dinámicos.
    Token desconocido o campos que faltan: "Fnc No Disp" (nunca lanza)."""
    e = LCD_OVERLAYS_BY_TOKEN.get(token)
    if e is None:
        return OVERLAY_MESSAGES["FNC_NO_DISP"][0]
    if not e["template"]:
        return e["text"]
    try:
        return e["text"].format(**fields)
    except (KeyError, IndexError, ValueError):
        return OVERLAY_MESSAGES["FNC_NO_DISP"][0]


def lcd_overlays_of_family(family: str | None) -> list[dict]:
    """Overlays registrados en una familia del LCD (None = sistema)."""
    return [e for e in LCD_OVERLAYS if e["family"] == family]
