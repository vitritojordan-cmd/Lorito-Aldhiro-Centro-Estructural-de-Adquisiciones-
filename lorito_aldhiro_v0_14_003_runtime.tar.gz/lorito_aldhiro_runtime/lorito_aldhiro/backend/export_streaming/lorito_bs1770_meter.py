from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Medidor de nivel por bloques (pico de muestra, true peak, RMS y sonoridad BS.1770) para la normalización Golden.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Medidor de nivel streaming de la Orden LA-GOLDEN-NORM-ARCH-017 (§4).
Procesa bloque a bloque con estado. La memoria es O(bloque + estado de los
filtros + un escalar por bloque de gating de 400 ms); no depende de la
duración de la sesión. Mide cuatro magnitudes, cada una con su semántica:

- **Pico de muestra.** Máximo absoluto de las muestras digitales. NO es el
  pico reconstruido entre muestras.
- **True peak** (ITU-R BS.1770, Anexo 2). Sobremuestreo polifásico (×4
  por debajo de 96 kHz, ×2 hasta 192 kHz, ×1 por encima: tasa
  sobremuestreada ≥ 192 kHz) con un FIR de interpolación sinc con ventana
  de Kaiser: 32 taps por fase, β = 8, corte en 0,45·fs de entrada.
  Tolerancia documentada y medida en las pruebas (senos a 48 kHz, 9
  fases): sublectura ≤ 0,05 dB hasta 0,4·fs y ≤ 0,2 dB hasta 0,44·fs; el
  medidor nunca lee por debajo del pico de muestra. El filtro no
  es la tabla de ejemplo de 48 taps del Anexo 2: es un diseño propio más
  largo (menor sublectura) y se declara como tal en los metadatos.
- **RMS.** Media cuadrática por canal sobre todo el programa, sin
  ponderación ni ventana: agregación de potencia en todo el archivo.
- **Sonoridad integrada (LUFS / LKFS)** según ITU-R BS.1770-5 / EBU R128:
  - ponderación K: estante de alta frecuencia más paso alto (RLB), con los
    coeficientes derivados del prototipo analógico para cualquier tasa;
    a 48 kHz reproduce la tabla de la norma;
  - bloques de 400 ms con solapamiento del 75 % (paso de 100 ms);
  - z = potencia media por canal; ganancias G = 1 para L/R/C y 1,41 para
    los envolventes (canales 4 y 5 en orden L, R, C, Ls, Rs; el LFE no se
    mide);
  - puerta absoluta de −70 LKFS y puerta relativa de −10 LU sobre la
    potencia media de los bloques que pasan la absoluta;
  - L = −0,691 + 10·log10(Σ G·z̄) con la potencia media de los bloques
    que pasan ambas puertas (promedio en potencia, no en dB).

Datos no finitos: NaN/Inf se cuentan y se excluyen de la medición (se
reemplazan por 0 SOLO dentro del medidor). Quien llama decide la política;
la normalización Golden aborta con NONFINITE_INPUT. Los subnormales se
cuentan.
"""

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.signal import lfilter

ABS_GATE_LKFS = -70.0
REL_GATE_LU = -10.0
BLOCK_S = 0.400
HOP_S = 0.100
_SURROUND_GAIN = 1.41
_TINY = np.finfo(np.float64).tiny


# ═════════════════════════════════════════════════════════════════════════════
#  Ponderación K
# ═════════════════════════════════════════════════════════════════════════════
def k_weighting_coeffs(fs: float):
    """(b1, a1, b2, a2) de las dos etapas de la ponderación K para la tasa
    `fs`: estante (~+4 dB por encima de ~1,5 kHz) y paso alto RLB (~38 Hz).
    Se derivan del prototipo analógico de BS.1770 por transformación
    bilineal; a 48 kHz coinciden con la tabla de la norma."""
    f0, G, Q = 1681.974450955533, 3.999843853973347, 0.7071752369554196
    K = math.tan(math.pi * f0 / fs)
    Vh = 10.0 ** (G / 20.0)
    Vb = Vh ** 0.4996667741545416
    a0 = 1.0 + K / Q + K * K
    b1 = np.array([(Vh + Vb * K / Q + K * K) / a0,
                   2.0 * (K * K - Vh) / a0,
                   (Vh - Vb * K / Q + K * K) / a0])
    a1 = np.array([1.0, 2.0 * (K * K - 1.0) / a0, (1.0 - K / Q + K * K) / a0])
    f0, Q = 38.13547087602444, 0.5003270373238773
    K = math.tan(math.pi * f0 / fs)
    d = 1.0 + K / Q + K * K
    b2 = np.array([1.0, -2.0, 1.0])
    a2 = np.array([1.0, 2.0 * (K * K - 1.0) / d, (1.0 - K / Q + K * K) / d])
    return b1, a1, b2, a2


def channel_weights(n_channels: int) -> np.ndarray:
    """G por canal (BS.1770): 1,0 salvo los envolventes de 5.x (índices 3 y
    4 en orden L, R, C, Ls, Rs), que pesan 1,41. Para 6 canales (5.1, orden
    L R C LFE Ls Rs) el LFE (índice 3) pesa 0 y Ls/Rs (4, 5) 1,41."""
    w = np.ones(n_channels, dtype=np.float64)
    if n_channels == 5:
        w[3:5] = _SURROUND_GAIN
    elif n_channels == 6:
        w[3] = 0.0
        w[4:6] = _SURROUND_GAIN
    return w


# ═════════════════════════════════════════════════════════════════════════════
#  True peak
# ═════════════════════════════════════════════════════════════════════════════
def true_peak_oversampling(fs: float) -> int:
    """Factor que lleva la tasa sobremuestreada a ≥ 192 kHz (Anexo 2)."""
    if fs < 96000:
        return 4
    if fs < 192000:
        return 2
    return 1


def interpolation_phases(os_factor: int, taps_per_phase: int = 32,
                         beta: float = 8.0, cutoff: float = 0.45) -> np.ndarray:
    """Filtro polifásico (os × taps): sinc con ventana de Kaiser, corte en
    `cutoff`·fs de entrada. Cada fase tiene ganancia DC 1."""
    n = os_factor * taps_per_phase
    m = np.arange(n) - (n - 1) / 2.0
    h = (2.0 * cutoff / os_factor) * np.sinc(2.0 * cutoff * m / os_factor) * np.kaiser(n, beta)
    phases = np.stack([h[p::os_factor] for p in range(os_factor)])
    phases /= phases.sum(axis=1, keepdims=True)
    return phases


# ═════════════════════════════════════════════════════════════════════════════
#  Resultado
# ═════════════════════════════════════════════════════════════════════════════
def lin_to_db(x: float) -> float:
    return 20.0 * math.log10(x) if x > 0.0 else float("-inf")


@dataclass(frozen=True)
class LevelReport:
    frames: int
    channels: int
    rate: int
    sample_peak: float                # lineal, máximo sobre canales
    true_peak: float                  # lineal (dBTP = 20·log10)
    true_peak_oversampling: int
    rms: float                        # lineal, canal con más potencia
    rms_per_channel: tuple
    integrated_lufs: float            # −inf si no hay bloques válidos
    gated_blocks: int
    total_blocks: int
    nonfinite: int
    subnormal: int
    clipped_samples: int              # |x| ≥ 1,0 (a escala completa)
    standard: str = "ITU-R BS.1770-5 / EBU R128 (puertas −70 LKFS y −10 LU)"
    tp_filter: str = field(default="")

    @property
    def sample_peak_dbfs(self) -> float:
        return lin_to_db(self.sample_peak)

    @property
    def true_peak_dbtp(self) -> float:
        return lin_to_db(self.true_peak)

    @property
    def rms_dbfs(self) -> float:
        return lin_to_db(self.rms)

    @property
    def silent(self) -> bool:
        return self.sample_peak == 0.0

    def as_dict(self) -> dict:
        def r(x):
            return None if (isinstance(x, float) and not math.isfinite(x)) else round(x, 4)
        return {
            "frames": self.frames, "channels": self.channels, "rate": self.rate,
            "sample_peak_dbfs": r(self.sample_peak_dbfs),
            "true_peak_dbtp": r(self.true_peak_dbtp),
            "true_peak_oversampling": self.true_peak_oversampling,
            "rms_dbfs": r(self.rms_dbfs),
            "integrated_lufs": r(self.integrated_lufs),
            "gated_blocks": self.gated_blocks, "total_blocks": self.total_blocks,
            "nonfinite": self.nonfinite, "subnormal": self.subnormal,
            "clipped_samples": self.clipped_samples,
            "standard": self.standard, "tp_filter": self.tp_filter,
        }


# ═════════════════════════════════════════════════════════════════════════════
#  Medidor
# ═════════════════════════════════════════════════════════════════════════════
class LevelMeter:
    """Medidor con estado: `process(block)` con bloques (frames × canales)
    de cualquier tamaño y `report()` al final. El resultado no depende de
    cómo se trocea la señal: los filtros y la ventana de gating llevan el
    estado entre bloques."""

    def __init__(self, rate: int, channels: int, gain: float = 1.0):
        self.rate = int(rate)
        self.channels = int(channels)
        self.gain = float(gain)       # medir x·gain sin materializarlo
        self._b1, self._a1, self._b2, self._a2 = k_weighting_coeffs(self.rate)
        self._z1 = [np.zeros(2) for _ in range(self.channels)]
        self._z2 = [np.zeros(2) for _ in range(self.channels)]
        self._w = channel_weights(self.channels)
        self._os = true_peak_oversampling(self.rate)
        self._phases = interpolation_phases(self._os)
        self._tpz = [[np.zeros(self._phases.shape[1] - 1) for _ in range(self._os)]
                     for _ in range(self.channels)]
        self._block = max(1, int(round(BLOCK_S * self.rate)))
        self._hop = max(1, int(round(HOP_S * self.rate)))
        # Potencia ponderada por subbloque de 100 ms: un bloque de 400 ms es
        # la suma de 4 subbloques consecutivos (exacto si 400 ms = 4·100 ms).
        self._sub_acc = np.zeros(self.channels)
        self._sub_fill = 0
        self._subs: list = []           # últimos 4 subbloques (potencia por canal)
        self._blocks_z: list = []       # z por canal de cada bloque de 400 ms
        self._frames = 0
        self._peak = 0.0
        self._tp = 0.0
        self._sumsq = np.zeros(self.channels)
        self._nonfinite = 0
        self._subnormal = 0
        self._clipped = 0

    SUBBLOCK = 16384      # acota los temporales: memoria O(sub-bloque)

    def process(self, block: np.ndarray) -> None:
        b = np.asarray(block)
        if b.ndim == 1:
            b = b[:, None]
        if b.shape[0] == 0:
            return
        if b.shape[1] != self.channels:
            raise ValueError(f"canales {b.shape[1]} ≠ {self.channels}")
        for i in range(0, b.shape[0], self.SUBBLOCK):
            self._process(b[i:i + self.SUBBLOCK])

    def _process(self, block: np.ndarray) -> None:
        x = np.asarray(block, dtype=np.float64)
        if self.gain != 1.0:
            x = x * self.gain
        bad = ~np.isfinite(x)
        nb = int(bad.sum())
        if nb:
            self._nonfinite += nb
            x = np.where(bad, 0.0, x)
        ax = np.abs(x)
        self._subnormal += int(((ax > 0) & (ax < _TINY)).sum())
        self._clipped += int((ax >= 1.0).sum())
        pk = float(ax.max())
        if pk > self._peak:
            self._peak = pk
        self._sumsq += np.einsum("ij,ij->j", x, x)
        self._frames += x.shape[0]
        self._true_peak(x)
        self._loudness(x)

    def _true_peak(self, x: np.ndarray) -> None:
        tp = self._tp
        for c in range(self.channels):
            col = x[:, c]
            for p in range(self._os):
                y, self._tpz[c][p] = lfilter(self._phases[p], 1.0, col, zi=self._tpz[c][p])
                m = float(np.abs(y).max())
                if m > tp:
                    tp = m
        self._tp = tp

    def _loudness(self, x: np.ndarray) -> None:
        n = x.shape[0]
        ksq = np.empty((n, self.channels))
        for c in range(self.channels):
            y, self._z1[c] = lfilter(self._b1, self._a1, x[:, c], zi=self._z1[c])
            y, self._z2[c] = lfilter(self._b2, self._a2, y, zi=self._z2[c])
            ksq[:, c] = y * y
        i = 0
        while i < n:
            take = min(self._hop - self._sub_fill, n - i)
            self._sub_acc += ksq[i:i + take].sum(axis=0)
            self._sub_fill += take
            i += take
            if self._sub_fill == self._hop:
                self._subs.append(self._sub_acc.copy())
                self._sub_acc[:] = 0.0
                self._sub_fill = 0
                if len(self._subs) > 4:
                    self._subs.pop(0)
                if len(self._subs) == 4:
                    self._blocks_z.append(sum(self._subs) / (4 * self._hop))

    def _integrated(self):
        if not self._blocks_z:
            return float("-inf"), 0, 0
        z = np.array(self._blocks_z)                       # bloques × canales
        power = z @ self._w
        with np.errstate(divide="ignore"):
            lj = -0.691 + 10.0 * np.log10(np.maximum(power, 1e-300))
        abs_ok = lj > ABS_GATE_LKFS
        if not abs_ok.any():
            return float("-inf"), 0, len(z)
        rel = -0.691 + 10.0 * math.log10(float(power[abs_ok].mean())) + REL_GATE_LU
        ok = abs_ok & (lj > rel)
        if not ok.any():
            return float("-inf"), 0, len(z)
        return (-0.691 + 10.0 * math.log10(float(power[ok].mean())),
                int(ok.sum()), len(z))

    def report(self) -> LevelReport:
        lufs, gated, total = self._integrated()
        rms_ch = tuple(float(math.sqrt(s / self._frames)) if self._frames else 0.0
                       for s in self._sumsq)
        return LevelReport(
            frames=self._frames, channels=self.channels, rate=self.rate,
            sample_peak=self._peak, true_peak=max(self._tp, self._peak),
            true_peak_oversampling=self._os,
            rms=max(rms_ch) if rms_ch else 0.0, rms_per_channel=rms_ch,
            integrated_lufs=lufs, gated_blocks=gated, total_blocks=total,
            nonfinite=self._nonfinite, subnormal=self._subnormal,
            clipped_samples=self._clipped,
            tp_filter=f"polifásico ×{self._os}, {self._phases.shape[1]} taps/fase, "
                      f"Kaiser β=8, corte 0,45·fs",
        )


def measure_blocks(blocks, rate: int, channels: int, gain: float = 1.0) -> LevelReport:
    m = LevelMeter(rate, channels, gain)
    for b in blocks:
        m.process(b)
    return m.report()
