from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Contrato tipado de la normalización Golden: objetivo, techo, ganancia máxima, silencio, errores y verificación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Normalización Golden — Orden LA-GOLDEN-NORM-ARCH-017 (§3–§7).

Flujo: fuente RAW/DERIVED → pase 1 de medición por bloques (`LevelMeter`)
→ ganancia estática → validación de límites (ganancia máxima, techo de
pico de muestra, true peak) → pase 2 de escritura por streaming
(`ExportService`) → medición de la salida publicada → informe
antes/después y estado final.

Reglas:

- **Normalizar no es limitar.** Este módulo calcula UNA ganancia estática
  enlazada para todos los canales (se conserva el balance). Nunca añade
  limitador, compresor ni saturación. Si el techo se excede, se baja la
  ganancia y se informa que el objetivo no se alcanzó. El limitador solo
  existe como etapa separada y declarada, cuando la usuaria lo elige.
- **Semántica explícita.** SAMPLE_PEAK (pico de muestra), TRUE_PEAK (dBTP,
  BS.1770 Anexo 2), RMS (potencia del canal más fuerte) y LUFS (BS.1770-5 /
  EBU R128, con puertas). El modo se declara en la solicitud y en los
  metadatos.
- **Silencio.** Una fuente digitalmente muda (pico 0), o sin sonoridad
  medible para el modo LUFS, no se amplifica. La ganancia queda en 0 dB
  y se informa `SILENT_SOURCE`.
- **Ganancia máxima.** Por defecto +24 dB. Si el objetivo pide más, se
  aplica el máximo y se informa `TARGET_UNREACHABLE`.
- **NaN/Inf.** Abortan con `NONFINITE_INPUT`: nunca se publica una salida
  normalizada de una fuente con valores no finitos.
- **Configuración inmutable.** La solicitud es `frozen`; un cambio de la
  usuaria crea una tarea nueva.
"""

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional

import numpy as np

from lorito_aldhiro.backend.export_streaming.lorito_bs1770_meter import (
    LevelMeter, LevelReport, lin_to_db,
)

ENGINE_ID = "lorito.normalizer.golden/1"
DEFAULT_MAX_GAIN_DB = 24.0
DEFAULT_SAMPLE_CEILING_DBFS = -0.2
DEFAULT_TRUE_PEAK_CEILING_DBTP = -1.0      # EBU R128: máximo −1 dBTP
TARGET_TOLERANCE_DB = 0.05


class TargetMode(str, Enum):
    NONE = "NONE"                  # modos de catálogo con fórmula propia (ver ExportService)
    SAMPLE_PEAK = "SAMPLE_PEAK"
    TRUE_PEAK = "TRUE_PEAK"
    RMS = "RMS"
    LUFS = "LUFS"


class TruePeakPolicy(str, Enum):
    REDUCE_GAIN = "REDUCE_GAIN"    # dBTP > techo → se baja la ganancia
    REPORT_ONLY = "REPORT_ONLY"    # se mide y se informa, sin tocar la ganancia


class ChannelLinking(str, Enum):
    LINKED = "LINKED"              # una ganancia para todos los canales (balance intacto)


class NormErrorCode(str, Enum):
    SOURCE_EMPTY = "SOURCE_EMPTY"
    INVALID_FORMAT = "INVALID_FORMAT"
    INVALID_REQUEST = "INVALID_REQUEST"
    NONFINITE_INPUT = "NONFINITE_INPUT"
    TARGET_UNREACHABLE = "TARGET_UNREACHABLE"
    TRUE_PEAK_LIMIT = "TRUE_PEAK_LIMIT"
    IO_ERROR = "IO_ERROR"
    CANCELLED = "CANCELLED"
    ENCODER_ERROR = "ENCODER_ERROR"
    INTEGRITY_FAILURE = "INTEGRITY_FAILURE"


class NormState(str, Enum):
    ARCHIVAL_SAFE = "ARCHIVAL_SAFE"    # integridad, frames, metadatos y política OK
    DEGRADED = "DEGRADED"              # utilizable, con advertencias
    INVALID = "INVALID"                # truncado, corrupto o validación fallida


class NormalizationError(Exception):
    def __init__(self, code: NormErrorCode, detail: str = ""):
        super().__init__(f"{code.value}: {detail}")
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class NormalizationRequest:
    target_mode: TargetMode
    target_value: float = 0.0                       # dBFS, dBTP, dBFS RMS o LUFS
    sample_ceiling_dbfs: float = DEFAULT_SAMPLE_CEILING_DBFS
    true_peak_ceiling_dbtp: float = DEFAULT_TRUE_PEAK_CEILING_DBTP
    max_gain_db: float = DEFAULT_MAX_GAIN_DB
    channel_linking: ChannelLinking = ChannelLinking.LINKED
    true_peak_policy: TruePeakPolicy = TruePeakPolicy.REPORT_ONLY

    def validate(self) -> None:
        if not isinstance(self.target_mode, TargetMode):
            raise NormalizationError(NormErrorCode.INVALID_REQUEST, f"modo {self.target_mode!r}")
        for name in ("target_value", "sample_ceiling_dbfs", "true_peak_ceiling_dbtp", "max_gain_db"):
            v = getattr(self, name)
            if not (isinstance(v, (int, float)) and math.isfinite(v)):
                raise NormalizationError(NormErrorCode.INVALID_REQUEST, f"{name}={v!r}")
        if self.sample_ceiling_dbfs > 0.0 or self.true_peak_ceiling_dbtp > 0.0:
            raise NormalizationError(NormErrorCode.INVALID_REQUEST, "techo > 0 dB")
        if self.max_gain_db < 0.0:
            raise NormalizationError(NormErrorCode.INVALID_REQUEST, "ganancia máxima < 0 dB")
        if self.channel_linking != ChannelLinking.LINKED:
            raise NormalizationError(NormErrorCode.INVALID_REQUEST,
                                     "solo se admite ganancia enlazada (LINKED)")

    def as_dict(self) -> dict:
        return {"target_mode": self.target_mode.value, "target_value": self.target_value,
                "sample_ceiling_dbfs": self.sample_ceiling_dbfs,
                "true_peak_ceiling_dbtp": self.true_peak_ceiling_dbtp,
                "max_gain_db": self.max_gain_db,
                "channel_linking": self.channel_linking.value,
                "true_peak_policy": self.true_peak_policy.value}


@dataclass
class GainDecision:
    gain: float
    requested_gain: float
    target_achieved: bool
    warnings: list = field(default_factory=list)

    @property
    def gain_db(self) -> float:
        return lin_to_db(self.gain)


def measure_source(blocks: Callable, rate: int, channels: int, gain: float = 1.0,
                   cancel_event=None) -> LevelReport:
    """Pase de medición sobre `blocks()` (iterable de arrays frames × canales)."""
    m = LevelMeter(rate, channels, gain)
    for b in blocks():
        if cancel_event is not None and cancel_event.is_set():
            raise NormalizationError(NormErrorCode.CANCELLED, "medición cancelada")
        m.process(b)
    return m.report()


def check_source(before: LevelReport) -> None:
    if before.frames == 0:
        raise NormalizationError(NormErrorCode.SOURCE_EMPTY, "fuente sin frames")
    if before.nonfinite:
        raise NormalizationError(NormErrorCode.NONFINITE_INPUT,
                                 f"{before.nonfinite} muestras NaN/Inf en la fuente")


def requested_gain(req: NormalizationRequest, before: LevelReport) -> Optional[float]:
    """Ganancia que pide el objetivo. None si no hay nada que medir
    (fuente muda o sin sonoridad medible)."""
    m = req.target_mode
    if m == TargetMode.SAMPLE_PEAK:
        ref = before.sample_peak
    elif m == TargetMode.TRUE_PEAK:
        ref = before.true_peak
    elif m == TargetMode.RMS:
        ref = before.rms
    elif m == TargetMode.LUFS:
        if not math.isfinite(before.integrated_lufs):
            return None
        return 10.0 ** ((req.target_value - before.integrated_lufs) / 20.0)
    else:
        raise NormalizationError(NormErrorCode.INVALID_REQUEST, f"modo {m}")
    if ref <= 0.0:
        return None
    return 10.0 ** (req.target_value / 20.0) / ref


def decide_gain(req: NormalizationRequest, before: LevelReport,
                wanted: Optional[float] = None) -> GainDecision:
    """Ganancia estática final. `wanted`: la que propone un modo de
    catálogo con fórmula propia (Preservativa, Crest Guard…). Si es None se
    usa la del objetivo de `req`. Aplica, en orden, la ganancia máxima, el
    techo de pico de muestra y la política de true peak."""
    req.validate()
    check_source(before)
    if wanted is None and req.target_mode != TargetMode.NONE:
        wanted = requested_gain(req, before)
    if before.silent or wanted is None:
        return GainDecision(1.0, 1.0, False,
                            ["SILENT_SOURCE: fuente muda o sin sonoridad medible; sin ganancia"])
    warnings = []
    g = wanted
    gmax = 10.0 ** (req.max_gain_db / 20.0)
    if g > gmax:
        warnings.append(f"{NormErrorCode.TARGET_UNREACHABLE.value}: pedía {lin_to_db(g):+.2f} dB, "
                        f"máximo {req.max_gain_db:+.2f} dB")
        g = gmax
    sc = 10.0 ** (req.sample_ceiling_dbfs / 20.0)
    if before.sample_peak * g > sc * (1 + 1e-12):
        g = sc / before.sample_peak
        warnings.append(f"{NormErrorCode.TARGET_UNREACHABLE.value}: techo de pico de muestra "
                        f"{req.sample_ceiling_dbfs:+.2f} dBFS")
    tpc = 10.0 ** (req.true_peak_ceiling_dbtp / 20.0)
    if before.true_peak * g > tpc * (1 + 1e-12):
        if req.true_peak_policy == TruePeakPolicy.REDUCE_GAIN:
            g = tpc / before.true_peak
            warnings.append(f"{NormErrorCode.TRUE_PEAK_LIMIT.value}: ganancia reducida al techo "
                            f"{req.true_peak_ceiling_dbtp:+.2f} dBTP")
        else:
            warnings.append(f"{NormErrorCode.TRUE_PEAK_LIMIT.value}: true peak previsto "
                            f"{lin_to_db(before.true_peak * g):+.2f} dBTP > "
                            f"{req.true_peak_ceiling_dbtp:+.2f} dBTP (solo informado)")
    achieved = abs(lin_to_db(g) - lin_to_db(wanted)) <= TARGET_TOLERANCE_DB
    return GainDecision(g, wanted, achieved, warnings)


def predict_after(before: LevelReport, gain: float) -> dict:
    """Medidas de la salida con ganancia escalar: todas escalan exactamente
    (el medidor es lineal en amplitud)."""
    gd = lin_to_db(gain)

    def sh(x):
        return None if not math.isfinite(x) else round(x + gd, 4)
    return {"sample_peak_dbfs": sh(before.sample_peak_dbfs),
            "true_peak_dbtp": sh(before.true_peak_dbtp),
            "rms_dbfs": sh(before.rms_dbfs),
            "integrated_lufs": sh(before.integrated_lufs)}


def verify_after(after: Optional[LevelReport], predicted: Optional[dict], lossless: bool,
                 scalar: bool) -> tuple:
    """(ok, avisos) comparando la salida publicada con lo previsto. Con
    códec sin pérdida y ganancia escalar, el pico de muestra debe coincidir
    (±0,05 dB, cuantificación) y no puede haber recorte. Con pérdida solo
    se informa."""
    warns = []
    if after is None:
        return False, ["post-medición no disponible (códec no legible)"]
    if after.nonfinite:
        return False, [f"{NormErrorCode.INTEGRITY_FAILURE.value}: salida con NaN/Inf"]
    if after.clipped_samples:
        warns.append(f"CLIPPING: {after.clipped_samples} muestras a escala completa en la salida")
    if predicted and lossless and scalar:
        p = predicted.get("sample_peak_dbfs")
        if p is not None and abs(after.sample_peak_dbfs - p) > TARGET_TOLERANCE_DB:
            warns.append(f"{NormErrorCode.INTEGRITY_FAILURE.value}: pico medido "
                         f"{after.sample_peak_dbfs:+.3f} dBFS ≠ previsto {p:+.3f} dBFS")
            return False, warns
    return True, warns


def final_state(ok: bool, warnings: list) -> NormState:
    if not ok:
        return NormState.INVALID
    return NormState.DEGRADED if warnings else NormState.ARCHIVAL_SAFE


def file_blocks(path: str, block_frames: int = 65536):
    """Lectura por bloques de un archivo publicado (para la post-medición)."""
    import soundfile as sf

    def _gen():
        with sf.SoundFile(path, "r") as f:
            while True:
                d = f.read(block_frames, dtype="float64", always_2d=True)
                if not len(d):
                    break
                yield d
    return _gen


def as_array_blocks(segment_blocks):
    """Adapta `SegmentProvider.iter_blocks` (objetos Block) a arrays."""
    def _gen():
        for blk in segment_blocks():
            yield blk.data
    return _gen
