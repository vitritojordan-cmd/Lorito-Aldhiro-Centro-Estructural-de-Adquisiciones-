from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Núcleo DSP compartido de reducción de ruido (Dolby B/C/S, dbx, etc.).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_nr_dsp_core.py — primitivas DSP compartidas por los sistemas de
reducción de ruido de Lorito Aldhiro (§GAP-011): filtro biquad shelving
(pre/de-énfasis de doble extremo — Dolby B/C/S, ANRS, DBX, S-ANRS),
paso-bajo deslizante controlado por envolvente (DNL), y compander RMS
2:1/1:2 con detector de pico de seguridad (DBX, S-ANRS).

Física y coeficientes verificados contra implementaciones reales
auditadas en el monolito de origen (`nr.*`, ver GAP-011 §2) — mismas fórmulas RBJ
Audio EQ Cookbook para los biquads, mismo modelo de compander
feed-forward con envolvente cuadrática.

Orden SERVO-016 §4 "Rendimiento" (medido en 0.11.014): el bucle Python
por muestra costaba 0,31–0,71 del tiempo real (Dolby B 0,31; dbx 0,41;
DNR 0,71; HX Pro 0,67) y el presupuesto DSP de la captura es 0,5: DNR o
HX Pro solos apagaban el DERIVED en plena captura. Los bucles por muestra
son ahora kernels Numba (`njit`) con su REFERENCIA en Python puro
(`*_py`, misma aritmética en float64), comparadas en
`tests/test_previ_nr_golden.py`. Sin Numba, `njit` deja la referencia tal
cual (más lenta, mismo resultado).
"""

import math
from typing import Optional

import numpy as np

from lorito_aldhiro.backend.dsp.lorito_dsp_numba_utils import njit


def _biquad_block_py(xf, out, b0, b1, b2, a1, a2, w1, w2):
    """DF-II T por canal; `w1`/`w2` (estado por canal) se actualizan."""
    n_samples, n_ch = xf.shape
    for ch in range(n_ch):
        s1 = w1[ch]
        s2 = w2[ch]
        for n in range(n_samples):
            xn = xf[n, ch]
            yn = b0 * xn + s1
            s1 = b1 * xn - a1 * yn + s2
            s2 = b2 * xn - a2 * yn
            out[n, ch] = yn
        w1[ch] = s1
        w2[ch] = s2


def _compander_block_py(out, env_sq_a, env_peak_sq_a, thr_lin, att, rel,
                        peak_att, peak_rel, gain_exp):
    """Compander RMS feed-forward in situ; envolventes por canal."""
    n_samples, n_ch = out.shape
    for ch in range(n_ch):
        env_sq = env_sq_a[ch]
        env_peak_sq = env_peak_sq_a[ch]
        for n in range(n_samples):
            xn = out[n, ch]
            xn_sq = xn * xn
            if xn_sq > env_sq:
                env_sq = att * env_sq + (1.0 - att) * xn_sq
            else:
                env_sq = rel * env_sq + (1.0 - rel) * xn_sq
            if xn_sq > env_peak_sq:
                env_peak_sq = peak_att * env_peak_sq + (1.0 - peak_att) * xn_sq
            else:
                env_peak_sq = peak_rel * env_peak_sq + (1.0 - peak_rel) * xn_sq
            env_use_sq = env_sq if env_sq > env_peak_sq else env_peak_sq
            rms = math.sqrt(env_use_sq) if env_use_sq > 1e-14 else 1e-7
            gain = (rms / thr_lin) ** gain_exp
            if gain < 1e-3:
                gain = 1e-3
            elif gain > 32.0:
                gain = 32.0
            out[n, ch] = xn * gain
        env_sq_a[ch] = env_sq
        env_peak_sq_a[ch] = env_peak_sq


def _one_pole_py(col, a, z):
    """Paso-bajo de un polo in situ; devuelve el estado final."""
    for n in range(col.shape[0]):
        z = a * z + (1.0 - a) * col[n]
        col[n] = z
    return z


_biquad_block = njit(cache=True)(_biquad_block_py)
_compander_block = njit(cache=True)(_compander_block_py)
_one_pole = njit(cache=True)(_one_pole_py)


# ═══════════════════════════════════════════════════════════════════════
#  BIQUAD — Forma Directa II Transpuesta, estado persistente entre bloques
# ═══════════════════════════════════════════════════════════════════════

class Biquad:
    """Biquad 2º orden con estado IIR persistente. `process()` puede
    llamarse repetidamente con bloques sucesivos del mismo stream sin
    discontinuidades — el estado (`_w1`/`_w2`) se conserva entre llamadas."""

    __slots__ = ("b0", "b1", "b2", "a1", "a2", "_w1", "_w2")

    def __init__(self, b0: float, b1: float, b2: float,
                 a1: float, a2: float, channels: int = 2):
        self.b0, self.b1, self.b2 = b0, b1, b2
        self.a1, self.a2 = a1, a2
        self._w1 = np.zeros(channels, dtype=np.float64)
        self._w2 = np.zeros(channels, dtype=np.float64)

    def process(self, x: np.ndarray) -> np.ndarray:
        mono = x.ndim == 1
        if mono:
            x = x[:, np.newaxis]
        n_samples, n_ch = x.shape
        if self._w1.shape[0] != n_ch:
            self._w1 = np.zeros(n_ch, dtype=np.float64)
            self._w2 = np.zeros(n_ch, dtype=np.float64)

        out = np.empty((n_samples, n_ch), dtype=np.float64)
        xf = np.ascontiguousarray(x, dtype=np.float64)
        _biquad_block(xf, out, self.b0, self.b1, self.b2, self.a1, self.a2,
                      self._w1, self._w2)

        out = out.astype(np.float32)
        return out[:, 0] if mono else out

    def reset(self) -> None:
        self._w1[:] = 0.0
        self._w2[:] = 0.0


def shelving_high(fc: float, gain_db: float, fs: float, channels: int = 2) -> Biquad:
    """Shelving de alta frecuencia (RBJ Audio EQ Cookbook), Q=0.707."""
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * math.pi * fc / fs
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / 2.0 * math.sqrt((A + 1.0 / A) * (1.0 / 0.707 - 1.0) + 2.0)
    b0 = A * ((A + 1.0) + (A - 1.0) * cos_w0 + 2.0 * math.sqrt(A) * alpha)
    b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cos_w0)
    b2 = A * ((A + 1.0) + (A - 1.0) * cos_w0 - 2.0 * math.sqrt(A) * alpha)
    a0 = (A + 1.0) - (A - 1.0) * cos_w0 + 2.0 * math.sqrt(A) * alpha
    a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cos_w0)
    a2 = (A + 1.0) - (A - 1.0) * cos_w0 - 2.0 * math.sqrt(A) * alpha
    return Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, channels)


def shelving_low(fc: float, gain_db: float, fs: float, channels: int = 2) -> Biquad:
    """Shelving de baja frecuencia (RBJ Audio EQ Cookbook), Q=0.707."""
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * math.pi * fc / fs
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / 2.0 * math.sqrt((A + 1.0 / A) * (1.0 / 0.707 - 1.0) + 2.0)
    b0 = A * ((A + 1.0) - (A - 1.0) * cos_w0 + 2.0 * math.sqrt(A) * alpha)
    b1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * cos_w0)
    b2 = A * ((A + 1.0) - (A - 1.0) * cos_w0 - 2.0 * math.sqrt(A) * alpha)
    a0 = (A + 1.0) + (A - 1.0) * cos_w0 + 2.0 * math.sqrt(A) * alpha
    a1 = -2.0 * ((A - 1.0) + (A + 1.0) * cos_w0)
    a2 = (A + 1.0) + (A - 1.0) * cos_w0 - 2.0 * math.sqrt(A) * alpha
    return Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, channels)


def lowpass(fc: float, fs: float, channels: int = 2, q: float = 0.707) -> Biquad:
    """Paso-bajo de 2º orden (RBJ Audio EQ Cookbook) — usado para el
    divisor de banda baja de `TwoBandAdaptiveGate` (DNR)."""
    w0 = 2.0 * math.pi * fc / fs
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2.0 * q)
    b0 = (1.0 - cos_w0) / 2.0
    b1 = 1.0 - cos_w0
    b2 = (1.0 - cos_w0) / 2.0
    a0 = 1.0 + alpha
    a1 = -2.0 * cos_w0
    a2 = 1.0 - alpha
    return Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, channels)


def highpass(fc: float, fs: float, channels: int = 2, q: float = 0.707) -> Biquad:
    """Paso-alto de 2º orden (RBJ Audio EQ Cookbook) — usado por el
    detector de contenido HF de HX Pro."""
    w0 = 2.0 * math.pi * fc / fs
    cos_w0, sin_w0 = math.cos(w0), math.sin(w0)
    alpha = sin_w0 / (2.0 * q)
    b0 = (1.0 + cos_w0) / 2.0
    b1 = -(1.0 + cos_w0)
    b2 = (1.0 + cos_w0) / 2.0
    a0 = 1.0 + alpha
    a1 = -2.0 * cos_w0
    a2 = 1.0 - alpha
    return Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, channels)


# ═══════════════════════════════════════════════════════════════════════
#  COMPANDER RMS — DBX / S-ANRS (relación de compresión fija, feed-forward)
# ═══════════════════════════════════════════════════════════════════════

class RmsCompander:
    """
    Compresor/expansor RMS de relación fija, con envolvente cuadrática
    persistente entre bloques y un detector de pico de seguridad
    independiente (ataque más rápido) para evitar overshoot en
    transitorios — mismo modelo que el compander real de dbx/S-ANRS.

    `ratio`: 2.0 → compresión 2:1 (ENCODE) / expansión 1:2 (DECODE,
    usar `ratio=0.5` — la ley de ganancia es simétrica e inversa).
    """

    def __init__(self, sample_rate: float, channels: int,
                 threshold_db: float, ratio: float,
                 attack_ms: float, release_ms: float,
                 peak_attack_ms: float = 1.0, peak_release_ms: float = 40.0):
        self.threshold_lin = 10.0 ** (threshold_db / 20.0)
        self.threshold_sq = self.threshold_lin ** 2
        # Ley de ganancia correcta de un compander feed-forward
        # referenciado (no la fórmula sin normalizar de la primera
        # versión, que producía EXPANSIÓN en vez de compresión para
        # señales lejos del umbral — ver GAP-011 §3, hallazgo real de
        # los tests): gain = (rms/ref)^(1/ratio - 1). ratio=2.0 → 2:1
        # (ENCODE); ratio=0.5 → 1:2, la expansión inversa exacta (DECODE).
        self.gain_exp = (1.0 / ratio) - 1.0
        self.att = math.exp(-1.0 / max(1, int(sample_rate * attack_ms / 1000.0)))
        self.rel = math.exp(-1.0 / max(1, int(sample_rate * release_ms / 1000.0)))
        self.peak_att = math.exp(-1.0 / max(1, int(sample_rate * peak_attack_ms / 1000.0)))
        self.peak_rel = math.exp(-1.0 / max(1, int(sample_rate * peak_release_ms / 1000.0)))
        self.env_sq = np.full(channels, self.threshold_sq, dtype=np.float64)
        self.env_peak_sq = np.full(channels, self.threshold_sq, dtype=np.float64)

    def process(self, x: np.ndarray) -> np.ndarray:
        mono = x.ndim == 1
        if mono:
            x = x[:, np.newaxis]
        out = x.astype(np.float64).copy()
        n_samples, n_ch = out.shape
        if self.env_sq.shape[0] != n_ch:
            self.env_sq = np.full(n_ch, self.threshold_sq, dtype=np.float64)
            self.env_peak_sq = np.full(n_ch, self.threshold_sq, dtype=np.float64)

        # Piso absoluto 1e-14 solo para evitar división por cero en
        # silencio digital puro — NO es un umbral que "aplane" la ley de
        # ganancia (ver corrección de fórmula arriba). Kernel Numba.
        _compander_block(out, self.env_sq, self.env_peak_sq, self.threshold_lin,
                         self.att, self.rel, self.peak_att, self.peak_rel, self.gain_exp)

        result = out.astype(np.float32)
        return result[:, 0] if mono else result

    def reset(self) -> None:
        self.env_sq[:] = self.threshold_sq
        self.env_peak_sq[:] = self.threshold_sq


# ═══════════════════════════════════════════════════════════════════════
#  PASO-BAJO DESLIZANTE — DNL (Philips, 1971): "de-hisser" de un extremo
# ═══════════════════════════════════════════════════════════════════════

class VariableLowpass:
    """
    Filtro paso-bajo de un polo cuya frecuencia de corte se recalcula
    dinámicamente (por bloque, no por muestra — simplificación aceptable
    a la tasa de bloque real del pipeline) según la envolvente RMS de
    entrada: corte alto (silencioso) con señal fuerte, corte bajo (hacia
    `cutoff_min_hz`) cuando el nivel cae por debajo del umbral.
    """

    def __init__(self, sample_rate: float, channels: int,
                 cutoff_min_hz: float, cutoff_max_hz: float,
                 threshold_db: float, attack_ms: float, release_ms: float):
        self.fs = sample_rate
        self.cutoff_min = cutoff_min_hz
        self.cutoff_max = cutoff_max_hz
        self.threshold_sq = (10.0 ** (threshold_db / 20.0)) ** 2
        self.att = math.exp(-1.0 / max(1, int(sample_rate * attack_ms / 1000.0)))
        self.rel = math.exp(-1.0 / max(1, int(sample_rate * release_ms / 1000.0)))
        self.env_sq = np.full(channels, self.threshold_sq, dtype=np.float64)
        self.z1 = np.zeros(channels, dtype=np.float64)

    def _cutoff_coef(self, cutoff_hz: float) -> float:
        # Coeficiente de un polo (RC) para el paso-bajo: y[n] = a*y[n-1]+(1-a)*x[n]
        rc = 1.0 / (2.0 * math.pi * cutoff_hz)
        dt = 1.0 / self.fs
        return rc / (rc + dt)

    def process(self, x: np.ndarray) -> np.ndarray:
        mono = x.ndim == 1
        if mono:
            x = x[:, np.newaxis]
        out = x.astype(np.float64).copy()
        n_samples, n_ch = out.shape
        if self.env_sq.shape[0] != n_ch:
            self.env_sq = np.full(n_ch, self.threshold_sq, dtype=np.float64)
            self.z1 = np.zeros(n_ch, dtype=np.float64)

        thr_sq = self.threshold_sq
        att, rel = self.att, self.rel

        # Envolvente RMS calculada por bloque (más barato que por muestra,
        # suficiente para la ballística de un des-hisser, que no necesita
        # resolución sub-milisegundo real).
        block_rms_sq = np.mean(out * out, axis=0)
        for ch in range(n_ch):
            e = self.env_sq[ch]
            e = (att * e + (1.0 - att) * block_rms_sq[ch] if block_rms_sq[ch] > e
                 else rel * e + (1.0 - rel) * block_rms_sq[ch])
            self.env_sq[ch] = e
            level_ratio = min(1.0, math.sqrt(max(e, 1e-12) / thr_sq))
            cutoff_hz = self.cutoff_min + (self.cutoff_max - self.cutoff_min) * level_ratio
            a = self._cutoff_coef(cutoff_hz)
            col = np.ascontiguousarray(out[:, ch])
            self.z1[ch] = _one_pole(col, a, float(self.z1[ch]))
            out[:, ch] = col

        result = out.astype(np.float32)
        return result[:, 0] if mono else result

    def reset(self) -> None:
        self.env_sq[:] = self.threshold_sq
        self.z1[:] = 0.0


# ═══════════════════════════════════════════════════════════════════════
#  DOS BANDAS ADAPTATIVAS — DNR (National Semiconductor LM1894, 1981)
# ═══════════════════════════════════════════════════════════════════════

class TwoBandAdaptiveGate:
    """
    "Noise gate espectral" de dos bandas (grave/agudo), cada una con su
    propio detector RMS y atenuación independiente — a diferencia de
    `VariableLowpass` (DNL, una sola banda de control HF), aquí ambas
    bandas se atenúan SOLO cuando su propia energía cae bajo el umbral,
    preservando mejor el contenido útil de rango medio.
    """

    def __init__(self, sample_rate: float, channels: int,
                 crossover_hz: float, threshold_db: float,
                 max_atten_db: float, attack_ms: float, release_ms: float):
        self.lp_split = lowpass(crossover_hz, sample_rate, channels)
        self.hp_split = highpass(crossover_hz, sample_rate, channels)
        self.threshold_sq = (10.0 ** (threshold_db / 20.0)) ** 2
        self.min_gain = 10.0 ** (-max_atten_db / 20.0)
        self.att = math.exp(-1.0 / max(1, int(sample_rate * attack_ms / 1000.0)))
        self.rel = math.exp(-1.0 / max(1, int(sample_rate * release_ms / 1000.0)))
        self.env_lo = np.full(channels, self.threshold_sq, dtype=np.float64)
        self.env_hi = np.full(channels, self.threshold_sq, dtype=np.float64)

    def _band_gain(self, env: np.ndarray, block_energy: np.ndarray, ch: int) -> float:
        e = env[ch]
        be = block_energy[ch]
        e = (self.att * e + (1.0 - self.att) * be if be > e
             else self.rel * e + (1.0 - self.rel) * be)
        env[ch] = e
        ratio = min(1.0, math.sqrt(max(e, 1e-12) / self.threshold_sq))
        return self.min_gain + (1.0 - self.min_gain) * ratio

    def process(self, x: np.ndarray) -> np.ndarray:
        mono = x.ndim == 1
        if mono:
            x = x[:, np.newaxis]
        lo = self.lp_split.process(x)
        hi = self.hp_split.process(x)
        n_ch = 1 if mono else x.shape[1]
        lo2 = lo if lo.ndim == 2 else lo[:, np.newaxis]
        hi2 = hi if hi.ndim == 2 else hi[:, np.newaxis]

        lo_energy = np.mean(lo2.astype(np.float64) ** 2, axis=0)
        hi_energy = np.mean(hi2.astype(np.float64) ** 2, axis=0)
        out = np.empty_like(lo2, dtype=np.float32)
        for ch in range(lo2.shape[1] if lo2.ndim == 2 else n_ch):
            g_lo = self._band_gain(self.env_lo, lo_energy, ch)
            g_hi = self._band_gain(self.env_hi, hi_energy, ch)
            out[:, ch] = (lo2[:, ch] * g_lo + hi2[:, ch] * g_hi).astype(np.float32)

        return out[:, 0] if mono else out

    def reset(self) -> None:
        self.lp_split.reset()
        self.hp_split.reset()
        self.env_lo[:] = self.threshold_sq
        self.env_hi[:] = self.threshold_sq
