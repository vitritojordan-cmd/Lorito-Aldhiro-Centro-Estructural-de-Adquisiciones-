from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Lógica pura de reproducción extraída del God Object — clamp de posición para el scrub/waveform y texto del contómetro de velocidad.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_playback_scrub_sync.py — GAP-070, FASE 7 ("Controllers / God
Object", §13) de la Orden Maestra de Saneamiento, Integración y
Consolidación de Lorito Aldhiro.

Extracción MECÁNICA de dos fragmentos puros duplicados que vivían
inline, repetidos varias veces, dentro de `_on_speed_changed()`/
`_on_morpher_changed()` (`PlaybackMixin`, `lorito_mw_playback.py`) —
mismo criterio de extracción ya usado en GAP-056
(`lorito_export_session_spec.py`) y GAP-062
(`lorito_speed_zone_labels.py`): el código y los umbrales EXACTOS, sin
rediseño, verificado con tests de regresión reales sobre la función
extraída.

## `clamp_position_fraction()`

Aparecía, calcada, en 4 sitios distintos de `_on_speed_changed()`/
`_on_morpher_changed()` — cada vez calculando la fracción `[0, 1]` de
`src_pos` sobre `total_frames` para actualizar `self.scrub`/
`self.waveform` durante reproducción con velocidad/morpher activos.
Dos variantes reales, NO unificadas aquí a propósito (unificar la
guarda cambiaría comportamiento, y esto es una extracción mecánica,
no un rediseño):

  - 2 de los 4 sitios (el flush de commit del Velocista, y el flush de
    consolidación final del Morpher) exigen ADEMÁS `total_secs > 0`
    antes de calcular la fracción, aunque `total_secs` nunca participa
    en el cálculo en sí — una guarda de sanidad extra contra un estado
    inconsistente (frames>0 pero secs<=0).
  - Los otros 2 sitios (Morpher forward/reverse durante drag) solo
    exigen `total_frames > 0`.

`clamp_position_fraction(src_pos, total_frames, total_secs=None)`
reproduce AMBAS variantes con un único parámetro opcional: se pasa
`total_secs` en los 2 sitios que lo exigían, se omite en los otros 2 —
comportamiento IDÉNTICO en los 4 sitios, ahora en un solo lugar.
Devuelve `None` cuando la guarda no se cumple (el llamador entonces NO
debe tocar `self.scrub`/`self.waveform`, exactamente como antes).

## `speed_status_text()`

El texto exacto `"__CAROLAMOTION_SPEED__LORITO PICOTEA EL CASSETTE
×{ratio:.2f} — {_carol_speed_label(ratio)}"` aparecía, calcado,
en 3 sitios (2 en `_on_speed_changed()`, uno en la consolidación final
de `_on_morpher_changed()`, este último parametrizado por
`self._speed_ratio` en vez de un `ratio` local — la misma fórmula).
`speed_status_text(ratio)` la centraliza — `_carol_speed_label()`
(`backend/export/lorito_normalization.py`) se importa y se llama tal
cual, sin reimplementar nada.

Ninguna de las dos funciones toca ningún widget de Qt, hilo, ni
estado de instancia — son aritmética/formateo de texto puros, cien
por cien testeables sin PySide6 (bloqueado en este sandbox, ver
GAP-054 §7) ni sin instanciar `LoritoAldhiroStudio`. El resto de
`_on_speed_changed()`/`_on_morpher_changed()` (orquestación real de
`self._player`, timers Qt, forense, `self.scrub`/`self.waveform`/
`self.clock`/`self.status_label`) NO se toca — sigue viviendo en
`lorito_mw_playback.py`, tal como pide la Orden para código de audio
en tiempo real sin verificación con hardware real disponible.
"""

from lorito_aldhiro.backend.export.lorito_normalization_common import _carol_speed_label


def clamp_position_fraction(src_pos: float, total_frames: float,
                            total_secs: float | None = None) -> float | None:
    """Fracción `[0.0, 1.0]` de `src_pos` sobre `total_frames`, o
    `None` si la guarda no se cumple (el llamador no debe actualizar
    scrub/waveform en ese caso). Si se pasa `total_secs` (no `None`),
    también se exige `> 0` — mismo criterio que los 2 sitios de
    llamada que lo comprobaban; se omite en los otros 2. Ver docstring
    del módulo."""
    if total_frames is None or total_frames <= 0:
        return None
    if total_secs is not None and total_secs <= 0:
        return None
    return max(0.0, min(1.0, src_pos / total_frames))


def speed_status_text(ratio: float) -> str:
    """Texto exacto del contómetro cuando el Velocista/Morpher está
    activo con reproducción en curso — ver docstring del módulo para
    los 3 sitios de llamada idénticos que reemplaza."""
    return (f"__CAROLAMOTION_SPEED__LORITO PICOTEA EL CASSETTE ×{ratio:.2f}"
            f" — {_carol_speed_label(ratio)}")
