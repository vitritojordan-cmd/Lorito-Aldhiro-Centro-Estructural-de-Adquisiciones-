from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Contrato del cuentavueltas analógico: posición confirmada → lectura 000–999 estimada, con lado, unidades y rodado de tambores.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Contrato funcional del cuentavueltas (Orden LA-GOLDEN-VIEW-SIGSEGV-019 §5).

- **Fuente de verdad.** La posición CONFIRMADA en frames de la fuente
  digital: la del `TransportCoordinator` en FF/REW o la del reproductor en
  PLAY, en frames enteros y con su tasa. Lorito no tiene un sensor de
  vueltas físico.
- **Calidad.** Siempre `ESTIMATED`: la lectura sale de un modelo de cinta,
  no de un contador físico. Sin fuente queda `UNKNOWN` y no inventa nada.
- **Unidades separadas:** frames (entrada) → segundos → lado de cinta y
  progreso del lado → lectura del cuentavueltas (000–999, 3 rodillos).
- **Modelo (el mismo que usa el panel de duración durante la captura).**
  - C-60 y C-90: cada lado recorre 000 → 999 de forma lineal con el tiempo
    del lado. El Lado A dura `side_a_secs`; el Lado B, `total − side_a`.
    Más allá del total la lectura satura en 999 con `overflow=True`.
  - OTROS: la lectura son los segundos módulo 1000 (vuelve a 000).
  - El volteo real de una grabación ocurre dentro de una ventana de
    tolerancia, no exactamente en `side_a_secs`, así que en reproducción
    la lectura del Lado B es una ESTIMACIÓN. Se declara como tal.
- **Sin deriva.** Se calcula desde la posición entera en cada lectura: no
  se acumula nada por temporizador.
- **Estados explícitos.** En pausa, al detener o en el límite no hay
  lectura nueva: la última queda congelada (la congela quien publica).
- **Rodado.** `drums()` devuelve, por rodillo, (dígito, rodado) con la
  regla del cuentakilómetros: las unidades ruedan de forma continua, y
  cada rodillo superior rueda solo mientras el inferior pasa de 9 a 0.
"""

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class CounterReading:
    value: float          # lectura continua 0..999,999…
    side: str             # "A", "B", "SOBRANTE", "LIBRE" o "" sin fuente
    quality: str          # "ESTIMATED" | "UNKNOWN"
    overflow: bool = False

    @property
    def shown(self) -> int:
        return int(math.floor(self.value)) % 1000


class TapeCounterModel:
    UNITS_PER_SIDE = 999.0

    def __init__(self, label: str, side_a_secs: float, total_secs: float):
        self.label = label
        self.side_a = float(side_a_secs)
        self.total = float(total_secs)

    @property
    def free_mode(self) -> bool:
        return self.label == "OTROS" or self.side_a <= 0 or self.total <= 0

    def reading_for_frames(self, frame: int, sample_rate: int) -> CounterReading:
        if sample_rate <= 0 or frame is None:
            return CounterReading(0.0, "", "UNKNOWN")
        return self.reading(int(frame) / float(sample_rate))

    def reading(self, pos_s: float) -> CounterReading:
        if pos_s is None or not math.isfinite(pos_s) or pos_s < 0:
            return CounterReading(0.0, "", "UNKNOWN")
        if self.free_mode:
            return CounterReading(pos_s % 1000.0, "LIBRE", "ESTIMATED")
        if pos_s < self.side_a:
            return CounterReading(pos_s / self.side_a * self.UNITS_PER_SIDE, "A", "ESTIMATED")
        side_b = max(self.total - self.side_a, 1e-9)
        t = (pos_s - self.side_a) / side_b
        if t > 1.0:
            return CounterReading(self.UNITS_PER_SIDE, "SOBRANTE", "ESTIMATED", overflow=True)
        return CounterReading(t * self.UNITS_PER_SIDE, "B", "ESTIMATED")


def drums(value: float, n: int = 3) -> tuple:
    """((dígitos), (rodado)) de `n` rodillos para una lectura continua, en
    el convenio de `CounterSnapshot` (posición del tambor = dígito − rodado)."""
    v = max(0.0, float(value)) % (10 ** n)
    digits, rolls = [], []
    for k in range(n):                      # k = 0 unidades, 1 decenas…
        unit = 10 ** k
        whole = math.floor(v / unit)
        pos = float(whole % 10)
        if k == 0:
            pos = (v % 10.0)
        else:
            below = v % unit                 # avance de los rodillos inferiores
            carry_zone = unit - 1            # el inferior está entre 9…9 y 0…0
            if below > carry_zone:
                pos = (whole % 10) + (below - carry_zone)
        d = int(math.ceil(pos - 1e-9)) % 10
        roll = (math.ceil(pos - 1e-9) - pos) if pos % 1 else 0.0
        digits.append(d)
        rolls.append(max(0.0, min(1.0, roll)))
    return tuple(reversed(digits)), tuple(reversed(rolls))
