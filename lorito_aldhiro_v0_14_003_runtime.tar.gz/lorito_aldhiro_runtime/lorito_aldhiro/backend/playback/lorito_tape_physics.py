from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Modelo físico de la cinta magnética (velocidad, wow/flutter, saturación) para reproducción.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

from enum import Enum, auto
import math as _math

# LA-GOLDEN-CORE-020: esta clase es la física de transporte propia de
# Lorito. Hasta 0.13 intentaba además importar un motor ITL externo
# opcional del monolito de origen (nunca incluido en ninguna entrega de
# Lorito) y, al no encontrarlo, caía siempre en esta misma física. Ese
# intento (y la ruta que delegaba en él) se retiró: no había ningún
# consumidor que pudiera activarla. El comportamiento observable no
# cambia; lo fija `tests/test_core_independencia.py` con una traza de
# referencia grabada sobre 0.13.009. El texto original queda archivado
# en /legado/procedencia/.


# ─────────────────────────────────────────────────────────────────────────────
#  TAPE LOG PANEL  — indicador de cassette C-60 / C-90 / OTROS
#  Muestra: hubs con giro diferenciado (carrete lleno→vacío), leyenda de lado,
#           y tape counter estilo deck vintage.
#  Modos de color:
#    "C-60"  → hubs + leyenda crema brillante  (#FFF8DC vivo)
#    "C-90"  → hubs + leyenda turquesa brillante (#00E5CC vivo)
#    "OTROS" → hubs + leyenda ámbar brillante   (#FFB300 vivo), parpadeo 1s
# ─────────────────────────────────────────────────────────────────────────────

# ══════════════════════════════════════════════════════════════════════════════
#  FÍSICA DE TRANSPORTE DE CINTA
#  Clases de estado (_CassetteType_Enum, _TransportMode_Enum, _SideState_Enum,
#  _AutoStopState_Enum, _PhysicsOutputs) y CassetteTransportPhysics, con la
#  interfaz que usa TapeLogPanel (step, flip_side, insert_cassette, outputs.*).
# ══════════════════════════════════════════════════════════════════════════════

class _CassetteType_Enum(Enum):
    C60 = auto()
    C90 = auto()

class _TransportMode_Enum(Enum):
    STOP = auto()
    PLAY = auto()
    FF   = auto()
    REW  = auto()

class _SideState_Enum(Enum):
    SIDE_A = auto()
    SIDE_B = auto()

class _AutoStopState_Enum(Enum):
    NONE          = auto()
    END_OF_SIDE_A = auto()
    END_OF_TAPE   = auto()

class _PhysicsOutputs:
    """Salidas de CassetteTransportPhysics que lee TapeLogPanel."""
    def __init__(self):
        self.reel_rpm_left        = 0.0
        self.reel_rpm_right       = 0.0
        self.reel_radius_left_cm  = 0.0
        self.reel_radius_right_cm = 0.0
        self.tape_position_cm     = 0.0
        self.elapsed_time_s       = 0.0
        self.remaining_time_s     = 0.0
        self.side_state           = _SideState_Enum.SIDE_A
        self.counter_value        = 0.0
        self.auto_stop_state      = _AutoStopState_Enum.NONE

class CassetteTransportPhysics:
    """
    Física de transporte de cinta de Lorito Aldhiro: posición en cm,
    radios de carrete por espiral (IEC 60581-6), RPM, cuentavueltas y
    fin de lado/cinta, avanzada por `step(dt, modo)`.
    """

    # ── Constantes de clase (preservadas para referencias externas) ───────────
    # Valores IEC 60581-6.
    NOMINAL_SPEED_CM_S      = 4.76   # cm/s (IEC 60581-6) — igual a V_TAPE_CM_S
    FF_REW_SPEED_MULTIPLIER = 20.0
    HUB_RADIUS_CM           = 1.10   # cm
    MAX_REEL_RADIUS_CM      = 3.30   # cm

    def __init__(self):
        self._tape_type         = None
        self._side              = _SideState_Enum.SIDE_A

        self._total_duration_s  = 0.0
        self._side_a_duration_s = 0.0
        self._side_b_duration_s = 0.0
        self._total_length_cm   = 0.0
        self._side_a_length_cm  = 0.0
        self._tape_thickness_cm = 0.0
        self._position_cm       = 0.0
        self._counter_revolutions = 0.0

        self.outputs = _PhysicsOutputs()

    def insert_cassette(self, tape_type) -> None:
        """Inserta un cassette y calcula longitudes y grosor de cinta."""
        self._tape_type = tape_type
        self._side      = _SideState_Enum.SIDE_A
        self._position_cm = 0.0
        self._counter_revolutions = 0.0

        if tape_type == _CassetteType_Enum.C60:
            self._total_duration_s  = 60 * 60.0
            self._side_a_duration_s = 30 * 60.0
        elif tape_type == _CassetteType_Enum.C90:
            self._total_duration_s  = 90 * 60.0
            self._side_a_duration_s = 45 * 60.0
        else:
            self._total_duration_s  = 60 * 60.0
            self._side_a_duration_s = 30 * 60.0

        self._side_b_duration_s = self._total_duration_s - self._side_a_duration_s
        self._total_length_cm   = self._total_duration_s  * self.NOMINAL_SPEED_CM_S
        self._side_a_length_cm  = self._side_a_duration_s * self.NOMINAL_SPEED_CM_S
        _area = _math.pi * (self.MAX_REEL_RADIUS_CM ** 2 - self.HUB_RADIUS_CM ** 2)
        _max_side = max(self._side_a_length_cm,
                        self._total_length_cm - self._side_a_length_cm)
        self._tape_thickness_cm = _area / _max_side if _max_side > 0 else 1.2e-3

        self._update_outputs(0.0, 0.0)

    def step(self, dt: float, mode) -> None:
        """
        Avanza la física un paso de dt segundos en el modo indicado.
        """
        if self._tape_type is None or mode == _TransportMode_Enum.STOP:
            self._update_outputs(0.0, 0.0)
            return

        is_play = (mode == _TransportMode_Enum.PLAY)

        if mode == _TransportMode_Enum.PLAY:
            speed_cm_s = self.NOMINAL_SPEED_CM_S
        elif mode == _TransportMode_Enum.FF:
            speed_cm_s = self.NOMINAL_SPEED_CM_S * self.FF_REW_SPEED_MULTIPLIER
        elif mode == _TransportMode_Enum.REW:
            speed_cm_s = -self.NOMINAL_SPEED_CM_S * self.FF_REW_SPEED_MULTIPLIER
        else:
            speed_cm_s = 0.0

        dx           = speed_cm_s * dt
        new_position = self._position_cm + dx
        _auto        = _AutoStopState_Enum.NONE

        if speed_cm_s > 0:
            if (self._side == _SideState_Enum.SIDE_A
                    and new_position >= self._side_a_length_cm):
                new_position = self._side_a_length_cm
                _auto = _AutoStopState_Enum.END_OF_SIDE_A
            elif (self._side == _SideState_Enum.SIDE_B
                    and new_position >= self._total_length_cm):
                new_position = self._total_length_cm
                _auto = _AutoStopState_Enum.END_OF_TAPE
        elif speed_cm_s < 0:
            _limit = 0.0 if self._side == _SideState_Enum.SIDE_A else self._side_a_length_cm
            if new_position <= _limit:
                new_position = _limit
                _auto = (_AutoStopState_Enum.END_OF_SIDE_A
                         if self._side == _SideState_Enum.SIDE_B
                         else _AutoStopState_Enum.END_OF_TAPE)

        actual_dx = new_position - self._position_cm
        self._position_cm = new_position
        self._update_outputs(actual_dx, dt)
        self.outputs.auto_stop_state = _auto

    def flip_side(self) -> None:
        """Voltea el cassette al lado contrario."""
        if self._tape_type is None:
            return
        if self._side == _SideState_Enum.SIDE_A:
            self._side        = _SideState_Enum.SIDE_B
            self._position_cm = self._side_a_length_cm
        else:
            self._side        = _SideState_Enum.SIDE_A
            self._position_cm = 0.0

        self._update_outputs(0.0, 0.0)

    # ── Internos ──────────────────────────────────────────────────────────────

    def _update_outputs(self, actual_dx: float, dt: float) -> None:
        """Radios, RPM y cuentavueltas desde la posición. Radio dinámico exacto IEC."""
        if self._tape_type is None:
            return
        if self._side == _SideState_Enum.SIDE_A:
            side_len  = self._side_a_length_cm
            side_pos  = self._position_cm
        else:
            side_len  = self._total_length_cm - self._side_a_length_cm
            side_pos  = self._position_cm - self._side_a_length_cm

        area_consumed  = side_pos             * self._tape_thickness_cm
        area_remaining = (side_len - side_pos) * self._tape_thickness_cm
        r_right_sq = self.HUB_RADIUS_CM ** 2 + area_consumed  / _math.pi
        r_left_sq  = self.HUB_RADIUS_CM ** 2 + area_remaining / _math.pi
        radius_right = _math.sqrt(max(r_right_sq, self.HUB_RADIUS_CM ** 2))
        radius_left  = _math.sqrt(max(r_left_sq,  self.HUB_RADIUS_CM ** 2))

        if radius_right > 0:
            self._counter_revolutions += (abs(actual_dx) / radius_right) / (2 * _math.pi)

        rpm_right = rpm_left = 0.0
        if dt > 0 and abs(actual_dx) > 0:
            v = abs(actual_dx) / dt
            rpm_right = (v / radius_right) * (60.0 / (2 * _math.pi))
            rpm_left  = (v / radius_left)  * (60.0 / (2 * _math.pi))

        self.outputs.reel_radius_left_cm  = radius_left
        self.outputs.reel_radius_right_cm = radius_right
        self.outputs.reel_rpm_left        = rpm_left
        self.outputs.reel_rpm_right       = rpm_right
        self.outputs.tape_position_cm     = self._position_cm
        self.outputs.elapsed_time_s       = side_pos               / self.NOMINAL_SPEED_CM_S
        self.outputs.remaining_time_s     = (side_len - side_pos)  / self.NOMINAL_SPEED_CM_S
        self.outputs.side_state           = self._side
        self.outputs.counter_value        = self._counter_revolutions
        self.outputs.auto_stop_state      = _AutoStopState_Enum.NONE
