from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ring SPSC de captura SIN sobrescritura — rechazo explícito, nunca pérdida silenciosa.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_capture_ring.py — Orden Golden del Motor de Captura (CAP-001,
CAP-002, Fase 2).

`SPSCCaptureRing` sustituye a la vieja política de `RingBufferAbsorcion`
(lock + `threading.Condition` + `notify_all` + overwrite-oldest +
truncamiento silencioso de bloques > `frames_max`) en el camino de
captura patrimonial.

Contrato (ver `RT_CONTRACT.md`):

  · Un ÚNICO productor (el callback de PortAudio) y un ÚNICO consumidor
    (el hilo de drenaje). Ninguno de los dos toma locks ni espera.
  · Memoria fija: `[n_slots, frames_max, channels]` float32 prealocado
    en el constructor. Ni el productor ni el consumidor asignan memoria
    de tamaño variable (el consumidor puede copiar a un destino propio).
  · SIN sobrescritura: si el ring está lleno, `write()` NO toca ningún
    slot — devuelve `RING_FULL` y el bloque queda registrado como
    pérdida por el llamador (FrameLedger). El dato más antiguo jamás se
    sacrifica en silencio.
  · SIN truncamiento: un bloque con más frames que `frames_max` (o con
    canales distintos) se rechaza entero (`BLOCK_OVERSIZE` /
    `BLOCK_SHAPE`) — nunca se recorta.
  · Cada slot publicado lleva su número de secuencia y la generación de
    sesión con la que se escribió; el consumidor descarta y cuenta
    cualquier slot de una generación distinta de la activa (prueba de
    "no mezcla de generaciones").

Orden de publicación (protocolo SPSC clásico de Lamport):
  productor: copia datos → escribe metadatos del slot → publica
             `_write_seq` (+1).
  consumidor: lee `_write_seq` → copia el slot → publica `_read_seq`
             (+1).
  `_write_seq` solo lo escribe el productor; `_read_seq` solo el
  consumidor. Ocupación = `_write_seq - _read_seq` ∈ [0, n_slots].

Garantía de memoria — LIMITACIÓN DECLARADA (exigida por la orden: "si el
backend no puede garantizar lock-free en el runtime objetivo, declarar
la limitación"): el protocolo es correcto en CPython CON GIL, donde cada
asignación de atributo es atómica y el orden de programa entre
bytecodes se preserva entre hilos. En builds free-threaded (PEP 703,
`python3.13t`) CPython no documenta barreras de memoria para asignación
de atributos de instancia simples; en ese runtime este ring NO se
declara lock-free verificado (`LOCK_FREE_VERIFIED` es False) y el motor
lo informa en telemetría. Tampoco es "lock-free" en sentido estricto de
tiempo real duro: el callback Python sigue sujeto al GIL del intérprete
(ver documentación de python-sounddevice); lo que sí garantiza es que
el callback no espera NUNCA a un lock o Condition de la aplicación.
"""

import sys

import numpy as np


WRITE_OK = 0
RING_FULL = 1
BLOCK_OVERSIZE = 2
BLOCK_SHAPE = 3
WRITE_DISABLED = 4

WRITE_RESULT_NAMES = {
    WRITE_OK: "OK",
    RING_FULL: "RING_FULL",
    BLOCK_OVERSIZE: "BLOCK_OVERSIZE",
    BLOCK_SHAPE: "BLOCK_SHAPE",
    WRITE_DISABLED: "WRITE_DISABLED",
}


def _gil_enabled() -> bool:
    probe = getattr(sys, "_is_gil_enabled", None)
    if probe is None:
        return True
    try:
        return bool(probe())
    except Exception:
        return True


LOCK_FREE_VERIFIED = _gil_enabled()


class SPSCCaptureRing:
    """Ring SPSC de bloques para el camino archivístico de captura."""

    __slots__ = (
        "_name", "_n", "_frames_max", "_channels",
        "_buf", "_frames", "_slot_seq", "_slot_gen",
        "_write_seq", "_read_seq", "_generation", "_enabled",
        # contadores del PRODUCTOR (solo él los escribe)
        "_rejected_full_blocks", "_rejected_full_frames",
        "_rejected_oversize_blocks", "_rejected_oversize_frames",
        "_rejected_shape_blocks", "_rejected_shape_frames",
        "_rejected_disabled_blocks", "_rejected_disabled_frames",
        "_accepted_blocks", "_accepted_frames", "_first_reject_seq",
        # contadores del CONSUMIDOR
        "_stale_generation_blocks", "_stale_generation_frames",
        "_consumed_blocks", "_consumed_frames",
        "watermark_pct", "_wm_state", "_wm_hysteresis",
    )

    def __init__(self, n_slots: int, frames_max: int, channels: int,
                 name: str = "RBA_SPSC_GOLDEN"):
        if n_slots < 2:
            raise ValueError("SPSCCaptureRing necesita al menos 2 slots")
        if frames_max < 1 or channels < 1:
            raise ValueError("frames_max y channels deben ser >= 1")
        self._name = name
        self._n = int(n_slots)
        self._frames_max = int(frames_max)
        self._channels = int(channels)
        self._buf = np.zeros((self._n, self._frames_max, self._channels), dtype=np.float32)
        self._frames = np.zeros(self._n, dtype=np.int64)
        self._slot_seq = np.full(self._n, -1, dtype=np.int64)
        self._slot_gen = np.zeros(self._n, dtype=np.int64)
        self._write_seq = 0
        self._read_seq = 0
        self._generation = 0
        self._enabled = True
        self._rejected_full_blocks = 0
        self._rejected_full_frames = 0
        self._rejected_oversize_blocks = 0
        self._rejected_oversize_frames = 0
        self._rejected_shape_blocks = 0
        self._rejected_shape_frames = 0
        self._rejected_disabled_blocks = 0
        self._rejected_disabled_frames = 0
        self._accepted_blocks = 0
        self._accepted_frames = 0
        self._first_reject_seq = -1
        self._stale_generation_blocks = 0
        self._stale_generation_frames = 0
        self._consumed_blocks = 0
        self._consumed_frames = 0
        self.watermark_pct = 0.0
        self._wm_state = "SAFE"
        self._wm_hysteresis = 0.05

    # ── Ciclo de vida (solo con productor Y consumidor quiescentes) ─────────

    def reset_for_generation(self, generation: int) -> None:
        """Vacía el ring y fija la generación activa. Precondición: ni el
        callback ni el drain están corriendo (lo garantiza la máquina de
        estados de sesión, nunca este método)."""
        self._generation = int(generation)
        self._write_seq = 0
        self._read_seq = 0
        self._slot_seq[:] = -1
        self._frames[:] = 0
        self.watermark_pct = 0.0
        self._wm_state = "SAFE"
        self._enabled = True

    def resize(self, n_slots: int) -> None:
        """Cambia la cantidad de slots EN EL MISMO objeto (0.13.002: ring
        dimensionado en segundos según la frecuencia). Misma precondición
        que `reset_for_generation`: productor y consumidor quiescentes. El
        ring queda vacío; los contadores acumulados se conservan."""
        n = int(n_slots)
        if n < 2:
            raise ValueError("SPSCCaptureRing necesita al menos 2 slots")
        if n == self._n:
            return
        self._n = n
        self._buf = np.zeros((n, self._frames_max, self._channels), dtype=np.float32)
        self._frames = np.zeros(n, dtype=np.int64)
        self._slot_seq = np.full(n, -1, dtype=np.int64)
        self._slot_gen = np.zeros(n, dtype=np.int64)
        self._write_seq = 0
        self._read_seq = 0
        self.watermark_pct = 0.0
        self._wm_state = "SAFE"

    @property
    def n_slots(self) -> int:
        return self._n

    def disable_writes(self) -> None:
        """Barrera lógica: desde aquí el productor rechaza todo
        (`WRITE_DISABLED`). Usado por la política fail-stop."""
        self._enabled = False

    def enable_writes(self) -> None:
        self._enabled = True

    # ── Productor (callback RT) ─────────────────────────────────────────────

    def write(self, block: np.ndarray, n_frames: int | None = None) -> bool:
        """Variante booleana de `publish()` (True solo si WRITE_OK)."""
        return self.publish(block, n_frames) == WRITE_OK

    def publish(self, block: np.ndarray, n_frames: int | None = None) -> int:
        """Publica `block[:n_frames]`. Devuelve un código `WRITE_*`.
        Nunca bloquea, nunca sobrescribe, nunca trunca."""
        n = block.shape[0] if n_frames is None else int(n_frames)
        if not self._enabled:
            self._rejected_disabled_blocks += 1
            self._rejected_disabled_frames += n
            return WRITE_DISABLED
        if block.ndim != 2 or block.shape[1] != self._channels or n > block.shape[0]:
            self._rejected_shape_blocks += 1
            self._rejected_shape_frames += n
            if self._first_reject_seq < 0:
                self._first_reject_seq = self._write_seq
            return BLOCK_SHAPE
        if n > self._frames_max:
            self._rejected_oversize_blocks += 1
            self._rejected_oversize_frames += n
            if self._first_reject_seq < 0:
                self._first_reject_seq = self._write_seq
            return BLOCK_OVERSIZE
        seq = self._write_seq
        if seq - self._read_seq >= self._n:
            self._rejected_full_blocks += 1
            self._rejected_full_frames += n
            if self._first_reject_seq < 0:
                self._first_reject_seq = seq
            return RING_FULL
        idx = seq % self._n
        self._buf[idx, :n] = block[:n]
        self._frames[idx] = n
        self._slot_gen[idx] = self._generation
        self._slot_seq[idx] = seq
        self._write_seq = seq + 1          # publicación
        self._accepted_blocks += 1
        self._accepted_frames += n
        self.watermark_pct = (seq + 1 - self._read_seq) / self._n
        return WRITE_OK

    # ── Consumidor (drain) ──────────────────────────────────────────────────

    def read_into(self, dest: np.ndarray):
        """Copia el siguiente bloque a `dest` (prealocado, ≥ frames_max).
        Devuelve `(n_frames, seq)` o `None` si no hay datos. Bloques de
        otra generación se descartan y cuentan (nunca se entregan)."""
        while True:
            rs = self._read_seq
            if rs >= self._write_seq:
                return None
            idx = rs % self._n
            n = int(self._frames[idx])
            gen = int(self._slot_gen[idx])
            seq = int(self._slot_seq[idx])
            if gen != self._generation or seq != rs:
                self._stale_generation_blocks += 1
                self._stale_generation_frames += n
                self._read_seq = rs + 1
                continue
            dest[:n] = self._buf[idx, :n]
            self._read_seq = rs + 1        # libera el slot
            self._consumed_blocks += 1
            self._consumed_frames += n
            self.watermark_pct = (self._write_seq - rs - 1) / self._n
            return n, seq

    def read(self):
        """Variante con copia propia: `(array, n_frames, seq)` o None."""
        rs = self._read_seq
        if rs >= self._write_seq:
            return None
        tmp = np.empty((self._frames_max, self._channels), dtype=np.float32)
        got = self.read_into(tmp)
        if got is None:
            return None
        n, seq = got
        return tmp[:n].copy(), n, seq

    def read_batch(self, max_items: int = 64) -> list:
        """Lista de copias independientes (compatibilidad con la API del
        RBA anterior). Cada elemento es un `np.ndarray [n, channels]`."""
        out = []
        while len(out) < max_items:
            item = self.read()
            if item is None:
                break
            out.append(item[0])
        return out

    # ── Métricas ────────────────────────────────────────────────────────────

    def get_watermark_state(self) -> str:
        wm = self.watermark_pct
        hy = self._wm_hysteresis
        prev = self._wm_state
        if prev == "CRITICAL":
            new = "CRITICAL" if wm > 0.85 - hy else "HIGH"
        elif prev == "HIGH":
            if wm > 0.85:
                new = "CRITICAL"
            elif wm < 0.30 + hy:
                new = "MEDIUM"
            else:
                new = "HIGH"
        elif prev == "MEDIUM":
            if wm > 0.60:
                new = "HIGH"
            elif wm < 0.10 + hy:
                new = "SAFE"
            else:
                new = "MEDIUM"
        else:
            new = "MEDIUM" if wm > 0.30 else "SAFE"
        self._wm_state = new
        return new

    @property
    def count(self) -> int:
        return max(0, self._write_seq - self._read_seq)

    @property
    def capacity(self) -> int:
        return self._n

    @property
    def frames_max(self) -> int:
        return self._frames_max

    @property
    def channels(self) -> int:
        return self._channels

    @property
    def generation(self) -> int:
        return self._generation

    @property
    def rejected_frames(self) -> int:
        return (self._rejected_full_frames + self._rejected_oversize_frames
                + self._rejected_shape_frames + self._rejected_disabled_frames)

    @property
    def rejected_blocks(self) -> int:
        return (self._rejected_full_blocks + self._rejected_oversize_blocks
                + self._rejected_shape_blocks)

    def counters(self) -> dict:
        return {
            "accepted_blocks": self._accepted_blocks,
            "accepted_frames": self._accepted_frames,
            "consumed_blocks": self._consumed_blocks,
            "consumed_frames": self._consumed_frames,
            "rejected_full_blocks": self._rejected_full_blocks,
            "rejected_full_frames": self._rejected_full_frames,
            "rejected_oversize_blocks": self._rejected_oversize_blocks,
            "rejected_oversize_frames": self._rejected_oversize_frames,
            "rejected_shape_blocks": self._rejected_shape_blocks,
            "rejected_shape_frames": self._rejected_shape_frames,
            "rejected_disabled_blocks": self._rejected_disabled_blocks,
            "rejected_disabled_frames": self._rejected_disabled_frames,
            "stale_generation_blocks": self._stale_generation_blocks,
            "stale_generation_frames": self._stale_generation_frames,
            "first_reject_seq": self._first_reject_seq,
            "pending_blocks": self.count,
            "lock_free_verified": LOCK_FREE_VERIFIED,
        }
