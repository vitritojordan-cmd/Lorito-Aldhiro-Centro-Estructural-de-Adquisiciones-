from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Capa de servicios de la aplicación: contratos tipados, raíz de composición y API pública de la interfaz (LA-GOLDEN-CORE-020 §4).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_aldhiro.backend.services — la frontera entre la interfaz y los
motores. Arquitectura objetivo de la orden: Application Shell → servicios
de dominio → contratos de motor → adaptadores → infraestructura.

- `lorito_contracts`: un `Protocol` por servicio, con exactamente lo que la
  interfaz usa de cada motor (verificado por prueba contra el código).
- `lorito_app_services`: la raíz de composición. `build_app_services()`
  crea los motores una sola vez y es la única vía de la interfaz hacia los
  objetos con estado global (guardián de crash, snapshots, registro de
  clips, forense de xruns). También expone fábricas sin estado (coordinador
  de transporte, exportación, TAU).
- `lorito_ui_api`: los símbolos puros que la interfaz necesita (catálogos
  de menú, enums, formato de nombres, registro de overlays, modelos
  visuales de la cinta).

La interfaz (`lorito_aldhiro.frontend`) importa de los motores solo a
través de este paquete; `tests/test_core_servicios.py` lo verifica.
"""
