from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: API pública de la interfaz: catálogos, enums, formato y modelos visuales puros, sin estado de motor (LA-GOLDEN-CORE-020 §4).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Todo lo que la interfaz toma de los paquetes de motores y que no es un
servicio con estado: listas de menú, enums, funciones de formato y de texto,
el registro de overlays del LCD, y los modelos visuales de la cinta que
cada widget instancia para su propia animación. La interfaz los importa de
aquí; así un motor puede reorganizarse sin tocar la interfaz, y la prueba
de capas impide que la interfaz entre por otro lado.
"""

# ── Captura y sistema de audio ────────────────────────────────────────────
from lorito_aldhiro.backend.capture.lorito_rate_support import CAPTURE_RATES, check_capture_rate
from lorito_aldhiro.backend.audio.lorito_audio_backend import (
    AUDIO_BACKEND, FFMPEG_CAPS, NORM_ITEMS, NormalizationMode)
from lorito_aldhiro.backend.audio.lorito_tau import (
    ACTIVATE as TAU_ACTIVATE, DEACTIVATE as TAU_DEACTIVATE, pattern_frames as tau_pattern_frames)

# ── Instrumentación forense (AIPLO) ───────────────────────────────────────
from lorito_aldhiro.backend.capture.lorito_forensics import (
    _AIPLO_FRN_ACTIVE, _aiplo_frn_counters, _frn_emit, _frn_short_stack)

# ── DSP: catálogos de menú ────────────────────────────────────────────────
from lorito_aldhiro.backend.dsp.lorito_dither import DITHER_OFF, DITHER_TPDF, needs_dither
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_presets import (
    MUSCLE_EQ_PRESET_CATEGORIES, get_preset_bands)
from lorito_aldhiro.backend.dsp.lorito_dsp_muscle_eq_samir import EqBandType
from lorito_aldhiro.backend.dsp.lorito_dsp_version_o_tron import VOT_CONFIGS
from lorito_aldhiro.backend.dsp.lucha_enloquecida import LUCHA_PROFILE_ORDER

# ── Exportación: nombres, especificación, imagen espectral ────────────────
from lorito_aldhiro.backend.export.lorito_export_naming import (
    export_clip_tag, export_codec_extension, export_speed_display_suffix,
    export_speed_filename_tag)
from lorito_aldhiro.backend.export.lorito_export_session_spec import (
    build_session_spec_text, compute_integrity_check)
from lorito_aldhiro.backend.export.lorito_export_spectral_engine import (
    DEFAULT_LAYOUT, SpectralImageLayout, compute_spectrogram_rgba_from_wav_files)
from lorito_aldhiro.backend.export.lorito_normalization_common import (
    NORM_ITEMS_V21, NormalizationModeV21, _carol_speed_label)
from lorito_aldhiro.backend.export_streaming.lorito_export_service import (
    LABEL_NONE, ExportRequest, planned_target_bits)
from lorito_aldhiro.backend.export_streaming.lorito_normalization_stats_bridge import (
    apply_normalization_stats_to_status)

# ── Overlays del LCD ──────────────────────────────────────────────────────
from lorito_aldhiro.backend.export.lorito_overlay_registry import (
    OVERLAY_MESSAGES, family_of_category, lcd_overlay, lcd_overlay_text, message_for)

# ── Reproducción y transporte: textos, enums y modelos visuales ───────────
from lorito_aldhiro.backend.playback.lorito_playback_scrub_sync import (
    clamp_position_fraction, speed_status_text)
from lorito_aldhiro.backend.playback.lorito_speed_zone_labels import speed_zone_coded_name
from lorito_aldhiro.backend.playback.lorito_tape_counter_model import TapeCounterModel, drums
from lorito_aldhiro.backend.playback.lorito_reel_kinematics import ReelKinematics
from lorito_aldhiro.backend.playback.lorito_tape_physics import (
    CassetteTransportPhysics, _CassetteType_Enum, _TransportMode_Enum)
from lorito_aldhiro.backend.transport.lorito_ffrew_motors import (
    LimitKind, MotorPhase, RejectReason, TransportStatus)

__all__ = [
    "CAPTURE_RATES", "check_capture_rate", "AUDIO_BACKEND", "FFMPEG_CAPS", "NORM_ITEMS",
    "NormalizationMode", "TAU_ACTIVATE", "TAU_DEACTIVATE", "tau_pattern_frames",
    "_AIPLO_FRN_ACTIVE", "_aiplo_frn_counters", "_frn_emit", "_frn_short_stack",
    "DITHER_OFF", "DITHER_TPDF", "needs_dither", "MUSCLE_EQ_PRESET_CATEGORIES",
    "get_preset_bands", "EqBandType", "VOT_CONFIGS", "LUCHA_PROFILE_ORDER",
    "export_clip_tag", "export_codec_extension", "export_speed_display_suffix",
    "export_speed_filename_tag", "build_session_spec_text", "compute_integrity_check",
    "DEFAULT_LAYOUT", "SpectralImageLayout", "compute_spectrogram_rgba_from_wav_files",
    "NORM_ITEMS_V21", "NormalizationModeV21", "_carol_speed_label", "LABEL_NONE",
    "ExportRequest", "planned_target_bits", "apply_normalization_stats_to_status",
    "OVERLAY_MESSAGES", "family_of_category", "lcd_overlay", "lcd_overlay_text",
    "message_for", "clamp_position_fraction", "speed_status_text",
    "speed_zone_coded_name", "TapeCounterModel", "drums", "ReelKinematics",
    "CassetteTransportPhysics", "_CassetteType_Enum", "_TransportMode_Enum",
    "LimitKind", "MotorPhase", "RejectReason", "TransportStatus",
]
