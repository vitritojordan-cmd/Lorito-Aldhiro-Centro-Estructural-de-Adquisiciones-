from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Vigilante de RAM del proceso: estado OK/HIGH/CRITICAL con transiciones, un único dueño por proceso (LA-GOLDEN-CORE-020 §4).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


La memoria que mide es la del proceso, no la de una sesión de captura. Hasta
0.14.001 su estado vivía en un objeto de estado global y, por eso, era único
por proceso. Al pasar el estado de sesión al motor (0.14.002), quedaba uno
por ventana: cada ventana repetía la limpieza de emergencia (`gc.collect`,
decenas de ms en el hilo de la interfaz). Este vigilante devuelve el estado
a su dueño natural, el proceso; `services.lorito_app_services` crea el
único y la ventana lo usa a través de `self._services.ram_watchdog`.

Transiciones (las mismas de antes):
- por encima del umbral crítico: CRITICAL, y `update()` informa la entrada
  solo la primera vez (para liberar cachés una vez, no en cada tick);
- por encima del umbral alto: HIGH, solo si venía de OK;
- por debajo: OK.
"""

import threading
from typing import Callable, Optional, Tuple


class RamWatchdog:
    def __init__(self, high_mb: float, critical_mb: float, sampler: Callable[[], float]):
        self.high_mb = float(high_mb)
        self.critical_mb = float(critical_mb)
        self._sampler = sampler
        self._lock = threading.Lock()
        self.state = "OK"
        self.last_mb = 0.0

    def update(self) -> Tuple[float, str, Optional[str]]:
        """Mide y actualiza. Devuelve (MB, estado, estado al que se entró en
        esta llamada o None)."""
        mb = float(self._sampler())
        with self._lock:
            entered = None
            if mb > self.critical_mb:
                if self.state != "CRITICAL":
                    self.state = entered = "CRITICAL"
            elif mb > self.high_mb:
                if self.state == "OK":
                    self.state = entered = "HIGH"
            else:
                self.state = "OK"
            self.last_mb = mb
            return mb, self.state, entered

    def reset(self) -> None:
        """Vuelve a OK (inicio de una grabación nueva, como hasta 0.14.001)."""
        with self._lock:
            self.state = "OK"
