from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Snapshots inmutables y versionados del visor de onda y su worker con parada ordenada (LA-GOLDEN-VIEW-SIGSEGV-019).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Pipeline del visor de onda de archivo (Orden LA-GOLDEN-VIEW-SIGSEGV-019 §2
y §4):

    fuente (archivo de sesión) → lector por bloques → envolvente min/max por
    columna → WaveformSnapshot inmutable y versionado → señal Qt encolada →
    widget (acepta solo la generación vigente)

Propiedad y vida útil (Capa A):

- **La solicitud** (`WaveformRequest`) se arma en el hilo GUI con todo lo
  que el worker necesita: generación, ruta, tasa, ancho visible y modo de
  amplitud. El worker **nunca** toca el widget ni lee sus atributos.
- **El snapshot** es inmutable: arrays de solo lectura, generación, rango
  de frames, tasa, canales y longitud válida. Un snapshot de otra
  generación (fuente cambiada, `clear`, ventana cerrada) se rechaza.
- **El worker** atiende solo la última solicitud: las intermedias se
  descartan, nunca datos de captura. Se detiene con `stop()`, que pone un
  centinela y hace `join` con timeout; después de `stop` no emite nada.
  Así ninguna señal llega durante la finalización del intérprete.
- **Los fallos** de cálculo producen un snapshot `ok=False` con el error:
  el widget se degrada a VISOR NO DISPONIBLE y la captura no se entera.

Costo (§2): la envolvente es O(ancho) en memoria. Para cada columna se
toman min y max, sin decimar tomando una muestra cada N, así que preserva
los transitorios. El ancho se acota a `MAX_COLUMNS`.
"""

import queue
import threading
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

MAX_COLUMNS = 4096
MIN_COLUMNS = 256


@dataclass(frozen=True)
class WaveformRequest:
    generation: int
    path: str
    rate: int
    width: int
    view_mode: str = "NORMALIZED"


@dataclass(frozen=True)
class WaveformSnapshot:
    generation: int
    source: str
    rate: int
    channels: int
    frames: int
    columns: int
    mn: np.ndarray
    mx: np.ndarray
    peak_clip: bool
    ok: bool = True
    error: str = ""

    @property
    def valid_len(self) -> int:
        return int(min(len(self.mn), len(self.mx)))


def _freeze(a) -> np.ndarray:
    arr = np.ascontiguousarray(np.asarray(a, dtype=np.float32)).copy()
    arr.setflags(write=False)
    return arr


def clamp_columns(width: int) -> int:
    return int(min(max(int(width or 0), MIN_COLUMNS), MAX_COLUMNS))


_EMPTY = np.zeros(0, dtype=np.float32)
_EMPTY.setflags(write=False)


def failed_snapshot(req: WaveformRequest, error: str) -> WaveformSnapshot:
    # Sin reservar memoria: el camino degradado debe funcionar también
    # cuando la causa es MemoryError.
    z = _EMPTY
    return WaveformSnapshot(req.generation, req.path, req.rate, 0, 0, 0, z, z, False,
                            ok=False, error=error)


def compute_snapshot(req: WaveformRequest) -> WaveformSnapshot:
    """Función pura (sin Qt): envolvente del archivo de la solicitud."""
    from lorito_aldhiro.backend.telemetry.lorito_waveform_envelope import (
        compute_file_envelope, view,
    )
    W = clamp_columns(req.width)
    channels = 0
    try:
        try:
            mn, mx, _peak, total = compute_file_envelope(req.path, W)
        except Exception:
            import soundfile as sf
            mns, mxs = [], []
            with sf.SoundFile(req.path, "r") as f:
                total = f.frames
                channels = f.channels
                fpp = max(1, total // W)
                for chunk in f.blocks(blocksize=fpp, dtype="float32", always_2d=True):
                    mns.append(chunk.min(axis=0))
                    mxs.append(chunk.max(axis=0))
            mn = np.array(mns, dtype=np.float32)
            mx = np.array(mxs, dtype=np.float32)
        if mn.ndim == 2:
            channels = channels or mn.shape[1]
        if mn.shape[0] == 0:
            z = _freeze(np.zeros(MIN_COLUMNS))
            return WaveformSnapshot(req.generation, req.path, req.rate, channels,
                                    int(total or 0), 0, z, z, False)
        mn_c, mx_c, _scale, peak = view(mn, mx, req.view_mode)
        if not (np.all(np.isfinite(mn_c)) and np.all(np.isfinite(mx_c))):
            return failed_snapshot(req, "envolvente no finita")
        return WaveformSnapshot(req.generation, req.path, req.rate, channels, int(total),
                                int(len(mn_c)), _freeze(mn_c), _freeze(mx_c),
                                bool(peak >= 0.999))
    except MemoryError:
        return failed_snapshot(req, "memoria insuficiente para la envolvente")
    except Exception as e:
        return failed_snapshot(req, f"{type(e).__name__}: {e}")


@dataclass
class WorkerStats:
    submitted: int = 0
    computed: int = 0
    superseded: int = 0
    failed: int = 0
    emitted_after_stop: int = 0


class WaveformWorker:
    """Hilo único que calcula snapshots de la última solicitud. `emit` es
    la entrega al hilo GUI: en la app, una señal Qt encolada."""

    _STOP = object()

    def __init__(self, emit: Callable[[object, WaveformSnapshot], None],
                 compute: Callable[[WaveformRequest], WaveformSnapshot] = compute_snapshot):
        self._emit = emit
        self._compute = compute
        self._q: queue.Queue = queue.Queue(maxsize=8)
        self._lock = threading.Lock()
        self._stopped = False
        self.stats = WorkerStats()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="lorito-waveform")
        self._thread.start()

    @property
    def alive(self) -> bool:
        return self._thread.is_alive()

    def submit(self, target, req: WaveformRequest) -> bool:
        """Encola (target, req) descartando las solicitudes pendientes:
        solo importa la más reciente."""
        with self._lock:
            if self._stopped:
                return False
            while True:
                try:
                    self._q.get_nowait()
                    self.stats.superseded += 1
                except queue.Empty:
                    break
            self._q.put_nowait((target, req))
            self.stats.submitted += 1
            return True

    def stop(self, timeout: float = 2.0) -> bool:
        """Parada ordenada: después de esto no se emite nada."""
        with self._lock:
            if self._stopped:
                return not self._thread.is_alive()
            self._stopped = True
            while True:
                try:
                    self._q.get_nowait()
                except queue.Empty:
                    break
            self._q.put_nowait(self._STOP)
        self._thread.join(timeout)
        return not self._thread.is_alive()

    def _loop(self) -> None:
        while True:
            item = self._q.get()
            if item is self._STOP:
                return
            target, req = item
            snap = self._compute(req)
            with self._lock:
                if self._stopped:
                    return
                self.stats.computed += 1
                if not snap.ok:
                    self.stats.failed += 1
            try:
                self._emit(target, snap)
            except Exception:
                pass
