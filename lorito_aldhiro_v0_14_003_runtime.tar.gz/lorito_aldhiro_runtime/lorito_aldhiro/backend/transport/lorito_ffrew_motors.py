"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motores Golden de avance rápido y rebobinado con su TransportCoordinator (LA-GOLDEN-TRANSPORT-018).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Motores de avance rápido (FF) y rebobinado (REW) — Orden
LA-GOLDEN-TRANSPORT-018 (0.12).

Modo de operación (§1): Lorito Aldhiro no tiene deck físico, así que
funciona en **Modo A, transporte lógico de archivo**. FF y REW mueven la
posición lógica (frames enteros) sobre la fuente ya capturada. Nunca leen,
cargan ni escriben audio: el adaptador lógico solo guarda un índice de
frame. El adaptador físico (`PhysicalDeckAdapter`) existe para declarar con
honestidad que no hay hardware: queda `UNAVAILABLE` y no simula transporte
(TR-14).

Arquitectura (§2):

    UI → TransportCoordinator → estado exclusivo → WindMotor(FF | REW)
       → adaptador → posición confirmada + calidad → TransportSnapshot → UI

- **Un solo dueño del estado.** El coordinador serializa los comandos con un
  lock y rechaza los incompatibles con una razón tipada (`RejectReason`).
  Nunca hay dos motores activos.
- **Cambio de sentido.** FF ↔ REW pasa por una rampa de parada confirmada
  (DETENIENDO) antes de arrancar el otro motor; nunca se invierte la
  velocidad de golpe (TR-03).
- **Velocidad.** Las pulsaciones sucesivas del mismo botón suben el factor
  ×1 → ×2 → … → `max_factor` y luego vuelven a ×1. Hay límites separados
  para FF y REW. ×1 equivale a `base_rate` segundos de programa por segundo
  real. Las rampas de aceleración y frenado son lineales y acotadas.
- **Posición.** Es entera, en frames. El avance por tick se integra en
  aritmética entera (frames/s × ns con resto acarreado), sin acumular error
  de punto flotante (TR-07, TR-15). Cerca de los extremos el motor frena
  cinemáticamente y termina exactamente en 0 o en el total, nunca fuera de
  [0, total].
- **Reloj.** Monotónico en ns, inyectable para las pruebas.
- **Parada.** STOP solicita la rampa y espera la confirmación del adaptador.
  Si no llega en `stop_timeout_s`, el estado pasa a ERROR: no se finge
  STOPPED (§6, TR-05).
- **Errores.** Un error de E/S o de adaptador detiene el movimiento, congela
  la posición en el último valor confirmado y registra un diagnóstico
  (TR-08).
- **Captura.** Tiene prioridad. Con la captura activa FF/REW se rechazan
  (`CAPTURE_ACTIVE`, TR-06). Si la captura empieza durante un bobinado, el
  motor se cancela al instante.
- **Expulsión.** En Lorito es la salida al exportador. Solo empieza tras
  confirmar el estado seguro: con un bobinado en curso, primero se detiene
  y luego se expulsa (TR-12).
- **Monitor (§4).** Durante el bobinado el audio NO se presenta como
  reproducción normal: la política es `MUTED_SCAN`. Si se partió de PLAY,
  la reproducción se suspende y, al confirmarse la parada, se reanuda desde
  la posición confirmada (`resume_play` en la instantánea). La política es
  explícita y está probada.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Optional

NS = 1_000_000_000


class TransportStatus(str, Enum):
    STOPPED = "STOPPED"
    PLAYING = "PLAYING"
    PAUSED = "PAUSED"
    FAST_FORWARDING = "FAST_FORWARDING"
    REWINDING = "REWINDING"
    SEEKING = "SEEKING"
    CAPTURING = "CAPTURING"
    EJECTING = "EJECTING"
    ERROR = "ERROR"
    UNAVAILABLE = "UNAVAILABLE"


S = TransportStatus
MOVING = frozenset({S.FAST_FORWARDING, S.REWINDING})

# Transiciones permitidas (§2). Cualquier otra es un defecto del programa
# y lanza `InvalidTransition`.
ALLOWED_TRANSITIONS: dict = {
    S.STOPPED: {S.PLAYING, S.PAUSED, S.FAST_FORWARDING, S.REWINDING, S.SEEKING,
                S.CAPTURING, S.EJECTING, S.ERROR, S.UNAVAILABLE},
    S.PLAYING: {S.STOPPED, S.PAUSED, S.FAST_FORWARDING, S.REWINDING, S.SEEKING,
                S.CAPTURING, S.EJECTING, S.ERROR},
    S.PAUSED: {S.STOPPED, S.PLAYING, S.FAST_FORWARDING, S.REWINDING, S.SEEKING,
               S.CAPTURING, S.EJECTING, S.ERROR},
    # Un motor en marcha sale por parada confirmada, por límite, por error o
    # por la prioridad de la captura; FF ↔ REW directo NO está permitido.
    S.FAST_FORWARDING: {S.STOPPED, S.PLAYING, S.CAPTURING, S.ERROR},
    S.REWINDING: {S.STOPPED, S.PLAYING, S.CAPTURING, S.ERROR},
    S.SEEKING: {S.STOPPED, S.PLAYING, S.PAUSED, S.ERROR},
    S.CAPTURING: {S.STOPPED, S.ERROR},
    S.EJECTING: {S.STOPPED, S.ERROR},
    S.ERROR: {S.STOPPED, S.UNAVAILABLE},
    S.UNAVAILABLE: {S.STOPPED},
}


class MotorPhase(str, Enum):
    IDLE = "IDLE"
    RAMP_UP = "RAMP_UP"
    RUNNING = "RUNNING"
    STOPPING = "STOPPING"          # DETENIENDO
    STOPPED = "STOPPED"            # parada confirmada
    LIMIT = "LIMIT"                # LÍMITE ALCANZADO (parada en el extremo)
    CANCELLED = "CANCELLED"        # cancelado por prioridad (captura/cierre)
    FAILED = "FAILED"


class PositionQuality(str, Enum):
    EXACT_FRAMES = "EXACT_FRAMES"          # fuente digital, índice entero
    SENSOR_CONFIRMED = "SENSOR_CONFIRMED"  # deck con contador calibrado
    ESTIMATED = "ESTIMATED"
    UNKNOWN = "UNKNOWN"


class RejectReason(str, Enum):
    CAPTURE_ACTIVE = "CAPTURE_ACTIVE"
    NO_SOURCE = "NO_SOURCE"
    INHIBITED = "INHIBITED"          # p. ej. Morpher o exportación en curso
    EJECT_PENDING = "EJECT_PENDING"
    ERROR_STATE = "ERROR_STATE"
    UNAVAILABLE = "UNAVAILABLE"
    BUSY = "BUSY"                    # seek con un motor en marcha
    INVALID = "INVALID"


class LimitKind(str, Enum):
    START = "START"
    END = "END"


class InvalidTransition(RuntimeError):
    pass


class TransportIOError(RuntimeError):
    """Fallo del adaptador (E/S, hardware perdido, timeout del dispositivo)."""


# ═════════════════════════════════════════════════════════════════════════════
#  Perfil y adaptadores
# ═════════════════════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class SpeedProfile:
    """Perfiles de velocidad (§3). ×1 = `base_rate` s de programa por s real.
    Los límites de FF y REW son independientes. `ramp_s`: tiempo de rampa de
    0 a la velocidad máxima. `min_brake_rate`: velocidad mínima (× tiempo
    real) del frenado cinemático junto a un extremo, para que el motor llegue
    al límite en un tiempo acotado."""
    base_rate: float = 8.0
    max_factor_ff: int = 4
    max_factor_rew: int = 4
    ramp_s: float = 0.25
    min_brake_rate: float = 1.0
    stop_timeout_s: float = 1.0

    def max_factor(self, direction: int) -> int:
        return self.max_factor_ff if direction > 0 else self.max_factor_rew

    def next_factor(self, direction: int, factor: int) -> int:
        """×1 → ×2 → … → máximo → ×1 (una pulsación = un escalón)."""
        return 1 if factor >= self.max_factor(direction) else factor + 1


DEFAULT_PROFILE = SpeedProfile()


class LogicalFileAdapter:
    """Modo A: posición lógica sobre una fuente ya capturada. Solo guarda un
    índice entero de frame; nunca abre ni carga el audio (TR-07)."""

    mode = "LOGICAL"
    quality = PositionQuality.EXACT_FRAMES

    def __init__(self, total_frames: int = 0, sample_rate: int = 48000,
                 position_frame: int = 0):
        self.set_source(total_frames, sample_rate, position_frame)

    def set_source(self, total_frames: int, sample_rate: int, position_frame: int = 0) -> None:
        self.total_frames = max(0, int(total_frames))
        self.sample_rate = max(1, int(sample_rate))
        self._pos = min(max(0, int(position_frame)), self.total_frames)

    def available(self) -> bool:
        return True

    def read_position(self) -> int:
        return self._pos

    def write_position(self, frame: int) -> None:
        self._pos = int(frame)

    def stop_confirmed(self, velocity_fps: int) -> bool:
        return velocity_fps == 0


class PhysicalDeckAdapter:
    """Modo B sin hardware: Lorito no tiene un deck controlable. Declara
    `UNAVAILABLE` y posición desconocida; no simula transporte (TR-14)."""

    mode = "PHYSICAL"
    quality = PositionQuality.UNKNOWN
    total_frames = 0
    sample_rate = 48000

    def available(self) -> bool:
        return False

    def read_position(self) -> int:
        raise TransportIOError("no hay deck físico conectado")

    def write_position(self, frame: int) -> None:
        raise TransportIOError("no hay deck físico conectado")

    def stop_confirmed(self, velocity_fps: int) -> bool:
        return False


# ═════════════════════════════════════════════════════════════════════════════
#  Instantáneas y eventos
# ═════════════════════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class TransportEvent:
    kind: str                 # STATE, LIMIT_REACHED, STOP_CONFIRMED, REJECTED, ERROR, ...
    t_ns: int
    detail: str = ""


@dataclass(frozen=True)
class MotorStatus:
    phase: MotorPhase
    direction: int
    factor: int
    velocity_fps: int
    position_frame: int


@dataclass(frozen=True)
class TransportSnapshot:
    """Instantánea inmutable que la UI pinta (LCD, onda, scrub, carretes)."""
    state: TransportStatus
    phase: MotorPhase
    direction: int            # +1 FF, −1 REW, 0 quieto
    factor: int
    velocity_fps: int
    position_frame: int
    total_frames: int
    sample_rate: int
    quality: PositionQuality
    generation: int
    limit: Optional[LimitKind]
    resume_play: bool         # al confirmarse la parada, reanudar PLAY
    eject_ready: bool         # parada confirmada con expulsión pendiente
    error: str = ""

    @property
    def position_s(self) -> float:
        return self.position_frame / self.sample_rate if self.sample_rate else 0.0

    @property
    def fraction(self) -> float:
        return self.position_frame / self.total_frames if self.total_frames else 0.0

    @property
    def rate(self) -> float:
        """Velocidad con signo en × tiempo real (para los carretes)."""
        return self.velocity_fps / self.sample_rate if self.sample_rate else 0.0


@dataclass(frozen=True)
class CommandResult:
    accepted: bool
    reason: Optional[RejectReason] = None
    factor: int = 0
    detail: str = ""


# ═════════════════════════════════════════════════════════════════════════════
#  Motor
# ═════════════════════════════════════════════════════════════════════════════
class WindMotor:
    """Motor de bobinado en un sentido (+1 FF, −1 REW). No bloquea: el
    coordinador lo avanza con `tick(now_ns)`."""

    def __init__(self, direction: int, adapter, profile: SpeedProfile, now_ns: int):
        self.direction = 1 if direction > 0 else -1
        self._adapter = adapter
        self._profile = profile
        self.factor = 1
        self.phase = MotorPhase.IDLE
        self.velocity_fps = 0               # con signo
        self._rem = 0                       # resto de la integración (ns·frames)
        self._last_ns = now_ns
        self._stop_since_ns: Optional[int] = None
        self.limit: Optional[LimitKind] = None
        sr = adapter.sample_rate
        self._max_fps = int(round(profile.base_rate * profile.max_factor(self.direction) * sr))
        # Aceleración en frames/s²: de 0 al máximo en `ramp_s`.
        self._accel = max(1, int(round(self._max_fps / max(profile.ramp_s, 1e-3))))
        self._min_brake_fps = max(1, int(round(profile.min_brake_rate * sr)))

    # ── API (§2) ─────────────────────────────────────────────────────────────
    def start(self, factor: int = 1) -> None:
        self.factor = max(1, min(int(factor), self._profile.max_factor(self.direction)))
        self.phase = MotorPhase.RAMP_UP
        self._stop_since_ns = None

    def set_factor(self, factor: int) -> None:
        self.factor = max(1, min(int(factor), self._profile.max_factor(self.direction)))
        if self.phase == MotorPhase.RUNNING:
            self.phase = MotorPhase.RAMP_UP

    def request_stop(self, now_ns: int) -> None:
        if self.phase in (MotorPhase.RAMP_UP, MotorPhase.RUNNING):
            self.phase = MotorPhase.STOPPING
            self._stop_since_ns = now_ns

    def cancel(self) -> None:
        self.velocity_fps = 0
        self._rem = 0
        self.phase = MotorPhase.CANCELLED

    def target_fps(self) -> int:
        sr = self._adapter.sample_rate
        return int(round(self._profile.base_rate * self.factor * sr))

    def status(self) -> MotorStatus:
        return MotorStatus(self.phase, self.direction, self.factor, self.velocity_fps,
                           self._adapter.read_position())

    @property
    def active(self) -> bool:
        return self.phase in (MotorPhase.RAMP_UP, MotorPhase.RUNNING, MotorPhase.STOPPING)

    @property
    def stop_elapsed_ns(self) -> int:
        return 0 if self._stop_since_ns is None else self._last_ns - self._stop_since_ns

    # ── Integración ──────────────────────────────────────────────────────────
    def tick(self, now_ns: int) -> None:
        dt = max(0, int(now_ns) - self._last_ns)
        self._last_ns = int(now_ns)
        if not self.active or dt == 0:
            return
        total = self._adapter.total_frames
        pos = self._adapter.read_position()
        remaining = (total - pos) if self.direction > 0 else pos

        # Velocidad objetivo: 0 al detener; si no, la del factor, limitada
        # por el frenado cinemático junto al extremo: v ≤ √(2·a·d).
        speed = abs(self.velocity_fps)
        if self.phase == MotorPhase.STOPPING:
            target = 0
        else:
            target = self.target_fps()
            brake = int((2 * self._accel * max(remaining, 0)) ** 0.5)
            target = min(target, max(brake, self._min_brake_fps))
        step = (self._accel * dt) // NS
        if speed < target:
            speed = min(target, speed + max(1, step))
        elif speed > target:
            speed = max(target, speed - max(1, step))
        if self.phase == MotorPhase.RAMP_UP and speed == target:
            self.phase = MotorPhase.RUNNING

        # Avance entero: frames = (v·dt + resto) // 1e9, con el resto acarreado.
        acc = speed * dt + self._rem
        frames, self._rem = divmod(acc, NS)
        new = pos + self.direction * frames
        hit = None
        if new <= 0 and self.direction < 0:
            new, hit = 0, LimitKind.START
        elif new >= total and self.direction > 0:
            new, hit = total, LimitKind.END
        self._adapter.write_position(new)          # puede lanzar TransportIOError
        self.velocity_fps = self.direction * speed
        if hit is not None:
            self.velocity_fps = 0
            self._rem = 0
            self.limit = hit
            self.phase = MotorPhase.LIMIT
        elif self.phase == MotorPhase.STOPPING and speed == 0:
            if self._adapter.stop_confirmed(0):
                self._rem = 0
                self.phase = MotorPhase.STOPPED


# ═════════════════════════════════════════════════════════════════════════════
#  Coordinador
# ═════════════════════════════════════════════════════════════════════════════
class TransportCoordinator:
    """Dueño único del estado de transporte de Lorito (FF/REW, PLAY,
    captura y expulsión). Todos los métodos son no bloqueantes y se
    serializan con un lock; la UI los llama desde su hilo y pinta las
    instantáneas que devuelve `tick()`."""

    MAX_EVENTS = 256

    def __init__(self, adapter=None, profile: SpeedProfile = DEFAULT_PROFILE,
                 clock_ns: Callable[[], int] = time.monotonic_ns):
        self._lock = threading.RLock()
        self._adapter = adapter if adapter is not None else LogicalFileAdapter()
        self._profile = profile
        self._clock = clock_ns
        self._events: deque = deque(maxlen=self.MAX_EVENTS)
        self._motor: Optional[WindMotor] = None
        self._pending: Optional[tuple] = None        # (direction, factor) tras la parada
        self._resume_play = False
        self._resume_ready = False
        self._eject_cb: Optional[Callable[[], None]] = None
        self._eject_ready = False
        self._limit: Optional[LimitKind] = None
        self._error = ""
        self._generation = 0
        self._inhibitors: dict = {}
        self._state = S.STOPPED if self._adapter.available() else S.UNAVAILABLE
        self._last_good = self._safe_read()

    # ── utilidades ───────────────────────────────────────────────────────────
    def _now(self) -> int:
        return int(self._clock())

    def _emit(self, kind: str, detail: str = "") -> None:
        self._events.append(TransportEvent(kind, self._now(), detail))

    def _set_state(self, new: TransportStatus) -> None:
        if new == self._state:
            return
        if new not in ALLOWED_TRANSITIONS[self._state]:
            raise InvalidTransition(f"{self._state.value} → {new.value}")
        self._emit("STATE", f"{self._state.value}->{new.value}")
        self._state = new

    def _safe_read(self) -> int:
        try:
            return self._adapter.read_position()
        except TransportIOError:
            return 0

    def _fail(self, exc: BaseException) -> None:
        """§4: detener, congelar en el último valor confirmado y diagnosticar."""
        if self._motor is not None:
            self._motor.cancel()
            self._motor.phase = MotorPhase.FAILED
        try:
            self._adapter.write_position(self._last_good)
        except Exception:
            pass
        self._error = f"{type(exc).__name__}: {exc}"
        self._pending = None
        self._resume_play = False
        self._emit("ERROR", self._error)
        if self._state not in (S.ERROR, S.UNAVAILABLE):
            self._set_state(S.ERROR)

    # ── consultas ────────────────────────────────────────────────────────────
    @property
    def state(self) -> TransportStatus:
        return self._state

    @property
    def adapter(self):
        return self._adapter

    @property
    def profile(self) -> SpeedProfile:
        return self._profile

    def events(self) -> list:
        return list(self._events)

    def drain_events(self) -> list:
        with self._lock:
            out = list(self._events)
            self._events.clear()
            return out

    def is_moving(self) -> bool:
        return self._motor is not None and self._motor.active

    # ── fuente e inhibidores ─────────────────────────────────────────────────
    def set_source(self, total_frames: int, sample_rate: int, position_frame: int) -> None:
        """Nueva fuente o reposicionamiento externo (scrub). Solo en reposo:
        con un motor en marcha se ignora, la posición la gobierna el motor."""
        with self._lock:
            if self.is_moving() or self._state in (S.ERROR, S.UNAVAILABLE):
                return
            a = self._adapter
            if (a.total_frames, a.sample_rate) != (int(total_frames), int(sample_rate)):
                self._generation += 1
            a.set_source(total_frames, sample_rate, position_frame)
            self._last_good = a.read_position()

    def set_inhibitor(self, name: str, active: bool) -> None:
        """Inhibidores de diseño (Morpher, exportación…): FF/REW → INHIBITED."""
        with self._lock:
            if active:
                self._inhibitors[name] = True
            else:
                self._inhibitors.pop(name, None)

    # ── comandos de transporte ───────────────────────────────────────────────
    def press(self, direction: int, playing: bool = False) -> CommandResult:
        """Pulsación de FF (+1) o REW (−1). Misma dirección en marcha: sube el
        factor. Dirección contraria: rampa de parada y luego arranque."""
        d = 1 if direction > 0 else -1
        with self._lock:
            reason = self._reject_reason()
            if reason is not None:
                self._emit("REJECTED", reason.value)
                return CommandResult(False, reason)
            m = self._motor
            if m is not None and m.active:
                if m.direction == d and m.phase != MotorPhase.STOPPING:
                    m.set_factor(self._profile.next_factor(d, m.factor))
                    self._emit("FACTOR", f"{'FF' if d > 0 else 'REW'} x{m.factor}")
                    return CommandResult(True, factor=m.factor)
                # Contraria (o ya deteniéndose): parada confirmada y luego arranque.
                if self._pending is not None and self._pending[0] == d:
                    nf = self._profile.next_factor(d, self._pending[1])
                else:
                    nf = 1
                self._pending = (d, nf)
                m.request_stop(self._now())
                self._emit("REVERSE_PENDING", f"{'FF' if d > 0 else 'REW'} x{nf}")
                return CommandResult(True, factor=nf, detail="tras parada")
            if self._state == S.PLAYING or playing:
                self._resume_play = True
            self._start_motor(d, 1)
            return CommandResult(True, factor=1)

    def _reject_reason(self) -> Optional[RejectReason]:
        if self._state == S.UNAVAILABLE or not self._adapter.available():
            return RejectReason.UNAVAILABLE
        if self._state == S.ERROR:
            return RejectReason.ERROR_STATE
        if self._state == S.CAPTURING:
            return RejectReason.CAPTURE_ACTIVE
        if self._state == S.EJECTING or self._eject_cb is not None:
            return RejectReason.EJECT_PENDING
        if self._adapter.total_frames <= 0:
            return RejectReason.NO_SOURCE
        if self._inhibitors:
            return RejectReason.INHIBITED
        return None

    def _start_motor(self, d: int, factor: int) -> None:
        self._motor = WindMotor(d, self._adapter, self._profile, self._now())
        self._motor.start(factor)
        self._limit = None
        self._resume_ready = False
        self._eject_ready = False
        if self._state in (S.PLAYING, S.PAUSED):
            self._set_state(S.STOPPED)
        self._set_state(S.FAST_FORWARDING if d > 0 else S.REWINDING)
        self._emit("START", f"{'FF' if d > 0 else 'REW'} x{factor}")

    def stop(self, resume_play: bool = False) -> CommandResult:
        """STOP: con un motor en marcha pide la rampa y espera la
        confirmación (la da `tick`). Sin motor, no hay nada que detener.
        `resume_play=True` (PLAY pulsado durante el bobinado): al confirmarse
        la parada, la instantánea pide reanudar desde la posición confirmada."""
        with self._lock:
            self._pending = None
            self._resume_play = bool(resume_play)
            if self.is_moving():
                self._motor.request_stop(self._now())
                self._emit("STOP_REQUESTED")
                return CommandResult(True, detail="parada en curso")
            return CommandResult(True, detail="sin movimiento")

    def seek(self, frame: int) -> CommandResult:
        """Posicionamiento directo. Política (§3): con un motor activo se
        rechaza (BUSY): nunca dos tareas de movimiento."""
        with self._lock:
            if self.is_moving():
                return CommandResult(False, RejectReason.BUSY)
            if self._state in (S.CAPTURING, S.ERROR, S.UNAVAILABLE, S.EJECTING):
                return CommandResult(False, self._reject_reason() or RejectReason.INVALID)
            prev = self._state
            self._set_state(S.SEEKING)
            try:
                f = min(max(0, int(frame)), self._adapter.total_frames)
                self._adapter.write_position(f)
                self._last_good = f
            except TransportIOError as e:
                self._fail(e)
                return CommandResult(False, RejectReason.ERROR_STATE, detail=self._error)
            self._set_state(prev if prev in (S.PLAYING, S.PAUSED) else S.STOPPED)
            return CommandResult(True)

    # ── estado externo: reproducción, captura, expulsión ────────────────────
    def set_playing(self, playing: bool) -> None:
        with self._lock:
            if self.is_moving() or self._state in (S.CAPTURING, S.ERROR, S.UNAVAILABLE,
                                                   S.EJECTING):
                return
            self._set_state(S.PLAYING if playing else S.STOPPED)

    def capture_started(self) -> None:
        """Prioridad de seguridad: la captura cancela cualquier bobinado."""
        with self._lock:
            if self._motor is not None and self._motor.active:
                self._motor.cancel()
                self._emit("CANCELLED", "captura")
            self._pending = None
            self._resume_play = False
            if self._state in (S.UNAVAILABLE, S.CAPTURING):
                return
            if self._state in (S.ERROR, S.EJECTING, S.SEEKING):
                # La captura no depende del transporte lógico: un error de
                # FF/REW o una expulsión no la bloquean.
                self._eject_cb = None
                self._eject_ready = False
                self._set_state(S.STOPPED)
            self._set_state(S.CAPTURING)

    def capture_stopped(self) -> None:
        with self._lock:
            if self._state == S.CAPTURING:
                self._set_state(S.STOPPED)

    def request_eject(self, on_ready: Callable[[], None]) -> CommandResult:
        """Expulsión (salida al exportador). Solo tras estado seguro: con un
        motor en marcha se detiene primero y `on_ready` se llama al confirmar."""
        with self._lock:
            if self._state in (S.CAPTURING, S.ERROR, S.UNAVAILABLE):
                return CommandResult(False, self._reject_reason())
            self._eject_cb = on_ready
            self._pending = None
            self._resume_play = False
            if self.is_moving():
                self._motor.request_stop(self._now())
                self._emit("EJECT_PENDING")
                return CommandResult(True, detail="tras parada")
        self._begin_eject()
        return CommandResult(True)

    def _begin_eject(self) -> None:
        with self._lock:
            cb, self._eject_cb = self._eject_cb, None
            if self._state in (S.PLAYING, S.PAUSED):
                self._set_state(S.STOPPED)
            self._set_state(S.EJECTING)
            self._eject_ready = True
        if cb is not None:
            cb()

    def eject_done(self) -> None:
        with self._lock:
            self._eject_ready = False
            if self._state == S.EJECTING:
                self._set_state(S.STOPPED)

    def reset_error(self) -> None:
        with self._lock:
            if self._state == S.ERROR:
                self._error = ""
                self._motor = None
                self._set_state(S.STOPPED if self._adapter.available() else S.UNAVAILABLE)

    def shutdown(self) -> None:
        """Cierre de la UI: el motor pasa a estado seguro (cancelado)."""
        with self._lock:
            if self._motor is not None and self._motor.active:
                self._motor.cancel()
                self._emit("CANCELLED", "cierre")
            self._pending = None
            self._resume_play = False
            if self._state in MOVING:
                self._set_state(S.STOPPED)

    # ── tick ─────────────────────────────────────────────────────────────────
    def tick(self, now_ns: Optional[int] = None) -> TransportSnapshot:
        """Avanza el motor (O(1)) y devuelve la instantánea confirmada."""
        eject = False
        with self._lock:
            now = self._now() if now_ns is None else int(now_ns)
            m = self._motor
            if m is not None and m.active and self._state in MOVING:
                try:
                    m.tick(now)
                    self._last_good = self._adapter.read_position()
                except TransportIOError as e:
                    self._fail(e)
                else:
                    if m.phase == MotorPhase.STOPPING and \
                            m.stop_elapsed_ns > self._profile.stop_timeout_s * NS:
                        self._fail(TransportIOError("timeout esperando la confirmación de parada"))
                    elif m.phase in (MotorPhase.STOPPED, MotorPhase.LIMIT):
                        eject = self._on_motor_stopped(m)
            snap = self._snapshot_locked()
            self._resume_ready = False
        if eject:
            self._begin_eject()
            with self._lock:
                snap = self._snapshot_locked()
        return snap

    def _on_motor_stopped(self, m: WindMotor) -> bool:
        if m.phase == MotorPhase.LIMIT:
            self._limit = m.limit
            self._emit("LIMIT_REACHED", m.limit.value)
        self._emit("STOP_CONFIRMED", f"frame={self._adapter.read_position()}")
        self._set_state(S.STOPPED)
        if self._eject_cb is not None:
            self._resume_play = False
            return True
        if self._pending is not None:
            d, f = self._pending
            self._pending = None
            if not (m.phase == MotorPhase.LIMIT and self._blocked_at_limit(d)):
                self._start_motor(d, f)
                return False
        if self._resume_play:
            self._resume_play = False
            if self._adapter.read_position() < self._adapter.total_frames:
                self._resume_ready = True
                self._set_state(S.PLAYING)
        return False

    def _blocked_at_limit(self, d: int) -> bool:
        pos, total = self._adapter.read_position(), self._adapter.total_frames
        return (d > 0 and pos >= total) or (d < 0 and pos <= 0)

    def _snapshot_locked(self) -> TransportSnapshot:
        m = self._motor
        a = self._adapter
        try:
            pos = a.read_position()
        except TransportIOError:
            pos = self._last_good
        moving = m is not None and m.active and self._state in MOVING
        return TransportSnapshot(
            state=self._state,
            phase=m.phase if m is not None else MotorPhase.IDLE,
            direction=m.direction if moving else 0,
            factor=m.factor if moving else 0,
            velocity_fps=m.velocity_fps if moving else 0,
            position_frame=pos,
            total_frames=a.total_frames,
            sample_rate=a.sample_rate,
            quality=a.quality if self._state != S.ERROR else PositionQuality.ESTIMATED,
            generation=self._generation,
            limit=self._limit,
            resume_play=self._resume_ready,
            eject_ready=self._eject_ready,
            error=self._error,
        )

    def snapshot(self) -> TransportSnapshot:
        with self._lock:
            return self._snapshot_locked()
