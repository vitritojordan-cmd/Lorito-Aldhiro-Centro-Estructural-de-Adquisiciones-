from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Transacciones de transporte con ID/generación/confirmación y libro de contadores por sesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

lorito_transport_ledger.py — Orden Golden Scrubs Morpher / Velocista /
Seek (SMV-05, SMV-06, SMV-08, SMV-14).

  · `TransportTransaction`: cada intención de la UI (seek, live, commit,
    stop) recibe `command_id` monotónico y se encola; el hilo de render
    la aplica EN ORDEN, le asigna `transport_generation` y la confirma
    cuando el primer bloque de esa generación queda publicado en el ring
    audible. Un seek pendiente reemplazado por otro posterior queda
    SUPERSEDED de forma determinista (sin ventanas de debounce).
  · `TransportLedger`: contadores por SESIÓN de reproducción (no estado
    global de módulo: sustituye a `_frn_state['phase_prev_cursor']`).
"""

import collections
import itertools
import time
from dataclasses import dataclass, field

PENDING, APPLIED, CONFIRMED, SUPERSEDED, REJECTED = (
    "PENDING", "APPLIED", "CONFIRMED", "SUPERSEDED", "REJECTED")

_IDS = itertools.count(1)   # next() es atómico bajo el GIL


@dataclass
class TransportTransaction:
    kind: str                      # SEEK | LIVE | COMMIT | STOP
    value: float | None
    source: str = ""
    command_id: int = field(default_factory=lambda: next(_IDS))
    session_generation: int = 0
    transport_generation: int | None = None
    status: str = PENDING
    reason: str = ""
    t_submit: float = field(default_factory=time.monotonic)
    t_apply: float | None = None
    t_confirm: float | None = None
    # Orden SERVO-016 §6 (tiempo de respuesta): época de velocidad que
    # produjo el comando y el instante en que el callback la hizo AUDIBLE.
    epoch: int | None = None
    t_audible: float | None = None

    def as_dict(self) -> dict:
        return {k: getattr(self, k) for k in (
            "command_id", "kind", "value", "source", "session_generation",
            "transport_generation", "status", "reason", "t_submit", "t_apply",
            "t_confirm", "epoch", "t_audible")}


@dataclass
class TransportLedger:
    commands_submitted: int = 0
    commands_applied: int = 0
    commands_confirmed: int = 0
    commands_superseded: int = 0
    commands_rejected: int = 0
    commands_out_of_order: int = 0
    live_coalesced: int = 0
    blocks_published: int = 0
    blocks_consumed: int = 0
    stale_dropped_before_ring: int = 0
    stale_discarded_in_callback: int = 0
    stale_consumed: int = 0
    mixed_generation_events: int = 0
    underrun_events: int = 0
    underrun_frames: int = 0
    last_underrun_generation: int = -1
    transitions: dict = field(default_factory=lambda: collections.Counter())
    degraded_transitions: int = 0
    last_command_id_applied: int = 0
    # Orden SERVO-016 §6: política de entradas fuera de rango y servicio.
    inputs_rejected: int = 0       # ratio no finito: comando rechazado
    ratio_clamped: int = 0         # ratio fuera de ±PE_MAX_RATIO: recortado y declarado
    seek_clamped: int = 0          # destino fuera de [0, total−1]: recortado y declarado
    starved_episodes: int = 0      # episodios de underrun prolongado (estado STARVED)
    slow_reads: int = 0            # bloques cuyo render tardó más que su duración

    def as_dict(self) -> dict:
        d = {k: getattr(self, k) for k in self.__dataclass_fields__ if k != "transitions"}
        d["transitions"] = dict(self.transitions)
        return d
