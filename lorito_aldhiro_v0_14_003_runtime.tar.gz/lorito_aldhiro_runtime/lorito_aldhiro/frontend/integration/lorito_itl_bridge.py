from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Puente de integración con el sistema ITL.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import logging
from lorito_aldhiro.backend.core.lorito_identity import logger_name


# ── Motor Inteligente de Transporte de Cinta (ITL) — v2.0.0 (CLCC-ITL) ───────
# Integrado directamente en Lorito Aldhiro (antes: import opcional de un
# módulo externo `itl_integration`, ausente del tarball — ver
# GAP-008). El motor vive ahora en `lorito_itl_integration.py`, junto al
# resto del paquete frontend, con el fix FIX-FORCED-PAUSE-ESCAPE aplicado
# (bug histórico "nunca se podía voltear a Lado B", auditado contra el monolito de origen).
try:
    from lorito_aldhiro.frontend.integration.lorito_itl_integration import integrate_itl_into_studio
    _ITL_AVAILABLE = True
except ImportError:
    _ITL_AVAILABLE = False
    _log_placeholder = logging.getLogger(logger_name())
    _log_placeholder.warning(
        "lorito_itl_integration no pudo importarse — "
        "motor ITL desactivado; funcionamiento sin cambio."
    )
