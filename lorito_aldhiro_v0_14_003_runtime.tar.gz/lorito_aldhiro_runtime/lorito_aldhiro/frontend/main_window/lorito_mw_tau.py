"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: TAU en la ventana principal: patrón según el resultado confirmado de cada botón y leyenda TAU sincronizada en el LCD (LA-TAU-OI-001).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""

TAU en la ventana (Orden LA-TAU-OI-001 §5). El botón decide primero y TAU
confirma después, sin cambiar la lógica del botón. Cada envoltorio mira el
estado ANTES y DESPUÉS de la acción, y solo pide un patrón si el cambio
ocurrió de verdad:

| Control | Activación (1 pitido) | Desactivación (2 pitidos) |
|---|---|---|
| REC | el motor confirmó la apertura (`rec_engine_ready(True)`) | — (lo cierra STOP) |
| PAUSA | la grabación quedó en pausa | la grabación se reanudó |
| PLAY | la reproducción arrancó | — |
| ◀◀ / ▶▶ | el coordinador ACEPTÓ la pulsación | — |
| STOP | — | se detuvo algo que estaba activo (captura, reproducción o bobinado) |
| OPTAPE: ALC, MPX, FOCUS, HX PRO | quedó encendido | quedó apagado |
| DSP → DITHER | TPDF elegido | dither apagado |

Una acción rechazada o sin efecto no suena. Quedan fuera del alcance
inicial (§5, controles no binarios) las selecciones de varios valores
(CINTA, HOST, MUESTRA, BITDEPH, perfiles NR, EQ/BIAS), ACERCA y EXPULSAR.

**Leyenda.**

- Se enciende y se apaga con los eventos del secuenciador, que el callback
  de audio entrega por una señal Qt encolada.
- Un temporizador de seguridad la apaga si no llega el `end` (excepción o
  dispositivo perdido).
- El cierre de la ventana la limpia.
"""

import itertools

from PySide6.QtCore import QTimer

from lorito_aldhiro.backend.services.lorito_ui_api import TAU_ACTIVATE, TAU_DEACTIVATE, tau_pattern_frames
from lorito_aldhiro.backend.services.lorito_app_services import make_tau_service

# Identidades únicas de los servicios TAU en el puente. Hasta 0.14.001 se
# usaba id(servicio): al liberarse un servicio, CPython puede reutilizar
# ese id para el siguiente, y un evento encolado del anterior se aceptaba
# como propio (apagaba la leyenda antes de tiempo).
_TAU_TOKENS = itertools.count(1)
from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge

_OPTAPE_FLAGS = {"ALC": "alc_active", "MPX": "mpx_active",
                 "FOCUS": "focus_active", "HX_PRO": "hx_pro_active"}


class TauMixin:
    """Mixin de la ventana principal (ver docstring del módulo)."""

    def _tau_init(self, service=None) -> None:
        self._tau_service = service or self._tau_make_service()
        self._tau_safety = QTimer(self)
        self._tau_safety.setSingleShot(True)
        self._tau_safety.timeout.connect(self._tau_safety_timeout)
        _bridge.tau_events.connect(self._on_tau_events)
        _bridge.tau_failed.connect(self._on_tau_failed)

    @staticmethod
    def _tau_make_service(**kw):
        """Servicio TAU cuyos eventos viajan por el puente con la identidad
        del servicio: cada ventana atiende SOLO los de su propio servicio."""
        svc = make_tau_service(**kw)
        token = next(_TAU_TOKENS)
        svc.bridge_token = token
        svc.on_events = lambda ev: _bridge.tau_events.emit((token, list(ev)))
        svc.on_failure = lambda why: _bridge.tau_failed.emit(f"{token}|{why}")
        return svc

    def _tau_owns(self, token) -> bool:
        svc = vars(self).get("_tau_service")
        return svc is not None and token == getattr(svc, "bridge_token", None)

    # ── solicitud ────────────────────────────────────────────────────────
    def _tau(self, activated: bool) -> bool:
        svc = vars(self).get("_tau_service")
        if svc is None:
            return False
        return svc.signal(TAU_ACTIVATE if activated else TAU_DEACTIVATE)

    # ── LCD (hilo GUI) ───────────────────────────────────────────────────
    def _on_tau_events(self, payload) -> None:
        """`payload` = (identidad del servicio, eventos). La señal del puente
        es global: los eventos de otro servicio (otra ventana) se ignoran."""
        if isinstance(payload, tuple):
            token, events = payload
            if not self._tau_owns(token):
                return
        else:
            events = payload                     # llamada directa (pruebas)
        if not events or not hasattr(self, "clock"):
            return
        lit = events[-1][0] == "start"           # [end, start] → sigue encendida
        self.clock.set_tau_lit(lit)
        if lit:
            p = self._tau_service.p
            worst = tau_pattern_frames(TAU_DEACTIVATE, p) / p.rate
            self._tau_safety.start(int(worst * 1000) + 750)
        else:
            self._tau_safety.stop()

    def _on_tau_failed(self, msg: str) -> None:
        token, _, why = str(msg).partition("|")
        if why and not self._tau_owns(int(token) if token.isdigit() else token):
            return
        _log.warning("TAU: %s", why or msg)
        self._tau_clear()

    def _tau_safety_timeout(self) -> None:
        _log.warning("TAU: fin de señal no recibido; se limpia la leyenda")
        self._tau_clear()

    def _tau_clear(self) -> None:
        if vars(self).get("_tau_safety") is not None:
            self._tau_safety.stop()
        if hasattr(self, "clock"):
            self.clock.set_tau_lit(False)

    def _tau_shutdown(self) -> None:
        svc = vars(self).get("_tau_service")
        if svc is not None:
            svc.shutdown()
        self._tau_clear()

    # ── envoltorios de botones (resultado confirmado) ────────────────────
    def _tau_click_pause(self) -> None:
        before = bool(self._engine.recording and self._engine.paused)
        rec = bool(self._engine.recording)
        self.toggle_pause()
        after = bool(self._engine.recording and self._engine.paused)
        if rec and after != before:
            self._tau(after)

    def _tau_click_play(self) -> None:
        was = bool(vars(self).get("_playing", False))
        self.play_audio()
        if not was and vars(self).get("_playing", False):
            self._tau(True)

    def _tau_click_stop(self) -> None:
        tc = vars(self).get("_transport")
        was_rec = bool(self._engine.recording)
        was_play = bool(vars(self).get("_playing", False))
        was_wind = bool(tc is not None and tc.is_moving())
        self.stop_all()
        wind_res = vars(self).get("_last_wind_stop")
        stopped = ((was_rec and not self._engine.recording) or
                   (was_play and not vars(self).get("_playing", False)) or
                   (was_wind and bool(getattr(wind_res, "accepted", False))))
        if stopped:
            self._tau(False)

    def _tau_click_ffrew(self, direction: int) -> None:
        if self._ffrew_press(direction):
            self._tau(True)

    def _tau_rec_confirmed(self, ok: bool) -> None:
        if ok:
            self._tau(True)

    def _tau_optape(self, which: str, impl) -> None:
        attr = _OPTAPE_FLAGS.get(which)
        coord = vars(self).get("_nr_coordinator")
        before = getattr(coord, attr, None) if attr and coord is not None else None
        impl(which)
        if attr and coord is not None:
            after = getattr(coord, attr, None)
            if before is not None and after is not None and bool(after) != bool(before):
                self._tau(bool(after))
