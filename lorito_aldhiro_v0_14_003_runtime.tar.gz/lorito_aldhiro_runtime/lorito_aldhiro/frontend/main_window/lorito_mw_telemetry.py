"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Telemetría en vivo: estado del motor, progreso de exportación, VU, forma de onda, archival.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import time
import gc
from PySide6.QtCore import QTimer

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.core.lorito_constants import (ARCHIVAL_SAFE_FPS,
    ARCHIVAL_SAFE_WATCHDOG,
    DRIFT_WARN_MS,
    SILENCE_ANALYSIS_INTERVAL_MS,
    SNAPSHOT_INTERVAL_SECS)
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import ExportSaveDialog





class TelemetryMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _on_backend_status(self, msg: str):
        _elog = getattr(self, "_event_log", None)
        if _elog is not None and not msg.startswith("__"):
            _elog.emit("ui.status", "INFO", "STATUS_MSG", data={"text": msg})
        if msg == "__EXPORT_DONE__":
            self._norm_blink_timer.stop()
            self.status_label.setText("__NORM_BLINK_OFF__")
            self._ui_state = ""  # forzar re-aplicación
            self._set_ui_state("standby")
            self._sync_buttons()
            # ── Cierre diferido post-export (CierreAbrupto "No") ──────────
            # Si el export fue lanzado desde closeEvent (guardar y cerrar),
            # disparamos el cierre ahora que el guardado terminó.
            if getattr(self, "_pending_close_after_export", False):
                self._pending_close_after_export = False
                QTimer.singleShot(80, self.close)   # breve pausa para que la UI se actualice
            return
        if msg == "__NORM_BLINK_ON__":
            self.status_label.setText("__NORM_BLINK_ON__")
            if not self._norm_blink_timer.isActive():
                self._norm_blink_timer.start()
            return
        # CAROLA DELICADA: arrancar timer de parpadeo al recibir la advertencia
        # y detenerlo tan pronto el nivel cambie a cualquier otro mensaje.
        if msg.startswith("__DRIFT_FRAMES_WARN__"):
            self.status_label.setText(msg)
            if not self._drift_frames_blink_timer.isActive():
                self._drift_frames_blink_timer.start()
            return
        # CAROLA ESTÁ APROBANDO: arrancar/detener timer de parpadeo celeste/verde
        if msg == "__EXPORT_VALIDATING_START__":
            self.status_label.setText("__EXPORT_VALIDATING_START__")
            return
        if msg == "__EXPORT_VALIDATING_STOP__":
            self.status_label.setText("__EXPORT_VALIDATING_STOP__")
            return
        # Cualquier otro mensaje distinto detiene el parpadeo de CAROLA DELICADA
        if self._drift_frames_blink_timer.isActive():
            self._drift_frames_blink_timer.stop()
        self.status_label.setText(msg)
    def _on_export_progress(self, codec: str, norm_val: str, pct: int):
        """
        Slot conectado a _bridge.export_progress (GUI thread).
        Gestiona el ciclo de vida del ExportSaveDialog:
          · pct == 0   → crea y muestra el diálogo (si no existe)
          · 0 < pct < 100 → actualiza la barra de progreso
          · pct == 100 → avanza la barra al 100 % y el diálogo se cierra solo
          · pct == -1  → cierre forzado (error o finally), sin importar el valor
        """
        if pct == -1:
            # Cierre forzado: error durante el export
            if self._export_save_dlg is not None:
                self._export_save_dlg.done(0)
                self._export_save_dlg = None
            # Limpiar overlay "Export" del contómetro (GAP-010) — el export
            # terminó (con error), ya no debe seguir mostrándose.
            if hasattr(self, "clock"):
                self.clock.setOverlay("EXPORT", False)
            return

        if self._export_save_dlg is None:
            # Primera emisión: crear y mostrar el diálogo
            self._export_save_dlg = ExportSaveDialog(codec, norm_val, self)
            self._export_save_dlg.finished.connect(
                lambda: setattr(self, "_export_save_dlg", None)
            )
            self._export_save_dlg.show()

        self._export_save_dlg.set_progress(pct)
        if pct >= 100 and hasattr(self, "clock"):
            # Limpiar overlay "Export" del contómetro (GAP-010) — export
            # completado con éxito.
            self.clock.setOverlay("EXPORT", False)
    def _on_vu_ready(self, rms_l: float, rms_r: float):
        """Recibe nivel de VU desde audio thread (vía señal queued).
        Siempre ejecutado en el main/GUI thread — safe para Wayland SHM.
        """
        if hasattr(self, "vu"):
            self.vu.setValues(rms_l, rms_r)
            self.vu.update()   # update() AQUÍ = main thread = seguro
    def _on_tape_update(self):
        """Pulso de animación para TapeLogPanel — main thread únicamente."""
        for attr in ("tape_log_a", "tape_log_b"):
            tl = getattr(self, attr, None)
            if tl is not None:
                tl.update()
    def _tick_vu_redraw(self):
        """Llamado desde _tick() (GUI timer, 15 Hz) para repaints pendientes.
        Centraliza todos los update() de widgets visuales en el GUI timer,
        eliminando el patrón de update() disperso en métodos llamados
        desde threads de audio.
        """
        # Waveform pendiente
        if hasattr(self, "waveform") and self.waveform._pending_update:
            self.waveform._pending_update = False
            self.waveform.update()
        # FIX-VUMETERS-FROZEN: repintar VU meters a 15 Hz como respaldo al
        # update() de _tick_cassette (24 Hz). Cubre el caso en que los datos
        # se actualizaron en _tick() pero _tick_cassette aun no corrio.
        # Seguro: _tick_vu_redraw siempre corre en el GUI thread (QTimer).
        if hasattr(self, "vu_rec"):
            self.vu_rec.update()
        if hasattr(self, "vu_play"):
            self.vu_play.update()
        # StatusDisplay (si tiene dirty interno)
        if hasattr(self, "status_label"):
            pass  # StatusDisplay ya tiene update() en setText -- OK en GUI timer
    def _on_waveform_snapshot(self, waveform_widget, snap):
        """Slot Qt (hilo GUI, conexión encolada): aplica el snapshot del
        worker solo si el widget sigue vivo (objeto C++ válido) y la
        generación es la vigente (Orden VIEW-SIGSEGV-019, WAV-03/SIG-03)."""
        try:
            import shiboken6
            if not shiboken6.isValid(waveform_widget):
                return
        except ImportError:
            pass
        apply = getattr(waveform_widget, "apply_snapshot", None)
        if apply is not None:
            apply(snap)

    def _on_recovery_msg(self, msg: str):
        self.status_label.setText(msg)
    def _on_stream_died(self):
        """GUI responde al stream muerto: actualiza indicadores sin cerrarse."""
        self.ind.setState("standby")
        self.status_label.setText("__STREAM_SLEEP__")
        self._stream_sleep_blink_timer.start()
    def _update_internal_status(self):
        """Actualiza buf_label con telemetría compacta v0.08 (1 Hz)."""
        # Telemetría RAM
        # El estado de RAM es del proceso (un único vigilante, ver
        # lorito_ram_watchdog); aquí se copia al estado de la sesión.
        ram_mb, ram_state, entered = self._services.ram_watchdog.update()
        self._session_status.ram_mb_approx = ram_mb
        self._session_status.ram_state = ram_state
        if entered == "CRITICAL":
            _log.error("RAM CRITICAL: %.0f MB — liberando caches", ram_mb)
            self._emergency_free_memory()
        elif entered == "HIGH":
            _log.warning("RAM HIGH: %.0f MB", ram_mb)

        if self._engine.recording and not self._engine.paused:
            xr   = self._session_status.xrun_count
            qs   = getattr(self._session_status, 'ced_frame_count', 0)
            q_pct= int(getattr(self._session_status, 'ced_pressure_pct', 0.0))
            bp   = self._session_status.backpressure_state[0]   # S/H/C/E
            drift_ms = self._session_status.drift_ms
            jit  = self._session_status.callback_jitter_ms
            mbps = self._session_status.disk_mbps
            ar   = "SAFE" if not self._archival_safe else "ARCH"
            # Formato compacto v0.08:
            # RT OK | XR:0 | Q:12% | RAM:210MB | DRIFT:0.2ms
            parts = [
                f"{'RT' if self._session_status.stream_alive else 'XX'} {ar[:2]}",
                f"XR:{xr}",
                f"Q:{q_pct}%",
                f"RAM:{ram_mb:.0f}MB",
                f"DRIFT:{drift_ms:.1f}ms",
            ]
            if mbps > 0:
                parts.append(f"{mbps:.1f}MB/s")
            if jit > 10:
                parts.append(f"JIT:{jit:.0f}ms")
            self.buf_label.setText(" | ".join(parts))

            # ── Detección de tendencia del RBA (anti-skip buffer) ─────────────
            # Solo monitorear si el motor tiene RBA accesible.
            # Umbral de tendencia: Δwm > +0.05 (llenando) / < -0.05 (vaciando).
            # Histéresis: 3 ticks consecutivos en la misma dirección antes de
            # cambiar el estado visible (evita parpadeo por fluctuaciones breves).
            _rba_wm_raw = getattr(self._session_status, 'rba_watermark_pct', -1.0)
            if _rba_wm_raw >= 0:
                _rba_wm = _rba_wm_raw / 100.0   # normalizar a 0.0–1.0
                if self._rba_prev_wm >= 0:
                    _delta = _rba_wm - self._rba_prev_wm
                    _TREND_THRESH = 0.05           # 5% de cambio por tick
                    _HYST_TICKS   = 3              # ticks consecutivos requeridos
                    if _delta > _TREND_THRESH:
                        _new_dir = "llena"
                    elif _delta < -_TREND_THRESH:
                        _new_dir = "vacia"
                    else:
                        _new_dir = "none"
                    if _new_dir == self._rba_vasito:
                        self._rba_tick_count += 1
                    else:
                        self._rba_tick_count = 1 if _new_dir != "none" else 0
                        self._rba_vasito = _new_dir
                    # Emitir leyenda solo cuando se alcanza el umbral de histéresis
                    if self._rba_tick_count == _HYST_TICKS:
                        if self._rba_vasito == "llena":
                            self.status_label.setText("__VASITO_LLENA__")
                        elif self._rba_vasito == "vacia":
                            self.status_label.setText("__VASITO_VACIA__")
                self._rba_prev_wm = _rba_wm
        else:
            # Fuera de grabación: resetear seguimiento del RBA
            self._rba_prev_wm    = -1.0
            self._rba_vasito     = "none"
            self._rba_tick_count = 0

        # ── Leyenda de reposo total ───────────────────────────────────────────
        # "CAROLALDHIRA ACTIVA!" en blanco puro SOLO cuando no hay NINGUNA
        # actividad: sin grabación, sin reproducción, sin morpher, sin vaciado.
        # Durante reproducción el log lo gestiona _on_seek_ready / _on_speed_changed
        # / _on_morpher_changed directamente — este tick NO debe pisarlos.
        is_idle = (
            not self._engine.recording
            and not self._playing
            and not self._morpher_active
            and self._ui_state not in ("rec", "pause", "stop", "play", "export")
            and self.status_label._level in ("idle", "activa",
                                             "ok", "speed_purple",
                                             "carolamotion", "carolamotion_rev")
        )
        if is_idle:
            self.status_label.setText("__CAROLALDHIRA_ACTIVA__")
    def _emergency_free_memory(self):
        """Libera toda memoria no crítica cuando RAM supera umbral CRITICAL."""
        _log.error("Modo protección RAM activado — liberando caches")
        with self._speed_cache_lock:
            self._speed_cache = None
            self._speed_cache_ratio = None
        gc.collect()   # CONSERVADO: camino de emergencia RAM — único gc.collect() legítimo
        _log.info("Caches liberadas. RAM antes=%.0f MB", self._session_status.ram_mb_approx)
    def _archival_tick(self):
        """
        Tick cada 5 s: comprueba drift temporal y guarda snapshots periódicos.
        v0.08: core del sistema de auditoría archivística.
        """
        if not self._engine.recording or self._engine.paused:
            return
        now = time.monotonic()

        # ── Drift temporal ────────────────────────────────────────────────
        if self._drift_t0 > 0:
            elapsed_wall   = now - self._drift_t0
            expected_f     = elapsed_wall * self._cache_rate
            actual_f       = float(self._session_status.frames_received)
            drift_ms       = (actual_f - expected_f) / max(self._cache_rate, 1) * 1000.0
            self._session_status.drift_ms = drift_ms
            self._session_status.expected_frames = int(expected_f)

            if abs(drift_ms) > DRIFT_WARN_MS:
                self._session_status.drift_warn_count += 1
                _log.warning("Drift temporal: %.1f ms (expected=%.0f actual=%.0f)",
                             drift_ms, expected_f, actual_f)
                if abs(drift_ms) > DRIFT_WARN_MS * 3:
                    _bridge.status_msg.emit(
                        f"LORITO VIO UNA DERIVA, TE AVISA!!! {drift_ms:+.0f}ms — pérdidas: {self._session_status.drift_warn_count}")

        # ── Snapshot periódico ────────────────────────────────────────────
        if (self._snapshot_t == 0 or
                now - self._snapshot_t >= SNAPSHOT_INTERVAL_SECS):
            dur = self._rec_elapsed + (now - self._rec_start_t)
            if self._disk_tmp_path and self._session_status.frames_written > 0:
                # OPT-03: worker persistente en lugar de Thread() efímero
                self._services.snapshot_worker.submit(
                    self._disk_tmp_path, self._cache_rate,
                    self._session_status.frames_written, self._session_codec, dur
                )
            self._snapshot_t = now

        # ── CrashGuard: actualizar manifest con estado actual ─────────────
        # Se ejecuta siempre que haya grabación activa. El ticker del daemon
        # escribe a disco cada CRASH_HEARTBEAT_SECS; aquí actualizamos el dict
        # en RAM para que el próximo tick tenga datos frescos.
        if self._disk_tmp_path and self._session_status.frames_written > 0:
            dur_now = self._rec_elapsed + (now - self._rec_start_t)
            try:
                seg_paths = list(self._engine.get_segment_paths())
            except Exception:
                seg_paths = []
            self._services.session_guard.update({
                "samplerate":     self._cache_rate,
                "tmp_file":       self._disk_tmp_path,
                "segment_paths":  seg_paths,
                "frames_written": self._session_status.frames_written,
                "duration_secs":  round(dur_now, 3),
                "codec_hint":     self.codec_box.currentText(),
                "opt1":           self.opt1_box.currentText(),
                "opt2":           self.opt2_box.currentText(),
                "norm":           self.norm_box.currentText(),
                "xruns":          self._session_status.xrun_count,
                "drift_ms":       round(self._session_status.drift_ms, 3),
                # v0.20 — normalización avanzada
                "normalization_mode":           self._session_status.normalization_mode,
                "normalization_gain_db":        round(self._session_status.normalization_gain_db, 4),
                "normalization_peak_db":        round(self._session_status.normalization_peak_db, 4),
                "normalization_lufs":           round(self._session_status.normalization_lufs, 4)
                                                if self._session_status.normalization_lufs != float("-inf")
                                                else None,
                "normalization_noise_floor_db": round(self._session_status.normalization_noise_floor_db, 4)
                                                if self._session_status.normalization_noise_floor_db != float("-inf")
                                                else None,
                "normalization_true_peak_db":   round(self._session_status.normalization_true_peak_db, 4),
                # El monolito de origen 0.20 — campos extendidos
                "normalization_pre_gain_db":       round(self._session_status.normalization_pre_gain_db, 4),
                "normalization_post_gain_db":      round(self._session_status.normalization_post_gain_db, 4),
                "normalization_mid_rms":           (round(self._session_status.normalization_mid_rms, 3)
                                                    if self._session_status.normalization_mid_rms != float("-inf")
                                                    else None),
                "normalization_side_rms":          (round(self._session_status.normalization_side_rms, 3)
                                                    if self._session_status.normalization_side_rms != float("-inf")
                                                    else None),
                "normalization_stereo_balance":    round(self._session_status.normalization_stereo_balance, 4),
                "normalization_crest_factor_db":   (round(self._session_status.normalization_crest_factor_db, 2)
                                                    if self._session_status.normalization_crest_factor_db != float("inf")
                                                    else None),
                "normalization_dynamic_range":     round(self._session_status.normalization_dynamic_range, 2),
                "normalization_histogram_density": round(self._session_status.normalization_histogram_density, 6),
                "normalization_silence_ratio":     round(self._session_status.normalization_silence_ratio, 4),
                "normalization_auto_mode":         self._session_status.normalization_auto_mode or None,
                # ── Cuentavueltas (persistencia ante crash) ──────────────────
                # Se guarda el estado completo del TapeLogPanel activo para que
                # _do_crash_recovery() pueda restaurarlo y el log de especificación
                # no muestre 000 al exportar un archivo recuperado.
                **self._get_counter_manifest_fields(),
            })
    def _get_counter_manifest_fields(self) -> dict:
        """
        Retorna un dict con el estado actual del cuentavueltas del TapeLogPanel
        activo, listo para ser mezclado en el crash-manifest.

        Usa claves con prefijo "counter_" para no colisionar con otros campos
        del manifest.  Si no se puede obtener el panel, retorna un dict vacío
        (el manifest quedará sin datos de cuentavueltas en lugar de fallar).
        """
        try:
            _lbl = self.cassette_dur_box.currentText()
            _panel_map = {
                "C-60":  self.tape_c60,
                "C-90":  self.tape_c90,
                "OTROS": self.tape_otros,
            }
            _panel = _panel_map.get(_lbl)
            if _panel is None:
                return {}
            return {
                "counter_tape_label":    _panel._tape_label,
                "counter_surplus_a":     _panel._counter_surplus_a,
                "counter_surplus_b":     _panel._counter_surplus_b,
                "counter_wrap_a_count":  _panel._counter_wrap_a_count,
                "counter_wrap_b_count":  _panel._counter_wrap_b_count,
                "counter_wrap_count":    _panel._counter_wrap_count,
                "counter_final_value":   _panel._counter_final_value,
                "counter_phase":         _panel._phase,
                "counter_flip_done":     _panel._flip_done,
            }
        except Exception as _e:
            _log.warning("_get_counter_manifest_fields: no se pudo leer estado — %s", _e)
            return {}
    def _toggle_archival_safe(self, enabled: bool):
        """
        Activa/desactiva Modo Archival Safe.
        Reduce FPS GUI, aumenta margen buffers, endurece watchdog.
        """
        self._archival_safe         = enabled
        self._session_status.archival_safe_mode  = enabled
        if enabled:
            self._timer_vu.setInterval(1000 // ARCHIVAL_SAFE_FPS)   # ~10 FPS
            _log.info("Modo Archival Safe ACTIVADO: FPS=%d watchdog=%.1fs",
                      ARCHIVAL_SAFE_FPS, ARCHIVAL_SAFE_WATCHDOG)
        else:
            self._timer_vu.setInterval(SILENCE_ANALYSIS_INTERVAL_MS)   # 15 Hz — UNIVERSAL_THRESHOLD_PROFILE
            _log.info("Modo Archival Safe DESACTIVADO")
