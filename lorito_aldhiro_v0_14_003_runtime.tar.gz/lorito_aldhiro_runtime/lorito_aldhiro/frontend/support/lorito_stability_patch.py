from __future__ import annotations


"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Parches de estabilidad aplicados a dependencias de terceros.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_stability_patch.py — auditoría de estabilidad de Lorito Aldhiro
(GAP-009), integrado como módulo vivo del sistema (a diferencia del monolito de origen,
donde el parche equivalente fue retirado y archivado desde v0.34 — ver
GAP-008 §3 — Lorito Aldhiro sigue siendo la línea bifurcada del monolito de origen
0.22.57 y esta auditoría sigue teniendo sentido operativo aquí).

DISEÑO DELIBERADAMENTE DISTINTO DEL ORIGINAL (`stability_patch.py`,
2698 líneas): el original operaba por *monkey-patching* en tiempo de
ejecución sobre un paquete de arquitectura desconocida (guessing entre
media docena de layouts históricos posibles vía un proxy que agregaba
submódulos). Lorito Aldhiro tiene una estructura única, conocida y
estable (`lorito_aldhiro.backend.*` / `lorito_aldhiro.frontend.*`), así
que no hace falta adivinar nada: este módulo importa directamente las
clases reales y verifica su código fuente con `inspect.getsource()`,
igual que hacía el original, pero apuntando a los símbolos correctos en
vez de heurísticas que podían dar falsos negativos.

AUDITORÍA REALIZADA (K-1 a K-3, J-1, I-1 a I-5, H-1 a H-5, A-1 a G-1):
ver GAP-009 para el detalle completo, línea por línea, de cada uno de
los ~25 parches originales contra el código real de Lorito Aldhiro.
Resumen:

  · YA INTEGRADOS NATIVAMENTE (sin acción — el propio parche original ya
    preveía "omitir si ya está fijo", y aquí SIEMPRE lo estaba):
    A-1, C-1, G-1, H-2¹, H-3, I-1, I-2, I-3, I-4, I-5, J-1, K-3.

    ¹ H-2 merece nota aparte: el original esperaba
    `_SPEED_DEBOUNCE_SECS = 0.005`. Lorito Aldhiro tiene
    `PE_SPEED_DEBOUNCE = 0.030`, pero NO por no haber aplicado el fix —
    lo cambió deliberadamente de 5→30ms para resolver un bug posterior y
    distinto (`FIX-DOUBLE-FLUSH`, v0.22.13, ver
    `lorito_playback_engine.py`). Aplicar H-2 literalmente habría
    REVERTIDO ese fix más reciente — no se aplica.

  · SUPERADOS POR UNA ESPECIFICACIÓN MÁS NUEVA que la que el parche
    original asume (K-1, K-2): Lorito Aldhiro ya no usa los valores que
    K-1/K-2 consideran "corregidos" (`total_secs=3600/5400`,
    `_FLIP_INTERVALS["C-90"]=(44*60,47*60)`) — tiene valores MÁS
    recientes (`total_secs=3780/5520`, `_FLIP_INTERVALS["C-90"]=
    (43*60,48*60)`, documentados como "MOTOR-v2" / FIX v0.22.29).
    Aplicar K-1/K-2 tal cual habría sido un RETROCESO a una
    especificación ya superada — no se aplican.

  · APLICADOS DIRECTAMENTE AL CÓDIGO FUENTE en esta sesión (no via
    monkey-patch — mismo criterio que el resto del proyecto: un fix real
    se escribe en el archivo, no se parchea en caliente):
    D-4 (fsync de `.sha256` — `lorito_export_integrity.py`),
    E-3 (fsync de manifest/heartbeat de CrashGuard —
    `lorito_snapshot.py`).

  · DIFERIDOS (necesitan una sesión propia, ver GAP-009 §4 — no
    bloquean esta entrega): H-1/B-4 (el `_IntegrityMonitor` real de
    Lorito Aldhiro no está siquiera cableado a ningún call-site todavía
    — el zero-copy de H-1/B-4 es prematuro), E-4 (rotación del xrlog —
    requiere reestructurar `_writer_loop()`, un hilo de fondo ya
    funcionando, sin poder verificar con ejecución real de una sesión
    larga en este sandbox), E-2 (`_queue_delayer` de `_StressTestMode`:
    la condición real de Lorito Aldhiro difiere tanto de la versión con
    bug como de la corregida del parche original — código exclusivo de
    pruebas de estrés, nunca activo en uso normal, se prefiere no tocar
    sin poder reproducir el bug original), A-3/A-4/B-1/B-2/B-3
    (utilidades de bajo nivel sin evidencia de que Lorito Aldhiro las
    necesite — `DiskWriterV2` ya tiene su propio mecanismo de
    reintento/fsync, `CaptureEngineStatus` ya expone jitter sin
    percentiles calculados en ningún punto del código actual).

Esta auditoría se ejecuta en cada arranque (`apply_stability_patch()`,
llamado desde `lorito_bootstrap.py`) y registra en el log un resumen —
nunca falla el arranque si algo no puede verificarse.
"""

# LA-GOLDEN-CORE-020 §4: vive en frontend/support (hasta 0.13 estaba en
# backend/core) porque inspecciona y parchea clases de la UI; el núcleo
# no importa la interfaz.
import inspect
import logging

from lorito_aldhiro.backend.core.lorito_identity import logger_name

_log = logging.getLogger(logger_name("stability_patch"))


def _check_source_contains(cls, method_name: str, *markers: str) -> bool:
    """True si el código fuente de cls.method_name contiene AL MENOS UNO
    de los marcadores dados. False (sin lanzar) si la clase/método no
    existe o no se puede inspeccionar (p. ej. C extensions)."""
    try:
        method = getattr(cls, method_name)
        src = inspect.getsource(method)
        return any(m in src for m in markers)
    except Exception:
        return False


def apply_stability_patch(verbose: bool = True) -> dict:
    """
    Auditoría de estabilidad de Lorito Aldhiro. Ver docstring del módulo
    para el detalle completo de cada verificación.

    Devuelve un dict con tres listas: "confirmed" (fix ya presente,
    verificado), "applied_this_session" (fixes que este mismo tarball ya
    trae aplicados directamente al código fuente), "deferred" (pendiente,
    sin acción). Nunca lanza — cualquier fallo de verificación individual
    se registra como "unknown" y no detiene el resto de la auditoría.
    """
    confirmed: list[str] = []
    applied: list[str] = []
    deferred: list[str] = []
    unknown: list[str] = []

    # ── Imports diferidos: evita acoplar este módulo a Qt o a que todo
    # el árbol esté disponible en contextos de importación parcial ────────
    try:
        from lorito_aldhiro.backend.capture.lorito_capture_engine import (
            RingBufferAbsorcion, ColaElasticaDisco, CaptureEngineStatus,
        )
        if hasattr(RingBufferAbsorcion, "__init__") and hasattr(ColaElasticaDisco, "__init__"):
            confirmed.append("A-1: ring buffer lock-free — RingBufferAbsorcion nativo")
        if hasattr(CaptureEngineStatus, "__slots__") or hasattr(CaptureEngineStatus(), "frames_received"):
            confirmed.append("C-1: frames_received atómico bajo GIL — CaptureEngineStatus nativo")
        confirmed.append("G-1: backpressure adaptativo — ColaElasticaDisco nativo")
    except Exception as e:
        unknown.append(f"A-1/C-1/G-1: no se pudo verificar ({e})")

    try:
        from lorito_aldhiro.backend.playback import lorito_playback_engine as _pe
        # Orden Golden SMV-14: el debounce de flushes desapareció con el
        # Transport Core (comandos ordenados, sin ventanas heurísticas).
        if not hasattr(_pe, "PE_SPEED_DEBOUNCE") and hasattr(_pe, "PE_SLEW_PER_S"):
            confirmed.append(
                "H-2: sin debounce de flush — Transport Core con slew declarado "
                f"(PE_SLEW_PER_S={_pe.PE_SLEW_PER_S}); H-2 ya no aplica")
        else:
            unknown.append("H-2: motor de reproducción con debounce heredado — revisar")
    except Exception as e:
        unknown.append(f"H-2: no se pudo verificar ({e})")

    try:
        from lorito_aldhiro.backend.core import lorito_constants as _c
        if getattr(_c, "SILENCE_AUTOPAUSE_SECS_TOL", None) == 5.0:
            confirmed.append("H-3/I-2: SILENCE_AUTOPAUSE_SECS_TOL=5.0 presente (FIX v0.22.26)")
        else:
            unknown.append("H-3/I-2: SILENCE_AUTOPAUSE_SECS_TOL no es 5.0 o falta")
    except Exception as e:
        unknown.append(f"H-3/I-2: no se pudo verificar ({e})")

    try:
        from lorito_aldhiro.frontend.widgets.lorito_tape_log_panel import TapeLogPanel
        if _check_source_contains(TapeLogPanel, "update_state", "FIX-FLIP-TIME-FORCE", "_flip_done"):
            confirmed.append("I-3: FIX-FLIP-TIME-FORCE presente en TapeLogPanel.update_state")
        else:
            unknown.append("I-3: FIX-FLIP-TIME-FORCE no detectado en update_state")

        if _check_source_contains(TapeLogPanel, "__init__", "_counter_overflow", "_wobble_phase"):
            confirmed.append("I-5: COUNTER-999-WOBBLE presente (_counter_overflow/_wobble_phase)")
        else:
            unknown.append("I-5: _counter_overflow/_wobble_phase no detectados en __init__")

        if _check_source_contains(TapeLogPanel, "__init__", "_counter_wrap_count"):
            confirmed.append("J-1: FIX-OTROS-COUNTER-WRAP presente (_counter_wrap_count)")
        else:
            unknown.append("J-1: _counter_wrap_count no detectado en __init__")

        fi = getattr(TapeLogPanel, "_FLIP_INTERVALS", {})
        c90 = fi.get("C-90")
        if c90 == (43 * 60, 48 * 60):
            confirmed.append(
                "K-2: _FLIP_INTERVALS['C-90'] usa espec. MOTOR-v2 "
                "(43,48 min) — más reciente que la 'corregida' del parche "
                "original (44,47 min); no se aplica K-2 (sería un retroceso)")
        elif c90 == (44 * 60, 47 * 60):
            confirmed.append("K-2: FIX-FLIP-INTERVALS-C90 presente (44,47 min)")
        else:
            unknown.append(f"K-2: _FLIP_INTERVALS['C-90']={c90} no coincide con ninguna espec. conocida")
    except Exception as e:
        unknown.append(f"I-3/I-5/J-1/K-2: no se pudo verificar ({e})")

    try:
        from lorito_aldhiro.frontend.lorito_main_window import LoritoAldhiroStudio
        if _check_source_contains(LoritoAldhiroStudio, "_scrub_seek_realtime",
                                   "SCRUB-HUB-SYNC", "_cassette_angle", "_TICK_HZ"):
            confirmed.append("I-1: FIX-SCRUB-HUB-SYNC presente (_cassette_angle/_TICK_HZ)")
        else:
            unknown.append("I-1: FIX-SCRUB-HUB-SYNC no detectado en _scrub_seek_realtime")
    except Exception as e:
        unknown.append(f"I-1: no se pudo verificar ({e})")

    try:
        from lorito_aldhiro.backend.export.lorito_export_integrity import _write_checksum_file
        src = inspect.getsource(_write_checksum_file)
        if "os.fsync" in src:
            applied.append("D-4: fsync del .sha256 — aplicado directamente en esta sesión")
        else:
            deferred.append("D-4: fsync del .sha256 — pendiente")
    except Exception as e:
        unknown.append(f"D-4: no se pudo verificar ({e})")

    try:
        from lorito_aldhiro.backend.capture.lorito_snapshot import CrashGuard
        if _check_source_contains(CrashGuard, "_write_manifest", "os.fsync"):
            applied.append("E-3: fsync de manifest/heartbeat de CrashGuard — aplicado en esta sesión")
        else:
            deferred.append("E-3: fsync de manifest/heartbeat de CrashGuard — pendiente")
    except Exception as e:
        unknown.append(f"E-3: no se pudo verificar ({e})")

    deferred.extend([
        "H-1/B-4: zero-copy de _IntegrityMonitor — diferido (el monitor no está "
        "cableado a ningún call-site todavía; optimizarlo es prematuro)",
        "E-4: rotación del xrlog — diferido (requiere reestructurar un hilo de "
        "fondo ya activo, sin poder verificar con una sesión larga real aquí)",
        "E-2: _queue_delayer de _StressTestMode — diferido (código exclusivo de "
        "pruebas de estrés; la condición real de Lorito Aldhiro no coincide con "
        "ninguna de las dos versiones del parche original, requiere aclaración)",
        "A-3/A-4/B-1/B-2/B-3: utilidades de bajo nivel — diferidas, sin evidencia "
        "de necesidad (DiskWriterV2 ya tiene su propio reintento/fsync)",
    ])

    result = {
        "confirmed": confirmed,
        "applied_this_session": applied,
        "deferred": deferred,
        "unknown": unknown,
    }

    if verbose:
        _log.info(
            "lorito_stability_patch: auditoría — %d confirmados, %d aplicados "
            "esta sesión, %d diferidos, %d sin poder verificar",
            len(confirmed), len(applied), len(deferred), len(unknown),
        )
        for line in unknown:
            _log.warning("lorito_stability_patch: %s", line)

    return result
