# -*- coding: utf-8 -*-

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Animación del motor/carrete de cinta en la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_cassette_motor_v4.py — Motor de Etapa de Duración de Cinta v4
═══════════════════════════════════════════════════════════════════════════
Integrado a Lorito Aldhiro (bifurcación del monolito de origen 0.22.57 — ver GAP-001),
módulo que faltaba en el tarball (ver GAP-012 §4) — entregado por el
usuario y renombrado a los estándares de Lorito Aldhiro.

NOTA DE NOMENCLATURA
────────────────────
El archivo original definía una clase TapePreset que es el perfil del motor
(con umbrales de tolerancia y callbacks) — Lorito Aldhiro no tiene un
módulo `presets.py` separado con otro TapePreset (dataclass de
normalización) con el que pudiera colisionar, pero se conserva el alias
`MotorTapeConfig`/`TapePreset` tal cual, sin razón para quitarlo.

    from lorito_aldhiro.frontend.widgets.lorito_cassette_motor_v4 import (
        CassetteMotorV4, make_motor, TapeSide, MotorAction,
    )
"""

from __future__ import annotations

import logging
import time
from enum import Enum, auto
from typing import Optional, Callable
from lorito_aldhiro.backend.core.lorito_identity import logger_name

_log = logging.getLogger(logger_name("cassette_motor_v4"))

# ═══════════════════════════════════════════════════════════════════════════════
#  CONSTANTE: cuántos segundos de silencio en pausa forzada activa antes de
#  conmutar a pausa automática por silencio (spec: "en un segundo").
# ═══════════════════════════════════════════════════════════════════════════════
FORCED_PAUSE_SILENCE_ESCAPE_S: float = 1.0


# ═══════════════════════════════════════════════════════════════════════════════
#  ENUMERACIONES PÚBLICAS
# ═══════════════════════════════════════════════════════════════════════════════

class TapeSide(Enum):
    """Lado activo de la cinta."""
    A         = auto()
    B         = auto()
    EXCEDENTE = auto()   # elapsed > total_secs


class MotorAction(Enum):
    """
    Acción que el motor solicita al exterior en este tick.
    El controlador (TapeLogPanel / LoritoAldhiroStudio) decide si actúa.
    """
    NONE           = auto()   # sin acción requerida
    AUTOPAUSE      = auto()   # activar pausa automática por silencio
    FORCED_PAUSE_A = auto()   # pausa forzada por tope de Lado A (audio activo)
    FLIP_SIDE_B    = auto()   # confirmar volteo a Lado B
    STOP           = auto()   # detener grabación (fin Lado B)


# ═══════════════════════════════════════════════════════════════════════════════
#  PERFIL DE CINTA DEL MOTOR
#  (renombrado como MotorTapeConfig para distinguirlo del dataclass de presets.py)
# ═══════════════════════════════════════════════════════════════════════════════

class MotorTapeConfig:
    """
    Parámetros de un preset de cinta para el motor de cinta.
    Todos los umbrales en segundos, referenciados al contómetro PRINCIPAL
    (tiempo total acumulado desde el inicio, sin reiniciar al voltear).

    Alias legacy: TapePreset (para compatibilidad con código que usaba el nombre original).
    """

    def __init__(
        self,
        name: str,
        side_a_s: float,          # duración nominal Lado A (s)
        total_s: float,           # duración nominal total  (s)
        tol_min_a_s: float,       # inicio ventana tolerancia Lado A (contómetro principal)
        tol_max_a_s: float,       # fin    ventana tolerancia Lado A (contómetro principal)
        tol_min_b_s: float,       # inicio ventana tolerancia Lado B (contómetro principal)
        tol_max_b_s: float,       # fin    ventana tolerancia Lado B (contómetro principal)
    ) -> None:
        self.name         = name
        self.side_a_s     = side_a_s
        self.total_s      = total_s
        self.tol_min_a_s  = tol_min_a_s
        self.tol_max_a_s  = tol_max_a_s
        self.tol_min_b_s  = tol_min_b_s
        self.tol_max_b_s  = tol_max_b_s

    def __repr__(self) -> str:
        return (
            f"MotorTapeConfig({self.name!r} "
            f"A=[{self.tol_min_a_s/60:.1f}…{self.tol_max_a_s/60:.1f}]min "
            f"B=[{self.tol_min_b_s/60:.1f}…{self.tol_max_b_s/60:.1f}]min)"
        )


# Alias de compatibilidad: el código legacy que importaba TapePreset desde
# Alias legacy conservado tal cual — sin colisión real en Lorito Aldhiro
# (no existe otro TapePreset en el proyecto).
TapePreset = MotorTapeConfig


# ── Presets predefinidos ────────────────────────────────────────────────────────
#
# FIX-LADO-B-TOLERANCIA-EXT3MIN (§GAP-014): +3 min al TOPE MÁXIMO de la
# ventana de tolerancia de Lado B únicamente (el mínimo no se toca) —
# mismo fix ya aplicado en el monolito de origen (ver CHANGELOG del monolito de origen [0.37.348]:
# "extensión de tolerancia Lado B (5→8 min), sumados únicamente al tope
# máximo"). Ventana de 5 min → 8 min en ambos modos de cinta.
#
# C-60:
#   Lado A: tolerancia [28 min … 33 min] del contómetro principal
#   Lado B: tolerancia [58 min … 66 min] del contómetro principal (antes 63 min)
#
# C-90:
#   Lado A: tolerancia [43 min … 48 min] del contómetro principal
#   Lado B: tolerancia [87 min … 95 min] del contómetro principal (antes 92 min)
#
_PRESET_C60 = MotorTapeConfig(
    name        = "C-60",
    side_a_s    = 30 * 60,
    total_s     = 60 * 60,
    tol_min_a_s = 28 * 60,
    tol_max_a_s = 33 * 60,
    tol_min_b_s = 58 * 60,
    tol_max_b_s = 66 * 60,   # FIX-LADO-B-TOLERANCIA-EXT3MIN: 63→66 min
)

_PRESET_C90 = MotorTapeConfig(
    name        = "C-90",
    side_a_s    = 45 * 60,
    total_s     = 90 * 60,
    tol_min_a_s = 43 * 60,
    tol_max_a_s = 48 * 60,
    tol_min_b_s = 87 * 60,
    tol_max_b_s = 95 * 60,   # FIX-LADO-B-TOLERANCIA-EXT3MIN: 92→95 min
)

_PRESETS: dict[str, MotorTapeConfig] = {
    "C-60": _PRESET_C60,
    "C-90": _PRESET_C90,
}


# ═══════════════════════════════════════════════════════════════════════════════
#  FSM INTERNA — estados discretos
# ═══════════════════════════════════════════════════════════════════════════════

class _FSMState(Enum):
    # ── Lado A ──────────────────────────────────────────
    A_LIBRE          = auto()   # antes de tol_min_a  — grabar libremente
    A_TOLERANCIA     = auto()   # [tol_min_a … tol_max_a) con audio — buscar silencio
    A_PAUSA_AUTO     = auto()   # silencio detectado dentro de tolerancia → pausa auto
    A_PAUSA_FORZADA  = auto()   # llegó a tol_max_a con audio → pausa forzada por tope
    A_ESCAPE         = auto()   # silencio confirmado en pausa forzada → conmutar a autopause
    # ── Volteo ──────────────────────────────────────────
    VOLTEO_PENDIENTE = auto()   # pausa liberada; ejecutar flip y marcar LADO B
    # ── Lado B ──────────────────────────────────────────
    B_LIBRE          = auto()   # antes de tol_min_b  — grabar libremente
    B_TOLERANCIA     = auto()   # [tol_min_b … tol_max_b) con audio — buscar silencio
    B_STOP           = auto()   # fin de cinta (por silencio o por tope)
    # ── Final ───────────────────────────────────────────
    TERMINADO        = auto()   # grabación completamente detenida


# ═══════════════════════════════════════════════════════════════════════════════
#  MOTOR PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════════

class CassetteMotorV4:
    """
    Motor de Etapa de Duración de Cinta v4.

    Implementa exactamente la fórmula de CAMBIAR_MOTOR_DE_MINUTOS_DE_REFERENCIA.txt.

    RELOJ USADO: elapsed_secs = contómetro PRINCIPAL (acumulado total,
    nunca se reinicia al voltear). El cuentavueltas analógico (0-999) se
    reinicia en Lado B a través de query_counter_reset().

    INTEGRACIÓN CON EL PAQUETE MODULAR
    ────────────────────────────────────
    1. LoritoAldhiroStudio instancia make_motor("C-60") / make_motor("C-90").
    2. Inyecta callbacks: on_forced_pause_a, on_flip_side_b, on_auto_stop.
    3. TapeLogPanel.update_state() llama tick(elapsed_secs, autopause_active)
       cada ~15 Hz.
    4. _deactivate_silence_autopause() llama notify_autopause_deactivated().
    5. Propiedades flip_pending / flip_done / forced_pause_active /
       stop_triggered se sincronizan con TapeLogPanel en cada tick.
    """

    def __init__(self, preset: MotorTapeConfig) -> None:
        self._preset = preset

        # ── FSM ──────────────────────────────────────────────────────────────
        self._state: _FSMState = _FSMState.A_LIBRE

        # ── Propiedades observables (leídas por TapeLogPanel) ────────────────
        self._flip_pending:        bool = False
        self._flip_done:           bool = False
        self._forced_pause_active: bool = False
        self._stop_triggered:      bool = False
        self._side: TapeSide            = TapeSide.A

        # ── Reset del cuentavueltas (single-shot) ────────────────────────────
        self._counter_reset_pending: bool = False

        # ── Temporizador de escape en pausa forzada ──────────────────────────
        self._forced_silence_since: Optional[float] = None

        # ── Callbacks externos ───────────────────────────────────────────────
        self.on_forced_pause_a:   Optional[Callable] = None
        self.on_flip_side_b:      Optional[Callable] = None
        self.on_auto_stop:        Optional[Callable] = None
        self.on_autopause_switch: Optional[Callable] = None

    # ── Propiedades públicas ─────────────────────────────────────────────────

    @property
    def flip_pending(self) -> bool:
        return self._flip_pending

    @property
    def flip_done(self) -> bool:
        return self._flip_done

    @property
    def forced_pause_active(self) -> bool:
        return self._forced_pause_active

    @property
    def stop_triggered(self) -> bool:
        return self._stop_triggered

    @property
    def side(self) -> TapeSide:
        return self._side

    def reset(self) -> None:
        """
        Reinicia el motor al estado inicial (Lado A, sin flip, sin stop).
        Los callbacks inyectados se conservan.
        """
        self._state                  = _FSMState.A_LIBRE
        self._flip_pending           = False
        self._flip_done              = False
        self._forced_pause_active    = False
        self._stop_triggered         = False
        self._side                   = TapeSide.A
        self._counter_reset_pending  = False
        self._forced_silence_since   = None
        _log.info("CassetteMotorV4 [%s]: reset → estado inicial Lado A", self._preset.name)

    def query_counter_reset(self) -> bool:
        """
        Retorna True UNA SOLA VEZ después de que el volteo a Lado B fue
        confirmado. TapeLogPanel llama a este método para reiniciar el
        cuentavueltas a 000.
        """
        if self._counter_reset_pending:
            self._counter_reset_pending = False
            return True
        return False

    # ── API de tick ──────────────────────────────────────────────────────────

    def tick(
        self,
        elapsed_secs: float,
        autopause_active: bool,
    ) -> MotorAction:
        """
        Evalúa la máquina de estados y retorna la acción requerida.

        Parámetros
        ----------
        elapsed_secs     : contómetro PRINCIPAL (segundos totales acumulados).
        autopause_active : True si la pausa automática por silencio está activa.

        Retorna
        -------
        MotorAction que el controlador externo puede usar para decidir si actúa.
        """
        p = self._preset

        if self._state == _FSMState.TERMINADO:
            return MotorAction.NONE

        if elapsed_secs > p.total_s and self._state not in (
            _FSMState.B_STOP, _FSMState.TERMINADO
        ):
            self._side = TapeSide.EXCEDENTE
            if not self._stop_triggered:
                self._stop_triggered = True
                self._state = _FSMState.TERMINADO
                _log.info(
                    "%s: excedente — elapsed=%.1fs > total=%.1fs → STOP",
                    p.name, elapsed_secs, p.total_s,
                )
                self._fire(self.on_auto_stop)
            return MotorAction.STOP

        # ══ LADO A ════════════════════════════════════════════════════════════

        if self._state == _FSMState.A_LIBRE:
            if elapsed_secs >= p.tol_min_a_s:
                self._state = _FSMState.A_TOLERANCIA
                _log.info(
                    "%s: entra en zona de tolerancia Lado A "
                    "(elapsed=%.1f s / %.1f min)",
                    p.name, elapsed_secs, elapsed_secs / 60,
                )
            else:
                return MotorAction.NONE

        if self._state == _FSMState.A_TOLERANCIA:
            if autopause_active:
                self._flip_pending        = True
                self._forced_pause_active = False
                self._state               = _FSMState.A_PAUSA_AUTO
                _log.info(
                    "%s: silencio en tolerancia A (%.1f min) → AUTOPAUSE + flip_pending",
                    p.name, elapsed_secs / 60,
                )
                return MotorAction.AUTOPAUSE

            if elapsed_secs >= p.tol_max_a_s:
                self._flip_pending         = True
                self._forced_pause_active  = True
                self._forced_silence_since = None
                self._state                = _FSMState.A_PAUSA_FORZADA
                _log.info(
                    "%s: tope Lado A alcanzado con audio (%.1f min) → PAUSA FORZADA",
                    p.name, elapsed_secs / 60,
                )
                self._fire(self.on_forced_pause_a)
                return MotorAction.FORCED_PAUSE_A

            return MotorAction.NONE

        if self._state == _FSMState.A_PAUSA_AUTO:
            return MotorAction.AUTOPAUSE

        if self._state == _FSMState.A_PAUSA_FORZADA:
            if autopause_active:
                now = time.monotonic()
                if self._forced_silence_since is None:
                    self._forced_silence_since = now
                elapsed_silence = now - self._forced_silence_since
                if elapsed_silence >= FORCED_PAUSE_SILENCE_ESCAPE_S:
                    self._forced_pause_active  = False
                    self._state                = _FSMState.A_ESCAPE
                    self._forced_silence_since = None
                    _log.info(
                        "%s: silencio ≥ %.1fs en pausa forzada → conmutar a AUTOPAUSE",
                        p.name, FORCED_PAUSE_SILENCE_ESCAPE_S,
                    )
                    if self.on_autopause_switch is not None:
                        self._fire(self.on_autopause_switch)
                    return MotorAction.AUTOPAUSE
            else:
                self._forced_silence_since = None

            return MotorAction.FORCED_PAUSE_A

        if self._state == _FSMState.A_ESCAPE:
            return MotorAction.AUTOPAUSE

        if self._state == _FSMState.VOLTEO_PENDIENTE:
            self._side               = TapeSide.B
            self._flip_pending       = False
            self._flip_done          = True
            self._counter_reset_pending = True
            self._state              = _FSMState.B_LIBRE
            _log.info(
                "%s: volteo a Lado B confirmado — cuentavueltas → 000",
                p.name,
            )
            self._fire(self.on_flip_side_b)
            return MotorAction.FLIP_SIDE_B

        # ══ LADO B ════════════════════════════════════════════════════════════

        if self._state == _FSMState.B_LIBRE:
            self._side = TapeSide.B
            if elapsed_secs >= p.tol_min_b_s:
                self._state = _FSMState.B_TOLERANCIA
                _log.info(
                    "%s: entra en zona de tolerancia Lado B "
                    "(elapsed=%.1f s / %.1f min)",
                    p.name, elapsed_secs, elapsed_secs / 60,
                )
            else:
                return MotorAction.NONE

        if self._state == _FSMState.B_TOLERANCIA:
            self._side = TapeSide.B

            if autopause_active:
                self._stop_triggered = True
                self._state          = _FSMState.B_STOP
                _log.info(
                    "%s: silencio en tolerancia B (%.1f min) → STOP",
                    p.name, elapsed_secs / 60,
                )
                self._fire(self.on_auto_stop)
                return MotorAction.STOP

            if elapsed_secs >= p.tol_max_b_s:
                self._stop_triggered = True
                self._state          = _FSMState.B_STOP
                _log.info(
                    "%s: tope Lado B alcanzado (%.1f min) → STOP DEFINITIVO",
                    p.name, elapsed_secs / 60,
                )
                self._fire(self.on_auto_stop)
                return MotorAction.STOP

            return MotorAction.NONE

        if self._state in (_FSMState.B_STOP, _FSMState.TERMINADO):
            return MotorAction.STOP

        return MotorAction.NONE

    # ── Notificación desde el controlador externo ────────────────────────────

    def notify_autopause_deactivated(self, elapsed_secs: float) -> None:
        """
        Llamado por _deactivate_silence_autopause() en LoritoAldhiroStudio cuando el
        usuario reanuda la grabación tras una pausa automática por silencio.
        """
        if self._state in (_FSMState.A_PAUSA_AUTO, _FSMState.A_ESCAPE):
            self._state               = _FSMState.VOLTEO_PENDIENTE
            self._forced_pause_active = False
            _log.info(
                "%s: autopause desactivada en Lado A (%.1f min) → VOLTEO PENDIENTE",
                self._preset.name, elapsed_secs / 60,
            )
            # Ejecutar volteo inmediatamente (no esperar al siguiente tick)
            self._side               = TapeSide.B
            self._flip_pending       = False
            self._flip_done          = True
            self._counter_reset_pending = True
            self._state              = _FSMState.B_LIBRE
            _log.info(
                "%s: volteo a Lado B ejecutado en notify_autopause_deactivated",
                self._preset.name,
            )
            self._fire(self.on_flip_side_b)

        elif self._state in (_FSMState.B_TOLERANCIA, _FSMState.B_STOP):
            if not self._stop_triggered:
                self._stop_triggered = True
                self._state          = _FSMState.B_STOP
                _log.warning(
                    "%s: notify_autopause_deactivated en Lado B — STOP forzado",
                    self._preset.name,
                )
                self._fire(self.on_auto_stop)

    # ── Utilidades internas ──────────────────────────────────────────────────

    @staticmethod
    def _fire(cb: Optional[Callable]) -> None:
        """Llama un callback ignorando errores (nunca bloquea el tick)."""
        if cb is None:
            return
        try:
            cb()
        except Exception as exc:
            _log.error("CassetteMotorV4 callback error: %s", exc)


# ═══════════════════════════════════════════════════════════════════════════════
#  FÁBRICA
# ═══════════════════════════════════════════════════════════════════════════════

def make_motor(tape_label: str) -> Optional[CassetteMotorV4]:
    """
    Retorna un CassetteMotorV4 configurado para el preset indicado,
    o None si la etiqueta no corresponde a ningún preset conocido (e.g. "OTROS").
    """
    label = tape_label.strip().upper()
    preset = _PRESETS.get(label)
    if preset is None:
        _log.debug(
            "make_motor: etiqueta '%s' no reconocida — motor inactivo", tape_label
        )
        return None
    motor = CassetteMotorV4(preset)
    _log.info("CassetteMotorV4 creado — preset=%s", preset)
    return motor


# ═══════════════════════════════════════════════════════════════════════════════
#  EXPORTS
# ═══════════════════════════════════════════════════════════════════════════════

__all__ = [
    "TapeSide",
    "MotorAction",
    "MotorTapeConfig",
    "TapePreset",        # alias legacy
    "CassetteMotorV4",
    "make_motor",
    "FORCED_PAUSE_SILENCE_ESCAPE_S",
]
