from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Animaciones de estado de reproducción/grabación en la interfaz.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import math as _math
import random
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QFontMetrics, QColor, QPainter, QPen, QFont
from PySide6.QtCore import QPointF

from lorito_aldhiro.frontend.support.lorito_fonts import font_media_anim


# Título que la computadora animada muestra en su pantalla. Excepción
# deliberada y acotada de LA-GOLDEN-CORE-020 §7: es solo texto de la
# animación (ficción visual), no nombre de producto, ruta, logger ni
# condición de ejecución. Es la única aparición permitida de esta cadena
# en el código; el escáner de referencias la admite por archivo, nombre y
# valor exactos, y `tests/test_core_independencia.py` vigila su alcance.
MEDIA_ANIM_COMPUTER_CAPTION = "AECCT2"


# ─────────────────────────────────────────────────────────────────────────────
#  MEDIA ANIM WIDGET — animación cassette→PC→disco óptico (dentro del clock)
# ─────────────────────────────────────────────────────────────────────────────
class MediaAnimWidget(QWidget):
    """
    Animación integrada dentro del recuadro del contador principal.
    Ocupa toda la altura del contómetro (TIMER_H=62).

    Estados:
      "idle"     — solo la PC centrada, sin cassette ni disco (inicialización
                   o buffer vacío).
      "rec"      — ciclo continuo: cassette entra por izquierda → ingresa a
                   la PC → sale convertido en disco por la derecha → disco
                   desaparece → el ciclo reinicia indefinidamente.
      "pause"    — ciclo congelado en la posición actual, todo parpadea a 480ms.
      "flushing" — PC arroja binarios a disco duro (vaciando buffer al disco).
                   Color del timer estado stop. Texto "VACIADO".
      "stopped"  — PC al centro + disco a la derecha (quietos) + checkmark
                   prominente al costado derecho. Texto "LORITO".
      "play"     — carrete de cinta abierta girando en sentido antihorario.
    """
    W = 110   # ancho fijo dentro del recuadro del clock

    # ── Parámetros del ciclo de animación REC ────────────────────────────────
    CASS_SPD      = 1.3    # px/tick — velocidad del cassette (entrada)
    DISC_SPD      = 1.3    # px/tick — velocidad del disco (salida)
    BLINK_TICKS   = 30     # ticks que parpadea el título dentro de la PC (~1.25s)

    # Sub-estados del ciclo REC
    _REC_ENTER    = 0      # cassette entra hacia la PC
    _REC_INSIDE   = 1      # cassette dentro de la PC, pantalla parpadeando
    _REC_EXIT     = 2      # disco sale de la ranura derecha

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)

        self._state       = "idle"
        self._blink_on    = True    # parpadeo en pause
        self._angle       = 0.0     # ángulo de rotación de hubs/disco
        self._reverse     = False   # True cuando la señal se está reversando (morph_rev)

        # Variables del ciclo REC
        self._rec_sub     = self._REC_ENTER
        self._cass_x      = 0.0     # posición X del cassette
        self._disc_x      = 0.0     # posición X del disco
        self._inside_tick = 0       # contador de ticks en _REC_INSIDE
        self._screen_on   = False   # estado parpadeo pantalla PC

        # FIX-FLUSH-ANIM: contador propio del estado "flushing".
        # _angle no avanza cuando la grabación ya se detuvo (delta=0 en
        # _tick_cassette → modo None), por lo que random.seed(_angle) siempre
        # produce las mismas posiciones de partículas → animación congelada.
        # _flush_tick incrementa en cada llamada a tick() sin depender de delta.
        self._flush_tick  = 0

        self._reset_cycle()

    # 0.13.007: el widget puede ser más ancho que alto (ocupa todo el ancho
    # de su celda para que las leyendas quepan al tamaño normal). Las
    # figuras se dibujan en un cuadrado de lado `_h` centrado: `_w` es el
    # lado de ese cuadrado y `_x0` su borde izquierdo.
    @property
    def _w(self): return min(self.width(), self.height())
    @property
    def _h(self): return self.height()
    @property
    def _x0(self): return (self.width() - self._w) / 2.0

    # Leyendas debajo de la PC: tamaño común a todas (el de READY/BREAK);
    # si una no cabe, primero se quita el espaciado extra y solo después,
    # si hace falta, se reduce el tamaño.
    LABEL_PX_REF = 7          # px a escala de diseño (h = 62)
    LABEL_SPACING_REF = 1.2

    def _reset_cycle(self):
        """Reinicia el ciclo: cassette fuera del borde izquierdo."""
        self._rec_sub     = self._REC_ENTER
        self._cass_x      = -28.0
        self._disc_x      = 0.0
        self._inside_tick = 0
        self._screen_on   = False

    def setState(self, state: str):
        if self._state != state:
            self._state = state
            if state == "rec":
                self._reset_cycle()
            if state == "flushing":
                self._flush_tick = 0   # FIX-FLUSH-ANIM: reiniciar al entrar en flushing
            self.update()

    def setBlink(self, on: bool):
        self._blink_on = on
        self.update()

    def tick(self, angle_delta: float, reverse: bool = False):
        """Llamado desde _tick_cassette (~24fps).
        reverse=True cuando la señal se está reversando (morph_rev):
        el carrete gira a baja velocidad en sentido horario."""
        self._reverse = reverse
        self._angle = (self._angle + angle_delta) % 360.0
        if self._state == "rec":
            self._tick_cycle()
        elif self._state == "flushing":
            # FIX-FLUSH-ANIM: avanzar contador propio siempre (independiente de delta).
            # Antes se usaba _angle como semilla de random, pero _angle es 0 cuando
            # delta=0 (grabación detenida) → partículas siempre en la misma posición.
            self._flush_tick += 1
            self._screen_on = (self._flush_tick % 6) < 3   # parpadeo pantalla ~4 Hz
        self.update()

    def _tick_cycle(self):
        """Avanza el ciclo cassette→inside→disco."""
        w = self._w
        sc = self._h / 62.0
        pc_cx   = w * 0.5
        mw      = int(34 * sc)
        pc_left = pc_cx - mw / 2    # borde izquierdo del monitor
        slot_x  = pc_cx + mw / 2    # borde derecho del monitor (slot de salida)

        if self._rec_sub == self._REC_ENTER:
            self._cass_x += self.CASS_SPD
            # El cassette entra cuando su centro alcanza el borde izquierdo del monitor
            if self._cass_x >= pc_left:
                self._cass_x      = pc_left   # fijar en el borde
                self._rec_sub     = self._REC_INSIDE
                self._inside_tick = 0
                self._disc_x      = slot_x    # disco arranca en el slot derecho
                self._screen_on   = True

        elif self._rec_sub == self._REC_INSIDE:
            self._inside_tick += 1
            # Pantalla parpadea: alterna cada 4 ticks
            self._screen_on = (self._inside_tick % 8) < 4
            if self._inside_tick >= self.BLINK_TICKS:
                self._rec_sub = self._REC_EXIT
                self._screen_on = False

        elif self._rec_sub == self._REC_EXIT:
            self._disc_x += self.DISC_SPD
            if self._disc_x > w + 28.0:
                self._reset_cycle()

    @classmethod
    def label_font(cls, text: str, sc: float, avail: float) -> QFont:
        """Fuente de la leyenda: tamaño común (`LABEL_PX_REF`·sc) con
        espaciado; si no cabe en `avail`, sin espaciado; solo si aun así no
        cabe, se reduce el tamaño (mínimo 5 px)."""
        px = max(5, int(cls.LABEL_PX_REF * sc))
        for spacing in (max(1, sc * cls.LABEL_SPACING_REF), 0.0):
            f = font_media_anim(size=1)
            f.setPixelSize(px)
            f.setBold(True)
            f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
            if QFontMetrics(f).horizontalAdvance(text) <= avail:
                return f
        while px > 5:
            px -= 1
            f.setPixelSize(px)
            if QFontMetrics(f).horizontalAdvance(text) <= avail:
                break
        return f

    def _get_color(self):
        """Color del Media Anim — SIEMPRE dorado lumínico (§VFD_GOLD_PALETTE,
        pedido explícito del usuario: "El Media Anim también deberá ser
        todo en color dorado"). Antes variaba por estado (rojo en rec,
        gris en standby, etc.) tomando el color del timer del THEME —
        eso quedó retirado por completo: rec/play usan el dorado
        brillante (mismo criterio que los dígitos del contómetro cuando
        están activos), el resto usa el dorado base."""
        # LCD Display (0.11.008): el Media Anim vive sobre el LCD ámbar —
        # se dibuja en la tinta negra del LCD (activo = tinta plena).
        if self._state in ("rec", "play"):
            return QColor(0x12, 0x10, 0x08, 255)
        return QColor(0x12, 0x10, 0x08, 215)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self._w, self._h
        cy = h // 2
        x0 = self._x0
        full_w = self.width()
        p.translate(x0, 0)                 # figuras en el cuadrado centrado

        col = self._get_color()
        visible = self._blink_on or self._state not in ("pause",)
        if not visible:
            p.end(); return

        # ── Escalado proporcional de las figuras al tamaño real del widget ───
        # Referencia de diseño: h=62 → escala=1.0
        sc = h / 62.0

        # ── Helpers de dibujo (escalados) ────────────────────────────────────

        def _draw_pc(cx, cy_pc, screen_active=True):
            """PC estilizada con slot de disco en el lateral derecho."""
            mw = int(34 * sc); mh = int(22 * sc)
            mx = int(cx - mw / 2); my = int(cy_pc - mh / 2 - 5 * sc)
            # Cuerpo del monitor
            p.setPen(QPen(col, max(1, sc * 1.2)))
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 22))
            p.drawRoundedRect(mx, my, mw, mh, int(3 * sc), int(3 * sc))
            # Pantalla interior
            pad = max(2, int(4 * sc))
            sw = mw - pad * 2; sh = mh - pad * 2
            scr_alpha = 80 if screen_active else 25
            p.setBrush(QColor(col.red(), col.green(), col.blue(), scr_alpha))
            p.drawRect(mx + pad, my + pad, sw, sh)
            # Título de la computadora en pantalla (MEDIA_ANIM_COMPUTER_CAPTION)
            fnt = font_media_anim(size=1)
            fnt.setPixelSize(max(4, int(6 * sc)))
            fnt.setBold(True)
            p.setFont(fnt)
            p.setPen(col if screen_active else QColor(col.red(), col.green(), col.blue(), 60))
            p.drawText(QRect(mx + pad, my + pad, sw, sh), Qt.AlignCenter, MEDIA_ANIM_COMPUTER_CAPTION)
            # Cuello y base
            p.setPen(QPen(col, max(1, sc * 1.2)))
            neck_y = my + mh
            p.drawLine(int(cx), neck_y, int(cx), neck_y + int(4 * sc))
            bw2 = int(12 * sc)
            p.drawLine(int(cx) - bw2, neck_y + int(4 * sc),
                       int(cx) + bw2, neck_y + int(4 * sc))
            # Slot de disco en lateral derecho del monitor (ranura vertical)
            slot_x = mx + mw - 1
            slot_y1 = my + int(mh * 0.3)
            slot_y2 = my + int(mh * 0.7)
            p.setPen(QPen(col, max(1, sc * 1.5)))
            p.drawLine(slot_x, slot_y1, slot_x, slot_y2)

        def _draw_cassette(cx, cy_c, angle_deg, alpha_mult=1.0):
            """Cassette con hubs giratorios."""
            cw = int(26 * sc); ch2 = int(16 * sc)
            base_alpha = int(22 * alpha_mult)
            p.setPen(QPen(QColor(col.red(), col.green(), col.blue(),
                                 int(col.alpha() * alpha_mult)), max(1, sc)))
            p.setBrush(QColor(col.red(), col.green(), col.blue(), base_alpha))
            p.drawRoundedRect(int(cx - cw / 2), int(cy_c - ch2 / 2),
                              cw, ch2, int(3 * sc), int(3 * sc))
            # Hubs
            hub_off = int(5 * sc); hr = 3.5 * sc
            for sx in (-hub_off, hub_off):
                hx = cx + sx; hy = cy_c + sc
                p.setBrush(QColor(col.red(), col.green(), col.blue(), int(55 * alpha_mult)))
                p.drawEllipse(QPointF(hx, hy), hr, hr)
                a = _math.radians(angle_deg if sx < 0 else -angle_deg)
                pen_hub = QPen(QColor(col.red(), col.green(), col.blue(),
                                      int(col.alpha() * alpha_mult)), max(1, sc * 0.9))
                p.setPen(pen_hub)
                p.drawLine(QPointF(hx, hy),
                           QPointF(hx + hr * _math.cos(a), hy + hr * _math.sin(a)))
            # Ventana de cinta
            ww = int(14 * sc); wh = int(5 * sc)
            p.setPen(QPen(QColor(col.red(), col.green(), col.blue(),
                                 int(col.alpha() * alpha_mult)), max(1, sc * 0.8)))
            p.setBrush(Qt.NoBrush)
            p.drawRect(int(cx - ww / 2), int(cy_c - wh / 2 + sc), ww, wh)

        def _draw_disc(cx, cy_d, angle_deg, alpha_mult=1.0):
            """Disco óptico con anillos iridiscentes y destello rotante."""
            r_out = 12 * sc; r_in = 3.5 * sc
            for ri, ai in ((r_out, int(35 * alpha_mult)),
                           (r_out * 0.72, int(22 * alpha_mult)),
                           (r_out * 0.50, int(12 * alpha_mult))):
                ring_c = QColor(col.red(), col.green(), col.blue(), ai)
                p.setPen(QPen(ring_c, max(1, sc * 0.9)))
                p.setBrush(Qt.NoBrush)
                p.drawEllipse(QPointF(cx, cy_d), ri, ri)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(col.red(), col.green(), col.blue(), int(60 * alpha_mult)))
            p.drawEllipse(QPointF(cx, cy_d), r_in, r_in)
            # Destello rotante
            a = _math.radians(angle_deg)
            sx2 = cx + (r_out - 3 * sc) * _math.cos(a)
            sy2 = cy_d + (r_out - 3 * sc) * _math.sin(a)
            p.setPen(QPen(QColor(col.red(), col.green(), col.blue(),
                                 int(180 * alpha_mult)), max(1, sc * 1.5)))
            p.drawLine(QPointF(cx, cy_d), QPointF(sx2, sy2))

        def _draw_checkmark(cx, cy_chk):
            """✓ prominente, mismo color del timer standby."""
            # Dorado lumínico (§VFD_GOLD_PALETTE) — antes gris fijo del
            # timer standby, independiente del resto del Media Anim.
            ck_col = QColor(0x12, 0x10, 0x08, 235)   # tinta del LCD
            sz = 7 * sc
            pen_ck = QPen(ck_col, max(2, sc * 2.2), Qt.SolidLine,
                          Qt.RoundCap, Qt.RoundJoin)
            p.setPen(pen_ck)
            p.drawPolyline([QPointF(cx - sz,       cy_chk),
                            QPointF(cx - sz * 0.2, cy_chk + sz * 0.9),
                            QPointF(cx + sz,        cy_chk - sz * 0.9)])

        def _draw_open_reel(cx, cy_r, angle_deg):
            """Carrete de magnetófono realista — flanges, hub central, radios, cinta."""
            r_flange  = 18 * sc   # radio del flange exterior
            r_hub     = 5  * sc   # radio del cubo central metálico
            r_tape    = 10 * sc   # radio interior donde empieza la cinta
            n_spokes  = 5         # cinco radios — estilo magnetófono clásico
            spoke_w   = max(1, sc * 1.4)

            # Flange exterior (aro grueso con borde doble — plato del carrete)
            p.setPen(QPen(col, max(1.5, sc * 1.5)))
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 10))
            p.drawEllipse(QPointF(cx, cy_r), r_flange, r_flange)
            # Segundo aro interior del flange (detalle realista)
            p.setPen(QPen(QColor(col.red(), col.green(), col.blue(), 90), max(1, sc)))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(cx, cy_r), r_flange - 2 * sc, r_flange - 2 * sc)

            # Área de cinta (anillo sombreado entre hub y r_tape)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 28))
            p.drawEllipse(QPointF(cx, cy_r), r_tape, r_tape)
            # Quitar el relleno del hueco central
            p.setBrush(QColor(0, 0, 0, 0))

            # Radios (spokes) desde hub hasta flange interior
            pen_sp = QPen(col, spoke_w)
            pen_sp.setCapStyle(Qt.RoundCap)
            p.setPen(pen_sp)
            for i in range(n_spokes):
                a = _math.radians(angle_deg + i * (360.0 / n_spokes))
                x1 = cx + r_hub * _math.cos(a)
                y1 = cy_r + r_hub * _math.sin(a)
                x2 = cx + (r_flange - 2 * sc) * _math.cos(a)
                y2 = cy_r + (r_flange - 2 * sc) * _math.sin(a)
                p.drawLine(QPointF(x1, y1), QPointF(x2, y2))

            # Hub central sólido (pieza metálica central)
            p.setPen(QPen(col, max(1, sc)))
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 200))
            p.drawEllipse(QPointF(cx, cy_r), r_hub, r_hub)
            # Eje central (punto brillante)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 255))
            p.drawEllipse(QPointF(cx, cy_r), 2.0 * sc, 2.0 * sc)

            # Etiqueta debajo del carrete: mismo tamaño que el resto de las
            # leyendas del Media Anim (0.13.007) y todo el ancho del widget.
            p.setFont(self.label_font("LORITEANDO", sc, full_w - 4))
            p.setPen(QColor(col.red(), col.green(), col.blue(), 200))
            lbl_y = int(cy_r + r_flange + 3 * sc)
            p.drawText(QRect(int(-x0), lbl_y, full_w, int(10 * sc)),
                       Qt.AlignHCenter | Qt.AlignTop, "LORITEANDO")

        # ── Helper: texto de etiqueta debajo de la PC ───────────────────────
        def _draw_label(text, alpha=200):
            fnt_lbl = self.label_font(text, sc, full_w - 4)
            p.setFont(fnt_lbl)
            p.setPen(QColor(col.red(), col.green(), col.blue(), alpha))
            # posición: debajo del cuello+base de la PC; ocupa TODO el ancho
            # del widget (no solo el cuadrado de las figuras).
            lbl_y = int(cy + int(22 * sc / 2) + int(4 * sc) + int(5 * sc))
            p.drawText(QRect(int(-x0), lbl_y, full_w, int(10 * sc)),
                       Qt.AlignHCenter | Qt.AlignTop, text)

        # ── Helper: disco duro estilizado para animación de vaciado ──────────
        def _draw_hdd(cx, cy_h):
            hw = int(28 * sc); hh = int(18 * sc)
            p.setPen(QPen(col, max(1, sc)))
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 20))
            p.drawRoundedRect(int(cx - hw/2), int(cy_h - hh/2), hw, hh,
                              int(2*sc), int(2*sc))
            # Plato circular interno
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 35))
            p.drawEllipse(QPointF(cx, cy_h), hw*0.3, hw*0.3)
            # Brazo lector
            arm_a = _math.radians(self._angle * 0.5 % 60 - 30)
            ax = cx + hw * 0.28 * _math.cos(arm_a)
            ay = cy_h + hw * 0.28 * _math.sin(arm_a)
            p.setPen(QPen(col, max(1, sc * 1.2)))
            p.drawLine(QPointF(cx, cy_h), QPointF(ax, ay))
            # Conector
            p.setPen(QPen(col, max(1, sc * 0.8)))
            for i in range(3):
                bx = int(cx - hw/2 + 4*sc + i*4*sc)
                p.drawLine(bx, int(cy_h + hh/2 - 3*sc),
                           bx, int(cy_h + hh/2))

        # ── Render por estado ────────────────────────────────────────────────
        pc_cx = w * 0.5

        if self._state == "idle":
            _draw_pc(pc_cx, cy, screen_active=False)
            _draw_label("READY", alpha=160)

        elif self._state in ("rec", "pause"):
            mw = int(34 * sc)
            pc_left  = int(pc_cx - mw / 2)
            pc_right = int(pc_cx + mw / 2)
            sub = self._rec_sub

            if sub == self._REC_ENTER:
                _draw_pc(pc_cx, cy, screen_active=False)
                p.save()
                p.setClipRect(0, 0, pc_left, h)
                _draw_cassette(self._cass_x, cy, self._angle)
                p.restore()
            elif sub == self._REC_INSIDE:
                _draw_pc(pc_cx, cy, screen_active=self._screen_on)
            elif sub == self._REC_EXIT:
                _draw_pc(pc_cx, cy, screen_active=False)
                p.save()
                p.setClipRect(pc_right, 0, w - pc_right, h)
                _draw_disc(self._disc_x, cy, self._angle * 1.8)
                p.restore()

            lbl_text = "TRANSDIGITALIZANDO" if self._state == "rec" else "BREAK"
            _draw_label(lbl_text)

        elif self._state == "flushing":
            # PC arroja binarios hacia un disco duro a la derecha.
            # La PC y el HDD comparten el color del timer "stop".
            pc_x2  = w * 0.32
            hdd_cx = w * 0.78
            _draw_pc(pc_x2, cy, screen_active=self._screen_on)
            _draw_hdd(hdd_cx, cy)
            # FIX-FLUSH-ANIM: usar _flush_tick como semilla en lugar de _angle.
            # _angle no avanza cuando delta=0 (grabación detenida) → partículas
            # siempre en la misma posición → animación congelada.
            random.seed(self._flush_tick & 0xFFFF)
            for _ in range(6):
                bx = w * 0.32 + (hdd_cx - w*0.32) * random.random()
                by = cy + ((random.random() - 0.5) * h * 0.55)
                fnt_b = font_media_anim(size=1)
                fnt_b.setPixelSize(max(4, int(6 * sc)))
                fnt_b.setBold(True)
                p.setFont(fnt_b)
                p.setPen(QColor(col.red(), col.green(), col.blue(),
                                int(80 + random.random() * 140)))
                p.drawText(QPointF(bx, by),
                           random.choice(["0","1","01","10","11","00"]))
            _draw_label("VACIADO")

        elif self._state == "stopped":
            disc_cx = w * 0.78
            _draw_pc(pc_cx, cy, screen_active=False)
            _draw_disc(disc_cx, cy, 0)
            _draw_checkmark(w * 0.93, cy)
            _draw_label("LORITO")

        elif self._state == "play":
            # En reversa: el carrete gira en sentido horario a baja velocidad.
            # +angle → horario; -angle → antihorario (reproducción normal).
            reel_angle = self._angle if getattr(self, "_reverse", False) else -self._angle
            _draw_open_reel(pc_cx, cy, reel_angle)

        p.end()
