from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Barra de menús de aluminio y persianas desplegables de 4 ítems con scroll.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Rediseño 0.12 (SVG de la usuaria):

- `LoritoMenuBar`: placa de aluminio con dos tornillos; reparte los
  botones a ancho igual entre los tornillos.
- `LoritoMenuButton`: botón metálico. El activo (persiana abierta) se pinta
  con canto y texto cian.
- `LoritoDropdown`: persiana desplegable. El monolito de origen admite hasta 10 ítems
  visibles; el lienzo de Lorito es más chico, así que se muestran como
  máximo `VISIBLE_ROWS` = 4 opciones. Si hay más, aparece una barra de
  scroll metálica a la derecha (arrastre, clic en el riel, rueda y
  teclado).

Los menús se siguen construyendo como `QMenu` (con `addAction`, `addMenu` y
`addSeparator`): el `QMenu` es solo el modelo de acciones y nunca se
muestra. La persiana lee sus acciones y llama a `QAction.trigger()`, de modo
que los manejadores existentes no cambian.
"""

from PySide6.QtWidgets import QWidget, QToolButton
from PySide6.QtCore import Qt, QRectF, QPoint, QTimer
from PySide6.QtGui import QPainter, QColor, QPen, QFont, QFontMetrics

from lorito_aldhiro.frontend.support import lorito_svg_skins as skins

VISIBLE_ROWS = 4          # opciones visibles por persiana (el monolito de origen: 10)
ROW_H = 24                # alto de fila (el SVG usa 30 a escala el monolito de origen)
BOX_PAD = 5               # margen interior vertical de la persiana
MIN_W = 220               # ancho del SVG de la usuaria
TEXT_PAD = 12
SB_TRACK_W = 10
SB_THUMB_W = 7
SB_MARGIN = 4
MIN_THUMB_H = 14


def _menu_font(px: int = 10, bold: bool = True) -> QFont:
    f = QFont("monospace")
    f.setStyleHint(QFont.Monospace)
    f.setPixelSize(px)
    f.setBold(bold)
    f.setLetterSpacing(QFont.AbsoluteSpacing, 1)
    return f


def dropdown_entries(menu) -> list:
    """Filas de la persiana a partir de un `QMenu`: un dict por acción visible,
    con `sep_above` cuando la precede un separador. Los separadores no
    ocupan fila: son líneas finas sobre la opción siguiente."""
    rows, pending_sep = [], False
    for act in menu.actions():
        if not act.isVisible():
            continue
        if act.isSeparator():
            pending_sep = bool(rows)
            continue
        rows.append({"action": act, "sep_above": pending_sep, "submenu": act.menu()})
        pending_sep = False
    return rows


class ScrollModel:
    """Ventana de `visible` filas sobre `count` (sin Qt, para las pruebas)."""

    def __init__(self, count: int, visible: int = VISIBLE_ROWS):
        self.count = max(0, int(count))
        self.visible = max(1, int(visible))
        self.top = 0

    @property
    def scrollable(self) -> bool:
        return self.count > self.visible

    @property
    def max_top(self) -> int:
        return max(0, self.count - self.visible)

    def set_top(self, top: int) -> int:
        self.top = min(max(0, int(top)), self.max_top)
        return self.top

    def scroll(self, rows: int) -> int:
        return self.set_top(self.top + rows)

    def ensure_visible(self, idx: int) -> int:
        if idx < self.top:
            self.set_top(idx)
        elif idx >= self.top + self.visible:
            self.set_top(idx - self.visible + 1)
        return self.top

    def thumb(self, track_h: float) -> tuple:
        """(y, h) del pulgar dentro de un riel de alto `track_h`."""
        if not self.scrollable:
            return 0.0, float(track_h)
        h = max(MIN_THUMB_H, track_h * self.visible / self.count)
        y = (track_h - h) * self.top / self.max_top
        return y, h

    def top_for_thumb_y(self, y: float, track_h: float) -> int:
        _, h = self.thumb(track_h)
        span = max(1.0, track_h - h)
        return self.set_top(round(min(max(0.0, y), span) / span * self.max_top))


# ═════════════════════════════════════════════════════════════════════════════
#  Barra
# ═════════════════════════════════════════════════════════════════════════════
class LoritoMenuBar(QWidget):
    """Placa de aluminio de la barra de menús, con tornillos en los
    extremos. Los botones se reparten a ancho igual entre los tornillos."""

    # Proporciones del SVG de la usuaria (placa 820×40): botones de 28 px a
    # 6 px del borde superior, separados 10 px, a 30 px de cada canto
    # (los tornillos van a 13 px).
    SCREW_ZONE = 30
    GAP = 10
    BTN_INSET_Y = 6
    # Margen de la sombra de la placa (el widget es más grande que la placa).
    SHADOW_X = 6
    SHADOW_TOP = 2
    SHADOW_BOTTOM = 8

    def __init__(self, parent=None):
        super().__init__(parent)
        self._buttons: list = []
        self._dropdown = None

    def add_button(self, btn) -> None:
        self._buttons.append(btn)
        btn._bar = self

    def buttons(self) -> list:
        return list(self._buttons)

    def layout_buttons(self, w: int, h: int) -> list:
        """Reparte los botones a ancho igual sobre la placa de `w`×`h`
        (sin la sombra); devuelve sus rects (x, y, w, h) en el widget."""
        n = len(self._buttons)
        if not n:
            return []
        avail = w - 2 * self.SCREW_ZONE - (n - 1) * self.GAP
        bw = avail // n
        x0 = self.SHADOW_X + self.SCREW_ZONE + (avail - bw * n) // 2
        bh = h - 2 * self.BTN_INSET_Y
        rects = []
        for i, b in enumerate(self._buttons):
            r = (x0 + i * (bw + self.GAP), self.SHADOW_TOP + self.BTN_INSET_Y, bw, bh)
            b.setGeometry(*r)
            rects.append(r)
        return rects

    def open_menu(self, btn) -> None:
        """Abre la persiana del botón (o la cierra si ya era la abierta)."""
        cur = self._dropdown
        if cur is not None and cur.isVisible():
            same = cur._button is btn
            cur.close()
            if same:
                return
        menu = vars(btn).get("_lorito_menu")
        if menu is None:
            return
        dd = LoritoDropdown(menu, button=btn, parent=self.window())
        self._dropdown = dd
        btn.set_active(True)
        dd.popup(btn.mapToGlobal(QPoint(0, btn.height() + 2)))

    def current_dropdown(self):
        dd = self._dropdown
        return dd if dd is not None and dd.isVisible() else None

    def paintEvent(self, _):
        p = QPainter(self)
        w, h = self.width(), self.height()
        sv = skins.svg_menu_bar(w, h, self.SHADOW_X, self.SHADOW_TOP, self.SHADOW_BOTTOM)
        if not skins.paint_svg(p, sv, 0, 0, w, h, self):
            p.fillRect(self.SHADOW_X, self.SHADOW_TOP, w - 2 * self.SHADOW_X,
                       h - self.SHADOW_TOP - self.SHADOW_BOTTOM, QColor("#2c3034"))
        p.end()


class LoritoMenuButton(QToolButton):
    """Botón de la barra: placa metálica con texto monoespaciado; cian
    mientras su persiana está abierta."""

    def __init__(self, label: str, parent=None):
        super().__init__(parent)
        self.setText(label)
        self._active = False
        self._lorito_menu = None
        self._bar = None
        self.setAttribute(Qt.WA_Hover, True)

    def set_active(self, on: bool) -> None:
        self._active = bool(on)
        self.update()

    def is_active(self) -> bool:
        return bool(vars(self).get("_active"))

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        active = self.is_active()
        skins.paint_svg(p, skins.svg_menu_button(w, h, active), 0, 0, w, h, self)
        p.setFont(_menu_font(11))
        if not self.isEnabled():
            col = QColor(120, 126, 134, 150)
        elif active:
            col = QColor(skins.MENU_CYAN)
        elif self.underMouse():
            col = QColor(230, 236, 242)
        else:
            col = QColor(skins.MENU_TEXT)
        p.setPen(col)
        fm = p.fontMetrics()
        txt = fm.elidedText(self.text(), Qt.ElideRight, max(8, w - 8))
        p.drawText(QRectF(0, 0, w, h), Qt.AlignCenter, txt)
        p.end()


# ═════════════════════════════════════════════════════════════════════════════
#  Persiana
# ═════════════════════════════════════════════════════════════════════════════
class LoritoDropdown(QWidget):
    """Persiana desplegable de Lorito: `VISIBLE_ROWS` opciones a la vista y
    barra de scroll derecha cuando hay más. Los submenús (DBX, LUCHA,
    DITHER) abren otra persiana igual a la derecha de la fila."""

    def __init__(self, menu, button=None, parent=None, parent_dropdown=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self._menu = menu
        self._button = button
        self._parent_dd = parent_dropdown
        self._child = None
        self._rows = dropdown_entries(menu)
        self._model = ScrollModel(len(self._rows), VISIBLE_ROWS)
        self._hover = -1
        self._drag_dy = None
        self._closing_chain = False
        self._font = _menu_font(10, bold=False)
        self._font_hi = _menu_font(10, bold=True)
        self._font_sc = _menu_font(9, bold=False)
        self.resize(*self.preferred_size())

    # ── geometría ────────────────────────────────────────────────────────────
    def rows(self) -> list:
        return list(self._rows)

    def model(self) -> ScrollModel:
        return self._model

    def visible_rows(self) -> int:
        return min(VISIBLE_ROWS, len(self._rows))

    def preferred_size(self) -> tuple:
        fm = QFontMetrics(self._font_hi)
        fms = QFontMetrics(self._font_sc)
        widest = 0
        for r in self._rows:
            a = r["action"]
            tw = fm.horizontalAdvance(a.text().replace("&", ""))
            sc = a.shortcut().toString()
            if sc:
                tw += 16 + fms.horizontalAdvance(sc)
            if r["submenu"] is not None:
                tw += 14
            widest = max(widest, tw)
        w = widest + 2 * TEXT_PAD + 8
        if self._model.scrollable:
            w += SB_TRACK_W + SB_MARGIN
        w = max(MIN_W, w)
        win = self.parentWidget()
        if win is not None:
            w = min(w, max(MIN_W, win.width() - 8))
        h = 2 * BOX_PAD + max(1, self.visible_rows()) * ROW_H
        return int(w), int(h)

    def _content_w(self) -> int:
        w = self.width() - 2 * 4
        if self._model.scrollable:
            w -= SB_TRACK_W + SB_MARGIN
        return w

    def row_rect(self, idx: int) -> QRectF:
        """Rect de la fila `idx` (índice absoluto) en coordenadas locales."""
        k = idx - self._model.top
        return QRectF(4, BOX_PAD + k * ROW_H, self._content_w(), ROW_H)

    def track_rect(self) -> QRectF:
        x = self.width() - SB_MARGIN - SB_TRACK_W
        return QRectF(x, BOX_PAD, SB_TRACK_W, self.height() - 2 * BOX_PAD)

    def thumb_rect(self) -> QRectF:
        tr = self.track_rect()
        y, h = self._model.thumb(tr.height())
        return QRectF(tr.x() + (SB_TRACK_W - SB_THUMB_W) / 2.0, tr.y() + y, SB_THUMB_W, h)

    def index_at(self, pos) -> int:
        if pos.x() >= 4 + self._content_w():
            return -1
        k = int((pos.y() - BOX_PAD) // ROW_H)
        if 0 <= k < self.visible_rows() and pos.y() >= BOX_PAD:
            idx = self._model.top + k
            return idx if idx < len(self._rows) else -1
        return -1

    # ── apertura / cierre ────────────────────────────────────────────────────
    def popup(self, global_pos) -> None:
        w, h = self.width(), self.height()
        x, y = global_pos.x(), global_pos.y()
        win = self.parentWidget()
        if win is not None:
            top_left = win.mapToGlobal(QPoint(0, 0))
            x = min(x, top_left.x() + win.width() - w - 2)
            x = max(x, top_left.x() + 2)
        self.move(x, y)
        self.show()
        self.setFocus()

    def close_chain(self) -> None:
        """Cierra esta persiana, sus hijas y sus madres."""
        dd = self
        while dd._parent_dd is not None:
            dd = dd._parent_dd
        dd._close_down()

    def _close_down(self) -> None:
        child = self._child
        self._child = None
        if child is not None:
            child._close_down()
        self.close()

    def closeEvent(self, ev):
        btn = self._button
        if btn is not None:
            btn.set_active(False)
            bar = vars(btn).get("_bar")
            # WA_DeleteOnClose: la barra no debe quedarse con un puntero muerto.
            if bar is not None and bar._dropdown is self:
                bar._dropdown = None
        parent = self._parent_dd
        if parent is not None and parent._child is self:
            parent._child = None
        child = self._child
        self._child = None
        if child is not None and child.isVisible():
            child.close()
        super().closeEvent(ev)

    # ── activación ───────────────────────────────────────────────────────────
    def activate(self, idx: int) -> None:
        if not (0 <= idx < len(self._rows)):
            return
        row = self._rows[idx]
        act = row["action"]
        if not act.isEnabled():
            return
        if row["submenu"] is not None:
            self.open_submenu(idx)
            return
        self.close_chain()
        # Tras cerrar las persianas: el manejador puede abrir diálogos.
        QTimer.singleShot(0, act.trigger)

    def open_submenu(self, idx: int):
        row = self._rows[idx]
        if self._child is not None:
            self._child._close_down()
            self._child = None
        child = LoritoDropdown(row["submenu"], parent=self.parentWidget(),
                               parent_dropdown=self)
        self._child = child
        rr = self.row_rect(idx)
        pos = self.mapToGlobal(QPoint(int(self.width() - 4), int(rr.y() - BOX_PAD)))
        # 0.13.005: si no cabe a la derecha (menús cercanos al borde, como
        # DSP), se abre a la IZQUIERDA de su madre, sin taparla.
        win = self.parentWidget()
        if win is not None:
            right_edge = win.mapToGlobal(QPoint(0, 0)).x() + win.width() - 2
            if pos.x() + child.width() > right_edge:
                pos.setX(self.mapToGlobal(QPoint(0, 0)).x() - child.width() + 4)
        child.popup(pos)
        return child

    def set_hover(self, idx: int) -> None:
        if idx != self._hover:
            self._hover = idx
            if idx >= 0:
                self._model.ensure_visible(idx)
            self.update()

    def scroll_rows(self, n: int) -> None:
        self._model.scroll(n)
        self.update()

    # ── eventos ──────────────────────────────────────────────────────────────
    def mouseMoveEvent(self, ev):
        pos = ev.position() if hasattr(ev, "position") else ev.pos()
        if self._drag_dy is not None:
            tr = self.track_rect()
            self._model.top_for_thumb_y(pos.y() - tr.y() - self._drag_dy, tr.height())
            self.update()
            return
        idx = self.index_at(pos)
        if idx != self._hover:
            self._hover = idx
            self.update()

    def mousePressEvent(self, ev):
        pos = ev.position() if hasattr(ev, "position") else ev.pos()
        if self._model.scrollable and self.track_rect().adjusted(-2, 0, 2, 0).contains(pos):
            th = self.thumb_rect()
            if th.contains(pos):
                self._drag_dy = pos.y() - th.y()
            else:
                # clic en el riel: avanza una página hacia ese lado
                self.scroll_rows(VISIBLE_ROWS if pos.y() > th.y() else -VISIBLE_ROWS)
            return
        if not self.rect().contains(pos.toPoint() if hasattr(pos, "toPoint") else pos):
            self.close_chain()
            return
        idx = self.index_at(pos)
        if idx >= 0:
            self.activate(idx)

    def mouseReleaseEvent(self, ev):
        self._drag_dy = None

    def wheelEvent(self, ev):
        dy = ev.angleDelta().y()
        if dy:
            self.scroll_rows(-1 if dy > 0 else 1)
        ev.accept()

    def keyPressEvent(self, ev):
        k = ev.key()
        n = len(self._rows)
        if k in (Qt.Key_Down, Qt.Key_Up) and n:
            step = 1 if k == Qt.Key_Down else -1
            idx = self._hover
            for _ in range(n):
                idx = (idx + step) % n if idx >= 0 else (0 if step > 0 else n - 1)
                if self._rows[idx]["action"].isEnabled():
                    break
            self.set_hover(idx)
        elif k == Qt.Key_PageDown:
            self.scroll_rows(VISIBLE_ROWS)
        elif k == Qt.Key_PageUp:
            self.scroll_rows(-VISIBLE_ROWS)
        elif k in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.activate(self._hover)
        elif k == Qt.Key_Right and 0 <= self._hover < n and self._rows[self._hover]["submenu"] is not None:
            child = self.open_submenu(self._hover)
            if child is not None:
                child.set_hover(0)
        elif k == Qt.Key_Left and self._parent_dd is not None:
            parent = self._parent_dd
            parent._child = None
            self.close()
            parent.setFocus()
        elif k == Qt.Key_Escape:
            self.close_chain()
        else:
            super().keyPressEvent(ev)

    # ── pintura ──────────────────────────────────────────────────────────────
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        if not skins.paint_svg(p, skins.svg_dropdown(w, h), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#1a1d20"))
        top = self._model.top
        for idx in range(top, min(len(self._rows), top + VISIBLE_ROWS)):
            self._paint_row(p, idx)
        if self._model.scrollable:
            tr = self.track_rect()
            skins.paint_svg(p, skins.svg_scroll_track(int(tr.width()), int(tr.height())),
                            tr.x(), tr.y(), int(tr.width()), int(tr.height()), self)
            th = self.thumb_rect()
            skins.paint_svg(p, skins.svg_scroll_thumb(int(th.width()), max(1, int(th.height()))),
                            th.x(), th.y(), int(th.width()), max(1, int(th.height())), self)
        p.end()

    def _paint_row(self, p: QPainter, idx: int) -> None:
        row = self._rows[idx]
        act = row["action"]
        rr = self.row_rect(idx)
        if row["sep_above"] and idx != self._model.top:
            p.setPen(QPen(QColor(skins.MENU_SEPARATOR), 1))
            p.drawLine(int(rr.x() + 6), int(rr.y()), int(rr.right() - 6), int(rr.y()))
        hi = idx == self._hover and act.isEnabled()
        if hi:
            p.setPen(QPen(QColor(skins.MENU_CYAN), 0.8))
            p.setBrush(QColor("#242c34"))
            p.drawRoundedRect(rr.adjusted(1, 2, -1, -2), 3, 3)
            p.setBrush(Qt.NoBrush)
        if not act.isEnabled():
            col = QColor(90, 98, 106)
        elif hi:
            col = QColor(skins.MENU_CYAN)
        else:
            col = QColor(skins.MENU_TEXT)
        text_r = rr.adjusted(TEXT_PAD, 0, -TEXT_PAD, 0)
        right_reserve = 0
        sc = act.shortcut().toString()
        if row["submenu"] is not None:
            p.setPen(col)
            p.setFont(self._font_hi)
            p.drawText(text_r, Qt.AlignRight | Qt.AlignVCenter, "▸")
            right_reserve = 14
        elif sc:
            p.setFont(self._font_sc)
            p.setPen(QColor(skins.MENU_SHORTCUT))
            p.drawText(text_r, Qt.AlignRight | Qt.AlignVCenter, sc)
            right_reserve = QFontMetrics(self._font_sc).horizontalAdvance(sc) + 12
        if act.isCheckable() and act.isChecked():
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(skins.MENU_CYAN))
            p.drawEllipse(QRectF(rr.x() + 4, rr.center().y() - 2, 4, 4))
            p.setBrush(Qt.NoBrush)
        font = self._font_hi if hi else self._font
        p.setFont(font)
        p.setPen(col)
        fm = QFontMetrics(font)
        avail = int(text_r.width() - right_reserve)
        p.drawText(text_r.adjusted(0, 0, -right_reserve, 0), Qt.AlignLeft | Qt.AlignVCenter,
                   fm.elidedText(act.text().replace("&", ""), Qt.ElideRight, avail))
