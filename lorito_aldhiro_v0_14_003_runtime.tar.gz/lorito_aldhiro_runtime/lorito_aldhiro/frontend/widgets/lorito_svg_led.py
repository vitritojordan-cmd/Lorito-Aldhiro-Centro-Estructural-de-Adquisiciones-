from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: LED circular del SVG del LCD Display, pintado con QPainter (sin dependencias de otros widgets).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


lorito_svg_led.py — el LED del SVG del LCD Display, separado de
`lorito_svg_panels` en 0.14 (LA-GOLDEN-CORE-020 §5) para romper el ciclo
de imports `lorito_indicators` ↔ `lorito_svg_panels`: el indicador lo
importaba dentro de `paintEvent` para esquivar ese ciclo.
"""

from PySide6.QtCore import Qt, QPointF
from PySide6.QtGui import QBrush, QColor, QPainter, QPen, QRadialGradient


def paint_svg_led(p: QPainter, cx: float, cy: float, radius: float, color: QColor,
                  lit: bool = True) -> None:
    """LED circular del SVG del LCD Display (zócalo rebajado + halo +
    lente + punto especular), escalado a `radius` (10 en el original)."""
    k = radius / 10.0
    bez = QRadialGradient(cx, cy, 10 * k)
    bez.setColorAt(0.0, QColor("#0a0c0e")); bez.setColorAt(0.7, QColor("#161a1e"))
    bez.setColorAt(1.0, QColor("#383d42"))
    p.setPen(QPen(QColor("#080a0c"), 1.5 * k)); p.setBrush(QBrush(bez))
    p.drawEllipse(QPointF(cx, cy), 10 * k, 10 * k)
    p.setPen(QPen(QColor(255, 255, 255, 38), 0.8 * k)); p.setBrush(Qt.NoBrush)
    p.drawEllipse(QPointF(cx, cy), 8.5 * k, 8.5 * k)
    if lit:
        halo = QRadialGradient(cx, cy, 11 * k)
        c0 = QColor(color); c0.setAlpha(110)
        c1 = QColor(color); c1.setAlpha(0)
        halo.setColorAt(0.0, c0); halo.setColorAt(1.0, c1)
        p.setPen(Qt.NoPen); p.setBrush(QBrush(halo))
        p.drawEllipse(QPointF(cx, cy), 11 * k, 11 * k)
    lens = QRadialGradient(cx - 2 * k, cy - 2 * k, 6.5 * k)
    if lit:
        lens.setColorAt(0.0, QColor("#ffffff")); lens.setColorAt(0.3, color)
        lens.setColorAt(1.0, color.darker(190))
    else:
        dim = QColor(color).darker(260)
        lens.setColorAt(0.0, dim.lighter(170)); lens.setColorAt(1.0, dim)
    p.setPen(Qt.NoPen); p.setBrush(QBrush(lens))
    p.drawEllipse(QPointF(cx, cy), 6 * k, 6 * k)
    p.setBrush(QColor(255, 255, 255, 204 if lit else 90))
    p.drawEllipse(QPointF(cx - 2 * k, cy - 2 * k), 1.5 * k, 1.5 * k)
