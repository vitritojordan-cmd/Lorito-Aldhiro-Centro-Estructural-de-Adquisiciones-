from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Cuentavueltas analógico de tambores ámbar montado por fuera del vidrio del panel de duración de cinta.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Cuentavueltas analógico de Lorito Aldhiro (0.13, SVG de la usuaria).

**Montaje (criterio del Vitreous Subeventos del monolito de origen).** En el monolito de origen el
cuentavueltas es un *control manual externo*: no es contenido detrás del
cristal, sino una pieza física montada por fuera de la carcasa vitrificada.
Por eso es un widget **hermano** del panel, en el mismo padre, colocado en
las coordenadas de su celda y siempre elevado (`raise_()`) por encima del
recubrimiento vítreo. Así el brillo del vidrio no lo tiñe. El panel de
duración de cinta no pinta nada detrás: bisel y chasis son siempre los del SVG.

**Diseño.** Del SVG de la usuaria:

- chasis oscuro, bolsillo hundido;
- tambores cilíndricos con gradiente ámbar (#ffb020 en el centro);
- dígitos oscuros con brillo ámbar, y los vecinos de arriba y abajo
  atenuados (0,2 / 0,4) sobre la superficie del cilindro;
- separadores verticales entre ruedas;
- vidrio con brillo, bisel metálico fino y cuatro tornillos.

**En privilegio del cuentavueltas de Lorito:**

- 3 rodillos (000–999) en vez de los 4 del SVG;
- fuente LLPixel del cuentavueltas;
- la física de giro del `TapeLogPanel` (impulso y decaimiento según el
  radio del carrete receptor), que rueda el tambor de forma continua: el
  dígito actual sale por arriba y el siguiente entra por abajo;
- los estados del panel: activo (ámbar encendido), pausa / espera
  (atenuado), desborde "OvFlow" (el ámbar alterna con el color de aviso en
  la fase de parpadeo del panel) e inactivo (EXPULSIÓN: tambores apagados).

El widget no calcula nada: pinta la `CounterSnapshot` que publica el panel
de cinta visible (`set_snapshot`).
"""

import math
from dataclasses import dataclass

from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QPainter, QColor, QLinearGradient, QBrush, QPen

from lorito_aldhiro.frontend.support import lorito_svg_skins as skins
from lorito_aldhiro.frontend.support.lorito_fonts import font_cuentavueltas

N_DRUMS = 3
AMBER = (0xFF, 0xB0, 0x20)
DIGIT_INK = QColor("#181003")


@dataclass(frozen=True)
class CounterSnapshot:
    values: tuple = (0, 0, 0)        # dígito visible de cada rodillo [centenas, decenas, unidades]
    roll: tuple = (0.0, 0.0, 0.0)    # 0 = quieto; 0..1 = el siguiente entra desde abajo
    state: str = "inactive"          # active / paused / waiting / inactive / transport / held
    overflow: bool = False
    blink: bool = True               # fase de parpadeo del panel (desborde)
    warn_rgb: tuple = (255, 0, 204)  # color de aviso de desborde de la cinta
    rms: float = 0.0
    label: str = "C-60"
    # Orden VIEW-SIGSEGV-019 §5: calidad declarada de la lectura. Sin
    # sensor físico de vueltas la lectura es siempre ESTIMATED; sin fuente,
    # UNKNOWN (tambores apagados, no se inventa precisión).
    quality: str = "ESTIMATED"
    source: str = "capture"          # capture (panel de cinta) | transport (PLAY, FF/REW)

    @property
    def value(self) -> int:
        v = self.values
        return v[0] * 100 + v[1] * 10 + v[2]


def counter_size(height: int) -> tuple:
    """(ancho, alto) en px del cuentavueltas de 3 rodillos para un alto dado."""
    s = height / skins.COUNTER_UNITS_H
    return int(round(skins.counter_units_w(N_DRUMS) * s)), int(height)


def drum_light(state: str, overflow: bool, blink: bool, warn_rgb) -> tuple:
    """(r, g, b, nivel) de la luz del tambor según el estado del panel."""
    if state == "inactive":
        return AMBER + (0.0,)
    if state == "held":                       # transporte detenido: valor congelado
        return AMBER + (0.6,)
    if overflow and blink:
        return tuple(warn_rgb) + (1.0,)
    if state in ("paused", "waiting"):
        return AMBER + (0.45,)
    return AMBER + (1.0,)


class TapeCounterDrums(QWidget):
    """Cuentavueltas de tambores ámbar. Hermano del panel de cinta, elevado
    por encima del vidrio del Metaloric Panel (ver docstring del módulo)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAutoFillBackground(False)
        self._snap = CounterSnapshot()
        self._sources: dict = {}

    def set_snapshot(self, snap: CounterSnapshot, source: str = "capture") -> None:
        """Publica la instantánea de una fuente. Prioridad: la captura en
        curso (panel de cinta activo); si no la hay, el transporte (PLAY y
        FF/REW, desde la posición confirmada); si tampoco, reposo."""
        self._sources[source] = snap
        self._select()

    def clear_source(self, source: str) -> None:
        self._sources.pop(source, None)
        self._select()

    def _select(self) -> None:
        cap = self._sources.get("capture")
        tr = self._sources.get("transport")
        if cap is not None and cap.state != "inactive":
            snap = cap
        elif tr is not None:
            snap = tr
        else:
            snap = cap if cap is not None else CounterSnapshot()
        if snap.quality == "UNKNOWN":
            snap = CounterSnapshot(state="inactive", quality="UNKNOWN", label=snap.label,
                                   source=snap.source)
        if snap != self._snap:
            self._snap = snap
            self.update()

    def snapshot(self) -> CounterSnapshot:
        return self._snap

    # ── geometría (unidades del SVG escaladas al alto) ──────────────────────
    def _scale(self) -> float:
        return self.height() / skins.COUNTER_UNITS_H

    def drum_rects(self) -> list:
        s = self._scale()
        x0 = (skins.COUNTER_POCKET_X_U + skins.COUNTER_DRUM_X_U) * s
        y0 = (skins.COUNTER_POCKET_Y_U + skins.COUNTER_DRUM_Y_U) * s
        d, pitch = skins.COUNTER_DRUM_U * s, skins.COUNTER_PITCH_U * s
        return [QRectF(x0 + i * pitch, y0, d, d) for i in range(N_DRUMS)]

    # ── pintura ──────────────────────────────────────────────────────────────
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        if not skins.paint_svg(p, skins.svg_tape_counter_back(w, h, N_DRUMS), 0, 0, w, h, self):
            p.fillRect(0, 0, w, h, QColor("#0d0e10"))
        snap = self._snap
        r, g, b, level = drum_light(snap.state, snap.overflow, snap.blink, snap.warn_rgb)
        rects = self.drum_rects()
        for i, rect in enumerate(rects):
            self._paint_drum(p, rect, snap.values[i], snap.roll[i], (r, g, b), level, snap.rms)
        # Separadores verticales entre ruedas
        s = self._scale()
        p.setPen(QPen(QColor(0, 0, 0), max(1.0, 2.0 * s)))
        for a, b2 in zip(rects, rects[1:]):
            x = (a.right() + b2.left()) / 2.0
            p.drawLine(int(round(x)), int(a.top()), int(round(x)), int(a.bottom()))
        # Sombra de oclusión horizontal sobre los tambores (opacidad 0,15)
        top, bot = rects[0].top(), rects[0].bottom()
        occ = QLinearGradient(0, top, 0, bot)
        occ.setColorAt(0.0, QColor(0, 0, 0, 90))
        occ.setColorAt(0.5, QColor(0, 0, 0, 0))
        occ.setColorAt(1.0, QColor(0, 0, 0, 90))
        p.fillRect(QRectF(rects[0].left(), top, rects[-1].right() - rects[0].left(), bot - top),
                   QBrush(occ))
        skins.paint_svg(p, skins.svg_tape_counter_front(w, h, N_DRUMS), 0, 0, w, h, self)
        p.end()

    def _paint_drum(self, p: QPainter, rect: QRectF, digit: int, roll: float, rgb, level, rms):
        r, g, b = rgb

        def mix(c, k):
            return QColor(int(c[0] * k), int(c[1] * k), int(c[2] * k))
        # Gradiente cilíndrico: oscuro en los bordes, color de luz en el centro.
        lit = max(0.12, level)
        grad = QLinearGradient(0, rect.top(), 0, rect.bottom())
        grad.setColorAt(0.00, QColor("#1a1204"))
        grad.setColorAt(0.18, mix((0x38, 0x26, 0x0a), max(0.5, lit)))
        grad.setColorAt(0.50, mix((r, g, b), lit))
        grad.setColorAt(0.82, mix((0x38, 0x26, 0x0a), max(0.5, lit)))
        grad.setColorAt(1.00, QColor("#140e02"))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(grad))
        p.drawRoundedRect(rect, 1.5, 1.5)
        p.setPen(QPen(QColor(0, 0, 0, 204), 1.2))
        p.drawLine(rect.topLeft(), rect.topRight())
        p.drawLine(rect.bottomLeft(), rect.bottomRight())

        # Dígitos sobre la superficie del cilindro: paso = 40/58 del tambor
        # (como en el SVG), el actual centrado y los vecinos atenuados.
        pitch = rect.height() * (40.0 / 58.0)
        f = font_cuentavueltas(size=1)
        f.setPixelSize(max(8, int(rect.height() * 0.62)))
        f.setBold(True)
        p.setFont(f)
        p.save()
        p.setClipRect(rect)
        # Posición continua del tambor: el panel fija el dígito NUEVO y deja
        # decaer `roll` (1 → 0), así que el tambor está en `dígito − roll`:
        # el anterior sale por arriba y el nuevo llega desde abajo.
        pos = digit - max(0.0, min(1.0, roll))
        base = math.floor(pos)
        frac = pos - base
        cy = rect.center().y() - frac * pitch
        glow = min(1.0, 0.35 + rms * 0.9) * level
        for k, alpha in ((-1, 0.2), (0, 1.0 - 0.6 * frac), (1, 0.4 + 0.6 * frac), (2, 0.1)):
            d = (base + k) % 10
            y = cy + k * pitch
            box = QRectF(rect.left(), y - pitch / 2.0, rect.width(), pitch)
            if k == (1 if frac >= 0.5 else 0) and glow > 0.02:
                # amberGlow (desenfoque 2) → halo ámbar alrededor del dígito
                p.setPen(QColor(r, g, b, int(110 * glow)))
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    p.drawText(box.translated(dx, dy), Qt.AlignCenter, str(d))
            ink = QColor(DIGIT_INK)
            ink.setAlphaF(alpha)
            p.setPen(ink)
            p.drawText(box, Qt.AlignCenter, str(d))
        p.restore()
