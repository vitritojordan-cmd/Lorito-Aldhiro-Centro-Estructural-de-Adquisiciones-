from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de captura de audio en tiempo real — callback, ring buffer, escritura a disco.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Motor Golden de Captura (Orden Maestra de Ingeniería, Refactorización
Golden del Motor de Captura, Lorito Aldhiro 0.11.001 → 0.12).

Camino archivístico (ver CAPTURE_ARCHITECTURE_GOLDEN.md):

  PortAudio ─► _audio_callback ─► SPSCCaptureRing ─► drain ─► CED ─► DiskWriterV2
     (RT)      sin locks/IO/log     sin overwrite      no-RT    finita   dueño único
                                    sin truncamiento   bloquea  (frames) del archivo
                                                       por back-
                                                       pressure

  · La pérdida solo puede ocurrir en UN punto (ring lleno / bloque
    inválido) y siempre es DECLARADA: FrameLedger + discontinuidad +
    fail-stop (sesión FAILED, clasificación INVALID).
  · La salida visual y el DSP (DERIVED) no comparten backpressure con el
    RAW: ruta con pérdida permitida y contabilizada.
  · El ciclo de vida lo gobierna `CaptureSessionFSM` (IDLE → ARMING →
    CAPTURING ↔ PAUSED → DRAINING → FINALIZING → CLASSIFIED / FAILED).
  · `request_stop()` y `finalize()` están separados; un timeout NUNCA se
    traduce en éxito (FINALIZATION_INCOMPLETE bloquea ARCHIVAL_SAFE).
"""

import sys
import os
import threading
import time
import logging
import errno
import uuid
import datetime
from collections import deque
from dataclasses import dataclass, field
import numpy as np
import sounddevice as sd
import soundfile as sf
from typing import Optional, List, Callable, Dict, Any

from lorito_aldhiro.backend.core.lorito_identity import thread_name
from lorito_aldhiro.backend.core.lorito_constants import CE_CED_BATCH_FRAMES, CE_CED_CAPACITY, CE_CHANNELS, CE_DISK_FLUSH_SETTLE_MAX_S, CE_DISK_FSYNC_EVERY, CE_DISK_WRITE_RETRY_MAX, CE_DISK_WRITE_RETRY_SLEEP, CE_DRAIN_BATCH_MAX, CE_DRAIN_BATCH_MIN, CE_JITTER_EWMA_ALPHA, CE_JITTER_HIST_SIZE, CE_PREROLL_SECS_DEFAULT, CE_PREROLL_SECS_MAX, CE_RBA_FRAMES_MAX, CE_RBA_SLOTS, CE_RBA_WATERMARK_CRIT, CE_RBA_WATERMARK_HIGH, CE_RBA_WATERMARK_LOW, CE_RBA_WATERMARK_MID, CE_RECOVERY_BACKOFF_BASE, CE_RECOVERY_BACKOFF_CAP, CE_RECOVERY_COOLDOWN, CE_RECOVERY_MAX_ATTEMPTS, CE_SAMPLE_RATE_DEFAULT, CE_WD_ORANGE_SECS, CE_WD_RED_SECS, CE_WD_TICK_SECS, CE_WD_YELLOW_SECS, CE_WM_HYSTERESIS, _ce_log
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _LIBC, _set_rt_priority
from lorito_aldhiro.backend.core.lorito_timing import CaptureClock, _monotonic_raw_ns
from lorito_aldhiro.backend.archival.lorito_segment_checksum import compute_segment_checksum
# GAP-052 (§8/§9, FASE 2 de la Orden de Saneamiento, Integración y
# Consolidación): aliasado para no chocar de nombre con el método
# `CaptureEngineV2.classify_session()` definido más abajo.
from lorito_aldhiro.backend.archival.lorito_archival_state import (
    classify_session as _classify_archival_session,
)
from lorito_aldhiro.backend.rt.lorito_capture_ring import (
    SPSCCaptureRing, WRITE_OK, RING_FULL, BLOCK_OVERSIZE, BLOCK_SHAPE,
    WRITE_DISABLED, WRITE_RESULT_NAMES, LOCK_FREE_VERIFIED,
)
from lorito_aldhiro.backend.capture.lorito_frame_ledger import FrameLedger
from lorito_aldhiro.backend.capture.lorito_capture_status import CaptureEngineStatus
from lorito_aldhiro.backend.telemetry.lorito_meter import (
    CaptureMeter, CaptureTelemetrySnapshot, VALID as _METER_VALID,
)
from lorito_aldhiro.backend.telemetry.lorito_waveform_envelope import LiveEnvelopeRing
from lorito_aldhiro.backend.telemetry.lorito_signal_intensity_meter import (
    SignalIntensityMeterEngine, SOURCE_REC,
)
from lorito_aldhiro.backend.capture.lorito_capture_session import (
    CaptureSessionFSM, CaptureState, IllegalTransition,
)


# ── Política de saturación (Orden Golden, CAP-002/CAP-010) ──────────────────
#   FAIL_STOP        — primera pérdida: sesión FAILED, ring deshabilitado,
#                      stream cerrado, archivo parcial preservado y
#                      clasificado INVALID. (Política por defecto.)
#   CONTINUE_INVALID — la pérdida se declara y la sesión queda INVALID de
#                      forma irreversible, pero se sigue grabando (para el
#                      operador que prefiere no perder lo que viene).
OVERFLOW_POLICY_FAIL_STOP = "FAIL_STOP"
OVERFLOW_POLICY_CONTINUE_INVALID = "CONTINUE_INVALID"

CE_STOP_QUIESCE_TIMEOUT_S = 2.0     # espera de quiescencia del callback
CE_STOP_DRAIN_TIMEOUT_S   = 30.0    # vaciado del ring hacia la CED
CE_FINALIZE_TIMEOUT_S     = 60.0    # flush_barrier + cierre del writer
CE_DISK_FREE_MIN_BYTES    = 50 * 1024 * 1024
CE_DISK_FREE_CHECK_S      = 1.0
CE_DSP_BUDGET_FRACTION    = 0.5     # DSP en drain: ≤ 50 % de la duración del bloque
CE_DSP_BUDGET_STRIKES     = 8       # bloques consecutivos fuera de presupuesto

# errno que NUNCA se reintentan: el writer pasa a fallo terminal.
_FATAL_ERRNOS = frozenset(e for e in (
    getattr(errno, "ENOSPC", None), getattr(errno, "EIO", None),
    getattr(errno, "EACCES", None), getattr(errno, "EPERM", None),
    getattr(errno, "EROFS", None), getattr(errno, "ENODEV", None),
    getattr(errno, "ENXIO", None), getattr(errno, "EDQUOT", None),
    getattr(errno, "ENOENT", None), getattr(errno, "EBADF", None),
) if e is not None)
_RETRYABLE_ERRNOS = frozenset(e for e in (
    getattr(errno, "EINTR", None), getattr(errno, "EAGAIN", None),
) if e is not None)


def _fsync_file_path(path: str) -> None:
    """fsync real del archivo por ruta. No depende de `f.buffer.fileno()`
    (CAP-009): abre un descriptor propio del mismo inodo. En Linux,
    fsync(2) vacía todas las páginas sucias del inodo, no solo las del
    descriptor. En Windows se requiere acceso de escritura para
    FlushFileBuffers. Cualquier error se PROPAGA (fallo de integridad)."""
    flags = os.O_RDONLY
    if os.name == "nt":
        flags = os.O_RDWR | getattr(os, "O_BINARY", 0)
    fd = os.open(path, flags)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _fsync_dir(path: str) -> bool:
    """fsync del directorio que contiene `path` (persistencia de la
    entrada de directorio tras crear/renombrar). Devuelve False si la
    plataforma o el filesystem no lo soportan (nivel de durabilidad
    reducido, declarado); propaga cualquier otro error."""
    if os.name == "nt":
        return False
    d = os.path.dirname(os.path.abspath(path)) or "."
    fd = os.open(d, os.O_RDONLY)
    try:
        os.fsync(fd)
        return True
    except OSError as e:
        if e.errno in (errno.EINVAL, getattr(errno, "ENOTSUP", errno.EINVAL),
                       getattr(errno, "EOPNOTSUPP", errno.EINVAL)):
            return False
        raise
    finally:
        os.close(fd)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 4: RING DE ABSORCIÓN — RBA (Nivel 1)
#  Orden Golden (CAP-001/CAP-002): el antiguo RBA con `threading.Condition`,
#  `notify_all`, overwrite-oldest y truncamiento silencioso queda RETIRADO.
#  `RingBufferAbsorcion` conserva el nombre por compatibilidad, pero ahora es
#  el ring SPSC sin locks y sin sobrescritura de `backend/rt`.
# ══════════════════════════════════════════════════════════════════════════════

class RingBufferAbsorcion(SPSCCaptureRing):
    """Ring de absorción SPSC (productor: callback; consumidor: drain).

    · `write()` devuelve False si el bloque NO se publicó (ring lleno,
      bloque sobredimensionado, forma inválida o escritura deshabilitada
      por fail-stop). El llamador debe declarar la pérdida.
    · Nunca sobrescribe ni trunca. No admite redimensionado en caliente:
      la memoria es fija durante toda la sesión.
    """

    def __init__(self, n_slots: int, frames_max: int, channels: int,
                 name: str = "RBA"):
        super().__init__(n_slots=n_slots, frames_max=frames_max,
                         channels=channels, name=name)

    @property
    def _count(self) -> int:
        """Alias histórico (tests de recovery no destructivo)."""
        return self.count

    @property
    def overrun_total(self) -> int:
        """Bloques rechazados por ring lleno (pérdida declarada)."""
        return self._rejected_full_blocks

    @property
    def underrun_total(self) -> int:
        return 0

    @property
    def occupancy_pct(self) -> float:
        return self.watermark_pct * 100.0

    def clear_without_reset_stats(self):
        """Solo con productor y consumidor quiescentes (lo garantiza la
        FSM de sesión): mantiene la generación activa."""
        self.reset_for_generation(self.generation)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 5: COLA ELÁSTICA DE DISCO — CED (Nivel 2)
#  Cola finita (en frames) entre drain y DiskWriter. Orden Golden (CAP-010):
#  la CED llena YA NO descarta audio RAW — el drain espera (backpressure) y
#  la presión se acumula en el ring, que es el único punto donde una pérdida
#  puede ocurrir, siempre declarada. `put_nowait()` (con descarte contado)
#  queda para rutas con pérdida permitida (DERIVED).
# ══════════════════════════════════════════════════════════════════════════════

class ColaElasticaDisco:
    """Cola finita de bloques `[frames, channels]` con número de secuencia."""

    def __init__(self, capacity: int = CE_CED_CAPACITY):
        self._cap         = capacity
        self._q           = deque()        # (bloque, seq)
        self._frame_count = 0
        self._lock        = threading.Lock()
        self._not_empty   = threading.Condition(self._lock)
        self._not_full    = threading.Condition(self._lock)
        self._dropped     = 0              # frames rechazados por put_nowait
        self._total_in    = 0
        self._total_out   = 0
        self._last_seq_in = -1
        self._closed      = False

    def _fits(self, n: int) -> bool:
        # Un bloque mayor que la capacidad total solo entra con la cola
        # vacía (evita bloqueo eterno sin violar la cota en régimen).
        return self._frame_count + n <= self._cap or self._frame_count == 0

    def put(self, block: np.ndarray, seq: int = -1, timeout: Optional[float] = None,
            should_abort: Optional[Callable[[], bool]] = None) -> bool:
        """Encola con backpressure: espera mientras la cola está llena.
        Devuelve False (sin encolar) si la cola se cerró, si
        `should_abort()` es True o si vence `timeout`."""
        n = block.shape[0]
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._not_full:
            while not self._fits(n):
                if self._closed or (should_abort is not None and should_abort()):
                    return False
                if deadline is not None:
                    rem = deadline - time.monotonic()
                    if rem <= 0:
                        return False
                    self._not_full.wait(min(rem, 0.05))
                else:
                    self._not_full.wait(0.05)
            if self._closed:
                return False
            self._q.append((block, seq))
            self._frame_count += n
            self._total_in    += n
            if seq > self._last_seq_in:
                self._last_seq_in = seq
            self._not_empty.notify()
        return True

    def put_nowait(self, block: np.ndarray, seq: int = -1) -> bool:
        """Encola sin esperar. Si no cabe devuelve False y CUENTA los
        frames en `dropped_frames` (nunca descarte silencioso)."""
        n = block.shape[0]
        with self._not_empty:
            if self._closed or self._frame_count + n > self._cap:
                self._dropped += n
                return False
            self._q.append((block, seq))
            self._frame_count += n
            self._total_in    += n
            if seq > self._last_seq_in:
                self._last_seq_in = seq
            self._not_empty.notify()
        return True

    def get_batch_seq(self, max_frames: int = CE_CED_BATCH_FRAMES,
                      timeout: float = 0.5):
        """`(array, last_seq)` con hasta `max_frames` frames, o None."""
        with self._not_empty:
            if self._frame_count == 0:
                self._not_empty.wait(timeout=timeout)
            if self._frame_count == 0:
                return None
            blocks   = []
            consumed = 0
            last_seq = -1
            while self._q:
                blk, seq = self._q[0]
                n = blk.shape[0]
                if blocks and consumed + n > max_frames:
                    break
                self._q.popleft()
                blocks.append(blk)
                consumed          += n
                self._frame_count -= n
                self._total_out   += n
                last_seq = seq
                if consumed >= max_frames:
                    break
            self._not_full.notify_all()
        if not blocks:
            return None
        if len(blocks) == 1:
            return blocks[0], last_seq
        return np.concatenate(blocks, axis=0), last_seq

    def get_batch(self, max_frames: int = CE_CED_BATCH_FRAMES,
                  timeout: float = 0.5) -> Optional[np.ndarray]:
        got = self.get_batch_seq(max_frames=max_frames, timeout=timeout)
        return None if got is None else got[0]

    def drain_all_count(self) -> int:
        """Vacía la cola y devuelve los frames retirados (para declarar
        pérdida tras un fallo terminal del writer)."""
        with self._lock:
            n = self._frame_count
            self._q.clear()
            self._frame_count = 0
            self._not_full.notify_all()
        return n

    def close(self):
        with self._lock:
            self._closed = True
            self._not_full.notify_all()
            self._not_empty.notify_all()

    def reopen(self):
        with self._lock:
            self._closed = False

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def pressure_pct(self) -> float:
        return (self._frame_count / max(self._cap, 1)) * 100.0

    @property
    def frame_count(self) -> int:
        return self._frame_count

    @property
    def dropped_frames(self) -> int:
        return self._dropped

    @property
    def total_in(self) -> int:
        return self._total_in

    @property
    def total_out(self) -> int:
        return self._total_out

    @property
    def last_seq_in(self) -> int:
        return self._last_seq_in

    def clear(self):
        with self._lock:
            self._q.clear()
            self._frame_count = 0
            self._last_seq_in = -1
            self._closed = False
            self._not_full.notify_all()

    @property
    def capacity(self) -> int:
        return self._cap

    def set_capacity(self, frames: int) -> None:
        """Capacidad en frames (0.13.002: se dimensiona en segundos según
        la frecuencia de la sesión, `lorito_rate_support.buffer_plan`)."""
        with self._lock:
            self._cap = max(1, int(frames))
            self._not_full.notify_all()


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 7: STATUS DEL MOTOR (estructura compartida de telemetría)
# ══════════════════════════════════════════════════════════════════════════════

# CaptureEngineStatus: ver lorito_capture_status (separado en 0.14.002).


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 8: PRE-ROLL BUFFER CIRCULAR
#  Mantiene los últimos N segundos antes de REC. Prealocado.
# ══════════════════════════════════════════════════════════════════════════════

class PreRollBufferV2:
    """
    Buffer circular de pre-roll. Versión hardened con prealocación.

    A diferencia de la versión anterior (deque de bloques variables),
    usa un array continuo prealocado para eliminar fragmentation del heap
    durante sesiones largas.
    """

    def __init__(self, secs: float = CE_PREROLL_SECS_DEFAULT,
                 rate: int = CE_SAMPLE_RATE_DEFAULT,
                 channels: int = CE_CHANNELS):
        self._secs     = min(max(0.0, secs), CE_PREROLL_SECS_MAX)
        self._rate     = rate
        self._channels = channels
        self._lock     = threading.Lock()
        self._active   = False
        self._buf      : Optional[np.ndarray] = None  # [max_frames, channels]
        self._write_pos = 0
        self._count    = 0
        self._max_frames = 0
        self._allocate()

    def _allocate(self):
        """Prealoca el buffer según la configuración actual."""
        max_f = int(self._rate * self._secs)
        if max_f <= 0:
            self._buf       = None
            self._max_frames = 0
            return
        self._buf        = np.zeros((max_f, self._channels), dtype=np.float32)
        self._max_frames = max_f
        self._write_pos  = 0
        self._count      = 0

    def configure(self, secs: float, rate: int):
        with self._lock:
            self._secs = min(max(0.0, secs), CE_PREROLL_SECS_MAX)
            self._rate = rate
            self._allocate()

    def push(self, block: np.ndarray):
        """
        Agrega frames al buffer circular prealocado.
        Sobrescribe los frames más antiguos cuando está lleno (circular).
        Cero allocaciones: copia directa en el array prealocado.
        """
        # Orden Golden (CAP-001): sin lock en el callback. El callback es
        # el ÚNICO escritor mientras `_active` es True; `drain()`/`clear()`/
        # `configure()` solo se invocan con el pre-roll inactivo (el motor
        # lo desactiva antes de ARMING), así que no hay carrera productor/
        # consumidor que proteger con un lock contencioso.
        buf = self._buf
        if buf is None or not self._active:
            return
        n = block.shape[0]
        max_f = self._max_frames
        if n >= max_f:
            buf[:] = block[-max_f:]
            self._write_pos = 0
            self._count     = max_f
            return
        wp = self._write_pos
        space_end = max_f - wp
        if n <= space_end:
            buf[wp:wp + n] = block
        else:
            buf[wp:]            = block[:space_end]
            buf[:n - space_end] = block[space_end:]
        self._write_pos = (wp + n) % max_f
        self._count     = min(self._count + n, max_f)

    def drain(self) -> Optional[np.ndarray]:
        """
        Drena el buffer y retorna el audio ordenado temporalmente.
        Limpia el buffer tras drenar. Retorna None si vacío.
        """
        with self._lock:
            if self._buf is None or self._count == 0:
                return None
            n = self._count
            if n == self._max_frames:
                # Buffer lleno: el audio empieza en write_pos
                start = self._write_pos
                if start == 0:
                    out = self._buf[:n].copy()
                else:
                    out = np.concatenate([
                        self._buf[start:],
                        self._buf[:start]
                    ], axis=0)
            else:
                # Buffer no lleno: audio de 0 a write_pos
                out = self._buf[:n].copy()
            # Reset
            self._write_pos = 0
            self._count     = 0
            return out

    def clear(self):
        with self._lock:
            self._write_pos = 0
            self._count     = 0

    def set_active(self, active: bool):
        self._active = active

    @property
    def buffered_secs(self) -> float:
        return self._count / max(self._rate, 1)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 9: DISK WRITER GOLDEN (Nivel 3)
#  Propietario único del archivo. Errores de write/flush/fsync/close → fallo
#  terminal con razón persistente (CAP-004). `flush_barrier(seq)` confirma
#  escritura + sincronización de todo lo anterior (CAP-009). `stop()` devuelve
#  un resultado explícito y nunca declara cerrado un hilo vivo (CAP-008).
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class FlushBarrierResult:
    ok: bool
    target_seq: int
    persisted_seq: int
    timed_out: bool = False
    reason: str = ""
    durability: str = ""


@dataclass
class WriterCloseResult:
    closed: bool
    thread_alive: bool
    frames_written: int
    frames_lost: int
    failed: bool
    failure_reason: str = ""
    verify_failures: list = field(default_factory=list)


class DiskWriterError(RuntimeError):
    def __init__(self, reason: str, err_no: Optional[int] = None):
        super().__init__(reason)
        self.reason = reason
        self.err_no = err_no


class DiskWriterV2:
    """
    Hilo dedicado de escritura a disco (dueño único del/los archivo(s)).

    Durabilidad garantizada (declarada en ARCHIVAL_CONTRACT.md):
      · `flush_barrier(seq)` → libsndfile `flush()` (cabecera + buffers al
        SO) y `fsync(2)` del archivo por descriptor propio; al crear y al
        cerrar cada segmento, `fsync` del directorio (POSIX). En Windows la
        entrada de directorio no se sincroniza (nivel reducido, declarado).
      · Un fallo de fsync es un fallo de integridad, nunca se ignora.

    API (compatible con la anterior + nueva):
      start(path_tmp, rate, channels, segment_max_secs=0.0)
      stop(timeout=20.0) → WriterCloseResult
      flush(timeout, progress_cb)            (compat)
      flush_barrier(seq, timeout) → FlushBarrierResult
      get_path(), get_segment_paths(), get_segment_checksums()
      failed / failure_reason / failure_errno
    """

    def __init__(self, ced: ColaElasticaDisco, status: CaptureEngineStatus,
                 ledger: Optional[FrameLedger] = None,
                 on_failure: Optional[Callable[[str], None]] = None,
                 subtype: str = "PCM_24", name: str = thread_name("disk")):
        self._ced          = ced
        self._status       = status
        self._ledger       = ledger if ledger is not None else FrameLedger()
        self._on_failure   = on_failure
        self._subtype      = subtype
        self._thread_name  = name
        self._active       = False
        self._thread       : Optional[threading.Thread] = None
        self._path_tmp     = ""
        self._rate         = CE_SAMPLE_RATE_DEFAULT
        self._channels     = CE_CHANNELS
        self._flush_done   = threading.Event()
        self._segment_paths: list = []
        self._segment_frames: list = []
        self._segment_max_frames = 0
        self._segment_checksums: list = []
        self._verify_failures: list = []
        self._dir_fsync_supported = True
        # Estado de fallo terminal
        self._failed       = False
        self._failure_reason = ""
        self._failure_errno: Optional[int] = None
        # Barrera de persistencia
        self._cond          = threading.Condition()
        self._written_seq   = -1
        self._persisted_seq = -1
        self._barrier_target: Optional[int] = None
        # Métricas
        self._write_ewma_ms = 0.0
        self._fsync_count   = 0
        self._blocks_since_fsync = 0
        self._frames_written_session = 0

    # ── Configuración ────────────────────────────────────────────────────────

    def attach_ledger(self, ledger: FrameLedger):
        self._ledger = ledger

    @property
    def ledger(self) -> FrameLedger:
        return self._ledger

    @property
    def failed(self) -> bool:
        return self._failed

    @property
    def failure_reason(self) -> str:
        return self._failure_reason

    @property
    def failure_errno(self) -> Optional[int]:
        return self._failure_errno

    @property
    def is_alive(self) -> bool:
        t = self._thread
        return t is not None and t.is_alive()

    @property
    def persisted_seq(self) -> int:
        return self._persisted_seq

    @property
    def durability_level(self) -> str:
        return ("FILE_FSYNC+DIR_FSYNC" if self._dir_fsync_supported
                else "FILE_FSYNC (directorio no sincronizable en esta plataforma/FS)")

    def start(self, path_tmp: str, rate: int, channels: int,
              segment_max_secs: float = 0.0):
        """Inicia el hilo de escritura (cierra antes el anterior)."""
        self.stop()
        self._path_tmp     = path_tmp
        self._rate         = rate
        self._channels     = channels
        self._active       = True
        self._flush_done.clear()
        self._segment_paths.clear()
        self._segment_frames.clear()
        self._segment_checksums.clear()
        self._verify_failures.clear()
        self._segment_max_frames = int(segment_max_secs * rate) if segment_max_secs > 0 else 0
        self._failed = False
        self._failure_reason = ""
        self._failure_errno = None
        self._written_seq = -1
        self._persisted_seq = -1
        self._barrier_target = None
        self._write_ewma_ms = 0.0
        self._fsync_count   = 0
        self._blocks_since_fsync = 0
        self._frames_written_session = 0
        self._ced.reopen()
        self._thread = threading.Thread(
            target=self._write_loop, daemon=True, name=self._thread_name)
        self._thread.start()
        self._status.disk_alive = True
        _ce_log.info("DiskWriter Golden iniciado: %s  %dHz  %dch", path_tmp, rate, channels)

    def stop(self, timeout: float = 20.0) -> WriterCloseResult:
        """Pide el cierre y espera al hilo. Si sigue vivo al vencer el
        timeout, el resultado dice `closed=False` (nunca éxito falso)."""
        self._active = False
        with self._cond:
            self._cond.notify_all()
        _t = self._thread
        alive = False
        if _t is not None and _t.is_alive() and _t is not threading.current_thread():
            _t.join(timeout=timeout)
            alive = _t.is_alive()
            if alive:
                _ce_log.error("DiskWriter thread no terminó en %.0fs — cierre "
                              "NO confirmado (bloqueo de I/O).", timeout)
        if not alive:
            self._thread = None
            self._status.disk_alive = False
        return WriterCloseResult(
            closed=not alive, thread_alive=alive,
            frames_written=self._frames_written_session,
            frames_lost=self._ledger.lost_writer,
            failed=self._failed, failure_reason=self._failure_reason,
            verify_failures=list(self._verify_failures))

    # ── Barrera de persistencia ─────────────────────────────────────────────

    def flush_barrier(self, seq: int, timeout: float = 30.0) -> FlushBarrierResult:
        """Bloquea hasta que todos los bloques con secuencia ≤ `seq` estén
        escritos Y sincronizados (flush + fsync). `seq=-1` sincroniza lo
        que haya escrito hasta ahora."""
        deadline = time.monotonic() + timeout
        with self._cond:
            self._barrier_target = seq if self._barrier_target is None \
                else max(self._barrier_target, seq)
            self._cond.notify_all()
            while True:
                if self._failed:
                    return FlushBarrierResult(False, seq, self._persisted_seq,
                                              reason=self._failure_reason,
                                              durability=self.durability_level)
                if self._persisted_seq >= seq and self._barrier_target is None:
                    return FlushBarrierResult(True, seq, self._persisted_seq,
                                              durability=self.durability_level)
                t = self._thread
                if t is None or not t.is_alive():
                    ok = self._persisted_seq >= seq and not self._failed
                    return FlushBarrierResult(ok, seq, self._persisted_seq,
                                              reason="" if ok else "WRITER_NOT_RUNNING",
                                              durability=self.durability_level)
                rem = deadline - time.monotonic()
                if rem <= 0:
                    return FlushBarrierResult(False, seq, self._persisted_seq,
                                              timed_out=True, reason="BARRIER_TIMEOUT",
                                              durability=self.durability_level)
                self._cond.wait(min(rem, 0.1))

    def flush(self, timeout: float = 30.0, progress_cb=None):
        """Compatibilidad: espera a que la CED se vacíe y luego aplica una
        barrera de persistencia sobre todo lo encolado. Devuelve el
        `FlushBarrierResult` (antes no devolvía nada)."""
        deadline = time.monotonic() + timeout
        total = max(self._ced.frame_count, 1)
        while self._ced.frame_count > 0 and time.monotonic() < deadline:
            if self._failed or not self.is_alive:
                break
            if progress_cb is not None:
                try:
                    progress_cb(self._ced.frame_count, total)
                except Exception:
                    pass
            time.sleep(0.02)
        remaining = max(0.0, deadline - time.monotonic())
        result = self.flush_barrier(self._ced.last_seq_in,
                                    timeout=min(max(remaining, 0.05),
                                                max(CE_DISK_FLUSH_SETTLE_MAX_S, remaining)))
        if progress_cb is not None:
            try:
                progress_cb(self._ced.frame_count, total)
            except Exception:
                pass
        return result

    # ── Consultas ───────────────────────────────────────────────────────────

    def get_path(self) -> str:
        return self._path_tmp

    def get_segment_paths(self) -> list:
        return list(self._segment_paths)

    def get_segment_checksums(self) -> list:
        """Checksums (SHA-256/CRC32) calculados releyendo cada segmento YA
        CERRADO y sincronizado desde disco."""
        return list(self._segment_checksums)

    def get_verify_failures(self) -> list:
        return list(self._verify_failures)

    def validate_duration(self, secs: float) -> bool:
        """Compara la duración leída del archivo con los frames que este
        writer confirma haber escrito (llamado por la GUI al sondear)."""
        expected = self._frames_written_session / max(self._rate, 1)
        ok = abs(expected - secs) <= (1.0 / max(self._rate, 1)) * 2
        if not ok:
            _ce_log.error("validate_duration: archivo=%.6fs, writer=%.6fs — discrepancia",
                          secs, expected)
        return ok

    # ── Fallo terminal ──────────────────────────────────────────────────────

    def _fail(self, reason: str, err_no: Optional[int] = None):
        if self._failed:
            return
        self._failed = True
        self._active = False
        self._failure_reason = reason
        self._failure_errno = err_no
        self._ledger.writer_failure_reason = reason
        self._status.writer_failed = True
        _ce_log.critical("DiskWriter FALLO TERMINAL: %s", reason)
        with self._cond:
            self._cond.notify_all()
        cb = self._on_failure
        if cb is not None:
            try:
                cb(reason)
            except Exception as e:
                _ce_log.error("on_failure del writer lanzó: %s", e)

    # ── Hilo de escritura ───────────────────────────────────────────────────

    def _segment_path(self, idx: int) -> str:
        if idx == 0:
            return self._path_tmp
        base, ext = os.path.splitext(self._path_tmp)
        return f"{base}_seg{idx:04d}{ext or '.wav'}"

    def _open_segment(self, idx: int):
        path = self._segment_path(idx)
        try:
            f = sf.SoundFile(path, mode="w", samplerate=self._rate,
                             channels=self._channels, subtype=self._subtype,
                             format="WAV")
        except OSError as e:
            raise DiskWriterError(f"OPEN_FAILED {path}: {e}", e.errno)
        except Exception as e:
            raise DiskWriterError(f"OPEN_FAILED {path}: {e}")
        self._segment_paths.append(path)
        self._segment_frames.append(0)
        try:
            if not _fsync_dir(path):
                self._dir_fsync_supported = False
        except OSError as e:
            raise DiskWriterError(f"DIR_FSYNC_FAILED {path}: {e}", e.errno)
        _ce_log.info("Segmento abierto: %s", path)
        return f

    def _sync(self, f, idx: int):
        """flush (libsndfile → SO) + fsync (SO → medio). Errores → fallo."""
        try:
            f.flush()
        except OSError as e:
            raise DiskWriterError(f"FLUSH_FAILED seg{idx:04d}: {e}", e.errno)
        except Exception as e:
            raise DiskWriterError(f"FLUSH_FAILED seg{idx:04d}: {e}")
        try:
            _fsync_file_path(self._segment_paths[idx])
        except OSError as e:
            raise DiskWriterError(f"FSYNC_FAILED seg{idx:04d}: {e}", e.errno)
        self._fsync_count += 1

    def _close_segment(self, f, idx: int):
        """Cierra, sincroniza y VERIFICA el segmento (cabecera, rate,
        canales, frames, checksum releído del archivo cerrado)."""
        if f is None:
            return
        err = None
        try:
            self._sync(f, idx)
        except DiskWriterError as e:
            err = e
        try:
            f.close()
        except Exception as e:
            if err is None:
                err = DiskWriterError(f"CLOSE_FAILED seg{idx:04d}: {e}",
                                      getattr(e, "errno", None))
        path = self._segment_paths[idx]
        try:
            _fsync_file_path(path)
            if not _fsync_dir(path):
                self._dir_fsync_supported = False
        except OSError as e:
            if err is None:
                err = DiskWriterError(f"FSYNC_AFTER_CLOSE_FAILED seg{idx:04d}: {e}", e.errno)
        _ce_log.info("Segmento cerrado: seg%04d", idx)
        expected_frames = self._segment_frames[idx]
        try:
            checksum = compute_segment_checksum(path)
            checksum["frames_expected"] = expected_frames
            self._segment_checksums.append(checksum)
            problems = []
            if checksum.get("frames") != expected_frames:
                problems.append(f"frames archivo={checksum.get('frames')} "
                                f"!= escritos={expected_frames}")
            if checksum.get("channels") not in (None, self._channels):
                problems.append(f"canales={checksum.get('channels')}")
            sr = checksum.get("samplerate")
            if sr is not None and sr != self._rate:
                problems.append(f"samplerate={sr}")
            if problems:
                self._verify_failures.append(f"seg{idx:04d}: " + "; ".join(problems))
                self._ledger.verified += min(int(checksum.get("frames") or 0), expected_frames)
            else:
                self._ledger.verified += expected_frames
            self._ledger.verification_ran = True
            self._status.frames_verified = self._ledger.verified
        except Exception as e:
            self._verify_failures.append(f"seg{idx:04d}: no se pudo releer/verificar: {e}")
            self._ledger.verification_ran = True
            _ce_log.error("No se pudo verificar el segmento %d: %s", idx, e)
        if err is not None:
            raise err

    def _write_with_policy(self, f, block: np.ndarray):
        """Escribe el bloque. Reintenta solo errores recuperables; los
        errno fatales y la escritura parcial son terminales."""
        n = block.shape[0]
        last_exc = None
        for attempt in range(max(1, CE_DISK_WRITE_RETRY_MAX)):
            before = getattr(f, "frames", None)
            try:
                t0 = time.monotonic()
                f.write(block)
                dt_ms = (time.monotonic() - t0) * 1000.0
                self._write_ewma_ms = 0.1 * dt_ms + 0.9 * self._write_ewma_ms
                self._status.disk_write_ms_last = dt_ms
                after = getattr(f, "frames", None)
                if isinstance(before, int) and isinstance(after, int) and after - before != n:
                    raise DiskWriterError(
                        f"PARTIAL_WRITE: {after - before}/{n} frames", getattr(errno, "EIO", None))
                return
            except DiskWriterError:
                raise
            except OSError as e:
                if e.errno in _FATAL_ERRNOS:
                    raise DiskWriterError(f"WRITE_FAILED errno={e.errno} "
                                          f"({errno.errorcode.get(e.errno, '?')}): {e}", e.errno)
                last_exc = e
                if e.errno not in _RETRYABLE_ERRNOS:
                    _ce_log.warning("sf.write() OSError no clasificado (intento %d/%d): %s",
                                    attempt + 1, CE_DISK_WRITE_RETRY_MAX, e)
            except Exception as e:
                last_exc = e
                _ce_log.warning("sf.write() excepción (intento %d/%d): %s",
                                attempt + 1, CE_DISK_WRITE_RETRY_MAX, e)
            time.sleep(CE_DISK_WRITE_RETRY_SLEEP)
        raise DiskWriterError(f"WRITE_RETRIES_EXHAUSTED: {last_exc}",
                              getattr(last_exc, "errno", None))

    def _check_free_space(self, n_frames: int):
        try:
            st = os.statvfs(os.path.dirname(os.path.abspath(self._path_tmp)) or ".")
        except (OSError, AttributeError):
            return  # plataforma sin statvfs: el error real llegará como ENOSPC
        free_bytes = st.f_bavail * st.f_frsize
        block_bytes = n_frames * self._channels * 3
        if free_bytes < max(block_bytes * 4, CE_DISK_FREE_MIN_BYTES):
            raise DiskWriterError(
                f"DISK_ALMOST_FULL: {free_bytes // 1024 // 1024} MB libres "
                f"(< {CE_DISK_FREE_MIN_BYTES // 1024 // 1024} MB) — fail-stop "
                f"preventivo antes de ENOSPC", getattr(errno, "ENOSPC", None))

    def _service_barrier(self, f, seg_idx: int):
        with self._cond:
            target = self._barrier_target
        if target is None:
            return
        if self._written_seq < target and self._ced.frame_count > 0:
            return  # todavía faltan bloques anteriores a la barrera
        self._sync(f, seg_idx)
        with self._cond:
            self._persisted_seq = max(self._written_seq, target if self._ced.frame_count == 0
                                      else self._written_seq)
            self._ledger.persisted = self._ledger.written
            self._status.frames_persisted = self._ledger.persisted
            if self._barrier_target is not None and self._persisted_seq >= self._barrier_target:
                self._barrier_target = None
            self._cond.notify_all()

    def _write_loop(self):
        _set_rt_priority(45)
        f = None
        seg_idx = 0
        seg_frames = 0
        last_space_check = 0.0
        # El ledger se lee en CADA vuelta (0.11.012): `start()` crea el de la
        # sesión y lo adjunta con `attach_ledger()`; si el hilo escritor ya
        # había arrancado (set_output() antes que start()), una referencia
        # guardada al arrancar seguía sumando al ledger anterior y el de la
        # sesión quedaba con written = 0.
        led = self._ledger
        try:
            f = self._open_segment(0)
            while True:
                led = self._ledger
                if self._failed:
                    break
                if not self._active and self._ced.frame_count == 0:
                    break
                got = self._ced.get_batch_seq(max_frames=CE_CED_BATCH_FRAMES, timeout=0.1)
                if got is None:
                    self._service_barrier(f, seg_idx)
                    continue
                batch, last_seq = got
                # 0.13.002: el ledger se vuelve a leer DESPUÉS de la espera.
                # `start()` puede adjuntar el de la sesión mientras este hilo
                # espera en `get_batch_seq`; con la referencia leída antes,
                # el primer lote se acreditaba al ledger anterior (el audio
                # llegaba al disco, pero `written` quedaba un lote corto).
                led = self._ledger
                n_frames = batch.shape[0]
                now = time.monotonic()
                if now - last_space_check >= CE_DISK_FREE_CHECK_S:
                    last_space_check = now
                    try:
                        self._check_free_space(n_frames)
                    except DiskWriterError:
                        led.lost_writer += n_frames
                        raise
                try:
                    self._write_with_policy(f, batch)
                except DiskWriterError:
                    led.lost_writer += n_frames
                    raise
                led.written += n_frames
                self._frames_written_session += n_frames
                self._segment_frames[seg_idx] += n_frames
                self._status.frames_written += n_frames
                seg_frames += n_frames
                if last_seq > self._written_seq:
                    self._written_seq = last_seq
                self._blocks_since_fsync += 1
                if self._blocks_since_fsync >= CE_DISK_FSYNC_EVERY:
                    self._sync(f, seg_idx)
                    self._blocks_since_fsync = 0
                    led.persisted = led.written
                    self._status.frames_persisted = led.persisted
                if self._segment_max_frames > 0 and seg_frames >= self._segment_max_frames:
                    self._close_segment(f, seg_idx)
                    f = None
                    led.persisted = led.written
                    seg_idx += 1
                    seg_frames = 0
                    f = self._open_segment(seg_idx)
                    self._blocks_since_fsync = 0
                self._service_barrier(f, seg_idx)
                self._status.disk_bytes_written = (
                    self._frames_written_session * self._channels * 3 + 44)
        except DiskWriterError as e:
            self._fail(e.reason, e.err_no)
        except Exception as exc:
            _ce_log.critical("DiskWriter error fatal no clasificado: %s", exc, exc_info=True)
            self._fail(f"UNEXPECTED: {exc}")
        finally:
            led = self._ledger
            if self._failed:
                # El audio que quedó en la CED no se escribirá: pérdida
                # DECLARADA (nunca descarte silencioso) y la cola se cierra
                # para que el drain deje de esperar backpressure.
                self._ced.close()
                led.lost_writer += self._ced.drain_all_count()
                self._status.frames_dropped = max(self._status.frames_dropped,
                                                  led.lost_writer)
            if f is not None:
                try:
                    self._close_segment(f, seg_idx)
                except DiskWriterError as e:
                    self._fail(e.reason, e.err_no)
            if not self._failed:
                with self._cond:
                    self._persisted_seq = max(self._persisted_seq, self._written_seq)
                    led.persisted = led.written
                    self._status.frames_persisted = led.persisted
                    self._barrier_target = None
            with self._cond:
                self._cond.notify_all()
            self._status.disk_alive = False
            self._flush_done.set()
            _ce_log.info("DiskWriter finalizado: %d frames escritos, %d perdidos%s",
                         self._frames_written_session, led.lost_writer,
                         f" — FALLO: {self._failure_reason}" if self._failed else "")


def _mlockall():
    """
    Bloquea todas las páginas del proceso en RAM (evita swap durante capture).
    Usa _LIBC (singleton global).
    """
    if sys.platform != "linux" or _LIBC is None:
        return
    try:
        MCL_CURRENT = 1
        MCL_FUTURE  = 2
        _LIBC.mlockall(MCL_CURRENT | MCL_FUTURE)
    except Exception:
        pass



# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 11: DRAIN — ring SPSC → CED (RAW) + rutas DERIVED/visual con pérdida
#  contabilizada. Orden Golden (CAP-003/CAP-010, Fase 5):
#   · Sale SOLO cuando hay parada solicitada, el productor está quiescente y
#     el ring está vacío (nunca `while not stop_evt.is_set()` a secas).
#   · RAW: `ced.put()` con backpressure; nunca descarta. Si el writer cayó, los
#     frames no encolables se declaran `lost_drain`.
#   · DSP solo sobre la copia DERIVED, con presupuesto de tiempo medido: si se
#     excede de forma sostenida se desactiva para el resto de la sesión.
#   · Visual: `acquire(blocking=False)` — un consumidor GUI lento nunca retiene
#     el drain; los bloques no publicados se cuentan.
# ══════════════════════════════════════════════════════════════════════════════

def _drain_loop_fn(
    rba,
    ced: ColaElasticaDisco,
    status: CaptureEngineStatus,
    stop_evt: threading.Event,
    visual_buf: Optional[deque],
    visual_lock: Optional[threading.Lock],
    nr_coordinator=None,
    *,
    ledger: Optional[FrameLedger] = None,
    producer_quiescent: Optional[threading.Event] = None,
    derived_sink: Optional[Callable[[np.ndarray], bool]] = None,
    writer_failed: Optional[Callable[[], bool]] = None,
    sample_rate: int = CE_SAMPLE_RATE_DEFAULT,
    on_raw_block: Optional[Callable[[np.ndarray], None]] = None,
    preroll: Optional[np.ndarray] = None,
):
    _set_rt_priority(58)
    _mlockall()
    _log = _ce_log
    led = ledger if ledger is not None else FrameLedger()
    frames_max = getattr(rba, "frames_max", CE_RBA_FRAMES_MAX)
    channels = getattr(rba, "channels", CE_CHANNELS)
    scratch = np.zeros((frames_max, channels), dtype=np.float32)

    WM_SLEEP_US = {"SAFE": 5000, "MEDIUM": 500, "HIGH": 100, "CRITICAL": 50}
    sleep_us = 5000
    prev_wm = "SAFE"
    dsp_enabled = nr_coordinator is not None
    dsp_strikes = 0
    dsp_failures = 0

    def _abort_put() -> bool:
        return bool(writer_failed is not None and writer_failed())

    # 0.14.003: el pre-roll (audio de los segundos previos a REC) es lo
    # primero que sale de este hilo, antes que cualquier bloque del ring: el
    # orden temporal lo garantiza que este hilo es el único productor de la
    # CED. Recorre el mismo camino que el audio en vivo (RAW, medidores,
    # DSP/DERIVED, visual), en trozos del tamaño de un bloque del ring.
    pending_preroll = deque()
    if preroll is not None and len(preroll) > 0:
        for i in range(0, preroll.shape[0], frames_max):
            pending_preroll.append(preroll[i:i + frames_max])

    while True:
        if pending_preroll:
            raw = pending_preroll.popleft()
            n, _seq, from_preroll = raw.shape[0], -1, True
        else:
            got = rba.read_into(scratch) if hasattr(rba, "read_into") else None
            if got is None:
                if (stop_evt.is_set()
                        and (producer_quiescent is None or producer_quiescent.is_set())
                        and rba.count == 0):
                    break
                wm_state = rba.get_watermark_state()
                if wm_state != prev_wm:
                    prev_wm = wm_state
                    sleep_us = WM_SLEEP_US.get(wm_state, 500)
                status.rba_watermark_pct = rba.watermark_pct * 100.0
                status.ced_pressure_pct = ced.pressure_pct
                time.sleep(sleep_us / 1_000_000.0)
                continue

            n, _seq = got
            from_preroll = False
            led.drained += n
            raw = scratch[:n].copy()       # bloque propio (la CED retiene la referencia)

        # ── RAW → CED (archivístico, con backpressure, sin descarte) ───────
        if ced.put(raw, seq=_seq, should_abort=_abort_put):
            if from_preroll:
                # Recibido del dispositivo antes de REC: cuenta como recibido
                # y como pre-roll (el ledger lo concilia con `preroll_frames`).
                led.preroll_frames += n
                status.frames_received += n
            else:
                led.enqueued += n
        elif from_preroll:
            led.record_discontinuity("PREROLL_LOST", 0, n, unknown=False,
                                     detail="pre-roll no encolable (writer caído/cola cerrada)")
            _log.critical("Drain: %d frames de pre-roll no encolables — pérdida "
                          "DECLARADA en el ledger.", n)
        else:
            led.lost_drain += n
            _log.critical("Drain: %d frames RAW no encolables (writer caído/cola "
                          "cerrada) — pérdida DECLARADA en el ledger.", n)

        # ── Telemetría (Orden Golden UI/ITL): medidor por canal + envolvente,
        # calculados AQUÍ (no en la GUI) sobre el RAW. Nunca afecta al RAW.
        if on_raw_block is not None:
            try:
                on_raw_block(raw)
            except Exception:
                pass

        # ── DERIVED (DSP) — aislado del RAW ─────────────────────────────────
        visual = raw
        if dsp_enabled:
            t0 = time.perf_counter()
            try:
                processed = nr_coordinator.process_chunk(raw.copy())
                if processed is None or processed.shape != raw.shape:
                    raise ValueError(f"forma de salida DSP inválida: "
                                     f"{None if processed is None else processed.shape}")
                visual = processed
                if derived_sink is not None:
                    if derived_sink(processed):
                        led.derived_enqueued += n
                    else:
                        led.derived_dropped += n
                        status.derived_dropped_frames = led.derived_dropped
            except Exception as e:
                dsp_failures += 1
                led.derived_dropped += n
                status.derived_dropped_frames = led.derived_dropped
                if dsp_failures <= 3 or dsp_failures % 100 == 0:
                    _log.error("Drain: fallo DSP (%s) — bloque RAW intacto, DERIVED "
                               "incompleto (fallos=%d)", e, dsp_failures)
            dt_ms = (time.perf_counter() - t0) * 1000.0
            block_ms = n * 1000.0 / max(sample_rate, 1)
            if dt_ms > CE_DSP_BUDGET_FRACTION * block_ms:
                dsp_strikes += 1
                if dsp_strikes >= CE_DSP_BUDGET_STRIKES:
                    dsp_enabled = False
                    status.dsp_capture_disabled = True
                    led.record_discontinuity(
                        "DSP_BUDGET_EXCEEDED", led.drained, 0,
                        detail=f"DSP {dt_ms:.2f} ms > {CE_DSP_BUDGET_FRACTION:.0%} de "
                               f"{block_ms:.2f} ms durante {dsp_strikes} bloques — "
                               f"DERIVED desactivado; RAW no afectado")
                    _log.error("Drain: DSP fuera de presupuesto — desactivado en captura "
                               "(el RAW sigue íntegro).")
            else:
                dsp_strikes = 0

        # ── Visual (GUI) — pérdida permitida y contabilizada ────────────────
        if visual_buf is not None:
            if visual_lock is None:
                visual_buf.append(visual)
            elif visual_lock.acquire(blocking=False):
                try:
                    visual_buf.append(visual)
                finally:
                    visual_lock.release()
            else:
                led.visual_dropped_blocks += 1
                status.visual_dropped_blocks = led.visual_dropped_blocks

        status.rba_watermark_pct = rba.watermark_pct * 100.0
        status.ced_pressure_pct = ced.pressure_pct


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 12: WATCHDOG / SUPERVISOR (no-RT)
#  Vigila callbacks, write stall y jitter, y en cada tick ejecuta `supervise()`
#  del motor (traduce los flags del callback en eventos del ledger y fail-stop).
#  Orden Golden: la expansión "defensiva" del RBA en caliente queda RETIRADA
#  (memoria fija; redimensionar con productor activo no es seguro sin locks).
# ══════════════════════════════════════════════════════════════════════════════

def _watchdog_loop_fn(
    rba,
    ced: ColaElasticaDisco,
    status: CaptureEngineStatus,
    stop_evt: threading.Event,
    on_stream_dead: Callable,
    on_alert: Optional[Callable] = None,
    supervise: Optional[Callable] = None,
):
    _log           = _ce_log
    last_cb_tick   = 0
    last_frames_w  = 0
    stall_ticks    = 0

    while not stop_evt.wait(CE_WD_TICK_SECS):
        if supervise is not None:
            try:
                supervise()
            except Exception as e:
                _log.error("Watchdog: supervise() falló: %s", e)

        if not status.recording or status.paused:
            last_cb_tick  = status.callback_tick
            last_frames_w = status.frames_written
            stall_ticks   = 0
            if status.wd_phase != "OK":
                status.wd_phase = "OK"
            continue

        now_ns   = _monotonic_raw_ns()
        now_tick = status.callback_tick
        if now_tick == last_cb_tick:
            elapsed_s = (now_ns - status.last_callback_ns) / 1e9
            if elapsed_s > CE_WD_RED_SECS:
                if status.wd_phase != "RED":
                    status.wd_phase    = "RED"
                    status.stream_alive = False
                    _log.error("Watchdog RED: stream muerto (%.1fs sin callbacks). "
                               "Iniciando recovery.", elapsed_s)
                    if on_alert:
                        on_alert("RED", elapsed_s)
                    on_stream_dead()
            elif elapsed_s > CE_WD_ORANGE_SECS:
                if status.wd_phase not in ("ORANGE", "RED"):
                    status.wd_phase = "ORANGE"
                    _log.warning("Watchdog ORANGE: %.1fs sin callbacks.", elapsed_s)
                    if on_alert:
                        on_alert("ORANGE", elapsed_s)
            elif elapsed_s > CE_WD_YELLOW_SECS:
                if status.wd_phase == "OK":
                    status.wd_phase = "YELLOW"
                    _log.warning("Watchdog YELLOW: %.1fs sin callbacks.", elapsed_s)
                    if on_alert:
                        on_alert("YELLOW", elapsed_s)
        else:
            last_cb_tick = now_tick
            status.stream_alive = True
            if status.wd_phase != "OK":
                _log.info("Watchdog: stream recuperado (fase: %s → OK)", status.wd_phase)
            status.wd_phase = "OK"

        fw_now = status.frames_written
        if fw_now == last_frames_w and ced.frame_count > 1024:
            stall_ticks += 1
            if stall_ticks >= 8:
                _log.error("Watchdog: WRITE STALL — %d frames en CED sin progresar "
                           "(%d ticks × %.0fms).", ced.frame_count, stall_ticks,
                           CE_WD_TICK_SECS * 1000)
                stall_ticks = 0
        else:
            stall_ticks   = 0
            last_frames_w = fw_now

        if status.jitter_ewma_ms > 30.0 or status.jitter_peak_ms > 80.0:
            _log.warning("Watchdog: jitter severo EWMA=%.1fms peak=%.1fms",
                         status.jitter_ewma_ms, status.jitter_peak_ms)


# ══════════════════════════════════════════════════════════════════════════════
#  SECCIÓN 13: MOTOR PRINCIPAL — CaptureEngineV2 (Golden)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class FinalizationResult:
    """Resultado explícito del cierre (CAP-003/CAP-008). `complete` es
    False ante CUALQUIER timeout, hilo vivo o barrera no confirmada."""
    complete: bool
    state: str
    reasons: list = field(default_factory=list)
    writer: Optional[WriterCloseResult] = None
    barrier: Optional[FlushBarrierResult] = None
    reconciliation: Any = None
    classification: Any = None
    derived_path: str = ""
    derived_provenance_path: str = ""


class _DerivedCapture:
    """Ruta DERIVED (salida del DSP de captura): archivo hermano del RAW,
    con su propia CED y su propio writer. Pérdida permitida y contabilizada:
    nunca aplica backpressure al RAW ni bloquea el drain."""

    def __init__(self, raw_path: str, rate: int, channels: int):
        base, ext = os.path.splitext(raw_path)
        self.path = f"{base}_DERIVED{ext or '.wav'}"
        self.status = CaptureEngineStatus()
        self.ledger = FrameLedger(session_id="derived", sample_rate=rate, channels=channels)
        self.ced = ColaElasticaDisco(capacity=CE_CED_CAPACITY)
        self.writer = DiskWriterV2(self.ced, self.status, ledger=self.ledger,
                                   name=thread_name("disk-derived"))
        self.writer.start(self.path, rate, channels)

    def offer(self, block: np.ndarray) -> bool:
        return self.ced.put_nowait(block.astype(np.float32, copy=False))

    def close(self, timeout: float = 20.0) -> WriterCloseResult:
        self.writer.flush_barrier(self.ced.last_seq_in, timeout=timeout)
        return self.writer.stop(timeout=timeout)


class CaptureEngineV2:
    """
    Motor de captura fonográfica — versión Golden.

    API pública (compatible):
      start(rate, blocksize) → bool
      stop()                       ≡ request_stop() + espera del drain
      finalize(timeout) → FinalizationResult   (NUEVO: cierre completo)
      pause(state)
      flush_disk()
      get_status() → CaptureEngineStatus
      set_output(path_tmp, rate, channels, segment_max_secs)
      classify_session() → ArchivalClassification
      ledger / state / session_generation
    """

    _RT_PRIORITY_CALLBACK = 80
    _RT_PRIORITY_DRAIN    = 58
    _RT_PRIORITY_DISK     = 45

    def __init__(self):
        self._status = CaptureEngineStatus()
        self._status.lock_free_verified = LOCK_FREE_VERIFIED
        self.nr_coordinator = None
        # Captura DERIVED (salida DSP) en archivo hermano. True por defecto:
        # si hay DSP activo, su resultado queda trazable y separado del RAW.
        self.capture_derived = True
        self.overflow_policy = OVERFLOW_POLICY_FAIL_STOP
        self.on_session_failed: Optional[Callable[[str], None]] = None
        self._clock = CaptureClock()
        self._fsm = CaptureSessionFSM(on_transition=self._on_fsm_transition)
        self._lifecycle_lock = threading.RLock()
        self._finalize_lock = threading.RLock()
        self._recovery_lock = threading.Lock()

        self._rba = RingBufferAbsorcion(
            n_slots=CE_RBA_SLOTS, frames_max=CE_RBA_FRAMES_MAX,
            channels=CE_CHANNELS, name="RBA")
        self._ced = ColaElasticaDisco(capacity=CE_CED_CAPACITY)
        # 0.13.002: solo se redimensionan el ring y la cola propios; los
        # inyectados desde fuera (pruebas de saturación) se respetan.
        self._rba_owned, self._ced_owned = self._rba, self._ced
        self._ledger = FrameLedger()
        self._disk_writer = DiskWriterV2(self._ced, self._status, ledger=self._ledger,
                                         on_failure=self._on_writer_failure)
        self._derived: Optional[_DerivedCapture] = None
        self._derived_lock = threading.Lock()
        self._preroll = PreRollBufferV2()

        self.buffer      : deque = deque(maxlen=4500)
        self.lock        = threading.Lock()
        self._monitor_block = np.zeros((CE_RBA_FRAMES_MAX, CE_CHANNELS), dtype=np.float32)
        self._monitor_block_frames = 0
        self.monitor_engine = None

        self._jitter_hist     = [0.0] * CE_JITTER_HIST_SIZE
        self._jitter_hist_pos = 0

        self.recording = False
        self.paused    = False
        self.rate      = CE_SAMPLE_RATE_DEFAULT
        self.blocksize = 2048
        self._stream   : Optional[sd.InputStream] = None

        # Barrera de callback (CAP-003): el callback marca entrada/salida.
        self._cb_active = False
        self._cb_calls = 0
        # 0.14.003: escucha en espera (stream abierto sin grabar) que llena
        # el pre-roll; `start()` la convierte en grabación sin reabrir.
        self._standby = False
        self._session_preroll_frames = 0
        self._producer_quiescent = threading.Event()
        self._producer_quiescent.set()

        self._drain_t    : Optional[threading.Thread] = None
        self._watchdog_t : Optional[threading.Thread] = None
        self._stop_evt   = threading.Event()        # drain: parada solicitada
        self._wd_stop_evt = threading.Event()       # watchdog
        self._failstop_t : Optional[threading.Thread] = None

        self._seen_rejected_frames = 0
        self._seen_input_overflow = 0
        self._last_finalization: Optional[FinalizationResult] = None
        self._last_classification = None

        # ── Telemetría observable (Orden Golden UI/ITL) ─────────────────────
        self.meter = CaptureMeter(CE_SAMPLE_RATE_DEFAULT, CE_CHANNELS)
        self.envelope = LiveEnvelopeRing(capacity=2048, channels=CE_CHANNELS)
        # Medidor de Intensidad de Señal LCD (0.11.012): mide en el hilo de
        # drenaje los bloques CRUDOS aceptados (entrada efectiva, pre-DSP).
        self.signal_meter = SignalIntensityMeterEngine(SOURCE_REC, CE_CHANNELS,
                                                       CE_SAMPLE_RATE_DEFAULT)
        self._snapshot: Optional[CaptureTelemetrySnapshot] = None
        self._snapshot_t = 0.0
        self.event_log = None          # ForensicEventLog opcional (asignado por la GUI)

    # ── Telemetría ───────────────────────────────────────────────────────────

    def _on_raw_block(self, block: np.ndarray) -> None:
        """Hilo de drenaje: alimenta medidor y envolvente y publica un
        snapshot inmutable a lo sumo cada 50 ms (referencia atómica)."""
        now = time.monotonic()
        self.meter.push(block, now)
        self.envelope.push(block)
        self.signal_meter.process_block(block, self._ledger.sample_rate)
        if now - self._snapshot_t >= 0.05:
            self._snapshot_t = now
            self._publish_snapshot(now)

    def _publish_snapshot(self, now: float) -> None:
        led = self._ledger
        s = self._status
        self._snapshot = CaptureTelemetrySnapshot(
            session_id=led.session_id, frame_index=led.received,
            sample_rate=led.sample_rate, channels=led.channels,
            frames_committed=led.written,
            elapsed_audio_s=(led.received - self._rba.rejected_frames) / max(led.sample_rate, 1),
            readings=self.meter.readings(now), measured_at=now, quality=_METER_VALID,
            xruns=s.xrun_count, frames_lost=s.frames_dropped,
            ring_pct=self._rba.watermark_pct * 100.0, disk_pressure_pct=self._ced.pressure_pct,
            archival_hint="INVALID" if (s.frames_dropped or self._fsm.failure_reason) else "")

    def telemetry_snapshot(self) -> Optional[CaptureTelemetrySnapshot]:
        """Último snapshot publicado (la GUI calcula su antigüedad/calidad)."""
        return self._snapshot

    def audio_seconds_accepted(self) -> float:
        """TimelineAuthority: segundos de audio ACEPTADOS por el ring (no
        ticks de GUI). Fuente de tiempo del ITL y del contador de cinta."""
        led = self._ledger
        return (led.received - self._rba.rejected_frames) / max(led.sample_rate, 1)

    def _log_event(self, severity, cause, **kw):
        log = self.event_log
        if log is not None:
            try:
                log.emit("capture", severity, cause, session_id=self._ledger.session_id, **kw)
            except Exception:
                pass

    # ── Propiedades de estado ────────────────────────────────────────────────

    @property
    def state(self) -> CaptureState:
        return self._fsm.state

    @property
    def session_generation(self) -> int:
        return self._fsm.generation

    @property
    def ledger(self) -> FrameLedger:
        return self._ledger

    @property
    def derived_path(self) -> str:
        d = self._derived
        return d.path if d is not None else ""

    def _on_fsm_transition(self, old, new, reason):
        self._status.capture_state = new.value
        self._status.session_generation = self._fsm.generation
        if new == CaptureState.FAILED:
            self._status.failure_reason = self._fsm.failure_reason
        _ce_log.info("Sesión de captura: %s → %s%s", old.value, new.value,
                     f" ({reason})" if reason else "")
        sev = "P0" if new == CaptureState.FAILED else "INFO"
        self._log_event(sev, "STATE_TRANSITION", prev_state=old.value, new_state=new.value,
                        frame=self._ledger.received, data={"reason": reason})

    # ── Arranque ─────────────────────────────────────────────────────────────

    def start(self, rate: int, blocksize: int) -> bool:
        """Arma una sesión nueva y abre el stream. True si quedó CAPTURING."""
        with self._lifecycle_lock:
            if self._fsm.state == CaptureState.DRAINING:
                # Sesión anterior detenida con `stop()` pero sin `finalize()`
                # (flujo heredado): se cierra y clasifica antes de rearmar.
                self.finalize()
            if self._fsm.state in (CaptureState.ARMING, CaptureState.CAPTURING,
                                   CaptureState.PAUSED, CaptureState.DRAINING,
                                   CaptureState.FINALIZING):
                _ce_log.error("start() rechazado: sesión en estado %s", self._fsm.state.value)
                return False
            if not self._join_background(timeout=5.0):
                # 0.14.004: con hilos de la sesión anterior todavía vivos
                # (fail-stop o drenado sin terminar), armar otra sesión
                # reiniciaba el estado compartido bajo su watchdog: este leía
                # `last_callback_ns = 0` y declaraba "stream muerto" con las
                # horas de uptime del equipo (traza de la usuaria). Se rechaza
                # REC hasta que terminen.
                _ce_log.error("start() rechazado: la sesión anterior aún no terminó "
                              "de cerrarse (hilos vivos).")
                return False
            if self._fsm.state in (CaptureState.CLASSIFIED, CaptureState.FAILED):
                self._fsm.transition(CaptureState.IDLE, "nueva sesión")

            # 0.14.003: si la escucha en espera ya tiene el stream abierto con
            # la misma frecuencia y bloque, la grabación lo hereda sin
            # reabrirlo, y el pre-roll acumulado entra antes del primer
            # bloque en vivo. Si no coincide, se cierra y se abre como antes.
            reuse_standby = (self._standby and self._stream is not None
                             and bool(getattr(self._stream, "active", True))
                             and self.rate == rate and self.blocksize == blocksize)
            if self._standby and not reuse_standby:
                _ce_log.info("Escucha en espera descartada (%s Hz/%s → %d Hz/%d): "
                             "la grabación abre su propio stream, sin pre-roll.",
                             self.rate, self.blocksize, rate, blocksize)
                self._disarm_standby_locked()

            self.rate      = rate
            self.blocksize = blocksize
            self._apply_buffer_plan(rate, blocksize)
            self._fsm.transition(CaptureState.ARMING, "start()")
            gen = self._fsm.generation
            self._ledger = FrameLedger(session_id=uuid.uuid4().hex, generation=gen,
                                       sample_rate=rate, channels=CE_CHANNELS)
            self._disk_writer.attach_ledger(self._ledger)
            self._rba.reset_for_generation(gen)
            self.meter.configure(rate, CE_CHANNELS)
            self.envelope = LiveEnvelopeRing(capacity=2048, channels=CE_CHANNELS)
            self.signal_meter.sample_rate = rate
            self.signal_meter.reset()
            self._snapshot = None
            self._ced.clear()
            self._stop_evt.clear()
            self._wd_stop_evt.clear()
            self._producer_quiescent.clear()
            self._clock.reset(sample_rate=rate)
            if not reuse_standby:
                self._preroll.configure(secs=CE_PREROLL_SECS_DEFAULT, rate=rate)
                self._preroll.set_active(False)
            self._session_preroll_frames = 0
            self._seen_rejected_frames = 0
            self._seen_input_overflow = 0
            self._last_finalization = None
            self._last_classification = None
            with self._derived_lock:
                self._derived = None

            s = self._status
            s.frames_received = 0
            s.frames_written  = 0
            s.frames_dropped  = 0
            s.frames_persisted = 0
            s.frames_verified = 0
            s.xrun_count      = 0
            s.status_flag_callbacks = 0
            s.input_overflow_count = 0
            s.input_underflow_count = 0
            s.starvation_events = 0
            s.recovery_count  = 0
            s.recovery_last_t = 0.0
            s.wd_phase        = "OK"
            s.ring_rejected_frames = 0
            s.ring_rejected_blocks = 0
            s.finalization_incomplete = False
            s.visual_dropped_blocks = 0
            s.derived_dropped_frames = 0
            s.dsp_capture_disabled = False
            s.writer_failed = False
            s.failure_reason = ""
            s.discontinuity_count = 0
            s.jitter_ewma_ms  = 0.0
            s.jitter_peak_ms  = 0.0
            s.last_callback_ns = 0
            # Contadores de disco de la sesión: también del motor (hasta 0.14.001
            # los reiniciaba la interfaz sobre otro objeto de estado).
            s.disk_bytes_written = 0
            s.disk_write_ms_last = 0.0

            # El callback empieza a aceptar en cuanto el stream arranca: la
            # transición a CAPTURING precede a la apertura del stream.
            self._fsm.transition(CaptureState.CAPTURING, "stream abriendo")
            with self.lock:
                self.recording = True
                self.paused    = False
            s.recording = True
            s.paused    = False
            preroll = None
            if reuse_standby:
                # Desde aquí cada callback publica en el ring. El que estaba en
                # curso pudo haber entrado aún por la rama de espera: se espera
                # a que termine antes de sacar el pre-roll (único escritor).
                self._standby = False
                self._preroll.set_active(False)
                self._wait_standby_callback_done()
                preroll = self._preroll.drain()
                if preroll is not None and len(preroll) > 0:
                    self._session_preroll_frames = int(preroll.shape[0])
                    self._ledger.record_discontinuity(
                        "PREROLL", 0, self._session_preroll_frames,
                        detail="audio previo a REC antepuesto")
                    _ce_log.info("Pre-roll: %.2f s (%d frames) antepuestos a la grabación",
                                 self._session_preroll_frames / max(rate, 1),
                                 self._session_preroll_frames)
            elif not self._open_stream():
                self._fsm.fail("STREAM_OPEN_FAILED")
                self._producer_quiescent.set()
                with self.lock:
                    self.recording = False
                s.recording = False
                return False

            s.stream_alive = True
            s.last_callback_ns = _monotonic_raw_ns()

            self._drain_t = threading.Thread(
                target=_drain_loop_fn,
                args=(self._rba, self._ced, self._status, self._stop_evt,
                      self.buffer, self.lock, self.nr_coordinator),
                kwargs=dict(ledger=self._ledger,
                            producer_quiescent=self._producer_quiescent,
                            derived_sink=self._derived_offer,
                            writer_failed=lambda: self._disk_writer.failed,
                            sample_rate=rate, on_raw_block=self._on_raw_block,
                            preroll=preroll),
                daemon=True, name=thread_name("drain"))
            # Orden SERVO-016: el DSP DERIVED corre con latencia alineada
            # (constante) durante toda la sesión y con estado nuevo.
            if self.nr_coordinator is not None and hasattr(self.nr_coordinator, "begin_stream"):
                try:
                    self.nr_coordinator.begin_stream()
                except Exception as e:
                    _ce_log.error("No se pudo iniciar el flujo DSP: %s", e)
            self._drain_t.start()
            self._watchdog_t = threading.Thread(
                target=_watchdog_loop_fn,
                args=(self._rba, self._ced, self._status, self._wd_stop_evt,
                      self._on_stream_dead, self._on_watchdog_alert),
                kwargs=dict(supervise=self.supervise),
                daemon=True, name=thread_name("watchdog"))
            self._watchdog_t.start()
            _ce_log.info("CaptureEngine Golden: gen=%d %dHz bs=%d ring=%d slots CED=%d frames "
                         "lock_free_verified=%s", gen, rate, blocksize,
                         getattr(self._rba, "_n", CE_RBA_SLOTS), self._ced.capacity,
                         LOCK_FREE_VERIFIED)
            return True

    # ── Parada en fases ──────────────────────────────────────────────────────

    def request_stop(self, timeout: float = CE_STOP_DRAIN_TIMEOUT_S) -> bool:
        """Fase 1 del cierre: deja de aceptar, cierra el stream, confirma
        callback quiescente y vacía el ring hacia la CED. Idempotente.
        Devuelve True si el ring quedó vacío y el drain terminó."""
        with self._lifecycle_lock:
            st = self._fsm.state
            if st in (CaptureState.CAPTURING, CaptureState.PAUSED):
                self._fsm.transition(CaptureState.DRAINING, "request_stop()")
            elif st == CaptureState.ARMING:
                self._fsm.fail("STOP_DURING_ARMING")
            with self.lock:
                self.recording = False
                self.paused    = False
            self._status.recording = False
            self._status.paused    = False
            self._close_stream()
            self._status.stream_alive = False

        ok = True
        if not self._wait_callback_quiescent(CE_STOP_QUIESCE_TIMEOUT_S):
            ok = False
            self._mark_incomplete("CALLBACK_NOT_QUIESCENT")
        self._producer_quiescent.set()
        self._stop_evt.set()
        t = self._drain_t
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=timeout)
            if t.is_alive():
                ok = False
                self._mark_incomplete(f"DRAIN_TIMEOUT ({self._rba.count} bloques en ring)")
        coord = self.nr_coordinator
        if coord is not None and hasattr(coord, "end_stream") and (t is None or not t.is_alive()):
            try:
                coord.end_stream()
            except Exception as e:
                _ce_log.error("No se pudo cerrar el flujo DSP: %s", e)
        self._wd_stop_evt.set()
        w = self._watchdog_t
        if w is not None and w.is_alive() and w is not threading.current_thread():
            w.join(timeout=5.0)
        self.supervise()
        return ok and self._rba.count == 0

    def stop(self):
        """Compatibilidad: equivale a `request_stop()` (el writer sigue
        abierto hasta `finalize()` o `_disk_writer.stop()`)."""
        self.request_stop()
        _ce_log.info("CaptureEngine detenido (gen=%d, estado=%s).",
                     self._fsm.generation, self._fsm.state.value)

    def finalize(self, timeout: float = CE_FINALIZE_TIMEOUT_S) -> FinalizationResult:
        """Cierre completo, serializado: llamadas concurrentes esperan a la
        primera y devuelven exactamente el mismo resultado (CAP-011)."""
        with self._finalize_lock:
            if self._last_finalization is not None and \
                    self._fsm.state == CaptureState.CLASSIFIED:
                return self._last_finalization
            return self._finalize_locked(timeout)

    def _finalize_locked(self, timeout: float) -> FinalizationResult:
        """Fase 2 del cierre: flush_barrier + fsync + cierre del writer,
        verificación de segmentos, reconciliación del ledger y
        clasificación. Idempotente: la segunda llamada devuelve el mismo
        resultado. Un timeout NUNCA se reporta como éxito."""
        with self._lifecycle_lock:
            if self._fsm.state == CaptureState.CLASSIFIED and self._last_finalization:
                return self._last_finalization
            if self._fsm.state == CaptureState.IDLE:
                # Sin sesión armada (writer usado de forma aislada o flujo
                # heredado): se cierra lo que haya y se clasifica igual,
                # pero el resultado nunca se declara completo.
                barrier = None
                if self._disk_writer.is_alive:
                    barrier = self._disk_writer.flush_barrier(self._ced.last_seq_in,
                                                              timeout=timeout)
                wres = self._disk_writer.stop(timeout=timeout)
                classification = self.classify_session()
                return FinalizationResult(complete=False, state="IDLE",
                                          reasons=["NO_SESSION"], writer=wres,
                                          barrier=barrier, classification=classification)
        self.request_stop()
        with self._lifecycle_lock:
            if self._fsm.state == CaptureState.CLASSIFIED and self._last_finalization:
                return self._last_finalization
            self._fsm.try_transition(CaptureState.FINALIZING, "finalize()")
        reasons = []
        barrier = None
        if self._disk_writer.is_alive:
            barrier = self._disk_writer.flush_barrier(self._ced.last_seq_in, timeout=timeout)
            if not barrier.ok:
                reasons.append(f"FLUSH_BARRIER_FAILED ({barrier.reason})")
        wres = self._disk_writer.stop(timeout=timeout)
        if not wres.closed:
            reasons.append("WRITER_THREAD_ALIVE")
        if wres.failed:
            reasons.append(f"WRITER_FAILED ({wres.failure_reason})")
        if self._ced.frame_count > 0:
            reasons.append(f"CED_PENDING ({self._ced.frame_count} frames)")
        for vf in wres.verify_failures:
            reasons.append(f"VERIFY_FAILED {vf}")
        derived_path = ""
        with self._derived_lock:
            d = self._derived
        derived_prov = ""
        if d is not None:
            dres = d.close(timeout=timeout)
            derived_path = d.path
            if not dres.closed or dres.failed:
                self._ledger.record_discontinuity(
                    "DERIVED_INCOMPLETE", self._ledger.drained, 0,
                    detail=dres.failure_reason or "writer DERIVED no cerró")
            try:
                derived_prov = self._write_derived_provenance(d, dres)
            except Exception as e:
                _ce_log.error("No se pudo escribir la procedencia DERIVED: %s", e)
        incomplete = [r for r in reasons if not r.startswith("VERIFY_FAILED")]
        if incomplete and not self._ledger.finalization_incomplete:
            self._mark_incomplete("; ".join(incomplete))
        self.supervise()
        classification = self.classify_session()
        rec = self._reconcile()
        with self._lifecycle_lock:
            self._fsm.try_transition(CaptureState.CLASSIFIED, "finalize()")
        result = FinalizationResult(
            complete=not reasons, state=self._fsm.state.value, reasons=reasons,
            writer=wres, barrier=barrier, reconciliation=rec,
            classification=classification, derived_path=derived_path,
            derived_provenance_path=derived_prov)
        self._last_finalization = result
        return result

    def _write_derived_provenance(self, d: "_DerivedCapture", dres) -> str:
        """Orden Golden DSP (Arquitectura §2): el DERIVED lleva procedencia
        completa — hash del RAW de origen, hash del resultado, cadena DSP
        (familia/fidelidad/parámetros), hash de configuración, latencia
        algorítmica declarada, telemetría e incidencias de integridad."""
        import hashlib
        import json

        def _sha(path):
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
            return h.hexdigest()

        coord = self.nr_coordinator
        # RAW-01 (Orden SERVO-016): tras procesar y cerrar el DERIVED se
        # RELEEN los segmentos RAW y se comparan con el SHA-256 registrado al
        # cerrarlos: el DSP nunca tocó el RAW.
        raw_recorded = self._disk_writer.get_segment_checksums()
        raw_verify = []
        for c in raw_recorded:
            try:
                now = compute_segment_checksum(c["path"])["sha256"]
                raw_verify.append({"path": os.path.basename(c["path"]),
                                   "sha256_recorded": c["sha256"], "sha256_now": now,
                                   "unchanged": now == c["sha256"]})
            except Exception as e:
                raw_verify.append({"path": os.path.basename(str(c.get("path"))),
                                   "unchanged": False, "error": str(e)})
        try:
            from lorito_aldhiro.backend.core.lorito_version import APP_VERSION as _engine_version
        except Exception:
            _engine_version = "desconocida"
        doc = {
            "schema": "lorito.derived.provenance/2",
            "engine_version": _engine_version,
            "processed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "source_raw_paths": [os.path.basename(c["path"]) for c in raw_recorded],
            "raw_verified_after_derived": raw_verify,
            "raw_unchanged": bool(raw_verify) and all(v["unchanged"] for v in raw_verify),
            "session_id": self._ledger.session_id,
            "generation": self._ledger.generation,
            "raw_segments": self._disk_writer.get_segment_checksums(),
            "derived_path": os.path.basename(d.path),
            "derived_sha256_file": _sha(d.path) if os.path.exists(d.path) else "",
            "derived_frames_written": dres.frames_written,
            "derived_frames_dropped": self._ledger.derived_dropped,
            "derived_complete": bool(dres.closed and not dres.failed
                                     and self._ledger.derived_dropped == 0
                                     and not self._status.dsp_capture_disabled),
            "dsp_capture_disabled": bool(self._status.dsp_capture_disabled),
        }
        if coord is not None:
            try:
                doc.update({
                    "dsp_chain": coord.describe_chain(),
                    "dsp_config_hash": coord.config_hash(),
                    "dsp_latency_frames": coord.chain_latency_frames(),
                    "dsp_integrity_state": coord.integrity_state,
                    "dsp_nonfinite_counts": coord.nonfinite_counts,
                    "dsp_telemetry": coord.telemetry(),
                    "dsp_integrity_events": [vars(e) if hasattr(e, "__dict__") else
                                             e.__repr__() for e in coord.integrity_events][:200],
                    "dsp_chain_warnings": coord.chain_warnings(),
                })
                if hasattr(coord, "get_status"):
                    doc["dsp_status"] = coord.get_status()
                    doc["dsp_reconfig_requests"] = coord.tickets
            except Exception as e:
                doc["dsp_description_error"] = str(e)
        path = d.path + ".provenance.json"
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(json.dumps(doc, ensure_ascii=False, indent=2, default=str))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        _fsync_dir(path)
        return path

    def _mark_incomplete(self, reason: str):
        led = self._ledger
        led.finalization_incomplete = True
        led.finalization_reason = (led.finalization_reason + "; " + reason).strip("; ")
        self._status.finalization_incomplete = True
        _ce_log.error("FINALIZATION_INCOMPLETE: %s", reason)

    def _wait_callback_quiescent(self, timeout: float) -> bool:
        """Con el stream ya detenido, confirma que ningún callback está en
        curso ni llega uno nuevo durante dos sondeos consecutivos."""
        deadline = time.monotonic() + timeout
        last_calls = self._cb_calls
        stable = 0
        while time.monotonic() < deadline:
            if not self._cb_active and self._cb_calls == last_calls:
                stable += 1
                if stable >= 2:
                    return True
            else:
                stable = 0
                last_calls = self._cb_calls
            time.sleep(0.005)
        return False

    def wait_for_background_threads(self, timeout: float = 5.0) -> bool:
        """Espera a que drain/watchdog/fail-stop terminen (con timeout)."""
        return self._join_background(timeout)

    def _join_background(self, timeout: float) -> bool:
        ok = True
        cur = threading.current_thread()
        for _t in (self._drain_t, self._watchdog_t, self._failstop_t):
            if _t is not None and _t.is_alive() and _t is not cur:
                _t.join(timeout=timeout)
                if _t.is_alive():
                    _ce_log.warning("El hilo %s sigue vivo tras %.1fs.", _t.name, timeout)
                    ok = False
        return ok

    # ── Pausa ────────────────────────────────────────────────────────────────

    def pause(self, state: bool):
        with self._lifecycle_lock:
            st = self._fsm.state
            if state and st == CaptureState.CAPTURING:
                self._fsm.transition(CaptureState.PAUSED, "pause(True)")
                self._ledger.record_discontinuity("PAUSE", self._ledger.received, 0,
                                                  detail="pausa del operador")
            elif not state and st == CaptureState.PAUSED:
                self._fsm.transition(CaptureState.CAPTURING, "pause(False)")
                self._ledger.record_discontinuity("RESUME", self._ledger.received, 0,
                                                  detail="reanudación del operador")
            with self.lock:
                self.paused = state
            self._status.paused = state
            self._preroll.set_active(not state and not self.recording)

    # ── Disco ────────────────────────────────────────────────────────────────

    def flush_disk(self):
        return self._disk_writer.flush(timeout=30.0)

    def set_output(self, path_tmp: str, rate: int, channels: int,
                   segment_max_secs: float = 0.0):
        self._disk_writer.attach_ledger(self._ledger)
        self._disk_writer.start(path_tmp, rate, channels, segment_max_secs)

    # ── Pre-roll: escucha en espera (0.14.003) ───────────────────────────────
    # Hasta 0.14.002 el stream solo se abría con REC, así que el buffer de
    # pre-roll nunca recibía audio; y el intento de anteponerlo después de
    # abrir el stream llegaba tarde (ya había audio en vivo encolado). Ahora
    # el stream queda abierto en espera, el callback llena solo el pre-roll y
    # `start()` hereda el stream: el pre-roll sale del hilo de drenado antes
    # que el primer bloque en vivo, sin hueco ni solape entre ambos.

    def arm_preroll_standby(self, rate: int, blocksize: int) -> bool:
        """Abre (o conserva) la escucha en espera. False si hay una sesión
        en curso o el dispositivo no abre."""
        with self._lifecycle_lock:
            if self.recording or self._fsm.state in (
                    CaptureState.ARMING, CaptureState.CAPTURING, CaptureState.PAUSED,
                    CaptureState.DRAINING, CaptureState.FINALIZING):
                return False
            if (self._standby and self._stream is not None
                    and bool(getattr(self._stream, "active", True))
                    and self.rate == rate and self.blocksize == blocksize):
                return True
            self._disarm_standby_locked()
            if self._stream is not None:
                return False
            self.rate      = rate
            self.blocksize = blocksize
            self._preroll.configure(secs=CE_PREROLL_SECS_DEFAULT, rate=rate)
            self._preroll.set_active(True)
            self._standby = True
            if not self._open_stream():
                self._standby = False
                self._preroll.set_active(False)
                return False
            _ce_log.info("Escucha en espera para pre-roll: %d Hz bs=%d (%.0f s)",
                         rate, blocksize, CE_PREROLL_SECS_DEFAULT)
            return True

    def disarm_preroll_standby(self) -> None:
        """Cierra la escucha en espera (si la hay) y descarta el pre-roll."""
        with self._lifecycle_lock:
            self._disarm_standby_locked()

    def _disarm_standby_locked(self) -> None:
        if not self._standby:
            return
        self._standby = False
        self._preroll.set_active(False)
        self._close_stream()
        self._wait_callback_quiescent(0.5)
        self._preroll.clear()

    def _wait_standby_callback_done(self, timeout: float = 1.0) -> None:
        """Con `accepting` ya publicado: espera a que termine el callback que
        estuviera en curso (los callbacks están serializados, así que basta
        con que no haya ninguno activo o que haya empezado otro)."""
        c0 = self._cb_calls
        deadline = time.monotonic() + timeout
        while self._cb_active and self._cb_calls == c0 and time.monotonic() < deadline:
            time.sleep(0.0005)

    @property
    def preroll_standby_active(self) -> bool:
        return bool(self._standby and self._stream is not None)

    @property
    def session_preroll_frames(self) -> int:
        """Frames de pre-roll antepuestos a la sesión actual."""
        return self._session_preroll_frames

    def preroll_buffered_secs(self) -> float:
        return self._preroll.buffered_secs

    def get_status(self) -> CaptureEngineStatus:
        return self._status

    def get_path(self) -> str:
        return self._disk_writer.get_path()

    def get_segment_paths(self) -> list:
        return self._disk_writer.get_segment_paths()

    # ── API pública para la interfaz (LA-GOLDEN-CORE-020 §4) ─────────────────
    # Hasta 0.14.001 la interfaz leía y operaba piezas internas del motor
    # (_disk_writer, _monitor_block, _preroll, _ced). Estos métodos son el
    # contrato `CaptureService` (backend/services/lorito_contracts.py) y no
    # cambian lo que se hace: delegan en las mismas piezas.

    def latest_input_block(self) -> np.ndarray:
        """Último bloque de entrada visto por el callback (vista, sin copia ni
        lock: el callback lo reescribe de una vez). Vacío si aún no hubo."""
        return self._monitor_block[:self._monitor_block_frames]

    def disk_backlog_frames(self) -> int:
        """Frames encolados para disco que el escritor aún no persistió."""
        return self._ced.frame_count

    def stop_disk_writer(self, timeout: float = 20.0):
        """Cierre directo del escritor (solo en el cierre de la aplicación);
        cierra también la escucha en espera del pre-roll."""
        self.disarm_preroll_standby()
        return self._disk_writer.stop(timeout)

    def validate_disk_duration(self, expected_secs: float):
        return self._disk_writer.validate_duration(expected_secs)

    # ── DERIVED ──────────────────────────────────────────────────────────────

    def _derived_offer(self, block: np.ndarray) -> bool:
        if not self.capture_derived:
            return False
        coord = self.nr_coordinator
        if coord is not None and not getattr(coord, "has_active_processing", True):
            return False
        d = self._derived
        if d is None:
            with self._derived_lock:
                if self._derived is None:
                    raw_path = self._disk_writer.get_path()
                    if not raw_path:
                        return False
                    try:
                        self._derived = _DerivedCapture(raw_path, self.rate, CE_CHANNELS)
                    except Exception as e:
                        _ce_log.error("No se pudo iniciar la captura DERIVED: %s", e)
                        self.capture_derived = False
                        return False
                d = self._derived
        return d.offer(block)

    # ── Supervisión (no-RT) ──────────────────────────────────────────────────

    def supervise(self):
        """Traduce contadores del callback/ring a eventos del ledger y
        aplica la política de saturación. Llamado por el watchdog cada
        tick y en cada fase de cierre."""
        s = self._status
        led = self._ledger
        rc = self._rba.counters()
        rejected = (rc["rejected_full_frames"] + rc["rejected_oversize_frames"]
                    + rc["rejected_shape_frames"] + rc["rejected_disabled_frames"])
        s.ring_rejected_frames = rejected
        s.ring_rejected_blocks = (rc["rejected_full_blocks"] + rc["rejected_oversize_blocks"]
                                  + rc["rejected_shape_blocks"] + rc["rejected_disabled_blocks"])
        s.rba_overrun_total = rc["rejected_full_blocks"]
        new_loss = rejected - self._seen_rejected_frames
        if new_loss > 0:
            self._seen_rejected_frames = rejected
            kind = ("RING_OVERFLOW" if rc["rejected_full_frames"] else
                    "BLOCK_OVERSIZE" if rc["rejected_oversize_frames"] else
                    "BLOCK_SHAPE" if rc["rejected_shape_frames"] else "REJECTED_AFTER_FAILSTOP")
            led.record_discontinuity(kind, rc["accepted_frames"], new_loss,
                                     detail=f"primer rechazo en seq={rc['first_reject_seq']}")
            if kind != "REJECTED_AFTER_FAILSTOP":
                _ce_log.critical("PÉRDIDA DECLARADA: %s, %d frames (sesión INVALID).",
                                 kind, new_loss)
                self._log_event("P0", kind, frame=rc["accepted_frames"],
                                data={"frames_lost": new_loss})
                if self.overflow_policy == OVERFLOW_POLICY_FAIL_STOP:
                    self._initiate_fail_stop(kind)
        new_ovf = s.input_overflow_count - self._seen_input_overflow
        if new_ovf > 0:
            self._seen_input_overflow = s.input_overflow_count
            led.record_discontinuity("INPUT_OVERFLOW", led.received, 0, unknown=True,
                                     detail=f"{new_ovf} callback(s) con paInputOverflow "
                                            f"(PortAudio descartó entrada; tamaño desconocido)")
        s.frames_dropped = rejected + led.lost_drain + led.lost_writer
        s.ced_dropped_frames = led.lost_drain
        s.discontinuity_count = len(led.discontinuities)
        s.frames_persisted = led.persisted

    def _initiate_fail_stop(self, reason: str):
        """Fail-stop (no-RT): la sesión pasa a FAILED, el ring deja de
        aceptar y un hilo dedicado cierra stream, drena, sincroniza y
        clasifica (archivo parcial preservado, INVALID)."""
        self._rba.disable_writes()
        if not self._fsm.fail(reason):
            return
        self._status.failure_reason = self._fsm.failure_reason
        if self._failstop_t is not None and self._failstop_t.is_alive():
            return

        def _run():
            try:
                self.finalize()
            except Exception as e:
                _ce_log.critical("fail-stop: finalize() falló: %s", e, exc_info=True)
            cb = self.on_session_failed
            if cb is not None:
                try:
                    cb(self._fsm.failure_reason)
                except Exception:
                    pass

        self._failstop_t = threading.Thread(target=_run, daemon=True, name=thread_name("failstop"))
        self._failstop_t.start()

    def _on_writer_failure(self, reason: str):
        self._initiate_fail_stop(f"WRITER_FAILURE: {reason}")

    # ── Clasificación ────────────────────────────────────────────────────────

    def _reconcile(self):
        return self._ledger.reconcile(self._rba.counters(),
                                      pending_ced_frames=self._ced.frame_count)

    def classify_session(self):
        """Clasifica la sesión (ARCHIVAL_SAFE/DEGRADED/INVALID) con el
        FrameLedger reconciliado, los segmentos y sus checksums reales,
        el estado de fallo y el saneamiento DSP (GAP-062)."""
        dsp_nonfinite_total = 0
        if self.nr_coordinator is not None:
            try:
                dsp_nonfinite_total = sum(self.nr_coordinator.nonfinite_counts.values())
            except Exception as e:
                _ce_log.error("classify_session(): no se pudo leer nonfinite_counts: %s", e)
        self.supervise()
        rec = self._reconcile()
        result = _classify_archival_session(
            self._status,
            segment_paths=self.get_segment_paths(),
            segment_checksums=self._disk_writer.get_segment_checksums(),
            dsp_nonfinite_total=dsp_nonfinite_total,
            ledger=self._ledger,
            reconciliation=rec,
            failure_reason=self._fsm.failure_reason,
            verify_failures=self._disk_writer.get_verify_failures(),
            require_checksums=True,
        )
        self._last_classification = result
        return result

    # ── Callback RT ──────────────────────────────────────────────────────────

    def _audio_callback(self, indata, frames, t, status):
        """
        Callback RT. Permitido: copiar al ring SPSC preasignado, contadores
        enteros/float, lectura de flags publicados. Prohibido: logging,
        I/O, locks de la aplicación, GUI, DSP, esperas, asignaciones de
        tamaño variable. Ver RT_CONTRACT.md.
        """
        self._cb_active = True
        self._cb_calls += 1
        try:
            # En espera (sin sesión que acepte audio) el callback solo llena
            # el pre-roll: ni contadores de sesión, ni monitor, ni medidores,
            # igual que cuando el stream estaba cerrado fuera de REC.
            if self._standby and not self._fsm.accepting:
                self._preroll.push(indata)
                return
            _s = self._status
            # ── Flags de PortAudio: contadores separados por tipo (CAP-007) ──
            if status:
                _s.status_flag_callbacks += 1
                _s.xrun_count += 1
                if getattr(status, "input_overflow", False):
                    _s.input_overflow_count += 1
                if getattr(status, "input_underflow", False):
                    _s.input_underflow_count += 1

            now_ns = _monotonic_raw_ns()
            last_ns = _s.last_callback_ns
            if last_ns > 0:
                expected_gap_ns = int(frames / max(self.rate, 1) * 1e9)
                actual_gap_ns   = now_ns - last_ns
                jitter_ms       = abs(actual_gap_ns - expected_gap_ns) / 1_000_000.0
                alpha = CE_JITTER_EWMA_ALPHA
                _s.jitter_ewma_ms = alpha * jitter_ms + (1 - alpha) * _s.jitter_ewma_ms
                if jitter_ms > _s.jitter_peak_ms:
                    _s.jitter_peak_ms = jitter_ms
                elif jitter_ms < _s.jitter_peak_ms * 0.6:
                    _s.jitter_peak_ms = _s.jitter_peak_ms * 0.90 + _s.jitter_ewma_ms * 0.10
                hp = self._jitter_hist_pos
                self._jitter_hist[hp] = jitter_ms
                self._jitter_hist_pos = (hp + 1) % CE_JITTER_HIST_SIZE
                # Starvation: UN incremento por callback tardío (CAP-006).
                if actual_gap_ns > expected_gap_ns + 5_000_000:
                    _s.starvation_events += 1
            _s.last_callback_ns = now_ns
            _s.callback_tick   += 1

            n_mon = frames if frames <= CE_RBA_FRAMES_MAX else CE_RBA_FRAMES_MAX
            self._monitor_block[:n_mon] = indata[:n_mon]
            self._monitor_block_frames  = n_mon
            mon = self.monitor_engine
            if mon is not None:
                mon.push_block(indata[:n_mon])

            if self._fsm.accepting:
                led = self._ledger
                led.callbacks += 1
                led.received += frames
                _s.frames_received += frames
                code = self._rba.publish(indata, frames)
                if code == WRITE_OK:
                    self._clock.tick_received(frames)
                elif code != WRITE_DISABLED and self.overflow_policy == OVERFLOW_POLICY_FAIL_STOP:
                    # Barrera lógica inmediata: nada más se acepta hasta que
                    # el supervisor (no-RT) declare la pérdida y haga fail-stop.
                    self._rba.disable_writes()
            elif self.paused and self.recording:
                self._ledger.received_while_paused += frames
            elif not self.recording:
                self._preroll.push(indata[:n_mon])
        finally:
            self._cb_active = False

    def _apply_buffer_plan(self, rate: int, blocksize: int) -> None:
        """0.13.002: ring y cola en segundos, no en frames fijos. Solo con
        productor y consumidor quiescentes (precondición de `start()`). Un
        ring inyectado desde fuera (pruebas) se respeta tal cual."""
        from lorito_aldhiro.backend.capture.lorito_rate_support import buffer_plan
        plan = buffer_plan(rate, blocksize)
        # Mismo objeto, más slots: ninguna referencia queda apuntando a un
        # ring viejo (reemplazar el objeto perdía un bloque sin contarlo).
        if self._rba is vars(self).get("_rba_owned") and self._rba.n_slots < plan.rba_slots:
            self._rba.resize(plan.rba_slots)
        if self._ced is vars(self).get("_ced_owned") and self._ced.capacity != plan.ced_frames:
            self._ced.set_capacity(plan.ced_frames)
        self.buffer_plan = plan

    # ── Stream ───────────────────────────────────────────────────────────────

    def _open_stream(self) -> bool:
        try:
            self._stream = sd.InputStream(
                samplerate = self.rate,
                channels   = CE_CHANNELS,
                dtype      = "float32",
                blocksize  = self.blocksize,
                callback   = self._audio_callback,
                latency    = "high",
            )
            # 0.13.002: la frecuencia efectiva del stream debe ser la pedida;
            # Lorito no convierte frecuencias en la captura.
            got = getattr(self._stream, "samplerate", self.rate)
            if isinstance(got, (int, float)) and abs(float(got) - float(self.rate)) > 0.5:
                _ce_log.error("Stream abierto a %s Hz en vez de %d Hz: se rechaza", got, self.rate)
                try:
                    self._stream.close()
                finally:
                    self._stream = None
                return False
            self._stream.start()
            self._status.estimated_latency_ms = (self.blocksize / self.rate) * 1000.0
            _ce_log.info("Stream abierto: %dHz  bs=%d  latency=high  est_lat=%.1fms",
                         self.rate, self.blocksize, self._status.estimated_latency_ms)
            return True
        except Exception as exc:
            _ce_log.error("ERROR al abrir stream: %s", exc)
            self._stream = None
            return False

    def _close_stream(self):
        stream = self._stream
        self._stream = None
        if stream is not None:
            try:
                stream.stop()
                stream.close()
            except Exception as e:
                _ce_log.warning("Error cerrando stream: %s", e)

    # ── Recovery (serializado con el ciclo de vida, CAP-011) ────────────────

    def _on_watchdog_alert(self, phase: str, elapsed_s: float):
        pass

    def _on_stream_dead(self):
        with self._recovery_lock:
            self._auto_recover()

    def _recovery_sleep(self, secs: float, generation: int) -> bool:
        """Espera de backoff en tramos cortos; False si la sesión dejó de
        admitir recovery (parada solicitada / generación nueva)."""
        remaining = secs
        while remaining > 0:
            step = 0.05 if remaining > 0.05 else remaining
            time.sleep(step)
            remaining -= step
            if not self._fsm.recovery_allowed(generation):
                return False
        return True

    def _auto_recover(self):
        """Recovery no destructivo: no limpia ni sobrescribe buffers; nunca
        reabre un stream tras una solicitud de parada; el hueco de
        dispositivo queda como discontinuidad DEVICE_GAP en el ledger."""
        _s  = self._status
        gen = self._fsm.generation
        if not self._fsm.recovery_allowed(gen):
            _ce_log.warning("Recovery denegado: sesión en estado %s.", self._fsm.state.value)
            return
        now = time.monotonic()
        if _s.recovery_last_t > 0:
            elapsed = now - _s.recovery_last_t
            if elapsed < CE_RECOVERY_COOLDOWN:
                _ce_log.warning("Recovery: cooldown activo (%.1fs restantes).",
                                CE_RECOVERY_COOLDOWN - elapsed)
                return

        _s.recovery_count += 1
        _ce_log.warning("Recovery #%d iniciado.", _s.recovery_count)
        gap_start_ns = _s.last_callback_ns or _monotonic_raw_ns()
        frames_at_gap = self._ledger.received
        with self._lifecycle_lock:
            if not self._fsm.recovery_allowed(gen):
                return
            self._close_stream()

        bs_candidates = list(dict.fromkeys([self.blocksize, 512, 1024, 2048, 4096]))
        for attempt in range(CE_RECOVERY_MAX_ATTEMPTS):
            wait = min(CE_RECOVERY_BACKOFF_BASE * (2 ** min(attempt, 7)),
                       CE_RECOVERY_BACKOFF_CAP)
            _ce_log.info("Recovery: intento %d/%d — esperando %.2fs.",
                         attempt + 1, CE_RECOVERY_MAX_ATTEMPTS, wait)
            if not self._recovery_sleep(wait, gen):
                _ce_log.warning("Recovery abortado: parada solicitada durante el backoff.")
                return
            if attempt >= 3:
                self.blocksize = bs_candidates[(attempt - 3) % len(bs_candidates)]
            with self._lifecycle_lock:
                if not self._fsm.recovery_allowed(gen):
                    _ce_log.warning("Recovery abortado: la sesión ya no admite reapertura.")
                    return
                opened = self._open_stream()
            if opened:
                _s.stream_alive    = True
                _s.recovery_last_t = time.monotonic()
                _s.wd_phase        = "OK"
                gap_s = max(0.0, (_monotonic_raw_ns() - gap_start_ns) / 1e9)
                self._ledger.record_discontinuity(
                    "DEVICE_GAP", frames_at_gap, int(gap_s * self.rate), unknown=True,
                    detail=f"recovery #{_s.recovery_count}: ~{gap_s:.3f}s sin captura "
                           f"(estimado por reloj monotónico)")
                _ce_log.info("Stream RECUPERADO en intento %d (blocksize=%d).",
                             attempt + 1, self.blocksize)
                return
            _ce_log.warning("Recovery: intento %d/%d falló.", attempt + 1,
                            CE_RECOVERY_MAX_ATTEMPTS)

        _s.recovery_last_t = time.monotonic()
        _ce_log.critical("FALLO CRÍTICO: stream no pudo recuperarse tras %d intentos.",
                         CE_RECOVERY_MAX_ATTEMPTS)
        self._ledger.record_discontinuity("RECOVERY_EXHAUSTED", frames_at_gap, 0,
                                          unknown=True, detail="stream irrecuperable")
        self._initiate_fail_stop("RECOVERY_EXHAUSTED")


# ── Alias de compatibilidad con el monolito ──────────────────────────────────
AudioCaptureEngine = CaptureEngineV2
