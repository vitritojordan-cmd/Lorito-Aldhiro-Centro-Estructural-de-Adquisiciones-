from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Raíz de composición: crea los motores una vez y es la única vía de la interfaz hacia el estado global (LA-GOLDEN-CORE-020 §4).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Hasta 0.14.001 cada mixin de la ventana importaba directamente las clases
de los motores y los objetos globales con estado (`_crash_guard`,
`_snapshot_worker`, `_clip_log`, `_xrun_forensics`) y los usaba desde donde
le hacía falta. Ahora:

- `build_app_services()` los crea o reúne una sola vez; la ventana lo
  llama en su `__init__` y guarda el resultado en `self._services`;
- los mixins los piden a `self._services`, tipados por los contratos de
  `lorito_contracts`;
- las fábricas sin estado (`new_transport_coordinator`, `new_export_service`,
  `make_tau_service`) son el único lugar que conoce esas clases.

No cambia qué objetos existen ni cómo se conectan entre sí: es el mismo
cableado que hacía la ventana, en un único sitio.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional

from lorito_aldhiro.backend.audio import lorito_tau as _tau
from lorito_aldhiro.backend.audio.lorito_audio_backend import _sample_ram_mb
from lorito_aldhiro.backend.audio.lorito_audio_utils import _clip_log
from lorito_aldhiro.backend.audio.lorito_ring_buffers import _xrun_forensics
from lorito_aldhiro.backend.audio.lorito_rt_priorities import _check_scheduler_warnings
from lorito_aldhiro.backend.capture import lorito_capture_engine as _ce
from lorito_aldhiro.backend.core.lorito_constants import RAM_THRESHOLD_CRITICAL_MB, RAM_THRESHOLD_HIGH_MB
from lorito_aldhiro.backend.capture import lorito_snapshot as _snap
from lorito_aldhiro.backend.capture.lorito_session_status import bind as _bind_session_status
from lorito_aldhiro.backend.export_streaming.lorito_export_service import ExportService
from lorito_aldhiro.backend.nr.lorito_nr_coordinator import NRCoordinator
from lorito_aldhiro.backend.playback.lorito_monitor_engine import MonitorEngine
from lorito_aldhiro.backend.playback.lorito_playback_engine import PlaybackEngine
from lorito_aldhiro.backend.telemetry.lorito_ram_watchdog import RamWatchdog
from lorito_aldhiro.backend.telemetry.lorito_corazon import CorazonEngine
from lorito_aldhiro.backend.capture.lorito_corazon_capture import attach_corazon
from lorito_aldhiro.backend.services.lorito_contracts import (
    CaptureService, DspChainService, SessionStatus, ExportServiceContract, MonitorService,
    PlaybackService, SessionGuardService, TauServiceContract, TransportService)
from lorito_aldhiro.backend.transport.lorito_ffrew_motors import (
    LogicalFileAdapter, TransportCoordinator)

# Configuración inicial de los motores (la misma que usaba la ventana).
INITIAL_RATE = 48000
INITIAL_CHANNELS = 2
INITIAL_NR_MODE = "DECODE"

# La memoria es del proceso: un único vigilante para todas las ventanas.
_RAM_WATCHDOG = RamWatchdog(RAM_THRESHOLD_HIGH_MB, RAM_THRESHOLD_CRITICAL_MB, _sample_ram_mb)


@dataclass
class AppServices:
    capture: CaptureService
    session_status: SessionStatus
    nr: DspChainService
    monitor: MonitorService
    playback: PlaybackService
    session_guard: SessionGuardService
    snapshot_worker: Any
    clip_log: Any
    xrun_forensics: Any
    ram_watchdog: RamWatchdog
    corazon: "CorazonEngine"
    heartbeat_path: str
    manifest_path: str
    validate_crash_manifest: Callable[[dict], tuple] = field(default=_snap._validate_crash_manifest)

    # ── operaciones sin estado propio ────────────────────────────────────
    @staticmethod
    def warm_up_dsp(sample_rate: int = INITIAL_RATE, channels: int = INITIAL_CHANNELS) -> float:
        return NRCoordinator.warm_up(sample_rate, channels)

    @staticmethod
    def warm_up_all_dsp(sample_rate: int = INITIAL_RATE, channels: int = INITIAL_CHANNELS) -> float:
        return NRCoordinator.warm_up_all(sample_rate, channels)

    @staticmethod
    def sample_ram_mb() -> float:
        return _sample_ram_mb()

    @staticmethod
    def check_scheduler_warnings() -> List[str]:
        return _check_scheduler_warnings()

    @staticmethod
    def audio_device_module() -> Optional[Any]:
        """El módulo de audio que usa el motor de captura (PortAudio real o
        el sustituto de las pruebas)."""
        return getattr(_ce, "sd", None)


def build_app_services() -> AppServices:
    """Crea y conecta los motores y enlaza el estado de sesión (el del
    motor de captura). Lo llama solo la ventana principal."""
    capture = _ce.CaptureEngineV2()
    nr = NRCoordinator(sample_rate=INITIAL_RATE, channels=INITIAL_CHANNELS, mode=INITIAL_NR_MODE)
    capture.nr_coordinator = nr
    monitor = MonitorEngine(sample_rate=INITIAL_RATE, channels=INITIAL_CHANNELS)
    capture.monitor_engine = monitor
    # Corazón del Lorito (0.14.005): refleja la sesión de captura; su
    # autoridad es la máquina de estados del motor.
    corazon = CorazonEngine()
    attach_corazon(capture, corazon)
    return AppServices(
        capture=capture, session_status=_bind_session_status(capture.get_status()), nr=nr, monitor=monitor, playback=PlaybackEngine(),
        session_guard=_snap._crash_guard, snapshot_worker=_snap._snapshot_worker,
        clip_log=_clip_log, xrun_forensics=_xrun_forensics, ram_watchdog=_RAM_WATCHDOG,
        corazon=corazon,
        heartbeat_path=_snap._HEARTBEAT_PATH, manifest_path=_snap._MANIFEST_PATH)


# ── Fábricas sin estado ──────────────────────────────────────────────────

def new_transport_coordinator() -> TransportService:
    return TransportCoordinator(LogicalFileAdapter())


def new_wind_scan_audio():
    """Sonido del bobinado FF/REW (0.14.004): uno por ventana."""
    from lorito_aldhiro.backend.playback.lorito_wind_scan_audio import WindScanAudio
    return WindScanAudio()


def new_export_service() -> ExportServiceContract:
    return ExportService()


def make_tau_service(**kw) -> TauServiceContract:
    return _tau.TauService(**kw)
