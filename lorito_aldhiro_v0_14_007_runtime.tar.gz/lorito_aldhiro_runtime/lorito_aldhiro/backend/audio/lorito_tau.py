from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: TAU: pitidos de confirmación (1 = activación, 2 = desactivación) con leyenda sincronizada en el LCD (LA-TAU-OI-001).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


TAU, la señalización acústica y visual de Lorito Aldhiro (Orden LA-TAU-OI-001,
0.13.004).

**Patrones.**

- ACTIVACIÓN (acción encendida y confirmada): exactamente 1 pitido.
- DESACTIVACIÓN (acción apagada y confirmada): exactamente 2 pitidos
  separados por una pausa.

La leyenda «TAU» del LCD se enciende cuando el audio *empieza efectivamente*
a sonar (el primer callback que entrega el tono). Sigue encendida durante la
pausa entre los dos pitidos y se apaga cuando se entregó la última muestra.

**Capas, desacopladas (§4.1):**

1. `TauSequencer`, puro, sin Qt ni audio: línea de tiempo exacta a la
   muestra, política de solicitudes y eventos `start` y `end`.
2. `TauService`: dueño de UN stream de salida reutilizable de la misma
   librería y dispositivo que el resto de Lorito (sounddevice/PortAudio). Lo
   abre a demanda en un único hilo de servicio, lo reutiliza entre clics y
   lo cierra tras `IDLE_CLOSE_S` de inactividad. Nunca crea un hilo ni un
   stream por clic.
3. El frontend: el botón decide el patrón con el resultado YA confirmado y
   el LCD refleja los eventos que llegan por una señal Qt encolada. TAU no
   toca la lógica de los botones.

**Por qué un stream propio y no mezclar en los de reproducción o monitor.**
Esos callbacks están certificados (ledger, generaciones, temporización).
Mezclar en ellos haría que TAU pudiera alterar la reproducción principal, y
la orden pide lo contrario (TAU-T05). Con PipeWire o PulseAudio, los streams
se mezclan en el servidor. Con un dispositivo ALSA `hw` exclusivo, el stream
de TAU puede no abrirse mientras se reproduce: TAU falla de forma segura, sin
pitido ni leyenda (§4.3).

**Política de solicitudes (§4.1 y §4.3):**

- Como máximo UNA solicitud pendiente: una nueva reemplaza a la pendiente.
- Una solicitud idéntica a la última aceptada dentro de `DEBOUNCE_S` se
  ignora (doble clic o rebote).

**Tono.** Seno con rampas de coseno alzado de `RAMP_MS` al principio y al
final, que evitan el clic de un corte brusco, y nivel de `LEVEL_DBFS`. Los
parámetros están centralizados en `TauParams`. La duración y la pausa
quedan dentro de lo recomendado por la orden (60–100 ms y 70–120 ms).
"""

import math
import queue
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

import numpy as np

ACTIVATE = "ACTIVATE"
DEACTIVATE = "DEACTIVATE"
PATTERN_BEEPS = {ACTIVATE: 1, DEACTIVATE: 2}


@dataclass(frozen=True)
class TauParams:
    tone_hz: float = 1500.0
    tone_ms: float = 80.0          # orden: 60–100 ms
    gap_ms: float = 95.0           # orden: 70–120 ms
    ramp_ms: float = 5.0           # coseno alzado, sin clic
    level_dbfs: float = -18.0
    rate: int = 48000
    channels: int = 2
    blocksize: int = 256           # ~5,3 ms a 48 kHz: baja latencia
    debounce_s: float = 0.12
    idle_close_s: float = 3.0

    def frames(self, ms: float) -> int:
        return int(round(self.rate * ms / 1000.0))


DEFAULT_PARAMS = TauParams()


def make_tone(p: TauParams) -> np.ndarray:
    n = p.frames(p.tone_ms)
    t = np.arange(n) / p.rate
    amp = 10.0 ** (p.level_dbfs / 20.0)
    x = amp * np.sin(2 * np.pi * p.tone_hz * t)
    r = min(p.frames(p.ramp_ms), n // 2)
    if r > 0:
        ramp = 0.5 - 0.5 * np.cos(np.pi * np.arange(r) / r)      # 0 → 1
        x[:r] *= ramp
        x[n - r:] *= ramp[::-1]
    return x.astype(np.float32)


def pattern_frames(kind: str, p: TauParams) -> int:
    beeps = PATTERN_BEEPS[kind]
    return beeps * p.frames(p.tone_ms) + (beeps - 1) * p.frames(p.gap_ms)


class TauSequencer:
    """Línea de tiempo de TAU. `request` se llama desde el hilo GUI y
    `render`, desde el callback de audio. La sección crítica es mínima y
    el callback nunca espera por el lock: si está tomado, ese ciclo
    entrega silencio y lo reintenta en el siguiente."""

    def __init__(self, params: TauParams = DEFAULT_PARAMS, clock=time.monotonic):
        self.p = params
        self._tone = make_tone(params)
        self._tone_n = len(self._tone)
        self._gap_n = params.frames(params.gap_ms)
        self._lock = threading.Lock()
        self._pending: Optional[str] = None
        self._active: Optional[str] = None
        self._pos = 0
        self._len = 0
        self._last_req: Tuple[Optional[str], float] = (None, -1e9)
        self._clock = clock
        self.stats = {"requested": 0, "accepted": 0, "debounced": 0, "replaced": 0,
                      "started": 0, "finished": 0, "beeps": 0}

    # ── hilo GUI ─────────────────────────────────────────────────────────
    def request(self, kind: str) -> bool:
        if kind not in PATTERN_BEEPS:
            raise ValueError(f"TAU: patrón desconocido {kind!r}")
        now = self._clock()
        with self._lock:
            self.stats["requested"] += 1
            last_kind, last_t = self._last_req
            if kind == last_kind and now - last_t < self.p.debounce_s:
                self.stats["debounced"] += 1
                return False
            if self._pending is not None:
                self.stats["replaced"] += 1
            self._pending = kind
            self._last_req = (kind, now)
            self.stats["accepted"] += 1
            return True

    def cancel(self) -> None:
        with self._lock:
            self._pending = None
            self._active = None
            self._pos = self._len = 0

    @property
    def busy(self) -> bool:
        return self._active is not None or self._pending is not None

    # ── callback de audio ────────────────────────────────────────────────
    def render(self, out: np.ndarray, frames: int) -> List[tuple]:
        """Escribe `frames` muestras en `out` (frames × canales, se pisa:
        silencio salvo el tono). Devuelve los eventos de este ciclo, en
        orden: ("start", kind) cuando el tono empieza a sonar, ("end", kind)
        cuando se entregó la última muestra del patrón."""
        out[:frames] = 0.0
        if not self._lock.acquire(blocking=False):
            return []
        events = []
        try:
            i = 0
            while i < frames:
                if self._active is None:
                    if self._pending is None:
                        break
                    self._active, self._pending = self._pending, None
                    self._pos, self._len = 0, pattern_frames(self._active, self.p)
                    self.stats["started"] += 1
                    events.append(("start", self._active))
                take = min(frames - i, self._len - self._pos)
                self._write(out, i, self._pos, take)
                i += take
                self._pos += take
                if self._pos >= self._len:
                    kind = self._active
                    self.stats["finished"] += 1
                    self.stats["beeps"] += PATTERN_BEEPS[kind]
                    events.append(("end", kind))
                    self._active = None
        finally:
            self._lock.release()
        return events

    def _write(self, out, i0, pos, n):
        """Copia el tramo [pos, pos+n) del patrón (tono · pausa · tono)."""
        period = self._tone_n + self._gap_n
        end = pos + n
        while pos < end:
            k, off = divmod(pos, period)
            if off < self._tone_n:
                m = min(end - pos, self._tone_n - off)
                out[i0:i0 + m] = self._tone[off:off + m, None]
            else:
                m = min(end - pos, period - off)
            i0 += m
            pos += m


class TauService:
    """Servicio TAU: secuenciador + stream de salida reutilizable abierto en
    un hilo de servicio único. `on_events(list)` (eventos `(tipo, patrón,
    hora monotónica del audio)`) y `on_failure(str)` se
    llaman desde el hilo de servicio (0.14.007: el callback de audio ya no
    llama código de la interfaz; deja los eventos en una cola)."""

    def __init__(self, params: TauParams = DEFAULT_PARAMS, sd_module=None,
                 on_events: Optional[Callable[[list], None]] = None,
                 on_failure: Optional[Callable[[str], None]] = None):
        self.p = params
        self.seq = TauSequencer(params)
        self._sd = sd_module
        self.on_events = on_events
        self.on_failure = on_failure
        # Identidad con la que la interfaz etiqueta los eventos de este
        # servicio en el puente Qt (la asigna quien lo crea; ver mw_tau).
        self.bridge_token: Optional[int] = None
        self._stream = None
        self._last_activity = time.monotonic()
        # Órdenes del hilo GUI y eventos del callback de audio: una sola cola
        # (SimpleQueue, en C; `put` nunca espera). El hilo de servicio se
        # despierta en cuanto llega algo, sin sondear.
        self._cmd: "queue.SimpleQueue" = queue.SimpleQueue()
        self._closed = False
        self.failures = 0
        self.last_error = ""
        self._thread: Optional[threading.Thread] = None   # se crea con el primer pitido
        self._thread_lock = threading.Lock()

    def _ensure_thread(self) -> None:
        with self._thread_lock:
            if self._thread is None and not self._closed:
                self._thread = threading.Thread(target=self._loop, name="lorito-tau", daemon=True)
                self._thread.start()

    # ── API (hilo GUI) ───────────────────────────────────────────────────
    def signal(self, kind: str) -> bool:
        """Solicita un patrón. Nunca bloquea: la apertura del stream ocurre
        en el hilo de servicio."""
        if self._closed:
            return False
        if not self.seq.request(kind):
            return False
        self._last_activity = time.monotonic()
        self._ensure_thread()
        self._post("ensure_open")
        return True

    def activate(self) -> bool:
        return self.signal(ACTIVATE)

    def deactivate(self) -> bool:
        return self.signal(DEACTIVATE)

    def shutdown(self, timeout: float = 1.0) -> None:
        """Cierre ordenado: cancela lo pendiente y cierra el stream."""
        if self._closed:
            return
        self._closed = True
        self.seq.cancel()
        th = self._thread
        if th is None:
            return
        for cmd in ("close", None):
            self._cmd.put(cmd)
        th.join(timeout)

    @property
    def stream_open(self) -> bool:
        return self._stream is not None

    # ── hilo de servicio ─────────────────────────────────────────────────
    def _post(self, cmd) -> None:
        self._cmd.put(cmd)

    def _loop(self) -> None:
        while True:
            try:
                cmd = self._cmd.get(timeout=0.5)
            except queue.Empty:
                cmd = "idle_check"
            if isinstance(cmd, tuple):              # ("events", [...]) del callback
                cb = self.on_events
                if cb is not None:
                    try:
                        cb(cmd[1])
                    except Exception:
                        pass
                continue
            if cmd is None:
                return
            try:
                if cmd == "ensure_open":
                    self._open()
                elif cmd == "close":
                    self._close()
                elif cmd == "idle_check":
                    if (self._stream is not None and not self.seq.busy and
                            time.monotonic() - self._last_activity > self.p.idle_close_s):
                        self._close()
            except Exception as e:                  # nunca muere el servicio
                self._fail(f"{type(e).__name__}: {e}")

    def _sd_mod(self):
        if self._sd is None:
            try:
                import sounddevice as sd
                self._sd = sd
            except Exception:
                self._sd = False
        return self._sd or None

    def _open(self) -> None:
        if self._stream is not None or self._closed:
            return
        sd = self._sd_mod()
        factory = getattr(sd, "OutputStream", None) if sd is not None else None
        if factory is None:
            self._fail("salida de audio no disponible")
            return
        out_buf = np.zeros((self.p.blocksize * 4, self.p.channels), np.float32)

        def _cb(outdata, frames, time_info, status):
            # 0.14.007 (Loro Central Boss, §5): el callback solo calcula y
            # mueve datos. Bloques mayores que el búfer se sirven por tramos
            # (sin asignar) y los eventos del pitido pasan al hilo de
            # servicio, que es quien avisa a la interfaz.
            cap = len(out_buf)
            pos = 0
            while pos < frames:
                n = frames - pos if frames - pos < cap else cap
                ev = self.seq.render(out_buf, n)
                outdata[pos:pos + n] = out_buf[:n]
                if ev:
                    # Hora monotónica del render (vDSO, sin espera): la
                    # interfaz dura la leyenda por el AUDIO, no por cuándo le
                    # llega el aviso.
                    t = time.monotonic()
                    self._cmd.put(("events", [(e[0], e[1], t) for e in ev]))
                pos += n
        try:
            st = factory(samplerate=self.p.rate, channels=self.p.channels, dtype="float32",
                         blocksize=self.p.blocksize, latency="low", callback=_cb)
            st.start()
        except Exception as e:
            self._fail(f"no se pudo abrir la salida: {e}")
            return
        self._stream = st

    def _close(self) -> None:
        st, self._stream = self._stream, None
        if st is not None:
            try:
                st.stop()
                st.close()
            except Exception:
                pass

    def _fail(self, why: str) -> None:
        """Fallo seguro: lo pendiente se descarta (sin pitido no hay
        leyenda) y se informa al frontend para que limpie el LCD."""
        self.failures += 1
        self.last_error = why
        self.seq.cancel()
        self._close()
        if self.on_failure is not None:
            try:
                self.on_failure(why)
            except Exception:
                pass
