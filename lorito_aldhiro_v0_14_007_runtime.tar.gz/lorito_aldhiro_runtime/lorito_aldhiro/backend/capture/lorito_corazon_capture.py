from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Adaptador de sesión de captura del Corazón del Lorito: conecta la máquina de estados del motor de captura con el reloj maestro del corazón.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Una sola autoridad de estado (sección 4 de la orden): la máquina de estados
de la sesión de captura (`CaptureSessionFSM`). El corazón la REFLEJA; la
interfaz nunca le ordena nada al corazón por su cuenta, así que corazón,
motor y LCD no pueden contradecirse (T-09).

| Captura (FSM)                 | Corazón                                   |
|-------------------------------|-------------------------------------------|
| → IDLE                        | reset → DETENIDO (sale de ERROR/FINALIZADO)|
| → ARMING                      | prepare → PREPARADO                       |
| sesión CONFIRMADA (`start()` OK)| start → GRABANDO                         |
| PAUSED → CAPTURING            | resume → GRABANDO                         |
| → PAUSED                      | pause → PAUSADO                           |
| → DRAINING / FINALIZING / CLASSIFIED | stop → FINALIZADO                  |
| → FAILED                      | fail → ERROR (sin latido)                 |

`ARMING → CAPTURING` NO arranca el corazón: el motor pasa a CAPTURING antes
de abrir el stream, y si la apertura falla la sesión termina en FAILED. Sólo
cuando `start()` confirma la sesión, el corazón late (sección 3: "solo tras
confirmar que la sesión de captura se ha iniciado correctamente").

El aviso llega en el hilo que hizo la transición (worker de apertura, hilo de
drenado, fail-stop…). Lo que hace aquí el corazón es O(1) con un lock corto:
no bloquea a la captura (RF-07). Un fallo del corazón nunca se propaga a la
captura: se registra y la sesión sigue.
"""

import logging

from lorito_aldhiro.backend.capture.lorito_capture_session import CaptureState
from lorito_aldhiro.backend.core.lorito_identity import engine_logger_name
from lorito_aldhiro.backend.telemetry.lorito_corazon import CorazonEngine, HeartState

_log = logging.getLogger(engine_logger_name("corazon"))

EVENT_TRANSITION = "TRANSITION"
EVENT_CONFIRMED = "CONFIRMED"


class CaptureCorazonAdapter:
    def __init__(self, corazon: CorazonEngine):
        self.corazon = corazon
        self.errors = 0

    def __call__(self, event: str, old, new, reason: str = "", generation: int = 0) -> None:
        try:
            self._apply(event, old, new, reason, generation)
        except Exception as e:                      # nunca hacia la captura
            self.errors += 1
            _log.error("Corazón: aviso de captura no aplicado (%s → %s): %s", old, new, e)

    def _apply(self, event, old, new, reason, generation) -> None:
        c = self.corazon
        sid = f"gen-{generation}"
        if event == EVENT_CONFIRMED:
            if c.state is HeartState.PREPARADO:
                c.start(sid)
            return
        if new == CaptureState.IDLE:
            c.reset("captura en reposo")
        elif new == CaptureState.ARMING:
            if c.state is not HeartState.DETENIDO:
                c.reset("sesión nueva")
            c.prepare(sid)
        elif new == CaptureState.CAPTURING:
            if old == CaptureState.PAUSED:
                c.resume(reason or "reanudación")
            # ARMING → CAPTURING: se espera la confirmación de start().
        elif new == CaptureState.PAUSED:
            c.pause(reason or "pausa")
        elif new in (CaptureState.DRAINING, CaptureState.FINALIZING, CaptureState.CLASSIFIED):
            if c.state in (HeartState.GRABANDO, HeartState.PAUSADO, HeartState.PREPARADO):
                c.stop(reason or new.value)
        elif new == CaptureState.FAILED:
            c.fail(reason or "FAILED")
        snap = c.snapshot()
        _log.info("Corazón: %s (captura %s; efectivo %.3f s; pulsos %d)",
                  snap.state.value, new.value, snap.elapsed_ns() / 1e9, snap.pulse_count)


def attach_corazon(capture_engine, corazon: CorazonEngine) -> CaptureCorazonAdapter:
    """Conecta el corazón a la máquina de estados de `capture_engine`."""
    adapter = CaptureCorazonAdapter(corazon)
    capture_engine.add_state_listener(adapter)
    return adapter
