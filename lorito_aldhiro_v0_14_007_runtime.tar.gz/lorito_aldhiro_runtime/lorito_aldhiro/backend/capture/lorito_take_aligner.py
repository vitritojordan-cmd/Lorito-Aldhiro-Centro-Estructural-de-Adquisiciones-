"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Alineador de la toma destructiva: la salida de la cadena DSP de captura queda frame a frame sobre el RAW, sin huecos ni latencia, aunque el DSP falle o se apague a mitad de la sesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Los DSP de Lorito Aldhiro son DESTRUCTIVOS (0.14.006): se aplican durante la
captura y, al vaciar el búfer, la sesión ya es audio procesado. No existe
camino post-destructivo (un journal de DSP aplicado al exportar).

La cadena de captura corre en streaming con un re-bloqueo fijo
(`FixedBlockAdapter`), así que su salida llega retrasada `latency` frames
(256) y arranca con ese mismo número de ceros. Este alineador convierte esa
salida en la toma de la sesión:

- **Inicio:** descarta los `latency` frames iniciales (los ceros del cebado).
  El frame 0 de la toma corresponde al frame 0 del RAW.
- **Fin:** `flush()` empuja `latency` frames de silencio por la cadena para
  sacar la cola que todavía tenía dentro. La toma mide exactamente lo mismo
  que el RAW.
- **Sin DSP para un bloque** (falló, o el DSP quedó fuera de presupuesto):
  ese tramo sale como RAW retrasado por la misma línea de retardo, así que la
  toma sigue continua. Nunca hay silencio ni corte.
- **Tras un fallo** el motor reinicia la cadena (`resync()`). La cadena
  vuelve a arrancar con `latency` ceros, y esos frames se reemplazan por el
  RAW retrasado que les corresponde. El empalme queda exacto.

Posición: `pos` es la posición, en frames de la sesión, del próximo frame que
sale. Empieza en `-latency`; los frames con posición negativa se descartan.
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np


class TakeAligner:
    """Convierte bloques (RAW, salida DSP o None) en la toma alineada."""

    def __init__(self, latency: int, channels: int):
        self.latency = max(0, int(latency))
        self.channels = int(channels)
        self._tail = np.zeros((self.latency, self.channels), dtype=np.float32)
        self.pos = -self.latency
        self._owed_until = -self.latency     # [pos, owed_until): ceros de cebado
        self.processed_frames = 0
        self.passthrough_frames = 0
        self.resyncs = 0

    def _delayed(self, raw: np.ndarray) -> np.ndarray:
        """RAW retrasado `latency` frames (línea de retardo continua)."""
        if self.latency == 0:
            return raw
        cat = np.concatenate((self._tail, raw.astype(np.float32, copy=False)), axis=0)
        n = raw.shape[0]
        self._tail = cat[n:].copy()
        return cat[:n]

    def _emit(self, y: np.ndarray, from_dsp: bool, replaced: int) -> np.ndarray:
        n = y.shape[0]
        start = self.pos
        self.pos += n
        cut = min(n, -start) if start < 0 else 0
        kept = n - cut
        if kept > 0:
            dsp_kept = max(0, kept - max(0, replaced - cut)) if from_dsp else 0
            self.processed_frames += dsp_kept
            self.passthrough_frames += kept - dsp_kept
        return y[cut:] if cut else y

    def feed(self, raw: np.ndarray, processed: Optional[np.ndarray]) -> np.ndarray:
        """`processed` es la salida de la cadena para `raw` (misma forma) o
        None si ese bloque no pasó por el DSP. Devuelve el tramo de toma
        (puede ser más corto al inicio, nunca más largo)."""
        d = self._delayed(raw)
        if processed is None:
            return self._emit(d, from_dsp=False, replaced=0)
        y = processed
        replaced = 0
        if self._owed_until > self.pos:
            replaced = min(y.shape[0], self._owed_until - self.pos)
            y = y.copy()
            y[:replaced] = d[:replaced]
        return self._emit(y, from_dsp=True, replaced=replaced)

    def resync(self) -> None:
        """La cadena se reinició: sus próximos `latency` frames son ceros de
        cebado y se reemplazan por el RAW retrasado."""
        self._owed_until = self.pos + self.latency
        self.resyncs += 1

    def flush(self, process: Optional[Callable[[np.ndarray], np.ndarray]] = None) -> np.ndarray:
        """Últimos `latency` frames de la toma: la cola de la cadena (con
        `process`) o el RAW retrasado que quedó en la línea de retardo."""
        if self.latency == 0:
            return np.zeros((0, self.channels), dtype=np.float32)
        silence = np.zeros((self.latency, self.channels), dtype=np.float32)
        if process is not None:
            out = process(silence)
            if out is None or out.shape != silence.shape:
                raise ValueError(f"forma de salida DSP inválida en el cierre: "
                                 f"{None if out is None else out.shape}")
            return self.feed(silence, np.asarray(out, dtype=np.float32))
        return self.feed(silence, None)
