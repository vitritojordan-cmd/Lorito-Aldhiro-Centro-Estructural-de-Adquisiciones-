from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Configuración central de logging de la aplicación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import atexit
import os
import logging
import queue
from logging.handlers import QueueHandler, QueueListener, RotatingFileHandler
from lorito_aldhiro.backend.core.lorito_identity import INTERNAL_LOG_FILE, logger_name


# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES GLOBALES
# ─────────────────────────────────────────────────────────────────────────────

ARCHIVE_DIR = os.path.expanduser("~/AUX/fonogramas")
os.makedirs(ARCHIVE_DIR, exist_ok=True)

# ── Logger interno silencioso (rotativo, bajo overhead) ───────────────────────
_LOG_PATH = os.path.join(ARCHIVE_DIR, INTERNAL_LOG_FILE)
_log = logging.getLogger(logger_name())
_log.setLevel(logging.DEBUG)
_log.propagate = False


class _DroppingQueueHandler(QueueHandler):
    """0.14.007 (Loro Central Boss, §5): registrar un log nunca escribe a
    disco en el hilo que lo emite. El registro pasa a una cola acotada y el
    hilo del `QueueListener` escribe el archivo. Si la cola se llena (disco
    detenido), el registro se descarta y se cuenta; el que registra nunca
    espera."""

    dropped = 0

    def enqueue(self, record):
        try:
            self.queue.put_nowait(record)
        except queue.Full:
            type(self).dropped += 1


LOG_QUEUE_MAX = 10000
_log_queue: "queue.Queue" = queue.Queue(maxsize=LOG_QUEUE_MAX)
_log_listener = None
try:
    _fh = RotatingFileHandler(_LOG_PATH, maxBytes=2*1024*1024, backupCount=3)
    _fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    _log.addHandler(_DroppingQueueHandler(_log_queue))
    _log_listener = QueueListener(_log_queue, _fh, respect_handler_level=True)
    _log_listener.start()
    atexit.register(_log_listener.stop)
except Exception:
    _log.addHandler(logging.NullHandler())


def log_queue_stats() -> dict:
    """Pendientes y descartados de la cola de logs (diagnóstico)."""
    return {"pending": _log_queue.qsize(), "dropped": _DroppingQueueHandler.dropped,
            "capacity": LOG_QUEUE_MAX,
            "writer_alive": bool(_log_listener is not None
                                 and getattr(_log_listener, "_thread", None) is not None)}
