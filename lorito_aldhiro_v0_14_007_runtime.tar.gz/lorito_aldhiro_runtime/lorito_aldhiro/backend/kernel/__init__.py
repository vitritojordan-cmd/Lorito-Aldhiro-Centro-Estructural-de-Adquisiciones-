"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — Kernel coordinador en espacio de usuario (Orden LA-KRN-LCB-001): planificador, dispositivos, salud y recuperación.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Contrato público: `lcb_contracts` (tipos) y `LoroCentralBoss` (API).
Los motores no importan los módulos internos (planificador, salud,
dispositivos, recuperación) para decidir por su cuenta: usan la API y los
eventos tipados.
"""

from lorito_aldhiro.backend.kernel.lcb_contracts import LCB_API_VERSION  # noqa: F401
from lorito_aldhiro.backend.kernel.lcb_kernel import KernelConfig, LoroCentralBoss  # noqa: F401
