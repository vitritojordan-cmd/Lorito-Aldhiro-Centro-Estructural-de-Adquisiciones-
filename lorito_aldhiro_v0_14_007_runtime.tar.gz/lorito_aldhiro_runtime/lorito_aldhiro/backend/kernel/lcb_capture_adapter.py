"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — adaptador del motor de captura: refleja su máquina de estados, publica sus contadores como salud, traduce sus fallos y fija el dispositivo de entrada con una concesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


§6: el motor de captura es la fuente autoritativa del estado de grabación
y de los contadores de frames. El Kernel supervisa; no inventa el progreso.

**Estado.** Se usa el oyente público `add_state_listener()` del motor.

| Captura | Sistema |
|---|---|
| ARMING desde FAILED | reconocimiento del error por el operador (REC) |
| CAPTURING | CAPTURANDO |
| PAUSED | PAUSADO |
| DRAINING | DETENIENDO → DRENANDO |
| FINALIZING | FINALIZANDO |
| CLASSIFIED / IDLE | LISTO (o DEGRADADO si hay riesgo) |
| FAILED | se declara el fallo y la parada segura VERIFICA lo que cerró el fail-stop del motor |

**Salud.** La sonda solo lee campos ya publicados en `CaptureEngineStatus`
(asignaciones atómicas bajo el GIL): ocupación del ring, presión de la
cola de disco, jitter, rechazos, overflow, frames. No toma locks del motor.

**Dispositivo de entrada.** En la primera captura el adaptador pide la
concesión ("capture", INPUT) y fija en el motor el índice y el nombre del
dispositivo. Desde ahí el motor abre siempre ESE dispositivo, también al
recuperarse de una caída del stream. Antes de 0.14.007 abría "el
dispositivo por defecto" y, si el sistema cambiaba el predeterminado tras
una desconexión, la recuperación podía seguir grabando de otro sin avisar
(§3.2: prohibido). Si el backend no da inventario (pruebas, sin
PortAudio), el motor sigue con el comportamiento anterior.
"""

from __future__ import annotations

from typing import Optional

from lorito_aldhiro.backend.core.lorito_identity import engine_logger_name
from lorito_aldhiro.backend.kernel.lcb_contracts import (
    DeviceRequest, Direction, FaultKind, KernelError, SystemState as S,
)

import logging

_log = logging.getLogger(engine_logger_name("lcb"))


def classify_failure(reason: str) -> FaultKind:
    r = (reason or "").upper()
    if "WRITER" in r or "DISK" in r or "ENOSPC" in r or "PERMISSION" in r:
        return FaultKind.CORRUPTION_RISK
    if "RECOVERY_EXHAUSTED" in r or "DEVICE" in r:
        return FaultKind.DEVICE_LOST
    if "OVERFLOW" in r or "REJECT" in r or "RING" in r or "LOST" in r:
        return FaultKind.OVERFLOW_UNRECOVERABLE
    return FaultKind.AUDIO_INPUT_FAILURE


class CaptureKernelAdapter:
    def __init__(self, kernel, engine, soundfile_module=None):
        self.kernel = kernel
        self.engine = engine
        self.errors = 0
        self.lease_id: Optional[str] = None
        self.pin_error = ""
        kernel.recovery.attach_capture(engine, soundfile_module)
        engine.add_state_listener(self._on_capture_event)
        if kernel.health is not None:
            kernel.health.register_probe("capture", self._probe)
            kernel.health.register_progress("capture", self._progress)
            kernel.health.register_progress("disk", self._disk_progress)
            # La escucha en espera (pre-roll) no tiene vigilante en el motor:
            # si su stream muere, la salud lo ve por callbacks que no avanzan.
            kernel.health.register_progress("standby_input", self._standby_progress)
        # Se fija desde el arranque: la escucha en espera abre el stream antes
        # de la primera captura.
        self._pin_input_device()

    # ── estado ───────────────────────────────────────────────────────────
    def _on_capture_event(self, event, old, new, reason, generation) -> None:
        try:
            self._handle(event, getattr(old, "value", str(old)),
                         getattr(new, "value", str(new)), reason)
        except Exception as e:            # nunca se propaga a la captura
            self.errors += 1
            _log.error("LCB: el adaptador de captura falló (%s)", e)

    def _handle(self, event: str, old: str, new: str, reason: str) -> None:
        k = self.kernel
        if event != "TRANSITION":
            return
        if new == "ARMING":
            if k.state == S.ERROR:
                k.acknowledge_error("REC del operador")
            self._pin_input_device()
        elif new == "CAPTURING":
            k.drive(S.CAPTURANDO, "captura en curso")
        elif new == "PAUSED":
            k.drive(S.PAUSADO, "captura en pausa")
        elif new == "DRAINING":
            k.drive(S.DETENIENDO, "parada pedida")
            k.drive(S.DRENANDO, "vaciando el ring")
        elif new == "FINALIZING":
            k.drive(S.FINALIZANDO, "cerrando la sesión")
        elif new in ("CLASSIFIED", "IDLE"):
            if k.state in (S.CAPTURANDO, S.PAUSADO, S.DETENIENDO, S.DRENANDO, S.FINALIZANDO):
                k.drive(k._rest_state(), f"sesión {new.lower()}")
        elif new == "FAILED":
            was_capturing = old in ("CAPTURING", "PAUSED", "DRAINING", "FINALIZING")
            # El writer caído manda: aunque el ring se haya llenado antes por
            # culpa del disco, el riesgo es de corrupción del archivo.
            writer_failed = bool(getattr(self.engine.get_status(), "writer_failed", False))
            kind = FaultKind.CORRUPTION_RISK if writer_failed else classify_failure(reason)
            if was_capturing:
                # El fail-stop del motor ya cierra; la parada segura verifica.
                k.report_fault(kind, "capture", reason)
            else:
                k.recovery.faults.append((k._clock(), kind.value, "capture", reason))
                k._enter_error(f"{kind.value}: {reason}")

    # ── dispositivo ──────────────────────────────────────────────────────
    def _pin_input_device(self) -> None:
        k, eng = self.kernel, self.engine
        if not (k.enabled and k.config.pin_capture_device):
            return
        rate = int(getattr(eng, "rate", 48000) or 48000)
        try:
            lease = k.acquire_device(DeviceRequest(owner="capture", direction=Direction.INPUT,
                                                   device_id=self._pinned_device_id(),
                                                   channels=2, samplerate=rate))
        except KernelError as e:
            self.pin_error = f"{e.code}: {e}"
            _log.warning("LCB: dispositivo de entrada sin concesión (%s); el motor abre el "
                         "dispositivo por defecto como antes.", e)
            return
        if lease.lease_id != self.lease_id:
            if self.lease_id is not None:
                k.release_device(self.lease_id)
            self.lease_id = lease.lease_id
        info = next((d for d in k.devices.list_devices() if d.device_id == lease.device_id), None)
        if hasattr(eng, "pin_input_device"):
            eng.pin_input_device(lease.index, info.name if info else None)
        self.pin_error = ""

    def _pinned_device_id(self) -> Optional[str]:
        """Una vez concedido, el mismo dispositivo en todas las sesiones."""
        if self.lease_id is None:
            return None
        for l in self.kernel.devices.leases():
            if l.lease_id == self.lease_id:
                return l.device_id
        return None

    # ── salud ────────────────────────────────────────────────────────────
    def _probe(self):
        s = self.engine.get_status()
        active = bool(s.recording and not s.paused)
        return {
            "active": (1.0 if active else 0.0, "bool"),
            "ring_watermark_pct": (getattr(s, "rba_watermark_pct", None), "%"),
            "disk_queue_pressure_pct": (getattr(s, "ced_pressure_pct", None), "%"),
            "callback_jitter_ewma_ms": (getattr(s, "jitter_ewma_ms", None), "ms"),
            "ring_rejected_frames": (getattr(s, "ring_rejected_frames", None), "frames"),
            "input_overflow_count": (getattr(s, "input_overflow_count", None), "eventos"),
            "xrun_count": (getattr(s, "xrun_count", None), "eventos"),
            "frames_received": (getattr(s, "frames_received", None), "frames"),
            "frames_written": (getattr(s, "frames_written", None), "frames"),
            "discontinuities": (getattr(s, "discontinuity_count", None), "eventos"),
            "stream_alive": (1.0 if getattr(s, "stream_alive", False) else 0.0, "bool"),
            "writer_failed": (1.0 if getattr(s, "writer_failed", False) else 0.0, "bool"),
            "recoveries": (getattr(s, "recovery_count", None), "eventos"),
        }

    def _progress(self):
        s = self.engine.get_status()
        st = getattr(getattr(self.engine, "state", None), "value", "")
        if st != "CAPTURING" or s.paused:
            return None
        return True, int(s.frames_received)

    def _standby_progress(self):
        eng = self.engine
        if not getattr(eng, "standby_active", False):
            return None
        return True, int(getattr(eng, "callbacks_total", 0))

    def _disk_progress(self):
        s = self.engine.get_status()
        st = getattr(getattr(self.engine, "state", None), "value", "")
        if st not in ("CAPTURING", "PAUSED", "DRAINING", "FINALIZING"):
            return None
        pending = int(getattr(getattr(self.engine, "_ced", None), "frame_count", 0) or 0)
        return pending > 0, int(s.frames_written)
