"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — contratos públicos versionados: estados, eventos tipados, trabajos, concesiones de dispositivo, métricas y errores con código.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Orden LA-KRN-LCB-001, Fase 1. Los motores y la interfaz hablan con el
Kernel SOLO por estos tipos: datos inmutables (dataclasses congeladas) y
enumeraciones. Ningún motor importa los módulos internos del planificador,
del monitor ni del coordinador de recuperación (§4).

Versión del contrato: `LCB_API_VERSION` ("MAYOR.MENOR"). Un cambio
incompatible sube MAYOR; agregar campos con valor por defecto sube MENOR.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Mapping, Optional, Tuple

LCB_API_VERSION = "1.0"


# ── Estados del sistema (§3.4) ───────────────────────────────────────────

class SystemState(str, enum.Enum):
    INICIALIZANDO = "INICIALIZANDO"
    LISTO = "LISTO"
    CAPTURANDO = "CAPTURANDO"
    REPRODUCIENDO = "REPRODUCIENDO"
    PAUSADO = "PAUSADO"
    DETENIENDO = "DETENIENDO"
    DRENANDO = "DRENANDO"
    FINALIZANDO = "FINALIZANDO"
    DEGRADADO = "DEGRADADO"
    ERROR = "ERROR"


class Command(str, enum.Enum):
    """Órdenes que la interfaz o un motor piden al sistema; cada una se
    valida contra el estado actual antes de aceptarse."""
    START_CAPTURE = "START_CAPTURE"
    PAUSE_CAPTURE = "PAUSE_CAPTURE"
    RESUME_CAPTURE = "RESUME_CAPTURE"
    STOP_CAPTURE = "STOP_CAPTURE"
    START_PLAYBACK = "START_PLAYBACK"
    STOP_PLAYBACK = "STOP_PLAYBACK"
    EXPORT = "EXPORT"
    CHANGE_DEVICE = "CHANGE_DEVICE"
    ACKNOWLEDGE_ERROR = "ACKNOWLEDGE_ERROR"


# ── Trabajos (§3.1) ──────────────────────────────────────────────────────

class JobClass(enum.IntEnum):
    """Clase de criticidad (menor = más urgente). La captura y la
    reproducción NO son trabajos del planificador: corren en sus propios
    hilos de tiempo real; el Kernel solo las protege."""
    INTERACTIVE = 1      # respuesta a la interfaz (sondas cortas, miniaturas visibles)
    EXPORT = 2           # exportación en streaming
    ANALYSIS = 3         # onda, espectro, normalización previa
    MAINTENANCE = 4      # limpieza, diagnósticos, compactación de logs


class JobState(str, enum.Enum):
    PENDING = "PENDING"            # aceptado, esperando turno o dependencias
    RUNNING = "RUNNING"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"

    @property
    def terminal(self) -> bool:
        return self in (JobState.SUCCEEDED, JobState.FAILED, JobState.CANCELLED,
                        JobState.REJECTED)


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 1          # 1 = sin reintento
    backoff_s: float = 0.5         # espera antes del reintento k: backoff_s * 2**(k-1)


@dataclass(frozen=True)
class JobSpec:
    """Pedido de trabajo. `fn(ctx)` recibe un `JobContext` y debe consultar
    `ctx.cancelled` en sus puntos seguros (cancelación cooperativa)."""
    name: str
    owner: str                      # motor propietario ("export", "waveform", ...)
    fn: Any
    job_class: JobClass = JobClass.ANALYSIS
    depends_on: Tuple[str, ...] = ()
    cancellable: bool = True
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    deadline_s: Optional[float] = None   # plazo informativo (alerta si se excede)


@dataclass(frozen=True)
class JobTicket:
    job_id: str
    accepted: bool
    state: JobState
    reason: str = ""


@dataclass(frozen=True)
class JobInfo:
    job_id: str
    name: str
    owner: str
    job_class: JobClass
    state: JobState
    created_ns: int
    started_ns: Optional[int]
    finished_ns: Optional[int]
    attempts: int
    progress: Optional[float]
    error: str = ""
    cancellable: bool = True
    depends_on: Tuple[str, ...] = ()


@dataclass(frozen=True)
class CancelResult:
    job_id: str
    state: JobState
    accepted: bool
    reason: str = ""


# ── Dispositivos (§3.2) ──────────────────────────────────────────────────

class Direction(str, enum.Enum):
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"


@dataclass(frozen=True)
class DeviceInfo:
    """Lo que el backend informa de un dispositivo. Un dato que el backend
    no da queda en None y su nombre aparece en `unknown` (no se inventa)."""
    device_id: str                  # estable: "<host api>::<nombre>"
    index: Optional[int]            # índice del backend (NO estable entre reinicios)
    name: str
    host_api: Optional[str]
    max_input_channels: Optional[int]
    max_output_channels: Optional[int]
    default_samplerate: Optional[float]
    connected: bool = True
    is_default_input: bool = False
    is_default_output: bool = False
    unknown: Tuple[str, ...] = ()


@dataclass(frozen=True)
class DeviceRequest:
    owner: str                      # "capture", "monitor", "playback", "wind_scan", "tau"
    direction: Direction
    device_id: Optional[str] = None  # None = dispositivo por defecto del backend
    channels: int = 2
    samplerate: int = 48000
    dtype: str = "float32"


class LeaseState(str, enum.Enum):
    ACTIVE = "ACTIVE"
    LOST = "LOST"                   # el dispositivo desapareció mientras estaba concedido
    RELEASED = "RELEASED"


@dataclass(frozen=True)
class DeviceLease:
    lease_id: str
    owner: str
    direction: Direction
    device_id: str
    index: Optional[int]
    channels: int
    samplerate: int
    dtype: str
    state: LeaseState
    granted_ns: int


# ── Salud (§3.3) ─────────────────────────────────────────────────────────

class HealthLevel(str, enum.Enum):
    """De menos a más exigente: el proceso responde (ALIVE), los contadores
    avanzan (PROGRESSING), se cumplen los umbrales (HEALTHY). DEGRADED: hay
    un riesgo detectado y sostenido."""
    UNKNOWN = "UNKNOWN"
    ALIVE = "ALIVE"
    PROGRESSING = "PROGRESSING"
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"


@dataclass(frozen=True)
class Metric:
    """Una medición con unidad, fuente y hora monotónica. `value` None =
    no disponible en esta plataforma (nunca un valor de relleno)."""
    name: str
    value: Optional[float]
    unit: str
    source: str
    t_ns: int


@dataclass(frozen=True)
class HealthAlert:
    subsystem: str
    metric: str
    value: Optional[float]
    threshold: float
    unit: str
    t_ns: int
    detail: str = ""


# ── Eventos (§7 subscribe_events) ────────────────────────────────────────

class EventKind(str, enum.Enum):
    STATE_CHANGED = "STATE_CHANGED"
    COMMAND_REJECTED = "COMMAND_REJECTED"
    JOB_SUBMITTED = "JOB_SUBMITTED"
    JOB_STARTED = "JOB_STARTED"
    JOB_FINISHED = "JOB_FINISHED"
    JOB_RETRY = "JOB_RETRY"
    DEVICE_LEASED = "DEVICE_LEASED"
    DEVICE_RELEASED = "DEVICE_RELEASED"
    DEVICE_LOST = "DEVICE_LOST"
    DEVICE_CONFLICT = "DEVICE_CONFLICT"
    INVENTORY_CHANGED = "INVENTORY_CHANGED"
    HEALTH_ALERT = "HEALTH_ALERT"
    HEALTH_CLEARED = "HEALTH_CLEARED"
    HEALTH_LEVEL = "HEALTH_LEVEL"
    FAULT = "FAULT"
    ENGINE_ISOLATED = "ENGINE_ISOLATED"
    SAFE_STOP_STEP = "SAFE_STOP_STEP"
    SAFE_STOP_DONE = "SAFE_STOP_DONE"


@dataclass(frozen=True)
class Event:
    seq: int
    kind: EventKind
    t_ns: int                       # hora monotónica
    source: str
    data: Mapping[str, Any] = field(default_factory=dict)


# ── Fallos y recuperación (§3.4) ─────────────────────────────────────────

class FaultKind(str, enum.Enum):
    AUX_ENGINE_FAILURE = "AUX_ENGINE_FAILURE"      # motor auxiliar (onda, TAU, telemetría, export)
    AUDIO_INPUT_FAILURE = "AUDIO_INPUT_FAILURE"    # stream de entrada muerto
    OVERFLOW_UNRECOVERABLE = "OVERFLOW_UNRECOVERABLE"
    DEVICE_LOST = "DEVICE_LOST"
    CORRUPTION_RISK = "CORRUPTION_RISK"            # fallo de escritura, disco lleno, permiso
    EXPORT_FAILURE = "EXPORT_FAILURE"


class SafeStopStep(str, enum.Enum):
    DETENER = "DETENER"
    DRENAR = "DRENAR"
    SINCRONIZAR = "SINCRONIZAR"
    CERRAR = "CERRAR"
    VERIFICAR = "VERIFICAR"


@dataclass(frozen=True)
class SafeStopReport:
    reason: str
    steps: Tuple[Tuple[str, bool, str], ...]     # (paso, ok, detalle)
    complete: bool
    verified: bool
    started_ns: int
    finished_ns: int


# ── Instantánea del sistema (§7 get_system_snapshot) ─────────────────────

@dataclass(frozen=True)
class SystemSnapshot:
    api_version: str
    seq: int                         # versión temporal: sube en cada cambio publicado
    t_ns: int
    state: SystemState
    health: HealthLevel
    metrics: Tuple[Metric, ...]
    alerts: Tuple[HealthAlert, ...]
    jobs: Tuple[JobInfo, ...]
    leases: Tuple[DeviceLease, ...]
    isolated_engines: Tuple[str, ...]
    events_dropped: int
    last_safe_stop: Optional[SafeStopReport] = None


@dataclass(frozen=True)
class Capabilities:
    api_version: str
    audio_backend: Optional[str]
    audio_backend_version: Optional[str]
    device_count: Optional[int]
    cpu_count: Optional[int]
    workers: int
    metrics_available: Tuple[str, ...]
    metrics_unavailable: Tuple[str, ...]
    warnings: Tuple[str, ...] = ()


# ── Errores tipados ──────────────────────────────────────────────────────

class KernelError(Exception):
    """Base de los errores del Kernel. `code` es estable y documentado."""
    code = "LCB_ERROR"

    def __init__(self, message: str, **detail):
        super().__init__(message)
        self.detail = detail


class InvalidConfigError(KernelError):
    code = "LCB_INVALID_CONFIG"


class IllegalCommandError(KernelError):
    code = "LCB_ILLEGAL_COMMAND"


class DeviceNotFoundError(KernelError):
    code = "LCB_DEVICE_NOT_FOUND"


class DeviceBusyError(KernelError):
    code = "LCB_DEVICE_BUSY"


class DeviceIncompatibleError(KernelError):
    code = "LCB_DEVICE_INCOMPATIBLE"


class BackendUnavailableError(KernelError):
    code = "LCB_BACKEND_UNAVAILABLE"


class UnknownJobError(KernelError):
    code = "LCB_UNKNOWN_JOB"


class NotInitializedError(KernelError):
    code = "LCB_NOT_INITIALIZED"


ERROR_CODES = {cls.code: cls for cls in (
    KernelError, InvalidConfigError, IllegalCommandError, DeviceNotFoundError,
    DeviceBusyError, DeviceIncompatibleError, BackendUnavailableError,
    UnknownJobError, NotInitializedError)}
