"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — administrador de dispositivos de audio: inventario sin datos inventados, concesiones explícitas por dirección, validación previa y detección de pérdida sin conmutar nunca en silencio.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


§3.2 de la orden. Una sola autoridad de asignación dentro de la aplicación.

**Identidad.** PortAudio numera los dispositivos con un índice que cambia
al reiniciar la biblioteca o al conectar otro equipo. El identificador
estable es `"<host api>::<nombre>"`; el índice se guarda aparte y solo
como dato del momento.

**Concesión (lease).** Un motor pide `DeviceRequest(owner, dirección,
dispositivo, canales, frecuencia, formato)` y recibe un `DeviceLease` o un
error tipado:

- **Exclusiva por dispositivo y dirección.** No se asume que un dispositivo
  admita varias corrientes independientes a la vez (§3.2). Otro dueño
  recibe `DeviceBusyError` y se publica DEVICE_CONFLICT.
- **Idempotente.** El mismo dueño con el mismo pedido recibe la misma
  concesión; con otro formato, debe liberarla antes (sin reaperturas
  dobles dentro de la aplicación).
- **Validación previa.** Antes de conceder, se comprueba con el backend
  (`check_input_settings` / `check_output_settings` de sounddevice) que
  el formato se puede abrir. Si el backend no ofrece la comprobación, se
  valida contra los canales y la frecuencia por defecto informados.
- **Sin vencimiento por tiempo.** Las concesiones de Gray y Cheriton
  vencen solas; aquí no, a propósito: una captura archivística puede
  durar 50 h y una concesión que vence en medio sería justo la
  conmutación silenciosa que la orden prohíbe. Se libera de forma
  explícita, o queda LOST si el dispositivo desaparece.

**Pérdida.** `refresh()` relee el inventario. Si un dispositivo concedido
ya no está, su concesión pasa a LOST y se publica DEVICE_LOST. El Kernel
nunca elige otro dispositivo por su cuenta. La lista de PortAudio solo se
actualiza al reiniciar la biblioteca, y eso cerraría las corrientes
abiertas; por eso `refresh(reinit=True)` se rechaza mientras haya
concesiones activas. Durante una captura, la muerte del dispositivo la
detecta el vigilante del motor (sin callbacks) y llega por
`report_stream_failure()`.
"""

from __future__ import annotations

import itertools
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple

from lorito_aldhiro.backend.kernel.lcb_contracts import (
    BackendUnavailableError, DeviceBusyError, DeviceIncompatibleError, DeviceInfo,
    DeviceLease, DeviceNotFoundError, DeviceRequest, Direction, EventKind, LeaseState,
)


def _get(d, key):
    try:
        return d[key]
    except Exception:
        return getattr(d, key, None)


class AudioDeviceManager:
    def __init__(self, backend_provider: Callable[[], object],
                 publish: Optional[Callable] = None, clock=time.monotonic_ns):
        self._backend_provider = backend_provider
        self._publish = publish or (lambda *a, **k: None)
        self._clock = clock
        self._lock = threading.RLock()
        self._inventory: Dict[str, DeviceInfo] = {}
        self._leases: Dict[str, DeviceLease] = {}
        self._ids = itertools.count(1)
        self.inventory_error = ""

    # ── inventario ───────────────────────────────────────────────────────
    def _backend(self):
        sd = self._backend_provider()
        if sd is None or not hasattr(sd, "query_devices"):
            raise BackendUnavailableError("no hay backend de audio (sounddevice/PortAudio)")
        return sd

    def _read_inventory(self, sd) -> Dict[str, DeviceInfo]:
        raw = sd.query_devices()
        try:
            hostapis = sd.query_hostapis()
        except Exception:
            hostapis = None
        try:
            default = getattr(sd, "default", None)
            dev = getattr(default, "device", None) if default is not None else None
            def_in, def_out = (dev[0], dev[1]) if dev is not None else (None, None)
        except Exception:
            def_in, def_out = None, None
        out: Dict[str, DeviceInfo] = {}
        for pos, d in enumerate(list(raw) if raw is not None else []):
            idx = _get(d, "index")
            idx = pos if idx is None else idx
            name = _get(d, "name")
            ha_idx = _get(d, "hostapi")
            ha_name = None
            if hostapis is not None and ha_idx is not None:
                try:
                    ha_name = _get(hostapis[ha_idx], "name")
                except Exception:
                    ha_name = None
            unknown = []
            fields = {}
            for key in ("max_input_channels", "max_output_channels", "default_samplerate"):
                v = _get(d, key)
                if v is None:
                    unknown.append(key)
                fields[key] = v
            if ha_name is None:
                unknown.append("host_api")
            if name is None:
                unknown.append("name")
            dev_id = f"{ha_name or '?'}::{name or f'#{idx}'}"
            # Dos dispositivos con el mismo nombre en la misma API: se
            # desambiguan por orden de aparición (estable entre lecturas).
            base, k = dev_id, 2
            while dev_id in out:
                dev_id = f"{base}#{k}"
                k += 1
            out[dev_id] = DeviceInfo(
                device_id=dev_id, index=idx, name=str(name) if name is not None else f"#{idx}",
                host_api=ha_name,
                max_input_channels=fields["max_input_channels"],
                max_output_channels=fields["max_output_channels"],
                default_samplerate=fields["default_samplerate"],
                connected=True,
                is_default_input=(def_in is not None and def_in == idx),
                is_default_output=(def_out is not None and def_out == idx),
                unknown=tuple(unknown))
        return out

    def list_devices(self, refresh: bool = False) -> List[DeviceInfo]:
        if refresh or not self._inventory:
            self.refresh()
        with self._lock:
            return list(self._inventory.values())

    def refresh(self, reinit: bool = False) -> List[str]:
        """Relee el inventario. Devuelve los ids de concesiones que
        quedaron LOST. `reinit=True` reinicia PortAudio para ver equipos
        nuevos: solo sin concesiones activas."""
        sd = self._backend()
        with self._lock:
            if reinit:
                if any(l.state == LeaseState.ACTIVE for l in self._leases.values()):
                    raise DeviceBusyError("no se reinicia el backend con dispositivos concedidos")
                term, init = getattr(sd, "_terminate", None), getattr(sd, "_initialize", None)
                if term and init:
                    term()
                    init()
            try:
                new = self._read_inventory(sd)
                self.inventory_error = ""
            except Exception as e:
                self.inventory_error = f"{type(e).__name__}: {e}"
                raise BackendUnavailableError(f"no se pudo leer el inventario: {e}")
            old_ids = set(self._inventory)
            self._inventory = new
            lost = []
            for lid, lease in list(self._leases.items()):
                if lease.state == LeaseState.ACTIVE and lease.device_id not in new:
                    self._leases[lid] = self._with_state(lease, LeaseState.LOST)
                    lost.append(lid)
        if set(new) != old_ids and old_ids:
            self._publish(EventKind.INVENTORY_CHANGED, "devices",
                          {"added": sorted(set(new) - old_ids),
                           "removed": sorted(old_ids - set(new))})
        for lid in lost:
            l = self._leases[lid]
            self._publish(EventKind.DEVICE_LOST, "devices",
                          {"lease_id": lid, "owner": l.owner, "device_id": l.device_id,
                           "direction": l.direction.value})
        return lost

    # ── concesiones ──────────────────────────────────────────────────────
    @staticmethod
    def _with_state(lease: DeviceLease, state: LeaseState) -> DeviceLease:
        return DeviceLease(lease.lease_id, lease.owner, lease.direction, lease.device_id,
                           lease.index, lease.channels, lease.samplerate, lease.dtype,
                           state, lease.granted_ns)

    def _resolve(self, req: DeviceRequest) -> DeviceInfo:
        if not self._inventory:
            self.refresh()
        with self._lock:
            if req.device_id is not None:
                info = self._inventory.get(req.device_id)
                if info is None:
                    raise DeviceNotFoundError(f"dispositivo {req.device_id!r} no está conectado",
                                              device_id=req.device_id)
                return info
            flag = "is_default_input" if req.direction == Direction.INPUT else "is_default_output"
            for info in self._inventory.values():
                if getattr(info, flag):
                    return info
            key = "max_input_channels" if req.direction == Direction.INPUT \
                else "max_output_channels"
            for info in self._inventory.values():
                if (getattr(info, key) or 0) > 0:
                    return info
        raise DeviceNotFoundError(f"no hay dispositivo de {req.direction.value.lower()}")

    def _validate(self, req: DeviceRequest, info: DeviceInfo) -> None:
        max_ch = (info.max_input_channels if req.direction == Direction.INPUT
                  else info.max_output_channels)
        if max_ch is not None and req.channels > max_ch:
            raise DeviceIncompatibleError(
                f"{info.name}: pide {req.channels} canales, admite {max_ch}",
                device_id=info.device_id)
        sd = self._backend()
        check = getattr(sd, "check_input_settings" if req.direction == Direction.INPUT
                        else "check_output_settings", None)
        if check is None:
            return
        try:
            check(device=info.index, channels=req.channels, dtype=req.dtype,
                  samplerate=req.samplerate)
        except Exception as e:
            raise DeviceIncompatibleError(f"{info.name}: {e}", device_id=info.device_id)

    def acquire(self, req: DeviceRequest) -> DeviceLease:
        info = self._resolve(req)
        with self._lock:
            for lease in self._leases.values():
                if (lease.state == LeaseState.ACTIVE and lease.device_id == info.device_id
                        and lease.direction == req.direction):
                    same = (lease.owner == req.owner and lease.channels == req.channels
                            and lease.samplerate == req.samplerate and lease.dtype == req.dtype)
                    if same:
                        return lease                       # idempotente
                    if lease.owner == req.owner:
                        raise DeviceBusyError(
                            f"{req.owner} ya tiene {info.name} con otro formato: liberar antes",
                            lease_id=lease.lease_id)
                    self._publish(EventKind.DEVICE_CONFLICT, "devices",
                                  {"device_id": info.device_id, "holder": lease.owner,
                                   "requester": req.owner, "direction": req.direction.value})
                    raise DeviceBusyError(
                        f"{info.name} ({req.direction.value.lower()}) está concedido a "
                        f"{lease.owner}", holder=lease.owner, lease_id=lease.lease_id)
        self._validate(req, info)
        with self._lock:
            lease = DeviceLease(f"lease-{next(self._ids)}", req.owner, req.direction,
                                info.device_id, info.index, req.channels, req.samplerate,
                                req.dtype, LeaseState.ACTIVE, self._clock())
            self._leases[lease.lease_id] = lease
        self._publish(EventKind.DEVICE_LEASED, "devices",
                      {"lease_id": lease.lease_id, "owner": lease.owner,
                       "device_id": lease.device_id, "direction": lease.direction.value,
                       "channels": lease.channels, "samplerate": lease.samplerate})
        return lease

    def release(self, lease_id: str) -> bool:
        """Idempotente: False si ya estaba liberada o no existe."""
        with self._lock:
            lease = self._leases.get(lease_id)
            if lease is None or lease.state == LeaseState.RELEASED:
                return False
            self._leases[lease_id] = self._with_state(lease, LeaseState.RELEASED)
        self._publish(EventKind.DEVICE_RELEASED, "devices",
                      {"lease_id": lease_id, "owner": lease.owner,
                       "device_id": lease.device_id})
        return True

    def release_owner(self, owner: str) -> int:
        with self._lock:
            ids = [l.lease_id for l in self._leases.values()
                   if l.owner == owner and l.state != LeaseState.RELEASED]
        return sum(1 for lid in ids if self.release(lid))

    def lease_of(self, owner: str, direction: Direction) -> Optional[DeviceLease]:
        with self._lock:
            for l in self._leases.values():
                if l.owner == owner and l.direction == direction \
                        and l.state != LeaseState.RELEASED:
                    return l
        return None

    def mark_lost(self, owner: str, direction: Direction, detail: str) -> Optional[DeviceLease]:
        """El motor dueño informa que su corriente murió (sin callbacks):
        la concesión queda LOST y no se reemplaza por otro dispositivo."""
        with self._lock:
            lease = self.lease_of(owner, direction)
            if lease is None or lease.state != LeaseState.ACTIVE:
                return lease
            lease = self._with_state(lease, LeaseState.LOST)
            self._leases[lease.lease_id] = lease
        self._publish(EventKind.DEVICE_LOST, "devices",
                      {"lease_id": lease.lease_id, "owner": owner,
                       "device_id": lease.device_id, "direction": direction.value,
                       "detail": detail})
        return lease

    def leases(self, include_released: bool = False) -> Tuple[DeviceLease, ...]:
        with self._lock:
            return tuple(l for l in self._leases.values()
                         if include_released or l.state != LeaseState.RELEASED)
