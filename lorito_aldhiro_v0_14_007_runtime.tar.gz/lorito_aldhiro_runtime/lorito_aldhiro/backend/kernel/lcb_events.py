"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — canal de eventos tipados que nunca bloquea al que publica: cada suscriptor tiene su cola acotada y cuenta lo que pierde.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


`subscribe_events()` (§7): publicar es O(suscriptores) con un lock corto y
sin esperas. Un consumidor lento no frena a nadie: su cola es acotada y,
si se llena, se descarta el evento MÁS VIEJO y se cuenta en `dropped`
(nunca una pérdida silenciosa). El consumidor drena desde su propio hilo
(`poll()`), por ejemplo la interfaz con un temporizador Qt en el hilo GUI:
el Kernel jamás llama código de la interfaz.

Nadie publica desde el callback de audio: los motores avisan al Kernel
desde sus hilos de trabajo.
"""

from __future__ import annotations

import itertools
import threading
import time
from collections import deque
from typing import List, Mapping, Optional

from lorito_aldhiro.backend.kernel.lcb_contracts import Event, EventKind


class Subscription:
    """Cola acotada de un consumidor. `poll()` devuelve y retira eventos."""

    def __init__(self, bus: "EventBus", name: str, capacity: int,
                 kinds: Optional[frozenset]):
        self._bus = bus
        self.name = name
        self.capacity = capacity
        self.kinds = kinds
        self._q: deque = deque()
        self._lock = threading.Lock()
        self.dropped = 0
        self.delivered = 0
        self.closed = False

    def _offer(self, ev: Event) -> None:
        if self.kinds is not None and ev.kind not in self.kinds:
            return
        with self._lock:
            if len(self._q) >= self.capacity:
                self._q.popleft()
                self.dropped += 1
            self._q.append(ev)

    def poll(self, max_events: int = 256) -> List[Event]:
        with self._lock:
            n = min(max_events, len(self._q))
            out = [self._q.popleft() for _ in range(n)]
        self.delivered += len(out)
        return out

    def pending(self) -> int:
        return len(self._q)

    def close(self) -> None:
        self.closed = True
        self._bus._remove(self)


class EventBus:
    def __init__(self, clock=time.monotonic_ns, history: int = 512):
        self._clock = clock
        self._subs: List[Subscription] = []
        self._lock = threading.Lock()
        self._seq = itertools.count(1)
        self._history: deque = deque(maxlen=history)
        self.published = 0

    def subscribe(self, name: str = "", capacity: int = 1024,
                  kinds=None) -> Subscription:
        sub = Subscription(self, name, max(1, int(capacity)),
                           frozenset(kinds) if kinds is not None else None)
        with self._lock:
            self._subs.append(sub)
        return sub

    def _remove(self, sub: Subscription) -> None:
        with self._lock:
            if sub in self._subs:
                self._subs.remove(sub)

    def publish(self, kind: EventKind, source: str,
                data: Optional[Mapping] = None) -> Event:
        ev = Event(seq=next(self._seq), kind=kind, t_ns=self._clock(), source=source,
                   data=dict(data or {}))
        with self._lock:
            subs = list(self._subs)
            self._history.append(ev)
            self.published += 1
        for s in subs:
            s._offer(ev)
        return ev

    def history(self) -> List[Event]:
        with self._lock:
            return list(self._history)

    def dropped_total(self) -> int:
        with self._lock:
            return sum(s.dropped for s in self._subs)
