"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — monitor de salud: métricas con unidad, fuente y hora monotónica; vivo, progresando, saludable o degradado; umbrales con ventana para no alarmar en falso.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


§3.3 de la orden. El muestreo corre en un hilo propio ("lorito-lcb-health"), uno solo para
todo el proceso aunque haya varios Kernels, fuera de la ruta crítica:

- Las sondas solo LEEN contadores ya publicados por los motores (campos
  atómicos del estado de captura, estadísticas del planificador). Nunca
  toman un lock del audio ni piden nada al callback.
- Las fuentes del sistema son baratas: `time.process_time()`,
  `/proc/self/statm`, `/proc/pressure/*` y `shutil.disk_usage`.

**Disponibilidad.** Una métrica que la plataforma no ofrece sale con
`value=None` y queda listada como no disponible; nunca se rellena. La
temperatura se lee de `/sys/class/thermal` solo si existe.

**Niveles.**

| Nivel | Condición |
|---|---|
| ALIVE | El muestreo corre. |
| PROGRESSING | Lo que debe avanzar avanza: frames recibidos y escritos durante una captura no pausada. |
| HEALTHY | Además, ninguna alerta activa. |
| DEGRADED | Alguna alerta activa (riesgo sostenido). |

**Umbrales con ventana.** Una alerta se levanta cuando la condición se
cumple en `raise_after` muestras seguidas y se retira tras `clear_after`
muestras seguidas sin cumplirse. Así un pico aislado no dispara alarmas
espurias. Cada alerta registra el valor, el umbral, la hora monotónica y el
subsistema.

**Umbrales iniciales.** Son provisionales: la orden fija los definitivos
tras la línea base medida en los equipos de destino (§9.2). Se configuran
con `KernelConfig.thresholds`.
"""

from __future__ import annotations

import glob
import os
import shutil
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple

from lorito_aldhiro.backend.core.lorito_identity import thread_name
from lorito_aldhiro.backend.kernel.lcb_contracts import (
    EventKind, HealthAlert, HealthLevel, Metric,
)


@dataclass(frozen=True)
class Threshold:
    subsystem: str
    metric: str
    op: str                 # ">" o "<"
    limit: float
    unit: str
    raise_after: int = 3
    clear_after: int = 3
    only_when: str = ""     # "capture": solo con captura activa

    def breached(self, value: Optional[float]) -> bool:
        if value is None:
            return False
        return value > self.limit if self.op == ">" else value < self.limit


# Provisionales (ver docstring). Valor, umbral y unidad quedan en la alerta.
DEFAULT_THRESHOLDS: Tuple[Threshold, ...] = (
    Threshold("capture", "ring_watermark_pct", ">", 60.0, "%", only_when="capture"),
    Threshold("capture", "disk_queue_pressure_pct", ">", 80.0, "%", only_when="capture"),
    Threshold("capture", "callback_jitter_ewma_ms", ">", 30.0, "ms", only_when="capture"),
    Threshold("capture", "ring_rejected_frames", ">", 0.0, "frames", raise_after=1,
              only_when="capture"),
    Threshold("capture", "input_overflow_count", ">", 0.0, "eventos", raise_after=1,
              only_when="capture"),
    Threshold("storage", "disk_free_mb", "<", 2048.0, "MB"),
    # Crecimiento, no tamaño absoluto: lo que importa en una sesión de 50 h
    # es la fuga. El tamaño base depende del equipo y de las bibliotecas.
    Threshold("process", "rss_growth_mb", ">", 512.0, "MB", raise_after=5),
    Threshold("system", "psi_io_some_avg10_pct", ">", 40.0, "%"),
    Threshold("system", "psi_memory_some_avg10_pct", ">", 20.0, "%"),
)


def _read_psi(resource: str) -> Optional[float]:
    try:
        with open(f"/proc/pressure/{resource}") as f:
            for line in f:
                if line.startswith("some"):
                    for part in line.split():
                        if part.startswith("avg10="):
                            return float(part[6:])
    except (OSError, ValueError):
        return None
    return None


def _read_rss_mb() -> Optional[float]:
    try:
        with open("/proc/self/statm") as f:
            pages = int(f.read().split()[1])
        return pages * os.sysconf("SC_PAGE_SIZE") / (1024.0 * 1024.0)
    except (OSError, ValueError, IndexError, AttributeError):
        return None


def _read_temperature_c() -> Optional[float]:
    """Máxima de las zonas térmicas, si el sistema las expone."""
    temps = []
    for path in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            with open(path) as f:
                temps.append(int(f.read().strip()) / 1000.0)
        except (OSError, ValueError):
            continue
    return max(temps) if temps else None


Probe = Callable[[], Dict[str, Tuple[Optional[float], str]]]


# ── Lecturas del proceso y del sistema, compartidas ──────────────────────
# Son del PROCESO, no de cada Kernel: se leen una vez por ciclo (caché de
# 200 ms) aunque haya varios monitores vivos (p. ej. varias ventanas).
_SYS_LOCK = threading.Lock()
_SYS_CACHE: Dict[str, object] = {"t": 0.0}


def _shared_readings() -> Dict[str, Optional[float]]:
    now = time.monotonic()
    with _SYS_LOCK:
        if now - float(_SYS_CACHE["t"]) > 0.2:
            _SYS_CACHE.update({
                "t": now, "rss": _read_rss_mb(), "temp": _read_temperature_c(),
                "psi_cpu": _read_psi("cpu"), "psi_io": _read_psi("io"),
                "psi_memory": _read_psi("memory")})
        return dict(_SYS_CACHE)


class _SharedSampler:
    """Un solo hilo "lorito-lcb-health" para todos los monitores vivos del
    proceso. Los guarda en un registro débil: un monitor que ya nadie usa
    deja de muestrearse, y el hilo termina cuando no queda ninguno."""

    MAX_WAIT_S = 1.0
    BATCH_S = 0.25        # a lo sumo 4 despertares por segundo, con muchos monitores

    def __init__(self):
        import weakref
        self._monitors = weakref.WeakSet()
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._wake = threading.Event()

    def add(self, mon: "HealthMonitor") -> None:
        with self._lock:
            self._monitors.add(mon)
            self._wake.set()
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._loop, daemon=True,
                                                name=thread_name("lcb-health"))
                self._thread.start()

    def remove(self, mon: "HealthMonitor") -> None:
        with self._lock:
            self._monitors.discard(mon)
        self._wake.set()

    def alive(self) -> bool:
        t = self._thread
        return t is not None and t.is_alive()

    def _loop(self) -> None:
        wait = 0.0
        while True:
            # Duerme hasta la próxima muestra que vence (sin despertares de
            # más: cada despertar compite por el GIL con el audio).
            self._wake.wait(wait)
            self._wake.clear()
            with self._lock:
                mons = list(self._monitors)
                if not mons:
                    self._thread = None
                    return
            now = time.monotonic()
            next_due = now + self.MAX_WAIT_S
            # Se muestrea todo lo que vence dentro de la ventana del lote: un
            # solo despertar para varios monitores (cada despertar pide el GIL).
            horizon = now + min(self.BATCH_S, min(m.period_s for m in mons) / 2)
            for m in mons:
                if m._next_due <= horizon:
                    m._next_due = now + m.current_period()
                    try:
                        m.sample()
                    except Exception:
                        m.probe_failures += 1
                next_due = min(next_due, m._next_due)
            wait = max(min(self.BATCH_S, min(m.period_s for m in mons) / 2),
                       next_due - time.monotonic())
            del mons, m


_SAMPLER = _SharedSampler()


class HealthMonitor:
    def __init__(self, publish: Optional[Callable] = None, period_s: float = 1.0,
                 thresholds: Tuple[Threshold, ...] = DEFAULT_THRESHOLDS,
                 storage_path: Optional[str] = None, clock=time.monotonic_ns,
                 stall_after: int = 3, idle_period_s: Optional[float] = None):
        self.period_s = float(period_s)
        # Período en reposo (0.14.007): sin actividad de audio ni alertas, se
        # muestrea menos (5 s). `is_idle()` lo provee el Kernel.
        self.idle_period_s = float(idle_period_s if idle_period_s is not None else period_s)
        self.is_idle: Callable[[], bool] = lambda: False
        self.thresholds = tuple(thresholds)
        self.storage_path = storage_path
        self._publish = publish or (lambda *a, **k: None)
        self._clock = clock
        self._probes: Dict[str, Probe] = {}
        self._progress: Dict[str, Callable[[], Optional[Tuple[bool, int]]]] = {}
        self._lock = threading.Lock()
        self._metrics: Tuple[Metric, ...] = ()
        self._alerts: Dict[Tuple[str, str], HealthAlert] = {}
        self._streak: Dict[Tuple[str, str], int] = {}
        self._clear_streak: Dict[Tuple[str, str], int] = {}
        self._last_progress: Dict[str, int] = {}
        self._stalled: Dict[str, bool] = {}
        self._stall_streak: Dict[str, int] = {}
        self.stall_after = max(1, int(stall_after))
        self._level = HealthLevel.UNKNOWN
        self._last_sample_ns = 0
        self._cpu_prev: Optional[Tuple[float, int]] = None
        self._rss_base: Optional[float] = None
        self._active = False
        self._next_due = 0.0
        self.samples = 0
        self.sample_cost_ns_max = 0
        self.probe_failures = 0

    # ── registro ─────────────────────────────────────────────────────────
    def register_probe(self, subsystem: str, probe: Probe) -> None:
        """`probe()` → {métrica: (valor o None, unidad)}. Debe ser barata y
        no bloquear (solo leer contadores)."""
        self._probes[subsystem] = probe

    def register_progress(self, subsystem: str,
                          fn: Callable[[], Optional[Tuple[bool, int]]]) -> None:
        """`fn()` → (debe_avanzar, contador) o None. Si debe avanzar y el
        contador no cambió entre dos muestras, el subsistema no progresa."""
        self._progress[subsystem] = fn

    # ── ciclo ────────────────────────────────────────────────────────────
    def start(self) -> None:
        if self._active:
            return
        self._active = True
        self._next_due = time.monotonic() + self.period_s
        _SAMPLER.add(self)

    def stop(self, timeout: float = 5.0) -> None:
        self._active = False
        _SAMPLER.remove(self)

    def wake(self) -> None:
        """Muestra cuanto antes (p. ej. al empezar una captura, sin esperar
        el período de reposo)."""
        self._next_due = time.monotonic()
        _SAMPLER._wake.set()

    def current_period(self) -> float:
        try:
            idle = bool(self.is_idle()) and not self._alerts
        except Exception:
            idle = False
        return self.idle_period_s if idle else self.period_s

    @property
    def running(self) -> bool:
        return self._active and _SAMPLER.alive()

    # ── muestreo ─────────────────────────────────────────────────────────
    def _system_metrics(self, now: int) -> List[Metric]:
        out = []
        cpu_now = time.process_time()
        if self._cpu_prev is not None:
            dc = cpu_now - self._cpu_prev[0]
            dt = (now - self._cpu_prev[1]) / 1e9
            pct = (dc / dt * 100.0) if dt > 0 else None
        else:
            pct = None
        self._cpu_prev = (cpu_now, now)
        out.append(Metric("cpu_process_pct", pct, "% de un núcleo", "time.process_time", now))
        sh = _shared_readings()
        rss = sh["rss"]
        if rss is not None and self._rss_base is None:
            self._rss_base = rss
        out.append(Metric("rss_mb", rss, "MB", "/proc/self/statm", now))
        out.append(Metric("rss_growth_mb",
                          None if rss is None or self._rss_base is None else rss - self._rss_base,
                          "MB", "/proc/self/statm (desde el arranque del Kernel)", now))
        for res in ("cpu", "io", "memory"):
            out.append(Metric(f"psi_{res}_some_avg10_pct", sh[f"psi_{res}"], "%",
                              f"/proc/pressure/{res}", now))
        free = None
        if self.storage_path:
            try:
                path = self.storage_path
                while path and not os.path.exists(path):
                    path = os.path.dirname(path)
                free = shutil.disk_usage(path or "/").free / (1024.0 * 1024.0)
            except OSError:
                free = None
        out.append(Metric("disk_free_mb", free, "MB", "shutil.disk_usage", now))
        out.append(Metric("temperature_c", sh["temp"], "°C",
                          "/sys/class/thermal", now))
        return out

    def sample(self) -> Tuple[Metric, ...]:
        t0 = time.perf_counter_ns()
        now = self._clock()
        metrics = self._system_metrics(now)
        by_sub: Dict[str, Dict[str, Optional[float]]] = {"process": {}, "system": {},
                                                         "storage": {}}
        for m in metrics:
            sub = ("storage" if m.name == "disk_free_mb" else
                   "process" if m.name in ("cpu_process_pct", "rss_mb", "rss_growth_mb")
                   else "system")
            by_sub[sub][m.name] = m.value
        for sub, probe in list(self._probes.items()):
            try:
                values = probe() or {}
            except Exception:
                self.probe_failures += 1
                continue
            for name, (val, unit) in values.items():
                v = None if val is None else float(val)
                metrics.append(Metric(f"{sub}.{name}", v, unit, f"probe:{sub}", now))
                by_sub.setdefault(sub, {})[name] = v
        progressing = True
        for sub, fn in list(self._progress.items()):
            try:
                res = fn()
            except Exception:
                self.probe_failures += 1
                res = None
            if res is None:
                self._last_progress.pop(sub, None)
                self._stalled[sub] = False
                self._stall_streak[sub] = 0
                continue
            must, counter = res
            prev = self._last_progress.get(sub)
            self._last_progress[sub] = counter
            still = bool(must and prev is not None and counter == prev)
            # Sin avance en `stall_after` muestras seguidas (no por una sola).
            self._stall_streak[sub] = self._stall_streak.get(sub, 0) + 1 if still else 0
            stalled = self._stall_streak[sub] >= self.stall_after
            self._stalled[sub] = stalled
            if stalled:
                progressing = False
        capture_active = bool(by_sub.get("capture", {}).get("active"))
        self._evaluate(by_sub, now, capture_active)
        with self._lock:
            self._metrics = tuple(metrics)
            level = (HealthLevel.DEGRADED if self._alerts else
                     HealthLevel.HEALTHY if progressing else HealthLevel.ALIVE)
            changed = level != self._level
            self._level = level
            self._last_sample_ns = now
            self.samples += 1
        if changed:
            self._publish(EventKind.HEALTH_LEVEL, "health",
                          {"level": level.value,
                           "stalled": sorted(s for s, v in self._stalled.items() if v)})
        cost = time.perf_counter_ns() - t0
        self.sample_cost_ns_max = max(self.sample_cost_ns_max, cost)
        return tuple(metrics)

    def _evaluate(self, by_sub, now: int, capture_active: bool) -> None:
        for th in self.thresholds:
            key = (th.subsystem, th.metric)
            if th.only_when == "capture" and not capture_active:
                value = None
            else:
                value = by_sub.get(th.subsystem, {}).get(th.metric)
            if th.breached(value):
                self._clear_streak[key] = 0
                self._streak[key] = self._streak.get(key, 0) + 1
                if key not in self._alerts and self._streak[key] >= th.raise_after:
                    alert = HealthAlert(th.subsystem, th.metric, value, th.limit, th.unit, now,
                                        f"{th.metric} {th.op} {th.limit:g} {th.unit} durante "
                                        f"{th.raise_after} muestras")
                    with self._lock:
                        self._alerts[key] = alert
                    self._publish(EventKind.HEALTH_ALERT, "health",
                                  {"subsystem": th.subsystem, "metric": th.metric,
                                   "value": value, "threshold": th.limit, "unit": th.unit,
                                   "t_ns": now})
            else:
                self._streak[key] = 0
                if key in self._alerts:
                    self._clear_streak[key] = self._clear_streak.get(key, 0) + 1
                    if self._clear_streak[key] >= th.clear_after:
                        with self._lock:
                            self._alerts.pop(key, None)
                        self._publish(EventKind.HEALTH_CLEARED, "health",
                                      {"subsystem": th.subsystem, "metric": th.metric,
                                       "value": value, "t_ns": now})
        # Sin progreso donde debería haberlo (ya filtrado por `stall_after`).
        for sub, stalled in self._stalled.items():
            key = (sub, "progress")
            if stalled and key not in self._alerts:
                alert = HealthAlert(sub, "progress", 0.0, 0.0, "frames/muestra", now,
                                    "los contadores no avanzan")
                with self._lock:
                    self._alerts[key] = alert
                self._publish(EventKind.HEALTH_ALERT, "health",
                              {"subsystem": sub, "metric": "progress", "value": 0,
                               "threshold": 0, "unit": "frames/muestra", "t_ns": now})
            elif not stalled and key in self._alerts:
                with self._lock:
                    self._alerts.pop(key, None)
                self._publish(EventKind.HEALTH_CLEARED, "health",
                              {"subsystem": sub, "metric": "progress", "t_ns": now})

    # ── lectura ──────────────────────────────────────────────────────────
    @property
    def level(self) -> HealthLevel:
        with self._lock:
            if self._last_sample_ns and self.running:
                stale = (self._clock() - self._last_sample_ns) > 3 * self.current_period() * 1e9
                if stale:
                    return HealthLevel.UNKNOWN
            return self._level

    def metrics(self) -> Tuple[Metric, ...]:
        with self._lock:
            return self._metrics

    def alerts(self) -> Tuple[HealthAlert, ...]:
        with self._lock:
            return tuple(self._alerts.values())

    def availability(self) -> Tuple[Tuple[str, ...], Tuple[str, ...]]:
        ms = self.metrics() or tuple(self._system_metrics(self._clock()))
        avail = tuple(m.name for m in ms if m.value is not None)
        missing = tuple(m.name for m in ms if m.value is None)
        return avail, missing
