"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — Kernel coordinador en espacio de usuario: API pública (§7) que une estado del sistema, planificador, dispositivos, salud y recuperación. Coordina; los motores Golden procesan.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Orden LA-KRN-LCB-001. "Kernel" es un núcleo coordinador de la aplicación:
no toca el kernel del sistema operativo ni pide privilegios.

Principio rector: el Kernel coordina y los motores especializados procesan.
Ninguna operación de esta API hace DSP, E/S de audio ni espera al callback.
Todas son cortas:

- las consultas leen instantáneas inmutables;
- las órdenes validan y encolan;
- lo largo (parada segura, trabajos) corre en hilos propios.

API (§7):

| Operación | Resultado |
|---|---|
| `initialize(config)` | Valida la configuración y devuelve `Capabilities`. No inicia ninguna captura. |
| `get_system_snapshot()` | `SystemSnapshot` inmutable con versión (`seq`). |
| `list_audio_devices()` | `DeviceInfo`; lo desconocido va marcado. |
| `acquire_device(request)` / `release_device(lease_id)` | `DeviceLease` o error tipado; idempotentes. |
| `submit_job(spec)` / `cancel_job(job_id)` | `JobTicket` (aceptado o rechazado con motivo) / `CancelResult`. |
| `subscribe_events()` | `Subscription` con cola acotada que no bloquea. |
| `request_safe_stop(reason)` | detener → drenar → sincronizar → cerrar → verificar. |

**Reversión (rollback).** `KernelConfig(enabled=False)` o la variable de
entorno `LORITO_LCB=0` deja el Kernel en modo observador. No arranca
workers ni el monitor, no fija el dispositivo de captura, y los motores
funcionan exactamente como en 0.14.006.
"""

from __future__ import annotations

import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field, replace
from typing import Callable, List, Optional, Tuple

from lorito_aldhiro.backend.kernel.lcb_contracts import (
    LCB_API_VERSION, Capabilities, CancelResult, Command, DeviceInfo, DeviceLease,
    DeviceRequest, Direction, EventKind, FaultKind, HealthLevel, IllegalCommandError,
    InvalidConfigError, JobClass, JobSpec, JobState, JobTicket, NotInitializedError,
    SafeStopReport,
    SystemSnapshot, SystemState,
)
from lorito_aldhiro.backend.kernel.lcb_devices import AudioDeviceManager
from lorito_aldhiro.backend.kernel.lcb_events import EventBus, Subscription
from lorito_aldhiro.backend.kernel.lcb_health import DEFAULT_THRESHOLDS, HealthMonitor, Threshold
from lorito_aldhiro.backend.kernel.lcb_recovery import RecoveryCoordinator
from lorito_aldhiro.backend.kernel.lcb_scheduler import Scheduler, default_workers
from lorito_aldhiro.backend.kernel.lcb_state import ACTIVE_AUDIO, SystemStateMachine

S = SystemState


@dataclass(frozen=True)
class KernelConfig:
    enabled: bool = True
    workers: Optional[int] = None            # None = default_workers()
    max_pending_jobs: int = 64
    aging_s: float = 30.0
    workers_during_audio: int = 1
    max_class_during_audio: JobClass = JobClass.ANALYSIS
    health_period_s: float = 1.0
    health_idle_period_s: float = 5.0        # en reposo (LISTO, sin alertas)
    thresholds: Tuple[Threshold, ...] = DEFAULT_THRESHOLDS
    storage_path: Optional[str] = None
    event_history: int = 512
    pin_capture_device: bool = True

    @staticmethod
    def from_env(**overrides) -> "KernelConfig":
        cfg = KernelConfig(**overrides)
        if os.environ.get("LORITO_LCB", "").strip() == "0":
            cfg = replace(cfg, enabled=False)
        return cfg

    def validate(self) -> None:
        errs = []
        if self.workers is not None and not (1 <= self.workers <= 64):
            errs.append("workers debe estar entre 1 y 64")
        if self.max_pending_jobs < 1:
            errs.append("max_pending_jobs debe ser ≥ 1")
        if self.aging_s < 0:
            errs.append("aging_s no puede ser negativo")
        if self.workers_during_audio < 0:
            errs.append("workers_during_audio no puede ser negativo")
        if not (0.05 <= self.health_period_s <= 60):
            errs.append("health_period_s debe estar entre 0,05 y 60 s")
        if not (self.health_period_s <= self.health_idle_period_s <= 300):
            errs.append("health_idle_period_s debe estar entre health_period_s y 300 s")
        for th in self.thresholds:
            if th.op not in (">", "<") or th.raise_after < 1 or th.clear_after < 1:
                errs.append(f"umbral inválido: {th.subsystem}.{th.metric}")
        if errs:
            raise InvalidConfigError("; ".join(errs), errors=errs)


class LoroCentralBoss:
    def __init__(self, audio_backend: Callable[[], object] = lambda: None,
                 clock=time.monotonic_ns):
        self._clock = clock
        self._audio_backend = audio_backend
        self.bus = EventBus(clock=clock)
        self.config: Optional[KernelConfig] = None
        self._state = SystemStateMachine(on_change=self._on_state_change, clock=clock)
        self.scheduler: Optional[Scheduler] = None
        self.devices = AudioDeviceManager(audio_backend, publish=self._pub, clock=clock)
        self.health: Optional[HealthMonitor] = None
        self.recovery = RecoveryCoordinator(
            publish=self._pub, isolate=self._isolate_engine,
            capture_active=self._capture_active, on_error=self._enter_error, clock=clock)
        self._isolated: dict = {}
        self._lock = threading.RLock()
        self._initialized = False
        self._closed = False
        self.capabilities: Optional[Capabilities] = None
        self.command_log: deque = deque(maxlen=128)

    # ── publicación ──────────────────────────────────────────────────────
    def _pub(self, kind: EventKind, source: str, data=None):
        return self.bus.publish(kind, source, data)

    def _on_state_change(self, old: S, new: S, reason: str) -> None:
        if self.scheduler is not None:
            self.scheduler.set_audio_active(new in ACTIVE_AUDIO)
        if self.health is not None and old == S.LISTO and self.health._active:
            self.health.wake()               # deja el período de reposo al instante
        self._pub(EventKind.STATE_CHANGED, "kernel",
                  {"from": old.value, "to": new.value, "reason": reason})

    # ── §7 initialize ────────────────────────────────────────────────────
    def initialize(self, config: Optional[KernelConfig] = None) -> Capabilities:
        cfg = config or KernelConfig.from_env()
        cfg.validate()
        with self._lock:
            if self._initialized:
                return self.capabilities
            self.config = cfg
            warnings = []
            if cfg.enabled:
                self.scheduler = Scheduler(
                    workers=cfg.workers, max_pending=cfg.max_pending_jobs, aging_s=cfg.aging_s,
                    workers_during_audio=cfg.workers_during_audio,
                    max_class_during_audio=cfg.max_class_during_audio,
                    publish=self._pub, clock=self._clock)
                self.health = HealthMonitor(publish=self._on_health_event,
                                            period_s=cfg.health_period_s,
                                            idle_period_s=cfg.health_idle_period_s,
                                            thresholds=cfg.thresholds,
                                            storage_path=cfg.storage_path, clock=self._clock)
                self.health.register_probe("kernel", self._kernel_probe)
                # Con audio activo (o en transición) se muestrea al período normal.
                self.health.is_idle = lambda: self.state == S.LISTO
            else:
                warnings.append("Kernel en modo observador (LORITO_LCB=0 o enabled=False)")
            sd = self._audio_backend()
            backend_name = backend_version = None
            device_count = None
            if sd is not None:
                backend_name = getattr(sd, "__name__", type(sd).__name__)
                try:
                    backend_version = str(sd.get_portaudio_version()[1])
                except Exception:
                    backend_version = None
                try:
                    device_count = len(self.devices.list_devices(refresh=True))
                except Exception as e:
                    warnings.append(f"inventario de audio no disponible: {e}")
            else:
                warnings.append("sin backend de audio")
            if self.health is not None:
                self.health.sample()
                avail, missing = self.health.availability()
            else:
                avail, missing = (), ()
            self.capabilities = Capabilities(
                api_version=LCB_API_VERSION, audio_backend=backend_name,
                audio_backend_version=backend_version, device_count=device_count,
                cpu_count=os.cpu_count(),
                workers=self.scheduler.workers if self.scheduler else 0,
                metrics_available=tuple(m for m in avail),
                metrics_unavailable=tuple(m for m in missing if m != "cpu_process_pct"),
                warnings=tuple(warnings))
            self._initialized = True
            self._state.transition(S.LISTO, "initialize()")
            if self.health is not None:
                self.health.start()
            return self.capabilities

    @property
    def enabled(self) -> bool:
        return bool(self.config and self.config.enabled)

    def _require_init(self):
        if not self._initialized:
            raise NotInitializedError("Loro Central Boss no inicializado: llamar initialize()")

    # ── estado ───────────────────────────────────────────────────────────
    @property
    def state(self) -> S:
        return self._state.state

    def validate_command(self, command: Command) -> Optional[str]:
        """None si la orden es legal ahora; si no, el motivo (y se publica
        COMMAND_REJECTED para el diagnóstico)."""
        why = self._state.validate(command)
        self.command_log.append((self._clock(), command.value, why))
        if why is not None:
            self._pub(EventKind.COMMAND_REJECTED, "kernel",
                      {"command": command.value, "state": self.state.value, "reason": why})
        return why

    def drive(self, target: S, reason: str) -> S:
        """Lleva el estado del sistema a `target` por el camino más corto de
        transiciones permitidas (cada salto queda registrado). Lo usan los
        adaptadores que reflejan a las autoridades de los motores."""
        from lorito_aldhiro.backend.kernel.lcb_state import _ALLOWED
        cur = self.state
        if cur == target:
            return cur
        prev = {cur: None}
        frontier = [cur]
        while frontier and target not in prev:
            nxt = []
            for s in frontier:
                for t in _ALLOWED[s]:
                    if t not in prev:
                        prev[t] = s
                        nxt.append(t)
            frontier = nxt
        if target not in prev:
            raise IllegalCommandError(f"sin camino {cur.value} → {target.value}")
        path = []
        s = target
        while s != cur:
            path.append(s)
            s = prev[s]
        for s in reversed(path):
            self._state.transition(s, reason)
        return self.state

    def acknowledge_error(self, by: str = "operador") -> S:
        self._state.require(Command.ACKNOWLEDGE_ERROR)
        return self._state.transition(S.LISTO, f"error reconocido por {by}")

    def _enter_error(self, reason: str) -> None:
        try:
            self.drive(S.ERROR, reason)
        except IllegalCommandError:
            pass

    def _capture_active(self) -> bool:
        return self.state in (S.CAPTURANDO, S.PAUSADO, S.DETENIENDO, S.DRENANDO, S.FINALIZANDO)

    def notify_playback(self, active: bool) -> None:
        """La reproducción no tiene máquina de estados propia publicada: la
        interfaz avisa al empezar y al terminar."""
        try:
            if active and self.state in (S.LISTO, S.DEGRADADO):
                self._state.transition(S.REPRODUCIENDO, "reproducción iniciada")
            elif not active and self.state == S.REPRODUCIENDO:
                self._state.transition(self._rest_state(), "reproducción terminada")
        except IllegalCommandError:
            pass

    def _rest_state(self) -> S:
        degraded = bool(self._isolated) or (
            self.health is not None and self.health.level == HealthLevel.DEGRADED)
        return S.DEGRADADO if degraded else S.LISTO

    # ── salud ────────────────────────────────────────────────────────────
    def _on_health_event(self, kind: EventKind, source: str, data=None):
        self._pub(kind, source, data)
        if kind == EventKind.HEALTH_LEVEL:
            lvl = (data or {}).get("level")
            try:
                if lvl == HealthLevel.DEGRADED.value and self.state == S.LISTO:
                    self._state.transition(S.DEGRADADO, "salud degradada")
                elif lvl in (HealthLevel.HEALTHY.value, HealthLevel.ALIVE.value) \
                        and self.state == S.DEGRADADO and not self._isolated:
                    self._state.transition(S.LISTO, "salud recuperada")
            except IllegalCommandError:
                pass

    def _kernel_probe(self):
        st = self.scheduler.stats() if self.scheduler else {}
        return {"jobs_running": (st.get("running"), "trabajos"),
                "jobs_pending": (st.get("pending"), "trabajos"),
                "jobs_rejected": (st.get("rejected"), "trabajos"),
                "events_dropped": (self.bus.dropped_total(), "eventos")}

    # ── aislamiento de motores auxiliares ────────────────────────────────
    def _isolate_engine(self, engine: str, reason: str) -> None:
        with self._lock:
            self._isolated[engine] = reason
        if self.scheduler is not None:
            self.scheduler.isolated_owners.add(engine)
            self.scheduler.cancel_owner(engine, reason)
        self._pub(EventKind.ENGINE_ISOLATED, "recovery", {"engine": engine, "reason": reason})
        if self.state == S.LISTO:
            try:
                self._state.transition(S.DEGRADADO, f"motor {engine} aislado")
            except IllegalCommandError:
                pass

    def restore_engine(self, engine: str) -> bool:
        with self._lock:
            had = self._isolated.pop(engine, None) is not None
        if self.scheduler is not None:
            self.scheduler.isolated_owners.discard(engine)
        if had and self.state == S.DEGRADADO and self._rest_state() == S.LISTO:
            self._state.transition(S.LISTO, f"motor {engine} restituido")
        return had

    def report_fault(self, kind: FaultKind, subsystem: str, detail: str = "") -> str:
        return self.recovery.report_fault(kind, subsystem, detail)

    # ── §7 dispositivos ──────────────────────────────────────────────────
    def list_audio_devices(self, refresh: bool = False) -> List[DeviceInfo]:
        return self.devices.list_devices(refresh=refresh)

    def acquire_device(self, request: DeviceRequest) -> DeviceLease:
        self._require_init()
        if request.owner == "capture" and request.direction == Direction.INPUT:
            held = self.devices.lease_of("capture", Direction.INPUT)
            if (held is not None and self._capture_active()
                    and request.device_id not in (None, held.device_id)):
                raise IllegalCommandError("no se cambia el dispositivo de entrada durante una "
                                          "captura", state=self.state.value)
        return self.devices.acquire(request)

    def release_device(self, lease_id: str) -> bool:
        return self.devices.release(lease_id)

    # ── §7 trabajos ──────────────────────────────────────────────────────
    def submit_job(self, spec: JobSpec) -> JobTicket:
        self._require_init()
        if self.scheduler is None:
            return JobTicket("", False, JobState.REJECTED,
                             "Kernel en modo observador: sin planificador")
        return self.scheduler.submit(spec)

    def cancel_job(self, job_id: str) -> CancelResult:
        self._require_init()
        return self.scheduler.cancel(job_id)

    # ── §7 eventos ───────────────────────────────────────────────────────
    def subscribe_events(self, name: str = "", capacity: int = 1024,
                         kinds=None) -> Subscription:
        return self.bus.subscribe(name=name, capacity=capacity, kinds=kinds)

    # ── §7 parada segura ─────────────────────────────────────────────────
    def request_safe_stop(self, reason: str) -> bool:
        self._require_init()
        return self.recovery.request_safe_stop(reason)

    # ── §7 instantánea ───────────────────────────────────────────────────
    def get_system_snapshot(self) -> SystemSnapshot:
        h = self.health
        jobs = tuple(self.scheduler.jobs()) if self.scheduler else ()
        return SystemSnapshot(
            api_version=LCB_API_VERSION, seq=self.bus.published, t_ns=self._clock(),
            state=self.state,
            health=h.level if h is not None else HealthLevel.UNKNOWN,
            metrics=h.metrics() if h is not None else (),
            alerts=h.alerts() if h is not None else (),
            jobs=jobs, leases=self.devices.leases(),
            isolated_engines=tuple(sorted(self._isolated)),
            events_dropped=self.bus.dropped_total(),
            last_safe_stop=self.recovery.last_report)

    # ── cierre ───────────────────────────────────────────────────────────
    def shutdown(self, timeout: float = 10.0) -> bool:
        """Libera hilos y concesiones. No toca la captura: el cierre de la
        sesión es de la ventana y del motor."""
        with self._lock:
            if self._closed:
                return True
            self._closed = True
        ok = True
        if self.health is not None:
            self.health.stop(timeout)
        if self.scheduler is not None:
            ok = self.scheduler.shutdown(timeout)
        for lease in self.devices.leases():
            self.devices.release(lease.lease_id)
        return ok

    def threads_alive(self) -> int:
        n = 0
        if self.scheduler is not None:
            n += self.scheduler.alive_workers
        if self.health is not None and self.health.running:
            n += 1
        return n


def make_report_text(rep: Optional[SafeStopReport]) -> str:
    if rep is None:
        return "sin parada segura registrada"
    lines = [f"Parada segura: {rep.reason}",
             f"  completa={rep.complete}  verificada={rep.verified}  "
             f"duración={(rep.finished_ns - rep.started_ns) / 1e9:.2f} s"]
    for step, ok, detail in rep.steps:
        lines.append(f"  {'✔' if ok else '✘'} {step}: {detail}")
    return "\n".join(lines)
