"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — coordinador de recuperación: aísla motores auxiliares, conduce la parada segura detener → drenar → sincronizar → cerrar → verificar y nunca reanuda ni reinicia por su cuenta.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


§3.4 de la orden. Política documentada:

| Fallo | Acción |
|---|---|
| AUX_ENGINE_FAILURE (onda, TAU, telemetría…) | Se aísla el motor: sus trabajos se cancelan y no se aceptan nuevos hasta `restore_engine()`. La captura sigue. |
| EXPORT_FAILURE | Igual que un motor auxiliar: la exportación queda aislada; la captura y el material ya grabado no se tocan. |
| AUDIO_INPUT_FAILURE, OVERFLOW_UNRECOVERABLE, DEVICE_LOST, CORRUPTION_RISK durante una captura | Se declara el evento y se hace la parada segura para proteger lo escrito. |
| Los mismos fallos fuera de captura | Se declaran y el sistema queda en ERROR o DEGRADADO, sin parada. |

**Convivencia con el motor de captura.** El motor ya tiene su propio cierre
de emergencia (fail-stop: ante pérdida declarada, fallo de escritura o
dispositivo irrecuperable cierra stream, drena, sincroniza y clasifica) y su
recuperación de stream (reabre el MISMO dispositivo, con espera). El
coordinador no los duplica ni compite con ellos:

- Si la sesión ya terminó en FAILED, la parada segura no repite el cierre:
  VERIFICA el resultado que dejó el motor.
- La parada segura usa las fases autoritativas del motor: `request_stop()`
  para detener y drenar, y `finalize()` para sincronizar (barrera de flush
  y fsync), cerrar el writer y verificar los segmentos. Después comprueba
  por su cuenta que el archivo en disco tiene los frames que el motor dice
  haber escrito.

**Lo que nunca hace.** No reinicia Lorito, no reanuda una captura, no abre
otro dispositivo. Sale de ERROR solo con un reconocimiento explícito.

**Hilo.** La parada corre en su propio hilo ("lorito-lcb-recovery"). Así
no se ejecuta en el hilo que avisó del fallo (vigilante, drenado), que la
parada tiene que esperar.
"""

from __future__ import annotations

import os
import threading
import time
from typing import Callable, List, Optional, Tuple

from lorito_aldhiro.backend.core.lorito_identity import thread_name
from lorito_aldhiro.backend.kernel.lcb_contracts import (
    EventKind, FaultKind, SafeStopReport, SafeStopStep,
)

AUXILIARY_FAULTS = frozenset({FaultKind.AUX_ENGINE_FAILURE, FaultKind.EXPORT_FAILURE})
CAPTURE_FAULTS = frozenset({FaultKind.AUDIO_INPUT_FAILURE, FaultKind.OVERFLOW_UNRECOVERABLE,
                            FaultKind.DEVICE_LOST, FaultKind.CORRUPTION_RISK})


def _probe_frames(path: str, sf_module) -> Optional[int]:
    if sf_module is None or not path or not os.path.exists(path):
        return None
    try:
        with sf_module.SoundFile(path, "r") as f:
            return int(f.frames)
    except Exception:
        return None


class RecoveryCoordinator:
    def __init__(self, publish: Callable, isolate: Callable[[str, str], None],
                 capture_active: Callable[[], bool],
                 on_error: Callable[[str], None], clock=time.monotonic_ns):
        self._publish = publish
        self._isolate = isolate
        self._capture_active = capture_active
        self._on_error = on_error
        self._clock = clock
        self._capture = None
        self._sf = None
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self.faults: List[Tuple[int, str, str, str]] = []
        self.last_report: Optional[SafeStopReport] = None
        self._done = threading.Event()
        self._done.set()

    def attach_capture(self, engine, soundfile_module=None) -> None:
        self._capture = engine
        self._sf = soundfile_module

    # ── fallos ───────────────────────────────────────────────────────────
    def report_fault(self, kind: FaultKind, subsystem: str, detail: str = "") -> str:
        """Devuelve la acción tomada ("isolate", "safe_stop", "declared")."""
        now = self._clock()
        with self._lock:
            self.faults.append((now, kind.value, subsystem, detail))
            del self.faults[:-256]
        if kind in AUXILIARY_FAULTS:
            action = "isolate"
        elif kind in CAPTURE_FAULTS and self._capture_active():
            action = "safe_stop"
        else:
            action = "declared"
        self._publish(EventKind.FAULT, "recovery",
                      {"kind": kind.value, "subsystem": subsystem, "detail": detail,
                       "action": action, "t_ns": now})
        if action == "isolate":
            self._isolate(subsystem, f"{kind.value}: {detail}")
        elif action == "safe_stop":
            self.request_safe_stop(f"{kind.value} ({subsystem}): {detail}")
        elif kind in CAPTURE_FAULTS:
            self._on_error(f"{kind.value} ({subsystem}): {detail}")
        return action

    # ── parada segura ────────────────────────────────────────────────────
    def request_safe_stop(self, reason: str) -> bool:
        """Inicia la secuencia en segundo plano. False si ya hay una en
        curso (idempotente) o no hay motor de captura."""
        if self._capture is None:
            return False
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return False
            self._done.clear()
            self._thread = threading.Thread(target=self._run_safe_stop, args=(reason,),
                                            daemon=True, name=thread_name("lcb-recovery"))
            self._thread.start()
        return True

    def wait(self, timeout: Optional[float] = None) -> Optional[SafeStopReport]:
        self._done.wait(timeout)
        return self.last_report

    def _step(self, steps, step: SafeStopStep, ok: bool, detail: str) -> None:
        steps.append((step.value, bool(ok), detail))
        self._publish(EventKind.SAFE_STOP_STEP, "recovery",
                      {"step": step.value, "ok": bool(ok), "detail": detail})

    def _run_safe_stop(self, reason: str) -> None:
        eng = self._capture
        t0 = self._clock()
        steps: list = []
        try:
            state_before = getattr(getattr(eng, "state", None), "value", str(getattr(eng, "state", "")))
            already_failed = state_before in ("FAILED", "CLASSIFIED")
            # 1-2. detener y drenar (fases del motor; en FAILED las hizo el fail-stop)
            if already_failed:
                self._step(steps, SafeStopStep.DETENER, True,
                           f"la sesión ya estaba en {state_before} (fail-stop del motor)")
                drained = True
                self._step(steps, SafeStopStep.DRENAR, True, "drenado por el fail-stop del motor")
            else:
                drained = bool(eng.request_stop())
                self._step(steps, SafeStopStep.DETENER, True, "stream cerrado, sin aceptar audio")
                self._step(steps, SafeStopStep.DRENAR, drained,
                           "ring vacío" if drained else "el ring no se vació a tiempo")
            # 3-4. sincronizar y cerrar (fail-stop: ya los hizo; finalize es idempotente)
            fin = eng.finalize()
            barrier = getattr(fin, "barrier", None)
            synced = barrier is None or bool(getattr(barrier, "ok", False))
            if barrier is None and getattr(fin, "writer", None) is None:
                synced = False
            self._step(steps, SafeStopStep.SINCRONIZAR, synced,
                       "flush + fsync confirmados" if synced else
                       f"barrera no confirmada ({getattr(barrier, 'reason', 'sin barrera')})")
            writer = getattr(fin, "writer", None)
            closed = bool(writer is not None and writer.closed and not writer.failed)
            self._step(steps, SafeStopStep.CERRAR, closed,
                       "writer cerrado" if closed else
                       f"writer: {getattr(writer, 'failure_reason', '') or 'no cerró'}")
            # 5. verificar: segmentos del motor + relectura independiente del archivo
            reasons = list(getattr(fin, "reasons", []) or [])
            verify_fail = [r for r in reasons if r.startswith("VERIFY_FAILED")]
            path = eng.get_path() if hasattr(eng, "get_path") else ""
            on_disk = _probe_frames(path, self._sf)
            written = getattr(writer, "frames_written", None)
            file_ok = on_disk is not None and written is not None and on_disk == written
            rec = getattr(fin, "reconciliation", None)
            rec_ok = rec is None or bool(getattr(rec, "ok", False))
            verified = file_ok and not verify_fail
            detail = (f"archivo {os.path.basename(path) or '?'}: {on_disk} frames en disco / "
                      f"{written} escritos; reconciliación {'OK' if rec_ok else 'con causas'}; "
                      f"clasificación {getattr(getattr(fin, 'classification', None), 'state', '?')}")
            if verify_fail:
                detail += "; " + "; ".join(verify_fail)
            self._step(steps, SafeStopStep.VERIFICAR, verified, detail)
            complete = drained and synced and closed and verified
        except Exception as e:
            steps.append(("EXCEPCION", False, f"{type(e).__name__}: {e}"))
            complete, verified = False, False
        report = SafeStopReport(reason=reason, steps=tuple(steps), complete=bool(complete),
                                verified=bool(verified), started_ns=t0,
                                finished_ns=self._clock())
        self.last_report = report
        self._publish(EventKind.SAFE_STOP_DONE, "recovery",
                      {"reason": reason, "complete": report.complete,
                       "verified": report.verified,
                       "steps": [s[0] + (" OK" if s[1] else " FALLÓ") for s in steps]})
        if not report.complete:
            self._on_error(f"parada segura incompleta: {reason}")
        self._done.set()
