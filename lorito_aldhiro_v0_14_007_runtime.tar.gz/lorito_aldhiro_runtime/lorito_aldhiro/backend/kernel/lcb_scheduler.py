"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — planificador de trabajos de fondo: cola acotada, clases de criticidad con envejecimiento, dependencias, reintentos y cancelación cooperativa; cede ante la captura.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


§3.1 de la orden. Lo que el planificador NO hace: no ejecuta ni controla
el callback de audio, ni la captura, ni la reproducción. Esos motores
tienen sus propios hilos de tiempo real; el planificador solo les cede el
paso:

- **Protección del audio.** Mientras hay captura o reproducción
  (`set_audio_active(True)`), solo corre `workers_during_audio` trabajos a
  la vez (1 por defecto) y las clases por encima de `max_class_during_audio`
  (mantenimiento) esperan. Así el análisis o la exportación nunca compiten
  con el drenado de la captura por todos los núcleos.
- **Orden.** Menor clase primero (INTERACTIVE < EXPORT < ANALYSIS <
  MAINTENANCE); a igual clase, el más antiguo.
- **Envejecimiento.** Cada `aging_s` de espera, un trabajo sube una clase
  efectiva (nunca por encima de INTERACTIVE). Evita la inanición de lo de
  fondo sin dejar que se adelante a lo interactivo de golpe.
- **Contrapresión.** La cola admite `max_pending` trabajos; con la cola
  llena, `submit()` RECHAZA con motivo (nunca promete lo que no puede).
- **Cancelación cooperativa.** `cancel()` en un trabajo pendiente lo
  cancela al instante; en uno que corre, marca `ctx.cancelled` y el
  trabajo decide en su próximo punto seguro. Un trabajo `cancellable=False`
  (p. ej. cerrar un archivo) no se interrumpe: la petición se rechaza.
  Nunca se mata un hilo (Python no ofrece una forma segura de hacerlo).
- **Dependencias.** Un trabajo espera a que sus dependencias terminen bien;
  si una falla o se cancela, el dependiente se cancela con ese motivo.
- **Reintentos.** Según `RetryPolicy`, con espera exponencial; nunca se
  reintenta un trabajo cancelado.

Los workers son hilos (`threading`), adecuados para trabajos que esperan
E/S o liberan el GIL en NumPy. No se fija afinidad de CPU (§5: medir antes).
"""

from __future__ import annotations

import itertools
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from lorito_aldhiro.backend.core.lorito_identity import thread_name
from lorito_aldhiro.backend.kernel.lcb_contracts import (
    CancelResult, EventKind, JobClass, JobInfo, JobSpec, JobState, JobTicket,
    UnknownJobError,
)


class JobCancelled(Exception):
    """Un trabajo puede lanzarla desde un punto seguro tras ver
    `ctx.cancelled`; cuenta como CANCELLED, no como fallo."""


class JobContext:
    """Lo que recibe la función de un trabajo."""

    def __init__(self, job_id: str, attempt: int):
        self.job_id = job_id
        self.attempt = attempt
        self._cancel = threading.Event()
        self._on_cancel: list = []
        self.progress: Optional[float] = None

    def on_cancel(self, callback: Callable[[], None]) -> None:
        """Registra un aviso de cancelación (p. ej. el `cancel_event` propio
        del motor). Si ya se pidió cancelar, se llama al instante."""
        self._on_cancel.append(callback)
        if self._cancel.is_set():
            self._fire(callback)

    @staticmethod
    def _fire(callback) -> None:
        try:
            callback()
        except Exception:
            pass

    def _request_cancel(self) -> None:
        self._cancel.set()
        for cb in list(self._on_cancel):
            self._fire(cb)

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    def check_cancelled(self) -> None:
        if self._cancel.is_set():
            raise JobCancelled(self.job_id)

    def report_progress(self, fraction: float) -> None:
        self.progress = max(0.0, min(1.0, float(fraction)))

    def wait(self, seconds: float) -> bool:
        """Espera interrumpible: True si se pidió cancelar."""
        return self._cancel.wait(seconds)


@dataclass
class _Job:
    job_id: str
    spec: JobSpec
    created_ns: int
    state: JobState = JobState.PENDING
    started_ns: Optional[int] = None
    finished_ns: Optional[int] = None
    attempts: int = 0
    not_before_ns: int = 0
    error: str = ""
    result: object = None
    ctx: Optional[JobContext] = None
    done: threading.Event = field(default_factory=threading.Event)

    def info(self) -> JobInfo:
        return JobInfo(job_id=self.job_id, name=self.spec.name, owner=self.spec.owner,
                       job_class=self.spec.job_class, state=self.state,
                       created_ns=self.created_ns, started_ns=self.started_ns,
                       finished_ns=self.finished_ns, attempts=self.attempts,
                       progress=self.ctx.progress if self.ctx else None,
                       error=self.error, cancellable=self.spec.cancellable,
                       depends_on=self.spec.depends_on)


def default_workers() -> int:
    """La mitad de los núcleos, entre 1 y 4: deja núcleos libres para el
    audio, la interfaz y el sistema (no satura todos los núcleos)."""
    n = os.cpu_count() or 2
    return max(1, min(4, n // 2))


class Scheduler:
    def __init__(self, workers: Optional[int] = None, max_pending: int = 64,
                 aging_s: float = 30.0, workers_during_audio: int = 1,
                 max_class_during_audio: JobClass = JobClass.ANALYSIS,
                 publish: Optional[Callable] = None, clock=time.monotonic_ns,
                 keep_finished: int = 256):
        self.workers = int(workers or default_workers())
        self.max_pending = int(max_pending)
        self.aging_ns = int(aging_s * 1e9)
        self.workers_during_audio = max(0, int(workers_during_audio))
        self.max_class_during_audio = JobClass(max_class_during_audio)
        self._publish = publish or (lambda *a, **k: None)
        self._clock = clock
        self._keep_finished = keep_finished
        self._jobs: Dict[str, _Job] = {}
        self._order: List[str] = []           # ids en orden de llegada (para retención)
        self._cv = threading.Condition()
        self._ids = itertools.count(1)
        self._running = 0
        self._audio_active = False
        self._threads: List[threading.Thread] = []
        self._shutdown = False
        self.rejected = 0
        self.isolated_owners: set = set()

    # ── ciclo de vida ────────────────────────────────────────────────────
    def start(self) -> None:
        with self._cv:
            if self._threads or self._shutdown:
                return
            for i in range(self.workers):
                t = threading.Thread(target=self._worker, daemon=True,
                                     name=thread_name(f"lcb-worker-{i}"))
                self._threads.append(t)
                t.start()

    def shutdown(self, timeout: float = 10.0) -> bool:
        """Cancela lo pendiente, pide cancelar lo cancelable que corre y
        espera a los workers. Devuelve False si alguno siguió vivo
        (un trabajo no cancelable aún terminando): nunca se mata."""
        with self._cv:
            self._shutdown = True
            for j in self._jobs.values():
                if j.state == JobState.PENDING:
                    self._finish_locked(j, JobState.CANCELLED, "cierre del planificador")
                elif j.state in (JobState.RUNNING, JobState.CANCEL_REQUESTED) \
                        and j.spec.cancellable and j.ctx is not None:
                    j.ctx._request_cancel()
            self._cv.notify_all()
        deadline = time.monotonic() + timeout
        for t in self._threads:
            t.join(max(0.0, deadline - time.monotonic()))
        return not any(t.is_alive() for t in self._threads)

    @property
    def alive_workers(self) -> int:
        return sum(1 for t in self._threads if t.is_alive())

    def set_audio_active(self, active: bool) -> None:
        with self._cv:
            self._audio_active = bool(active)
            self._cv.notify_all()

    # ── API ──────────────────────────────────────────────────────────────
    def submit(self, spec: JobSpec) -> JobTicket:
        self.start()                      # los workers nacen con el primer trabajo
        with self._cv:
            job_id = f"job-{next(self._ids)}"
            reason = ""
            if self._shutdown:
                reason = "planificador cerrado"
            elif spec.owner in self.isolated_owners:
                reason = f"motor {spec.owner!r} aislado por fallo"
            elif self._pending_count() >= self.max_pending:
                reason = f"cola llena ({self.max_pending} pendientes)"
            else:
                missing = [d for d in spec.depends_on if d not in self._jobs]
                if missing:
                    reason = f"dependencias desconocidas: {', '.join(missing)}"
            if reason:
                self.rejected += 1
                self._publish(EventKind.JOB_FINISHED, "scheduler",
                              {"job_id": job_id, "name": spec.name, "state": "REJECTED",
                               "reason": reason})
                return JobTicket(job_id, False, JobState.REJECTED, reason)
            job = _Job(job_id, spec, self._clock())
            self._jobs[job_id] = job
            self._order.append(job_id)
            self._trim_locked()
            self._cv.notify_all()
        self._publish(EventKind.JOB_SUBMITTED, "scheduler",
                      {"job_id": job_id, "name": spec.name, "owner": spec.owner,
                       "class": spec.job_class.name})
        return JobTicket(job_id, True, JobState.PENDING)

    def cancel(self, job_id: str) -> CancelResult:
        with self._cv:
            job = self._jobs.get(job_id)
            if job is None:
                raise UnknownJobError(f"trabajo desconocido {job_id!r}", job_id=job_id)
            st = job.state
            if st.terminal:
                return CancelResult(job_id, st, False, "ya terminó")
            if st == JobState.PENDING:
                self._finish_locked(job, JobState.CANCELLED, "cancelado antes de empezar")
                self._cv.notify_all()
                return CancelResult(job_id, JobState.CANCELLED, True)
            if not job.spec.cancellable:
                return CancelResult(job_id, st, False,
                                    "no cancelable: se deja terminar para no dejar un archivo "
                                    "a medio cerrar")
            job.state = JobState.CANCEL_REQUESTED
            if job.ctx is not None:
                job.ctx._request_cancel()
            return CancelResult(job_id, JobState.CANCEL_REQUESTED, True,
                                "cancelación cooperativa solicitada")

    def cancel_owner(self, owner: str, reason: str) -> int:
        """Cancela lo pendiente y pide cancelar lo que corre de un motor."""
        n = 0
        with self._cv:
            ids = [j.job_id for j in self._jobs.values()
                   if j.spec.owner == owner and not j.state.terminal]
        for jid in ids:
            try:
                if self.cancel(jid).accepted:
                    n += 1
            except UnknownJobError:
                pass
        return n

    def info(self, job_id: str) -> JobInfo:
        with self._cv:
            job = self._jobs.get(job_id)
            if job is None:
                raise UnknownJobError(f"trabajo desconocido {job_id!r}", job_id=job_id)
            return job.info()

    def wait(self, job_id: str, timeout: Optional[float] = None) -> JobInfo:
        with self._cv:
            job = self._jobs.get(job_id)
            if job is None:
                raise UnknownJobError(f"trabajo desconocido {job_id!r}", job_id=job_id)
        job.done.wait(timeout)
        return self.info(job_id)

    def result(self, job_id: str):
        with self._cv:
            return self._jobs[job_id].result

    def jobs(self) -> List[JobInfo]:
        with self._cv:
            return [self._jobs[i].info() for i in self._order]

    def stats(self) -> dict:
        with self._cv:
            by_state: Dict[str, int] = {}
            for j in self._jobs.values():
                by_state[j.state.value] = by_state.get(j.state.value, 0) + 1
            return {"workers": self.workers, "alive_workers": self.alive_workers,
                    "running": self._running, "pending": self._pending_count(),
                    "rejected": self.rejected, "audio_active": self._audio_active,
                    "by_state": by_state}

    # ── interno ──────────────────────────────────────────────────────────
    def _pending_count(self) -> int:
        return sum(1 for j in self._jobs.values() if j.state == JobState.PENDING)

    def _trim_locked(self) -> None:
        excess = len(self._order) - self._keep_finished
        if excess <= 0:
            return
        keep = []
        for jid in self._order:
            j = self._jobs[jid]
            if excess > 0 and j.state.terminal:
                del self._jobs[jid]
                excess -= 1
            else:
                keep.append(jid)
        self._order = keep

    def _effective_class(self, job: _Job, now: int) -> int:
        cls = int(job.spec.job_class)
        if self.aging_ns > 0:
            cls -= int((now - job.created_ns) // self.aging_ns)
        return max(int(JobClass.INTERACTIVE), cls)

    def _deps_state(self, job: _Job) -> str:
        """"ok", "wait" o el motivo de cancelación."""
        for d in job.spec.depends_on:
            dj = self._jobs.get(d)
            if dj is None:
                continue                      # ya retirado del historial: terminó bien antes
            if dj.state == JobState.SUCCEEDED:
                continue
            if dj.state.terminal:
                return f"dependencia {d} terminó en {dj.state.value}"
            return "wait"
        return "ok"

    def _pick_locked(self) -> Optional[_Job]:
        now = self._clock()
        if self._audio_active and self._running >= self.workers_during_audio:
            return None
        best, best_key = None, None
        for jid in self._order:
            j = self._jobs[jid]
            if j.state != JobState.PENDING or j.not_before_ns > now:
                continue
            dep = self._deps_state(j)
            if dep == "wait":
                continue
            if dep != "ok":
                self._finish_locked(j, JobState.CANCELLED, dep)
                continue
            eff = self._effective_class(j, now)
            if self._audio_active and eff > int(self.max_class_during_audio):
                continue
            key = (eff, j.created_ns)
            if best_key is None or key < best_key:
                best, best_key = j, key
        return best

    def _next_wakeup_s(self) -> float:
        now = self._clock()
        waits = [j.not_before_ns - now for j in self._jobs.values()
                 if j.state == JobState.PENDING and j.not_before_ns > now]
        # En reposo los workers despiertan cada segundo (submit los avisa
        # al instante); con reintentos en espera, al vencer el primero.
        return min([1.0] + [w / 1e9 for w in waits])

    def _worker(self) -> None:
        while True:
            with self._cv:
                job = None
                while not self._shutdown:
                    job = self._pick_locked()
                    if job is not None:
                        break
                    self._cv.wait(self._next_wakeup_s())
                if job is None:
                    return
                job.state = JobState.RUNNING
                job.attempts += 1
                job.started_ns = job.started_ns or self._clock()
                job.ctx = JobContext(job.job_id, job.attempts)
                self._running += 1
            self._publish(EventKind.JOB_STARTED, "scheduler",
                          {"job_id": job.job_id, "name": job.spec.name,
                           "attempt": job.attempts})
            outcome, err, result = JobState.SUCCEEDED, "", None
            try:
                result = job.spec.fn(job.ctx)
                if job.ctx.cancelled and job.spec.cancellable:
                    outcome, err = JobState.CANCELLED, "cancelado por pedido"
            except JobCancelled:
                outcome, err = JobState.CANCELLED, "cancelado por pedido"
            except Exception as e:                  # el fallo de un trabajo no tumba al worker
                outcome, err = JobState.FAILED, f"{type(e).__name__}: {e}"
            with self._cv:
                self._running -= 1
                job.result = result
                if (outcome == JobState.FAILED and not self._shutdown
                        and job.attempts < job.spec.retry.max_attempts
                        and job.state != JobState.CANCEL_REQUESTED):
                    job.state = JobState.PENDING
                    job.error = err
                    delay = job.spec.retry.backoff_s * (2 ** (job.attempts - 1))
                    job.not_before_ns = self._clock() + int(delay * 1e9)
                    self._cv.notify_all()
                    retry = True
                else:
                    self._finish_locked(job, outcome, err)
                    self._cv.notify_all()
                    retry = False
            if retry:
                self._publish(EventKind.JOB_RETRY, "scheduler",
                              {"job_id": job.job_id, "attempt": job.attempts, "error": err})

    def _finish_locked(self, job: _Job, state: JobState, err: str) -> None:
        job.state = state
        job.error = err
        job.finished_ns = self._clock()
        job.done.set()
        late = (job.spec.deadline_s is not None and job.started_ns is not None
                and (job.finished_ns - job.created_ns) / 1e9 > job.spec.deadline_s)
        self._publish(EventKind.JOB_FINISHED, "scheduler",
                      {"job_id": job.job_id, "name": job.spec.name, "owner": job.spec.owner,
                       "state": state.value, "error": err, "attempts": job.attempts,
                       "duration_s": ((job.finished_ns - job.started_ns) / 1e9
                                      if job.started_ns else None),
                       "deadline_exceeded": bool(late)})
