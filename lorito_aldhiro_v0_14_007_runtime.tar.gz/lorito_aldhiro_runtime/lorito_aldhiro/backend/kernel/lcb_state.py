"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Loro Central Boss — máquina de estados del sistema: transiciones explícitas, órdenes validadas contra el estado y ninguna transición ambigua.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Estados de §3.4. El estado del SISTEMA no reemplaza a las autoridades
existentes (§6): la sesión de captura sigue siendo de `CaptureSessionFSM`
y el transporte, del Transport Core. El Kernel REFLEJA esos estados y les
suma lo que ningún motor ve solo: DEGRADADO (riesgo sostenido de salud o
un motor auxiliar aislado) y ERROR (fallo que exige reconocimiento).

Reglas:
- Toda transición está en `_ALLOWED`; cualquier otra lanza
  `IllegalCommandError` (no hay transiciones implícitas).
- `validate(command)` dice si una orden es legal en el estado actual
  ANTES de que la interfaz la ejecute.
- DEGRADADO no interrumpe una captura: es una marca encima del estado de
  la sesión (`degraded=True`) mientras la captura sigue; el estado
  publicado pasa a DEGRADADO solo fuera de captura/reproducción, para no
  ocultar que se sigue grabando.
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Dict, FrozenSet, List, Optional, Tuple

from lorito_aldhiro.backend.kernel.lcb_contracts import (
    Command, IllegalCommandError, SystemState as S,
)

_ALLOWED: Dict[S, FrozenSet[S]] = {
    S.INICIALIZANDO: frozenset({S.LISTO, S.ERROR}),
    S.LISTO: frozenset({S.CAPTURANDO, S.REPRODUCIENDO, S.DEGRADADO, S.ERROR}),
    S.CAPTURANDO: frozenset({S.PAUSADO, S.DETENIENDO, S.ERROR}),
    S.PAUSADO: frozenset({S.CAPTURANDO, S.DETENIENDO, S.ERROR}),
    S.DETENIENDO: frozenset({S.DRENANDO, S.FINALIZANDO, S.LISTO, S.ERROR}),
    S.DRENANDO: frozenset({S.FINALIZANDO, S.ERROR}),
    S.FINALIZANDO: frozenset({S.LISTO, S.DEGRADADO, S.ERROR}),
    S.REPRODUCIENDO: frozenset({S.LISTO, S.DEGRADADO, S.ERROR}),
    S.DEGRADADO: frozenset({S.LISTO, S.CAPTURANDO, S.REPRODUCIENDO, S.ERROR}),
    S.ERROR: frozenset({S.LISTO}),             # solo con reconocimiento explícito
}

# Órdenes legales por estado.
_COMMANDS: Dict[Command, FrozenSet[S]] = {
    Command.START_CAPTURE: frozenset({S.LISTO, S.DEGRADADO}),
    Command.PAUSE_CAPTURE: frozenset({S.CAPTURANDO}),
    Command.RESUME_CAPTURE: frozenset({S.PAUSADO}),
    Command.STOP_CAPTURE: frozenset({S.CAPTURANDO, S.PAUSADO}),
    Command.START_PLAYBACK: frozenset({S.LISTO, S.DEGRADADO}),
    Command.STOP_PLAYBACK: frozenset({S.REPRODUCIENDO}),
    Command.EXPORT: frozenset({S.LISTO, S.DEGRADADO}),
    Command.CHANGE_DEVICE: frozenset({S.LISTO, S.DEGRADADO}),   # nunca durante captura
    Command.ACKNOWLEDGE_ERROR: frozenset({S.ERROR}),
}

ACTIVE_AUDIO = frozenset({S.CAPTURANDO, S.PAUSADO, S.DETENIENDO, S.DRENANDO,
                          S.FINALIZANDO, S.REPRODUCIENDO})
CAPTURE_STATES = frozenset({S.CAPTURANDO, S.PAUSADO, S.DETENIENDO, S.DRENANDO,
                            S.FINALIZANDO})


class SystemStateMachine:
    def __init__(self, on_change: Optional[Callable[[S, S, str], None]] = None,
                 clock=time.monotonic_ns, history: int = 128):
        self._state = S.INICIALIZANDO
        self._lock = threading.Lock()
        self._on_change = on_change
        self._clock = clock
        self._history: List[Tuple[int, str, str, str]] = []
        self._history_max = history
        self.error_reason = ""

    @property
    def state(self) -> S:
        return self._state

    def can(self, target: S) -> bool:
        return target in _ALLOWED[self._state]

    def transition(self, target: S, reason: str = "") -> S:
        with self._lock:
            old = self._state
            if target == old:
                return old                     # idempotente
            if target not in _ALLOWED[old]:
                raise IllegalCommandError(
                    f"transición {old.value} → {target.value} no permitida",
                    current=old.value, target=target.value)
            self._state = target
            if target == S.ERROR:
                self.error_reason = reason
            self._history.append((self._clock(), old.value, target.value, reason))
            del self._history[:-self._history_max]
        if self._on_change is not None:
            self._on_change(old, target, reason)
        return target

    def validate(self, command: Command) -> Optional[str]:
        """None si la orden es legal; si no, el motivo."""
        allowed = _COMMANDS[command]
        st = self._state
        if st in allowed:
            return None
        return (f"{command.value} no es válido en {st.value} "
                f"(válido en: {', '.join(sorted(s.value for s in allowed))})")

    def require(self, command: Command) -> None:
        why = self.validate(command)
        if why is not None:
            raise IllegalCommandError(why, command=command.value, state=self._state.value)

    def history(self) -> List[Tuple[int, str, str, str]]:
        with self._lock:
            return list(self._history)


def allowed_transitions() -> Dict[str, Tuple[str, ...]]:
    """Tabla pública (documentación y pruebas de contrato)."""
    return {s.value: tuple(sorted(t.value for t in targets)) for s, targets in _ALLOWED.items()}


def allowed_commands() -> Dict[str, Tuple[str, ...]]:
    return {c.value: tuple(sorted(s.value for s in states)) for c, states in _COMMANDS.items()}
