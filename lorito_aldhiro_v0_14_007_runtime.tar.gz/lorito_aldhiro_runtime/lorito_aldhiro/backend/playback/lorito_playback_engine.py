from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Motor de reproducción en tiempo real — velocidad variable, scrub, resampleo.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

Orden Golden Scrubs Morpher / Velocista / Seek (SMV-01…SMV-14) —
refundación del motor. El Transport Core (`TransportMachine`,
`SpeedPlanner`, generaciones) es la ÚNICA autoridad productiva.

Pipeline (ver SCRUBS_TRANSPORT_ARCHITECTURE_GOLDEN.md):

    UI ──TransportTransaction──▶ cola de comandos (deque, sin locks)
                                   │  (aplicación EN ORDEN, coalescing
                                   ▼   explícito, seek supersedido)
    hilo `pe-render`: TransportMachine + SpeedPlanner
       └─ VariableRateReader (cursor absoluto, rampa de ratio por muestra)
       └─ TransitionPolicy (rampas precalculadas; DIP/XFADE/EOF/STOP)
       └─ publica bloques ETIQUETADOS (sesión, transporte, epoch de ratio)
                                   │
                                   ▼
    ring SPSC preasignado de PE_RING_SLOTS × PE_BLOCKSIZE frames
                                   │
                                   ▼
    callback RT: SOLO copia frames válidos, descarta generaciones por
    debajo del mínimo válido, rellena silencio declarado en underrun y
    actualiza contadores/cursor audible. Sin lecturas de disco, sin
    logs, sin forenses, sin locks, sin crossfades.

Semántica de corte: un comando surte efecto en la CABEZA de escritura
del ring (el audio ya encolado, ≤ PE_TARGET_LEAD bloques ≈ 64 ms a
48 kHz, se reproduce íntegro y es válido para la generación vigente al
publicarse). Nunca se vacía la cola audible por debajo del callback, de
modo que ningún bloque viejo puede aparecer DESPUÉS de uno nuevo.

Cursores canónicos (CURSOR_AND_GENERATION_LEDGER.md):
    requested_frame   último destino pedido por la UI (seek)
    read_head_frame   cursor del lector (hilo de render)
    queued_head_frame fin del último bloque publicado
    audible_frame     posición del frame que el callback entrega ahora
    ui_frame          = audible_frame (la UI muestra lo audible)
"""

import collections
import logging
import math as _math
import threading
import time
from typing import Callable, Optional

import numpy as np
import sounddevice as sd
import soundfile as sf

from lorito_aldhiro.backend.core.lorito_identity import logger_name
from lorito_aldhiro.backend.telemetry.lorito_signal_intensity_meter import (
    SignalIntensityMeterEngine, SOURCE_PLAY,
)
from lorito_aldhiro.backend.playback.lorito_varispeed_reader import (
    VariableRateReader, _adapt_channels,
)
from lorito_aldhiro.backend.transport.lorito_transport_state import Direction, TransportMode
from lorito_aldhiro.backend.transport.lorito_transport_commands import TransportCommand
from lorito_aldhiro.backend.transport.lorito_transport_machine import (
    TransportMachine, InvalidTransitionError,
)
from lorito_aldhiro.backend.transport.lorito_speed_planner import (
    SpeedPlanner, SpeedPlannerConfig,
)
from lorito_aldhiro.backend.transport.lorito_transition_policy import (
    TransitionPolicy, TransitionRecord, DIP, XFADE_EQUAL_POWER, XFADE_LINEAR, CUT,
    FADE_OUT_END, CONTINUOUS,
)
from lorito_aldhiro.backend.transport.lorito_transport_ledger import (
    TransportTransaction, TransportLedger, APPLIED, CONFIRMED, SUPERSEDED, REJECTED,
)

__all__ = ["PlaybackEngine", "_adapt_channels", "PE_BLOCKSIZE", "PE_RING_SLOTS",
           "PE_TARGET_LEAD", "PE_SLEW_PER_S", "PE_MAX_RATIO"]

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES DEL MOTOR (contrato declarado)
# ─────────────────────────────────────────────────────────────────────────────
PE_BLOCKSIZE = 512          # frames por bloque del ring y por callback
PE_RING_SLOTS = 16          # capacidad del ring (bloques preasignados)
PE_TARGET_LEAD = 6          # bloques que el render mantiene por delante (~64 ms @48k)
PE_CACHE_FRAMES = 65_536    # caché de lectura de la fuente
PE_SLEW_PER_S = 8.0         # velocidad máxima de cambio del ratio (unidades/s)
PE_MAX_RATIO = 4.0          # |ratio| máximo aceptado
PE_PRELOAD_TIMEOUT = 2.0    # s — sin datos en este plazo, la sesión aborta
PE_STOP_TIMEOUT = 1.5       # s — espera del cierre con fundido antes del corte duro
PE_UNDERRUN_LIMIT = 5       # underruns consecutivos antes de avisar (fuera del callback)
PE_CB_TIMING_SAMPLES = 4096
# Orden SERVO-016 §6: por debajo de esta |velocidad| la salida se atenúa en
# proporción (|ratio| / umbral): una cinta detenida no produce señal (la
# salida de una cabeza inductiva es proporcional a la velocidad). Sin esto,
# con ratio 0 el lector repetía la misma muestra: corriente continua sostenida.
PE_SILENT_BELOW_RATIO = 0.05
PE_STAMP_SLOTS = 64         # sellos de tiempo audibles por época/generación
PE_RESPONSE_SAMPLES = 256

# Límites declarados del servo (§6): rangos, rampas, dirección, seek y
# política de datos fuera de rango. El motor los hace cumplir; los rangos
# de los widgets (Velocista 0,5–2,0; Morpher −0,7…1,5) son subconjuntos.
SERVO_LIMITS = {
    "ratio_min": -PE_MAX_RATIO, "ratio_max": PE_MAX_RATIO,
    "slew_ratio_per_s": PE_SLEW_PER_S,           # aceleración = desaceleración
    "accel_ratio_per_s": PE_SLEW_PER_S, "decel_ratio_per_s": PE_SLEW_PER_S,
    "direction": "signo del ratio; la reversa cruza 0 de forma continua",
    "silent_below_abs_ratio": PE_SILENT_BELOW_RATIO,
    "seek_range": "[0, total − 1] frames; fuera de rango se recorta y se declara",
    "non_finite_ratio": "comando RECHAZADO (contado); la velocidad vigente se conserva",
    "out_of_range_ratio": "recortado a ±ratio_max y declarado en el comando",
    "seek_transition": "según la política de transición (DIP por defecto)",
    "ui_velocista_range": (0.5, 2.0), "ui_morpher_range": (-0.7, 1.5),
}
SYNC_STATES = ("PRELOADING", "LOCKED", "SLEWING", "SEEKING", "STARVED",
               "STOPPING", "EOF", "ENDED", "FAILED")

_FLAG_END = 1
_FLAG_TRANSITION = 2
_FLAG_DEGRADED = 4

_plog = logging.getLogger(logger_name("playback_engine"))


class _Session:
    """Estado de UNA sesión de reproducción (generación de sesión). Nada
    de este estado es global de módulo (SMV-08)."""

    def __init__(self, gen: int, channels: int, rate: int, total: int):
        n, b = PE_RING_SLOTS, PE_BLOCKSIZE
        self.gen = gen
        self.channels = channels
        self.rate = rate
        self.total = total
        self.data = np.zeros((n, b, channels), dtype=np.float32)
        self.n = np.zeros(n, dtype=np.int64)
        self.tgen = np.zeros(n, dtype=np.int64)
        self.epoch = np.zeros(n, dtype=np.int64)
        self.src0 = np.zeros(n, dtype=np.float64)
        self.src1 = np.zeros(n, dtype=np.float64)
        self.ratio1 = np.zeros(n, dtype=np.float64)
        self.flags = np.zeros(n, dtype=np.int64)
        self.rms = np.zeros((n, 2), dtype=np.float64)
        # Medidor de Intensidad de Señal LCD (0.11.012): pico por canal de
        # cada bloque y número de bloque publicado en ese slot (para que el
        # hilo de supervisión descarte un slot ya reutilizado).
        self.peak = np.zeros((n, 2), dtype=np.float64)
        self.seq = np.full(n, -1, dtype=np.int64)
        # 0.14.004: cadena DSP que se escucha en la reproducción (o None).
        # Corre en el hilo de render (no-RT), como en el monolito de origen.
        self.dsp_filter: Optional[Callable] = None
        self.dsp_errors = 0
        self.meter_fed = 0         # bloques consumidos ya entregados al medidor
        self.w = 0                 # solo escribe el render
        self.r = 0                 # solo escribe el callback
        self.min_valid_gen = 0     # generación mínima aceptable en el callback
        # Estado del callback (solo lo toca el callback salvo lecturas).
        self.cb_pos = 0
        self.cb_last_tgen = -1
        self.cb_underrun_consec = 0
        self.cb_done = False
        self.cb_hard_stop = False
        self.audible_frame = 0.0
        self.audible_generation = -1
        self.audible_ratio = 1.0
        self.last_consumed_slot = -1
        self.cb_durations = np.zeros(PE_CB_TIMING_SAMPLES, dtype=np.float64)
        self.cb_count = 0
        # Render.
        self.stop_requested = False
        self.render_done = False
        self.eof = False
        self.ledger = TransportLedger()
        self.cmd_q = collections.deque()
        self.history = collections.deque(maxlen=256)
        self.transition_log = collections.deque(maxlen=256)
        self.requested_frame = 0.0
        self.read_head_frame = 0.0
        self.queued_head_frame = 0.0
        self.ratio_epoch = 0
        # Orden SERVO-016 §6 — telemetría en vivo del servo.
        self.live_mode = "PRELOADING"
        self.live_tgen = 0
        self.desired_ratio = 1.0
        self.applied_ratio = 1.0
        self.cb_starts = np.zeros(PE_CB_TIMING_SAMPLES, dtype=np.float64)
        self.cb_last_epoch = -1
        self.epoch_seen = np.full(PE_STAMP_SLOTS, -1, dtype=np.int64)
        self.epoch_t = np.zeros(PE_STAMP_SLOTS, dtype=np.float64)
        self.gen_seen = np.full(PE_STAMP_SLOTS, -1, dtype=np.int64)
        self.gen_t = np.zeros(PE_STAMP_SLOTS, dtype=np.float64)
        self.response_ms = collections.deque(maxlen=PE_RESPONSE_SAMPLES)
        self.render_ms = np.zeros(PE_CB_TIMING_SAMPLES, dtype=np.float64)
        self.render_count = 0
        self.disk_reads = 0
        self.starved = False
        self.stream_started = False
        self.failed_reason = ""


class PlaybackEngine:
    """
    Motor de reproducción streaming con velocidad variable y Transport Core
    como autoridad única. NUNCA carga el archivo completo en RAM.

    API pública (comandos semánticos, todos asíncronos y no bloqueantes
    salvo `start`/`stop`):
      start(path, rate, channels, start_frame, speed_ratio, on_done)
      stop()                      fundido STOP tras el audio encolado (espera)
      request_stop()              ídem, no bloqueante (GUI)
      set_speed(ratio)            SPEED_COMMIT (soltar Velocista / fin Morpher)
      set_speed_live(ratio)       SPEED_LIVE (arrastre; coalescing explícito)
      set_speed_live_noflush(r)   alias de SPEED_LIVE (retorno elástico)
      seek_to(frame)              SEEK transaccional (supersede al anterior)
      transport_snapshot()        cursores, generaciones, contadores, timing
      is_active()

    Atributos de solo lectura: src_pos (= audible_frame), src_total,
    src_rate, vu_l, vu_r.
    """

    def __init__(self, seek_policy: str = DIP):
        self._thread: Optional[threading.Thread] = None
        self._render_thread: Optional[threading.Thread] = None
        self._stream = None
        self._gen = 0
        self._lock = threading.Lock()          # solo start/stop (nunca el callback)
        self._sess: Optional[_Session] = None
        self._on_done: Optional[Callable] = None
        self.seek_policy = seek_policy
        self._policy = TransitionPolicy(seek_policy=seek_policy)
        self._start_frame = 0.0
        self.src_total = 0
        self.src_rate = 48000
        self.vu_l = 0.0
        self.vu_r = 0.0
        # Medidor de Intensidad de Señal LCD (0.11.012): mide cada bloque que
        # el callback consume (la salida audible, con el resampleo aplicado).
        self.signal_meter = SignalIntensityMeterEngine(SOURCE_PLAY, 2)
        self.event_log = None                  # ForensicEventLog opcional (fuera del RT)
        self.last_session_snapshot: Optional[dict] = None

    # ── Propiedades de cursor ────────────────────────────────────────────────
    @property
    def src_pos(self) -> float:
        """Posición AUDIBLE (lo que la UI debe mostrar)."""
        s = self._sess
        return float(s.audible_frame) if s is not None else float(self._start_frame)

    # ── API pública ──────────────────────────────────────────────────────────
    def start(self, path: str, rate: int, channels: int, start_frame: int,
              speed_ratio: float, on_done: Optional[Callable] = None,
              dsp_filter: Optional[Callable] = None) -> None:
        """`dsp_filter(block) -> block` (0.14.004): cadena DSP aplicada a cada
        bloque renderizado antes de publicarlo al callback; lo que se escucha
        en la reproducción es la señal procesada. El RAW en disco no cambia."""
        self.stop()
        try:
            with sf.SoundFile(path, "r") as probe:
                total = int(probe.frames)
        except Exception as exc:
            _plog.error("PlaybackEngine: no se pudo abrir %s: %s", path, exc)
            return
        ratio = self._clamp_ratio(speed_ratio)
        with self._lock:
            self._gen += 1
            sess = _Session(self._gen, int(channels), int(rate), total)
            sf0 = float(max(0, min(int(start_frame), max(total - 1, 0))))
            sess.audible_frame = sess.requested_frame = sess.read_head_frame = sf0
            sess.queued_head_frame = sf0
            sess.audible_ratio = ratio
            sess.dsp_filter = dsp_filter
            self._sess = sess
        self.src_total = total
        self.src_rate = int(rate)
        self._start_frame = float(start_frame)
        self._on_done = on_done
        self.vu_l = self.vu_r = 0.0
        self._thread = threading.Thread(
            target=self._play_loop, args=(sess, path, ratio),
            daemon=True, name="pe-play")
        self._thread.start()

    def request_stop(self) -> None:
        """STOP no bloqueante (hilo de GUI): encola el comando; el render
        publica el fundido + fin y la sesión termina sola."""
        sess = self._sess
        if sess is not None:
            self._submit(sess, "STOP", None, "UI")
            sess.stop_requested = True

    def stop(self) -> None:
        """Cierre ordenado: comando STOP → el render publica un fundido de
        salida y el marcador de fin; el callback termina el stream. Si no
        llega a tiempo (dispositivo colgado), corte duro declarado."""
        sess = self._sess
        if sess is not None:
            self._submit(sess, "STOP", None, "UI")
            sess.stop_requested = True
        t = self._thread
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=PE_STOP_TIMEOUT)
            if t.is_alive() and sess is not None:
                sess.cb_hard_stop = True
                stream = self._stream
                if stream is not None:
                    try:
                        stream.stop()
                    except Exception:
                        pass
                t.join(timeout=2.0)
        self._thread = None
        self._stream = None
        self.vu_l = 0.0
        self.vu_r = 0.0

    def set_speed(self, ratio: float) -> None:
        self._speed_command("COMMIT", ratio, "COMMIT")

    def set_speed_live(self, ratio: float) -> None:
        self._speed_command("LIVE", ratio, "LIVE")

    def set_speed_live_noflush(self, ratio: float) -> None:
        self._speed_command("LIVE", ratio, "ELASTIC")

    def seek_to(self, frame: int) -> None:
        """SEEK transaccional. Fuera de [0, total−1] se recorta y se DECLARA
        (razón del comando + `seek_clamped`); un destino no finito se
        rechaza."""
        sess = self._sess
        if sess is None:
            return
        try:
            raw = float(frame)
        except (TypeError, ValueError):
            raw = float("nan")
        if not _math.isfinite(raw):
            self._reject_input(sess, "SEEK", frame, "destino no finito")
            return
        last = float(max(sess.total - 1, 0))
        target = float(max(0, min(int(raw), int(last))))
        reason = ""
        if target != int(raw):
            sess.ledger.seek_clamped += 1
            reason = f"CLAMPED {int(raw)}→{int(target)}"
        sess.requested_frame = target
        self._submit(sess, "SEEK", target, "SEEK", reason)

    @property
    def generation(self) -> int:
        """Generación de la sesión de reproducción en curso (cambia con
        cada start); la interfaz la usa para distinguir reproducciones."""
        return self._gen

    def is_active(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def transport_snapshot(self) -> dict:
        s = self._sess
        if s is None:
            return dict(self.last_session_snapshot or {})
        return self._snapshot(s)

    # ── Internos: comandos ───────────────────────────────────────────────────
    @staticmethod
    def _clamp_ratio(ratio: float) -> float:
        """Recorte a ±PE_MAX_RATIO (usado al ARRANCAR, donde no hay comando
        que rechazar: un ratio no finito arranca a 1,0)."""
        r = float(ratio)
        if not _math.isfinite(r):
            r = 1.0
        return max(-PE_MAX_RATIO, min(PE_MAX_RATIO, r))

    def _reject_input(self, sess, kind, value, reason) -> None:
        tx = TransportTransaction(kind=kind, value=None, source="INPUT",
                                  session_generation=sess.gen)
        sess.ledger.commands_submitted += 1
        sess.ledger.inputs_rejected += 1
        self._record(sess, tx, REJECTED, f"{reason}: {value!r}")

    def _speed_command(self, kind: str, ratio, source: str) -> None:
        """§6 política de datos fuera de rango: un ratio no finito se
        RECHAZA (antes se convertía en 1,0 en silencio); fuera de ±máx se
        recorta y el comando lo declara."""
        sess = self._sess
        if sess is None:
            return
        try:
            r = float(ratio)
        except (TypeError, ValueError):
            r = float("nan")
        if not _math.isfinite(r):
            self._reject_input(sess, kind, ratio, "ratio no finito")
            return
        c = max(-PE_MAX_RATIO, min(PE_MAX_RATIO, r))
        reason = ""
        if c != r:
            sess.ledger.ratio_clamped += 1
            reason = f"CLAMPED {r:g}→{c:g}"
        self._submit(sess, kind, c, source, reason)

    def _submit(self, sess: Optional[_Session], kind: str, value, source: str,
                reason: str = "") -> None:
        if sess is None:
            return
        tx = TransportTransaction(kind=kind, value=value, source=source,
                                  session_generation=sess.gen, reason=reason)
        sess.ledger.commands_submitted += 1
        sess.cmd_q.append(tx)

    def _record(self, sess: _Session, tx: TransportTransaction, status: str,
                reason: str = "") -> None:
        tx.status = status
        if reason or status != APPLIED:
            tx.reason = reason or tx.reason
        if status == APPLIED:
            tx.t_apply = time.monotonic()
            if tx.command_id < sess.ledger.last_command_id_applied:
                sess.ledger.commands_out_of_order += 1
            sess.ledger.last_command_id_applied = tx.command_id
            sess.ledger.commands_applied += 1
        elif status == SUPERSEDED:
            sess.ledger.commands_superseded += 1
        elif status == REJECTED:
            sess.ledger.commands_rejected += 1
        sess.history.append(tx)

    def _drain_commands(self, sess, machine, planner, pending):
        """Aplica la cola EN ORDEN. Devuelve (seek_tx|None, confirm_list).
        `pending` = seek aún no renderizado (puede quedar supersedido)."""
        to_confirm = []
        last_live = None
        while sess.cmd_q:
            tx = sess.cmd_q.popleft()
            try:
                if tx.kind == "SEEK":
                    if pending is not None:
                        self._record(sess, pending, SUPERSEDED, f"reemplazado por #{tx.command_id}")
                    pending = tx
                elif tx.kind == "LIVE":
                    if last_live is not None:
                        sess.ledger.live_coalesced += 1
                    last_live = tx
                    if machine.state.mode not in (TransportMode.SPEED_LIVE,
                                                  TransportMode.MORPHER_LIVE):
                        machine.apply(TransportCommand.set_target_speed(tx.value))
                    else:
                        machine.state.target_speed = tx.value
                    planner.update_desired(tx.value)
                    sess.ratio_epoch += 1
                    tx.epoch = sess.ratio_epoch
                    tx.transport_generation = machine.state.transport_generation
                    self._record(sess, tx, APPLIED)
                    to_confirm.append(tx)
                elif tx.kind == "COMMIT":
                    if machine.state.mode not in (TransportMode.SPEED_LIVE,):
                        machine.apply(TransportCommand.set_target_speed(tx.value))
                    machine.state.target_speed = tx.value
                    machine.apply(TransportCommand.commit_speed())
                    planner.update_desired(tx.value)
                    sess.ratio_epoch += 1
                    tx.epoch = sess.ratio_epoch
                    tx.transport_generation = machine.state.transport_generation
                    self._record(sess, tx, APPLIED)
                    to_confirm.append(tx)
                elif tx.kind == "STOP":
                    if machine.state.mode not in (TransportMode.STOPPING,
                                                  TransportMode.EOF):
                        machine.apply(TransportCommand.stop())
                    tx.transport_generation = machine.state.transport_generation
                    self._record(sess, tx, APPLIED)
                    sess.stop_requested = True
                    if pending is not None:
                        self._record(sess, pending, SUPERSEDED, "STOP")
                        pending = None
                else:
                    self._record(sess, tx, REJECTED, "tipo desconocido")
            except InvalidTransitionError as exc:
                self._record(sess, tx, REJECTED, str(exc))
        return pending, to_confirm

    # ── Internos: ring ───────────────────────────────────────────────────────
    def _publish(self, sess: _Session, slot: int, n: int, tgen: int, src0: float,
                 src1: float, ratio1: float, flags: int) -> None:
        sess.n[slot] = n
        sess.tgen[slot] = tgen
        sess.epoch[slot] = sess.ratio_epoch
        sess.src0[slot] = src0
        sess.src1[slot] = src1
        sess.ratio1[slot] = ratio1
        sess.flags[slot] = flags
        if n:
            blk = sess.data[slot, :n]
            l2 = float(np.mean(blk[:, 0].astype(np.float64) ** 2))
            r2 = float(np.mean(blk[:, -1].astype(np.float64) ** 2))
            sess.rms[slot, 0] = l2 ** 0.5
            sess.rms[slot, 1] = r2 ** 0.5
            sess.peak[slot, 0] = float(np.max(np.abs(blk[:, 0])))
            sess.peak[slot, 1] = float(np.max(np.abs(blk[:, -1])))
        sess.seq[slot] = sess.w
        # Etiqueta comprobada ANTES de entrar al ring audible.
        if tgen < sess.min_valid_gen:
            sess.ledger.stale_dropped_before_ring += 1
            return
        sess.queued_head_frame = src1
        sess.w += 1                      # publicación (el slot ya está completo)
        sess.ledger.blocks_published += 1

    # ── Hilo de render (no-RT) ───────────────────────────────────────────────
    @staticmethod
    def _apply_dsp(sess: _Session, buf: np.ndarray, n_valid: int) -> None:
        """Pasa los frames válidos del bloque por la cadena DSP de la sesión.
        Si la cadena falla, el bloque sale sin procesar y se cuenta (nunca
        silencio ni corte: mismo criterio que el monolito de origen)."""
        dsp = sess.dsp_filter
        if dsp is None or n_valid <= 0:
            return
        try:
            out = dsp(buf[:n_valid])
            if out is not None and out.shape == buf[:n_valid].shape:
                buf[:n_valid] = out
            else:
                sess.dsp_errors += 1
        except Exception as exc:
            sess.dsp_errors += 1
            if sess.dsp_errors <= 3:
                _plog.error("PlaybackEngine: fallo DSP (%s) — bloque sin procesar", exc)

    def _render_loop(self, sess: _Session, path: str, ratio0: float) -> None:
        B = PE_BLOCKSIZE
        policy = self._policy
        machine = TransportMachine()
        machine.apply(TransportCommand.play(
            Direction.REVERSE if ratio0 < 0 else Direction.FORWARD))
        machine.state.speed_ratio = machine.state.target_speed = ratio0
        planner = SpeedPlanner(SpeedPlannerConfig(
            max_step_per_tick=PE_SLEW_PER_S * B / max(sess.rate, 1),
            min_ratio=-PE_MAX_RATIO, max_ratio=PE_MAX_RATIO), initial_ratio=ratio0)
        tmp = np.zeros((B, sess.channels), dtype=np.float32)
        period = B / max(sess.rate, 1)
        pending = None
        # Comandos APLICADOS que esperan su primer bloque publicado. Persiste
        # entre iteraciones: si el ring está lleno, el render duerme y antes
        # se perdía la lista (comandos aplicados que nunca llegaban a
        # CONFIRMED).
        awaiting = []
        try:
            with sf.SoundFile(path, "r") as f:
                reader = VariableRateReader(f, sess.channels, block=B,
                                            cache_frames=PE_CACHE_FRAMES,
                                            max_ratio=PE_MAX_RATIO)
                reader.seek(sess.read_head_frame)
                while not sess.cb_hard_stop:
                    pending, newly = self._drain_commands(sess, machine, planner, pending)
                    awaiting.extend(newly)
                    sess.live_mode = machine.state.mode.name
                    sess.live_tgen = machine.state.transport_generation
                    sess.desired_ratio = planner.desired_ratio
                    sess.applied_ratio = planner.applied_ratio
                    sess.disk_reads = getattr(reader, "disk_reads", 0)
                    if sess.w - sess.r >= PE_TARGET_LEAD and not sess.stop_requested:
                        time.sleep(period / 3)
                        continue
                    if sess.w - sess.r >= PE_RING_SLOTS:
                        time.sleep(period / 3)
                        continue
                    slot = sess.w % PE_RING_SLOTS
                    buf = sess.data[slot]
                    t_render0 = time.perf_counter()
                    r0 = planner.applied_ratio
                    if sess.stop_requested:
                        # STOP: continuación con fundido + marcador de fin.
                        n_valid, p0, p1 = reader.render(buf, B, r0, r0)
                        self._apply_dsp(sess, buf, n_valid)
                        m, deg = policy.fade_out_tail(buf, min(n_valid, policy.stop_fade),
                                                      policy.stop_fade)
                        buf[min(n_valid, policy.stop_fade):] = 0.0
                        self._log_transition(sess, "STOP", FADE_OUT_END, policy.stop_fade, m,
                                             deg, "audio insuficiente" if deg else "",
                                             machine.state.transport_generation)
                        self._publish(sess, slot, B, machine.state.transport_generation,
                                      p0, p1, r0, _FLAG_TRANSITION)
                        self._publish_end(sess, machine)
                        break
                    r1 = planner.step()
                    flags = 0
                    if pending is not None:
                        tx = pending
                        pending = None
                        try:
                            machine.apply(TransportCommand.seek(int(tx.value)))
                        except InvalidTransitionError as exc:
                            self._record(sess, tx, REJECTED, str(exc))
                            continue
                        tx.transport_generation = machine.state.transport_generation
                        self._record(sess, tx, APPLIED)
                        p0, p1, n_valid, flags = self._render_seek(
                            sess, reader, policy, buf, tmp, tx.value, r0, r1,
                            machine.state.transport_generation)
                        awaiting.append(tx)
                        machine.apply(TransportCommand(kind=_SEEK_DONE))
                    else:
                        n_valid, p0, p1 = reader.render(buf, B, r0, r1)
                    if n_valid and min(abs(r0), abs(r1)) < PE_SILENT_BELOW_RATIO:
                        ramp = r0 + (r1 - r0) * (np.arange(n_valid) + 1.0) / B
                        buf[:n_valid] *= np.minimum(1.0, np.abs(ramp) / PE_SILENT_BELOW_RATIO
                                                    ).astype(np.float32)[:, None]
                    self._apply_dsp(sess, buf, n_valid)
                    dt_render = time.perf_counter() - t_render0
                    sess.render_ms[sess.render_count % PE_CB_TIMING_SAMPLES] = dt_render * 1e3
                    sess.render_count += 1
                    if dt_render > period:
                        sess.ledger.slow_reads += 1
                    planner.report_rendered(r1)
                    machine.state.speed_ratio = r1
                    self._sync_direction(machine, r1)
                    sess.read_head_frame = reader.pos
                    eof = n_valid < B
                    if eof:
                        m, deg = policy.fade_out_tail(buf, n_valid, policy.eof_fade)
                        self._log_transition(sess, "EOF", FADE_OUT_END, policy.eof_fade, m,
                                             deg, "bloque final más corto que el fundido"
                                             if deg else "", machine.state.transport_generation)
                        flags |= _FLAG_TRANSITION | (_FLAG_DEGRADED if deg else 0)
                    if n_valid or not eof:
                        self._publish(sess, slot, n_valid, machine.state.transport_generation,
                                      p0, p1, r1, flags)
                    now = time.monotonic()
                    for tx in awaiting:
                        if tx.status == APPLIED:
                            # 0.14.004: el contador antes que el estado — quien
                            # ve CONFIRMED ve también el ledger ya sumado (antes,
                            # bajo carga, se leía "todo confirmado" con el
                            # contador un comando atrás).
                            tx.t_confirm = now
                            sess.ledger.commands_confirmed += 1
                            tx.status = CONFIRMED
                    awaiting.clear()
                    if eof:
                        sess.eof = True
                        if machine.state.mode not in (TransportMode.STOPPING,):
                            machine.state.mode = TransportMode.EOF
                        self._publish_end(sess, machine)
                        break
        except Exception as exc:
            _plog.error("PlaybackEngine render: %s", exc)
            sess.cb_hard_stop = True
        finally:
            sess.render_done = True
            sess.final_mode = machine.state.mode.name
            sess.final_tgen = machine.state.transport_generation
            sess.final_ratio_applied = planner.applied_ratio
            sess.final_ratio_desired = planner.desired_ratio
            sess.live_mode = sess.final_mode
            sess.desired_ratio = planner.desired_ratio
            sess.applied_ratio = planner.applied_ratio

    def _publish_end(self, sess: _Session, machine) -> None:
        while sess.w - sess.r >= PE_RING_SLOTS and not sess.cb_hard_stop:
            time.sleep(0.002)
        slot = sess.w % PE_RING_SLOTS
        self._publish(sess, slot, 0, machine.state.transport_generation,
                      sess.queued_head_frame, sess.queued_head_frame, 0.0, _FLAG_END)

    def _render_seek(self, sess, reader, policy, buf, tmp, target, r0, r1, tgen):
        """Bloque de transición de SEEK según la política declarada."""
        B = PE_BLOCKSIZE
        kind = policy.seek_policy
        flags = _FLAG_TRANSITION
        degraded = False
        reason = ""
        if kind == DIP:
            k_out = policy.dip_out
            nv_old, _, _ = reader.render(buf, k_out, r0, r0)
            buf[:k_out] *= policy.ramp_down(k_out)[:, None]
            reader.seek(target)
            n_new = B - k_out
            nv_new, p0n, p1 = reader.render(tmp, n_new, r0, r1)
            buf[k_out:B] = tmp[:n_new]
            fin = min(policy.dip_in, nv_new)
            if fin < policy.dip_in:
                degraded, reason = True, "destino con menos frames que el fundido de entrada"
            if fin:
                ramp = policy.ramp_up(policy.dip_in) if fin == policy.dip_in else \
                    (0.5 - 0.5 * np.cos(np.pi * (np.arange(fin) + 0.5) / fin)).astype(np.float32)
                buf[k_out:k_out + fin] *= ramp[:, None]
            applied = k_out + fin
            planned = policy.dip_out + policy.dip_in
            n_valid = k_out + nv_new
            p0 = target - k_out * r0
        elif kind in (XFADE_EQUAL_POWER, XFADE_LINEAR):
            xf = policy.xfade
            nv_old, _, _ = reader.render(tmp, xf, r0, r0)
            reader.seek(target)
            nv_new, p0, p1 = reader.render(buf, B, r0, r1)
            n_mix = min(xf, nv_old, nv_new)
            if n_mix < xf:
                degraded, reason = True, "audio insuficiente para la ventana completa"
            if n_mix:
                policy.crossfade(tmp, buf, n_mix, kind)
            applied, planned, n_valid = n_mix, xf, nv_new
        else:  # CUT
            reader.seek(target)
            n_valid, p0, p1 = reader.render(buf, B, r0, r1)
            applied = planned = 0
        if degraded:
            flags |= _FLAG_DEGRADED
        self._log_transition(sess, "SEEK", kind, planned, applied, degraded, reason, tgen)
        return p0, p1, n_valid, flags

    def _log_transition(self, sess, op, kind, planned, applied, degraded, reason, tgen):
        rec = TransitionRecord(op, kind, int(planned), int(applied), bool(degraded), reason, tgen)
        sess.transition_log.append(rec)
        sess.ledger.transitions[f"{op}:{kind}"] += 1
        if degraded:
            sess.ledger.degraded_transitions += 1
        log = self.event_log
        if log is not None:
            try:
                log.emit("playback.transport", "WARNING" if degraded else "INFO",
                         f"TRANSITION_{op}", data=rec.__dict__)
            except Exception:
                pass

    @staticmethod
    def _sync_direction(machine, ratio: float) -> None:
        d = Direction.REVERSE if ratio < 0 else Direction.FORWARD
        if machine.state.direction != d:
            machine.state.direction = d
            if machine.state.mode in (TransportMode.PLAY_FORWARD, TransportMode.PLAY_REVERSE):
                machine.state.mode = (TransportMode.PLAY_REVERSE if d == Direction.REVERSE
                                      else TransportMode.PLAY_FORWARD)

    # ── Callback RT ──────────────────────────────────────────────────────────
    @staticmethod
    def _make_callback(sess: _Session):
        data, nmeta, tgen = sess.data, sess.n, sess.tgen
        src0, src1, flags_a, ratio1 = sess.src0, sess.src1, sess.flags, sess.ratio1
        epoch_a = sess.epoch
        durs = sess.cb_durations
        starts = sess.cb_starts
        epoch_seen, epoch_t = sess.epoch_seen, sess.epoch_t
        gen_seen, gen_t = sess.gen_seen, sess.gen_t
        NS = PE_RING_SLOTS
        NST = PE_STAMP_SLOTS
        ledger = sess.ledger
        perf = time.perf_counter
        mono = time.monotonic
        CallbackStop = sd.CallbackStop

        def _audio_cb(outdata, frames, time_info, status):
            t0 = perf()
            starts[sess.cb_count % PE_CB_TIMING_SAMPLES] = t0
            if sess.cb_hard_stop or sess.cb_done:
                outdata.fill(0)
                raise CallbackStop()
            written = 0
            while written < frames:
                if sess.r == sess.w:
                    # Underrun: silencio EXPLÍCITO y contabilizado.
                    outdata[written:] = 0
                    ledger.underrun_events += 1
                    ledger.underrun_frames += frames - written
                    ledger.last_underrun_generation = sess.audible_generation
                    sess.cb_underrun_consec += 1
                    break
                slot = sess.r % NS
                g = tgen[slot]
                if g < sess.min_valid_gen:
                    # SV-01: un bloque de una generación ya superada (tardío)
                    # jamás suena ni mueve el cursor audible.
                    ledger.stale_discarded_in_callback += 1
                    sess.r += 1
                    sess.cb_pos = 0
                    continue
                if g > sess.min_valid_gen:
                    sess.min_valid_gen = g      # puerta monotónica (solo la escribe el callback)
                if flags_a[slot] & _FLAG_END:
                    outdata[written:] = 0
                    sess.cb_done = True
                    sess.r += 1
                    raise CallbackStop()
                if g < sess.cb_last_tgen:
                    ledger.mixed_generation_events += 1
                sess.cb_last_tgen = g
                n = nmeta[slot]
                pos = sess.cb_pos
                if pos == 0:
                    ep = epoch_a[slot]
                    if ep != sess.cb_last_epoch:
                        epoch_seen[ep % NST] = ep
                        epoch_t[ep % NST] = mono()
                        sess.cb_last_epoch = ep
                    if gen_seen[g % NST] != g:
                        gen_seen[g % NST] = g
                        gen_t[g % NST] = mono()
                take = n - pos
                need = frames - written
                if take > need:
                    take = need
                outdata[written:written + take] = data[slot, pos:pos + take]
                written += take
                pos += take
                a, b = src0[slot], src1[slot]
                sess.audible_frame = a + (b - a) * (pos / n) if n else b
                sess.audible_generation = g
                sess.audible_ratio = ratio1[slot]
                sess.cb_underrun_consec = 0
                if pos >= n:
                    sess.last_consumed_slot = slot
                    ledger.blocks_consumed += 1
                    sess.r += 1
                    sess.cb_pos = 0
                else:
                    sess.cb_pos = pos
            durs[sess.cb_count % PE_CB_TIMING_SAMPLES] = perf() - t0
            sess.cb_count += 1

        return _audio_cb

    # ── Hilo de sesión: render + stream + monitor ────────────────────────────
    def _play_loop(self, sess: _Session, path: str, ratio0: float) -> None:
        render = threading.Thread(target=self._render_loop, args=(sess, path, ratio0),
                                  daemon=True, name="pe-render")
        self._render_thread = render
        render.start()
        t0 = time.monotonic()
        while (sess.w < min(PE_TARGET_LEAD, 2) and not sess.render_done
               and not sess.stop_requested and time.monotonic() - t0 < PE_PRELOAD_TIMEOUT):
            time.sleep(0.002)
        try:
            if sess.w == 0:
                sess.failed_reason = f"PRELOAD_TIMEOUT ({PE_PRELOAD_TIMEOUT:.1f} s sin datos)"
                _plog.warning("PlaybackEngine: sin datos en %.1fs, abortando", PE_PRELOAD_TIMEOUT)
                return
            self._stream = sd.OutputStream(
                samplerate=sess.rate, channels=sess.channels, dtype="float32",
                blocksize=PE_BLOCKSIZE, latency="low", callback=self._make_callback(sess))
            # Copia local: otro hilo (stop) puede anular self._stream.
            stream_local = self._stream
            self.signal_meter.sample_rate = sess.rate
            self.signal_meter.reset()
            sess.meter_fed = sess.r
            with stream_local:
                sess.stream_started = True
                warn_last = 0.0
                while stream_local.active:
                    if sess.cb_hard_stop or sess.gen != self._gen:
                        break
                    time.sleep(0.020)
                    self._feed_signal_meter(sess)
                    slot = sess.last_consumed_slot
                    if slot >= 0:
                        for i, attr in ((0, "vu_l"), (1, "vu_r")):
                            db = max(-60.0, min(0.0, 20.0 * _math.log10(
                                max(sess.rms[slot, i], 1e-12))))
                            cur = getattr(self, attr)
                            setattr(self, attr, cur + 0.35 * ((db + 60) / 60 - cur))
                    self._update_response_times(sess)
                    uc = sess.cb_underrun_consec
                    now = time.monotonic()
                    if uc >= PE_UNDERRUN_LIMIT:
                        if not sess.starved:
                            sess.starved = True          # §6: estado STARVED, no solo un log
                            sess.ledger.starved_episodes += 1
                        if now - warn_last > 5.0:
                            warn_last = now
                            _plog.warning("PE UNDERRUN prolongado: %d callbacks consecutivos", uc)
                    elif uc == 0:
                        sess.starved = False
        except Exception as exc:
            sess.failed_reason = f"STREAM_ERROR: {exc}"
            _plog.error("PlaybackEngine OutputStream: %s", exc)
        finally:
            sess.cb_hard_stop = True
            render.join(timeout=3.0)
            self._update_response_times(sess)
            self.last_session_snapshot = self._snapshot(sess)
            self.vu_l = self.vu_r = 0.0
            self._stream = None
            if sess.gen == self._gen and self._on_done:
                self._on_done()

    # ── Telemetría (fuera del RT) ────────────────────────────────────────────
    def _feed_signal_meter(self, sess: _Session) -> int:
        """Entrega al medidor, en orden, los bloques que el callback ya
        consumió desde la última llamada (hilo de supervisión, no-RT). Un
        slot reutilizado por el render (número de bloque distinto) o de una
        generación descartada no se mide: se pierde una actualización
        visual, nunca audio. Devuelve los bloques medidos."""
        r = sess.r
        fed = sess.meter_fed
        if r - fed > PE_RING_SLOTS:
            fed = r - PE_RING_SLOTS
        measured = 0
        meter = self.signal_meter
        while fed < r:
            slot = fed % PE_RING_SLOTS
            n = int(sess.n[slot])
            if (sess.seq[slot] == fed and n > 0
                    and sess.tgen[slot] >= sess.min_valid_gen):
                meter.process_block_stats(sess.peak[slot], sess.rms[slot], n, sess.rate)
                measured += 1
            fed += 1
        sess.meter_fed = fed
        return measured

    @staticmethod
    def _update_response_times(sess: _Session) -> None:
        """Tiempo de respuesta comando → AUDIBLE (§6): con los sellos que el
        callback deja la primera vez que suena una época de velocidad o una
        generación de transporte. Fuera del RT (hilo de supervisión)."""
        for tx in list(sess.history)[-64:]:
            if tx.t_audible is not None or tx.status != CONFIRMED:
                continue
            if tx.kind in ("LIVE", "COMMIT") and tx.epoch is not None:
                k = tx.epoch % PE_STAMP_SLOTS
                if sess.epoch_seen[k] == tx.epoch:
                    tx.t_audible = float(sess.epoch_t[k])
                elif sess.cb_last_epoch > tx.epoch:
                    tx.t_audible = -1.0          # coalescido: nunca sonó por sí mismo
                    continue
            elif tx.kind == "SEEK" and tx.transport_generation is not None:
                g = tx.transport_generation
                k = g % PE_STAMP_SLOTS
                if sess.gen_seen[k] == g:
                    tx.t_audible = float(sess.gen_t[k])
            if tx.t_audible is not None and tx.t_audible > 0:
                sess.response_ms.append(max(0.0, (tx.t_audible - tx.t_submit) * 1e3))

    @staticmethod
    def _sync_state(s: _Session) -> str:
        if s.failed_reason:
            return "FAILED"
        if s.cb_done or (s.render_done and s.cb_hard_stop):
            return "ENDED"
        if not s.stream_started:
            return "PRELOADING"
        if s.starved:
            return "STARVED"
        if s.eof or s.live_mode == "EOF":
            return "EOF"
        if s.stop_requested or s.live_mode == "STOPPING":
            return "STOPPING"
        if s.live_tgen > s.audible_generation >= 0 or s.live_mode in ("SEEKING", "SEEK"):
            return "SEEKING"
        if abs(s.desired_ratio - s.applied_ratio) > 1e-6 or \
                abs(s.applied_ratio - s.audible_ratio) > 1e-6:
            return "SLEWING"
        return "LOCKED"

    @staticmethod
    def _stats(values) -> dict:
        v = np.asarray(values, dtype=np.float64)
        if v.size == 0:
            return {"n": 0}
        v = np.sort(v)
        pick = lambda q: float(v[min(v.size - 1, int(q * v.size))])   # noqa: E731
        return {"n": int(v.size), "p50": pick(0.5), "p95": pick(0.95), "max": float(v[-1])}

    def _snapshot(self, s: _Session) -> dict:
        n = min(s.cb_count, PE_CB_TIMING_SAMPLES)
        timing = {"callbacks": s.cb_count}
        if n:
            d = np.sort(s.cb_durations[:n])
            for name, q in (("p50", 0.5), ("p95", 0.95), ("p99", 0.99), ("p999", 0.999)):
                timing[name + "_ms"] = float(d[min(n - 1, int(q * n))] * 1e3)
            timing["max_ms"] = float(d[-1] * 1e3)
            timing["deadline_ms"] = PE_BLOCKSIZE / max(s.rate, 1) * 1e3
            timing["deadline_misses"] = int(np.count_nonzero(d * 1e3 > timing["deadline_ms"]))
        # Jitter (§6): desviación del intervalo ENTRE callbacks respecto del
        # período nominal (no la duración del callback, que es otra métrica).
        jitter = {"n": 0}
        if n >= 3:
            idx = np.arange(s.cb_count - n, s.cb_count) % PE_CB_TIMING_SAMPLES
            iv = np.diff(s.cb_starts[idx]) * 1e3
            nominal = PE_BLOCKSIZE / max(s.rate, 1) * 1e3
            jitter = self._stats(np.abs(iv - nominal))
            jitter["nominal_ms"] = nominal
        nr = min(s.render_count, PE_CB_TIMING_SAMPLES)
        render = self._stats(s.render_ms[:nr])
        render.update({"slow_reads": s.ledger.slow_reads, "disk_reads": s.disk_reads})
        return {
            "session_generation": s.gen,
            "transport_generation": getattr(s, "final_tgen", s.live_tgen),
            "mode": getattr(s, "final_mode", s.live_mode),
            "sync_state": self._sync_state(s),
            "failed_reason": s.failed_reason,
            "requested_ratio": s.desired_ratio,
            "applied_ratio": s.applied_ratio,
            "effective_ratio": s.audible_ratio,
            "jitter_ms": jitter,
            "response_ms": self._stats(list(s.response_ms)),
            "render_ms": render,
            "stale_blocks": (s.ledger.stale_dropped_before_ring
                             + s.ledger.stale_discarded_in_callback),
            "limits": dict(SERVO_LIMITS),
            "requested_frame": s.requested_frame,
            "read_head_frame": s.read_head_frame,
            "queued_head_frame": s.queued_head_frame,
            "audible_frame": s.audible_frame,
            "ui_frame": s.audible_frame,
            "audible_generation": s.audible_generation,
            "audible_ratio": s.audible_ratio,
            "ratio_epoch": s.ratio_epoch,
            "ring_lead_blocks": s.w - s.r,
            "eof": s.eof,
            "seek_policy": self.seek_policy,
            "ledger": s.ledger.as_dict(),
            "callback_timing": timing,
            "transactions": [tx.as_dict() for tx in list(s.history)[-32:]],
            "transitions": [r.__dict__ for r in list(s.transition_log)[-32:]],
        }


# SEEK_DONE es un comando interno del motor (no lo emite la UI).
from lorito_aldhiro.backend.transport.lorito_transport_commands import CommandKind as _CK  # noqa: E402
_SEEK_DONE = _CK.SEEK_DONE
