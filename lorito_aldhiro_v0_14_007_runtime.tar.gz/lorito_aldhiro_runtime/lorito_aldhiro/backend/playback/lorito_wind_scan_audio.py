from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Sonido del bobinado (cue/review): durante FF/REW se oye la cinta acelerada, al derecho o en reversa, a la velocidad real del motor.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Hasta 0.14.004 el bobinado era mudo por política (`MUTED_SCAN`, orden
TRANSPORT-018): la usuaria pidió oír el sonido acelerado al rebobinar y al
avanzar rápido, como un deck con cue/review.

Cómo suena: cada bloque de salida (B frames de tiempo real) cubre
`|rate| × B` frames de programa, leídos a partir de la posición del motor
(hacia adelante en FF; hacia atrás y al revés en REW). Se reducen a B frames
promediando grupos consecutivos (un filtro de caja que hace de antialias
simple): el resultado es el "chirrido" agudo característico del bobinado.
Nivel −6 dB y fundidos de entrada/salida para no golpear al empezar o parar.

Hilos: la UI informa posición y velocidad del motor (`update`, 25 Hz); un hilo
lector prepara los bloques (no-RT, con disco); el callback del stream solo
copia bloques ya hechos (sin disco, sin locks de la aplicación). El cursor
propio avanza con la velocidad y se reengancha a la posición confirmada del
motor si se aparta más de 250 ms de programa más lo que el motor recorre en
300 ms (a ×32 el motor avanza 1,28 s de programa entre dos ticks de la UI).
El RAW nunca se modifica.
"""

import logging
import threading
import time
from collections import deque
from typing import Callable, Optional

import numpy as np

from lorito_aldhiro.backend.core.lorito_identity import logger_name, thread_name

_log = logging.getLogger(logger_name("wind_scan"))

SCAN_BLOCK = 1024          # frames de salida por bloque (~21 ms a 48 kHz)
SCAN_GAIN = 0.5            # −6 dB, nivel de cue típico de un deck
SCAN_QUEUE = 4             # bloques preparados por delante del callback
RESYNC_S = 0.25            # deriva tolerada respecto de la posición del motor…
RESYNC_LAG_S = 0.3         # …más lo que el motor recorre en este tiempo (tick
                           # de la UI de 40 ms + bloques preparados + margen)


def compress_span(span: np.ndarray, out_frames: int) -> np.ndarray:
    """Reduce `span` (n × ch) a `out_frames` promediando grupos contiguos.
    Con n < out_frames repite muestras (velocidad < ×1, solo en frenadas)."""
    n = span.shape[0]
    ch = span.shape[1]
    if n == 0:
        return np.zeros((out_frames, ch), dtype=np.float32)
    if n <= out_frames:
        idx = np.minimum((np.arange(out_frames) * n) // out_frames, n - 1)
        return span[idx].astype(np.float32, copy=False)
    edges = np.linspace(0, n, out_frames + 1).astype(np.int64)
    cs = np.vstack([np.zeros((1, ch), dtype=np.float64),
                    np.cumsum(span, axis=0, dtype=np.float64)])
    width = np.maximum(edges[1:] - edges[:-1], 1)[:, None]
    return ((cs[edges[1:]] - cs[edges[:-1]]) / width).astype(np.float32)


class WindScanAudio:
    """Salida de audio del bobinado. `start` → `update` (cada tick) → `stop`."""

    def __init__(self, stream_factory: Optional[Callable] = None,
                 soundfile_module=None):
        self._stream_factory = stream_factory
        self._sf = soundfile_module
        self._lock = threading.Lock()
        self._active = False
        self._target_frame = 0.0
        self._velocity_fps = 0.0
        self._queue: deque = deque(maxlen=SCAN_QUEUE * 2)
        self._thread: Optional[threading.Thread] = None
        self._stream = None
        self._stop_evt = threading.Event()
        self._fading_out = False
        self.blocks_rendered = 0
        self.underruns = 0

    # ── API (hilo de la UI) ──────────────────────────────────────────────
    @property
    def active(self) -> bool:
        return self._active

    def start(self, path: str, sample_rate: int, position_frame: int,
              velocity_fps: float = 0.0) -> bool:
        """Abre el archivo y la salida. False si no hay dispositivo o
        archivo: el bobinado sigue, mudo, como antes."""
        self.stop()
        sf = self._sf
        if sf is None:
            import soundfile as sf
        try:
            f = sf.SoundFile(path, "r")
        except Exception as e:
            _log.warning("Bobinado sin sonido: no se pudo abrir %s (%s)", path, e)
            return False
        sr = int(getattr(f, "samplerate", sample_rate) or sample_rate)
        ch = int(getattr(f, "channels", 2) or 2)
        with self._lock:
            self._target_frame = float(position_frame)
            self._velocity_fps = float(velocity_fps)
        self._queue.clear()
        self._stop_evt.clear()
        self._fading_out = False
        try:
            factory = self._stream_factory
            if factory is None:
                import sounddevice as sd
                factory = sd.OutputStream
            self._stream = factory(samplerate=sr, channels=ch, dtype="float32",
                                   blocksize=SCAN_BLOCK, latency="low",
                                   callback=self._callback)
        except Exception as e:
            _log.warning("Bobinado sin sonido: no se pudo abrir la salida (%s)", e)
            f.close()
            self._stream = None
            return False
        self._active = True
        self._thread = threading.Thread(target=self._reader_loop, args=(f, sr, ch),
                                        daemon=True, name=thread_name("wind-scan"))
        self._thread.start()
        try:
            self._stream.start()
        except Exception as e:
            _log.warning("Bobinado sin sonido: la salida no arrancó (%s)", e)
            self.stop()
            return False
        return True

    def update(self, position_frame: int, velocity_fps: float) -> None:
        with self._lock:
            self._target_frame = float(position_frame)
            self._velocity_fps = float(velocity_fps)

    def stop(self) -> None:
        if not self._active and self._thread is None:
            return
        self._fading_out = True
        self._stop_evt.set()
        t = self._thread
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=1.0)
        self._thread = None
        stream = self._stream
        self._stream = None
        if stream is not None:
            try:
                time.sleep(SCAN_BLOCK * 2 / 48000.0)   # deja salir el fundido
                stream.stop()
                stream.close()
            except Exception:
                pass
        self._queue.clear()
        self._active = False

    # ── Hilo lector (no-RT) ──────────────────────────────────────────────
    def _reader_loop(self, f, sr: int, ch: int) -> None:
        B = SCAN_BLOCK
        total = int(getattr(f, "frames", 0) or 0)
        with self._lock:
            cursor = self._target_frame
        first = True
        try:
            while not self._stop_evt.is_set():
                if len(self._queue) >= SCAN_QUEUE:
                    time.sleep(B / sr / 2)
                    continue
                with self._lock:
                    target, vel = self._target_frame, self._velocity_fps
                if abs(cursor - target) > RESYNC_S * sr + abs(vel) * RESYNC_LAG_S:
                    cursor = target
                step = vel * B / sr                  # frames de programa por bloque
                span_n = int(round(abs(step)))
                if span_n <= 0:
                    block = np.zeros((B, ch), dtype=np.float32)
                else:
                    if step > 0:
                        a = int(max(0, min(cursor, total)))
                        b = int(max(0, min(cursor + span_n, total)))
                    else:
                        a = int(max(0, min(cursor - span_n, total)))
                        b = int(max(0, min(cursor, total)))
                    if b > a:
                        f.seek(a)
                        span = f.read(b - a, dtype="float32", always_2d=True)
                        if step < 0:
                            span = span[::-1]
                        block = compress_span(span, B)
                    else:
                        block = np.zeros((B, ch), dtype=np.float32)
                    cursor += step
                block *= SCAN_GAIN
                if first:
                    block *= np.linspace(0.0, 1.0, B, dtype=np.float32)[:, None]
                    first = False
                self._queue.append(block)
                self.blocks_rendered += 1
        except Exception as e:
            _log.warning("Bobinado: lectura interrumpida (%s)", e)
        finally:
            try:
                f.close()
            except Exception:
                pass

    # ── Callback (RT): solo copia ────────────────────────────────────────
    def _callback(self, outdata, frames, t, status) -> None:
        try:
            block = self._queue.popleft()
        except IndexError:
            outdata[:] = 0.0
            self.underruns += 1
            return
        n = min(frames, block.shape[0])
        outdata[:n] = block[:n]
        if n < frames:
            outdata[n:] = 0.0
        if self._fading_out:
            outdata[:n] *= np.linspace(1.0, 0.0, n, dtype=np.float32)[:, None]
            self._queue.clear()
