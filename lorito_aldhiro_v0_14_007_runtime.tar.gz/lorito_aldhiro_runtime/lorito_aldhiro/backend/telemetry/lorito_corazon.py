from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Corazón del Lorito: reloj maestro lógico de la sesión de captura y señal de pulso para el icono de corazón del LCD (Orden de Ingeniería Corazón del Lorito).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Principio rector de la orden: el corazón visible INDICA el estado de captura;
no es la fuente de tiempo ni controla el flujo de audio. Por eso este módulo:

- no toca audio, disco ni widgets, y nada de la captura lo espera;
- mide con un reloj monotónico (`time.monotonic_ns`, CLOCK_MONOTONIC en
  Linux): no lo mueven los cambios de hora del sistema ni los saltos de NTP
  (PEP 418), a diferencia de la hora de pared del equipo;
- calcula el tiempo efectivo con MARCAS reales —acumulado de los tramos
  cerrados + (ahora − inicio del tramo abierto)—, nunca sumando un periodo
  nominal por tick, así no hay deriva acumulativa (RF-09);
- programa cada pulso contra un plazo ABSOLUTO derivado de esas marcas
  (pulso k en el instante en que el tiempo efectivo llega a k·periodo), no
  "ahora + periodo": un despertar tardío no desplaza los siguientes;
- publica instantáneas INMUTABLES: la interfaz lee la última por referencia
  (sin lock, sin esperar) y calcula la fase visual con su propio reloj;
- entrega a los suscriptores desde SU hilo, nunca desde el que ordenó la
  transición: un suscriptor lento (un repintado) no puede retrasar a la
  captura que avisa del cambio (RF-07).

Partes (sección 4 de la orden):
  `ClockSource`     reloj monotónico inyectable (`MonotonicClock` / pruebas)
  `CorazonEngine`   máquina de estados + tiempo efectivo + pulsos
  `PulsePublisher`  última instantánea + suscriptores (fallos contados)
  hilo planificador uno por motor, sólo duerme y emite pulsos

Estados (sección 3): DETENIDO → PREPARADO → GRABANDO ⇄ PAUSADO →
FINALIZADO / DETENIDO; cualquier fallo → ERROR (sin latido) hasta un
`reset()` explícito.
"""

import itertools
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional, Protocol

NS = 1_000_000_000

#: Periodo por defecto del pulso visual: un latido por segundo de tiempo
#: EFECTIVO grabado (el pulso n.º k marca el segundo k de la grabación).
#: Configurable; no tiene relación con la frecuencia de muestreo (RF-02).
DEFAULT_PULSE_PERIOD_NS = NS
#: Fracción del periodo en que el corazón se ve "contraído" (sístole).
DEFAULT_SYSTOLE_FRACTION = 0.18
#: Límites del periodo aceptado (evita temporizadores de alta frecuencia).
MIN_PULSE_PERIOD_NS = 250_000_000          # 4 latidos/s como máximo
MAX_PULSE_PERIOD_NS = 10 * NS


class HeartState(str, Enum):
    DETENIDO = "DETENIDO"
    PREPARADO = "PREPARADO"
    GRABANDO = "GRABANDO"
    PAUSADO = "PAUSADO"
    FINALIZADO = "FINALIZADO"
    ERROR = "ERROR"


class CorazonError(RuntimeError):
    """Transición pedida que la máquina de estados no admite."""


class ClockSource(Protocol):
    def now_ns(self) -> int: ...


class MonotonicClock:
    """Reloj monotónico del sistema (RF-01). Nunca la hora civil."""

    @staticmethod
    def now_ns() -> int:
        return time.monotonic_ns()


@dataclass(frozen=True)
class Transition:
    t_ns: int
    old: str
    new: str
    reason: str


@dataclass(frozen=True)
class HeartSnapshot:
    """Instantánea inmutable publicada (RF-10): todo lo que la interfaz y los
    diagnósticos necesitan, sin acceso al motor."""
    state: HeartState
    session_id: str
    t_ns: int                       # instante de la instantánea (monotónico)
    accumulated_ns: int             # tiempo efectivo de los tramos cerrados
    run_start_ns: Optional[int]     # inicio del tramo GRABANDO abierto
    pulse_period_ns: int
    systole_fraction: float
    pulse_count: int
    last_pulse_ns: Optional[int]
    error: str = ""
    reason: str = ""
    delivery_failures: int = 0
    late_pulses: int = 0
    max_lateness_ns: int = 0
    transitions: int = 0

    def elapsed_ns(self, now_ns: Optional[int] = None) -> int:
        """Tiempo efectivo a `now_ns` (por defecto, el de la instantánea).
        Sólo corre en GRABANDO; congelado en el resto (RF-04)."""
        if self.state is HeartState.GRABANDO and self.run_start_ns is not None:
            now = self.t_ns if now_ns is None else now_ns
            return self.accumulated_ns + max(0, now - self.run_start_ns)
        return self.accumulated_ns

    def beat(self, now_ns: int) -> float:
        """Fase visual del latido en [0, 1): 0 = inicio de la sístole. La
        deriva de la propia instantánea (calculada a otra hora) se corrige
        con `now_ns`; fuera de GRABANDO no hay latido."""
        if self.state is not HeartState.GRABANDO:
            return 0.0
        return (self.elapsed_ns(now_ns) % self.pulse_period_ns) / self.pulse_period_ns

    def systole(self, now_ns: int) -> bool:
        return (self.state is HeartState.GRABANDO
                and self.beat(now_ns) < self.systole_fraction)


@dataclass(frozen=True)
class PulseEvent:
    session_id: str
    index: int            # pulso n.º k: el tiempo efectivo alcanzó k·periodo
    due_ns: int           # plazo absoluto (monotónico) del pulso
    t_ns: int             # instante real de emisión
    elapsed_ns: int       # tiempo efectivo al emitir

    @property
    def lateness_ns(self) -> int:
        return max(0, self.t_ns - self.due_ns)


class PulsePublisher:
    """Guarda la última instantánea (lectura sin lock: asignación atómica de
    una referencia inmutable) y avisa a los suscriptores. Un suscriptor que
    falla no detiene a los demás ni al motor: se cuenta (sección 8)."""

    def __init__(self):
        self.latest: Optional[HeartSnapshot] = None
        self._subs: dict = {}
        self._ids = itertools.count(1)
        self._lock = threading.Lock()
        self.delivery_failures = 0

    def subscribe(self, callback: Callable) -> int:
        with self._lock:
            sid = next(self._ids)
            self._subs[sid] = callback
            return sid

    def unsubscribe(self, sid: int) -> None:
        with self._lock:
            self._subs.pop(sid, None)

    def publish(self, item) -> None:
        if isinstance(item, HeartSnapshot):
            self.latest = item
        with self._lock:
            subs = list(self._subs.values())
        for cb in subs:
            try:
                cb(item)
            except Exception:
                self.delivery_failures += 1


_ALLOWED = {
    HeartState.DETENIDO: {HeartState.PREPARADO},
    HeartState.PREPARADO: {HeartState.GRABANDO, HeartState.DETENIDO},
    HeartState.GRABANDO: {HeartState.PAUSADO, HeartState.FINALIZADO, HeartState.DETENIDO},
    HeartState.PAUSADO: {HeartState.GRABANDO, HeartState.FINALIZADO, HeartState.DETENIDO},
    HeartState.FINALIZADO: {HeartState.DETENIDO, HeartState.PREPARADO},
    HeartState.ERROR: set(),          # sólo `reset()` (recuperación explícita)
}


class CorazonEngine:
    """Reloj maestro lógico de la sesión de captura (sección 4.1).

    Las operaciones son idempotentes y no bloqueantes (sólo un lock corto):
    repetir `start`/`pause`/`resume`/`stop` no crea hilos ni tareas
    duplicadas (RF-08). El hilo planificador es UNO por motor, se crea al
    primer `start` y termina con `close()`."""

    def __init__(self, clock: Optional[ClockSource] = None,
                 pulse_period_ns: int = DEFAULT_PULSE_PERIOD_NS,
                 systole_fraction: float = DEFAULT_SYSTOLE_FRACTION,
                 run_scheduler: bool = True, transitions_kept: int = 64):
        self._clock = clock or MonotonicClock()
        self._lock = threading.Lock()
        self._wake = threading.Condition(self._lock)
        self._period = self._valid_period(pulse_period_ns)
        self._systole = min(max(float(systole_fraction), 0.05), 0.9)
        self._state = HeartState.DETENIDO
        self._session_id = ""
        self._accumulated_ns = 0
        self._run_start_ns: Optional[int] = None
        self._pulse_count = 0
        self._last_pulse_ns: Optional[int] = None
        self._error = ""
        self._reason = ""
        self._late_pulses = 0
        self._max_lateness_ns = 0
        self._transitions: deque = deque(maxlen=transitions_kept)
        self._transition_total = 0
        self.publisher = PulsePublisher()
        self._run_scheduler = run_scheduler
        self._thread: Optional[threading.Thread] = None
        self._closed = False
        self._outbox: deque = deque()
        self._publish_locked(self._clock.now_ns())
        self._outbox.clear()
        self.delivered_from_caller_thread = 0

    # ── Configuración ────────────────────────────────────────────────────
    @staticmethod
    def _valid_period(period_ns: int) -> int:
        p = int(period_ns)
        if not MIN_PULSE_PERIOD_NS <= p <= MAX_PULSE_PERIOD_NS:
            raise ValueError(f"periodo de pulso fuera de rango: {p} ns")
        return p

    def _set_pulse_period_impl(self, period_ns: int) -> None:
        """Cambia la frecuencia del pulso visual. El tiempo efectivo no se
        toca; el próximo pulso se reprograma con el periodo nuevo."""
        p = self._valid_period(period_ns)
        with self._lock:
            elapsed = self._elapsed_locked(self._clock.now_ns())
            self._period = p
            self._pulse_count = elapsed // p
            self._publish_locked(self._clock.now_ns())
            self._wake.notify_all()

    # ── Ciclo de vida (sección 5) ────────────────────────────────────────
    def _prepare_impl(self, session_id: str = "") -> bool:
        """DETENIDO/FINALIZADO → PREPARADO: sesión nueva, tiempo en cero."""
        with self._lock:
            if self._state is HeartState.PREPARADO and session_id == self._session_id:
                return False
            self._require(HeartState.PREPARADO)
            self._session_id = str(session_id)
            self._accumulated_ns = 0
            self._run_start_ns = None
            self._pulse_count = 0
            self._last_pulse_ns = None
            self._reason = ""
            return self._go(HeartState.PREPARADO, "sesión preparada")

    def start(self, session_id: str = "") -> bool:
        """PREPARADO → GRABANDO, tras confirmar que la captura arrancó.
        Desde DETENIDO pasa antes por PREPARADO."""
        with self._lock:
            if self._state is HeartState.GRABANDO:
                return False
        if self.state in (HeartState.DETENIDO, HeartState.FINALIZADO):
            self.prepare(session_id)
        with self._lock:
            if self._state is HeartState.PAUSADO:
                raise CorazonError("start() en PAUSADO: usar resume()")
            self._require(HeartState.GRABANDO)
            if session_id:
                self._session_id = str(session_id)
            self._run_start_ns = self._clock.now_ns()
            changed = self._go(HeartState.GRABANDO, "grabación confirmada", self._run_start_ns)
        self._flush()
        self._ensure_scheduler()
        return changed

    def _pause_impl(self, reason: str = "pausa") -> bool:
        with self._lock:
            if self._state is HeartState.PAUSADO:
                return False
            if self._state is not HeartState.GRABANDO:
                return False                        # nada que pausar (idempotente)
            now = self._clock.now_ns()
            self._emit_due_locked(now)
            self._accumulated_ns += max(0, now - self._run_start_ns)
            self._run_start_ns = None
            return self._go(HeartState.PAUSADO, reason, now)

    def _resume_impl(self, reason: str = "reanudación") -> bool:
        with self._lock:
            if self._state is HeartState.GRABANDO:
                return False
            if self._state is not HeartState.PAUSADO:
                return False
            self._run_start_ns = self._clock.now_ns()
            return self._go(HeartState.GRABANDO, reason, self._run_start_ns)

    def _stop_impl(self, reason: str = "fin de captura") -> bool:
        """Cierre idempotente: GRABANDO/PAUSADO → FINALIZADO (tiempo efectivo
        congelado, sin pulsos). Desde PREPARADO vuelve a DETENIDO."""
        with self._lock:
            if self._state in (HeartState.FINALIZADO, HeartState.DETENIDO, HeartState.ERROR):
                return False
            now = self._clock.now_ns()
            if self._state is HeartState.GRABANDO:
                self._emit_due_locked(now)
                self._accumulated_ns += max(0, now - self._run_start_ns)
            self._run_start_ns = None
            target = (HeartState.DETENIDO if self._state is HeartState.PREPARADO
                      else HeartState.FINALIZADO)
            return self._go(target, reason, now)

    def _release_impl(self, reason: str = "sesión liberada") -> bool:
        """FINALIZADO → DETENIDO (corazón en reposo)."""
        with self._lock:
            if self._state is not HeartState.FINALIZADO:
                return False
            return self._go(HeartState.DETENIDO, reason)

    def _fail_impl(self, reason: str) -> bool:
        """Cualquier estado → ERROR: sin latido (nunca una señal de vida
        falsa, RF-06). Conserva la primera razón."""
        with self._lock:
            if self._state is HeartState.ERROR:
                return False
            now = self._clock.now_ns()
            if self._state is HeartState.GRABANDO and self._run_start_ns is not None:
                self._emit_due_locked(now)
                self._accumulated_ns += max(0, now - self._run_start_ns)
            self._run_start_ns = None
            self._error = str(reason) or "ERROR"
            return self._go(HeartState.ERROR, self._error, now, check=False)

    def _reset_impl(self, reason: str = "recuperación explícita") -> bool:
        """ERROR (o cualquier estado) → DETENIDO. Es la transición explícita de
        recuperación que exige la orden."""
        with self._lock:
            if self._state is HeartState.DETENIDO:
                return False
            self._run_start_ns = None
            self._error = ""
            return self._go(HeartState.DETENIDO, reason, check=False)

    # ── Envolturas públicas: aplican y entregan a los suscriptores ────────
    def set_pulse_period(self, period_ns: int) -> None:
        self._set_pulse_period_impl(period_ns); self._flush()

    def prepare(self, session_id: str = "") -> bool:
        r = self._prepare_impl(session_id); self._flush(); return r

    def pause(self, reason: str = "pausa") -> bool:
        r = self._pause_impl(reason); self._flush(); return r

    def resume(self, reason: str = "reanudación") -> bool:
        r = self._resume_impl(reason); self._flush(); return r

    def stop(self, reason: str = "fin de captura") -> bool:
        r = self._stop_impl(reason); self._flush(); return r

    def release(self, reason: str = "sesión liberada") -> bool:
        r = self._release_impl(reason); self._flush(); return r

    def fail(self, reason: str) -> bool:
        r = self._fail_impl(reason); self._flush(); return r

    def reset(self, reason: str = "recuperación explícita") -> bool:
        r = self._reset_impl(reason); self._flush(); return r

    def close(self, timeout: float = 2.0) -> None:
        """Libera el hilo planificador (cierre de la aplicación)."""
        with self._lock:
            self._closed = True
            self._wake.notify_all()
        t = self._thread
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(timeout)
        self._thread = None

    # ── Lectura ──────────────────────────────────────────────────────────
    @property
    def state(self) -> HeartState:
        return self._state

    def snapshot(self) -> HeartSnapshot:
        """Instantánea al instante actual (lock corto)."""
        with self._lock:
            return self._snapshot_locked(self._clock.now_ns())

    def latest(self) -> Optional[HeartSnapshot]:
        """Última instantánea publicada, sin lock (para la interfaz)."""
        return self.publisher.latest

    def subscribe(self, callback: Callable) -> int:
        return self.publisher.subscribe(callback)

    def unsubscribe(self, sid: int) -> None:
        self.publisher.unsubscribe(sid)

    def transitions(self) -> list:
        with self._lock:
            return list(self._transitions)

    @property
    def scheduler_alive(self) -> bool:
        t = self._thread
        return t is not None and t.is_alive()

    # ── Pulsos ───────────────────────────────────────────────────────────
    def next_pulse_due_ns(self) -> Optional[int]:
        """Plazo ABSOLUTO del próximo pulso, derivado de las marcas: el
        instante en que el tiempo efectivo llega a (k+1)·periodo."""
        with self._lock:
            return self._next_due_locked()

    def service(self, now_ns: Optional[int] = None) -> list:
        """Emite los pulsos vencidos a `now_ns`. Lo llama el hilo
        planificador (o una prueba con reloj simulado). Si el despertar llegó
        tarde y vencieron varios, se emiten en orden con su plazo propio;
        nunca se desplaza el calendario."""
        with self._lock:
            now = self._clock.now_ns() if now_ns is None else int(now_ns)
            events = self._emit_due_locked(now)
            if events:
                self._publish_locked(now)
        if not self._run_scheduler or threading.current_thread() is self._thread:
            self._deliver_pending()
        else:
            self._flush()
        return events

    # ── Internos ─────────────────────────────────────────────────────────
    def _emit_due_locked(self, now: int) -> list:
        """Emite (a la cola de entrega) los pulsos cuyo plazo ya pasó. Se
        llama también justo antes de pausar, detener o fallar, para que la
        cuenta cierre exacta: pulsos == tiempo efectivo // periodo."""
        events = []
        while True:
            due = self._next_due_locked()
            if due is None or due > now:
                break
            self._pulse_count += 1
            ev = PulseEvent(self._session_id, self._pulse_count, due, now,
                            self._elapsed_locked(now))
            lat = ev.lateness_ns
            if lat > self._period // 4:
                self._late_pulses += 1
            self._max_lateness_ns = max(self._max_lateness_ns, lat)
            self._last_pulse_ns = now
            events.append(ev)
        self._outbox.extend(events)
        return events

    def _require(self, target: HeartState) -> None:
        if target not in _ALLOWED[self._state]:
            raise CorazonError(f"transición no permitida: {self._state.value} → {target.value}")

    def _go(self, new: HeartState, reason: str, now: Optional[int] = None,
            check: bool = True) -> bool:
        if check:
            self._require(new)
        now = self._clock.now_ns() if now is None else now
        old = self._state
        self._state = new
        self._reason = reason
        self._transitions.append(Transition(now, old.value, new.value, reason))
        self._transition_total += 1
        self._publish_locked(now)
        self._wake.notify_all()
        return True

    def _elapsed_locked(self, now: int) -> int:
        if self._state is HeartState.GRABANDO and self._run_start_ns is not None:
            return self._accumulated_ns + max(0, now - self._run_start_ns)
        return self._accumulated_ns

    def _next_due_locked(self) -> Optional[int]:
        if self._state is not HeartState.GRABANDO or self._run_start_ns is None:
            return None
        target_elapsed = (self._pulse_count + 1) * self._period
        return self._run_start_ns + (target_elapsed - self._accumulated_ns)

    def _snapshot_locked(self, now: int) -> HeartSnapshot:
        return HeartSnapshot(
            state=self._state, session_id=self._session_id, t_ns=now,
            accumulated_ns=self._accumulated_ns, run_start_ns=self._run_start_ns,
            pulse_period_ns=self._period, systole_fraction=self._systole,
            pulse_count=self._pulse_count, last_pulse_ns=self._last_pulse_ns,
            error=self._error, reason=self._reason,
            delivery_failures=self.publisher.delivery_failures,
            late_pulses=self._late_pulses, max_lateness_ns=self._max_lateness_ns,
            transitions=self._transition_total)

    def _publish_locked(self, now: int) -> None:
        """La última instantánea queda visible al instante (referencia
        atómica); los suscriptores se avisan después, FUERA del lock
        (`_flush`), para que un suscriptor lento no frene al motor."""
        snap = self._snapshot_locked(now)
        self.publisher.latest = snap
        self._outbox.append(snap)

    def _flush(self) -> None:
        """Con hilo planificador, la entrega la hace él (se le despierta);
        sin hilo (pruebas con reloj simulado) se entrega aquí mismo."""
        if self._run_scheduler and not self._closed:
            with self._lock:
                self._wake.notify_all()
            self._ensure_scheduler()
            return
        self._deliver_pending()

    def _deliver_pending(self) -> None:
        while True:
            try:
                item = self._outbox.popleft()
            except IndexError:
                return
            self.publisher.publish(item)

    def _ensure_scheduler(self) -> None:
        if not self._run_scheduler:
            return
        with self._lock:
            if self._closed or (self._thread is not None and self._thread.is_alive()):
                return
            self._thread = threading.Thread(target=self._scheduler_loop, daemon=True,
                                            name="lorito-corazon")
            self._thread.start()

    def _scheduler_loop(self) -> None:
        """Duerme hasta el plazo absoluto del próximo pulso (o hasta que
        cambie el estado) y emite. Sin trabajo de audio, disco ni widgets."""
        while True:
            self._deliver_pending()                         # avisos fuera del lock
            with self._lock:
                if self._closed:
                    return
                if self._outbox:
                    continue
                due = self._next_due_locked()
                if due is None:
                    self._wake.wait()                       # PAUSADO/DETENIDO/...
                    continue
                wait_s = (due - self._clock.now_ns()) / NS
                if wait_s > 0:
                    self._wake.wait(timeout=wait_s)
                    continue
            self.service()
