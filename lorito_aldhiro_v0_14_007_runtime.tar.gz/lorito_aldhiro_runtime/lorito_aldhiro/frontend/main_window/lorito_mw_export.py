"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Exportación: diálogo exportador y despacho al ExportService streaming (única ruta productiva).
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Ventana principal de Lorito Aldhiro — orquesta captura, reproducción, exportación y todos los menús.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import os
import threading
from datetime import datetime
import soundfile as sf
from PySide6.QtWidgets import QMessageBox
from PySide6.QtCore import QTimer

from lorito_aldhiro.backend.core.lorito_identity import EXPORT_FILE_PREFIX, SESSION_SPEC_SUFFIX, thread_name
from lorito_aldhiro.backend.core.lorito_app_logging import _log
# Orden Golden de Exportación (EX-01/EX-06): ÚNICA ruta productiva —
# ExportRequest → ExportService → ExportSession streaming. El motor legado
# basado en un array de sesión completo en RAM quedó retirado.
from lorito_aldhiro.backend.services.lorito_ui_api import ExportRequest, LABEL_NONE
from lorito_aldhiro.backend.services.lorito_app_services import new_export_service
from lorito_aldhiro.backend.services.lorito_ui_api import apply_normalization_stats_to_status
# GAP-056 (FASE 7, §13): primer corte de extracción del God Object —
# lógica pura (verificación de integridad + texto del spec de sesión)
# sin ninguna dependencia de Qt, extraída de este mismo archivo.
from lorito_aldhiro.backend.services.lorito_ui_api import (
    compute_integrity_check,
    build_session_spec_text)
# GAP-071 (FASE 7, §13): tercer corte de extracción del God Object —
# lógica pura de nombrado/formato de exportación (extensión por
# códec, tag/sufijo de velocidad, tag de clips), extraída de
# `_do_export()` en este mismo archivo.
from lorito_aldhiro.backend.services.lorito_ui_api import (
    export_codec_extension,
    export_speed_filename_tag,
    export_speed_display_suffix,
    export_clip_tag)
from lorito_aldhiro.backend.core.lorito_version import APP_VERSION, APP_BRAND
from lorito_aldhiro.frontend.integration.lorito_bridge import _bridge
from lorito_aldhiro.frontend.dialogs.lorito_dialogs import LoritoExportadorDialog





LOSSLESS_CODECS = ("WAV", "FLAC", "WV")
RAW_CAPTURE_BITS = 24        # DiskWriterV2 escribe el RAW en PCM_24


def export_is_raw(codec: str, norm_label: str, speed_ratio: float) -> bool:
    """Exportación "cruda" (celda MASTER, 0.13): la fuente es el RAW de
    captura; sin normalización ni cambio de velocidad (el limitador solo
    existe asociado a la normalización) y con códec sin pérdida."""
    return ((codec or "").upper() in LOSSLESS_CODECS
            and (norm_label or "Sin normalizar") == "Sin normalizar"
            and abs(float(speed_ratio or 1.0) - 1.0) <= 0.0005)


class ExportMixin:
    """Mixin de responsabilidad — ver banner de cabecera. Solo cobra sentido
    mezclado con QWidget (o algo que ya provea sus atributos) dentro de
    `LoritoAldhiroStudio` — no se instancia de forma independiente."""

    def _export_segment_paths(self, primary_path: str) -> list:
        """Lista ORDENADA de segmentos de la sesión, sin filtrar en
        silencio (EX-03): un segmento faltante/corrupto/incompatible hace
        abortar el preflight de `SegmentProvider` con error tipado."""
        seg_paths = list(self._engine.get_segment_paths())
        if not seg_paths:
            return [primary_path]
        if primary_path not in seg_paths:
            return [primary_path] + seg_paths
        return seg_paths

    def cancel_export(self):
        """Cancelación cooperativa de la exportación en curso (EX-T11)."""
        ev = getattr(self, "_export_cancel_event", None)
        if ev is not None:
            ev.set()

    def _open_lorito_exportador(self):
        """
        Abre "LORITO EXPORTADOR" (§GAP-016) — clon del panel de
        exportación MANUAL del monolito de origen. Mismo mecanismo real que el monolito de origen: el
        diálogo deja elegir códec/profundidad/normalización/directorio
        antes de disparar la exportación real (`self.export()`), en vez
        de exportar directo con lo que estuviera seleccionado.

        Orden TRANSPORT-018 (TR-12): la salida (expulsión) solo empieza con
        el transporte en estado seguro; con un bobinado en curso se detiene
        primero y el exportador se abre al confirmarse la parada.
        """
        _tc = vars(self).get("_transport")
        if _tc is not None:
            from lorito_aldhiro.backend.services.lorito_ui_api import TransportStatus as _TS
            if _tc.is_moving():
                _tc.request_eject(lambda: QTimer.singleShot(0, self._open_lorito_exportador))
                self.status_label.setText("LORITO DETIENE LA CINTA ANTES DE EXPULSAR…")
                return
            if _tc.state == _TS.EJECTING:
                _tc.eject_done()
        if not (self._disk_tmp_path and os.path.exists(self._disk_tmp_path)
                and os.path.getsize(self._disk_tmp_path) > 512
                and not self._engine.recording):
            QMessageBox.warning(self, "Sin audio", "No hay audio grabado.")
            return
        dlg = LoritoExportadorDialog(self, self)
        dlg.export_requested.connect(self.export)
        dlg.exec()
    def export(self):
        # ══════════════════════════════════════════════════════════════════════
        #  ETAPA 1 — CAPTURAR PARÁMETROS EN EL GUI THREAD (solo lectura widgets)
        # ══════════════════════════════════════════════════════════════════════
        codec    = self.codec_box.currentText()
        opt1_val = self.opt1_box.currentText()
        opt2_val = self.opt2_box.currentText()
        norm_val = self.norm_box.currentText()
        ratio    = self._speed_ratio

        # ── Validación rápida de fuente de audio (GUI thread, sin I/O pesada) ──
        tmp_path = self._disk_tmp_path
        use_disk = (tmp_path and os.path.exists(tmp_path)
                    and os.path.getsize(tmp_path) > 512
                    and not self._engine.recording)
        if not use_disk:
            QMessageBox.warning(self, "Sin audio", "No hay audio grabado."); return

        # ══════════════════════════════════════════════════════════════════════
        #  ETAPA 2 — BLOQUEAR CONTROLES INMEDIATAMENTE (antes de cualquier I/O)
        # ══════════════════════════════════════════════════════════════════════
        # CORRECCIÓN CRÍTICA v0.20: en versiones anteriores _set_ui_state("export")
        # y _sync_buttons() se llamaban DESPUÉS de leer la sesión y
        # la normalización — que pueden tardar minutos en sesiones largas o con
        # modos de normalización pesados (LUFS, two-pass, presets de cinta).
        # Resultado: la interfaz quedaba bloqueada en "SE PREPARAN A VACIAR"
        # con todos los controles habilitados por tiempo indefinido.
        # Solución: bloquear la UI PRIMERO, luego lanzar el hilo con toda la carga.
        _normalized = (norm_val != "Sin normalizar")
        _CODEC_PREFIX = {
            "WAV":  ("__EXPORT_WAV__",  "LORITO EXPORTANDO WAV"),
            "FLAC": ("__EXPORT_FLAC__", "LORITO EXPORTANDO FLAC"),
            "OGG":  ("__EXPORT_OGG__",  "LORITO EXPORTANDO OGG VORBIS"),
            "WV":   ("__EXPORT_WV__",   "LORITO EXPORTANDO WAVEPACK"),
        }
        _pfx, _label = _CODEC_PREFIX.get(codec, ("__CAROLAMOTION_EXPORT__", f"EXPORTANDO {codec}"))

        self._set_ui_state("export")
        self._sync_buttons()
        # 0.13: MASTER se enciende solo si la exportación es cruda — sin
        # ningún tratamiento (normalización, velocidad; el limitador solo
        # existe con normalización) y con códec sin pérdida. El worker la
        # confirma con el resultado real (`res.transforms`).
        # LA-DTH-OI-001: con TPDF elegido y reducción de profundidad, el
        # dither es un tratamiento DSP → la exportación ya no es cruda.
        from lorito_aldhiro.backend.services.lorito_ui_api import (
            DITHER_OFF, DITHER_TPDF, needs_dither, planned_target_bits)
        _dmode = self._dither_mode() if hasattr(self, "_dither_mode") else DITHER_OFF
        _dither_acts = (_dmode == DITHER_TPDF and
                        needs_dither(RAW_CAPTURE_BITS, planned_target_bits(codec, opt1_val or "")))
        _planned_raw = export_is_raw(codec, norm_val, ratio) and not _dither_acts
        if hasattr(self, "clock"):
            self.clock.set_cell_lit("MASTER", _planned_raw)
        # Overlay "Export" en el contómetro — calco exacto del monolito de origen,
        # genérico sin variante por códec (mismo sistema VFD terso —
        # GAP-010).
        if hasattr(self, "clock"):
            self.clock.setOverlayFromRegistry("EXPORT", True, "EXPORT")
        self.status_label.setText(
            "__EXPORT_PREPARING__LORITO SE PREPARA A VACIAR, ESPERA…")
        # WAYLAND-FIX: QApplication.processEvents() puede producir reentrancia
        # no segura en Qt6/Wayland cuando se llama directamente desde un slot.
        # Diferir la exportación un ciclo del event loop garantiza que el repaint
        # del status_label se procese antes de arrancar el hilo de fondo.

        if _normalized:
            self._norm_blink_timer.start()

        # ══════════════════════════════════════════════════════════════════════
        #  ETAPA 3 — ExportRequest inmutable + ExportService en un worker
        # ══════════════════════════════════════════════════════════════════════
        # Orden Golden de Exportación: la GUI ya no lee segmentos, ni
        # normaliza, ni remuestrea, ni codifica. Solo construye la
        # solicitud y consume progreso (por FRAMES) y un ExportResult
        # tipado. Memoria O(bloque) para cualquier duración de sesión.
        ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
        spd_tag = export_speed_filename_tag(ratio)
        base    = os.path.join(self._export_output_dir, f"{EXPORT_FILE_PREFIX}{ts}{spd_tag}")
        ext     = export_codec_extension(codec)
        out_path = f"{base}.{ext}"
        _cls = getattr(self, "_last_archival_classification", None)
        _src_state = getattr(getattr(_cls, "state", None), "value", "") if _cls else ""
        try:
            _session_id = self._engine.ledger.session_id
        except Exception:
            _session_id = ""
        request = ExportRequest(
            segment_paths=tuple(self._export_segment_paths(tmp_path)),
            final_path=out_path, codec=codec, opt1=opt1_val or "", opt2=opt2_val or "",
            norm_label=norm_val or LABEL_NONE, speed_ratio=float(ratio),
            source_archival_state=_src_state, source_session_id=_session_id,
            dither_mode=_dmode,
            extra_metadata=(("Aplicacion", f"{APP_BRAND} {APP_VERSION}"),
                            ("Clips L", self._session_status.clip_count_l),
                            ("Clips R", self._session_status.clip_count_r),
                            ("XRuns captura", self._session_status.xrun_count)),
        )
        self._export_cancel_event = threading.Event()
        cancel_event = self._export_cancel_event
        self._last_export_result = None

        def _do_export():
            last_pct = [-1]

            def _on_progress(stage, done, total):
                if stage == "ANALYSIS":
                    _bridge.status_msg.emit(
                        "__EXPORT_PREPARING__LORITO ANALIZA LA SESIÓN (pase 1)…")
                elif stage == "ENCODING":
                    if last_pct[0] < 0:
                        _bridge.status_msg.emit(f"{_pfx}{_label}")
                        if _normalized:
                            _bridge.status_msg.emit("__NORM_BLINK_ON__")
                    pct = int(done * 100 / total) if total else 0
                    pct = max(0, min(99, pct))
                    if pct != last_pct[0]:
                        last_pct[0] = pct
                        _bridge.export_progress.emit(codec, norm_val, pct)
                elif stage == "VERIFY":
                    _bridge.status_msg.emit("__EXPORT_CHECKSUM__LORITO MIDE LO QUE GUARDÓ...")
                elif stage == "MANIFEST":
                    _bridge.status_msg.emit("__EXPORT_CHECKSUM__LORITO CHECKSUM...")

            try:
                _bridge.status_msg.emit(
                    "__EXPORT_PREPARING__LORITO SE PREPARA A VACIAR, ESPERA…")
                _bridge.export_progress.emit(codec, norm_val, 0)
                res = new_export_service().run(request, progress_cb=_on_progress,
                                          cancel_event=cancel_event)
                _bridge.master_cell.emit(bool(_planned_raw and res.ok and not res.transforms))
                self._last_export_result = res
                _bridge.export_progress.emit(codec, norm_val, 100)

                if res.status == "CANCELLED":
                    _log.warning("Exportación CANCELADA por el operador (%s)", out_path)
                    _bridge.status_msg.emit("__ERROR_CAROLA__EXPORTACIÓN CANCELADA")
                    return
                if not res.ok:
                    _log.error("Exportación ABORTADA [%s/%s]: %s",
                               res.error_code, res.failed_stage, res.error)
                    # Error tipado (Orden NORM-ARCH-017 §7): el código se
                    # muestra tal cual; nunca se reduce a "sin audio".
                    _bridge.status_msg.emit(
                        f"__EXPORT_DESTROYED__😰 LORITO NO PUBLICÓ NADA "
                        f"[{res.error_code or 'ERROR'}]: {res.error[:80]}")
                    return

                # ── Estadísticas de normalización → _status (UI/spec) ──────
                if _normalized:
                    apply_normalization_stats_to_status(self._session_status, res.norm_stats)
                    self._session_status.normalization_mode = norm_val
                    _log.info("Normalización [%s]: %s", norm_val,
                              {k: res.norm_stats[k] for k in sorted(res.norm_stats)
                               if isinstance(res.norm_stats[k], (int, float, str, bool))})
                    _log.info("Normalización Golden: estado=%s avisos=%s",
                              res.norm_state, res.norm_warnings)

                # ── Integridad end-to-end (captura → exportación) ──────────
                self._session_status.frames_exported = res.frames_out
                fr, fw, fe = self._session_status.frames_received, self._session_status.frames_written, res.frames_out
                _integ = compute_integrity_check(fr, fw, fe)
                if not _integ.ok:
                    _log.error("INTEGRIDAD END-TO-END: %s  (fr=%d fw=%d fe=%d)",
                               _integ.summary, fr, fw, fe)
                    self._services.xrun_forensics.record_xrun(
                        f"INTEGRITY_FAIL:{_integ.summary[:40]}",
                        cb_latency_ms=0.0, write_latency_ms=0.0, queue_size=0)
                else:
                    _log.info("Integridad end-to-end OK: fr=%d fw=%d fe=%d", fr, fw, fe)

                clip_data = self._services.clip_log.to_dict()
                out_sz = os.path.getsize(out_path)
                dur_s = res.frames_out / max(res.rate, 1)
                spd_info = export_speed_display_suffix(ratio)
                clip_tag = export_clip_tag(clip_data["total_l"], clip_data["total_r"])
                msg = (f"__EXPORT_SAVED__LORITO GUARDÓ: {EXPORT_FILE_PREFIX}{ts}{spd_tag}.{ext}{spd_info}"
                       f"  ({out_sz//1024} KB  {dur_s/60:.1f} min){clip_tag}"
                       f"  [{res.archival_class}]"
                       + (f"  [NORM {res.norm_state}]" if _normalized and res.norm_state else ""))
                _log.info("Export completo: %s  %d bytes  %.2f s  sha256=%s…  clase=%s %s",
                          out_path, out_sz, dur_s, res.sha256[:16], res.archival_class,
                          res.archival_reasons)
                _bridge.status_msg.emit(msg)

                # ── Imagen espectral (streaming, ventanas acotadas) ────────
                try:
                    from lorito_aldhiro.backend.services.lorito_ui_api import (
                        compute_spectrogram_rgba_from_wav_files)
                    from lorito_aldhiro.frontend.spectral.lorito_export_spectral_render import (
                        render_spectral_png,
                    )
                    _spec_src = list(request.segment_paths)
                    if codec == "WAV" and request.opt1 != "32-bit Float":
                        _spec_src = [out_path]
                    _spec_rgba = compute_spectrogram_rgba_from_wav_files(_spec_src, win_size=2048)
                    render_spectral_png(_spec_rgba, f"{base}_spectral.png",
                                        filename=os.path.basename(out_path), codec_name=codec)
                except Exception as _spec_exc:
                    _log.error("Fallo al generar imagen espectral: %s", _spec_exc)

                # ── "Aldhira de Especificación de Lorito" ────────────────────
                try:
                    _tape_lbl_active = self.cassette_dur_box.currentText()
                    _tape_panel = {"C-60": self.tape_c60, "C-90": self.tape_c90,
                                   "OTROS": self.tape_otros}.get(_tape_lbl_active)
                    _spec_data = _tape_panel.get_spec_log_data() if _tape_panel else {}
                    _spec_text = build_session_spec_text(
                        app_brand=APP_BRAND, app_version=APP_VERSION,
                        out_filename=os.path.basename(out_path),
                        timestamp_str=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        tape_label=_spec_data.get("tape_label", _tape_lbl_active),
                        sha256=res.sha256,
                        codec=codec, rate=res.rate, duration_s=dur_s, size_bytes=out_sz,
                        total_frames=res.frames_out, speed_ratio=ratio,
                        codec_opt1=opt1_val or "", codec_opt2=opt2_val or "",
                        norm_mode_label=self._session_status.normalization_mode or LABEL_NONE,
                        norm_gain_db=self._session_status.normalization_gain_db,
                        norm_peak_db=self._session_status.normalization_peak_db,
                        norm_lufs=self._session_status.normalization_lufs,
                        frames_received=self._session_status.frames_received,
                        frames_written=self._session_status.frames_written,
                        frames_exported=self._session_status.frames_exported,
                        clip_l=clip_data.get("total_l", 0), clip_r=clip_data.get("total_r", 0),
                        is_otros=_spec_data.get("is_otros", True), tape_counter_data=_spec_data,
                    )
                    _spec_text += (f"\nClase archivística de la exportación: {res.archival_class}\n"
                                   + "".join(f"  · {r}\n" for r in res.archival_reasons)
                                   + f"Manifiesto: {os.path.basename(res.manifest_path)}\n")
                    with open(f"{base}{SESSION_SPEC_SUFFIX}", "w", encoding="utf-8") as _sf_spec:
                        _sf_spec.write(_spec_text)
                except Exception as _spec_err:
                    _log.error("No se pudo escribir la especificación de sesión: %s", _spec_err)

            except Exception as e:
                _log.error("Export excepción inesperada: %s", e, exc_info=True)
                # Loro Central Boss: fallo de un motor auxiliar → la exportación
                # queda aislada hasta el próximo pedido del operador.
                _k = vars(self).get("_kernel")
                if _k is not None:
                    from lorito_aldhiro.backend.kernel.lcb_contracts import FaultKind
                    _k.report_fault(FaultKind.EXPORT_FAILURE, "export", str(e)[:200])
                _bridge.status_msg.emit(f"__ERROR_CAROLA__SI TODO ESTABA BIEN 🥺: {str(e)[:100]}")
            finally:
                _bridge.export_progress.emit(codec, norm_val, -1)
                _bridge.status_msg.emit("__EXPORT_DONE__")

        # WAYLAND-FIX: diferir el lanzamiento un ciclo del event loop para que
        # el repaint del status_label se complete antes de arrancar I/O.
        QTimer.singleShot(0, lambda: self._launch_export_job(_do_export, cancel_event))

    def _launch_export_job(self, do_export, cancel_event) -> None:
        """0.14.007: la exportación es un trabajo de Loro Central Boss (clase
        EXPORT, cancelable de forma cooperativa). Cancelar desde el Kernel
        enciende el mismo `cancel_event` que usa el botón. Con el Kernel en
        modo observador (LORITO_LCB=0) se usa el hilo propio de siempre."""
        k = vars(self).get("_kernel")
        if k is None or not k.enabled:
            threading.Thread(target=do_export, daemon=True, name=thread_name("export")).start()
            return
        from lorito_aldhiro.backend.kernel.lcb_contracts import JobClass, JobSpec

        def _job(ctx):
            ctx.on_cancel(cancel_event.set)
            do_export()

        # Pedirla es la autorización del operador: si un fallo anterior aisló
        # la exportación, se restituye.
        k.restore_engine("export")
        ticket = k.submit_job(JobSpec(name="exportación", owner="export", fn=_job,
                                      job_class=JobClass.EXPORT, cancellable=True))
        self._export_job_id = ticket.job_id if ticket.accepted else None
        if not ticket.accepted:
            _log.error("Exportación rechazada por el planificador: %s", ticket.reason)
            _bridge.status_msg.emit(f"__ERROR_CAROLA__EXPORTACIÓN NO ADMITIDA: {ticket.reason[:60]}")
            _bridge.status_msg.emit("__EXPORT_DONE__")
    @staticmethod
    def _fmt_short(sec):
        return f"{int(sec//60):02d}:{int(sec%60):02d}"
