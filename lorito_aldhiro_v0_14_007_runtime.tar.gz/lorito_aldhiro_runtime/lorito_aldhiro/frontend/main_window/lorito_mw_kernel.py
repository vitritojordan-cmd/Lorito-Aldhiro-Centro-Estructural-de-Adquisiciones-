from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: La ventana frente a Loro Central Boss: lee sus eventos en el hilo GUI, muestra los fallos que antes no llegaban a la pantalla y ofrece el panel de diagnóstico.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Orden LA-KRN-LCB-001 §5 y §6: la interfaz solo consume instantáneas y
eventos, y nunca bloquea al audio.

- **Eventos.** Un temporizador Qt (250 ms, hilo GUI) drena la suscripción
  del Kernel (`poll()`, cola acotada). El Kernel nunca llama código de la
  interfaz; la interfaz nunca espera al Kernel.
- **Fallo de captura.** Hasta 0.14.006 la ventana no se enteraba: el motor
  cerraba la sesión (fail-stop), pero las señales `stream_died` y
  `recovery_msg` no las emitía nadie y `on_session_failed` no tenía
  receptor. La interfaz seguía mostrando "grabando". Ahora, ante el
  evento FAULT de la captura, la ventana sigue su flujo normal de STOP (el
  motor devuelve el cierre ya hecho, que es idempotente) y avisa del motivo.
- **Parada segura incompleta** o **dispositivo perdido**: aviso en el
  estado y registro en la bitácora forense.
- **Diagnóstico.** HOST → "DIAGNÓSTICO LORO CENTRAL BOSS…" abre un panel
  de solo lectura con estado, salud, métricas (con unidad y fuente),
  alertas, concesiones, trabajos y la última parada segura. Se refresca
  cada segundo desde la instantánea.
"""

from PySide6.QtCore import QTimer

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.kernel.lcb_contracts import EventKind
from lorito_aldhiro.backend.kernel.lcb_kernel import make_report_text

_CAPTURE_FAULT_ACTIONS = ("safe_stop", "declared")


class KernelMixin:
    def _kernel_setup(self) -> None:
        k = self._services.kernel
        self._kernel = k
        self._kernel_sub = k.subscribe_events("ventana", capacity=512)
        self._kernel_diag = None
        self._kernel_timer = QTimer(self)
        self._kernel_timer.timeout.connect(self._poll_kernel_events)
        self._kernel_timer.start(250)
        # Si Qt destruye la ventana sin pasar por closeEvent, su Kernel
        # también termina (sin referenciar a la ventana ya destruida).
        self.destroyed.connect(lambda *_a, _k=k: _k.shutdown(timeout=0.5))

    def _kernel_close(self) -> None:
        t = vars(self).get("_kernel_timer")
        if t is not None:
            t.stop()
        k = vars(self).get("_kernel")
        if k is not None:
            k.shutdown(timeout=5.0)

    # ── eventos ──────────────────────────────────────────────────────────
    def _poll_kernel_events(self) -> None:
        sub = vars(self).get("_kernel_sub")
        if sub is None:
            return
        for ev in sub.poll(64):
            try:
                self._on_kernel_event(ev)
            except Exception as e:
                _log.error("LCB: evento %s sin procesar en la ventana: %s", ev.kind.value, e)

    def _kernel_log(self, severity: str, cause: str, data: dict) -> None:
        log = vars(self).get("_event_log")
        if log is not None:
            log.emit("KERNEL", severity, cause, data=data)

    def _on_kernel_event(self, ev) -> None:
        d = dict(ev.data)
        if ev.kind == EventKind.FAULT:
            self._kernel_log("ERROR", f"{d.get('kind')}: {d.get('detail', '')}", d)
            if d.get("subsystem") == "capture" and d.get("action") in _CAPTURE_FAULT_ACTIONS:
                if getattr(self, "_ui_state", "") in ("rec", "pause"):
                    # El motor ya cerró la sesión; la ventana sale de "grabando"
                    # por su flujo normal (finalize() devuelve el cierre hecho).
                    self._capture_failed_pending = True
                    self.stop_all()
                self.status_label.setText(
                    f"__ERROR_CAROLA__CAPTURA DETENIDA: {str(d.get('detail', ''))[:80]}")
        elif ev.kind == EventKind.SAFE_STOP_DONE:
            self._kernel_log("WARNING" if d.get("complete") else "ERROR",
                             f"parada segura: {d.get('reason', '')}", d)
            if not d.get("verified"):
                self.status_label.setText("__ERROR_CAROLA__PARADA SEGURA SIN VERIFICAR — "
                                          "VER DIAGNÓSTICO")
        elif ev.kind == EventKind.DEVICE_LOST:
            self._kernel_log("ERROR", f"dispositivo perdido: {d.get('device_id')}", d)
            self.status_label.setText(
                f"__ERROR_CAROLA__DISPOSITIVO PERDIDO: {str(d.get('device_id', ''))[:60]}")
        elif ev.kind in (EventKind.HEALTH_ALERT, EventKind.ENGINE_ISOLATED,
                         EventKind.DEVICE_CONFLICT):
            self._kernel_log("WARNING", f"{ev.kind.value}", d)
        elif ev.kind == EventKind.HEALTH_CLEARED:
            self._kernel_log("INFO", "HEALTH_CLEARED", d)

    # ── reproducción (sin máquina de estados propia publicada) ───────────
    def _kernel_playback(self, active: bool) -> None:
        k = vars(self).get("_kernel")
        if k is not None:
            k.notify_playback(active)

    # ── diagnóstico ──────────────────────────────────────────────────────
    def _open_kernel_diagnostics(self) -> None:
        from PySide6.QtWidgets import QDialog, QPlainTextEdit, QVBoxLayout
        dlg = vars(self).get("_kernel_diag")
        if dlg is None:
            dlg = QDialog(self)
            dlg.setWindowTitle("Loro Central Boss — diagnóstico")
            dlg.resize(620, 560)
            lay = QVBoxLayout(dlg)
            view = QPlainTextEdit(dlg)
            view.setReadOnly(True)
            lay.addWidget(view)
            dlg._view = view
            timer = QTimer(dlg)
            timer.timeout.connect(lambda: view.setPlainText(self._kernel_diagnostic_text()))
            timer.start(1000)
            dlg._timer = timer
            self._kernel_diag = dlg
        dlg._view.setPlainText(self._kernel_diagnostic_text())
        dlg.show()
        dlg.raise_()

    def _kernel_diagnostic_text(self) -> str:
        k = vars(self).get("_kernel")
        if k is None:
            return "Loro Central Boss no disponible"
        snap = k.get_system_snapshot()
        caps = k.capabilities
        lines = [f"LORO CENTRAL BOSS — API {snap.api_version} · versión de instantánea {snap.seq}",
                 f"Estado: {snap.state.value}    Salud: {snap.health.value}",
                 ""]
        if caps is not None:
            lines.append(f"Backend: {caps.audio_backend or '—'} {caps.audio_backend_version or ''}"
                         f" · dispositivos: {caps.device_count if caps.device_count is not None else 'desconocido'}"
                         f" · CPU: {caps.cpu_count} · workers: {caps.workers}")
            for w in caps.warnings:
                lines.append(f"  aviso: {w}")
        lines.append("")
        lines.append("Alertas activas:" if snap.alerts else "Alertas activas: ninguna")
        for a in snap.alerts:
            val = "—" if a.value is None else f"{a.value:g}"
            lines.append(f"  ⚠ {a.subsystem}.{a.metric} = {val} {a.unit} (umbral {a.threshold:g})")
        if snap.isolated_engines:
            lines.append("Motores aislados: " + ", ".join(snap.isolated_engines))
        lines.append("")
        lines.append("Métricas (valor · unidad · fuente):")
        for m in snap.metrics:
            val = "no disponible" if m.value is None else f"{m.value:.3g}"
            lines.append(f"  {m.name:<38} {val:>14} {m.unit:<16} {m.source}")
        lines.append("")
        lines.append("Concesiones de dispositivo:" if snap.leases else
                     "Concesiones de dispositivo: ninguna")
        for l in snap.leases:
            lines.append(f"  {l.owner:<10} {l.direction.value:<6} {l.device_id} "
                         f"({l.channels} ch, {l.samplerate} Hz) — {l.state.value}")
        active_jobs = [j for j in snap.jobs if not j.state.terminal]
        lines.append(f"Trabajos: {len(active_jobs)} activos, {len(snap.jobs)} en historial")
        for j in snap.jobs[-8:]:
            prog = "" if j.progress is None else f" {j.progress * 100:.0f}%"
            lines.append(f"  {j.job_id:<8} {j.name:<12} {j.state.value:<16}{prog} {j.error[:40]}")
        lines.append("")
        lines.append(make_report_text(snap.last_safe_stop))
        lines.append(f"Eventos descartados por consumidores lentos: {snap.events_dropped}")
        return "\n".join(lines)
