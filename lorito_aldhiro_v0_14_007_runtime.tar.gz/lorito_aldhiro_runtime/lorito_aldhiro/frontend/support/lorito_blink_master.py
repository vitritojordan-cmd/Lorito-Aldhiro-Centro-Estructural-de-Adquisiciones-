from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Compuerta del reloj maestro de parpadeo: un elemento que parpadea solo mientras está abierta, con la fase del reloj de la ventana.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Hasta 0.14.003 la pausa manual (250 ms), el modo SIPA (480 ms) y el
desbordamiento de cinta (480 ms) tenían cada uno su QTimer, arrancado en un
instante distinto, y cada receptor alternaba su propia fase: el LCD, los
paneles de log y duración de cinta, el StatusDisplay y la PC no parpadeaban
juntos. Ahora hay un único reloj (`_blink` de la ventana) y estas compuertas
conservan la interfaz que usaba el código (`start`/`stop`/`isActive`): abrir
la compuerta hace que el reloj maestro le entregue su fase en cada tick.
"""


class BlinkGate:
    """Compuerta abierta/cerrada; el reloj maestro la consulta en cada tick."""

    __slots__ = ("_open",)

    def __init__(self) -> None:
        self._open = False

    def start(self, *_a) -> None:
        self._open = True

    def stop(self) -> None:
        self._open = False

    def isActive(self) -> bool:
        return self._open
