from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Controles inhibidos: un clic sobre un control deshabilitado por el estado del sistema muestra "Fnc No Disp" en el LCD.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════


Qt no entrega el clic a un widget deshabilitado, así que hasta 0.14.003 un
botón inhibido (REC durante la reproducción, EXPORT sin audio, un scrub sin
cinta, ...) no daba ninguna respuesta. El filtro ve el clic antes de que Qt
lo descarte y avisa en el contómetro, como el resto de funciones no
disponibles (pedido de la usuaria, 0.14.004).
"""

from typing import Callable, Iterable

from PySide6.QtCore import QEvent, QObject
from PySide6.QtWidgets import QWidget


class InhibitedClickFilter(QObject):
    """Llama a `on_inhibited` cuando se pulsa un control vigilado que está
    deshabilitado. Nunca consume el evento."""

    def __init__(self, on_inhibited: Callable[[], None], parent=None):
        super().__init__(parent)
        self._on_inhibited = on_inhibited

    def watch(self, widgets: Iterable[QWidget]) -> int:
        n = 0
        for w in widgets:
            if w is not None:
                w.installEventFilter(self)
                n += 1
        return n

    def eventFilter(self, obj, event):
        if (event.type() == QEvent.MouseButtonPress
                and isinstance(obj, QWidget) and obj.isVisible() and not obj.isEnabled()):
            self._on_inhibited()
        return False
