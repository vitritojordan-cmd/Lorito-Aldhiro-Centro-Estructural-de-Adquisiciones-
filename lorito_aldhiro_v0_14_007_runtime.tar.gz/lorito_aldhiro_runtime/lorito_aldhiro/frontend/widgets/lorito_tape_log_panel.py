from __future__ import annotations

"""
════════════════════════════════════════════════════════════════════
  LORITO ALDHIRO DE REGISTROS ALTERNATIVOS C.E.A
════════════════════════════════════════════════════════════════════
  Concepto: Panel de bitácora de eventos de la sesión.
════════════════════════════════════════════════════════════════════
        ,,__
      <(o )---.
       ( ._>   `--.
        `--'\\      `-.
             \\_/\\_/\\_/
════════════════════════════════════════════════════════════════════

"""

import math as _math
from typing import Optional
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QColor, QPainter, QPen, QLinearGradient, QBrush, QFont, QPainterPath

from lorito_aldhiro.backend.core.lorito_app_logging import _log
from lorito_aldhiro.backend.services.lorito_ui_api import (
    _AIPLO_FRN_ACTIVE,
    _frn_emit,
    _aiplo_frn_counters)
from lorito_aldhiro.backend.services.lorito_ui_api import (
    CassetteTransportPhysics,
    _CassetteType_Enum,
    _TransportMode_Enum)
from lorito_aldhiro.backend.services.lorito_ui_api import ReelKinematics
from lorito_aldhiro.frontend.support.lorito_fonts import font_leyendas, font_cuentavueltas

from lorito_aldhiro.frontend.widgets.lorito_cassette_motor_v4 import CassetteMotorV4, TapeSide



class TapeLogPanel(QWidget):
    # 0.12: dentro del panel fusionado (visor + cinta + log bajo un solo
    # vidrio) el widget no dibuja ventana ni borde propios; el vidrio y
    # las líneas finas de separación los pone el Metaloric Panel.
    _fused = False

    # 0.11.011: los hubs de este panel se retiraron. Su cinemática de
    # rotación la orquestan ahora los carretes del LCD Display
    # (`ReelKinematics`): este panel solo calcula los radios de las bobinas
    # y le pasa cada tick. Margen izquierdo de las leyendas:
    TEXT_PAD = 6

    # ── Física de transporte — delegada a CassetteTransportPhysics (v0.22.06) ──
    # El motor físico determinista reemplaza los cálculos IEC embebidos (v0.22.03).
    # CassetteTransportPhysics usa radio dinámico exacto:
    #   R(t) = sqrt(r_hub² + (h/π)·x)  donde h = grosor real de la cinta,
    # calculado a partir del área disponible en el carrete y la longitud total.
    # El cuentavueltas se acopla mecánicamente al carrete receptor (derecho).
    # _TAPE_DT_S se conserva para sincronización con el timer de 15 Hz.
    _TAPE_DT_S   = 1.0 / 15.0   # 15 Hz — sincronizado con SILENCE_ANALYSIS_INTERVAL_MS

    # Mapa etiqueta → tipo de cassette para el motor
    _CASSETTE_TYPE_MAP = {
        "C-60": _CassetteType_Enum.C60,
        "C-90": _CassetteType_Enum.C90,
    }

    # Radios de las bobinas por tipo de cassette (mm, medidos en hardware real).
    # Determinan la velocidad angular de los carretes del LCD:
    #   RATIO_MIN = r_hub_vacio / r_hub_lleno  → cuán pequeño se ve el carrete vacío
    #   RATIO_MAX = 1.0  (carrete lleno = radio máximo disponible en el widget)
    # C-90 tiene más cinta → el carrete lleno es físicamente más grueso → RATIO_MIN menor
    # (más contraste entre vacío y lleno) y R_MAX_MM mayor que C-60.
    _HUB_RADII = {
        #           r_vacio_mm  r_lleno_mm
        "C-60":  (   11.0,       20.0  ),   # cinta ~13 μm, L≈88 m
        "C-90":  (   11.0,       26.0  ),   # cinta ~15 μm, L≈131 m — carrete más grueso
        "OTROS": (   11.0,       20.0  ),   # aproximación genérica (igual C-60)
    }

    # Valores de clase: fallback C-60 (se sobreescriben por instancia en __init__)
    R_MIN_MM  = 11.0
    R_MAX_MM  = 20.0
    RATIO_MIN = R_MIN_MM / R_MAX_MM   # ≈ 0.55
    RATIO_MAX = 1.00

    # Colores por modo (R, G, B, A)
    _MODE_COLORS = {
        "C-60":  (255, 253, 208, 245),   # crema brillante
        "C-90":  (  0, 229, 204, 245),   # turquesa brillante
        "OTROS": (255, 179,   0, 245),   # ámbar brillante
    }

    # ── Colores de desbordamiento (counter = 999) ─────────────────────────────
    # C-60: FUCSIA INTENSO (#FF00CC) — R=255, G=0, B=204
    # C-90: AMARILLO INTENSO (#FFE000) — R=255, G=224, B=0
    # OTROS: mismo que C-60 (fucsia)
    _OVF_COLORS = {
        "C-60":  (255,   0, 204, 255),   # fucsia intenso
        "C-90":  (255, 224,   0, 255),   # amarillo intenso
        "OTROS": (255,   0, 204, 255),   # fucsia intenso (fallback)
    }

    def __init__(self, label, side_a_secs, total_secs, parent=None):
        super().__init__(parent)
        self._tape_label  = label
        self._side_a_secs = side_a_secs
        self._total_secs  = total_secs
        self._is_otros    = (label == "OTROS")

        # ── Radios de las bobinas por tipo de cassette (v0.22.07) ───────────────
        # Cada tipo tiene proporciones físicas distintas; C-90 tiene más cinta
        # → el carrete lleno es más grueso → mayor contraste visual vacío/lleno.
        _r_vacio, _r_lleno = self._HUB_RADII.get(label, (11.0, 20.0))
        self.R_MIN_MM  = float(_r_vacio)
        self.R_MAX_MM  = float(_r_lleno)
        self.RATIO_MIN = self.R_MIN_MM / self.R_MAX_MM
        self.RATIO_MAX = 1.0

        # ── Motor de física de transporte (v0.22.06) ────────────────────────────
        # CassetteTransportPhysics reemplaza los cálculos IEC embebidos.
        # Se instancia e inicializa aquí; update_state() lo conduce tick a tick.
        self._transport = CassetteTransportPhysics()
        _ctype = self._CASSETTE_TYPE_MAP.get(label)
        if _ctype is not None:
            self._transport.insert_cassette(_ctype)
        # Ajuste post-insert: forzar la posición al inicio exacto según side_a_secs
        # para que el motor sea coherente con los parámetros del panel.
        if _ctype is not None and not self._is_otros:
            # Recalcular duración con los valores exactos del panel (no los aleatorios del motor)
            self._transport._total_duration_s  = float(total_secs)
            self._transport._side_a_duration_s = float(side_a_secs)
            self._transport._side_b_duration_s = float(total_secs - side_a_secs)
            self._transport._total_length_cm  = total_secs  * self._transport.NOMINAL_SPEED_CM_S
            self._transport._side_a_length_cm = side_a_secs * self._transport.NOMINAL_SPEED_CM_S
            # Recalcular grosor con las longitudes deterministas
            _area = (_math.pi * (self._transport.MAX_REEL_RADIUS_CM ** 2
                                 - self._transport.HUB_RADIUS_CM ** 2))
            _max_side = max(self._transport._side_a_length_cm,
                            self._transport._total_length_cm - self._transport._side_a_length_cm)
            self._transport._tape_thickness_cm = _area / _max_side
            self._transport._position_cm       = 0.0
            self._transport._update_outputs(0.0, 0.0)
        # _theta_recv ya no existe en instancia; el motor lo gestiona internamente.


        # Cinemática de los carretes del LCD (0.11.011). Cada panel arranca
        # con una propia; la ventana principal inyecta la compartida con el
        # LCD vía `set_reel_kinematics()`.
        self._reels = ReelKinematics()

        self._active      = False
        self._elapsed     = 0.0
        self._angle1      = 0.0
        self._angle2      = 0.0
        self._counter     = 0
        self._counter_base= 0.0
        self._phase       = "A"

        # Parpadeo modo OTROS (~12 ticks = 500ms on/off → ciclo 1s)
        self._otros_blink_ctr  = 0
        self._otros_blink_vis  = True

        # Estado de pausa (BUSYCHAN)
        self._paused           = False
        self._pause_blink_vis  = True

        # ── Modo EL LORITO SE POSA EN EL PALO (auto-pausa por silencio, SIPA) ──────────
        # Estado completamente independiente de _paused (pausa manual).
        # Solo se activa desde _activate_carola_waiting() / _deactivate_carola_waiting().
        self._carola_waiting      = False   # True = auto-pausa silencio activa
        self._carola_blink_phase  = False   # False=gris, True=amarillo intenso
        self._carola_blink_vis    = True    # True=dibuja, False=apagado en fase

        # RMS para glow analógico del contador
        self._rms = 0.0

        # ── Contador mecánico analógico (rodillos tipo deck tape counter) ────
        # Cada dígito tiene una posición de rodillo en [0.0, 1.0):
        #   0.0 = dígito completamente visible en reposo,
        #   0.0..1.0 = girando (el dígito actual sale por arriba, el siguiente entra)
        # _mech_prev: valor anterior del contador (para detectar cambio y activar giro)
        self._mech_digits    = [0.0, 0.0, 0.0]   # offset de giro por dígito [0]=centenas
        self._mech_values    = [0,   0,   0]       # valor actual visible de cada rodillo
        self._mech_prev_cnt  = -1                  # último _counter procesado

        # ── Física del cuentavueltas analógico (hub receptor) ─────────────────
        # El cuentavueltas está unido al hub receptor (el que recoge cinta).
        # Al inicio el hub receptor es pequeño → gira rápido.
        # A medida que la cinta avanza, el hub crece → gira más lento.
        # _mech_accum: acumulador fraccional de "decenas de segundo" contadas
        # _mech_spool_angle: ángulo acumulado (grados) del hub receptor
        self._mech_accum      = 0.0   # acumulador sub-entero de decenas de segundo
        self._mech_spool_ang  = 0.0   # ángulo total acumulado del hub receptor (grados)

        # ── Control de volteo lado B (C-60 / C-90) ───────────────────────────
        # _flip_pending: True = la auto-pausa de volteo fue activada; esperando
        #                que el usuario la desactive para activar lado B.
        # _flip_pending_unlocked: True = pausa forzada por tope (con protección)
        #                fue desarmada por silencio ≥ 3 s (cassette detenido).
        #                La pausa continúa activa como pausa ORDINARIA; al regresar
        #                señal se libera y se voltea inmediatamente.
        # _flip_done:    True = el volteo ya se realizó en este lado A.
        # _stop_triggered: True = la detención automática ya fue disparada.
        self._flip_pending          = False
        self._flip_pending_unlocked = False
        self._flip_done             = False
        self._stop_triggered        = False
        # MOTOR-v2: pausa forzada por tope flip_max con audio activo.
        # True = el sistema está en "pausa forzada" esperando silencio para
        # conmutar a auto-pausa por silencio (≤ 1 ms) y poder reactivar en Lado B.
        self._forced_pause_active   = False
        # Callback para notificar al controlador principal que debe voltear
        # o detener la grabación. Se inyecta desde LoritoAldhiroStudio.
        self.on_flip_side_b     = None   # callable() → voltear a lado B
        self.on_auto_stop       = None   # callable() → detener grabación

        # ── MOTOR-v3: motor de etapa de duración de cinta ───────────────
        # make_motor() retorna None para etiquetas no reconocidas (OTROS).
        self._cassette_motor: Optional[CassetteMotorV4] = None  # se asigna en _init_cassette_motor()

        # ── Desbordamiento de cuentavueltas (counter = 999) ──────────────────
        # _counter_overflow: True = el contador llegó a 999 (cinta demasiado larga).
        # _wobble_phase: fase acumulada del tambaleo sinusoidal (0..2π).
        # _wobble_blink_vis: alterna True/False para el parpadeo de color.
        # Avanza con cada tick de update_state mientras _counter_overflow=True.
        self._counter_overflow  = False
        self._wobble_phase      = 0.0   # radianes, avanza +0.52 rad/tick (≈8 Hz a 15 Hz)
        self._wobble_blink_vis  = True  # True=color overflow, False=color normal
        self._counter_wrap_count = 0    # FIX-OTROS-COUNTER-WRAP: ciclos 0→999→0 en modo OTROS

        # ── Sobrantes de cuentavueltas C-60/C-90 y final OTROS (v0.22.36) ────
        # _counter_surplus_a : vueltas acumuladas > 999 en Lado A (C-60/C-90).
        # _counter_surplus_b : vueltas acumuladas > 999 en Lado B (C-60/C-90).
        # _counter_wrap_a_count : cuántas veces pasó por 000 en Lado A.
        # _counter_wrap_b_count : cuántas veces pasó por 000 en Lado B.
        # _counter_post_a_base  : valor normalizado 0-999 al iniciar Lado B
        #                         (para calcular vueltas desde el inicio de B).
        # _counter_final_value  : valor del contador al detenerse la grabación.
        self._counter_surplus_a    = 0     # vueltas post-999 en Lado A
        self._counter_surplus_b    = 0     # vueltas post-999 en Lado B
        self._counter_wrap_a_count = 0     # ciclos 0→999 en Lado A
        self._counter_wrap_b_count = 0     # ciclos 0→999 en Lado B
        self._counter_post_a_base  = 0     # valor contador al iniciar Lado B
        self._counter_final_value  = 0     # valor al detener grabación

        # ── Wayland-safe: WA_OpaquePaintEvent=False ───────────────────────────
        # Permite composición alpha del panel sobre el fondo de la ventana.
        # update() solo se llama desde _on_tape_update() (main thread via señal).
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)

    # ── Carretes del LCD (0.11.011) ───────────────────────────────────────
    def set_reel_kinematics(self, reels: ReelKinematics) -> None:
        """Usa la cinemática compartida con los carretes del LCD Display."""
        reels.tape_angles(self._tape_label)[:] = self._reels.tape_angles(self._tape_label)
        self._reels = reels

    # `_angle1`/`_angle2` (suministro/receptor) viven en la cinemática de los
    # carretes; se conservan como propiedades porque el volteo y el inicio de
    # grabación los ponen a 0 desde fuera.
    @property
    def _angle1(self) -> float:
        return self._reels.tape_angles(self._tape_label)[0]

    @_angle1.setter
    def _angle1(self, value: float) -> None:
        self._reels.tape_angles(self._tape_label)[0] = float(value)

    @property
    def _angle2(self) -> float:
        return self._reels.tape_angles(self._tape_label)[1]

    @_angle2.setter
    def _angle2(self, value: float) -> None:
        self._reels.tape_angles(self._tape_label)[1] = float(value)

    def setRms(self, rms: float):
        """Actualiza el RMS suavizado para el glow del contador."""
        self._rms = max(0.0, min(1.0, rms))

    # ── Intervalos de auto-pausa volteo y parada automática ──────────────────
    # C-60: volteo a lado B cuando la auto-pausa se desactive en el intervalo
    #        [28min, 33min]; parada automática solo al terminar el lado B (≥ 60 min total).
    # C-90: volteo a lado B cuando la auto-pausa se desactive en el intervalo
    #        [44min, 48min]; parada automática solo al terminar el lado B (≥ 90 min total).
    #
    # COMPORTAMIENTO CORRECTO:
    #   · Fin de Lado A  → AUTO-PAUSA (espera que el usuario voltee el cassette)
    #   · Fin de Lado B  → DETENCIÓN COMPLETA de la grabación
    # Zona de tolerancia Lado A (volteo a Lado B):
    #   C-60: [28 min, 33 min]  — nominal 30 min   — ventana 5 min
    #   C-90: [43 min, 48 min]  — nominal 45 min   — ventana 5 min  (MOTOR-v2)
    # El volteo se confirma cuando la auto-pausa se desactiva dentro de este rango.
    _FLIP_INTERVALS = {
        "C-60": (28 * 60, 33 * 60),    # (tol_min_secs, tol_max_secs) Lado A
        "C-90": (43 * 60, 48 * 60),    # MOTOR-v2: ventana 5 min [43,48] según nueva spec
    }

    # Zona de tolerancia Lado B (detención automática):
    #   C-60: [58 min total, 66 min total]  — nominal 60 min  — ventana 8 min
    #   C-90: [87 min total, 95 min total]  — nominal 90 min  — ventana 8 min
    # Los tiempos son elapsed_total (Lado A + Lado B).
    # _b_tol_min = side_b_dur - (b_tol_max - b_tol_min)
    # La ventana del Lado B es INDEPENDIENTE de la del Lado A (C-90 difiere).
    # Formato: (b_tol_window_secs,)  — se resta de side_b_dur para obtener _b_tol_min.
    # FIX-LADO-B-TOLERANCIA-EXT3MIN (§GAP-014): ventana 5→8 min — junto con
    # el total_secs +3min pasado a TapeLogPanel (ver lorito_main_window.py),
    # el efecto neto es +3 min SOLO al tope máximo (el mínimo, 58/87 min,
    # no se mueve) — mismo fix que el monolito de origen [0.37.348]. Referencia documental/
    # fallback: con el motor real activo (CassetteMotorV4, no OTROS), estos
    # valores se derivan de _PRESET_C60/_PRESET_C90 en
    # lorito_cassette_motor_v4.py, que son la fuente de verdad — deben
    # mantenerse en sincronía manual con ellos.
    _STOP_INTERVALS = {
        "C-60": (8 * 60,),   # ventana 8 min → _b_tol_min = side_b_dur-480 = 1680s (58 min)
        "C-90": (8 * 60,),   # ventana 8 min → _b_tol_min = side_b_dur-480 = 2520s (87 min)
    }
    # _STOP_THRESHOLDS eliminado: el fin del lado A NO debe detener la grabación,
    # solo activar la pausa automática de volteo. La detención real ocurre únicamente
    # al agotar el lado B, gestionada por el bloque "Parada automática lado B" más abajo.

    def update_state(self, active, elapsed_secs, autopause_active=False):
        """
        active        — True = grabando sin pausa
        elapsed_secs  — tiempo transcurrido total (incluye lados A+B)
        autopause_active — True = la auto-pausa por silencio está activa ahora mismo
        """
        prev_phase = self._phase
        changed = False

        if not active:
            if self._active:
                self._active     = False
                self._angle1     = 0.0
                self._angle2     = 0.0
                # _theta_recv eliminado en v0.22.06 — el motor gestiona su estado internamente
                self._otros_blink_ctr = 0
                self._otros_blink_vis = True
                changed = True
        else:
            self._active  = True
            self._elapsed = elapsed_secs

            if self._is_otros:
                # Modo OTROS: velocidad lineal constante a radio medio (sin volteo)
                # El motor no gestiona OTROS; se mantiene la aproximación geométrica.
                _r_mid_mm = (self.R_MIN_MM + self.R_MAX_MM) / 2.0
                self._reels.step_tape_uniform(self._tape_label, _r_mid_mm, self._TAPE_DT_S)
                # ── FIX-OTROS-COUNTER-WRAP (v0.22.23) ────────────────────────
                # Contador en ciclos de 1000 s: al llegar a 999 el siguiente
                # tick muestra 000 y la cuenta continúa. No se activa overflow
                # ni se cambia leyenda ni color — solo reset numérico del visor.
                _counter_raw = int(elapsed_secs)
                _wrap_new    = _counter_raw // 1000
                if _wrap_new > self._counter_wrap_count:
                    self._counter_wrap_count = _wrap_new
                    _log.info(
                        "TapeLogPanel OTROS: cuentavueltas → 000 "
                        "(ciclo %d, elapsed=%.1f s)", _wrap_new, elapsed_secs
                    )
                self._counter = _counter_raw % 1000
                # v0.22.36: guardar valor actual para log de especificación
                self._counter_final_value = self._counter
            else:
                # ── Determinar fase de la cinta ───────────────────────────────
                # FIX-FLIP-TIME-FORCE (v0.22.19): la condición original
                # `elapsed_secs > self._side_a_secs` forzaba new_phase="B"
                # en cuanto el reloj superaba el umbral del Lado A (28 min en
                # C-60), aunque el usuario nunca hubiera volteado el cassette
                # y _flip_done=False. Esto bypasseaba toda la lógica de
                # _flip_pending / on_flip_side_b, produciendo un volteo
                # "fantasma" solo por tiempo.
                # SOLUCIÓN: new_phase="B" SOLO si _flip_done=True (el volteo
                # real ocurrió) O si la fase ya era "B" (estado persistido).
                # Mientras _flip_done=False, la fase permanece en "A" aunque
                # elapsed_secs supere _side_a_secs.
                if elapsed_secs > self._total_secs:
                    new_phase = "SOBRANTE"
                elif self._phase == "B" or self._flip_done:
                    new_phase = "B"
                else:
                    new_phase = "A"

                # Lógica de volteo a lado B (solo C-60 / C-90)
                flip_min, flip_max = self._FLIP_INTERVALS.get(self._tape_label, (None, None))

                # ── FIX-FLIP-AUDIO-GATE (v0.22.20) ────────────────────────────
                #
                # COMPORTAMIENTO CORRECTO (especificado):
                #
                # LADO A — zona de tolerancia [flip_min … flip_max]:
                #   · Si hay señal de audio activa (autopause_active=False):
                #       NO activar pausa automática, NO activar _flip_pending.
                #       Dejar que la grabación continúe.
                #   · Si se detecta silencio de 1 minuto (gestionado por el monolito de origen con
                #       SILENCE_AUTOPAUSE_SECS_TOLERANCE=60s y el detector llama a
                #       _activate_silence_autopause → autopause_active=True):
                #       activar _flip_pending=True y dejar la pausa activa.
                #   · Cuando la señal regresa después de la auto-pausa por silencio
                #       (_deactivate_silence_autopause lo detecta y reanuda con
                #       _flip_pending=True → voltear a Lado B allí).
                #   · Al llegar a flip_max con señal activa (cassette ya terminó
                #       el lado A): forzar auto-pausa (on_flip_side_b callback).
                #       Se activa la pausa; el volteo ocurre cuando regresa señal.
                #
                # LADO B — zona de tolerancia [side_a_secs … total_secs]:
                #   · Detener solo cuando el detector el monolito de origen detecte silencio
                #       (autopause_active=True) — no por posición sola.
                #   · Al llegar a total_secs con señal, detener igualmente
                #       (cassette ya reprodujo el lado B completo).

                # ══════════════════════════════════════════════════════════════
                # MOTOR-v3 — Motor de Etapa de Duración de Cinta
                # Delegado completo a CassetteMotorV4 (lorito_cassette_motor_v4.py).
                # Sustituye MOTOR-v2 embebido. Los callbacks on_flip_side_b
                # y on_auto_stop se inyectan desde LoritoAldhiroStudio tras la creación
                # del panel (igual que antes). El motor inicializa sus propios
                # umbrales desde _PRESET_CONFIG; las tablas _FLIP_INTERVALS y
                # _STOP_INTERVALS quedan como referencia documental.
                # ══════════════════════════════════════════════════════════════
                if self._cassette_motor is not None and not self._is_otros:
                    _motor_action = self._cassette_motor.tick(
                        elapsed_secs     = elapsed_secs,
                        autopause_active = autopause_active,
                    )
                    # ── Sincronizar estado del motor → TapeLogPanel ───────────
                    self._flip_pending        = self._cassette_motor.flip_pending
                    self._flip_done           = self._cassette_motor.flip_done
                    self._forced_pause_active = self._cassette_motor.forced_pause_active
                    self._stop_triggered      = self._cassette_motor.stop_triggered
                    # Propagar nueva fase desde el motor
                    _side_map = {
                        TapeSide.A:         "A",
                        TapeSide.B:         "B",
                        TapeSide.EXCEDENTE: "SOBRANTE",
                    }
                    new_phase = _side_map.get(self._cassette_motor.side, new_phase)
                    # ── Reinicio de cuentavueltas al voltear a Lado B ─────────
                    if self._cassette_motor.query_counter_reset():
                        # firma='aiplo_frn_counter_reset'
                        if _AIPLO_FRN_ACTIVE:
                            _aiplo_frn_counters["counter_reset"] += 1
                            _frn_emit("AIPLO_COUNTER_RESET", {
                                "origin" : "update_state",
                                "panel"  : getattr(self, "_tape_label", "?"),
                                "elapsed": elapsed_secs,
                                "n"      : _aiplo_frn_counters["counter_reset"],
                            })
                        self._counter_base        = elapsed_secs
                        self._counter             = 0
                        self._counter_final_value = 0
                        self._counter_surplus_b   = 0
                        self._counter_wrap_b_count = 0
                        # FIX-OVERFLOW-RESET-FLIP: limpiar overflow al voltear.
                        self._counter_overflow    = False
                        self._wobble_phase        = 0.0
                        self._wobble_blink_vis    = True
                        self._forced_pause_active = False
                        # FIX-HUB-FLIP-RESET (v0.22.49): al voltear físicamente el
                        # cassette, los carretes (antes los hubs) vuelven a 0° para
                        # que la animación arranque desde la posición inicial.
                        self._reels.reset_tape(self._tape_label)
                        _log.info(
                            "TapeLogPanel %s [v3]: cuentavueltas → 000 al voltear "
                            "a Lado B (surplus Lado A: %d, wraps Lado A: %d)",
                            self._tape_label,
                            self._counter_surplus_a, self._counter_wrap_a_count,
                        )
                        self._transport.flip_side()
                        self._mech_accum     = 0.0
                        self._mech_spool_ang = 0.0
                        self._mech_digits    = [0.0, 0.0, 0.0]
                        self._mech_values    = [0, 0, 0]
                        self._mech_prev_cnt  = -1

                if new_phase != prev_phase:
                    if new_phase == "B":
                        pass   # reset ya ejecutado arriba por query_counter_reset()
                    elif new_phase == "SOBRANTE":
                        self._counter_base = self._total_secs
                    self._phase = new_phase

                # ── Física de transporte — motor CassetteTransportPhysics ─────
                # Se avanza un tick PLAY (dt = _TAPE_DT_S) y se leen las salidas.
                # El motor calcula:
                #   R(t) = sqrt(r_hub² + (h/π)·x)  — radio dinámico exacto
                #   RPM = (v / R) * 60/(2π)
                #   counter_value = vueltas acumuladas del carrete receptor
                if new_phase != "SOBRANTE":
                    self._transport.step(self._TAPE_DT_S, _TransportMode_Enum.PLAY)
                    _out = self._transport.outputs

                    # Radios de cada bobina (cm → mm). Los carretes del LCD giran
                    # con ω = v / R: suministro (decrece) y receptor (crece).
                    _r_recv_mm = _out.reel_radius_right_cm * 10.0
                    _r_supp_mm = _out.reel_radius_left_cm  * 10.0
                    _r_recv_mm = max(self.R_MIN_MM * 0.5, _r_recv_mm)
                    _r_supp_mm = max(self.R_MIN_MM * 0.5, _r_supp_mm)
                    self._reels.step_tape(self._tape_label, _r_supp_mm, _r_recv_mm,
                                          self._TAPE_DT_S)

                    # Cuentavueltas: escalar counter_value (vueltas reales) a 0–999
                    # Normalización: 999 vueltas = fin del segmento actual
                    _seg_dur = (self._side_a_secs if self._phase == "A"
                                else self._total_secs - self._side_a_secs)
                    _seg_cm  = _seg_dur * CassetteTransportPhysics.NOMINAL_SPEED_CM_S
                    # Vueltas totales del receptor en ese segmento (integral exacta del motor)
                    # Usamos counter_value directamente, escalado a 0–999 al final.
                    # counter_value crece con cada tick; al fin del segmento alcanza su máximo.
                    # Escala dinámica: ratio elapsed/seg_dur × 999
                    _seg_elapsed = elapsed_secs - self._counter_base
                    _t_norm_raw = _seg_elapsed / max(_seg_dur, 1.0)          # FIX-COUNTER-WRAP-C6090: definir antes del primer uso
                    _t_norm = max(0.0, min(1.0, _t_norm_raw))
                    # Usar los RPM del receptor como proxy de avance angular
                    # y acumular directamente desde elapsed normalizado × 999
                    _prev_counter = self._counter
                    # FIX-COUNTER-WRAP-C6090 (v0.22.44): cuando _t_norm_raw > 1.0
                    # (cinta más larga que el segmento nominal) usar módulo 1000
                    # para que el visor retorne a 000 y siga contando, en lugar
                    # de clampar en 999. El flag _counter_overflow sigue activo
                    # mientras la cinta esté "larga" para mantener la leyenda/tambaleo.
                    if _t_norm_raw > 1.0:
                        self._counter = int(_t_norm_raw * 999) % 1000
                    else:
                        self._counter = int(_t_norm * 999)
                    self._counter_final_value = self._counter   # v0.22.36

                    # ── v0.22.36: conteo de surplus (vueltas post-999) ────────
                    # Cuando el contador llega a 999 significa que el segmento
                    # teórico se agotó. Aquí rastreamos cuántos "ciclos extra"
                    # se acumulan más allá de ese punto para el log de spec.
                    # El cálculo se hace con _t_norm sin clamp (puede superar 1.0
                    # en cintas muy largas o grabaciones más allá del límite).
                    # _t_norm_raw ya calculado arriba — no se repite aquí.
                    if _t_norm_raw > 1.0:
                        # Vueltas acumuladas post-999: la fracción que excede 1.0
                        # escalada a 0-999 representa "cuánto falta para otro ciclo"
                        _surplus_raw = int((_t_norm_raw - 1.0) * 999)
                        if self._phase == "A":
                            # Detectar wrap (cada vez que surplus pasa de 999 a 0)
                            if _surplus_raw < self._counter_surplus_a and self._counter_surplus_a >= 990:
                                self._counter_wrap_a_count += 1
                            self._counter_surplus_a = _surplus_raw
                        else:  # phase B
                            if _surplus_raw < self._counter_surplus_b and self._counter_surplus_b >= 990:
                                self._counter_wrap_b_count += 1
                            self._counter_surplus_b = _surplus_raw

                    # ── FIX-TAPE-DUR-SILENCE v0.22.22: desbordamiento a 999 ────
                    # Cuando el contador llega a 999 la cinta es demasiado larga.
                    # Activar modo overflow: parpadeo de color + tambaleo de los
                    # carretes del LCD (antes, de los hubs de este panel).
                    #
                    # FIX-OVERFLOW-WRAP-PERSIST (v0.22.46): el overflow debe
                    # mantenerse activo incluso cuando el contador hace wrap y
                    # retorna a 000 (o cualquier valor < 999). La condición
                    # correcta es _t_norm_raw > 1.0 (desbordamiento real del
                    # segmento), NO self._counter >= 999 (que es 0 tras el wrap).
                    if _t_norm_raw > 1.0:
                        self._counter_overflow = True
                        # Avanzar fase sinusoidal del tambaleo:
                        # +0.52 rad/tick → ~1.24 Hz ciclo completo a 15 Hz
                        # (parece más rápido visualmente porque es oscilación ±)
                        self._wobble_phase = (self._wobble_phase + 0.52) % (2.0 * _math.pi)
                        # FIX-OVERFLOW-BLINK-SYNC (v0.22.49): parpadeo de color ya NO
                        # se alterna aquí (cada tick ≈ 7.5 Hz). El timer
                        # _carola_waiting_blink_timer (480 ms) llama tick_overflow_blink()
                        # → mismo ritmo que la leyenda "¡OYE, ¿DÓNDE TE HAS METIDO?!".
                    else:
                        self._counter_overflow = False
                        self._wobble_phase     = 0.0
                        self._wobble_blink_vis = True
                else:
                    # SOBRANTE: seguir girando a velocidad media
                    _r_mid_mm = (self.R_MIN_MM + self.R_MAX_MM) / 2.0
                    self._reels.step_tape_uniform(self._tape_label, _r_mid_mm,
                                                  self._TAPE_DT_S)
            self._reels.set_tape_wobble(self._tape_label, self._counter_overflow,
                                        self._wobble_phase)

            changed = True

        if changed:
            self.update()

    def get_spec_log_data(self) -> dict:
        """
        Retorna un dict con los datos del cuentavueltas para el log de especificación.
        Llamar DESPUÉS de detener la grabación (cuando _counter_final_value es definitivo).

        C-60 / C-90:
          surplus_a       — vueltas sobrantes post-999 en Lado A
          surplus_b       — vueltas sobrantes post-999 en Lado B
          wrap_a_count    — cuántas veces retornó a 000 en Lado A
          wrap_b_count    — cuántas veces retornó a 000 en Lado B
          final_value     — valor del contador al detenerse (Lado B)

        OTROS:
          wrap_count      — cantidad de veces que el contador retornó a 000
          final_value     — valor del contador al detenerse
        """
        return {
            "tape_label":    self._tape_label,
            "is_otros":      self._is_otros,
            # C-60 / C-90
            "surplus_a":     self._counter_surplus_a,
            "surplus_b":     self._counter_surplus_b,
            "wrap_a_count":  self._counter_wrap_a_count,
            "wrap_b_count":  self._counter_wrap_b_count,
            # OTROS
            "wrap_count":    self._counter_wrap_count,
            # Compartido
            "final_value":   self._counter_final_value,
            # v0.22.37: estado de fase y volteo para detectar grabación truncada
            "phase":         self._phase,        # "A", "B" o "SOBRANTE"
            "flip_done":     self._flip_done,    # True = Lado A completó el ciclo y se volteó
        }

    def restore_counter_state(self, data: dict):
        """
        Restaura el estado del cuentavueltas desde un dict de crash-manifest.
        Llamar desde _do_crash_recovery() ANTES de que el usuario exporte,
        para que get_spec_log_data() devuelva los valores correctos y el log
        de especificación no muestre 000 en todos los campos.

        Campos esperados (todos opcionales, con fallback a 0/False/"A"):
          surplus_a, surplus_b, wrap_a_count, wrap_b_count,
          wrap_count, final_value, phase, flip_done
        """
        self._counter_surplus_a    = int(data.get("counter_surplus_a",    0))
        self._counter_surplus_b    = int(data.get("counter_surplus_b",    0))
        self._counter_wrap_a_count = int(data.get("counter_wrap_a_count", 0))
        self._counter_wrap_b_count = int(data.get("counter_wrap_b_count", 0))
        self._counter_wrap_count   = int(data.get("counter_wrap_count",   0))
        self._counter_final_value  = int(data.get("counter_final_value",  0))
        self._phase                = str(data.get("counter_phase",        "A"))
        self._flip_done            = bool(data.get("counter_flip_done",   False))
        _log.info(
            "TapeLogPanel %s: estado cuentavueltas restaurado desde crash-manifest "
            "(surplus_a=%d surplus_b=%d wrap_a=%d wrap_b=%d final=%d phase=%s flip=%s)",
            self._tape_label,
            self._counter_surplus_a, self._counter_surplus_b,
            self._counter_wrap_a_count, self._counter_wrap_b_count,
            self._counter_final_value, self._phase, self._flip_done,
        )

    def set_paused(self, paused):
        self._paused = paused
        if paused:
            # v0.20.14: inicia en True (en fase con _cafe_blink_state=True del
            # StatusDisplay) para que TapeLogPanel y log parpadeen JUNTOS en pausa
            # manual.  El cruce de fase es solo para carola_waiting (auto-pausa).
            self._pause_blink_vis = True
        else:
            self._pause_blink_vis = True
        self.update()

    def tick_pause_blink(self, phase=None):
        """Con `phase` (reloj maestro, 0.14.004) la asigna; sin ella alterna."""
        if self._paused:
            self._pause_blink_vis = (not self._pause_blink_vis) if phase is None else bool(phase)
            self.update()

    # ── Modo EL LORITO SE POSA EN EL PALO (SIPA) ────────────────────────────────────────

    def activate_carola_waiting(self):
        """Activa el modo auto-pausa silencio (independiente de pausa manual).
        v0.20.12: _carola_blink_phase arranca en True para que el parpadeo del
        TapeLogPanel sea OPUESTO al del StatusDisplay (_cafe_blink_state arranca
        en True → amarillo intenso).  Con fase True la leyenda empieza en amarillo
        mientras el StatusDisplay muestra rosado; al primer tick ambos invierten
        y quedan en oposición permanente (parpadeo cruzado sincronizado).
        """
        self._carola_waiting     = True
        self._carola_blink_phase = True   # opuesto al _cafe_blink_state=True inicial
        self._carola_blink_vis   = True
        self.update()

    def deactivate_carola_waiting(self):
        """Desactiva el modo auto-pausa silencio."""
        self._carola_waiting = False
        self.update()

    def tick_carola_blink(self, phase=None):
        """Avanza un ciclo de parpadeo para el modo EL LORITO SE POSA EN EL PALO (SIPA).
        Debe llamarse desde el timer de parpadeo del modo (SILENCE_BLINK_INTERVAL_MS).
        Alterna: gris → amarillo intenso → gris → ..."""
        if self._carola_waiting:
            # Con fase del reloj maestro se asigna: el cruce con el StatusDisplay
            # se conserva (ambos arrancan en True y reciben la misma fase).
            self._carola_blink_phase = (not self._carola_blink_phase) if phase is None else bool(phase)
            self.update()

    def tick_overflow_blink(self, phase=None):
        """Avanza un ciclo de parpadeo para el modo de desbordamiento
        (TU CINTA ES MUY LARGA... UPS!!). Sincronizado con _carola_waiting_blink_timer
        (SILENCE_BLINK_INTERVAL_MS = 480 ms) para que el ritmo sea idéntico al de la
        leyenda de pausa automática '¡OYE, ¿DÓNDE TE HAS METIDO?!' del StatusDisplay.
        FIX-OVERFLOW-BLINK-SYNC (v0.22.49): antes _wobble_blink_vis se alternaba en cada
        tick de update_state (~15 Hz → ~7.5 Hz), mucho más rápido que el parpadeo de
        la leyenda de autopause (480 ms → ~1.04 Hz). Ahora ambos comparten el mismo timer."""
        if self._counter_overflow:
            self._wobble_blink_vis = (not self._wobble_blink_vis) if phase is None else bool(phase)
            self.update()

    # ── Cuentavueltas externo (0.13) ─────────────────────────────────────────
    # Con `attach_counter_view()` el cuentavueltas de tambores ámbar
    # (`TapeCounterDrums`, SVG de la usuaria) es un control montado POR
    # FUERA del vidrio (criterio del Vitreous Subeventos del monolito de origen): hermano
    # de este panel, elevado sobre el Metaloric Panel. Este panel sigue
    # calculando la física de los rodillos y publica la instantánea. No pinta
    # nada detrás: el chasis y el bisel son los del SVG del cuentavueltas, así
    # que su acabado es idéntico encendido y apagado (pedido de la usuaria:
    # solo cambia el brillo de los tambores).
    def attach_counter_view(self, view) -> None:
        self._counter_view = view

    def _counter_reserve(self, default: int) -> int:
        cv = vars(self).get("_counter_view")
        return cv.width() + 8 if cv is not None else default

    def counter_snapshot(self):
        from lorito_aldhiro.frontend.widgets.lorito_tape_counter import CounterSnapshot
        if not self._active:
            state = "inactive"
        elif self._carola_waiting:
            state = "waiting"
        elif self._paused:
            state = "paused"
        else:
            state = "active"
        ovf = self._OVF_COLORS.get(self._tape_label, (255, 0, 204, 255))
        return CounterSnapshot(
            values=tuple(int(v) for v in self._mech_values),
            roll=tuple(float(r) for r in self._mech_digits),
            state=state, overflow=bool(self._counter_overflow),
            blink=bool(self._wobble_blink_vis), warn_rgb=tuple(ovf[:3]),
            rms=float(vars(self).get("_rms", 0.0)), label=self._tape_label)

    def paintEvent(self, ev):
        self._paint_panel()
        cv = vars(self).get("_counter_view")
        if cv is not None and self.isVisible():
            cv.set_snapshot(self.counter_snapshot(), "capture")

    def _paint_panel(self):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()

        # FIX v0.22.24: clip estricto al rect del widget para que nada
        # desborde ni deforme widgets vecinos.
        # Se usa QPainterPath redondeado (radio=5) idéntico al fondo.
        _clip_path = QPainterPath()
        _rr = 0 if self._fused else 5
        _clip_path.addRoundedRect(0, 0, w, h, _rr, _rr)
        p.setClipPath(_clip_path)

        cr, cg, cb, ca = self._MODE_COLORS.get(self._tape_label, (255, 25, 25, 245))
        legend_color = QColor(cr, cg, cb, ca)

        if self._tape_label == "C-60":
            label_text = "LORITO CAPTURA A LA CINTA C-60"
        elif self._tape_label == "C-90":
            label_text = "LORITO CAPTURA A LA CINTA C-90"
        else:
            label_text = "LORITO CAPTURA AL MODO LIBRE"

        # ── FIX-TAPE-DUR-SILENCE v0.22.22: color y leyenda de desbordamiento ──
        # Cuando _counter_overflow=True (cinta demasiado larga, contador en 999):
        #   · Color cambia a overflow (fucsia C-60 / amarillo C-90).
        #   · Leyenda cambia a "TU CINTA ES MUY LARGA... UPS!!" (parpadea con color).
        #   · El parpadeo alterna entre color overflow y color normal en cada tick.
        #   · El tambaleo lo hacen ahora los carretes del LCD (0.11.011).
        _ovf_r, _ovf_g, _ovf_b, _ovf_a = self._OVF_COLORS.get(
            self._tape_label, (255, 0, 204, 255))
        if self._counter_overflow:
            # FIX v0.22.24: parpadeo idéntico al de las leyendas de pausa automática
            # (amarillo↔gris). "LORITO CAPTURA..." desaparece en AMBAS fases.
            # Fase True  → amarillo intenso (idéntico a la fase "oye ven" de autopause)
            # Fase False → gris (idéntico a la fase "auto-pausa silencio activa")
            if self._wobble_blink_vis:
                # Fase amarillo: color amarillo brillante igual que _carola_waiting
                cr, cg, cb, ca = 255, 210, 0, 245
                legend_color = QColor(cr, cg, cb, ca)
            else:
                # Fase gris: color gris igual que _carola_waiting fase apagada
                cr, cg, cb, ca = 200, 200, 200, 180
                legend_color = QColor(cr, cg, cb, ca)
            # AMBAS fases: leyenda de desbordamiento (sin "LORITO CAPTURA...")
            label_text = "COOOORREEE!!! ESE CASSETTE ESTA LARGO!!!"

        # Metaloric Panel (0.11.008): misma ventana HUD que el visor de
        # señal y el panel de estado.
        from lorito_aldhiro.frontend.widgets.lorito_svg_panels import paint_metaloric_window
        paint_metaloric_window(p, w, h, fused=self._fused)

        # ── Retroiluminación tipo StatusDisplay ──────────────────────────────
        # v0.20.12: el tinte de fondo y el glow de borde se adecúan al color
        # de la fuente de la leyenda que se muestra en ese momento, no a un
        # color fijo por estado.  Así la retroiluminación siempre "rhima" con
        # el texto visible: amarillo cuando la leyenda es amarilla, gris/nulo
        # cuando la leyenda es gris, color de cinta cuando se graba, etc.
        _rl_tint = None
        _rl_glow = None
        if self._carola_waiting:
            # Auto-pausa silencio: la leyenda alterna amarillo ↔ gris.
            # La retroiluminación sigue el color de la fuente visible:
            #   fase True  → fuente amarillo (255,210,0)  → tinte amarillo
            #   fase False → fuente gris (200,200,200)    → tinte nulo (apagado)
            if self._carola_blink_phase:
                _rl_tint = QColor(255, 210,   0, 22)   # amarillo = color fuente activa
                _rl_glow = QColor(255, 200,   0, 50)
            else:
                _rl_tint = QColor(0, 0, 0, 0)
                _rl_glow = None
        elif self._paused:
            # Pausa manual: leyenda BUSYCHAN en gris (200,200,200).
            # Retroiluminación coincide con el color real de la fuente BUSYCHAN.
            if self._pause_blink_vis:
                _rl_tint = QColor(200, 200, 200, 22)   # gris = color fuente BUSYCHAN
                _rl_glow = QColor(255, 200,   0, 50)
            else:
                _rl_tint = QColor(0, 0, 0, 0)
                _rl_glow = None
        elif self._active:
            # Grabación activa: leyenda en color de la cinta (cr,cg,cb).
            # Retroiluminación = tinte suave del mismo color de la fuente.
            _rl_tint = QColor(cr, cg, cb, 12)
            _rl_glow = QColor(cr, cg, cb, 30)

        if _rl_tint and _rl_tint.alpha() > 0:
            p.setBrush(_rl_tint)
            p.drawRoundedRect(0, 0, w, h, _rr, _rr)
        if _rl_glow and not self._fused:
            # Borde interior con glow: líneas concéntricas DENTRO del rect,
            # nunca fuera — elimina el efecto fantasma en los bordes redondeados.
            p.setBrush(Qt.NoBrush)
            for _off in range(3):
                _ga = int(_rl_glow.alpha() * (3 - _off) / 3)
                p.setPen(QPen(QColor(_rl_glow.red(), _rl_glow.green(),
                                     _rl_glow.blue(), _ga), 1))
                p.drawRoundedRect(_off, _off, w - _off * 2 - 1,
                                  h - _off * 2 - 1, max(1, 5 - _off), max(1, 5 - _off))

        # Fuente unificada con StatusDisplay — sin negrita, efecto retroiluminado
        fnt_phase = font_leyendas(size=1)
        fnt_phase.setPixelSize(9)
        fnt_phase.setLetterSpacing(QFont.AbsoluteSpacing, 1)
        fnt_phase.setBold(False)

        # ── Modo EL LORITO SE POSA EN EL PALO (SIPA) (auto-pausa silencio) ─────────────
        # Se evalúa ANTES que BUSYCHAN para que pueda coexistir con la pausa
        # manual sin ser ocultado (tienen prioridades diferentes).
        if self._carola_waiting:
            # Colores del ciclo de parpadeo, sincronizados símbolo de pausa ↔ leyenda:
            #   fase False → gris   (200, 200, 200)
            #   fase True  → amarillo (255, 210, 0)
            if self._carola_blink_phase:
                cw_r, cw_g, cw_b = 255, 210, 0     # amarillo intenso
                cw_alpha = 240
            else:
                cw_r, cw_g, cw_b = 200, 200, 200   # gris
                cw_alpha = 180

            cw_color = QColor(cw_r, cw_g, cw_b, cw_alpha)

            cy  = h // 2

            # ── Símbolo de pausa ⏸ al inicio del panel (0.11.011: los hubs
            # que tenía a la izquierda se retiraron; giran los carretes del LCD)
            pause_x = self.TEXT_PAD
            bar_w, bar_h = 3, 11
            bar_gap      = 3
            by = cy - bar_h // 2
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(cw_r, cw_g, cw_b, cw_alpha))
            p.drawRect(pause_x,            by, bar_w, bar_h)
            p.drawRect(pause_x + bar_w + bar_gap, by, bar_w, bar_h)

            text_x = pause_x + bar_w * 2 + bar_gap + 5

            # ── Dos leyendas con la misma fase que el símbolo de pausa ───────
            _col_amarillo = QColor(255, 210,   0, 245)   # amarillo brillante fijo
            _col_gris     = QColor(200, 200, 200, 180)   # gris fijo
            p.setFont(fnt_phase)
            # (El rótulo "BUSY" que había entre los hubs y el símbolo de pausa
            # tenía 1 px de ancho y nunca se veía; se retiró con los hubs.)
            msg_rect = QRect(int(text_x), 0, int(w - text_x - self._counter_reserve(2)), h)
            # Si es auto-pausa de volteo (flip_pending) mostrar leyenda de volteo
            _is_flip_pause = getattr(self, "_flip_pending", False)
            if self._carola_blink_phase:
                p.setPen(_col_amarillo)
                if _is_flip_pause:
                    p.drawText(msg_rect, Qt.AlignCenter, "⏩ VOLTEAR CINTA — LADO B LISTO")
                else:
                    p.drawText(msg_rect, Qt.AlignCenter, "EL LORITO SE POSA EN EL PALO")
            else:
                p.setPen(_col_gris)
                if _is_flip_pause:
                    p.drawText(msg_rect, Qt.AlignCenter, "ESPERO")
                else:
                    p.drawText(msg_rect, Qt.AlignCenter, "EL LORITO SE POSA EN EL PALO")

            if not self._fused:
                p.setPen(QPen(QColor(cw_r, cw_g, cw_b, 35), 1))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(0, 0, w-1, h-1, 5, 5)
            p.end()
            return

        # Modo BUSYCHAN (pausa activa — pausa manual o auto-pausa)
        if self._paused:
            busychan_color = QColor(200, 200, 200, 220)
            if self._pause_blink_vis:
                p.setFont(fnt_phase)
                p.setPen(busychan_color)
                # Restaurar leyenda BUSYCHAN (tipo de cinta) en la zona del mid_rect,
                # igual que en modo activo, pero con prefijo "BUSYCHAN" para indicar pausa.
                p.setFont(fnt_phase)
                p.setPen(busychan_color)
                mid_rect = QRect(self.TEXT_PAD, 0, int(w - self.TEXT_PAD - self._counter_reserve(52)), h)
                busychan_label = f"BUSYCHAN  {label_text}"
                p.drawText(mid_rect, Qt.AlignCenter, busychan_label)

            if not self._fused:
                p.setPen(QPen(QColor(200, 200, 200, 35), 1))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(0, 0, w-1, h-1, 5, 5)
            p.end()
            return

        if not self._active:
            # EXPULSIÓN centrada en toda la pantalla, misma fuente que las
            # leyendas activas (fnt_phase). Sin selector de duracion ni contometro.
            p.setFont(fnt_phase)
            p.setPen(QColor(255, 255, 255, 200))
            p.drawText(QRect(0, 0, int(w - self._counter_reserve(0)), h), Qt.AlignCenter, "EXPULSIÓN")
            if not self._fused:
                p.setPen(QPen(QColor(40, 40, 40, 80), 1))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(0, 0, w-1, h-1, 5, 5)
            p.end()
            return

        # 0.11.011: los hubs, su embobinado y la línea de cinta se retiraron;
        # la rotación la orquestan los carretes del LCD Display.

        # Leyenda central
        # FIX v0.22.22: en overflow, label_text ya fue sobreescrito a
        # "TU CINTA ES MUY LARGA... UPS!!" y legend_color al color de overflow.
        # En overflow NO se añade "LADO A/B" — la leyenda de UPS es completa.
        if self._counter_overflow:
            phase_text = label_text   # "TU CINTA ES MUY LARGA... UPS!!"
        elif self._is_otros:
            phase_text = label_text if self._otros_blink_vis else ""
        else:
            phase_text = {
                "A":        f"{label_text}  LADO A",
                "B":        f"{label_text}  LADO B",
                "SOBRANTE": f"{label_text}  SOBRANTE",
            }.get(self._phase, label_text)

        p.setFont(fnt_phase)
        p.setPen(legend_color)

        mid_x    = self.TEXT_PAD
        mid_w    = w - self.TEXT_PAD - self._counter_reserve(52)
        # FIX v0.22.24: la leyenda NO tambalea — rect fijo en coordenadas del widget.
        mid_rect = QRect(int(mid_x), 0, int(mid_w), h)
        p.drawText(mid_rect, Qt.AlignCenter, phase_text)

        # ── Contador mecánico analógico (3 rodillos, estilo Tape Counter de deck) ─
        # El contador muestra el tiempo en segundos (0–999 s).
        # La animación de giro es proporcional a la velocidad de la bobina
        # receptora: inicio → giro rápido (bobina pequeña), final → lento.
        # Solo en modo OTROS la animación es lineal.

        cnt_secs = max(0, self._counter)
        cnt_val  = min(cnt_secs, 999)   # valor en segundos, máximo 999

        # ── Velocidad de giro de los rodillos según física IEC exacta ───────
        # _mech_speed_factor: proporción entre la velocidad angular actual del
        # receptor y su velocidad mínima (en radio máximo).
        #   factor = R_MAX / r_recv(t) = (r_max/r_min al inicio) → 1.0 al final
        # Mayor factor → giro de animación más pronunciado (inicio de cinta).
        # Este factor es idéntico al usado en update_state para los ángulos reales.

        if self._is_otros:
            _mech_speed_factor = 1.0   # OTROS: lineal
        else:
            seg_dur_c = (self._side_a_secs if self._phase in ("A",)
                         else self._total_secs - self._side_a_secs
                              if self._phase == "B" else 1.0)
            seg_el_c = max(0.0, self._elapsed - self._counter_base)
            t_c = max(0.0, min(1.0, seg_el_c / max(seg_dur_c, 1.0)))
            # r_recv en mm usando la física IEC exacta (misma fórmula que update_state)
            dr_c = self.R_MAX_MM - self.R_MIN_MM
            r_recv_c_mm = self.R_MIN_MM + dr_c * t_c
            r_recv_c_mm = max(self.R_MIN_MM * 0.5, r_recv_c_mm)
            # factor: R_MAX/r_recv → máx al inicio, 1.0 al final
            _mech_speed_factor = self.R_MAX_MM / r_recv_c_mm

        # Detectar cambio de valor para activar animación de giro
        if cnt_val != self._mech_prev_cnt:
            if self._mech_prev_cnt >= 0:
                diff = cnt_val - self._mech_prev_cnt
                if diff > 0:
                    d0 = cnt_val % 10
                    d1 = (cnt_val // 10) % 10
                    d2 = (cnt_val // 100) % 10
                    p0 = self._mech_prev_cnt % 10
                    p1 = (self._mech_prev_cnt // 10) % 10
                    p2 = (self._mech_prev_cnt // 100) % 10
                    # La velocidad de giro se escala por _mech_speed_factor:
                    # mayor factor → impulso de giro más pronunciado
                    _roll_impulse = min(1.0, 0.55 + _mech_speed_factor * 0.25)
                    if d0 != p0:
                        self._mech_digits[2] = min(self._mech_digits[2] + _roll_impulse, 1.0)
                    if d1 != p1:
                        self._mech_digits[1] = min(self._mech_digits[1] + _roll_impulse, 1.0)
                    if d2 != p2:
                        self._mech_digits[0] = min(self._mech_digits[0] + _roll_impulse, 1.0)
                    self._mech_values = [d2, d1, d0]
            else:
                self._mech_values = [
                    (cnt_val // 100) % 10,
                    (cnt_val // 10)  % 10,
                    cnt_val % 10,
                ]
            self._mech_prev_cnt = cnt_val

        # Decay del giro — más rápido al inicio (alta velocidad), más lento al final
        # Esto da la ilusión de que el rodillo gira con inercia proporcional a la cinta
        ROLL_DECAY_BASE = 0.14
        _roll_decay = ROLL_DECAY_BASE + (1.0 - ROLL_DECAY_BASE) * min(1.0, (_mech_speed_factor - 1.0) * 0.3) if not self._is_otros else ROLL_DECAY_BASE
        for i in range(3):
            if self._mech_digits[i] > 0.001:
                self._mech_digits[i] *= (1.0 - _roll_decay)
            else:
                self._mech_digits[i] = 0.0

        # 0.13: con cuentavueltas externo, aquí no se pinta nada de él.
        if vars(self).get("_counter_view") is not None:
            if not self._fused:
                p.setPen(QPen(QColor(cr, cg, cb, 35), 1))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(0, 0, w-1, h-1, 5, 5)
            p.end()
            return

        # ── Geometría del contador (caja de rodillos estilo deck) ─────────────
        DIGIT_W  = 14; DIGIT_H = h - 4; DIGIT_GAP = 2
        N_DIGITS = 3
        cnt_total_w = N_DIGITS * DIGIT_W + (N_DIGITS - 1) * DIGIT_GAP
        cnt_x0 = w - cnt_total_w - 4
        # FIX v0.22.24: el cuentavueltas NO tambalea — posición fija.
        cnt_y0 = 2

        # Caja exterior del contador (carcasa metálica)
        _box_x = cnt_x0 - 3
        _box_w = cnt_total_w + 6
        _box_y = cnt_y0 - 1
        _box_h = DIGIT_H + 2
        # Gradiente de la carcasa: gris oscuro con brillo metálico
        _box_grad = QLinearGradient(_box_x, _box_y, _box_x, _box_y + _box_h)
        _box_grad.setColorAt(0.0, QColor(40, 40, 40, 240))
        _box_grad.setColorAt(0.4, QColor(22, 22, 22, 250))
        _box_grad.setColorAt(1.0, QColor(8, 8, 8, 255))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(_box_grad))
        p.drawRoundedRect(_box_x, _box_y, _box_w, _box_h, 3, 3)

        # Borde metálico de la carcasa
        p.setPen(QPen(QColor(cr, cg, cb, 60), 0.9))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(_box_x, _box_y, _box_w, _box_h, 3, 3)

        # Sombra interna arriba y abajo (efecto de profundidad del visor)
        p.setPen(QPen(QColor(0, 0, 0, 120), 1.5))
        p.drawLine(_box_x + 2, _box_y + 1, _box_x + _box_w - 2, _box_y + 1)
        p.drawLine(_box_x + 2, _box_y + _box_h - 2, _box_x + _box_w - 2, _box_y + _box_h - 2)

        # ── Fuente de los rodillos ─────────────────────────────────────────────
        fnt_mech = font_cuentavueltas(size=1)
        fnt_mech.setPixelSize(max(8, DIGIT_H - 3))
        fnt_mech.setBold(True)
        fnt_mech.setLetterSpacing(QFont.AbsoluteSpacing, 0)

        for i in range(N_DIGITS):
            dx = cnt_x0 + i * (DIGIT_W + DIGIT_GAP)
            dy = cnt_y0
            roll = self._mech_digits[i]       # 0.0=quieto, >0=girando
            cur_d = self._mech_values[i]
            nxt_d = (cur_d + 1) % 10

            # Fondo del visor individual (negro profundo)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(3, 3, 3, 255))
            p.drawRect(dx, dy, DIGIT_W, DIGIT_H)

            # Gradiente de fondo del rodillo (efecto curvatura del cilindro)
            _roll_bg = QLinearGradient(dx, dy, dx + DIGIT_W, dy)
            _roll_bg.setColorAt(0.0,  QColor(0, 0, 0, 255))
            _roll_bg.setColorAt(0.15, QColor(8, 8, 8, 255))
            _roll_bg.setColorAt(0.5,  QColor(14, 14, 14, 255))
            _roll_bg.setColorAt(0.85, QColor(8, 8, 8, 255))
            _roll_bg.setColorAt(1.0,  QColor(0, 0, 0, 255))
            p.setBrush(QBrush(_roll_bg))
            p.drawRect(dx, dy, DIGIT_W, DIGIT_H)

            # Clip al rectángulo del dígito
            p.save()
            p.setClipRect(dx, dy, DIGIT_W, DIGIT_H)

            # Posición Y del dígito: el rodillo gira hacia arriba (el siguiente entra desde abajo)
            # roll=0 → actual en dy (visible completo); roll=1 → actual salió arriba, siguiente en dy
            cy_cur = dy + int(-roll * DIGIT_H)
            cy_nxt = dy + int((1.0 - roll) * DIGIT_H)

            alpha_cur = int(255 * max(0.0, 1.0 - roll * 1.4))
            alpha_nxt = int(255 * min(1.0, roll * 1.4))

            # Glow analógico (RMS)
            _rms = getattr(self, "_rms", 0.0)
            glow_a = int(min(50, _rms * 80))

            # Dígito actual
            if alpha_cur > 6:
                col_cur = QColor(cr, cg, cb, alpha_cur)
                if glow_a > 0 and roll < 0.25:
                    p.setPen(QColor(cr, cg, cb, min(alpha_cur // 3, glow_a)))
                    for _dxy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        p.setFont(fnt_mech)
                        p.drawText(QRect(dx + _dxy[0], cy_cur + _dxy[1], DIGIT_W, DIGIT_H),
                                   Qt.AlignHCenter | Qt.AlignTop, str(cur_d))
                p.setPen(col_cur)
                p.setFont(fnt_mech)
                p.drawText(QRect(dx, cy_cur, DIGIT_W, DIGIT_H),
                           Qt.AlignHCenter | Qt.AlignTop, str(cur_d))

            # Dígito siguiente (entra desde abajo)
            if alpha_nxt > 6:
                col_nxt = QColor(cr, cg, cb, alpha_nxt)
                p.setPen(col_nxt)
                p.setFont(fnt_mech)
                p.drawText(QRect(dx, cy_nxt, DIGIT_W, DIGIT_H),
                           Qt.AlignHCenter | Qt.AlignTop, str(nxt_d))

            p.restore()

            # Separadores verticales (ranuras entre rodillos)
            if i < N_DIGITS - 1:
                sep_x = dx + DIGIT_W
                p.setPen(QPen(QColor(0, 0, 0, 200), 2))
                p.drawLine(sep_x, cnt_y0, sep_x + DIGIT_GAP, cnt_y0 + DIGIT_H)
                p.setPen(QPen(QColor(cr, cg, cb, 30), 0.5))
                p.drawLine(sep_x, cnt_y0 + 2, sep_x, cnt_y0 + DIGIT_H - 2)

            # Sombra lateral del rodillo (efecto cilíndrico)
            _sh_l = QLinearGradient(dx, dy, dx + 3, dy)
            _sh_l.setColorAt(0.0, QColor(0, 0, 0, 160))
            _sh_l.setColorAt(1.0, QColor(0, 0, 0, 0))
            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(_sh_l))
            p.drawRect(dx, dy, 3, DIGIT_H)
            _sh_r = QLinearGradient(dx + DIGIT_W - 3, dy, dx + DIGIT_W, dy)
            _sh_r.setColorAt(0.0, QColor(0, 0, 0, 0))
            _sh_r.setColorAt(1.0, QColor(0, 0, 0, 160))
            p.setBrush(QBrush(_sh_r))
            p.drawRect(dx + DIGIT_W - 3, dy, 3, DIGIT_H)

            # Reflejo superior del visor (vidrio)
            refl = QLinearGradient(dx, dy, dx, dy + DIGIT_H // 3)
            refl.setColorAt(0.0, QColor(255, 255, 255, 18))
            refl.setColorAt(1.0, QColor(255, 255, 255, 0))
            p.setBrush(QBrush(refl))
            p.drawRect(dx, dy, DIGIT_W, DIGIT_H // 3)

        # ── Guía de lectura central (línea de referencia del deck) ─────────────
        guide_y = cnt_y0 + DIGIT_H // 2
        p.setPen(QPen(QColor(cr, cg, cb, 45), 0.6))
        p.drawLine(_box_x + 1, guide_y, _box_x + _box_w - 1, guide_y)
        # Sombra sobre la guía (parte superior del visor más oscura)
        _top_grad = QLinearGradient(_box_x, _box_y, _box_x, guide_y)
        _top_grad.setColorAt(0.0, QColor(0, 0, 0, 60))
        _top_grad.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(_top_grad))
        p.drawRoundedRect(_box_x, _box_y, _box_w, guide_y - _box_y, 3, 3)

        # Borde del panel
        if not self._fused:
            p.setPen(QPen(QColor(cr, cg, cb, 35), 1))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(0, 0, w-1, h-1, 5, 5)

        p.end()
